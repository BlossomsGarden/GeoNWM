"""Four independent 1x1 projections followed by channel concatenation."""

from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import nn

from da3_tok.contracts import (
    FEATURE_DIM,
    FEATURE_LAYERS,
    PATCH_TOKENS,
    TOKEN_HEIGHT,
    TOKEN_WIDTH,
)


class FourLayerConvConcatFusion(nn.Module):
    """Compress each DA3 level to 384 channels and concatenate in layer order."""

    PROJECTION_DIM = FEATURE_DIM // len(FEATURE_LAYERS)

    def __init__(
        self,
        dim: int = FEATURE_DIM,
        layers: Sequence[int] = FEATURE_LAYERS,
    ) -> None:
        super().__init__()
        if tuple(layers) != FEATURE_LAYERS:
            raise ValueError(f"DA3-Tok-cat feature layers must be {FEATURE_LAYERS}, got {tuple(layers)}")
        if dim != FEATURE_DIM:
            raise ValueError(f"DA3-Tok-cat feature dim must be {FEATURE_DIM}, got {dim}")
        self.layers = tuple(layers)
        self.norms = nn.ModuleList(nn.LayerNorm(dim) for _ in self.layers)
        self.projections = nn.ModuleList(
            nn.Conv2d(dim, self.PROJECTION_DIM, kernel_size=1, bias=True)
            for _ in self.layers
        )

    def forward(self, features: Sequence[torch.Tensor]) -> torch.Tensor:
        if len(features) != len(self.layers):
            raise ValueError(f"Expected {len(self.layers)} feature levels, got {len(features)}")
        shape = features[0].shape
        if len(shape) != 4 or tuple(shape[-2:]) != (PATCH_TOKENS, FEATURE_DIM):
            raise ValueError(
                f"Expected [B,V,{PATCH_TOKENS},{FEATURE_DIM}] features, got {tuple(shape)}"
            )
        batch, views = shape[:2]
        compressed: list[torch.Tensor] = []
        for layer, norm, projection, feature in zip(
            self.layers, self.norms, self.projections, features
        ):
            if feature.shape != shape:
                raise ValueError(
                    f"Layer {layer} has {tuple(feature.shape)}, expected {tuple(shape)}"
                )
            spatial = norm(feature).reshape(
                batch * views, TOKEN_HEIGHT, TOKEN_WIDTH, FEATURE_DIM
            )
            spatial = spatial.permute(0, 3, 1, 2).contiguous()
            projected = projection(spatial)
            tokens = projected.flatten(2).transpose(1, 2).reshape(
                batch, views, PATCH_TOKENS, self.PROJECTION_DIM
            )
            compressed.append(tokens)
        return torch.cat(compressed, dim=-1)
