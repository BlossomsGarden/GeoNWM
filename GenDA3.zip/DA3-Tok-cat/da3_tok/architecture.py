"""Serializable architecture identity for conv-concat parity audits."""

from __future__ import annotations


def architecture_manifest() -> dict[str, object]:
    return {
        "encoder": {
            "type": "geometry_aware_da3_frozen",
            "feature_layers": [5, 7, 9, 11],
            "feature_dim": 1536,
            "patch_tokens": 1040,
        },
        "fusion": {
            "type": "four_independent_conv1x1_concat",
            "independent_layer_norms": 4,
            "independent_conv1x1": 4,
            "per_layer_output_dim": 384,
            "activation": None,
            "scalar_softmax_logits": 0,
            "final_layer_mean_token_broadcast": False,
            "output_dim": 1536,
        },
        "rgb_decoder": {
            "type": "gld_general_decoder_variable",
            "input_dim": 1536,
            "hidden_dim": 1152,
            "layers": 28,
            "heads": 16,
            "intermediate_dim": 4096,
            "base_image_size": [504, 504],
            "patch_size": 14,
        },
        "dense_decoder": {
            "type": "shared_spatial_decoder",
            "input_dim": 1536,
            "outputs": ["depth", "semantic_logits"],
        },
    }
