"""Fatal-on-error JSONL logging, curves, confusion matrices, and visuals."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

import numpy as np


def append_jsonl(path: str | Path, record: Mapping[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(dict(record), ensure_ascii=False, separators=(",", ":")) + "\n")


def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _pyplot():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    return plt


def _plot_scalar_curves(records, keys, output: Path, title: str) -> None:
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(10, 5))
    plotted = False
    for key in keys:
        points = [(int(record["step"]), float(record[key])) for record in records if key in record]
        if points:
            axis.plot([point[0] for point in points], [point[1] for point in points], label=key)
            plotted = True
    if plotted:
        axis.legend(ncol=2)
    axis.set_xlabel("step")
    axis.set_title(title)
    axis.grid(alpha=0.25)
    figure.tight_layout()
    figure.savefig(output, dpi=150)
    plt.close(figure)


def _plot_semantic_iou(records, output: Path, title: str) -> None:
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(10, 5))
    for class_index in range(10):
        points = []
        for record in records:
            values = record.get("semantic_per_class_iou")
            if isinstance(values, list) and class_index < len(values) and values[class_index] is not None:
                points.append((int(record["step"]), float(values[class_index])))
        if points:
            axis.plot([point[0] for point in points], [point[1] for point in points], label=str(class_index))
    axis.set_xlabel("step")
    axis.set_ylabel("IoU")
    axis.set_title(title)
    axis.legend(ncol=5, title="class")
    axis.grid(alpha=0.25)
    figure.tight_layout()
    figure.savefig(output, dpi=150)
    plt.close(figure)


def _plot_confusion(record: Mapping[str, Any], output: Path) -> None:
    confusion = np.asarray(record["semantic_confusion"], dtype=np.float64)
    if confusion.shape != (10, 10):
        raise ValueError(f"Semantic confusion must be 10x10, got {confusion.shape}")
    rows = confusion.sum(axis=1, keepdims=True)
    normalized = np.divide(confusion, rows, out=np.zeros_like(confusion), where=rows > 0)
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(7, 6))
    image = axis.imshow(normalized, vmin=0.0, vmax=1.0, cmap="viridis")
    axis.set_xlabel("predicted")
    axis.set_ylabel("target")
    axis.set_xticks(range(10))
    axis.set_yticks(range(10))
    figure.colorbar(image, ax=axis)
    figure.tight_layout()
    figure.savefig(output, dpi=150)
    plt.close(figure)


def render_curve_artifacts(run_dir: str | Path) -> None:
    run_dir = Path(run_dir)
    train = read_jsonl(run_dir / "train_metrics.jsonl")
    dev = read_jsonl(run_dir / "dev_metrics.jsonl")
    val = read_jsonl(run_dir / "val_metrics.jsonl")
    if not train or not dev or not val:
        raise RuntimeError("Curve rendering requires non-empty train/dev/val JSONL logs")
    loss_keys = ("total", "rgb", "perceptual", "depth", "point", "semantic")
    metric_keys = (
        "rgb_l1", "rgb_lpips", "rgb_psnr", "rgb_ssim", "depth_abs_rel",
        "depth_rmse", "depth_delta1", "point_l2", "point_z_abs", "point_xy_l2",
        "semantic_miou", "semantic_pixel_accuracy",
    )
    _plot_scalar_curves(train, loss_keys, run_dir / "loss_curves.png", "Training losses")
    _plot_scalar_curves(dev, metric_keys, run_dir / "metric_curves_dev.png", "Dev metrics")
    _plot_scalar_curves(val, metric_keys, run_dir / "metric_curves_val.png", "Val metrics")
    _plot_semantic_iou(dev, run_dir / "semantic_iou_curves_dev.png", "Dev semantic IoU")
    _plot_semantic_iou(val, run_dir / "semantic_iou_curves_val.png", "Val semantic IoU")
    _plot_confusion(dev[-1], run_dir / "semantic_confusion_latest.png")


def save_joint_visualization(
    path: str | Path,
    batch: Mapping[str, Any],
    prediction: Mapping[str, Any],
) -> None:
    """Save CAM_FRONT RGB target/reconstruction, depth, and semantic panels."""
    rgb_target = batch["rgb_01"][0, 0].permute(1, 2, 0).numpy()
    rgb_prediction = prediction["rgb"][0, 0].permute(1, 2, 0).numpy()
    depth = prediction["depth"][0, 0, 0].numpy()
    semantic = prediction["semantic_logits"][0, 0].argmax(0).numpy()
    plt = _pyplot()
    figure, axes = plt.subplots(1, 4, figsize=(16, 4))
    axes[0].imshow(np.clip(rgb_target, 0.0, 1.0))
    axes[1].imshow(np.clip(rgb_prediction, 0.0, 1.0))
    axes[2].imshow(depth, cmap="magma")
    axes[3].imshow(semantic, vmin=0, vmax=9, cmap="tab10")
    for axis in axes:
        axis.axis("off")
    figure.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(path, dpi=150)
    plt.close(figure)
