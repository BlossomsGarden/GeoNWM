# DA3-Tok-cat

This is the conv-concat counterpart to `DA3-Tok-MAE-style`. The two experiments use the same six-view data, frozen geometry-aware DA3 encoder, GLD MAE RGB decoder, compact depth/semantic decoder, joint losses, GAN schedule, optimizer, EMA, evaluation subsets, metrics, and checkpoint policy. Their only representation-level variable is how blocks `[5,7,9,11]` become one 1536-channel feature.

## Conv-Concat Fusion

One nuScenes keyframe contains six synchronized cameras in this exact order:

```text
CAM_FRONT, CAM_FRONT_RIGHT, CAM_BACK_RIGHT,
CAM_BACK, CAM_BACK_LEFT, CAM_FRONT_LEFT
```

All modalities and camera matrices must already be aligned to `280x728`. The loader does not resize, warp, reorder, repair, or substitute camera views.

The frozen DA3-BASE encoder jointly processes the six views and returns four tensors:

```text
block [5,7,9,11]: 4 x [B,6,1040,1536]
```

Each level has its own learnable path:

```text
LayerNorm(1536)
[B,6,1040,1536] -> [B*6,1536,20,52]
Conv2d(1536,384,kernel_size=1,bias=True)
no activation
[B*6,384,20,52] -> [B,6,1040,384]
```

The four results are concatenated in block order to `[B,6,1040,1536]`. The four convolutions do not share parameters. This fusion has no `layer_logits`, scalar softmax gating, weighted elementwise sum, token pooling, or block-11 mean-token broadcast.

`da3_tok/architecture.py` records the formal architecture identity. The completed acceptance audit confirmed that the MAE-style and cat manifests are equal after removing only the `fusion` entry, and that all downstream implementation files and vendored GLD files are byte-identical; the result is archived in `../DA3-Tok-design-0729.md`.

## Unchanged Heads And Objective

The RGB branch is the vendored GLD `GeneralDecoder_Variable` with only its input width set to 1536:

```text
decoder_embed             Linear(1536,1152)
base positional grid      504x504 -> bicubic interpolation to 20x52
decoder layers            28
attention heads           16
intermediate width        4096
patch size                14
dropout                    0
```

Depth and semantic use the same compact shared spatial decoder as `DA3-Tok-MAE-style`; points are derived by backprojecting predicted depth with intrinsics.

```text
rgb_loss = RGB L1 + LPIPS
         + I(step >= 6000) * 0.75 * adaptive_weight * vanilla_GAN_G

total = rgb_loss + depth + 0.02 * point + 0.50 * semantic
```

Adaptive weight is the gradient-norm ratio on `rgb_decoder.core.decoder_pred.weight`, clamped to 10000. The hinge-loss discriminator begins one update per successful generator step at step 4000; generator GAN begins at step 6000. Real/fake use the same random `224x224` crop, DiffAug probability 1, cutout 0, no blur warm-up, and D fake clamp plus approximate 8-bit quantization. DINO-S/8 is frozen and only discriminator heads train.

The generator uses AdamW betas `(0.9,0.95)`, LR `2e-4`, 1000-step warm-up, cosine decay to `2e-5` at step 40000, and weight decay 0. The discriminator scheduler uses actual D update count, with 1000 update warm-up and decay ending at update 16000.

## Evaluation And Checkpoints

Full-generator EMA decay is `0.9978`, updated after every successful generator optimizer step. EMA is used for dev/val, best checkpoints, milestones, and visualizations. Frozen DA3, DINO discriminator backbone, and LPIPS are excluded from EMA and checkpoints.

The first run fixes 64 dev samples and 64 val samples with seed `20260729`. Each sample contains all six views; subset JSON files persist manifest hashes and camera tokens. Every 1000 steps, EMA is evaluated once on both subsets at full `280x728`. Dev alone selects best joint/RGB/depth/point/semantic checkpoints; val is monitoring-only. Metrics are recorded globally and per camera.

`latest.pt` is the only resumable checkpoint and contains raw trainable generator modules, EMA, optimizers, schedulers, scaler, trainable discriminator heads, actual D update count, RNG, stream position, resolved config, model identity, and metrics. Best files and 5000-step milestones contain EMA inference weights and metadata only. No checkpoint contains the DA3 backbone.

Unlike weighted fusion experiments, cat has no fusion-weight curve because there are no scalar fusion weights to log.

## Commands

Build strict six-view manifests with the local `build_manifests.py`. Training:

```powershell
torchrun --standalone --nproc_per_node=2 -m da3_tok.train `
  --config configs/train.yaml `
  --train-manifest C:\data\manifests\train.jsonl `
  --dev-manifest C:\data\manifests\dev.jsonl `
  --val-manifest C:\data\manifests\val.jsonl `
  --semantic-mapping configs\semantic_label_mapping.json `
  --da3-model-dir C:\models\DA3-BASE `
  --dino-discriminator-checkpoint C:\models\discs\dino_vit_small_patch8_224.pth `
  --lpips-checkpoint C:\models\lpips\vgg.pth `
  --run-dir C:\runs\da3_tok_cat
```

`--lpips-checkpoint` must point to GLD's LPIPS linear weights with MD5 `d507d7349b931f0638a25a48a722f98a`. Resume with the same resolved inputs and `--resume C:\runs\da3_tok_cat\latest.pt`. Schema, config, manifest, architecture, DA3, DINO, and LPIPS identity mismatches fail; weighted-fusion checkpoints are not accepted.
