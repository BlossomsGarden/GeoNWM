"""DDP-reducible aggregate and per-camera dense prediction metrics."""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from typing import Any

import torch
import torch.distributed as dist
import torch.nn.functional as F

from da3_tok.contracts import CAMERA_ORDER
from da3_tok.geometry import backproject_depth


RGB_ABS = 0
RGB_SQ = 1
RGB_COUNT = 2
LPIPS_SUM = 3
LPIPS_COUNT = 4
SSIM_SUM = 5
SSIM_COUNT = 6
DEPTH_ABS_REL = 7
DEPTH_SQ = 8
DEPTH_DELTA1 = 9
DEPTH_COUNT = 10
POINT_L2 = 11
POINT_Z = 12
POINT_XY = 13
POINT_FRAME_COUNT = 14
SAMPLE_COUNT = 15
VIEW_COUNT = 16
STAT_COUNT = 17


def structural_similarity_per_view(
    prediction: torch.Tensor,
    target: torch.Tensor,
    window_size: int = 11,
    sigma: float = 1.5,
) -> torch.Tensor:
    """Return Gaussian-window RGB SSIM for each ``[N,C,H,W]`` camera view."""
    if prediction.shape != target.shape or prediction.ndim != 4:
        raise ValueError("SSIM prediction and target must have matching [N,C,H,W] shapes")
    if window_size % 2 != 1 or window_size < 3:
        raise ValueError("SSIM window_size must be an odd integer >= 3")
    if min(prediction.shape[-2:]) <= window_size // 2:
        raise ValueError("SSIM views are too small for reflect padding")
    prediction = prediction.float().clamp(0.0, 1.0)
    target = target.float().clamp(0.0, 1.0)
    coordinates = torch.arange(window_size, device=prediction.device, dtype=prediction.dtype)
    coordinates -= (window_size - 1) / 2.0
    kernel_1d = torch.exp(-coordinates.square() / (2.0 * sigma**2))
    kernel_1d /= kernel_1d.sum()
    kernel_2d = kernel_1d[:, None] * kernel_1d[None, :]
    channels = prediction.shape[1]
    kernel = kernel_2d.expand(channels, 1, window_size, window_size)
    padding = window_size // 2

    def local_mean(values: torch.Tensor) -> torch.Tensor:
        return F.conv2d(F.pad(values, (padding,) * 4, mode="reflect"), kernel, groups=channels)

    mean_prediction = local_mean(prediction)
    mean_target = local_mean(target)
    variance_prediction = local_mean(prediction.square()) - mean_prediction.square()
    variance_target = local_mean(target.square()) - mean_target.square()
    covariance = local_mean(prediction * target) - mean_prediction * mean_target
    c1 = 0.01**2
    c2 = 0.03**2
    numerator = (2.0 * mean_prediction * mean_target + c1) * (2.0 * covariance + c2)
    denominator = (mean_prediction.square() + mean_target.square() + c1) * (
        variance_prediction + variance_target + c2
    )
    return (numerator / denominator.clamp_min(1e-12)).mean(dim=(1, 2, 3))


def _require_finite(name: str, values: torch.Tensor, mask: torch.Tensor | None = None) -> None:
    selected = values if mask is None else values[mask.expand_as(values)]
    if not torch.isfinite(selected).all():
        raise FloatingPointError(f"{name} contains NaN or Inf on valid target pixels")


class DenseMetricAccumulator:
    """Accumulate all metrics as sums/counts for exact rank-independent reduction."""

    def __init__(
        self,
        semantic_classes: int,
        device: torch.device,
        lpips_metric: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    ) -> None:
        if semantic_classes <= 0:
            raise ValueError("semantic_classes must be positive")
        if lpips_metric is None:
            raise ValueError("lpips_metric is required for formal evaluation")
        self.semantic_classes = semantic_classes
        self.lpips_metric = lpips_metric
        self.stats = torch.zeros((1 + len(CAMERA_ORDER), STAT_COUNT), dtype=torch.float64, device=device)
        self.confusion = torch.zeros(
            (1 + len(CAMERA_ORDER), semantic_classes, semantic_classes),
            dtype=torch.int64,
            device=device,
        )

    @torch.no_grad()
    def _update_domain(
        self,
        domain: int,
        predicted_rgb: torch.Tensor,
        target_rgb: torch.Tensor,
        predicted_depth: torch.Tensor,
        target_depth: torch.Tensor,
        depth_valid: torch.Tensor,
        semantic_logits: torch.Tensor,
        semantic_target: torch.Tensor,
        semantic_valid: torch.Tensor,
        intrinsics: torch.Tensor,
        sample_count: int,
        view_count: int,
    ) -> None:
        _require_finite("rgb", predicted_rgb)
        _require_finite("depth", predicted_depth, depth_valid)
        _require_finite("semantic_logits", semantic_logits, semantic_valid.unsqueeze(1))
        predicted_rgb = predicted_rgb.float().clamp(0.0, 1.0)
        target_rgb = target_rgb.float().clamp(0.0, 1.0)
        rgb_error = predicted_rgb - target_rgb
        self.stats[domain, RGB_ABS] += rgb_error.abs().sum(dtype=torch.float64)
        self.stats[domain, RGB_SQ] += rgb_error.square().sum(dtype=torch.float64)
        self.stats[domain, RGB_COUNT] += rgb_error.numel()
        lpips = self.lpips_metric(predicted_rgb.mul(2.0).sub(1.0), target_rgb.mul(2.0).sub(1.0))
        lpips = torch.as_tensor(lpips, device=predicted_rgb.device).reshape(predicted_rgb.shape[0], -1).mean(1)
        _require_finite("rgb_lpips", lpips)
        self.stats[domain, LPIPS_SUM] += lpips.sum(dtype=torch.float64)
        self.stats[domain, LPIPS_COUNT] += lpips.numel()
        ssim = structural_similarity_per_view(predicted_rgb, target_rgb)
        self.stats[domain, SSIM_SUM] += ssim.sum(dtype=torch.float64)
        self.stats[domain, SSIM_COUNT] += ssim.numel()

        predicted_depth = predicted_depth.float()
        target_depth = target_depth.float()
        valid = depth_valid.bool() & torch.isfinite(target_depth) & target_depth.gt(0.0)
        if valid.any():
            predicted_values = predicted_depth[valid].clamp_min(1e-6)
            target_values = target_depth[valid]
            difference = predicted_values - target_values
            self.stats[domain, DEPTH_ABS_REL] += (difference.abs() / target_values).sum(dtype=torch.float64)
            self.stats[domain, DEPTH_SQ] += difference.square().sum(dtype=torch.float64)
            ratio = torch.maximum(predicted_values / target_values, target_values / predicted_values)
            self.stats[domain, DEPTH_DELTA1] += ratio.lt(1.25).sum(dtype=torch.float64)
            self.stats[domain, DEPTH_COUNT] += target_values.numel()

        predicted_points = backproject_depth(predicted_depth, intrinsics)
        target_points = backproject_depth(target_depth, intrinsics)
        for pred, truth, frame_valid in zip(predicted_points, target_points, valid.squeeze(1)):
            if not frame_valid.any():
                continue
            difference = pred[:, frame_valid] - truth[:, frame_valid]
            self.stats[domain, POINT_L2] += torch.linalg.vector_norm(difference, dim=0).mean().double()
            self.stats[domain, POINT_Z] += difference[2].abs().mean().double()
            self.stats[domain, POINT_XY] += torch.linalg.vector_norm(difference[:2], dim=0).mean().double()
            self.stats[domain, POINT_FRAME_COUNT] += 1

        valid_semantic = semantic_valid.bool() & semantic_target.ge(0) & semantic_target.lt(
            self.semantic_classes
        )
        if valid_semantic.any():
            predicted_class = semantic_logits.argmax(dim=1)
            target_values = semantic_target[valid_semantic]
            predicted_values = predicted_class[valid_semantic]
            encoded = target_values * self.semantic_classes + predicted_values
            counts = torch.bincount(encoded, minlength=self.semantic_classes**2)
            self.confusion[domain] += counts.reshape(self.semantic_classes, self.semantic_classes)
        self.stats[domain, SAMPLE_COUNT] += sample_count
        self.stats[domain, VIEW_COUNT] += view_count

    @torch.no_grad()
    def update(self, prediction: Mapping[str, torch.Tensor], batch: Mapping[str, torch.Tensor]) -> None:
        rgb = prediction["rgb"]
        depth = prediction["depth"]
        semantic_logits = prediction["semantic_logits"]
        if rgb.ndim != 5 or rgb.shape[1] != len(CAMERA_ORDER):
            raise ValueError(f"Expected RGB [B,6,3,H,W], got {tuple(rgb.shape)}")
        if depth.shape[:2] != rgb.shape[:2] or semantic_logits.shape[:2] != rgb.shape[:2]:
            raise ValueError("All predictions must share batch and six-view dimensions")
        batch_size, views = rgb.shape[:2]
        flat = lambda tensor: tensor.flatten(0, 1)
        self._update_domain(
            0,
            flat(rgb),
            flat(batch["rgb_01"]),
            flat(depth),
            flat(batch["depth"]),
            flat(batch["depth_valid"]),
            flat(semantic_logits),
            flat(batch["semantic"]),
            flat(batch["semantic_valid"]),
            flat(batch["intrinsics"]),
            batch_size,
            batch_size * views,
        )
        for camera_index in range(views):
            self._update_domain(
                camera_index + 1,
                rgb[:, camera_index],
                batch["rgb_01"][:, camera_index],
                depth[:, camera_index],
                batch["depth"][:, camera_index],
                batch["depth_valid"][:, camera_index],
                semantic_logits[:, camera_index],
                batch["semantic"][:, camera_index],
                batch["semantic_valid"][:, camera_index],
                batch["intrinsics"][:, camera_index],
                batch_size,
                batch_size,
            )

    def synchronize(self) -> None:
        if dist.is_available() and dist.is_initialized():
            dist.all_reduce(self.stats, op=dist.ReduceOp.SUM)
            dist.all_reduce(self.confusion, op=dist.ReduceOp.SUM)

    def _compute_domain(self, domain: int) -> dict[str, Any]:
        stats = self.stats[domain]
        confusion = self.confusion[domain].double()
        required = (
            stats[RGB_COUNT],
            stats[LPIPS_COUNT],
            stats[SSIM_COUNT],
            stats[DEPTH_COUNT],
            stats[POINT_FRAME_COUNT],
            confusion.sum(),
        )
        if any(value.item() <= 0 for value in required):
            raise RuntimeError(f"Evaluation metric domain {domain} has an empty sufficient-statistic count")
        intersection = confusion.diag()
        union = confusion.sum(0) + confusion.sum(1) - intersection
        valid_classes = union.gt(0)
        per_class_iou = intersection / union.clamp_min(1.0)
        rgb_mse = (stats[RGB_SQ] / stats[RGB_COUNT]).item()
        depth_mse = (stats[DEPTH_SQ] / stats[DEPTH_COUNT]).item()
        return {
            "rgb_l1": (stats[RGB_ABS] / stats[RGB_COUNT]).item(),
            "rgb_lpips": (stats[LPIPS_SUM] / stats[LPIPS_COUNT]).item(),
            "rgb_psnr": -10.0 * math.log10(max(rgb_mse, 1e-12)),
            "rgb_ssim": (stats[SSIM_SUM] / stats[SSIM_COUNT]).item(),
            "depth_abs_rel": (stats[DEPTH_ABS_REL] / stats[DEPTH_COUNT]).item(),
            "depth_rmse": math.sqrt(depth_mse),
            "depth_delta1": (stats[DEPTH_DELTA1] / stats[DEPTH_COUNT]).item(),
            "point_l2": (stats[POINT_L2] / stats[POINT_FRAME_COUNT]).item(),
            "point_z_abs": (stats[POINT_Z] / stats[POINT_FRAME_COUNT]).item(),
            "point_xy_l2": (stats[POINT_XY] / stats[POINT_FRAME_COUNT]).item(),
            "semantic_miou": per_class_iou[valid_classes].mean().item(),
            "semantic_pixel_accuracy": (intersection.sum() / confusion.sum()).item(),
            "semantic_per_class_iou": [
                value.item() if valid else None
                for value, valid in zip(per_class_iou.cpu(), valid_classes.cpu())
            ],
            "semantic_confusion": self.confusion[domain].cpu().tolist(),
            "evaluated_samples": int(stats[SAMPLE_COUNT].item()),
            "evaluated_views": int(stats[VIEW_COUNT].item()),
            "counts": {
                "rgb_elements": int(stats[RGB_COUNT].item()),
                "lpips_views": int(stats[LPIPS_COUNT].item()),
                "depth_pixels": int(stats[DEPTH_COUNT].item()),
                "point_frames": int(stats[POINT_FRAME_COUNT].item()),
                "semantic_pixels": int(confusion.sum().item()),
            },
        }

    def compute(self) -> dict[str, Any]:
        result = self._compute_domain(0)
        result["per_camera"] = {
            camera: self._compute_domain(index + 1) for index, camera in enumerate(CAMERA_ORDER)
        }
        return result
