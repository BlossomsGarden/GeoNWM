"""JSONL schema for one nuScenes keyframe with six ordered camera views."""

from __future__ import annotations

import hashlib
import json
import math
import os
import tempfile
from pathlib import Path
from typing import Any

from da3_tok.contracts import CAMERA_ORDER, MANIFEST_SCHEMA_VERSION, validate_view_names


_VIEW_PATH_KEYS = ("rgb_path", "depth_path", "semantic_path")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _validate_matrix(value: object, shape: tuple[int, int], field: str) -> None:
    if not isinstance(value, list) or len(value) != shape[0]:
        raise ValueError(f"{field} must have shape {shape}")
    for row in value:
        if not isinstance(row, list) or len(row) != shape[1]:
            raise ValueError(f"{field} must have shape {shape}")
        for element in row:
            if isinstance(element, bool) or not isinstance(element, (int, float)) or not math.isfinite(element):
                raise ValueError(f"{field} must contain only finite numbers")


def _required_text(mapping: dict[str, Any], key: str, context: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{context}.{key} must be a non-empty string")
    return value


def validate_manifest_record(
    record: object,
    expected_split: str | None = None,
    index: int | None = None,
) -> None:
    context = f"record[{index}]" if index is not None else "record"
    if not isinstance(record, dict):
        raise ValueError(f"{context} must be an object")
    if record.get("schema_version") != MANIFEST_SCHEMA_VERSION:
        raise ValueError(
            f"{context}.schema_version must be {MANIFEST_SCHEMA_VERSION}, got {record.get('schema_version')!r}"
        )
    split = _required_text(record, "split", context)
    if expected_split is not None and split != expected_split:
        raise ValueError(f"{context}.split must be {expected_split!r}, got {split!r}")
    _required_text(record, "sample_token", context)
    _required_text(record, "scene_name", context)
    views = record.get("views")
    if not isinstance(views, list):
        raise ValueError(f"{context}.views must be a list")
    try:
        validate_view_names(view.get("camera") if isinstance(view, dict) else None for view in views)
    except ValueError as error:
        raise ValueError(f"{context}.views camera order is invalid: {error}") from error

    seen_tokens: set[str] = set()
    for view_index, view in enumerate(views):
        view_context = f"{context}.views[{view_index}]"
        if not isinstance(view, dict):
            raise ValueError(f"{view_context} must be an object")
        token = _required_text(view, "sample_data_token", view_context)
        if token in seen_tokens:
            raise ValueError(f"{view_context}.sample_data_token is duplicated: {token}")
        seen_tokens.add(token)
        for key in _VIEW_PATH_KEYS:
            _required_text(view, key, view_context)
        _validate_matrix(view.get("intrinsics"), (3, 3), f"{view_context}.intrinsics")
        _validate_matrix(view.get("world_to_camera"), (4, 4), f"{view_context}.world_to_camera")


def load_manifest(path: Path, expected_split: str) -> list[dict[str, Any]]:
    path = Path(path)
    records = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if not records:
        raise ValueError(f"Manifest is empty: {path}")
    seen_samples: set[str] = set()
    for index, record in enumerate(records):
        validate_manifest_record(record, expected_split=expected_split, index=index)
        token = str(record["sample_token"])
        if token in seen_samples:
            raise ValueError(f"Duplicate sample_token {token} in {path}")
        seen_samples.add(token)
    return records


def atomic_write_text(path: Path, content: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def atomic_write_json(path: Path, payload: object) -> None:
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def write_manifest(path: Path, records: list[dict[str, Any]], split: str) -> None:
    if not records:
        raise ValueError(f"Refusing to write empty {split} manifest")
    for index, record in enumerate(records):
        validate_manifest_record(record, expected_split=split, index=index)
    content = "".join(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n" for record in records)
    atomic_write_text(path, content)
