"""Strict reader for pre-aligned six-camera nuScenes keyframe samples."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

from da3_tok.contracts import TARGET_HEIGHT, TARGET_WIDTH, validate_view_names
from da3_tok.data.label_spec import SemanticLabelSpec
from da3_tok.data.manifest import load_manifest
from da3_tok.data.transforms import imagenet_normalize


def _require_exact_shape(array: np.ndarray, path: Path, expected: tuple[int, int]) -> None:
    if tuple(array.shape[:2]) != expected:
        raise ValueError(
            f"Aligned modality {path} must be {expected[0]}x{expected[1]}, got {tuple(array.shape[:2])}"
        )


def read_rgb_exact(path: str | Path) -> torch.Tensor:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"RGB file not found: {path}")
    with Image.open(path) as image:
        array = np.asarray(image.convert("RGB"), dtype=np.uint8)
    _require_exact_shape(array, path, (TARGET_HEIGHT, TARGET_WIDTH))
    return torch.from_numpy(array.copy()).permute(2, 0, 1).float().div_(255.0)


def _read_depth_array(path: Path) -> tuple[np.ndarray, np.ndarray | None]:
    suffix = path.suffix.lower()
    if suffix == ".npz":
        with np.load(path) as archive:
            if "depth" not in archive.files:
                raise ValueError(f"Depth archive {path} must contain key 'depth', got {archive.files}")
            depth = np.asarray(archive["depth"], dtype=np.float32)
            file_mask = np.asarray(archive["mask"], dtype=bool) if "mask" in archive.files else None
        return depth, file_mask
    if suffix == ".npy":
        return np.asarray(np.load(path), dtype=np.float32), None
    with Image.open(path) as image:
        return np.asarray(image, dtype=np.float32), None


def read_depth_exact(path: str | Path) -> tuple[torch.Tensor, torch.Tensor]:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Depth file not found: {path}")
    depth, file_mask = _read_depth_array(path)
    depth = np.squeeze(depth)
    if depth.ndim != 2:
        raise ValueError(f"Depth {path} must be a single [H,W] array, got {depth.shape}")
    _require_exact_shape(depth, path, (TARGET_HEIGHT, TARGET_WIDTH))
    valid = np.isfinite(depth) & (depth > 0)
    if file_mask is not None:
        file_mask = np.squeeze(file_mask)
        if file_mask.shape != depth.shape:
            raise ValueError(f"Depth mask {path} has shape {file_mask.shape}, expected {depth.shape}")
        valid &= file_mask
    depth_tensor = torch.from_numpy(depth.copy()).unsqueeze(0)
    valid_tensor = torch.from_numpy(valid.copy()).unsqueeze(0)
    return depth_tensor, valid_tensor


def _semantic_id_array(path: Path) -> np.ndarray:
    with Image.open(path) as image:
        values = np.asarray(image)
    values = np.squeeze(values)
    if values.ndim == 2:
        return values
    if values.ndim == 3 and values.shape[-1] in {3, 4}:
        channels = values[..., :3]
        if np.array_equal(channels[..., 0], channels[..., 1]) and np.array_equal(
            channels[..., 0], channels[..., 2]
        ):
            return channels[..., 0]
    raise ValueError(f"Semantic target {path} must be a single-channel class-ID image, got {values.shape}")


def read_semantic_exact(
    path: str | Path,
    semantic_spec: SemanticLabelSpec,
) -> tuple[torch.Tensor, torch.Tensor]:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Semantic file not found: {path}")
    values = _semantic_id_array(path)
    _require_exact_shape(values, path, (TARGET_HEIGHT, TARGET_WIDTH))
    mapped = semantic_spec.map_tensor(torch.from_numpy(values.astype(np.int64, copy=True)))
    valid = mapped.ge(0) & mapped.lt(semantic_spec.classes)
    return mapped, valid


class NuScenesSixViewDataset(Dataset):
    """One item is one keyframe sample with six pre-aligned camera views."""

    def __init__(self, manifest_path: str | Path, split: str, semantic_mapping_path: str | Path) -> None:
        self.manifest_path = Path(manifest_path).expanduser().resolve()
        self.manifest_dir = self.manifest_path.parent
        self.records = load_manifest(self.manifest_path, expected_split=split)
        self.semantic_spec = SemanticLabelSpec.from_json(semantic_mapping_path)

    def __len__(self) -> int:
        return len(self.records)

    def _path(self, recorded: object) -> Path:
        if not isinstance(recorded, str) or not recorded:
            raise ValueError(f"Manifest path must be non-empty text, got {recorded!r}")
        path = Path(recorded).expanduser()
        return path if path.is_absolute() else self.manifest_dir / path

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        views = record["views"]
        validate_view_names(view["camera"] for view in views)
        rgb = torch.stack([read_rgb_exact(self._path(view["rgb_path"])) for view in views])
        depth_and_mask = [read_depth_exact(self._path(view["depth_path"])) for view in views]
        semantic_and_mask = [
            read_semantic_exact(self._path(view["semantic_path"]), self.semantic_spec) for view in views
        ]
        return {
            "rgb_01": rgb,
            "image_da3": imagenet_normalize(rgb),
            "depth": torch.stack([item[0] for item in depth_and_mask]),
            "depth_valid": torch.stack([item[1] for item in depth_and_mask]),
            "semantic": torch.stack([item[0] for item in semantic_and_mask]),
            "semantic_valid": torch.stack([item[1] for item in semantic_and_mask]),
            "intrinsics": torch.tensor([view["intrinsics"] for view in views], dtype=torch.float32),
            "world_to_camera": torch.tensor(
                [view["world_to_camera"] for view in views], dtype=torch.float32
            ),
            "camera_names": tuple(view["camera"] for view in views),
            "camera_tokens": tuple(view["sample_data_token"] for view in views),
            "sample_token": record["sample_token"],
            "scene_name": record["scene_name"],
        }
