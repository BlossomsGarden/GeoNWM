"""Persist deterministic fixed dev/val keyframe subsets."""

from __future__ import annotations

import json
import random
from collections.abc import Callable
from pathlib import Path
from typing import Any

from da3_tok.contracts import CAMERA_ORDER, validate_view_names
from da3_tok.data.manifest import atomic_write_json, sha256_file


def subset_record(index: int, record: dict[str, Any]) -> dict[str, Any]:
    views = record["views"]
    validate_view_names(view["camera"] for view in views)
    return {
        "manifest_index": index,
        "sample_token": record["sample_token"],
        "cameras": [
            {"camera": view["camera"], "sample_data_token": view["sample_data_token"]}
            for view in views
        ],
    }


def validate_subset_payload(
    payload: object,
    records: list[dict[str, Any]],
    manifest_digest: str,
    size: int,
    seed: int,
) -> None:
    if not isinstance(payload, dict):
        raise ValueError("Fixed subset payload must be an object")
    if payload.get("manifest_sha256") != manifest_digest:
        raise ValueError("Fixed subset manifest hash does not match the current manifest")
    if payload.get("seed") != seed or payload.get("size") != size:
        raise ValueError("Fixed subset seed or size does not match the formal configuration")
    samples = payload.get("samples")
    if not isinstance(samples, list) or len(samples) != size:
        raise ValueError(f"Fixed subset must contain exactly {size} samples")
    indices = [item.get("manifest_index") if isinstance(item, dict) else None for item in samples]
    if any(not isinstance(index, int) for index in indices):
        raise ValueError("Fixed subset manifest_index values must be integers")
    if indices != sorted(indices) or len(set(indices)) != size:
        raise ValueError("Fixed subset manifest indices must be sorted and unique")
    for item, index in zip(samples, indices):
        if index < 0 or index >= len(records):
            raise ValueError(f"Fixed subset manifest_index is out of range: {index}")
        expected = subset_record(index, records[index])
        if item != expected:
            raise ValueError(f"Fixed subset sample identity mismatch at manifest index {index}")


def load_or_create_fixed_subset(
    manifest_path: str | Path,
    records: list[dict[str, Any]],
    output_path: str | Path,
    size: int,
    seed: int,
    rank: int,
    barrier: Callable[[], None],
) -> list[int]:
    if len(records) < size:
        raise ValueError(f"Manifest has {len(records)} samples but fixed subset requires {size}")
    manifest_path = Path(manifest_path)
    output_path = Path(output_path)
    digest = sha256_file(manifest_path)
    if rank == 0 and not output_path.exists():
        rng = random.Random(seed)
        indices = sorted(rng.sample(range(len(records)), size))
        atomic_write_json(
            output_path,
            {
                "manifest_sha256": digest,
                "seed": seed,
                "size": size,
                "camera_order": list(CAMERA_ORDER),
                "samples": [subset_record(index, records[index]) for index in indices],
            },
        )
    barrier()
    if not output_path.is_file():
        raise RuntimeError(f"Rank {rank} cannot find fixed subset after synchronization: {output_path}")
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    if payload.get("camera_order") != list(CAMERA_ORDER):
        raise ValueError("Fixed subset camera_order does not match the formal contract")
    validate_subset_payload(payload, records, digest, size, seed)
    return [int(item["manifest_index"]) for item in payload["samples"]]
