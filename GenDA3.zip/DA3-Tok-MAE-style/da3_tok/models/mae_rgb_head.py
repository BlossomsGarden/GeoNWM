"""Thin six-view adapter around the unmodified GLD MAE decoder core."""

from __future__ import annotations

from pathlib import Path

import torch
from torch import nn

from da3_tok.contracts import FEATURE_DIM, PATCH_TOKENS, TARGET_HEIGHT, TARGET_WIDTH
from vendor.gld.decoders import GeneralDecoder_Variable, ViTMAEConfig


class GLDMAERGBHead(nn.Module):
    """Decode DA3-Tok fused tokens with GLD's exact Stage-1 RGB decoder."""

    def __init__(
        self,
        input_dim: int = FEATURE_DIM,
        view_chunk_size: int = 1,
        config_path: str | Path | None = None,
    ) -> None:
        super().__init__()
        if input_dim != FEATURE_DIM:
            raise ValueError(f"Formal fused feature dimension must be {FEATURE_DIM}, got {input_dim}")
        if view_chunk_size <= 0:
            raise ValueError("view_chunk_size must be positive")
        if config_path is None:
            config_path = Path(__file__).resolve().parents[2] / "vendor" / "gld" / "configs" / "ViTXL"
        config = ViTMAEConfig.from_pretrained(str(config_path))
        config.hidden_size = input_dim
        config.patch_size = 14
        config.attention_probs_dropout_prob = 0.0
        config.hidden_dropout_prob = 0.0
        self.core = GeneralDecoder_Variable(config, base_image_size=(504, 504))
        self.input_dim = input_dim
        self.view_chunk_size = view_chunk_size
        self.register_buffer("imagenet_mean", torch.tensor((0.485, 0.456, 0.406)).view(1, 3, 1, 1))
        self.register_buffer("imagenet_std", torch.tensor((0.229, 0.224, 0.225)).view(1, 3, 1, 1))

    @property
    def last_layer(self) -> nn.Parameter:
        return self.core.decoder_pred.weight

    def forward(self, fused_tokens: torch.Tensor, view_chunk_size: int | None = None) -> dict[str, torch.Tensor]:
        if fused_tokens.ndim != 4:
            raise ValueError(f"Expected fused tokens [B,V,N,C], got {tuple(fused_tokens.shape)}")
        batch, views, tokens, channels = fused_tokens.shape
        if tokens != PATCH_TOKENS or channels != self.input_dim:
            raise ValueError(f"Expected [B,V,{PATCH_TOKENS},{self.input_dim}], got {tuple(fused_tokens.shape)}")
        flat = fused_tokens.reshape(batch * views, tokens, channels)
        chunk = view_chunk_size or self.view_chunk_size
        if chunk <= 0:
            raise ValueError("view_chunk_size must be positive")
        normalized: list[torch.Tensor] = []
        for start in range(0, flat.shape[0], chunk):
            logits = self.core(
                flat[start : start + chunk],
                input_size=(TARGET_HEIGHT, TARGET_WIDTH),
                drop_cls_token=False,
            ).logits
            normalized.append(self.core.unpatchify(logits, (TARGET_HEIGHT, TARGET_WIDTH)))
        rgb_norm = torch.cat(normalized).reshape(batch, views, 3, TARGET_HEIGHT, TARGET_WIDTH)
        flat_norm = rgb_norm.flatten(0, 1)
        rgb = flat_norm * self.imagenet_std.to(flat_norm) + self.imagenet_mean.to(flat_norm)
        return {"rgb_norm": rgb_norm, "rgb": rgb.reshape_as(rgb_norm)}
