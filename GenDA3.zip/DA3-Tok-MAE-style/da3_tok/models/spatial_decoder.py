"""Compact DINO-Tok-inspired spatial decoder for DA3-Tok depth and semantic outputs."""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn

from da3_tok.contracts import TARGET_HEIGHT, TARGET_WIDTH, TOKEN_HEIGHT, TOKEN_WIDTH


class SpatialHybridBlock(nn.Module):
    """Residual spatial context and GLU-style local mixing without token attention."""

    def __init__(self, channels: int, expansion: int = 2) -> None:
        super().__init__()
        hidden = channels * expansion
        self.norm = nn.GroupNorm(1, channels)
        self.context = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, bias=False),
            nn.GELU(),
            nn.Conv2d(channels, channels, kernel_size=1, bias=False),
        )
        self.local_norm = nn.GroupNorm(1, channels)
        self.depthwise = nn.Conv2d(channels, channels, kernel_size=3, padding=1, groups=channels, bias=False)
        self.glu = nn.Conv2d(channels, hidden * 2, kernel_size=1)
        self.project = nn.Conv2d(hidden, channels, kernel_size=1, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.context(self.norm(x))
        local = self.depthwise(self.local_norm(x))
        gate, value = self.glu(local).chunk(2, dim=1)
        return x + self.project(F.gelu(value) * torch.sigmoid(gate))


class PredictionHead(nn.Module):
    def __init__(self, input_channels: int, output_channels: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(input_channels, 48, kernel_size=3, padding=1),
            nn.GELU(),
            nn.Conv2d(48, output_channels, kernel_size=1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class SharedSpatialDecoder(nn.Module):
    """Decode ``[B,V,N,C]`` tokens into depth and semantic outputs."""

    def __init__(
        self,
        semantic_classes: int,
        input_dim: int = 1536,
        token_height: int = TOKEN_HEIGHT,
        token_width: int = TOKEN_WIDTH,
        target_height: int = TARGET_HEIGHT,
        target_width: int = TARGET_WIDTH,
        view_chunk_size: int = 1,
    ) -> None:
        super().__init__()
        self.token_height = token_height
        self.token_width = token_width
        self.target_height = target_height
        self.target_width = target_width
        self.view_chunk_size = view_chunk_size
        self.input_dim = input_dim
        self.project_in = nn.Sequential(
            nn.Conv2d(input_dim, 512, kernel_size=1, bias=False),
            nn.GroupNorm(1, 512),
            nn.GELU(),
        )
        self.low_blocks = nn.Sequential(SpatialHybridBlock(512), SpatialHybridBlock(512))
        self.up1 = nn.Sequential(
            nn.Conv2d(512, 256, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(1, 256),
            nn.GELU(),
            SpatialHybridBlock(256),
        )
        self.up2 = nn.Sequential(
            nn.Conv2d(256, 128, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(1, 128),
            nn.GELU(),
            SpatialHybridBlock(128),
        )
        self.up3 = nn.Sequential(
            nn.Conv2d(128, 96, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(1, 96),
            nn.GELU(),
            SpatialHybridBlock(96),
        )
        self.refine = SpatialHybridBlock(96)
        self.depth_head = PredictionHead(96, 1)
        self.semantic_head = PredictionHead(96, semantic_classes)

    def _decode_views(self, views: torch.Tensor) -> dict[str, torch.Tensor]:
        x = self.project_in(views)
        x = self.low_blocks(x)
        x = F.interpolate(x, scale_factor=2.0, mode="bilinear", align_corners=False)
        x = self.up1(x)
        x = F.interpolate(x, scale_factor=2.0, mode="bilinear", align_corners=False)
        x = self.up2(x)
        x = F.interpolate(x, scale_factor=2.0, mode="bilinear", align_corners=False)
        x = self.up3(x)
        x = F.interpolate(x, size=(self.target_height, self.target_width), mode="bilinear", align_corners=False)
        x = self.refine(x)
        return {
            "depth": F.softplus(self.depth_head(x)) + 1e-4,
            "semantic_logits": self.semantic_head(x),
        }

    def forward(self, fused_tokens: torch.Tensor, view_chunk_size: int | None = None) -> dict[str, torch.Tensor]:
        if fused_tokens.ndim != 4:
            raise ValueError(f"Expected [B,V,N,C], got {tuple(fused_tokens.shape)}")
        batch, views, tokens, channels = fused_tokens.shape
        expected_tokens = self.token_height * self.token_width
        if tokens != expected_tokens or channels != self.input_dim:
            raise ValueError(
                f"Expected {expected_tokens} tokens with {self.input_dim} channels, got {tokens}×{channels}"
            )
        flat = fused_tokens.reshape(batch * views, tokens, channels)
        flat = flat.transpose(1, 2).reshape(batch * views, channels, self.token_height, self.token_width)
        chunk = view_chunk_size or self.view_chunk_size
        if chunk <= 0:
            raise ValueError("view_chunk_size must be positive")
        outputs: dict[str, list[torch.Tensor]] = {"depth": [], "semantic_logits": []}
        for start in range(0, flat.shape[0], chunk):
            decoded = self._decode_views(flat[start : start + chunk])
            for name, value in decoded.items():
                outputs[name].append(value)
        return {
            name: torch.cat(values, dim=0).reshape(batch, views, *values[0].shape[1:])
            for name, values in outputs.items()
        }
