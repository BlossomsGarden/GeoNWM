"""Four-layer weighted fusion with GLD MAE RGB and compact dense Heads."""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

import torch
from torch import nn

from da3_tok.contracts import FEATURE_LAYERS

from .da3_frozen import DA3FrozenEncoder
from .fusion import FourLayerRAEv2Fusion
from .mae_rgb_head import GLDMAERGBHead
from .spatial_decoder import SharedSpatialDecoder


class DA3Tok(nn.Module):
    def __init__(
        self,
        da3_model_dir: str | Path,
        semantic_classes: int,
        view_chunk_size: int = 1,
        feature_layers: Sequence[int] = FEATURE_LAYERS,
        feature_dim: int | None = None,
    ) -> None:
        super().__init__()
        self.encoder = DA3FrozenEncoder(da3_model_dir, layers=feature_layers, feature_dim=feature_dim)
        self.fusion = FourLayerRAEv2Fusion(dim=self.encoder.feature_dim, layers=feature_layers)
        self.rgb_decoder = GLDMAERGBHead(self.encoder.feature_dim, view_chunk_size)
        self.decoder = SharedSpatialDecoder(
            semantic_classes=semantic_classes,
            view_chunk_size=view_chunk_size,
            input_dim=self.encoder.feature_dim,
        )

    def forward(
        self,
        image_da3: torch.Tensor,
        intrinsics: torch.Tensor,
        world_to_camera: torch.Tensor,
        view_chunk_size: int | None = None,
    ) -> dict[str, torch.Tensor]:
        levels = self.encoder(image_da3, intrinsics, world_to_camera)
        fused_tokens, fusion_weights = self.fusion(levels)
        output = self.decoder(fused_tokens, view_chunk_size=view_chunk_size)
        output.update(self.rgb_decoder(fused_tokens, view_chunk_size=view_chunk_size))
        output["fusion_weights"] = fusion_weights
        return output

    def train(self, mode: bool = True) -> "DA3Tok":
        super().train(mode)
        self.encoder.da3.eval()
        return self

    def trainable_modules(self) -> dict[str, nn.Module]:
        return {"fusion": self.fusion, "rgb_decoder": self.rgb_decoder, "decoder": self.decoder}

    def trainable_module_names(self) -> set[str]:
        return set(self.trainable_modules())
