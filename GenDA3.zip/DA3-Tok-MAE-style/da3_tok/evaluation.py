"""EMA evaluation, dev-only best selection, and one-shot checkpoint events."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from contextlib import nullcontext
from typing import Any

import torch
import torch.distributed as dist
from torch import nn

from da3_tok.checkpointing import unwrap_model
from da3_tok.ema import ExponentialMovingAverage
from da3_tok.metrics import DenseMetricAccumulator


LOSS_NAMES = ("rgb", "perceptual", "depth", "point", "semantic")


def _to_device(batch: Mapping[str, Any], device: torch.device) -> dict[str, Any]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


@torch.no_grad()
def _evaluate_without_ema(
    model: nn.Module,
    criterion: nn.Module,
    lpips_metric: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    loader: Iterable[Mapping[str, Any]],
    device: torch.device,
) -> tuple[dict[str, float], dict[str, Any], tuple[dict[str, Any], dict[str, torch.Tensor]] | None]:
    model.eval()
    class_weights = getattr(criterion, "semantic_class_weights", None)
    semantic_classes = int(class_weights.numel()) if isinstance(class_weights, torch.Tensor) else 10
    accumulator = DenseMetricAccumulator(semantic_classes, device, lpips_metric)
    sums = torch.zeros(len(LOSS_NAMES), dtype=torch.float64, device=device)
    counts = torch.zeros(len(LOSS_NAMES), dtype=torch.float64, device=device)
    visual: tuple[dict[str, Any], dict[str, torch.Tensor]] | None = None
    for raw_batch in loader:
        batch = _to_device(raw_batch, device)
        prediction = model(batch["image_da3"], batch["intrinsics"], batch["world_to_camera"])
        losses = criterion(prediction, batch)
        for index, name in enumerate(LOSS_NAMES):
            sums[index] += losses[f"{name}_sum"].double()
            counts[index] += losses[f"{name}_count"].double()
        accumulator.update(prediction, batch)
        if visual is None:
            visual = (
                {key: value.detach().cpu() if isinstance(value, torch.Tensor) else value for key, value in batch.items()},
                {key: value.detach().cpu() for key, value in prediction.items() if isinstance(value, torch.Tensor)},
            )
    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(sums, op=dist.ReduceOp.SUM)
        dist.all_reduce(counts, op=dist.ReduceOp.SUM)
    if (counts <= 0).any():
        raise RuntimeError("Evaluation produced an empty loss domain")
    means = {name: (sums[index] / counts[index]).item() for index, name in enumerate(LOSS_NAMES)}
    weights = criterion.weights
    means["total"] = (
        weights.rgb * means["rgb"]
        + weights.perceptual * means["perceptual"]
        + weights.depth * means["depth"]
        + weights.point * means["point"]
        + weights.semantic * means["semantic"]
    )
    accumulator.synchronize()
    return means, accumulator.compute(), visual


def evaluate_joint(
    model: nn.Module,
    ema: ExponentialMovingAverage,
    criterion: nn.Module,
    lpips_metric: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    loader: Iterable[Mapping[str, Any]],
    device: torch.device,
) -> tuple[dict[str, float], dict[str, Any]]:
    was_training = model.training
    try:
        with ema.average_parameters(unwrap_model(model)):
            losses, metrics, _ = _evaluate_without_ema(model, criterion, lpips_metric, loader, device)
        return losses, metrics
    finally:
        model.train(was_training)


def evaluate_dev_val(
    model: nn.Module,
    ema: ExponentialMovingAverage,
    criterion: nn.Module,
    lpips_metric: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    dev_loader: Iterable[Mapping[str, Any]],
    val_loader: Iterable[Mapping[str, Any]],
    device: torch.device,
) -> dict[str, Any]:
    was_training = model.training
    try:
        with ema.average_parameters(unwrap_model(model)):
            dev_losses, dev_metrics, dev_visual = _evaluate_without_ema(
                model, criterion, lpips_metric, dev_loader, device
            )
            val_losses, val_metrics, val_visual = _evaluate_without_ema(
                model, criterion, lpips_metric, val_loader, device
            )
        return {
            "dev": {"losses": dev_losses, "metrics": dev_metrics, "visual": dev_visual},
            "val": {"losses": val_losses, "metrics": val_metrics, "visual": val_visual},
        }
    finally:
        model.train(was_training)


def update_best_records(
    best_records: Mapping[str, Any],
    step: int,
    dev_losses: Mapping[str, float],
    dev_metrics: Mapping[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    candidates = {
        "best_joint": (float(dev_losses["total"]), "min"),
        "best_rgb": (float(dev_metrics["rgb_l1"]) + float(dev_metrics["rgb_lpips"]), "min"),
        "best_depth": (float(dev_metrics["depth_abs_rel"]), "min"),
        "best_point": (float(dev_metrics["point_l2"]), "min"),
        "best_semantic": (float(dev_metrics["semantic_miou"]), "max"),
    }
    updated = {name: dict(value) for name, value in best_records.items()}
    improved: list[str] = []
    for name, (value, mode) in candidates.items():
        previous = updated.get(name)
        is_better = previous is None or (value < previous["value"] if mode == "min" else value > previous["value"])
        if is_better:
            updated[name] = {"step": step, "value": value, "mode": mode}
            improved.append(name)
    return updated, improved


def run_checkpoint_event(
    step: int,
    evaluate_once: Callable[[], Any],
    write_latest: Callable[[Any], None],
    write_best: Callable[[Any], None] | None,
    write_milestone: Callable[[Any], None] | None,
    has_improved_best: bool,
    milestone_every: int,
) -> Any:
    """Evaluate once and fan the same result out to all due checkpoint writers."""
    result = evaluate_once()
    write_latest(result)
    if has_improved_best and write_best is not None:
        write_best(result)
    if step % milestone_every == 0 and write_milestone is not None:
        write_milestone(result)
    return result
