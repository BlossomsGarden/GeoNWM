"""Joint GLD-style RGB and DA3-Tok dense objectives before the GAN term."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn

from da3_tok.geometry import backproject_depth, flatten_views


def _require_finite_on_mask(name: str, values: torch.Tensor, mask: torch.Tensor) -> None:
    expanded = mask
    while expanded.ndim < values.ndim:
        expanded = expanded.unsqueeze(-3)
    if expanded.shape != values.shape:
        expanded = expanded.expand_as(values)
    if not torch.isfinite(values[expanded]).all():
        raise FloatingPointError(f"{name} contains NaN or Inf on valid target pixels")


class CharbonnierLoss(nn.Module):
    def __init__(self, epsilon: float = 1e-3) -> None:
        super().__init__()
        self.epsilon = epsilon

    def forward(self, prediction: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return torch.sqrt((prediction - target).square() + self.epsilon**2).mean()


class PerceptualLoss(nn.Module):
    """Lazy LPIPS wrapper so VGG weights load only when perceptual loss is used."""

    LPIPS_VGG_MD5 = "d507d7349b931f0638a25a48a722f98a"

    def __init__(
        self,
        enabled: bool = True,
        checkpoint_path: str | Path | None = None,
    ) -> None:
        super().__init__()
        self.enabled = enabled
        self.checkpoint_path = Path(checkpoint_path).expanduser().resolve() if checkpoint_path else None
        self._metric: nn.Module | None = None

    def _get_metric(self, device: torch.device) -> nn.Module:
        if self._metric is None:
            from vendor.gld.disc import LPIPS
            import vendor.gld.disc.lpips as lpips_module

            if self.checkpoint_path is None or not self.checkpoint_path.is_file():
                raise FileNotFoundError(f"GLD LPIPS checkpoint not found: {self.checkpoint_path}")
            digest = hashlib.md5(self.checkpoint_path.read_bytes()).hexdigest()
            if digest != self.LPIPS_VGG_MD5:
                raise ValueError(
                    f"GLD LPIPS checkpoint MD5 must be {self.LPIPS_VGG_MD5}, got {digest}"
                )
            original_resolver = lpips_module.get_ckpt_path
            try:
                lpips_module.get_ckpt_path = lambda *_args, **_kwargs: str(self.checkpoint_path)
                self._metric = LPIPS().eval().to(device)
            finally:
                lpips_module.get_ckpt_path = original_resolver
            for parameter in self._metric.parameters():
                parameter.requires_grad_(False)
        return self._metric

    def forward_stats(self, prediction_01: torch.Tensor, target_01: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        view_count = flatten_views(prediction_01).shape[0]
        count = prediction_01.new_tensor(float(view_count), dtype=torch.float32)
        if not self.enabled:
            return prediction_01.new_zeros(()), count
        metric = self._get_metric(prediction_01.device)
        prediction = flatten_views(prediction_01).mul(2.0).sub(1.0)
        target = flatten_views(target_01).mul(2.0).sub(1.0)
        values = metric(prediction, target, reduction="none").flatten()
        return values.sum(), count

    def forward(self, prediction_01: torch.Tensor, target_01: torch.Tensor) -> torch.Tensor:
        total, count = self.forward_stats(prediction_01, target_01)
        return total / count.clamp_min(1.0)


@dataclass(frozen=True)
class LossWeights:
    rgb: float = 1.0
    perceptual: float = 1.0
    depth: float = 1.0
    point: float = 0.02
    semantic: float = 0.50


class DA3TokLoss(nn.Module):
    def __init__(
        self,
        semantic_ignore_index: int = -1,
        semantic_class_weights: torch.Tensor | None = None,
        use_lpips: bool = True,
        lpips_checkpoint: str | Path | None = None,
        weights: LossWeights = LossWeights(),
    ) -> None:
        super().__init__()
        self.semantic_ignore_index = semantic_ignore_index
        self.weights = weights
        self.charbonnier = CharbonnierLoss()
        self.perceptual = PerceptualLoss(
            enabled=use_lpips,
            checkpoint_path=lpips_checkpoint,
        )
        if semantic_class_weights is not None:
            self.register_buffer("semantic_class_weights", semantic_class_weights.float())
        else:
            self.semantic_class_weights = None

    def forward(self, prediction: dict[str, torch.Tensor], batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        rgb = prediction["rgb"]
        depth = prediction["depth"]
        semantic_logits = prediction["semantic_logits"]
        target_rgb = batch["rgb_01"]
        target_depth = batch["depth"]
        depth_valid = batch["depth_valid"].bool()
        semantic_target = batch["semantic"].long()
        semantic_valid = batch["semantic_valid"].bool()
        if rgb.shape != target_rgb.shape or depth.shape != target_depth.shape:
            raise ValueError("Predictions and dense RGB/depth targets must have matching shapes")
        if semantic_logits.shape[:2] != semantic_target.shape[:2] or semantic_logits.shape[-2:] != semantic_target.shape[-2:]:
            raise ValueError("Semantic predictions and targets must share batch, view, and spatial dimensions")
        _require_finite_on_mask("rgb", rgb, torch.ones_like(target_rgb, dtype=torch.bool))
        _require_finite_on_mask("depth", depth, depth_valid)
        semantic_prediction_mask = semantic_valid.unsqueeze(2).expand_as(semantic_logits)
        _require_finite_on_mask("semantic_logits", semantic_logits, semantic_prediction_mask)

        rgb_values = (rgb - target_rgb).abs()
        rgb_sum = rgb_values.sum()
        rgb_count = rgb.new_tensor(float(rgb_values.numel()), dtype=torch.float32)
        rgb_loss = rgb_sum / rgb_count.clamp_min(1.0)
        perceptual_sum, perceptual_count = self.perceptual.forward_stats(rgb, target_rgb)
        perceptual_loss = perceptual_sum / perceptual_count.clamp_min(1.0)
        safe_target_depth = target_depth.clamp_min(1e-4)
        log_error = (depth.clamp_min(1e-4).log() - safe_target_depth.log()).abs()
        depth_count = depth_valid.sum().to(dtype=torch.float32)
        depth_sum = log_error[depth_valid].sum() if depth_valid.any() else depth.sum() * 0.0
        depth_loss = depth_sum / depth_count.clamp_min(1.0)

        flat_pred_depth = flatten_views(depth)
        flat_target_depth = flatten_views(target_depth)
        flat_intrinsics = batch["intrinsics"].flatten(0, 1)
        flat_mask = flatten_views(depth_valid.float()).bool()
        pred_points = backproject_depth(flat_pred_depth, flat_intrinsics)
        target_points = backproject_depth(flat_target_depth, flat_intrinsics)
        point_distance = torch.linalg.vector_norm(pred_points - target_points, dim=1, keepdim=True)
        point_count = flat_mask.sum().to(dtype=torch.float32)
        if flat_mask.any():
            point_values = torch.sqrt(point_distance[flat_mask].square() + self.charbonnier.epsilon**2)
            point_sum = point_values.sum()
        else:
            point_sum = depth.sum() * 0.0
        point_loss = point_sum / point_count.clamp_min(1.0)

        flattened_logits = semantic_logits.flatten(0, 1)
        masked_target = semantic_target.masked_fill(~semantic_valid, self.semantic_ignore_index)
        semantic_count = semantic_valid.sum().to(dtype=torch.float32)
        if semantic_valid.any():
            reduction_count = semantic_count
            if self.semantic_class_weights is not None:
                valid_classes = semantic_target[semantic_valid]
                reduction_count = self.semantic_class_weights[valid_classes].sum().to(dtype=torch.float32)
            semantic_sum = F.cross_entropy(
                flattened_logits,
                masked_target.flatten(0, 1),
                weight=self.semantic_class_weights,
                ignore_index=self.semantic_ignore_index,
                reduction="sum",
            )
            semantic_loss = semantic_sum / reduction_count.clamp_min(1.0)
            semantic_count = reduction_count
        else:
            semantic_sum = semantic_logits.sum() * 0.0
            semantic_loss = semantic_logits.sum() * 0.0
        total = (
            self.weights.rgb * rgb_loss
            + self.weights.perceptual * perceptual_loss
            + self.weights.depth * depth_loss
            + self.weights.point * point_loss
            + self.weights.semantic * semantic_loss
        )
        return {
            "total": total,
            "rgb_objective": self.weights.rgb * rgb_loss + self.weights.perceptual * perceptual_loss,
            "rgb": rgb_loss.detach(),
            "perceptual": perceptual_loss.detach(),
            "depth": depth_loss.detach(),
            "point": point_loss.detach(),
            "semantic": semantic_loss.detach(),
            "rgb_sum": rgb_sum.detach(),
            "rgb_count": rgb_count.detach(),
            "perceptual_sum": perceptual_sum.detach(),
            "perceptual_count": perceptual_count.detach(),
            "depth_sum": depth_sum.detach(),
            "depth_count": depth_count.detach(),
            "point_sum": point_sum.detach(),
            "point_count": point_count.detach(),
            "semantic_sum": semantic_sum.detach(),
            "semantic_count": semantic_count.detach(),
        }
