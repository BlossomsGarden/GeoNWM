"""Strict schema-v4 trainable-only checkpoints with atomic replacement."""

from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Any, Mapping, Protocol

import numpy as np
import torch
from torch import nn

from da3_tok.contracts import CAMERA_ORDER, CHECKPOINT_SCHEMA_VERSION, FEATURE_LAYERS
from da3_tok.ema import ExponentialMovingAverage


class TrainableModuleModel(Protocol):
    def trainable_modules(self) -> dict[str, nn.Module]: ...


def unwrap_model(model: nn.Module) -> nn.Module:
    return model.module if hasattr(model, "module") else model


def _modules(model: nn.Module) -> dict[str, nn.Module]:
    unwrapped = unwrap_model(model)
    if not hasattr(unwrapped, "trainable_modules"):
        raise TypeError("Model must expose trainable_modules() for checkpointing")
    modules = unwrapped.trainable_modules()
    if not isinstance(modules, dict) or not modules:
        raise ValueError("trainable_modules() must return a non-empty dict")
    for name, module in modules.items():
        if not isinstance(name, str) or not isinstance(module, nn.Module):
            raise TypeError("trainable_modules() must map string names to nn.Module values")
        if name in {"encoder", "da3", "backbone"}:
            raise ValueError(f"Frozen module {name!r} cannot be checkpointed")
    return modules


def trainable_state_dict(model: nn.Module) -> dict[str, dict[str, torch.Tensor]]:
    return {
        name: {key: value.detach().cpu().clone() for key, value in module.state_dict().items()}
        for name, module in _modules(model).items()
    }


def load_trainable_state_dict(model: nn.Module, state: Mapping[str, Any]) -> None:
    modules = _modules(model)
    if set(state) != set(modules):
        raise ValueError(
            f"Trainable module names mismatch: checkpoint={sorted(state)}, model={sorted(modules)}"
        )
    for name, module in modules.items():
        module.load_state_dict(state[name], strict=True)


def capture_rng_state() -> dict[str, Any]:
    state: dict[str, Any] = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state["torch_cuda"] = torch.cuda.get_rng_state_all()
    return state


def restore_rng_state(state: Mapping[str, Any]) -> None:
    if set(state) - {"python", "numpy", "torch_cpu", "torch_cuda"}:
        raise ValueError("RNG checkpoint contains unknown keys")
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch_cpu"])
    if "torch_cuda" in state:
        if not torch.cuda.is_available():
            raise RuntimeError("Checkpoint contains CUDA RNG state but CUDA is unavailable")
        torch.cuda.set_rng_state_all(state["torch_cuda"])


def formal_model_identity(
    experiment: str,
    fusion_type: str,
    frozen_da3_identity: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "experiment": experiment,
        "feature_layers": list(FEATURE_LAYERS),
        "camera_order": list(CAMERA_ORDER),
        "fusion_type": fusion_type,
        "frozen_da3": dict(frozen_da3_identity),
    }


def _base_payload(
    kind: str,
    step: int,
    resolved_config: Mapping[str, Any],
    manifest_hashes: Mapping[str, str],
    model_identity: Mapping[str, Any],
    metrics: Mapping[str, Any] | None,
) -> dict[str, Any]:
    if step < 0:
        raise ValueError("Checkpoint step must be non-negative")
    return {
        "schema_version": CHECKPOINT_SCHEMA_VERSION,
        "kind": kind,
        "experiment": model_identity.get("experiment"),
        "step": step,
        "resolved_config": dict(resolved_config),
        "manifest_hashes": dict(manifest_hashes),
        "model_identity": dict(model_identity),
        "metrics": dict(metrics) if metrics is not None else None,
    }


def build_latest_payload(
    model: nn.Module,
    ema: ExponentialMovingAverage,
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
    scaler: Any,
    step: int,
    stream_position: Mapping[str, Any],
    best_records: Mapping[str, Any],
    resolved_config: Mapping[str, Any],
    manifest_hashes: Mapping[str, str],
    model_identity: Mapping[str, Any],
    metrics: Mapping[str, Any] | None = None,
    adversarial_state: Mapping[str, Any] | None = None,
    rng_state: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    payload = _base_payload(
        "latest", step, resolved_config, manifest_hashes, model_identity, metrics
    )
    payload.update(
        {
            "trainable_generator": trainable_state_dict(model),
            "ema": ema.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "scaler": scaler.state_dict() if scaler is not None else None,
            "rng": dict(rng_state) if rng_state is not None else capture_rng_state(),
            "stream_position": dict(stream_position),
            "best_records": dict(best_records),
            "adversarial": dict(adversarial_state) if adversarial_state is not None else None,
        }
    )
    return payload


def build_inference_payload(
    model: nn.Module,
    ema: ExponentialMovingAverage,
    step: int,
    resolved_config: Mapping[str, Any],
    manifest_hashes: Mapping[str, str],
    model_identity: Mapping[str, Any],
    metrics: Mapping[str, Any],
) -> dict[str, Any]:
    with ema.average_parameters(unwrap_model(model)):
        inference_state = trainable_state_dict(model)
    payload = _base_payload(
        "inference", step, resolved_config, manifest_hashes, model_identity, metrics
    )
    payload["ema_inference"] = inference_state
    return payload


def validate_checkpoint_identity(
    payload: Mapping[str, Any],
    expected_kind: str,
    expected_model_identity: Mapping[str, Any],
    expected_manifest_hashes: Mapping[str, str],
) -> None:
    if payload.get("schema_version") != CHECKPOINT_SCHEMA_VERSION:
        raise ValueError(
            f"Checkpoint schema_version must be {CHECKPOINT_SCHEMA_VERSION}; legacy checkpoints are unsupported"
        )
    if payload.get("kind") != expected_kind:
        raise ValueError(f"Checkpoint kind must be {expected_kind!r}")
    if payload.get("model_identity") != dict(expected_model_identity):
        raise ValueError("Checkpoint model identity does not match the formal run")
    if payload.get("manifest_hashes") != dict(expected_manifest_hashes):
        raise ValueError("Checkpoint manifest hashes do not match the formal run")


def restore_latest_payload(
    payload: Mapping[str, Any],
    model: nn.Module,
    ema: ExponentialMovingAverage,
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
    scaler: Any,
    expected_model_identity: Mapping[str, Any],
    expected_manifest_hashes: Mapping[str, str],
    rank_value: int = 0,
) -> None:
    validate_checkpoint_identity(
        payload, "latest", expected_model_identity, expected_manifest_hashes
    )
    required = {
        "trainable_generator", "ema", "optimizer", "scheduler", "rng",
        "stream_position", "best_records",
    }
    missing = required - set(payload)
    if missing:
        raise ValueError(f"Latest checkpoint is incomplete; missing={sorted(missing)}")
    load_trainable_state_dict(model, payload["trainable_generator"])
    ema.load_state_dict(payload["ema"], unwrap_model(model))
    optimizer.load_state_dict(payload["optimizer"])
    scheduler.load_state_dict(payload["scheduler"])
    if scaler is not None:
        if payload.get("scaler") is None:
            raise ValueError("Configured scaler is absent from checkpoint")
        scaler.load_state_dict(payload["scaler"])
    rng = payload["rng"]
    if isinstance(rng, Mapping) and "per_rank" in rng:
        if int(rng.get("world_size", -1)) != len(rng["per_rank"]):
            raise ValueError("Checkpoint per-rank RNG payload is malformed")
        if rank_value >= len(rng["per_rank"]):
            raise ValueError("Checkpoint has no RNG state for this rank")
        rng = rng["per_rank"][rank_value]
    restore_rng_state(rng)


def atomic_torch_save(payload: Mapping[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    torch.save(dict(payload), temporary)
    os.replace(temporary, path)
