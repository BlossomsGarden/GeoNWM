"""Build strict six-camera nuScenes keyframe manifests for aligned modalities."""

from __future__ import annotations

import argparse
import random
from collections import defaultdict
from pathlib import Path
from typing import Any

from da3_tok.contracts import (
    CAMERA_ORDER,
    MANIFEST_SCHEMA_VERSION,
    TARGET_HEIGHT,
    TARGET_WIDTH,
)
from da3_tok.data.manifest import atomic_write_json, sha256_file, write_manifest


def _resolve_nuscenes_root(path: str | Path, version: str) -> Path:
    root = Path(path).expanduser().resolve()
    if (root / version / "scene.json").is_file():
        return root
    if root.name == version and (root / "scene.json").is_file():
        return root.parent
    raise FileNotFoundError(f"Could not find {version}/scene.json below {root}")


def _index_aligned_root(root: str | Path, modality: str) -> dict[tuple[str, str], Path]:
    root = Path(root).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"{modality} root does not exist: {root}")
    index: dict[tuple[str, str], Path] = {}
    duplicates: dict[tuple[str, str], list[Path]] = defaultdict(list)
    for path in sorted(candidate for candidate in root.rglob("*") if candidate.is_file()):
        relative_parts = path.relative_to(root).parts
        cameras = [camera for camera in CAMERA_ORDER if camera in relative_parts]
        if len(cameras) != 1:
            continue
        key = (cameras[0], path.stem)
        if key in index:
            duplicates[key].extend((index[key], path))
        else:
            index[key] = path.resolve()
    if duplicates:
        key, paths = next(iter(duplicates.items()))
        unique = sorted({str(path) for path in paths})
        raise RuntimeError(f"Ambiguous {modality} files for {key}: {unique[:4]}")
    return index


def _matrix_from_pose(translation: list[float], rotation: list[float]):
    import numpy as np
    from pyquaternion import Quaternion

    matrix = np.eye(4, dtype=np.float64)
    matrix[:3, :3] = Quaternion(rotation).rotation_matrix
    matrix[:3, 3] = np.asarray(translation, dtype=np.float64)
    return matrix


def _world_to_camera(nusc: Any, sample_data: dict[str, Any]) -> list[list[float]]:
    import numpy as np

    calibrated = nusc.get("calibrated_sensor", sample_data["calibrated_sensor_token"])
    ego_pose = nusc.get("ego_pose", sample_data["ego_pose_token"])
    sensor_to_ego = _matrix_from_pose(calibrated["translation"], calibrated["rotation"])
    ego_to_world = _matrix_from_pose(ego_pose["translation"], ego_pose["rotation"])
    return np.linalg.inv(ego_to_world @ sensor_to_ego).astype("float32").tolist()


def _aligned_intrinsics(raw: list[list[float]], raw_width: int, raw_height: int) -> list[list[float]]:
    import numpy as np

    if raw_width <= 0 or raw_height <= 0:
        raise ValueError(f"Invalid nuScenes camera size {(raw_width, raw_height)}")
    scale = TARGET_WIDTH / float(raw_width)
    resized_height = int(round(raw_height * scale))
    if resized_height < TARGET_HEIGHT:
        raise ValueError(
            f"Width-aligned camera image becomes {resized_height}px high, below target {TARGET_HEIGHT}"
        )
    crop_y = int(round((resized_height - TARGET_HEIGHT) / 2.0))
    pixel_transform = np.asarray(
        [[scale, 0.0, 0.0], [0.0, scale, -float(crop_y)], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )
    matrix = pixel_transform @ np.asarray(raw, dtype=np.float64)
    if matrix.shape != (3, 3) or not np.isfinite(matrix).all():
        raise ValueError("calibrated_sensor.camera_intrinsic must be a finite 3x3 matrix")
    return matrix.astype("float32").tolist()


def _scene_names_for_version(version: str) -> tuple[str, str]:
    if version == "v1.0-mini":
        return "mini_train", "mini_val"
    if version == "v1.0-trainval":
        return "train", "val"
    raise ValueError(f"Unsupported nuScenes version for official splits: {version}")


def build_manifests(
    nuscenes_root: str | Path,
    nuscenes_version: str,
    aligned_rgb_root: str | Path,
    aligned_depth_root: str | Path,
    aligned_semantic_root: str | Path,
    output_dir: str | Path,
    dev_scene_fraction: float,
    seed: int,
) -> dict[str, int]:
    try:
        from nuscenes.nuscenes import NuScenes
        from nuscenes.utils.splits import create_splits_scenes
    except ImportError as error:
        raise ImportError("nuscenes-devkit is required to build manifests") from error

    if not 0.0 < dev_scene_fraction < 1.0:
        raise ValueError("dev_scene_fraction must be in (0, 1)")
    dataroot = _resolve_nuscenes_root(nuscenes_root, nuscenes_version)
    nusc = NuScenes(version=nuscenes_version, dataroot=str(dataroot), verbose=False)
    rgb_index = _index_aligned_root(aligned_rgb_root, "RGB")
    depth_index = _index_aligned_root(aligned_depth_root, "depth")
    semantic_index = _index_aligned_root(aligned_semantic_root, "semantic")

    train_key, val_key = _scene_names_for_version(nuscenes_version)
    official = create_splits_scenes()
    present = {scene["name"]: scene for scene in nusc.scene}
    train_scenes = sorted(set(official[train_key]) & present.keys())
    val_scenes = sorted(set(official[val_key]) & present.keys())
    if len(train_scenes) < 2 or not val_scenes:
        raise RuntimeError("nuScenes split must contain at least two train scenes and one val scene")
    rng = random.Random(seed)
    shuffled = train_scenes.copy()
    rng.shuffle(shuffled)
    dev_count = max(1, round(len(shuffled) * dev_scene_fraction))
    dev_count = min(dev_count, len(shuffled) - 1)
    dev_scenes = set(shuffled[:dev_count])
    train_scenes = set(shuffled[dev_count:])
    split_by_scene = {name: "train" for name in train_scenes}
    split_by_scene.update({name: "dev" for name in dev_scenes})
    split_by_scene.update({name: "val" for name in val_scenes})

    records: dict[str, list[dict[str, Any]]] = {"train": [], "dev": [], "val": []}
    problems: list[str] = []
    for sample in nusc.sample:
        scene = nusc.get("scene", sample["scene_token"])
        split = split_by_scene.get(scene["name"])
        if split is None:
            continue
        views: list[dict[str, Any]] = []
        for camera in CAMERA_ORDER:
            token = sample.get("data", {}).get(camera)
            if not token:
                problems.append(f"sample={sample['token']} missing camera={camera}")
                continue
            sample_data = nusc.get("sample_data", token)
            if sample_data.get("sample_token") != sample["token"]:
                problems.append(
                    f"sample={sample['token']} camera={camera} belongs to sample={sample_data.get('sample_token')}"
                )
                continue
            stem = Path(sample_data["filename"]).stem
            paths = {
                "rgb_path": rgb_index.get((camera, stem)),
                "depth_path": depth_index.get((camera, stem)),
                "semantic_path": semantic_index.get((camera, stem)),
            }
            missing = [name for name, path in paths.items() if path is None]
            if missing:
                problems.append(f"sample={sample['token']} camera={camera} stem={stem} missing={missing}")
                continue
            calibrated = nusc.get("calibrated_sensor", sample_data["calibrated_sensor_token"])
            views.append(
                {
                    "camera": camera,
                    "sample_data_token": token,
                    **{name: str(path) for name, path in paths.items()},
                    "intrinsics": _aligned_intrinsics(
                        calibrated["camera_intrinsic"], int(sample_data["width"]), int(sample_data["height"])
                    ),
                    "world_to_camera": _world_to_camera(nusc, sample_data),
                }
            )
        if len(views) == len(CAMERA_ORDER):
            records[split].append(
                {
                    "schema_version": MANIFEST_SCHEMA_VERSION,
                    "split": split,
                    "sample_token": sample["token"],
                    "scene_name": scene["name"],
                    "views": views,
                }
            )
    if problems:
        preview = "\n".join(problems[:50])
        raise RuntimeError(f"Manifest build found {len(problems)} invalid sample-view records:\n{preview}")

    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    counts: dict[str, int] = {}
    hashes: dict[str, str] = {}
    for split in ("train", "dev", "val"):
        records[split].sort(key=lambda item: str(item["sample_token"]))
        path = output_dir / f"{split}.jsonl"
        write_manifest(path, records[split], split)
        counts[split] = len(records[split])
        hashes[split] = sha256_file(path)
    atomic_write_json(
        output_dir / "split_manifest.json",
        {
            "schema_version": MANIFEST_SCHEMA_VERSION,
            "nuscenes_version": nuscenes_version,
            "seed": seed,
            "dev_scene_fraction": dev_scene_fraction,
            "camera_order": list(CAMERA_ORDER),
            "target_size": [TARGET_HEIGHT, TARGET_WIDTH],
            "counts": counts,
            "sha256": hashes,
        },
    )
    return counts


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nuscenes-root", required=True)
    parser.add_argument("--nuscenes-version", default="v1.0-trainval")
    parser.add_argument("--aligned-rgb-root", required=True)
    parser.add_argument("--aligned-depth-root", required=True)
    parser.add_argument("--aligned-semantic-root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--dev-scene-fraction", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=20260729)
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    result = build_manifests(**vars(arguments))
    print(result)
