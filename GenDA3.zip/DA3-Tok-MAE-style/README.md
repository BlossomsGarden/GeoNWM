# DA3-Tok MAE-Style

This joint experiment keeps the four-layer weighted DA3-Tok representation and replaces only the compact RGB branch with GLD's Stage-1 MAE decoder. It is the direct weighted-fusion counterpart to `DA3-Tok-cat`.

## Controlled Representation

The frozen DA3-BASE encoder reads one nuScenes keyframe with six synchronized cameras in this exact order:

```text
CAM_FRONT, CAM_FRONT_RIGHT, CAM_BACK_RIGHT,
CAM_BACK, CAM_BACK_LEFT, CAM_FRONT_LEFT
```

All RGB, depth, semantic, intrinsics, and extrinsics inputs must already be aligned to `280x728`. The loader does not resize, warp, reorder, repair, or substitute views.

Blocks `[5,7,9,11]` each produce `[B,6,1040,1536]`. Four independent LayerNorms feed learned scalar softmax weights; their elementwise weighted sum receives the normalized block-11 mean-token broadcast. The fused output remains `[B,6,1040,1536]`.

## Exact GLD RGB Core

`vendor/gld` contains byte-identical copies of the GLD decoder, discriminator, LPIPS, DiffAug, and GAN-loss sources. The adapter changes only the MAE input width before the vendored core:

```text
decoder_embed             Linear(1536,1152)
base positional grid      504x504 -> bicubic interpolation to 20x52
decoder layers            28
attention heads           16
intermediate width        4096
patch size                14
decoder_pred              Linear(1152,14*14*3)
dropout                    0
```

Everything after `decoder_embed` follows GLD `GeneralDecoder_Variable`, including trainable CLS, fixed base sin-cos positions, interpolation, Transformer blocks, prediction, and unpatchify. The compact depth and semantic Heads are unchanged from DA3-Tok. Camera-frame points remain depth-derived.

## Joint Objective

```text
rgb_loss = RGB L1 + LPIPS
         + I(step >= 6000) * 0.75 * adaptive_weight * vanilla_GAN_G

total = rgb_loss + depth + 0.02 * point + 0.50 * semantic
```

Adaptive weight is the GLD gradient-norm ratio on `rgb_decoder.core.decoder_pred.weight`, clamped to 10000. The discriminator uses hinge loss and begins one update per successful generator step at step 4000. Generator GAN begins at step 6000. Both use the same random `224x224` crop; DiffAug probability is 1, cutout is 0, and blur warm-up is disabled. D updates clamp and approximately 8-bit quantize fake RGB. The DINO-S/8 backbone is frozen; only discriminator heads train.

The generator uses AdamW `(0.9,0.95)`, LR `2e-4`, 1000-step warm-up, cosine decay to `2e-5` at step 40000, and weight decay 0. The discriminator uses the same optimizer values, 1000 actual-update warm-up steps, and cosine decay to `2e-5` at update 16000. Full-generator EMA uses `0.9978` after every successful generator step. Frozen DA3, DINO discriminator backbone, and LPIPS are excluded from EMA and checkpoints.

## Evaluation And Checkpoints

The first run persists fixed 64-keyframe dev and 64-keyframe val subsets with seed `20260729`, exact tokens, and manifest hashes. EMA is evaluated every 1000 steps. Dev alone selects best joint, RGB, depth, point, and semantic checkpoints; val produces monitoring curves only. Aggregate and per-camera metrics cover RGB L1/LPIPS/PSNR/SSIM, depth AbsRel/RMSE/delta1, point L2/z/xy, and semantic mIoU/accuracy/per-class IoU/confusion.

`latest.pt` is the only resumable file. It includes raw generator, generator EMA, optimizers/schedulers/scaler, trainable discriminator heads, discriminator update count, per-rank RNG, stream position, identities, and metrics. Best and 5000-step milestone files contain EMA inference weights and metadata only.

## Commands

Build manifests with the local `build_manifests.py` using the same arguments documented in `DA3-Tok/README.md`.

```powershell
torchrun --standalone --nproc_per_node=2 -m da3_tok.train `
  --config configs/train.yaml `
  --train-manifest C:\data\manifests\train.jsonl `
  --dev-manifest C:\data\manifests\dev.jsonl `
  --val-manifest C:\data\manifests\val.jsonl `
  --semantic-mapping configs\semantic_label_mapping.json `
  --da3-model-dir C:\models\DA3-BASE `
  --dino-discriminator-checkpoint C:\models\discs\dino_vit_small_patch8_224.pth `
  --lpips-checkpoint C:\models\lpips\vgg.pth `
  --run-dir C:\runs\da3_tok_mae_style
```

`--lpips-checkpoint` must point to GLD's LPIPS linear weights with MD5 `d507d7349b931f0638a25a48a722f98a`. Resume with the same resolved inputs and `--resume C:\runs\da3_tok_mae_style\latest.pt`. Schema, config, manifest, DA3, DINO, and LPIPS identity mismatches fail; there is no legacy fallback.
