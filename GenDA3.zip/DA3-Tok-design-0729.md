# DA3-Tok 四组对照实验设计（0729）

- 日期：2026-07-29
- 状态：设计已批准并完成实施；CPU 可用测试与静态编译已于 2026-07-29 通过
- 适用范围：
  - `GenDA3/DA3-Tok`
  - `GenDA3/DA3-Tok-MAE-style`
  - `GenDA3/DA3-GLD-RGB-Sem`
  - `GenDA3/DA3-Tok-cat`
- 明确不修改：`GenDA3/DA3-Tok-eval`

## 1. 研究目的

这四组实验用于评估 DA3 多层特征在通道压缩率、信息保留量和下游解码性能之间的 trade-off。实验需要同时回答两个问题：

1. 未进行特征通道压缩时，DA3 四层特征对 RGB 和 semantic 的可解码能力上限是多少？
2. 将四层特征压缩成统一的 1536 通道表示时，逐元素加权融合与逐层降维后拼接分别损失了多少信息？

为使比较成立，四组实验统一使用 DA3-BASE blocks `[5, 7, 9, 11]`、同一个 nuScenes 六视角 keyframe 数据接口、相同的 `280x728` 模态坐标系以及一致的验证和 checkpoint 规则。除研究变量外，不允许通过旧逻辑、fallback 或隐含配置改变输入信息量和训练预算。

## 2. 四个目录的职责和控制变量

| 目录 | 研究角色 | 四层特征进入下游 Head 的方式 | RGB Head | 训练方式 |
| --- | --- | --- | --- | --- |
| `DA3-Tok` | 原 DA3-Tok 基线 | LayerNorm 后 scalar-softmax 加权求和，再加 final-layer mean-token broadcast，输出 1536 通道 | 原 compact RGB decoder | RGB/depth/point/semantic 联合训练，无 GAN |
| `DA3-Tok-MAE-style` | weighted fusion + 强 RGB decoder | 与 `DA3-Tok` 相同，输出 1536 通道 | GLD 原版 MAE-style decoder，只有 `decoder_embed` 输入为 1536 | RGB/depth/point/semantic 联合训练，RGB 使用 L1+LPIPS+GAN |
| `DA3-GLD-RGB-Sem` | 未压缩解码能力上限 | RGB 将四层原始 patch feature 拼成 6144 通道；semantic 直接使用四层 DA3 feature list | GLD 原版 MAE-style decoder，输入 6144 | RGB 和 semantic 两个 Head 独立训练 |
| `DA3-Tok-cat` | conv 降维后 concat 对照 | 四个独立 `LayerNorm -> 1x1 Conv(1536,384)`，再按通道拼成 1536；无 scalar weight，无 mean broadcast | 与 `DA3-Tok-MAE-style` 完全相同 | 与 `DA3-Tok-MAE-style` 完全相同的联合训练 |

`DA3-Tok-MAE-style` 和 `DA3-Tok-cat` 的唯一研究变量是 1536 通道 fused feature 的形成方法。fusion 输出之后的所有模块、维度、初始化配置、loss、optimizer、训练步数、EMA、验证子集和 checkpoint 判据必须一致。

`DA3-GLD-RGB-Sem` 的两个独立 Head 是压缩前的上限，不用它们的结果替代联合训练 checkpoint。RGB 上限对应 GLD 原始四层 concat 路径，semantic 上限对应原 DA3 DualDPT 主分支式输入和特征处理。

## 3. 为什么统一改为四层

原 `DA3-Tok` 和 `DA3-Tok-MAE-style` 使用 `[3, 5, 7, 9, 11]` 五层。正式实验统一改为 `[5, 7, 9, 11]`，原因如下：

1. `DA3-GLD-RGB-Sem` 的 GLD/DA3 基准都使用四层特征。输入层数不一致会混入额外信息量变量。
2. 较早的 block 3 可能包含更多局部和低级噪声；后四层表征更稳定。
3. `DA3-Tok-cat` 固定为 `4 x 384 = 1536`，四层输入使通道压缩率易于解释。
4. 所有实验使用完全相同的 layer order，便于做结构和 checkpoint 审计。

实现中不保留五层别名、五层默认值、自动裁剪到四层或兼容旧 checkpoint 的 fallback。旧五层 checkpoint 应因 schema/config 不匹配而被明确拒绝。

## 4. scalar softmax weights 和 mean-token broadcast 背景

### 4.1 scalar softmax weights

现有 fusion 为每个输入层维护一个可学习 scalar logit：

```text
w = softmax(layer_logits)
fused = sum_i w_i * LayerNorm(feature_i)
```

四层版本的权重初始化为 `[0.25, 0.25, 0.25, 0.25]`。它让模型以全局标量选择不同深度的特征贡献，同时维持逐元素相加和固定 1536 通道，不产生通道扩张。

代码来源审计表明，这组 learnable scalar-softmax weights 是当前 DA3-Tok fusion 的本地定制，不是原始 RAEv2 multi-layer strategy 的原样实现。它的局限是一个层在所有 view、token 和 channel 上共享同一个权重，无法表达空间或通道相关的层选择。

本设计在 `DA3-Tok` 和 `DA3-Tok-MAE-style` 中保留它，是为了维持 weighted-fusion 基线；在 `DA3-Tok-cat` 中删除它，避免 concat 分支仍被全局 scalar gate 改写。

### 4.2 final-layer mean-token broadcast

weighted fusion 在加权求和后还执行：

```text
global_context = normalized_layer_11.mean(dim=patch_token)
fused = fused + global_context.broadcast_to_all_patch_tokens()
```

它把最后一层的全局平均语义注入每个空间 token。相关机制可在 DINOv3 RAEv2 路径中找到，而 DINOv2 MLS 路径并不统一采用这一项。它的目的通常是让每个局部 token 获得一个低成本的全局图像/视角上下文。

它同时会把同一个向量加到所有空间位置，无法保留该全局项的空间来源。`DA3-Tok-cat` 的目标是直接比较四层独立降维后保留的信息，因此删除 broadcast，防止它与 concat 表示混合。weighted 两组继续保留，以保持既有基线机制。

## 5. 统一 nuScenes 数据接口

### 5.1 样本定义

一个 dataset item 是一个 nuScenes keyframe `sample`，不是时间 clip，也不是连续九个 `CAM_FRONT` frame。每个 item 必须包含同一 sample 的六个同步 camera view，固定顺序为：

1. `CAM_FRONT`
2. `CAM_FRONT_RIGHT`
3. `CAM_BACK_RIGHT`
4. `CAM_BACK`
5. `CAM_BACK_LEFT`
6. `CAM_FRONT_LEFT`

`CAM_FRONT` 是 DA3 reference view。manifest 构建必须从 keyframe sample 出发，解析这六个 camera 的 `sample_data`，禁止通过 prev/next 链构造时间窗口。

### 5.2 必需模态

每个 camera record 必须提供：

- camera channel 名称和 sample-data token；
- RGB 路径；
- MoGe2 depth 路径，以及可选文件内 depth mask；
- semantic class-ID 路径；
- `3x3` intrinsics；
- `4x4` world-to-camera extrinsics；
- sample token 和必要的数据身份信息。

train/dev/val 使用同一 schema。manifest 读取时必须验证 camera 数量、固定顺序、token 唯一性和路径存在性。缺失 camera、重复 camera、错序、跨 sample 配对和跨 camera stem fallback 都直接报错。

### 5.3 对齐和 tensor shape

所有模态在进入训练前必须已经对齐到 `280x728`。加载器不 resize、不 crop、不 warp supervision，也不静默修正 intrinsics。

主要 tensor shape 为：

```text
rgb_01             [B, 6, 3, 280, 728]
image_da3          [B, 6, 3, 280, 728]
depth              [B, 6, 1, 280, 728]
depth_valid        [B, 6, 1, 280, 728]
semantic           [B, 6, 280, 728]
semantic_valid     [B, 6, 280, 728]
intrinsics         [B, 6, 3, 3]
world_to_camera    [B, 6, 4, 4]
```

DA3 patch size 为 14，因此 token grid 固定为 `20x52`，每层 patch feature 为 `[B,6,1040,1536]`。

### 5.4 有效 mask

有效 mask 是监督标签侧的布尔选择，不是模型预测的 confidence。

```text
depth_valid = optional_file_mask AND finite(depth) AND depth > 0
semantic_valid = semantic_train_id in [0, 9]
```

semantic 原始 ignore/void ID `255` 映射为 `-1`，不参与 CE 或指标；未知 ID 不是 ignore，应直接报错。RGB 全部像素有效。

DA3 DualDPT 的 `depth_conf` 是连续预测置信度，不是 ground-truth validity。主 depth/point 指标不允许用预测 confidence 选择更容易的像素。若模型在有效 GT 区域产生 NaN/Inf，评估直接失败，不能通过修改 mask 将其排除。

point target 由有效 depth 和 intrinsics 反投影得到，因此 point loss/metric 共用 `depth_valid`，不另设模型输出的 point mask。

## 6. Backbone 和特征提取

### 6.1 DA3-Tok 系列

`DA3-Tok`、`DA3-Tok-MAE-style` 和 `DA3-Tok-cat` 使用 geometry-aware `DA3FrozenEncoder`：

- 加载本地 DA3-BASE checkpoint；
- 使用 intrinsics 和 world-to-camera 构造 camera token；
- 第一 view 固定为 `CAM_FRONT` reference；
- 一次联合编码六视角；
- 提取 blocks `[5,7,9,11]`；
- 输出 patch-only `[B,6,1040,1536]` feature；
- 全部 DA3 参数冻结并保持 eval。

旧 `FiveLayerRAEv2Fusion` 和 five-layer encoder 命名/校验应改成明确的 four-layer 版本，不保留活动兼容入口。

### 6.2 DA3-GLD RGB

RGB 上限严格保留 GLD `RAE_DA3` 的四层 raw feature extraction，包括原始 learned reference/source camera-token 行为。GLD 路径输出每层 `[B*6,1041,1536]`，index 0 为 CLS。训练 RGB decoder 时执行原 GLD 逻辑：

```text
for layer in [5,7,9,11]: remove CLS
concat along channel
z_rgb = [B*6, 1040, 6144]
```

nuScenes adapter 只替换数据来源和训练步数调度，不改 feature extraction、CLS removal、concat 或 MAE decoder core。

### 6.3 DA3-GLD Semantic

Semantic 上限使用原 DA3 geometry-aware 的四层 feature list 输入方式。四层特征不 concat、不压缩、不做 scalar weighted fusion，直接进入 Semantic DPT Head。RGB 和 semantic 是两个独立训练入口，因此不强行把 GLD RGB encoder 路径与原 DA3 semantic 路径合并。

## 7. Fusion 设计

### 7.1 Weighted fusion

适用于 `DA3-Tok` 和 `DA3-Tok-MAE-style`：

```text
input per layer: [B,6,1040,1536]
each layer: independent LayerNorm(1536)
weights: softmax(4 trainable scalar logits)
elementwise weighted sum
add normalized layer-11 mean patch token broadcast
output: [B,6,1040,1536]
```

fusion forward 同时返回四个 weights，用于训练日志和曲线。

### 7.2 Conv-concat fusion

仅适用于 `DA3-Tok-cat`：

```text
for each layer independently:
  LayerNorm(1536)
  [B,6,1040,1536] -> [B*6,1536,20,52]
  Conv2d(1536,384,kernel_size=1,bias=True)
  no activation
concat [5,7,9,11] along channel
output: [B,6,1040,1536]
```

四个 Conv 不共享参数。该路径不创建 `layer_logits`，不做 softmax gating，也不做 final-layer mean broadcast。

## 8. RGB Head

### 8.1 必须使用 GLD 原版 decoder

当前 `DA3-Tok-MAE-style` 本地 `MAEStyleRGBHead` 不是 GLD `GeneralDecoder_Variable` 的精确等价实现：本地版本直接创建 `20x52` 矩形 sin-cos position embedding，而 GLD 从 `504x504` base grid 的 position embedding bicubic 插值到目标 grid。

因此实施时替换本地近似实现，vendoring GLD 原始 `GeneralDecoder_Variable` 和所需 decoder 代码。不能同时保留两个 MAE decoder 供 fallback 选择。

统一 MAE decoder 参数为：

```text
decoder_hidden_size          1152
decoder_num_hidden_layers      28
decoder_num_attention_heads    16
decoder_intermediate_size    4096
patch_size                     14
num_channels                    3
dropout                         0
layer_norm_eps              1e-12
```

输入差异只有：

- `DA3-GLD-RGB-Sem`: `decoder_embed = Linear(6144,1152)`；
- `DA3-Tok-MAE-style`: `decoder_embed = Linear(1536,1152)`；
- `DA3-Tok-cat`: `decoder_embed = Linear(1536,1152)`。

后续 trainable CLS、position interpolation、28 层 transformer、decoder norm、`decoder_pred` 和 unpatchify 全部相同。decoder 为每个 view 独立重建 RGB；六视角交互已经发生在 DA3 feature extraction 阶段。

`DA3-Tok` 保留原 compact RGB decoder，不改成 MAE Head。

## 9. Semantic DPT Head

`DA3-GLD-RGB-Sem` 的 Semantic Head 复制 DA3 `DualDPT` depth main branch 的架构和特征处理，不复制 ray auxiliary branch：

```text
shared LayerNorm over dim 1536
per-stage 1x1 projections: [96,192,384,768]
spatial scaling: [x4,x2,x1,/2]
UV positional embedding
four-level RefineNet fusion
features = 128
output path: 128 -> 64 -> 32 -> 10
```

最后输出 10 个线性 semantic logits，不使用 depth activation，不额外输出 semantic confidence。semantic validity 来自 label ignore mask，而不是 Head。

联合训练的 `DA3-Tok`、`DA3-Tok-MAE-style` 和 `DA3-Tok-cat` 继续使用它们共同的 compact depth/semantic decoder。`DA3-Tok-MAE-style` 与 `DA3-Tok-cat` 在 fusion 之后的 decoder 结构必须完全一致。

point 不增加独立 Head。预测 depth 通过 intrinsics 反投影后计算 point loss 和 point metric。

## 10. Loss 设计

### 10.1 DA3-Tok

保留原基线目标，不增加 GAN：

```text
total =
    1.00 * RGB Charbonnier
  + 0.20 * LPIPS
  + 1.00 * depth
  + 0.02 * point
  + 0.50 * semantic
```

### 10.2 DA3-Tok-MAE-style 和 DA3-Tok-cat

两者使用完全相同的联合目标：

```text
rgb_loss =
    1.00 * RGB L1
  + 1.00 * GLD LPIPS
  + I(global_step >= 6000) * 0.75 * adaptive_weight * vanilla_GAN_G

total =
    1.00 * rgb_loss
  + 1.00 * depth
  + 0.02 * point
  + 0.50 * semantic
```

adaptive weight 使用 GLD 原算法：分别计算 `L1+LPIPS` 与 generator GAN loss 对 `rgb_decoder.decoder_pred.weight` 的梯度范数，取比值并 clamp 到 `10000`。depth、point、semantic 不进入 adaptive-weight numerator。

### 10.3 DA3-GLD-RGB-Sem

- `train_rgb.py`：只训练 MAE decoder，使用上面的完整 `rgb_loss`。
- `train_semantic.py`：只训练 Semantic DPT Head，使用未乘 `0.5` 的 weighted CE。

### 10.4 Dense loss 明细

- depth：`depth_valid` 上的 `abs(log(pred)-log(target))`；
- point：预测和目标 depth 反投影后的 camera-frame 3D Charbonnier distance；
- semantic：weighted cross-entropy，`ignore_index=-1`；
- semantic class weights：
  `[0.39,0.25,0.36,0.43,1.90,3.00,0.25,0.87,0.56,0.25]`。

不增加 Dice、Lovasz、boundary 或 auxiliary semantic loss。

## 11. GLD Stage-1 GAN 细节

MAE RGB 训练保留 GLD Stage-1 行为：

- generator GAN loss：vanilla；
- discriminator loss：hinge；
- `disc_weight=0.75`；
- discriminator 从 global step 4000 开始更新；
- generator 从 global step 6000 开始加入 GAN loss；
- LPIPS 从 step 0 开始；
- 每个 generator step 对应一次 discriminator update；
- generator GAN 使用随机 `224x224` crop；
- discriminator 的 real/fake 使用同一 crop 坐标；
- 输入 discriminator 前处于 `[-1,1]`；
- DiffAug `prob=1.0`、`cutout=0.0`；
- discriminator 更新的 fake 先 clamp，再近似量化到 8-bit；
- DINO-S/8 discriminator backbone 冻结，只训练 discriminator heads；
- 不启用 GLD 代码支持但原配置没有调用的 blur warm-up。

验证不使用随机 crop、DiffAug 或 GAN loss。

## 12. Step-based optimizer 和 scheduler

nuScenes 训练统一使用 optimizer step，而不是 epoch，避免数据量和 world size 改变 GAN/验证边界。

### 12.1 Generator/Head

```text
total_steps                  40000
optimizer                    AdamW
base_lr                      2e-4
betas                        (0.9, 0.95)
weight_decay                 0
warmup_steps                 1000
cosine_decay_end_step        40000
final_lr                     2e-5
```

该配置适用于三个联合训练任务、GLD standalone RGB 和 GLD standalone semantic。

### 12.2 Discriminator

```text
optimizer                    AdamW
base_lr                      2e-4
betas                        (0.9, 0.95)
weight_decay                 0
update_start_global_step     4000
warmup_updates               1000
cosine_decay_end_updates     16000
final_lr                     2e-5
updates_per_generator_step   1
```

discriminator scheduler 按实际 discriminator update count 计数，不按 global generator step 或 epoch 计数。

训练默认 BF16/DDP；只有 FP16 使用 GradScaler。global step 表示成功完成的 generator optimizer step。

## 13. EMA

统一 `ema_decay=0.9978`，每个 generator optimizer step 完成后更新一次：

```text
ema = 0.9978 * ema + 0.0022 * current
```

选择原因：

- 它是 GLD 原始 DA3 Stage-1 MAE 配置值；
- 半衰期约 315 optimizer steps，有效平均窗口约 455 steps；
- 能在 step 4000/6000 的 discriminator/GAN 状态切换后，在下一次 1000-step 验证前较快适应；
- `0.9995` 半衰期约 1386 steps，会长时间混入切换前参数；
- `0.9999` 半衰期约 6931 steps，对 40000-step Stage-1 训练过于滞后。

EMA 范围：

- 联合模型：fusion、RGB decoder、depth/semantic decoder 的所有 trainable parameters；
- `DA3-Tok`：同样新增 full-generator EMA；
- GLD RGB：MAE decoder；
- GLD Semantic：Semantic DPT Head；
- 不包含 frozen DA3、LPIPS 或 discriminator。

dev/val 和保存的 best/milestone 推理权重统一使用 EMA。raw generator 只用于继续训练。

## 14. 固定 dev/val 子集

每个 run 首次创建：

```text
subset_seed = 20260729
dev samples = 64
val samples = 64
```

每个 sample 含六视角，因此每次 dev 和 val 各评估 384 张图像。

`dev_subset.json` 和 `val_subset.json` 保存：

- manifest hash；
- sample token；
- manifest index；
- 六个 camera channel 和 sample-data token；
-固定 camera order；
- subset seed。

resume 时必须复用已有文件。manifest hash 改变时直接报错，不重新抽样。manifest 少于 64 个 sample 时直接报错。

旧 scene-stratified selector、temporal-centre clip selector、`max_dev_batches` 的硬件相关截断和任何 fallback 全部删除。

## 15. 验证 loss 和指标

每 1000 optimizer steps 使用 EMA 评估一次固定 dev 和 val。验证使用完整 `280x728`，不做随机 crop 或 DiffAug。

### 15.1 验证 loss

MAE joint：

```text
dev_total = L1 + LPIPS + depth + 0.02*point + 0.5*semantic
```

不把 GAN score 放入 dev total，因为 discriminator 在共同变化，不能作为稳定的 reconstruction checkpoint 判据。

DA3-Tok：

```text
dev_total = Charbonnier + 0.20*LPIPS + depth + 0.02*point + 0.5*semantic
```

Standalone RGB 使用 `L1+LPIPS`，Standalone Semantic 使用 weighted CE。

### 15.2 指标

- RGB：L1、LPIPS、PSNR、SSIM；
- Depth：AbsRel、RMSE、delta1；
- Point：camera-frame 3D mean L2、mean absolute z error、mean xy L2；
- Semantic：mIoU、pixel accuracy、10 类 per-class IoU、`10x10` confusion matrix。

保存六视角总体指标和 per-camera 明细。best checkpoint 和主曲线只使用六视角总体指标。

所有 sufficient statistics 先在 DDP ranks 间求和，再计算最终指标。Distributed eval sampler 不得通过 padding 重复 sample。LPIPS/SSIM 等按明确的 image count 聚合。

## 16. Best-checkpoint 判据

只使用 dev 选择 best，val 只绘制固定样本监控曲线：

```text
best_joint     minimum dev_total
best_rgb       minimum dev (RGB L1 + LPIPS)
best_depth     minimum dev AbsRel
best_point     minimum dev camera-frame 3D mean L2
best_semantic  maximum dev mIoU
```

为跨 RGB decoder 公平比较，`best_rgb` 统一使用 `L1+LPIPS`，即使 `DA3-Tok` 的训练 RGB objective 是 Charbonnier+0.20 LPIPS。

Standalone GLD RGB 只生成 `best_rgb`；Standalone GLD Semantic 只生成 `best_semantic`。联合实验生成五类 best。

## 17. Checkpoint event 和保存策略

### 17.1 触发频率

```text
loss_log_every       10 steps
checkpoint_event   1000 steps
milestone_every    5000 steps
```

每次 checkpoint event：

1. 同步 ranks；
2. 切换到 EMA 并评估固定 dev/val；
3. 写入 JSONL 和更新曲线；
4. 原子写入 `latest.pt`；
5. 根据 dev 判据写 best；
6. 如命中 5000-step 边界，写 milestone；
7. 恢复 raw generator 继续训练。

同一步同时命中 latest、best 和 milestone 时只评估一次。

### 17.2 分级 payload

`latest.pt` 是唯一完整可恢复 checkpoint，原子覆盖保存：

- trainable raw generator/Head；
- trainable EMA；
- generator optimizer 和 scheduler；
- FP16 scaler（若存在）；
- trainable discriminator heads、optimizer、scheduler 和 update count（GAN 任务）；
- global step、data epoch/cursor 和 RNG states；
- best records、resolved config 和 schema metadata。

`best_*.pt` 和 `milestones/step_XXXXX.pt` 只保存：

- trainable EMA inference weights；
- step；
- resolved config 和模型身份；
- 对应 dev/val metrics。

它们不保存 raw generator、optimizer、discriminator 或 RNG，不能作为精确训练 resume checkpoint。

### 17.3 明确不保存的权重

- frozen DA3 backbone/camera encoder；
- frozen DINO-S/8 discriminator backbone；
- frozen LPIPS。

checkpoint 只记录这些依赖的模型标识、配置、路径和权重摘要。resume 时重新加载并校验。schema version、实验类型、layers、camera order、fusion type、manifest hash 或 backbone identity 不一致时拒绝 resume。

## 18. 日志和可视化产物

每个 run 至少输出：

```text
config_resolved.yaml
dev_subset.json
val_subset.json
train_metrics.jsonl
dev_metrics.jsonl
val_metrics.jsonl
loss_curves.png
metric_curves_dev.png
metric_curves_val.png
semantic_iou_curves_dev.png
semantic_iou_curves_val.png
semantic_confusion_latest.png
fusion_weight_curves.png        # weighted fusion 实验
latest.pt
best_*.pt
milestones/
visuals/
```

`train_metrics.jsonl` 每 10 steps 记录 total、各模态 loss、L1、LPIPS、GAN、adaptive weight、discriminator loss/accuracy、generator/discriminator LR 和 fusion weights（若存在）。

每次 checkpoint event 重新生成曲线。固定样本可视化显示 RGB reconstruction、depth 和 semantic，不使用它们选择 checkpoint。

## 19. 自包含目录和执行接口

采用四个实验目录完全自包含的方案，不建立 `GenDA3/common`，也不使用单一运行时 fusion switch。

建议目录边界：

```text
DA3-Tok/
  train.py
  build_manifests.py
  configs/
  da3_tok/
  tests/

DA3-Tok-MAE-style/
  train.py
  build_manifests.py
  configs/
  da3_tok/
  vendor/gld/
  tests/

DA3-GLD-RGB-Sem/
  train_rgb.py
  train_semantic.py
  build_manifests.py
  configs/rgb.yaml
  configs/semantic.yaml
  da3_gld/
  vendor/gld/
  tests/

DA3-Tok-cat/
  train.py
  build_manifests.py
  configs/
  da3_tok/
  vendor/gld/
  tests/
```

四组入口统一参数命名：train/dev/val manifest、nuScenes root、DA3 model directory、run directory、resume、DDP、precision 和 worker/batch 配置。GLD 目录的两个入口只暴露对应 Head 需要的配置。

GLD vendored code 保持原始 RGB feature extraction、decoder、LPIPS、discriminator 和 GAN loss core；nuScenes 数据与 step-based trainer 作为外围 adapter。这样既保证目录独立，又能审计 GLD core 是否改变。

## 20. 错误处理和禁止的 fallback

以下情况直接失败：

- camera 缺失、重复或顺序错误；
- 六个 camera 不属于同一 sample；
- 任一模态不是 `280x728`；
- intrinsics/extrinsics shape 错误或非有限；
- depth/semantic 文件缺失；
- semantic 出现未映射的未知 ID；
- 有效 GT 区域出现非有限预测；
- 任一评估域有效 count 为 0；
- DDP 汇总的 sample/view count 与固定子集不一致；
- checkpoint schema/config/model identity 不一致；
- 旧五层 checkpoint 尝试 resume。

明确不允许：

- 九帧时间 clip fallback；
- 缺失 camera 时复用其他 view；
- 自动调整 camera order；
- 自动 resize/warp 已对齐 supervision；
- 用预测 confidence 修改主指标 mask；
- 同时保留旧 MAE Head；
- 自动从四层退回五层或相反；
- 在 `DA3-Tok-cat` 中保留 scalar gate 或 mean broadcast；
- 修改 `DA3-Tok-eval` 作为训练评估依赖。

## 21. 测试计划

### 21.1 数据和 manifest

- 一个 manifest record 对应一个 keyframe sample；
- 六 camera 固定顺序通过；缺失、重复、错序和跨 sample 失败；
- 所有模态 shape 和相机矩阵校验；
- depth/semantic valid mask 数值测试；
- 未知 semantic ID 失败；
- fixed dev/val subset 在 resume 后完全一致；
- manifest hash 改变失败。

### 21.2 模型结构

- blocks 严格为 `[5,7,9,11]`；
- weighted fusion 的 LayerNorm、softmax、加权和和 mean broadcast 数值测试；
- cat fusion 有四个独立 Conv，输出顺序和 1536 通道正确；
- cat state dict 不含 `layer_logits`；
- MAE-style 和 cat 在 fusion 之后的参数名、shape 和 config 完全一致；
- GLD decoder 与原代码的 state-dict schema、config 和小型 seeded forward parity；
- Semantic DPT 四尺度处理正确，输出 10 logits，无 ray/confidence；
- point 由 depth 反投影，不存在独立 point Head。

### 21.3 训练

- loss 权重和 semantic class weights；
- discriminator 在 step 3999/4000 的边界；
- generator GAN 在 step 5999/6000 的边界；
- adaptive weight 只对 RGB reconstruction 求 numerator 且 clamp 到 10000；
- generator/discriminator scheduler 分别按正确 counter 更新；
- EMA decay、更新时机和覆盖参数集合；
- synthetic 六视角 batch 完成 forward/backward/optimizer step。

### 21.4 评估和 checkpoint

- RGB/depth/point/semantic 指标使用已知小 tensor 验证；
- DDP sufficient-statistic reduction 不因 rank 数变化；
- aggregate 和 per-camera count 正确；
- best 判据方向正确；
- val 不触发 best；
- 同一步只运行一次评估；
- `latest.pt` 可精确 resume；
- best/milestone 只含 EMA inference payload；
- 所有 checkpoint 明确不含 DA3 backbone keys。

### 21.5 运行环境

CPU 单元测试使用 synthetic data 和小型配置。真实 DA3 checkpoint、完整 MAE decoder、DINO discriminator 和 CUDA/DDP 测试单独标记；环境缺少权重或 GPU 时必须明确报告跳过原因，不伪报通过。

## 22. README 和叙述更新

四个目录 README 必须说明：

- 实验目的和相互区别；
- blocks `[5,7,9,11]`；
- 一个 sample 的六视角顺序；
- `280x728` 严格对齐；
- fusion/Head tensor shape；
- loss、GAN step、EMA 和 optimizer schedule；
- dev/val 64-sample 固定子集；
- checkpoint payload 和 best 判据；
- 完整训练、resume 和 standalone Head 命令。

删除四个目标目录中与活动设计冲突的 five-layer、九帧 CAM_FRONT、scene-stratified/temporal-centre selector、旧 MAE Head 和 fallback 叙述。原需求不再以 README 隐藏 HTML 注释保留，本文档作为正式设计留档。

## 23. 非目标

- 不改 `GenDA3/DA3-Tok-eval`；
- 不训练或保存 DA3 backbone；
- 不为 point 新建独立 decoder；
- 不为 semantic 新增 confidence、ray、Dice、Lovasz 或 auxiliary Head；
- 不给 `DA3-Tok` 增加 GAN；
- 不将四个实验合并成一个 runtime-configured 模型；
- 不用 val 选择 best checkpoint；
- 不加入未确认的 temporal consistency 或 LiDAR calibration 指标。

## 24. 完成标准

实施完成需同时满足：

1. 四个目录可独立构建六视角 manifest 并启动对应训练。
2. 四组数据接口、camera order、分辨率、layers、schedule、EMA 和评估子集一致。
3. `DA3-GLD-RGB-Sem` RGB core 与 GLD 原实现保持 parity。
4. `DA3-Tok-MAE-style` 与 `DA3-Tok-cat` 除 fusion 外结构和训练行为一致。
5. MAE RGB 三组均保留 GLD Stage-1 L1+LPIPS+GAN 细节。
6. dev/val 指标、曲线、可视化和 checkpoint event 在四个目录内部完成。
7. checkpoint 不包含 DA3 backbone，EMA decay 为 0.9978。
8. 旧五层、九帧、scene-stratified 和 fallback 活动逻辑被删除。
9. 单元测试和可运行的 smoke test 通过；无法运行的 GPU/权重测试明确列出。
10. 四个 README 与本文档一致，`DA3-Tok-eval` 未被修改。

## 26. 远端 CUDA 验收记录（2026-07-29）

远端工作目录固定为 `/data4/DATA/wlh/GenDA3`，使用 `/data/wlh/miniconda3` 的 `da3` 环境（Python 3.10.13、PyTorch 2.5.1、CUDA 12.4）以及物理 GPU `cuda:2,3`。DA3 源码通过 `PYTHONPATH=/data/wlh/DA3/code/Depth-Anything-3-main/src` 直接加载，没有安装或复制第二份 DA3 package。

冻结依赖均从服务器已有绝对路径直接加载，没有创建软链接：

```text
DA3-BASE:
  /data/wlh/DA3/model/DA3-BASE/model.safetensors
  SHA256 e01067dc1659613083d9145a9a2547ccdbe6ccbbf83c4fe7b3e8a4e2bdae78b5
DINO-S/8 discriminator:
  /data4/DATA/wlh/GenDA3/model/discs/dino_vit_small_patch8_224.pth
  SHA256 55c8b267f479b614ec20858947ce361ba804846c193e20be74263a096bb6d75e
GLD LPIPS linear weights:
  /home/wlh/.cache/torch/hub/checkpoints/vgg.pth
  MD5 d507d7349b931f0638a25a48a722f98a
VGG16:
  /home/wlh/.cache/torch/hub/checkpoints/vgg16-397923af.pth
  SHA256 397923af8e79cdbb6a7127f12361acd7a2f83e06b05044ddf496e83de57a5bf0
```

远端 `da3` 环境没有安装 pytest。本次没有修改环境，而是将服务器已有 pytest 8.3.5 的纯 Python site-packages 追加到 `da3` Python 搜索路径，并关闭第三方 plugin 自动加载。实际 PyTorch/CUDA 依赖仍全部来自 `da3`。结果为：

```text
DA3-Tok             50 passed
DA3-Tok-MAE-style   33 passed, 11 skipped
DA3-GLD-RGB-Sem     32 passed, 12 skipped
DA3-Tok-cat         42 passed, 11 skipped
```

skip 仅对应服务器不存在外部 `GLD-main` 原仓库，因而不能在远端重复 source-vs-vendor byte parity；本地存在原仓库时这些 parity test 已实际运行并通过。所有运行时测试、LPIPS 显式路径/MD5 测试、架构测试和 checkpoint 测试均在远端执行。四目录远端 `compileall` 同样通过。

使用一个真实 nuScenes keyframe 的六个同步 camera 构造临时 `280x728` batch 后，正式 BF16 optimizer-step helper 的验收结果如下：

| 任务 | 结果 | 峰值显存 |
| --- | --- | ---: |
| `DA3-Tok` joint | forward/backward/AdamW/scheduler/EMA 通过 | 13.86 GiB |
| `DA3-Tok-MAE-style` joint | step 0 全 RGB/dense loss 通过 | 39.73 GiB |
| `DA3-Tok-cat` joint | step 0 全 RGB/dense loss 通过 | 39.66 GiB |
| `DA3-GLD-RGB-Sem` RGB | standalone RGB step 通过 | 31.24 GiB |
| `DA3-GLD-RGB-Sem` Semantic | standalone semantic step 通过 | 2.02 GiB |

MAE-style 还在 `formal_step=6000` 运行了 warm-up 后的完整 GAN 路径：adaptive weight、vanilla generator GAN、`0.75` GAN 系数、hinge discriminator update 均实际执行，discriminator update count 为 1，峰值显存 43.13 GiB。双卡 DDP 使用物理 `cuda:2,3` 构造完整 MAE-style generator 和 discriminator，完成参数广播、all-reduce 与 NCCL barrier；两个 rank 均成功退出。

正式训练尚未启动。服务器现有 RGB/semantic 源文件为 `900x1600`，MoGe2 depth 为 `480x832`，不满足本文规定的预对齐 `280x728` loader contract；因此不能将它们直接写入正式 manifest。smoke test 只使用临时、明确标记的对齐 batch，验收后删除。全量训练前必须先按同一相机坐标变换离线生成 `280x728` RGB/depth/semantic，再运行 `build_manifests.py`；不得通过训练 loader fallback 或静默 resize 绕过该条件。

## 25. 实施验收记录

本设计已落入四个自包含目录。最终本机验证结果：

```text
DA3-Tok             29 passed, 7 skipped
DA3-Tok-MAE-style   40 passed, 1 skipped
DA3-GLD-RGB-Sem     37 passed, 2 skipped
DA3-Tok-cat         45 passed, 2 skipped
```

四个目录的 `compileall` 均通过。跳过项需要当前环境未安装的 PyTorch，或需要真实 DA3/DINO 权重与 CUDA/DDP；未将这些项目记为通过。

交叉审计确认：

1. 五个正式 config（含 GLD 的 RGB/Semantic 两份）均使用六视角 keyframe、`280x728`、blocks `[5,7,9,11]`、40000 steps、EMA `0.9978`、dev/val 各 64 samples。
2. GLD decoder、encoder、LPIPS、DiffAug、GAN loss 和 discriminator vendor 源码通过 byte-level parity 测试。
3. `DA3-Tok-MAE-style` 与 `DA3-Tok-cat` 的 architecture manifest 除 fusion 字段外相同；下游实现文件和 vendor tree 通过 hash parity。
4. cat fusion 不创建 scalar logits，不执行 mean-token broadcast；四个 `LayerNorm -> Conv2d(1536,384,1)` 独立并按 `[5,7,9,11]` 拼接。
5. checkpoint adapter 只序列化各模型显式声明的 trainable modules，并拒绝名为 encoder/DA3/backbone 的模块。
6. checkpoint event 会验证 DDP 聚合后的 dev/val 数量严格为 64 samples、384 views，且每个 camera 各 64 views。
7. 四个训练目录没有导入 `DA3-Tok-eval`，该目录未被修改。
