"""Train the uncompressed four-level DA3 Semantic DPT Head on nuScenes."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Iterable, Mapping

import torch
from torch import nn
from torch.nn.parallel import DistributedDataParallel as DDP

from da3_gld.checkpointing import (
    atomic_torch_save,
    build_inference_payload,
    build_latest_payload,
    formal_model_identity,
    restore_latest_payload,
    unwrap_model,
)
from da3_gld.config import SEMANTIC_EXPERIMENT, write_resolved_config
from da3_gld.contracts import SEMANTIC_CLASSES, validate_evaluation_cardinality
from da3_gld.data.label_spec import SemanticLabelSpec
from da3_gld.distributed import (
    barrier,
    cleanup_distributed,
    is_main_process,
    reduce_sum,
    setup_distributed,
)
from da3_gld.ema import ExponentialMovingAverage
from da3_gld.evaluation import evaluate_semantic_dev_val, update_best_semantic
from da3_gld.losses import SemanticCrossEntropyLoss
from da3_gld.models import SemanticUpperBound
from da3_gld.plotting import (
    append_jsonl,
    render_semantic_artifacts,
    save_semantic_visualization,
)
from da3_gld.schedules import make_cosine_warmup_scheduler
from da3_gld.training import (
    all_rank_rng_state,
    autocast_context,
    evaluation_record,
    frozen_da3_identity,
    make_dataloaders,
    move_batch,
    require_cuda_device,
    resolve_runtime_config,
)


def parse_args() -> argparse.Namespace:
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=project / "configs" / "semantic.yaml")
    parser.add_argument("--train-manifest", type=Path)
    parser.add_argument("--dev-manifest", type=Path)
    parser.add_argument("--val-manifest", type=Path)
    parser.add_argument(
        "--semantic-mapping",
        type=Path,
        default=project / "configs" / "semantic_label_mapping.json",
    )
    parser.add_argument("--da3-model-dir", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--workers", type=int)
    parser.add_argument("--gradient-accumulation", type=int, default=1)
    parser.add_argument("--view-chunk-size", type=int)
    parser.add_argument("--precision", choices=("bf16", "fp16", "fp32"))
    return parser.parse_args()


def _semantic_weights(config: Mapping[str, Any], device: torch.device) -> torch.Tensor:
    weights = torch.tensor(
        config["loss"]["semantic_class_weights"], dtype=torch.float32, device=device
    )
    if weights.shape != (SEMANTIC_CLASSES,) or not torch.isfinite(weights).all():
        raise ValueError("semantic_class_weights must contain ten finite values")
    if (weights <= 0).any():
        raise ValueError("semantic_class_weights must be positive")
    return weights


def train_semantic_optimizer_step(
    model: nn.Module,
    criterion: nn.Module,
    batches: Iterable[Mapping[str, Any]],
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
    ema: ExponentialMovingAverage,
    device: torch.device,
    precision: str,
    scaler: Any = None,
) -> tuple[dict[str, torch.Tensor], int]:
    batches = list(batches)
    if not batches:
        raise ValueError("One optimizer step requires at least one microbatch")
    optimizer.zero_grad(set_to_none=True)
    semantic_sum = torch.zeros((), dtype=torch.float64, device=device)
    semantic_count = torch.zeros((), dtype=torch.float64, device=device)
    for raw_batch in batches:
        batch = move_batch(raw_batch, device)
        with autocast_context(device, precision):
            prediction = model(
                batch["image_da3"], batch["intrinsics"], batch["world_to_camera"]
            )
            losses = criterion(prediction, batch)
            backward = losses["total"] / len(batches)
        if scaler is not None and scaler.is_enabled():
            scaler.scale(backward).backward()
        else:
            backward.backward()
        semantic_sum += losses["semantic_sum"].double()
        semantic_count += losses["semantic_count"].double()
    stepped = True
    if scaler is not None and scaler.is_enabled():
        previous_scale = scaler.get_scale()
        scaler.step(optimizer)
        scaler.update()
        stepped = scaler.get_scale() >= previous_scale
    else:
        optimizer.step()
    if not stepped:
        optimizer.zero_grad(set_to_none=True)
        return {"semantic_sum": semantic_sum, "semantic_count": semantic_count}, 0
    scheduler.step()
    ema.update(unwrap_model(model))
    return {"semantic_sum": semantic_sum, "semantic_count": semantic_count}, 1


def main() -> None:
    args = parse_args()
    config = resolve_runtime_config(args, SEMANTIC_EXPERIMENT, require_discriminator=False)
    rank, world_size, local_rank = setup_distributed()
    device = require_cuda_device(local_rank)
    run_dir = args.run_dir.expanduser().resolve()
    if is_main_process():
        run_dir.mkdir(parents=True, exist_ok=True)
        write_resolved_config(config, run_dir)
    barrier()
    semantic_spec = SemanticLabelSpec.from_json(args.semantic_mapping)
    if semantic_spec.classes != SEMANTIC_CLASSES or semantic_spec.ignore_index != -1:
        raise ValueError("Semantic mapping must define ten classes with ignore_index=-1")
    train_loader, dev_loader, val_loader, train_sampler, manifest_hashes = make_dataloaders(
        config, args.semantic_mapping, run_dir, rank, world_size
    )

    model = SemanticUpperBound(
        args.da3_model_dir,
        view_chunk_size=int(config["model"]["view_chunk_size"]),
    ).to(device)
    model.encoder.assert_frozen()
    if world_size > 1:
        model = DDP(model, device_ids=[local_rank], broadcast_buffers=False, find_unused_parameters=False)
    unwrapped = unwrap_model(model)
    criterion = SemanticCrossEntropyLoss(_semantic_weights(config, device), ignore_index=-1).to(device)
    optimizer = torch.optim.AdamW(
        [parameter for parameter in unwrapped.parameters() if parameter.requires_grad],
        lr=float(config["training"]["base_lr"]),
        betas=(0.9, 0.95),
        weight_decay=float(config["training"]["weight_decay"]),
    )
    scheduler = make_cosine_warmup_scheduler(
        optimizer,
        int(config["training"]["warmup_steps"]),
        int(config["training"]["steps"]),
        float(config["training"]["final_lr"]) / float(config["training"]["base_lr"]),
    )
    precision = str(config["training"]["precision"])
    scaler = torch.cuda.amp.GradScaler(enabled=precision == "fp16")
    ema = ExponentialMovingAverage(unwrapped, float(config["training"]["ema_decay"]))
    identity = formal_model_identity(
        SEMANTIC_EXPERIMENT,
        "raw_four_level_semantic_dpt",
        frozen_da3_identity(args.da3_model_dir),
    )

    global_step = 0
    data_epoch = 0
    batch_cursor = 0
    best_records: dict[str, Any] = {}
    if args.resume is not None:
        checkpoint = torch.load(args.resume, map_location=device, weights_only=False)
        if checkpoint.get("resolved_config") != config:
            raise ValueError("Resume checkpoint resolved config differs from the active config")
        restore_latest_payload(
            checkpoint,
            model,
            ema,
            optimizer,
            scheduler,
            scaler,
            identity,
            manifest_hashes,
            rank_value=rank,
        )
        if checkpoint.get("adversarial") is not None:
            raise ValueError("Semantic checkpoint must not contain adversarial state")
        global_step = int(checkpoint["step"])
        data_epoch = int(checkpoint["stream_position"]["epoch"])
        batch_cursor = int(checkpoint["stream_position"]["batch"])
        best_records = dict(checkpoint["best_records"])

    accumulation = int(config["runtime"]["gradient_accumulation"])
    total_steps = int(config["training"]["steps"])
    model.train()
    pending: list[Mapping[str, Any]] = []
    while global_step < total_steps:
        if train_sampler is not None:
            train_sampler.set_epoch(data_epoch)
        for batch_index, batch in enumerate(train_loader):
            if batch_index < batch_cursor:
                continue
            pending.append(batch)
            batch_cursor = batch_index + 1
            if len(pending) < accumulation:
                continue
            losses, advanced = train_semantic_optimizer_step(
                model,
                criterion,
                pending,
                optimizer,
                scheduler,
                ema,
                device,
                precision,
                scaler,
            )
            pending.clear()
            if not advanced:
                continue
            global_step += 1
            if global_step % int(config["checkpoint"]["loss_log_every"]) == 0:
                semantic_sum = reduce_sum(losses["semantic_sum"]).item()
                semantic_count = reduce_sum(losses["semantic_count"]).item()
                if semantic_count <= 0:
                    raise RuntimeError("Semantic training reduction produced an empty domain")
                semantic = semantic_sum / semantic_count
                if is_main_process():
                    append_jsonl(
                        run_dir / "train_metrics.jsonl",
                        {
                            "step": global_step,
                            "total": semantic,
                            "semantic": semantic,
                            "generator_lr": optimizer.param_groups[0]["lr"],
                        },
                    )
            if global_step % int(config["checkpoint"]["checkpoint_every"]) == 0:
                barrier()
                results = evaluate_semantic_dev_val(
                    model, ema, criterion, dev_loader, val_loader, device
                )
                for split in ("dev", "val"):
                    validate_evaluation_cardinality(
                        results[split]["metrics"], int(config["evaluation"][f"{split}_samples"])
                    )
                new_best, improved = update_best_semantic(
                    best_records, global_step, results["dev"]["metrics"]
                )
                rng_state = all_rank_rng_state(rank, world_size)
                if is_main_process():
                    append_jsonl(
                        run_dir / "dev_metrics.jsonl",
                        evaluation_record(global_step, results["dev"]),
                    )
                    append_jsonl(
                        run_dir / "val_metrics.jsonl",
                        evaluation_record(global_step, results["val"]),
                    )
                    render_semantic_artifacts(run_dir)
                    if results["dev"]["visual"] is not None:
                        save_semantic_visualization(
                            run_dir / "visuals" / f"step_{global_step:05d}.png",
                            *results["dev"]["visual"],
                        )
                    serializable = {
                        split: {"losses": value["losses"], "metrics": value["metrics"]}
                        for split, value in results.items()
                    }
                    atomic_torch_save(
                        build_latest_payload(
                            model,
                            ema,
                            optimizer,
                            scheduler,
                            scaler,
                            global_step,
                            {"epoch": data_epoch, "batch": batch_cursor},
                            new_best,
                            config,
                            manifest_hashes,
                            identity,
                            serializable,
                            adversarial_state=None,
                            rng_state=rng_state,
                        ),
                        run_dir / "latest.pt",
                    )
                    if improved:
                        atomic_torch_save(
                            build_inference_payload(
                                model, ema, global_step, config, manifest_hashes, identity, serializable
                            ),
                            run_dir / "best_semantic.pt",
                        )
                    if global_step % int(config["checkpoint"]["milestone_every"]) == 0:
                        atomic_torch_save(
                            build_inference_payload(
                                model, ema, global_step, config, manifest_hashes, identity, serializable
                            ),
                            run_dir / "milestones" / f"step_{global_step:05d}.pt",
                        )
                best_records = new_best
                barrier()
                model.train()
            if global_step >= total_steps:
                break
        else:
            data_epoch += 1
            batch_cursor = 0
            pending.clear()
            continue
        if global_step >= total_steps:
            break
    cleanup_distributed()


if __name__ == "__main__":
    main()
