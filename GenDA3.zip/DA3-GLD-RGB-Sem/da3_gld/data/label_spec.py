"""Validated source-to-train semantic taxonomy mappings."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
import torch


@dataclass(frozen=True)
class SemanticLabelSpec:
    """Map confirmed source IDs to the ten semantic train IDs."""

    source_to_train: dict[int, int]
    ignore_ids: frozenset[int]
    classes: int
    ignore_index: int = -1

    @classmethod
    def from_json(cls, path: str | Path) -> "SemanticLabelSpec":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if raw.get("status") != "CONFIRMED":
            raise ValueError(
                f"Semantic mapping {path} has status={raw.get('status')!r}; audit and set status to CONFIRMED first."
            )
        try:
            classes = int(raw["classes"])
            source_to_train = {int(source): int(target) for source, target in raw["source_to_train"].items()}
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError(
                f"{path} must contain classes and a source_to_train object with integer IDs"
            ) from error
        ignore_index = int(raw.get("ignore_index", -1))
        ignore_ids = frozenset(int(value) for value in raw.get("ignore_ids", []))
        invalid_targets = {target for target in source_to_train.values() if target < 0 or target >= classes}
        if classes <= 0 or invalid_targets:
            raise ValueError(
                f"Invalid semantic mapping in {path}: classes={classes}, invalid targets={sorted(invalid_targets)}"
            )
        return cls(source_to_train, ignore_ids, classes, ignore_index)

    def map_tensor(self, source: torch.Tensor) -> torch.Tensor:
        output = torch.full_like(source, self.ignore_index)
        known = torch.zeros_like(source, dtype=torch.bool)
        for source_id, target_id in self.source_to_train.items():
            match = source.eq(source_id)
            output[match] = target_id
            known |= match
        for source_id in self.ignore_ids:
            known |= source.eq(source_id)
        unknown = ~known
        if unknown.any():
            unknown_ids = torch.unique(source[unknown]).tolist()
            raise ValueError(
                f"Semantic source contains IDs absent from the verified taxonomy: {unknown_ids[:16]}."
            )
        return output
