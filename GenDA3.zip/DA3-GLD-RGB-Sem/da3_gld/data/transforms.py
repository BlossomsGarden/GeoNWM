"""Normalization only; aligned supervision is never resized or warped."""

from __future__ import annotations

import torch


def imagenet_normalize(rgb_01: torch.Tensor) -> torch.Tensor:
    """ImageNet-normalize ``[...,3,H,W]`` RGB for the frozen DA3 encoder."""
    if rgb_01.shape[-3] != 3:
        raise ValueError(f"Expected RGB channel at -3, got {tuple(rgb_01.shape)}")
    mean = torch.tensor((0.485, 0.456, 0.406), dtype=rgb_01.dtype, device=rgb_01.device)
    std = torch.tensor((0.229, 0.224, 0.225), dtype=rgb_01.dtype, device=rgb_01.device)
    shape = (1,) * (rgb_01.ndim - 3) + (3, 1, 1)
    return (rgb_01 - mean.view(shape)) / std.view(shape)


def rgb_01_to_pm1(rgb_01: torch.Tensor) -> torch.Tensor:
    """Map RGB from ``[0,1]`` to ``[-1,1]``."""
    return rgb_01.mul(2.0).sub(1.0)
