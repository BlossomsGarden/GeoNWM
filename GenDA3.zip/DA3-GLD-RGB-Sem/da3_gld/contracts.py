"""Formal experiment constants shared by data, model, and checkpoint code."""

from __future__ import annotations

from collections.abc import Iterable, Mapping


CAMERA_ORDER = (
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_FRONT_LEFT",
)
FEATURE_LAYERS = (5, 7, 9, 11)
TARGET_HEIGHT = 280
TARGET_WIDTH = 728
PATCH_SIZE = 14
TOKEN_HEIGHT = 20
TOKEN_WIDTH = 52
PATCH_TOKENS = 1040
FEATURE_DIM = 1536
SEMANTIC_CLASSES = 10
MANIFEST_SCHEMA_VERSION = 1
CHECKPOINT_SCHEMA_VERSION = 4


def validate_view_names(names: Iterable[str]) -> None:
    actual = tuple(names)
    if actual != CAMERA_ORDER:
        raise ValueError(f"Expected camera order {CAMERA_ORDER}, got {actual}")


def validate_evaluation_cardinality(metrics: Mapping[str, object], expected_samples: int) -> None:
    expected_views = expected_samples * len(CAMERA_ORDER)
    if metrics.get("evaluated_samples") != expected_samples:
        raise RuntimeError(f"Expected {expected_samples} evaluated samples")
    if metrics.get("evaluated_views") != expected_views:
        raise RuntimeError(f"Expected {expected_views} evaluated views")
    per_camera = metrics.get("per_camera")
    if not isinstance(per_camera, Mapping) or tuple(per_camera) != CAMERA_ORDER:
        raise RuntimeError("Per-camera evaluation domains do not match the formal camera order")
    for camera in CAMERA_ORDER:
        domain = per_camera[camera]
        if not isinstance(domain, Mapping):
            raise RuntimeError(f"Per-camera metrics are malformed for {camera}")
        if domain.get("evaluated_samples") != expected_samples or domain.get("evaluated_views") != expected_samples:
            raise RuntimeError(f"Expected {expected_samples} evaluated views for {camera}")
