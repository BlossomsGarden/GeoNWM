"""DDP-reducible standalone RGB and semantic metrics."""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from typing import Any

import torch
import torch.distributed as dist
import torch.nn.functional as F

from da3_gld.contracts import CAMERA_ORDER, SEMANTIC_CLASSES


def structural_similarity_per_view(
    prediction: torch.Tensor,
    target: torch.Tensor,
    window_size: int = 11,
    sigma: float = 1.5,
) -> torch.Tensor:
    if prediction.shape != target.shape or prediction.ndim != 4:
        raise ValueError("SSIM inputs must share [N,C,H,W] shape")
    coordinates = torch.arange(window_size, device=prediction.device, dtype=torch.float32)
    coordinates -= (window_size - 1) / 2.0
    kernel_1d = torch.exp(-coordinates.square() / (2.0 * sigma**2))
    kernel_1d /= kernel_1d.sum()
    kernel_2d = kernel_1d[:, None] * kernel_1d[None, :]
    channels = prediction.shape[1]
    kernel = kernel_2d.expand(channels, 1, window_size, window_size)
    padding = window_size // 2

    def mean(values: torch.Tensor) -> torch.Tensor:
        values = F.pad(values, (padding,) * 4, mode="reflect")
        return F.conv2d(values, kernel, groups=channels)

    prediction = prediction.float().clamp(0.0, 1.0)
    target = target.float().clamp(0.0, 1.0)
    mean_prediction = mean(prediction)
    mean_target = mean(target)
    variance_prediction = mean(prediction.square()) - mean_prediction.square()
    variance_target = mean(target.square()) - mean_target.square()
    covariance = mean(prediction * target) - mean_prediction * mean_target
    numerator = (2.0 * mean_prediction * mean_target + 0.01**2) * (
        2.0 * covariance + 0.03**2
    )
    denominator = (mean_prediction.square() + mean_target.square() + 0.01**2) * (
        variance_prediction + variance_target + 0.03**2
    )
    return (numerator / denominator.clamp_min(1e-12)).mean(dim=(1, 2, 3))


class RGBMetricAccumulator:
    """Aggregate GLD RGB metrics globally and for each ordered camera."""

    ABS, SQ, ELEMENTS, LPIPS, LPIPS_VIEWS, SSIM, SSIM_VIEWS, SAMPLES, VIEWS = range(9)

    def __init__(
        self,
        device: torch.device,
        lpips_metric: Callable[..., torch.Tensor],
    ) -> None:
        if lpips_metric is None:
            raise ValueError("lpips_metric is required")
        self.lpips_metric = lpips_metric
        self.stats = torch.zeros((1 + len(CAMERA_ORDER), 9), dtype=torch.float64, device=device)

    @torch.no_grad()
    def _update_domain(
        self,
        domain: int,
        prediction: torch.Tensor,
        target: torch.Tensor,
        samples: int,
        views: int,
    ) -> None:
        if prediction.shape != target.shape or prediction.ndim != 4:
            raise ValueError("RGB metric inputs must share [N,C,H,W] shape")
        if not torch.isfinite(prediction).all():
            raise FloatingPointError("RGB prediction contains NaN or Inf")
        prediction = prediction.float().clamp(0.0, 1.0)
        target = target.float().clamp(0.0, 1.0)
        error = prediction - target
        lpips = self.lpips_metric(
            prediction.mul(2.0).sub(1.0),
            target.mul(2.0).sub(1.0),
            reduction="none",
        ).reshape(prediction.shape[0], -1).mean(1)
        ssim = structural_similarity_per_view(prediction, target)
        if not torch.isfinite(lpips).all() or not torch.isfinite(ssim).all():
            raise FloatingPointError("RGB metric produced NaN or Inf")
        stat = self.stats[domain]
        stat[self.ABS] += error.abs().sum(dtype=torch.float64)
        stat[self.SQ] += error.square().sum(dtype=torch.float64)
        stat[self.ELEMENTS] += error.numel()
        stat[self.LPIPS] += lpips.sum(dtype=torch.float64)
        stat[self.LPIPS_VIEWS] += lpips.numel()
        stat[self.SSIM] += ssim.sum(dtype=torch.float64)
        stat[self.SSIM_VIEWS] += ssim.numel()
        stat[self.SAMPLES] += samples
        stat[self.VIEWS] += views

    @torch.no_grad()
    def update(self, prediction: Mapping[str, torch.Tensor], batch: Mapping[str, torch.Tensor]) -> None:
        rgb = prediction["rgb"]
        target = batch["rgb_01"]
        if rgb.shape != target.shape or rgb.ndim != 5 or rgb.shape[1] != len(CAMERA_ORDER):
            raise ValueError("Expected matching six-view RGB tensors")
        batch_size, views = rgb.shape[:2]
        self._update_domain(0, rgb.flatten(0, 1), target.flatten(0, 1), batch_size, batch_size * views)
        for camera_index in range(views):
            self._update_domain(
                camera_index + 1,
                rgb[:, camera_index],
                target[:, camera_index],
                batch_size,
                batch_size,
            )

    def synchronize(self) -> None:
        if dist.is_available() and dist.is_initialized():
            dist.all_reduce(self.stats, op=dist.ReduceOp.SUM)

    def _compute_domain(self, domain: int) -> dict[str, Any]:
        stat = self.stats[domain]
        if any(stat[index].item() <= 0 for index in (self.ELEMENTS, self.LPIPS_VIEWS, self.SSIM_VIEWS)):
            raise RuntimeError(f"RGB metric domain {domain} is empty")
        mse = (stat[self.SQ] / stat[self.ELEMENTS]).item()
        return {
            "rgb_l1": (stat[self.ABS] / stat[self.ELEMENTS]).item(),
            "rgb_lpips": (stat[self.LPIPS] / stat[self.LPIPS_VIEWS]).item(),
            "rgb_psnr": -10.0 * math.log10(max(mse, 1e-12)),
            "rgb_ssim": (stat[self.SSIM] / stat[self.SSIM_VIEWS]).item(),
            "evaluated_samples": int(stat[self.SAMPLES].item()),
            "evaluated_views": int(stat[self.VIEWS].item()),
            "counts": {
                "rgb_elements": int(stat[self.ELEMENTS].item()),
                "lpips_views": int(stat[self.LPIPS_VIEWS].item()),
            },
        }

    def compute(self) -> dict[str, Any]:
        result = self._compute_domain(0)
        result["per_camera"] = {
            camera: self._compute_domain(index + 1)
            for index, camera in enumerate(CAMERA_ORDER)
        }
        return result


class SemanticMetricAccumulator:
    """Aggregate semantic confusion matrices globally and per camera."""

    def __init__(self, device: torch.device) -> None:
        domains = 1 + len(CAMERA_ORDER)
        self.confusion = torch.zeros(
            (domains, SEMANTIC_CLASSES, SEMANTIC_CLASSES),
            dtype=torch.int64,
            device=device,
        )
        self.counts = torch.zeros((domains, 2), dtype=torch.int64, device=device)

    @torch.no_grad()
    def _update_domain(
        self,
        domain: int,
        logits: torch.Tensor,
        target: torch.Tensor,
        valid: torch.Tensor,
        samples: int,
        views: int,
    ) -> None:
        if not torch.isfinite(logits[valid.unsqueeze(1).expand_as(logits)]).all():
            raise FloatingPointError("Semantic logits contain NaN or Inf on valid pixels")
        valid = valid.bool() & target.ge(0) & target.lt(SEMANTIC_CLASSES)
        if valid.any():
            predicted = logits.argmax(1)[valid]
            truth = target[valid]
            encoded = truth * SEMANTIC_CLASSES + predicted
            self.confusion[domain] += torch.bincount(
                encoded, minlength=SEMANTIC_CLASSES**2
            ).reshape(SEMANTIC_CLASSES, SEMANTIC_CLASSES)
        self.counts[domain, 0] += samples
        self.counts[domain, 1] += views

    @torch.no_grad()
    def update(self, prediction: Mapping[str, torch.Tensor], batch: Mapping[str, torch.Tensor]) -> None:
        logits = prediction["semantic_logits"]
        target = batch["semantic"]
        valid = batch["semantic_valid"]
        if logits.ndim != 5 or logits.shape[1] != len(CAMERA_ORDER):
            raise ValueError("Expected semantic logits [B,6,C,H,W]")
        batch_size, views = logits.shape[:2]
        self._update_domain(
            0,
            logits.flatten(0, 1),
            target.flatten(0, 1),
            valid.flatten(0, 1),
            batch_size,
            batch_size * views,
        )
        for camera_index in range(views):
            self._update_domain(
                camera_index + 1,
                logits[:, camera_index],
                target[:, camera_index],
                valid[:, camera_index],
                batch_size,
                batch_size,
            )

    def synchronize(self) -> None:
        if dist.is_available() and dist.is_initialized():
            dist.all_reduce(self.confusion, op=dist.ReduceOp.SUM)
            dist.all_reduce(self.counts, op=dist.ReduceOp.SUM)

    def _compute_domain(self, domain: int) -> dict[str, Any]:
        confusion = self.confusion[domain].double()
        if confusion.sum().item() <= 0:
            raise RuntimeError(f"Semantic metric domain {domain} is empty")
        intersection = confusion.diag()
        union = confusion.sum(0) + confusion.sum(1) - intersection
        valid_classes = union.gt(0)
        per_class_iou = intersection / union.clamp_min(1.0)
        return {
            "semantic_miou": per_class_iou[valid_classes].mean().item(),
            "semantic_pixel_accuracy": (intersection.sum() / confusion.sum()).item(),
            "semantic_per_class_iou": [
                value.item() if valid else None
                for value, valid in zip(per_class_iou.cpu(), valid_classes.cpu())
            ],
            "semantic_confusion": self.confusion[domain].cpu().tolist(),
            "evaluated_samples": int(self.counts[domain, 0].item()),
            "evaluated_views": int(self.counts[domain, 1].item()),
            "counts": {"semantic_pixels": int(confusion.sum().item())},
        }

    def compute(self) -> dict[str, Any]:
        result = self._compute_domain(0)
        result["per_camera"] = {
            camera: self._compute_domain(index + 1)
            for index, camera in enumerate(CAMERA_ORDER)
        }
        return result
