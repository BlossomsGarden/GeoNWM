"""GLD Stage-1 GAN adapter with the approved step boundaries."""

from __future__ import annotations

import torch
from torch import nn

from vendor.gld.disc import hinge_d_loss, vanilla_g_loss


DISCRIMINATOR_START_STEP = 4000
GENERATOR_GAN_START_STEP = 6000
DISC_WEIGHT = 0.75
MAX_ADAPTIVE_WEIGHT = 10000.0
CROP_SIZE = 224


def discriminator_enabled(step: int) -> bool:
    return step >= DISCRIMINATOR_START_STEP


def generator_gan_enabled(step: int) -> bool:
    return step >= GENERATOR_GAN_START_STEP


def calculate_adaptive_weight(
    reconstruction_loss: torch.Tensor,
    generator_gan_loss: torch.Tensor,
    last_layer: nn.Parameter,
    max_weight: float = MAX_ADAPTIVE_WEIGHT,
) -> torch.Tensor:
    reconstruction_gradient = torch.autograd.grad(
        reconstruction_loss, last_layer, retain_graph=True
    )[0]
    gan_gradient = torch.autograd.grad(generator_gan_loss, last_layer, retain_graph=True)[0]
    weight = torch.norm(reconstruction_gradient) / (torch.norm(gan_gradient) + 1e-6)
    return torch.clamp(weight, 0.0, max_weight).detach()


def random_crop_pair(first: torch.Tensor, second: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    if first.shape != second.shape or first.ndim != 4:
        raise ValueError("GAN crop inputs must share [N,C,H,W] shape")
    height, width = first.shape[-2:]
    if height < CROP_SIZE or width < CROP_SIZE:
        raise ValueError(f"GAN crop {CROP_SIZE} exceeds input {(height, width)}")
    top = int(torch.randint(0, height - CROP_SIZE + 1, ()).item())
    left = int(torch.randint(0, width - CROP_SIZE + 1, ()).item())
    slices = (..., slice(top, top + CROP_SIZE), slice(left, left + CROP_SIZE))
    return first[slices], second[slices]


def quantize_fake_for_discriminator(fake_pm1: torch.Tensor) -> torch.Tensor:
    fake = fake_pm1.clamp(-1.0, 1.0)
    return torch.round((fake + 1.0) * 127.5) / 127.5 - 1.0


__all__ = [
    "DISC_WEIGHT", "MAX_ADAPTIVE_WEIGHT", "discriminator_enabled", "generator_gan_enabled",
    "calculate_adaptive_weight", "random_crop_pair", "quantize_fake_for_discriminator",
    "hinge_d_loss", "vanilla_g_loss",
]
