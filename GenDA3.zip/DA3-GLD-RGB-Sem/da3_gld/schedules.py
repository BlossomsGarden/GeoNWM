"""Step-based learning-rate schedules shared by all formal runs."""

from __future__ import annotations

import math


def cosine_warmup_factor(
    step: int,
    warmup_steps: int,
    decay_end_step: int,
    final_lr_ratio: float,
) -> float:
    if step < 0:
        raise ValueError("step must be non-negative")
    if warmup_steps <= 0 or decay_end_step <= warmup_steps:
        raise ValueError("Require 0 < warmup_steps < decay_end_step")
    if not 0.0 < final_lr_ratio <= 1.0:
        raise ValueError("final_lr_ratio must be in (0, 1]")
    if step < warmup_steps:
        return float(step + 1) / float(warmup_steps)
    progress = min(1.0, (step - warmup_steps) / (decay_end_step - warmup_steps))
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    return final_lr_ratio + (1.0 - final_lr_ratio) * cosine


def make_cosine_warmup_scheduler(
    optimizer,
    warmup_steps: int,
    decay_end_step: int,
    final_lr_ratio: float,
):
    from torch.optim.lr_scheduler import LambdaLR

    return LambdaLR(
        optimizer,
        lambda step: cosine_warmup_factor(step, warmup_steps, decay_end_step, final_lr_ratio),
    )
