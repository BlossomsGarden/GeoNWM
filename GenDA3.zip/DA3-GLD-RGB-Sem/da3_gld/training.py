"""Shared orchestration utilities for the two standalone training entry points."""

from __future__ import annotations

from contextlib import nullcontext
from pathlib import Path
from typing import Any, Mapping

import torch
import torch.distributed as dist
from torch import nn
from torch.utils.data import DataLoader, DistributedSampler, Subset

from da3_gld.checkpointing import capture_rng_state
from da3_gld.config import load_config
from da3_gld.data.manifest import sha256_file
from da3_gld.data.nuscenes_six_view import NuScenesSixViewDataset
from da3_gld.data.subsets import load_or_create_fixed_subset
from da3_gld.distributed import DistributedEvalSampler, barrier


def resolve_runtime_config(
    args: Any,
    expected_experiment: str,
    require_discriminator: bool,
) -> dict[str, Any]:
    config = load_config(args.config, expected_experiment)
    for key in ("train_manifest", "dev_manifest", "val_manifest"):
        override = getattr(args, key)
        if override is not None:
            config["data"][key] = str(override.expanduser().resolve())
        if not config["data"].get(key):
            raise ValueError(f"Provide --{key.replace('_', '-')} or set data.{key}")
        config["data"][key] = str(Path(config["data"][key]).expanduser().resolve())
    for key in ("batch_size", "workers", "precision"):
        override = getattr(args, key)
        if override is not None:
            config["training"][key] = override
    if args.view_chunk_size is not None:
        config["model"]["view_chunk_size"] = args.view_chunk_size
    if int(config["training"]["batch_size"]) <= 0 or int(config["training"]["workers"]) < 0:
        raise ValueError("batch_size must be positive and workers must be non-negative")
    if int(config["model"]["view_chunk_size"]) <= 0 or args.gradient_accumulation <= 0:
        raise ValueError("view_chunk_size and gradient_accumulation must be positive")
    config["runtime"] = {
        "da3_model_dir": str(args.da3_model_dir.expanduser().resolve()),
        "semantic_mapping": str(args.semantic_mapping.expanduser().resolve()),
        "gradient_accumulation": int(args.gradient_accumulation),
    }
    if require_discriminator:
        checkpoint = args.lpips_checkpoint.expanduser().resolve()
        config["runtime"]["lpips_checkpoint"] = str(checkpoint)
        if args.dino_discriminator_checkpoint is not None:
            config["gan"]["discriminator_checkpoint"] = str(
                args.dino_discriminator_checkpoint.expanduser().resolve()
            )
        discriminator_checkpoint = config["gan"].get("discriminator_checkpoint")
        if not discriminator_checkpoint:
            raise ValueError("Provide --dino-discriminator-checkpoint or configure gan.discriminator_checkpoint")
        config["gan"]["discriminator_checkpoint"] = str(
            Path(discriminator_checkpoint).expanduser().resolve()
        )
    return config


def require_cuda_device(local_rank: int) -> torch.device:
    if not torch.cuda.is_available():
        raise RuntimeError("Formal DA3 training requires CUDA; CPU is reserved for synthetic tests")
    return torch.device("cuda", local_rank)


def autocast_context(device: torch.device, precision: str):
    if precision == "fp32":
        return nullcontext()
    dtype = torch.bfloat16 if precision == "bf16" else torch.float16
    return torch.autocast(device_type=device.type, dtype=dtype)


def move_batch(batch: Mapping[str, Any], device: torch.device) -> dict[str, Any]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def frozen_da3_identity(model_dir: Path) -> dict[str, Any]:
    model_dir = model_dir.expanduser().resolve()
    config_path = model_dir / "config.json"
    weights = next(
        (path for path in (model_dir / "model.safetensors", model_dir / "pytorch_model.bin") if path.is_file()),
        None,
    )
    if not config_path.is_file() or weights is None:
        raise FileNotFoundError(f"DA3 directory must contain config.json and model weights: {model_dir}")
    return {
        "path": str(model_dir),
        "config_sha256": sha256_file(config_path),
        "weights_file": weights.name,
        "weights_sha256": sha256_file(weights),
    }


def frozen_file_identity(path: str | Path) -> dict[str, Any]:
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Frozen dependency not found: {path}")
    return {"path": str(path), "sha256": sha256_file(path)}


def all_rank_rng_state(rank: int, world_size: int) -> dict[str, Any]:
    local = capture_rng_state()
    if world_size == 1:
        return local
    gathered: list[Any] = [None] * world_size
    dist.all_gather_object(gathered, local)
    return {"world_size": world_size, "per_rank": gathered}


def make_dataloaders(
    config: Mapping[str, Any],
    semantic_mapping: Path,
    run_dir: Path,
    rank: int,
    world_size: int,
) -> tuple[DataLoader, DataLoader, DataLoader, DistributedSampler | None, dict[str, str]]:
    datasets = {
        split: NuScenesSixViewDataset(config["data"][f"{split}_manifest"], split, semantic_mapping)
        for split in ("train", "dev", "val")
    }
    manifest_hashes = {
        split: sha256_file(Path(config["data"][f"{split}_manifest"])) for split in datasets
    }
    subset_indices = {
        split: load_or_create_fixed_subset(
            config["data"][f"{split}_manifest"],
            datasets[split].records,
            run_dir / f"{split}_subset.json",
            int(config["evaluation"][f"{split}_samples"]),
            int(config["evaluation"]["subset_seed"]),
            rank,
            barrier,
        )
        for split in ("dev", "val")
    }
    train_sampler = (
        DistributedSampler(datasets["train"], num_replicas=world_size, rank=rank, shuffle=True)
        if world_size > 1
        else None
    )
    common = {
        "batch_size": int(config["training"]["batch_size"]),
        "num_workers": int(config["training"]["workers"]),
        "pin_memory": True,
        "persistent_workers": int(config["training"]["workers"]) > 0,
    }
    train_loader = DataLoader(
        datasets["train"],
        sampler=train_sampler,
        shuffle=train_sampler is None,
        drop_last=True,
        **common,
    )
    evaluation = []
    for split in ("dev", "val"):
        subset = Subset(datasets[split], subset_indices[split])
        sampler = DistributedEvalSampler(subset, rank, world_size)
        evaluation.append(DataLoader(subset, sampler=sampler, shuffle=False, drop_last=False, **common))
    return train_loader, evaluation[0], evaluation[1], train_sampler, manifest_hashes


def evaluation_record(step: int, result: Mapping[str, Any]) -> dict[str, Any]:
    return {"step": step, **result["losses"], **result["metrics"]}


def discriminator_module(discriminator: nn.Module) -> nn.Module:
    return discriminator.module if hasattr(discriminator, "module") else discriminator


def discriminator_checkpoint_state(
    discriminator: nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
    update_count: int,
) -> dict[str, Any]:
    module = discriminator_module(discriminator)
    return {
        "heads": {key: value.detach().cpu().clone() for key, value in module.heads.state_dict().items()},
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict(),
        "update_count": int(update_count),
    }


def restore_discriminator_checkpoint(
    state: Mapping[str, Any],
    discriminator: nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
) -> int:
    if set(state) != {"heads", "optimizer", "scheduler", "update_count"}:
        raise ValueError("Adversarial checkpoint schema is incomplete or contains unknown fields")
    discriminator_module(discriminator).heads.load_state_dict(state["heads"], strict=True)
    optimizer.load_state_dict(state["optimizer"])
    scheduler.load_state_dict(state["scheduler"])
    return int(state["update_count"])


def optimizer_step(
    loss: torch.Tensor,
    optimizer: torch.optim.Optimizer,
    scaler: Any,
) -> bool:
    if scaler is not None and scaler.is_enabled():
        previous_scale = scaler.get_scale()
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        return scaler.get_scale() >= previous_scale
    loss.backward()
    optimizer.step()
    return True
