"""Standalone RGB and semantic upper-bound objectives."""

from __future__ import annotations

import hashlib
from pathlib import Path

import torch
import torch.nn.functional as F
from torch import nn


def _require_finite(name: str, values: torch.Tensor, mask: torch.Tensor) -> None:
    expanded = mask
    while expanded.ndim < values.ndim:
        expanded = expanded.unsqueeze(-3)
    expanded = expanded.expand_as(values)
    if not torch.isfinite(values[expanded]).all():
        raise FloatingPointError(f"{name} contains NaN or Inf on valid target pixels")


class PerceptualLoss(nn.Module):
    """Lazy wrapper around the vendored GLD LPIPS implementation."""

    LPIPS_VGG_MD5 = "d507d7349b931f0638a25a48a722f98a"

    def __init__(
        self,
        enabled: bool = True,
        checkpoint_path: str | Path | None = None,
    ) -> None:
        super().__init__()
        self.enabled = enabled
        self.checkpoint_path = Path(checkpoint_path).expanduser().resolve() if checkpoint_path else None
        self._metric: nn.Module | None = None

    def metric(self, device: torch.device) -> nn.Module:
        if self._metric is None:
            from vendor.gld.disc import LPIPS
            import vendor.gld.disc.lpips as lpips_module

            if self.checkpoint_path is None or not self.checkpoint_path.is_file():
                raise FileNotFoundError(f"GLD LPIPS checkpoint not found: {self.checkpoint_path}")
            digest = hashlib.md5(self.checkpoint_path.read_bytes()).hexdigest()
            if digest != self.LPIPS_VGG_MD5:
                raise ValueError(
                    f"GLD LPIPS checkpoint MD5 must be {self.LPIPS_VGG_MD5}, got {digest}"
                )
            original_resolver = lpips_module.get_ckpt_path
            try:
                lpips_module.get_ckpt_path = lambda *_args, **_kwargs: str(self.checkpoint_path)
                self._metric = LPIPS().eval().to(device)
            finally:
                lpips_module.get_ckpt_path = original_resolver
            self._metric.requires_grad_(False)
        return self._metric

    def forward_stats(
        self,
        prediction_01: torch.Tensor,
        target_01: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        views = prediction_01.flatten(0, 1)
        count = prediction_01.new_tensor(float(views.shape[0]), dtype=torch.float32)
        if not self.enabled:
            return prediction_01.new_zeros(()), count
        values = self.metric(prediction_01.device)(
            views.mul(2.0).sub(1.0),
            target_01.flatten(0, 1).mul(2.0).sub(1.0),
            reduction="none",
        ).flatten()
        return values.sum(), count


class RGBReconstructionLoss(nn.Module):
    """GLD Stage-1 reconstruction numerator: one L1 plus one LPIPS."""

    def __init__(
        self,
        use_lpips: bool = True,
        lpips_checkpoint: str | Path | None = None,
    ) -> None:
        super().__init__()
        self.perceptual = PerceptualLoss(
            enabled=use_lpips,
            checkpoint_path=lpips_checkpoint,
        )

    def forward(
        self,
        prediction: dict[str, torch.Tensor],
        batch: dict[str, torch.Tensor],
    ) -> dict[str, torch.Tensor]:
        rgb = prediction["rgb"]
        target = batch["rgb_01"]
        if rgb.shape != target.shape or rgb.ndim != 5:
            raise ValueError("RGB prediction and target must share [B,V,3,H,W] shape")
        _require_finite("rgb", rgb, torch.ones_like(target, dtype=torch.bool))
        l1_values = (rgb - target).abs()
        l1_sum = l1_values.sum()
        l1_count = rgb.new_tensor(float(l1_values.numel()), dtype=torch.float32)
        l1 = l1_sum / l1_count
        perceptual_sum, perceptual_count = self.perceptual.forward_stats(rgb, target)
        perceptual = perceptual_sum / perceptual_count.clamp_min(1.0)
        total = l1 + perceptual
        return {
            "total": total,
            "rgb_objective": total,
            "rgb": l1.detach(),
            "perceptual": perceptual.detach(),
            "rgb_sum": l1_sum.detach(),
            "rgb_count": l1_count.detach(),
            "perceptual_sum": perceptual_sum.detach(),
            "perceptual_count": perceptual_count.detach(),
        }


class SemanticCrossEntropyLoss(nn.Module):
    """Standalone class-weighted CE with the label-side validity mask."""

    def __init__(
        self,
        class_weights: torch.Tensor,
        ignore_index: int = -1,
    ) -> None:
        super().__init__()
        if class_weights.shape != (10,) or not torch.isfinite(class_weights).all():
            raise ValueError("Semantic class weights must contain ten finite values")
        if (class_weights <= 0).any():
            raise ValueError("Semantic class weights must be positive")
        self.register_buffer("class_weights", class_weights.float())
        self.ignore_index = int(ignore_index)

    def forward(
        self,
        prediction: dict[str, torch.Tensor],
        batch: dict[str, torch.Tensor],
    ) -> dict[str, torch.Tensor]:
        logits = prediction["semantic_logits"]
        target = batch["semantic"].long()
        valid = batch["semantic_valid"].bool()
        if logits.ndim != 5 or logits.shape[:2] != target.shape[:2]:
            raise ValueError("Semantic logits and target must share batch and view dimensions")
        if logits.shape[2] != self.class_weights.numel() or logits.shape[-2:] != target.shape[-2:]:
            raise ValueError("Semantic logits have an invalid class or spatial shape")
        _require_finite("semantic_logits", logits, valid.unsqueeze(2))
        if not valid.any():
            raise RuntimeError("Semantic loss domain has no valid pixels")
        masked_target = target.masked_fill(~valid, self.ignore_index)
        valid_classes = target[valid]
        weighted_count = self.class_weights[valid_classes].sum().float()
        weighted_sum = F.cross_entropy(
            logits.flatten(0, 1),
            masked_target.flatten(0, 1),
            weight=self.class_weights,
            ignore_index=self.ignore_index,
            reduction="sum",
        )
        loss = weighted_sum / weighted_count.clamp_min(1.0)
        return {
            "total": loss,
            "semantic": loss.detach(),
            "semantic_sum": weighted_sum.detach(),
            "semantic_count": weighted_count.detach(),
        }
