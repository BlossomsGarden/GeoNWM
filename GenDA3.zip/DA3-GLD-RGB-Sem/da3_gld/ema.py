"""EMA over named trainable generator parameters only."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any

import torch
from torch import nn


def _trainable_parameters(model: nn.Module) -> dict[str, nn.Parameter]:
    return {name: parameter for name, parameter in model.named_parameters() if parameter.requires_grad}


class ExponentialMovingAverage:
    def __init__(self, model: nn.Module, decay: float) -> None:
        if not 0.0 < decay < 1.0:
            raise ValueError("EMA decay must be in (0, 1)")
        parameters = _trainable_parameters(model)
        if not parameters:
            raise ValueError("EMA requires at least one trainable parameter")
        self.decay = float(decay)
        self.shadow = {
            name: parameter.detach().float().clone() for name, parameter in parameters.items()
        }

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(self.shadow)

    def _validated_parameters(self, model: nn.Module) -> dict[str, nn.Parameter]:
        parameters = _trainable_parameters(model)
        if set(parameters) != set(self.shadow):
            missing = sorted(set(self.shadow) - set(parameters))
            unexpected = sorted(set(parameters) - set(self.shadow))
            raise ValueError(f"EMA parameter names changed; missing={missing}, unexpected={unexpected}")
        return parameters

    @torch.no_grad()
    def update(self, model: nn.Module) -> None:
        parameters = self._validated_parameters(model)
        for name, parameter in parameters.items():
            value = parameter.detach().to(device=self.shadow[name].device, dtype=torch.float32)
            self.shadow[name].mul_(self.decay).add_(value, alpha=1.0 - self.decay)

    def state_dict(self) -> dict[str, Any]:
        return {
            "decay": self.decay,
            "shadow": {name: value.detach().cpu().clone() for name, value in self.shadow.items()},
        }

    def load_state_dict(self, state: dict[str, Any], model: nn.Module) -> None:
        if set(state) != {"decay", "shadow"} or not isinstance(state["shadow"], dict):
            raise ValueError("Invalid EMA state schema")
        decay = float(state["decay"])
        if decay != self.decay:
            raise ValueError(f"EMA decay mismatch: checkpoint={decay}, configured={self.decay}")
        parameters = _trainable_parameters(model)
        if set(parameters) != set(state["shadow"]):
            raise ValueError("EMA checkpoint parameter names do not match the trainable model")
        self.shadow = {
            name: torch.as_tensor(state["shadow"][name], dtype=torch.float32, device=parameter.device).clone()
            for name, parameter in parameters.items()
        }

    @contextmanager
    def average_parameters(self, model: nn.Module):
        parameters = self._validated_parameters(model)
        backups: dict[str, torch.Tensor] = {}
        try:
            with torch.no_grad():
                for name, parameter in parameters.items():
                    backups[name] = parameter.detach().clone()
                    parameter.copy_(self.shadow[name].to(device=parameter.device, dtype=parameter.dtype))
            yield model
        finally:
            with torch.no_grad():
                for name, parameter in parameters.items():
                    parameter.copy_(backups[name])
