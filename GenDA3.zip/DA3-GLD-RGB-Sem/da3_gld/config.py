"""Strict configuration loading for the two standalone upper-bound trainers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from da3_gld.contracts import (
    CAMERA_ORDER,
    CHECKPOINT_SCHEMA_VERSION,
    FEATURE_LAYERS,
    SEMANTIC_CLASSES,
    TARGET_HEIGHT,
    TARGET_WIDTH,
)


RGB_EXPERIMENT = "da3_gld_rgb_upper"
SEMANTIC_EXPERIMENT = "da3_gld_semantic_upper"


def load_config(path: str | Path, expected_experiment: str) -> dict[str, Any]:
    path = Path(path)
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(config, dict):
        raise ValueError("Config root must be a mapping")
    if expected_experiment not in {RGB_EXPERIMENT, SEMANTIC_EXPERIMENT}:
        raise ValueError(f"Unknown standalone experiment {expected_experiment!r}")
    experiment = config.get("experiment", {})
    if experiment.get("type") != expected_experiment:
        raise ValueError(f"Expected experiment.type={expected_experiment}")
    if experiment.get("schema_version") != CHECKPOINT_SCHEMA_VERSION:
        raise ValueError(f"Formal schema_version must be {CHECKPOINT_SCHEMA_VERSION}")
    data = config.get("data", {})
    model = config.get("model", {})
    training = config.get("training", {})
    evaluation = config.get("evaluation", {})
    checkpoint = config.get("checkpoint", {})
    fixed = {
        "camera_order": (data.get("camera_order"), list(CAMERA_ORDER)),
        "height": (data.get("height"), TARGET_HEIGHT),
        "width": (data.get("width"), TARGET_WIDTH),
        "feature_layers": (model.get("feature_layers"), list(FEATURE_LAYERS)),
        "steps": (training.get("steps"), 40000),
        "warmup_steps": (training.get("warmup_steps"), 1000),
        "base_lr": (float(training.get("base_lr", -1)), 2e-4),
        "final_lr": (float(training.get("final_lr", -1)), 2e-5),
        "weight_decay": (float(training.get("weight_decay", -1)), 0.0),
        "ema_decay": (training.get("ema_decay"), 0.9978),
        "dev_samples": (evaluation.get("dev_samples"), 64),
        "val_samples": (evaluation.get("val_samples"), 64),
        "checkpoint_every": (checkpoint.get("checkpoint_every"), 1000),
        "milestone_every": (checkpoint.get("milestone_every"), 5000),
        "loss_log_every": (checkpoint.get("loss_log_every"), 10),
    }
    for name, (actual, expected) in fixed.items():
        if actual != expected:
            raise ValueError(f"Formal {name} must be {expected!r}, got {actual!r}")
    if int(training.get("batch_size", 0)) <= 0 or int(training.get("workers", -1)) < 0:
        raise ValueError("batch_size must be positive and workers must be non-negative")
    if int(model.get("view_chunk_size", 0)) <= 0:
        raise ValueError("view_chunk_size must be positive")
    if training.get("precision") not in {"bf16", "fp16", "fp32"}:
        raise ValueError("precision must be bf16, fp16, or fp32")
    if expected_experiment == RGB_EXPERIMENT:
        rgb_fixed = {
            "raw_feature_dim": (model.get("raw_feature_dim"), 1536),
            "concat_dim": (model.get("concat_dim"), 6144),
            "decoder_hidden_size": (model.get("decoder_hidden_size"), 1152),
            "decoder_layers": (model.get("decoder_layers"), 28),
            "decoder_heads": (model.get("decoder_heads"), 16),
            "decoder_intermediate_size": (model.get("decoder_intermediate_size"), 4096),
        }
        gan = config.get("gan", {})
        gan_fixed = {
            "discriminator_start_step": (gan.get("discriminator_start_step"), 4000),
            "generator_start_step": (gan.get("generator_start_step"), 6000),
            "disc_weight": (float(gan.get("disc_weight", -1)), 0.75),
            "max_adaptive_weight": (float(gan.get("max_adaptive_weight", -1)), 10000.0),
            "disc_updates_per_generator": (gan.get("disc_updates_per_generator"), 1),
            "crop_size": (gan.get("crop_size"), 224),
            "augment_probability": (float(gan.get("augment_probability", -1)), 1.0),
            "cutout": (float(gan.get("cutout", -1)), 0.0),
            "blur_warmup": (gan.get("blur_warmup"), False),
            "disc_warmup_updates": (gan.get("scheduler", {}).get("warmup_updates"), 1000),
            "disc_decay_end_updates": (gan.get("scheduler", {}).get("decay_end_updates"), 16000),
        }
        for name, (actual, expected) in {**rgb_fixed, **gan_fixed}.items():
            if actual != expected:
                raise ValueError(f"Formal {name} must be {expected!r}, got {actual!r}")
    else:
        semantic_fixed = {
            "feature_dim": (model.get("feature_dim"), 1536),
            "projections": (model.get("projections"), [96, 192, 384, 768]),
            "dpt_features": (model.get("dpt_features"), 128),
            "semantic_classes": (model.get("semantic_classes"), SEMANTIC_CLASSES),
        }
        for name, (actual, expected) in semantic_fixed.items():
            if actual != expected:
                raise ValueError(f"Formal {name} must be {expected!r}, got {actual!r}")
    return config


def write_resolved_config(config: dict[str, Any], run_dir: str | Path) -> None:
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "config_resolved.yaml").write_text(
        yaml.safe_dump(config, sort_keys=False), encoding="utf-8"
    )
