"""Uncompressed DA3 RGB and semantic decoding upper bounds."""

from .contracts import CAMERA_ORDER, FEATURE_LAYERS, TARGET_HEIGHT, TARGET_WIDTH

__all__ = ["CAMERA_ORDER", "FEATURE_LAYERS", "TARGET_HEIGHT", "TARGET_WIDTH"]
