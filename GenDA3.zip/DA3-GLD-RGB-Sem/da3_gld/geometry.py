"""Camera-frame geometry for already aligned six-view tensors."""

from __future__ import annotations

import torch


def flatten_views(tensor: torch.Tensor) -> torch.Tensor:
    """Flatten leading batch and camera-view dimensions."""
    if tensor.ndim < 2:
        raise ValueError(f"Expected batch and view dimensions, got {tuple(tensor.shape)}")
    return tensor.flatten(0, 1)


def backproject_depth(depth: torch.Tensor, intrinsics: torch.Tensor) -> torch.Tensor:
    """Backproject ``[B,1,H,W]`` metric depth to camera ``[B,3,H,W]`` points."""
    if depth.ndim != 4 or depth.shape[1] != 1:
        raise ValueError(f"Expected depth [B,1,H,W], got {tuple(depth.shape)}")
    if intrinsics.shape != (depth.shape[0], 3, 3):
        raise ValueError(f"Expected intrinsics [B,3,3], got {tuple(intrinsics.shape)}")
    depth = depth.float()
    intrinsics = intrinsics.float()
    batch, _, height, width = depth.shape
    yy, xx = torch.meshgrid(
        torch.arange(height, device=depth.device, dtype=depth.dtype),
        torch.arange(width, device=depth.device, dtype=depth.dtype),
        indexing="ij",
    )
    pixels = torch.stack((xx, yy, torch.ones_like(xx)), dim=0).reshape(1, 3, -1)
    rays = torch.linalg.solve(intrinsics, pixels.expand(batch, -1, -1))
    return rays.reshape(batch, 3, height, width) * depth


def camera_point_errors(
    prediction: torch.Tensor,
    target: torch.Tensor,
    valid_mask: torch.Tensor,
) -> dict[str, torch.Tensor]:
    """Return camera-view mean 3D, axial-z, and lateral-xy errors."""
    if prediction.shape != target.shape or prediction.ndim != 4 or prediction.shape[1] != 3:
        raise ValueError("Prediction and target must both be [B,3,H,W]")
    if valid_mask.shape != (prediction.shape[0], 1, *prediction.shape[-2:]):
        raise ValueError("valid_mask must be [B,1,H,W]")
    valid = valid_mask.squeeze(1).bool()
    values: dict[str, list[torch.Tensor]] = {"l2": [], "z": [], "xy": []}
    for pred, truth, mask in zip(prediction, target, valid):
        if not mask.any():
            zero = pred.new_zeros(())
            for key in values:
                values[key].append(zero)
            continue
        diff = pred[:, mask] - truth[:, mask]
        values["l2"].append(torch.linalg.vector_norm(diff, dim=0).mean())
        values["z"].append(diff[2].abs().mean())
        values["xy"].append(torch.linalg.vector_norm(diff[:2], dim=0).mean())
    return {key: torch.stack(items) for key, items in values.items()}
