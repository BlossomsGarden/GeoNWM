"""Fatal-on-error logging, curves, confusion matrices, and fixed-view visuals."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

import numpy as np


def append_jsonl(path: str | Path, record: Mapping[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(dict(record), ensure_ascii=False, separators=(",", ":")) + "\n")


def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def _pyplot():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    return plt


def _plot_scalars(records, keys, output: Path, title: str) -> None:
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(10, 5))
    for key in keys:
        points = [(int(row["step"]), float(row[key])) for row in records if key in row]
        if points:
            axis.plot([item[0] for item in points], [item[1] for item in points], label=key)
    axis.set_xlabel("step")
    axis.set_title(title)
    axis.grid(alpha=0.25)
    if axis.lines:
        axis.legend(ncol=2)
    figure.tight_layout()
    figure.savefig(output, dpi=150)
    plt.close(figure)


def _require_logs(run_dir: Path) -> tuple[list[dict[str, Any]], ...]:
    logs = tuple(
        read_jsonl(run_dir / name)
        for name in ("train_metrics.jsonl", "dev_metrics.jsonl", "val_metrics.jsonl")
    )
    if any(not rows for rows in logs):
        raise RuntimeError("Curve rendering requires non-empty train/dev/val JSONL logs")
    return logs


def render_rgb_artifacts(run_dir: str | Path) -> None:
    run_dir = Path(run_dir)
    train, dev, val = _require_logs(run_dir)
    _plot_scalars(
        train,
        ("total", "rgb", "perceptual", "generator_gan", "gan_term", "disc_loss"),
        run_dir / "loss_curves.png",
        "Standalone RGB training losses",
    )
    metrics = ("rgb_l1", "rgb_lpips", "rgb_psnr", "rgb_ssim")
    _plot_scalars(dev, metrics, run_dir / "metric_curves_dev.png", "Dev RGB metrics")
    _plot_scalars(val, metrics, run_dir / "metric_curves_val.png", "Val RGB metrics")


def _plot_iou(records, output: Path, title: str) -> None:
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(10, 5))
    for class_index in range(10):
        points = []
        for row in records:
            values = row.get("semantic_per_class_iou")
            if isinstance(values, list) and values[class_index] is not None:
                points.append((int(row["step"]), float(values[class_index])))
        if points:
            axis.plot([item[0] for item in points], [item[1] for item in points], label=str(class_index))
    axis.set_xlabel("step")
    axis.set_ylabel("IoU")
    axis.set_title(title)
    axis.grid(alpha=0.25)
    if axis.lines:
        axis.legend(ncol=5, title="class")
    figure.tight_layout()
    figure.savefig(output, dpi=150)
    plt.close(figure)


def _plot_confusion(record: Mapping[str, Any], output: Path) -> None:
    confusion = np.asarray(record["semantic_confusion"], dtype=np.float64)
    if confusion.shape != (10, 10):
        raise ValueError(f"Semantic confusion must be 10x10, got {confusion.shape}")
    rows = confusion.sum(1, keepdims=True)
    normalized = np.divide(confusion, rows, out=np.zeros_like(confusion), where=rows > 0)
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(7, 6))
    image = axis.imshow(normalized, vmin=0.0, vmax=1.0, cmap="viridis")
    axis.set_xlabel("predicted")
    axis.set_ylabel("target")
    axis.set_xticks(range(10))
    axis.set_yticks(range(10))
    figure.colorbar(image, ax=axis)
    figure.tight_layout()
    figure.savefig(output, dpi=150)
    plt.close(figure)


def render_semantic_artifacts(run_dir: str | Path) -> None:
    run_dir = Path(run_dir)
    train, dev, val = _require_logs(run_dir)
    _plot_scalars(train, ("total", "semantic"), run_dir / "loss_curves.png", "Semantic training loss")
    metrics = ("semantic_miou", "semantic_pixel_accuracy")
    _plot_scalars(dev, metrics, run_dir / "metric_curves_dev.png", "Dev semantic metrics")
    _plot_scalars(val, metrics, run_dir / "metric_curves_val.png", "Val semantic metrics")
    _plot_iou(dev, run_dir / "semantic_iou_curves_dev.png", "Dev semantic IoU")
    _plot_iou(val, run_dir / "semantic_iou_curves_val.png", "Val semantic IoU")
    _plot_confusion(dev[-1], run_dir / "semantic_confusion_latest.png")


def save_rgb_visualization(
    path: str | Path,
    batch: Mapping[str, Any],
    prediction: Mapping[str, Any],
) -> None:
    target = batch["rgb_01"][0, 0].permute(1, 2, 0).numpy()
    reconstructed = prediction["rgb"][0, 0].permute(1, 2, 0).numpy()
    plt = _pyplot()
    figure, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].imshow(np.clip(target, 0.0, 1.0))
    axes[1].imshow(np.clip(reconstructed, 0.0, 1.0))
    for axis in axes:
        axis.axis("off")
    figure.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(path, dpi=150)
    plt.close(figure)


def save_semantic_visualization(
    path: str | Path,
    batch: Mapping[str, Any],
    prediction: Mapping[str, Any],
) -> None:
    target = batch["semantic"][0, 0].numpy()
    predicted = prediction["semantic_logits"][0, 0].argmax(0).numpy()
    plt = _pyplot()
    figure, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].imshow(target, vmin=-1, vmax=9, cmap="tab10")
    axes[1].imshow(predicted, vmin=0, vmax=9, cmap="tab10")
    for axis in axes:
        axis.axis("off")
    figure.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(path, dpi=150)
    plt.close(figure)
