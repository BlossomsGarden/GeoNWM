"""EMA evaluation and dev-only best selection for standalone Heads."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from typing import Any

import torch
import torch.distributed as dist
from torch import nn

from da3_gld.checkpointing import unwrap_model
from da3_gld.ema import ExponentialMovingAverage
from da3_gld.metrics import RGBMetricAccumulator, SemanticMetricAccumulator


def _to_device(batch: Mapping[str, Any], device: torch.device) -> dict[str, Any]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def _cpu_visual(
    batch: Mapping[str, Any],
    prediction: Mapping[str, torch.Tensor],
) -> tuple[dict[str, Any], dict[str, torch.Tensor]]:
    return (
        {
            key: value.detach().cpu() if isinstance(value, torch.Tensor) else value
            for key, value in batch.items()
        },
        {key: value.detach().cpu() for key, value in prediction.items()},
    )


@torch.no_grad()
def _evaluate_rgb(
    model: nn.Module,
    criterion: nn.Module,
    lpips_metric: Callable[..., torch.Tensor],
    loader: Iterable[Mapping[str, Any]],
    device: torch.device,
) -> dict[str, Any]:
    model.eval()
    accumulator = RGBMetricAccumulator(device, lpips_metric)
    sums = torch.zeros(2, dtype=torch.float64, device=device)
    counts = torch.zeros(2, dtype=torch.float64, device=device)
    visual = None
    for raw_batch in loader:
        batch = _to_device(raw_batch, device)
        prediction = model(batch["image_da3"])
        losses = criterion(prediction, batch)
        sums += torch.stack((losses["rgb_sum"].double(), losses["perceptual_sum"].double()))
        counts += torch.stack((losses["rgb_count"].double(), losses["perceptual_count"].double()))
        accumulator.update(prediction, batch)
        if visual is None:
            visual = _cpu_visual(batch, prediction)
    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(sums, op=dist.ReduceOp.SUM)
        dist.all_reduce(counts, op=dist.ReduceOp.SUM)
    if (counts <= 0).any():
        raise RuntimeError("RGB evaluation produced an empty loss domain")
    losses = {
        "rgb": (sums[0] / counts[0]).item(),
        "perceptual": (sums[1] / counts[1]).item(),
    }
    losses["total"] = losses["rgb"] + losses["perceptual"]
    accumulator.synchronize()
    return {"losses": losses, "metrics": accumulator.compute(), "visual": visual}


@torch.no_grad()
def _evaluate_semantic(
    model: nn.Module,
    criterion: nn.Module,
    loader: Iterable[Mapping[str, Any]],
    device: torch.device,
) -> dict[str, Any]:
    model.eval()
    accumulator = SemanticMetricAccumulator(device)
    weighted_sum = torch.zeros((), dtype=torch.float64, device=device)
    weighted_count = torch.zeros((), dtype=torch.float64, device=device)
    visual = None
    for raw_batch in loader:
        batch = _to_device(raw_batch, device)
        prediction = model(
            batch["image_da3"], batch["intrinsics"], batch["world_to_camera"]
        )
        losses = criterion(prediction, batch)
        weighted_sum += losses["semantic_sum"].double()
        weighted_count += losses["semantic_count"].double()
        accumulator.update(prediction, batch)
        if visual is None:
            visual = _cpu_visual(batch, prediction)
    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(weighted_sum, op=dist.ReduceOp.SUM)
        dist.all_reduce(weighted_count, op=dist.ReduceOp.SUM)
    if weighted_count.item() <= 0:
        raise RuntimeError("Semantic evaluation produced an empty loss domain")
    semantic = (weighted_sum / weighted_count).item()
    accumulator.synchronize()
    return {
        "losses": {"total": semantic, "semantic": semantic},
        "metrics": accumulator.compute(),
        "visual": visual,
    }


def evaluate_rgb_dev_val(
    model: nn.Module,
    ema: ExponentialMovingAverage,
    criterion: nn.Module,
    lpips_metric: Callable[..., torch.Tensor],
    dev_loader: Iterable[Mapping[str, Any]],
    val_loader: Iterable[Mapping[str, Any]],
    device: torch.device,
) -> dict[str, Any]:
    was_training = model.training
    try:
        with ema.average_parameters(unwrap_model(model)):
            return {
                "dev": _evaluate_rgb(model, criterion, lpips_metric, dev_loader, device),
                "val": _evaluate_rgb(model, criterion, lpips_metric, val_loader, device),
            }
    finally:
        model.train(was_training)


def evaluate_semantic_dev_val(
    model: nn.Module,
    ema: ExponentialMovingAverage,
    criterion: nn.Module,
    dev_loader: Iterable[Mapping[str, Any]],
    val_loader: Iterable[Mapping[str, Any]],
    device: torch.device,
) -> dict[str, Any]:
    was_training = model.training
    try:
        with ema.average_parameters(unwrap_model(model)):
            return {
                "dev": _evaluate_semantic(model, criterion, dev_loader, device),
                "val": _evaluate_semantic(model, criterion, val_loader, device),
            }
    finally:
        model.train(was_training)


def update_best_rgb(
    best_records: Mapping[str, Any],
    step: int,
    dev_metrics: Mapping[str, Any],
) -> tuple[dict[str, Any], bool]:
    value = float(dev_metrics["rgb_l1"]) + float(dev_metrics["rgb_lpips"])
    updated = {name: dict(record) for name, record in best_records.items()}
    previous = updated.get("best_rgb")
    improved = previous is None or value < float(previous["value"])
    if improved:
        updated["best_rgb"] = {"step": step, "value": value, "mode": "min"}
    return updated, improved


def update_best_semantic(
    best_records: Mapping[str, Any],
    step: int,
    dev_metrics: Mapping[str, Any],
) -> tuple[dict[str, Any], bool]:
    value = float(dev_metrics["semantic_miou"])
    updated = {name: dict(record) for name, record in best_records.items()}
    previous = updated.get("best_semantic")
    improved = previous is None or value > float(previous["value"])
    if improved:
        updated["best_semantic"] = {"step": step, "value": value, "mode": "max"}
    return updated, improved
