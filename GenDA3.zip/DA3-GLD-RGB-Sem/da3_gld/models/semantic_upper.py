"""Geometry-aware DA3 feature list with a standalone semantic DPT Head."""

from __future__ import annotations

from pathlib import Path

import torch
from torch import nn

from da3_gld.contracts import FEATURE_LAYERS
from da3_gld.models.da3_frozen import DA3FrozenEncoder
from da3_gld.models.semantic_dpt import SemanticDPTHead


class SemanticUpperBound(nn.Module):
    def __init__(self, da3_model_dir: str | Path, view_chunk_size: int = 1) -> None:
        super().__init__()
        self.encoder = DA3FrozenEncoder(da3_model_dir, layers=FEATURE_LAYERS, feature_dim=1536)
        self.semantic_head = SemanticDPTHead(view_chunk_size=view_chunk_size)

    def forward(
        self,
        image_da3: torch.Tensor,
        intrinsics: torch.Tensor,
        world_to_camera: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        features = self.encoder(image_da3, intrinsics, world_to_camera)
        return {"semantic_logits": self.semantic_head(features)}

    def train(self, mode: bool = True) -> "SemanticUpperBound":
        super().train(mode)
        self.encoder.da3.eval()
        return self

    def trainable_modules(self) -> dict[str, nn.Module]:
        return {"semantic_head": self.semantic_head}
