"""Semantic-only copy of the DA3 DualDPT main-branch architecture."""

from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import nn

from da3_gld.contracts import FEATURE_DIM, PATCH_TOKENS, SEMANTIC_CLASSES, TARGET_HEIGHT, TARGET_WIDTH
from depth_anything_3.model.dpt import _make_fusion_block, _make_scratch
from depth_anything_3.model.utils.head_utils import create_uv_grid, custom_interpolate, position_grid_to_embed


class SemanticDPTHead(nn.Module):
    """Four-scale DPT main branch with logits only: no ray or confidence branch."""

    def __init__(self, view_chunk_size: int = 1) -> None:
        super().__init__()
        if view_chunk_size <= 0:
            raise ValueError("view_chunk_size must be positive")
        self.view_chunk_size = view_chunk_size
        self.patch_size = 14
        self.norm = nn.LayerNorm(FEATURE_DIM)
        out_channels = (96, 192, 384, 768)
        self.projects = nn.ModuleList(nn.Conv2d(FEATURE_DIM, channels, 1) for channels in out_channels)
        self.resize_layers = nn.ModuleList(
            [
                nn.ConvTranspose2d(96, 96, kernel_size=4, stride=4),
                nn.ConvTranspose2d(192, 192, kernel_size=2, stride=2),
                nn.Identity(),
                nn.Conv2d(768, 768, kernel_size=3, stride=2, padding=1),
            ]
        )
        features = 128
        self.scratch = _make_scratch(list(out_channels), features, expand=False)
        self.scratch.refinenet1 = _make_fusion_block(features)
        self.scratch.refinenet2 = _make_fusion_block(features)
        self.scratch.refinenet3 = _make_fusion_block(features)
        self.scratch.refinenet4 = _make_fusion_block(features, has_residual=False)
        self.scratch.output_conv1 = nn.Conv2d(128, 64, kernel_size=3, padding=1)
        self.scratch.output_conv2 = nn.Sequential(
            nn.Conv2d(64, 32, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, SEMANTIC_CLASSES, kernel_size=1),
        )

    @staticmethod
    def _add_pos_embed(x: torch.Tensor, width: int, height: int, ratio: float = 0.1) -> torch.Tensor:
        grid_width, grid_height = x.shape[-1], x.shape[-2]
        position = create_uv_grid(
            grid_width,
            grid_height,
            aspect_ratio=width / height,
            dtype=x.dtype,
            device=x.device,
        )
        position = position_grid_to_embed(position, x.shape[1]) * ratio
        return x + position.permute(2, 0, 1)[None].expand(x.shape[0], -1, -1, -1)

    def _forward_impl(self, features: Sequence[torch.Tensor]) -> torch.Tensor:
        count = features[0].shape[0]
        resized = []
        for stage, feature in enumerate(features):
            if feature.shape != (count, PATCH_TOKENS, FEATURE_DIM):
                raise ValueError(f"Semantic DPT feature {stage} has invalid shape {tuple(feature.shape)}")
            x = self.norm(feature)
            x = x.permute(0, 2, 1).contiguous().reshape(count, FEATURE_DIM, 20, 52)
            x = self.projects[stage](x)
            x = self._add_pos_embed(x, TARGET_WIDTH, TARGET_HEIGHT)
            resized.append(self.resize_layers[stage](x))
        level1, level2, level3, level4 = resized
        level1 = self.scratch.layer1_rn(level1)
        level2 = self.scratch.layer2_rn(level2)
        level3 = self.scratch.layer3_rn(level3)
        level4 = self.scratch.layer4_rn(level4)
        fused = self.scratch.refinenet4(level4, size=level3.shape[2:])
        fused = self.scratch.refinenet3(fused, level3, size=level2.shape[2:])
        fused = self.scratch.refinenet2(fused, level2, size=level1.shape[2:])
        fused = self.scratch.refinenet1(fused, level1)
        fused = self.scratch.output_conv1(fused)
        fused = custom_interpolate(
            fused, (TARGET_HEIGHT, TARGET_WIDTH), mode="bilinear", align_corners=True
        )
        fused = self._add_pos_embed(fused, TARGET_WIDTH, TARGET_HEIGHT)
        return self.scratch.output_conv2(fused)

    def forward(self, features: Sequence[torch.Tensor]) -> torch.Tensor:
        if len(features) != 4 or features[0].ndim != 4:
            raise ValueError("Semantic DPT requires four [B,V,N,C] feature tensors")
        batch, views = features[0].shape[:2]
        flat = [feature.flatten(0, 1) for feature in features]
        chunks = []
        for start in range(0, batch * views, self.view_chunk_size):
            chunks.append(self._forward_impl([feature[start : start + self.view_chunk_size] for feature in flat]))
        return torch.cat(chunks).reshape(batch, views, SEMANTIC_CLASSES, TARGET_HEIGHT, TARGET_WIDTH)
