"""Uncompressed four-level GLD RGB upper-bound model."""

from __future__ import annotations

from pathlib import Path

import torch
from torch import nn

from da3_gld.contracts import PATCH_TOKENS, TARGET_HEIGHT, TARGET_WIDTH
from vendor.gld.decoders import GeneralDecoder_Variable, ViTMAEConfig
from vendor.gld.encoders.da3 import DA3EncoderDirect


class GLDRGBDecoder(nn.Module):
    """Thin adapter around the byte-identical GLD GeneralDecoder_Variable."""

    INPUT_DIM = 1536 * 4

    def __init__(self, view_chunk_size: int = 1, config_path: str | Path | None = None) -> None:
        super().__init__()
        if view_chunk_size <= 0:
            raise ValueError("view_chunk_size must be positive")
        if config_path is None:
            config_path = Path(__file__).resolve().parents[2] / "vendor" / "gld" / "configs" / "ViTXL"
        config = ViTMAEConfig.from_pretrained(str(config_path))
        config.hidden_size = self.INPUT_DIM
        config.patch_size = 14
        config.attention_probs_dropout_prob = 0.0
        config.hidden_dropout_prob = 0.0
        self.core = GeneralDecoder_Variable(config, base_image_size=(504, 504))
        self.view_chunk_size = view_chunk_size
        self.register_buffer("imagenet_mean", torch.tensor((0.485, 0.456, 0.406)).view(1, 3, 1, 1))
        self.register_buffer("imagenet_std", torch.tensor((0.229, 0.224, 0.225)).view(1, 3, 1, 1))

    @property
    def last_layer(self) -> nn.Parameter:
        return self.core.decoder_pred.weight

    def forward(self, tokens: torch.Tensor, batch: int, views: int) -> torch.Tensor:
        if tokens.shape != (batch * views, PATCH_TOKENS, self.INPUT_DIM):
            raise ValueError(
                f"Expected concatenated tokens {(batch * views, PATCH_TOKENS, self.INPUT_DIM)}, got {tuple(tokens.shape)}"
            )
        outputs: list[torch.Tensor] = []
        for start in range(0, tokens.shape[0], self.view_chunk_size):
            logits = self.core(
                tokens[start : start + self.view_chunk_size],
                input_size=(TARGET_HEIGHT, TARGET_WIDTH),
                drop_cls_token=False,
            ).logits
            outputs.append(self.core.unpatchify(logits, (TARGET_HEIGHT, TARGET_WIDTH)))
        normalized = torch.cat(outputs)
        rgb = normalized * self.imagenet_std.to(normalized) + self.imagenet_mean.to(normalized)
        return rgb.reshape(batch, views, 3, TARGET_HEIGHT, TARGET_WIDTH)


class GLDRGBUpperBound(nn.Module):
    """Preserve GLD raw four-level extraction, CLS removal, and 6144 concat."""

    def __init__(self, da3_model_dir: str | Path, view_chunk_size: int = 1) -> None:
        super().__init__()
        self.encoder = DA3EncoderDirect(pretrained_path=str(da3_model_dir))
        self.encoder.eval().requires_grad_(False)
        self.rgb_decoder = GLDRGBDecoder(view_chunk_size=view_chunk_size)

    def forward(self, image_da3: torch.Tensor, **_: torch.Tensor) -> dict[str, torch.Tensor]:
        if image_da3.ndim != 5 or image_da3.shape[1] != 6:
            raise ValueError(f"Expected ImageNet-normalized [B,6,3,H,W], got {tuple(image_da3.shape)}")
        batch, views = image_da3.shape[:2]
        with torch.inference_mode():
            all_features = self.encoder(image_da3, mode="all")
        if tuple(sorted(all_features)) != (0, 1, 2, 3):
            raise RuntimeError(f"GLD encoder returned unexpected levels: {sorted(all_features)}")
        tokens = torch.cat([all_features[level][:, 1:, :] for level in sorted(all_features)], dim=-1)
        tokens = tokens.clone()
        return {"rgb": self.rgb_decoder(tokens, batch, views)}

    def train(self, mode: bool = True) -> "GLDRGBUpperBound":
        super().train(mode)
        self.encoder.eval()
        return self

    def trainable_modules(self) -> dict[str, nn.Module]:
        return {"rgb_decoder": self.rgb_decoder}
