# DA3-GLD-RGB-Sem

该目录提供两条彼此独立的 nuScenes 训练任务，用来估计 DA3 四层特征在通道压缩前的 RGB 与 semantic 解码能力上限。它不与 `DA3-Tok` 系列共享运行时代码，也不联合训练两个 Head。

## 实验定义

两条任务统一使用同一个 nuScenes keyframe `sample` 的六个同步视角，固定顺序为：

```text
CAM_FRONT, CAM_FRONT_RIGHT, CAM_BACK_RIGHT,
CAM_BACK, CAM_BACK_LEFT, CAM_FRONT_LEFT
```

RGB、MoGe2 depth、semantic、intrinsics 和 world-to-camera extrinsics 必须在生成 manifest 前已经严格对齐为 `280x728`。dataset 不 resize、不 crop supervision、不 warp，也不跨 camera 或跨 sample 猜测缺失文件。

四个 feature block 固定为 `[5, 7, 9, 11]`，patch size 为 14，对应每层 `20x52=1040` 个 patch token。

### RGB 上限

`train_rgb.py` 保留 GLD 原始 `DA3EncoderDirect` 路径。每层输出 `[B*6,1041,1536]`，移除 CLS 后将四层按通道拼接：

```text
4 x [B*6,1040,1536] -> [B*6,1040,6144]
```

随后输入 byte-identical vendored `GeneralDecoder_Variable`。相对 GLD 原始 Stage-1，只替换 nuScenes 数据入口和 epoch-based 调度；feature extraction、CLS removal、concat、`Linear(6144,1152)`、504 基础位置网格插值、28 层 decoder、LPIPS、discriminator 与 GAN core 不变。

RGB generator objective 为：

```text
L1 + LPIPS + I(step >= 6000) * 0.75 * adaptive_weight * vanilla_GAN_G
```

discriminator 使用 hinge loss，从正式 generator step 4000 开始每步更新一次。generator GAN 从 step 6000 开始。adaptive weight 使用 `L1+LPIPS` 与 `decoder_pred.weight` 的梯度范数比，最大值 10000。GAN 使用相同坐标的随机 `224x224` real/fake crop、`[-1,1]` 输入、DiffAug probability 1、cutout 0；D 更新的 fake 会 clamp 并近似量化到 8-bit。DINO-S/8 backbone 冻结，只训练 discriminator heads。

### Semantic 上限

`train_semantic.py` 使用 geometry-aware `DA3FrozenEncoder`，将 intrinsics 和 world-to-camera extrinsics 编码进 DA3 camera tokens。四层 `[B,6,1040,1536]` 特征不 concat、不压缩、不加权，直接作为 list 输入 Semantic DPT Head。

Semantic DPT 复制 DA3 DualDPT depth main branch 的特征处理：

```text
LayerNorm(1536)
1x1 projections: [96,192,384,768]
scales: [x4,x2,x1,/2]
UV position embedding
four RefineNet stages, features=128
output: 128 -> 64 -> 32 -> 10 logits
```

该 Head 没有 ray、confidence 或 auxiliary branch。训练目标是未乘联合训练系数 `0.5` 的 weighted CE，class weights 为：

```text
[0.39,0.25,0.36,0.43,1.90,3.00,0.25,0.87,0.56,0.25]
```

semantic 有效 mask 来自标签映射：train ID `0..9` 有效，ignore/void 映射为 `-1`。它不是模型预测的 confidence。

## Manifest

```powershell
python build_manifests.py `
  --nuscenes-root D:\datasets\nuscenes `
  --nuscenes-version v1.0-trainval `
  --aligned-rgb-root D:\aligned\rgb `
  --aligned-depth-root D:\aligned\depth `
  --aligned-semantic-root D:\aligned\semantic `
  --output-dir D:\manifests\nuscenes-six-view
```

生成 `train.jsonl`、`dev.jsonl`、`val.jsonl` 和 split metadata。任何缺失视角、模态、非有限相机矩阵或非 `280x728` 输入都会直接失败。

## 训练

将 DA3 官方源码的 `src` 加入 `PYTHONPATH`，并提供包含 `config.json` 与模型权重的本地 DA3 snapshot。

RGB：

```powershell
torchrun --standalone --nproc_per_node=8 train_rgb.py `
  --train-manifest D:\manifests\nuscenes-six-view\train.jsonl `
  --dev-manifest D:\manifests\nuscenes-six-view\dev.jsonl `
  --val-manifest D:\manifests\nuscenes-six-view\val.jsonl `
  --da3-model-dir D:\models\DA3-BASE `
  --dino-discriminator-checkpoint D:\models\discs\dino_vit_small_patch8_224.pth `
  --lpips-checkpoint D:\models\lpips\vgg.pth `
  --run-dir D:\runs\da3-gld-rgb
```

Semantic：

```powershell
torchrun --standalone --nproc_per_node=8 train_semantic.py `
  --train-manifest D:\manifests\nuscenes-six-view\train.jsonl `
  --dev-manifest D:\manifests\nuscenes-six-view\dev.jsonl `
  --val-manifest D:\manifests\nuscenes-six-view\val.jsonl `
  --da3-model-dir D:\models\DA3-BASE `
  --run-dir D:\runs\da3-gld-semantic
```

RGB 的 `--lpips-checkpoint` 必须是 GLD LPIPS linear 权重，MD5 为 `d507d7349b931f0638a25a48a722f98a`。精确恢复训练分别追加 `--resume <run-dir>\latest.pt`。配置默认 BF16/DDP；仅 FP16 使用 GradScaler。

## 调度、EMA 与评估

两个 Head 都训练 40000 optimizer steps。generator/Head 使用 AdamW，LR `2e-4`，1000-step warmup，随后 cosine decay 到 step 40000 的 `2e-5`，betas `(0.9,0.95)`，weight decay 0。RGB discriminator 使用独立 update counter，1000 次 D update warmup，在第 16000 次 D update decay 到 `2e-5`。

EMA decay 固定为 `0.9978`，每个成功 optimizer step 后更新。dev/val、best 和 milestone inference checkpoint 全部使用 EMA；raw Head 只用于继续训练。

首次运行会以 seed `20260729` 分别固定 dev 64 samples 和 val 64 samples，每个 sample 含六视角。subset JSON 保存 manifest SHA256 和六个 camera token；resume 时若 manifest 改变会直接拒绝。

每 1000 steps 对 dev 和 val 各评估一次。RGB 指标为 L1、LPIPS、PSNR、SSIM；semantic 指标为 mIoU、pixel accuracy、per-class IoU 和 confusion matrix。两类指标都记录六视角总体与 per-camera 结果。best 只由 dev 选择：RGB 最小化 `L1+LPIPS`，semantic 最大化 mIoU；val 只用于监控。

## Checkpoint 与产物

`latest.pt` 是唯一可精确 resume 的完整训练 checkpoint。`best_rgb.pt`、`best_semantic.pt` 和 `milestones/` 只保存 EMA inference weights 与元数据。所有 checkpoint 都不包含 frozen DA3、frozen DINO backbone 或 LPIPS 权重；RGB latest 只额外保存 discriminator heads、optimizer、scheduler 和实际 update count。

每个 run 生成 resolved config、固定 subset JSON、train/dev/val JSONL、loss/metric 曲线、固定 CAM_FRONT 可视化、latest/best/milestone checkpoints。semantic run 额外生成 per-class IoU 曲线和最新 confusion matrix。
