"""Train the uncompressed four-level GLD MAE RGB decoder on nuScenes."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Iterable, Mapping

import torch
from torch import nn
from torch.nn.parallel import DistributedDataParallel as DDP

from da3_gld.adversarial import (
    DISC_WEIGHT,
    calculate_adaptive_weight,
    discriminator_enabled,
    generator_gan_enabled,
    hinge_d_loss,
    quantize_fake_for_discriminator,
    random_crop_pair,
    vanilla_g_loss,
)
from da3_gld.checkpointing import (
    atomic_torch_save,
    build_inference_payload,
    build_latest_payload,
    formal_model_identity,
    restore_latest_payload,
    unwrap_model,
)
from da3_gld.config import RGB_EXPERIMENT, write_resolved_config
from da3_gld.contracts import validate_evaluation_cardinality
from da3_gld.data.label_spec import SemanticLabelSpec
from da3_gld.distributed import (
    barrier,
    cleanup_distributed,
    is_main_process,
    reduce_sum,
    setup_distributed,
)
from da3_gld.ema import ExponentialMovingAverage
from da3_gld.evaluation import evaluate_rgb_dev_val, update_best_rgb
from da3_gld.losses import RGBReconstructionLoss
from da3_gld.models import GLDRGBUpperBound
from da3_gld.plotting import append_jsonl, render_rgb_artifacts, save_rgb_visualization
from da3_gld.schedules import make_cosine_warmup_scheduler
from da3_gld.training import (
    all_rank_rng_state,
    autocast_context,
    discriminator_checkpoint_state,
    discriminator_module,
    evaluation_record,
    frozen_da3_identity,
    frozen_file_identity,
    make_dataloaders,
    move_batch,
    require_cuda_device,
    resolve_runtime_config,
    restore_discriminator_checkpoint,
)
from vendor.gld.disc import build_discriminator


def parse_args() -> argparse.Namespace:
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=project / "configs" / "rgb.yaml")
    parser.add_argument("--train-manifest", type=Path)
    parser.add_argument("--dev-manifest", type=Path)
    parser.add_argument("--val-manifest", type=Path)
    parser.add_argument(
        "--semantic-mapping",
        type=Path,
        default=project / "configs" / "semantic_label_mapping.json",
    )
    parser.add_argument("--da3-model-dir", type=Path, required=True)
    parser.add_argument("--dino-discriminator-checkpoint", type=Path)
    parser.add_argument("--lpips-checkpoint", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--workers", type=int)
    parser.add_argument("--gradient-accumulation", type=int, default=1)
    parser.add_argument("--view-chunk-size", type=int)
    parser.add_argument("--precision", choices=("bf16", "fp16", "fp32"))
    return parser.parse_args()


def train_rgb_optimizer_step(
    model: nn.Module,
    criterion: nn.Module,
    batches: Iterable[Mapping[str, Any]],
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
    ema: ExponentialMovingAverage,
    discriminator: nn.Module,
    disc_augment: Any,
    disc_optimizer: torch.optim.Optimizer,
    disc_scheduler: Any,
    formal_step: int,
    device: torch.device,
    precision: str,
    scaler: Any = None,
) -> tuple[dict[str, torch.Tensor], int]:
    """Run one generator update and the due one-to-one discriminator update."""
    batches = list(batches)
    if not batches:
        raise ValueError("One optimizer step requires at least one microbatch")
    optimizer.zero_grad(set_to_none=True)
    discriminator.eval()
    accumulated: dict[str, torch.Tensor] = {}
    last_batch: dict[str, Any] | None = None
    for raw_batch in batches:
        batch = move_batch(raw_batch, device)
        last_batch = batch
        with autocast_context(device, precision):
            prediction = model(batch["image_da3"])
            losses = criterion(prediction, batch)
            generator_gan = losses["total"].new_zeros(())
            adaptive_weight = losses["total"].new_zeros(())
            gan_term = losses["total"].new_zeros(())
            if generator_gan_enabled(formal_step):
                fake_pm1 = prediction["rgb"].flatten(0, 1).mul(2.0).sub(1.0)
                real_pm1 = batch["rgb_01"].flatten(0, 1).mul(2.0).sub(1.0)
                fake_crop, _ = random_crop_pair(fake_pm1, real_pm1)
                fake_logits, _ = discriminator(
                    disc_augment.aug(fake_crop, warmup_blur_schedule=0), None
                )
                generator_gan = vanilla_g_loss(fake_logits)
                adaptive_weight = calculate_adaptive_weight(
                    losses["rgb_objective"],
                    generator_gan,
                    unwrap_model(model).rgb_decoder.last_layer,
                )
                gan_term = DISC_WEIGHT * adaptive_weight * generator_gan
            total = losses["total"] + gan_term
            backward = total / len(batches)
        if scaler is not None and scaler.is_enabled():
            scaler.scale(backward).backward()
        else:
            backward.backward()
        for name in ("rgb", "perceptual"):
            for suffix in ("sum", "count"):
                key = f"{name}_{suffix}"
                value = losses[key].detach().double()
                accumulated[key] = accumulated.get(key, torch.zeros_like(value)) + value
        for key, value in {
            "generator_gan": generator_gan,
            "adaptive_weight": adaptive_weight,
            "gan_term": gan_term,
            "total_with_gan": total,
        }.items():
            value = value.detach().double()
            accumulated[key] = accumulated.get(key, torch.zeros_like(value)) + value
        accumulated["generator_batches"] = accumulated.get(
            "generator_batches", total.new_zeros((), dtype=torch.float64)
        ) + 1.0

    stepped = True
    if scaler is not None and scaler.is_enabled():
        previous_scale = scaler.get_scale()
        scaler.step(optimizer)
        scaler.update()
        stepped = scaler.get_scale() >= previous_scale
    else:
        optimizer.step()
    if not stepped:
        optimizer.zero_grad(set_to_none=True)
        return accumulated, 0
    scheduler.step()
    ema.update(unwrap_model(model))

    accumulated["disc_loss"] = torch.zeros((), dtype=torch.float64, device=device)
    accumulated["disc_accuracy"] = torch.zeros((), dtype=torch.float64, device=device)
    accumulated["disc_updates"] = torch.zeros((), dtype=torch.float64, device=device)
    if discriminator_enabled(formal_step):
        if last_batch is None:
            raise RuntimeError("Discriminator update has no generator microbatch")
        model.eval()
        discriminator.train()
        disc_optimizer.zero_grad(set_to_none=True)
        with autocast_context(device, precision):
            with torch.no_grad():
                generated = model(last_batch["image_da3"])["rgb"]
                fake_pm1 = quantize_fake_for_discriminator(
                    generated.flatten(0, 1).mul(2.0).sub(1.0)
                )
                real_pm1 = last_batch["rgb_01"].flatten(0, 1).mul(2.0).sub(1.0)
            fake_crop, real_crop = random_crop_pair(fake_pm1, real_pm1)
            fake_input = disc_augment.aug(fake_crop, warmup_blur_schedule=0)
            real_input = disc_augment.aug(real_crop, warmup_blur_schedule=0)
            fake_logits, real_logits = discriminator(fake_input, real_input)
            disc_loss = hinge_d_loss(real_logits, fake_logits)
            disc_accuracy = (real_logits > fake_logits).float().mean()
        disc_stepped = True
        if scaler is not None and scaler.is_enabled():
            previous_scale = scaler.get_scale()
            scaler.scale(disc_loss).backward()
            scaler.step(disc_optimizer)
            scaler.update()
            disc_stepped = scaler.get_scale() >= previous_scale
        else:
            disc_loss.backward()
            disc_optimizer.step()
        if disc_stepped:
            disc_scheduler.step()
            accumulated["disc_updates"] += 1.0
        accumulated["disc_loss"] = disc_loss.detach().double()
        accumulated["disc_accuracy"] = disc_accuracy.detach().double()
        discriminator.eval()
        model.train()
    return accumulated, 1


def _train_record(
    step: int,
    losses: Mapping[str, torch.Tensor],
    generator_lr: float,
    discriminator_lr: float,
    discriminator_update_count: int,
) -> dict[str, Any]:
    sums = reduce_sum(torch.stack((losses["rgb_sum"], losses["perceptual_sum"])).double())
    counts = reduce_sum(torch.stack((losses["rgb_count"], losses["perceptual_count"])).double())
    if (counts <= 0).any():
        raise RuntimeError("RGB training reduction produced an empty loss domain")
    rgb = (sums[0] / counts[0]).item()
    perceptual = (sums[1] / counts[1]).item()
    batches = reduce_sum(losses["generator_batches"]).item()
    record = {
        "step": step,
        "rgb": rgb,
        "perceptual": perceptual,
        "generator_lr": generator_lr,
        "discriminator_lr": discriminator_lr,
        "discriminator_update_count": discriminator_update_count,
    }
    for key in ("generator_gan", "adaptive_weight", "gan_term", "total_with_gan"):
        record[key] = reduce_sum(losses[key]).item() / batches
    updates = reduce_sum(losses["disc_updates"]).item()
    record["disc_loss"] = reduce_sum(losses["disc_loss"]).item() / updates if updates else 0.0
    record["disc_accuracy"] = (
        reduce_sum(losses["disc_accuracy"]).item() / updates if updates else 0.0
    )
    record["total"] = record["total_with_gan"]
    return record


def main() -> None:
    args = parse_args()
    config = resolve_runtime_config(args, RGB_EXPERIMENT, require_discriminator=True)
    rank, world_size, local_rank = setup_distributed()
    device = require_cuda_device(local_rank)
    run_dir = args.run_dir.expanduser().resolve()
    if is_main_process():
        run_dir.mkdir(parents=True, exist_ok=True)
        write_resolved_config(config, run_dir)
    barrier()
    semantic_spec = SemanticLabelSpec.from_json(args.semantic_mapping)
    if semantic_spec.classes != 10 or semantic_spec.ignore_index != -1:
        raise ValueError("Semantic mapping must define ten classes with ignore_index=-1")
    train_loader, dev_loader, val_loader, train_sampler, manifest_hashes = make_dataloaders(
        config, args.semantic_mapping, run_dir, rank, world_size
    )

    model = GLDRGBUpperBound(
        args.da3_model_dir,
        view_chunk_size=int(config["model"]["view_chunk_size"]),
    ).to(device)
    if any(parameter.requires_grad for parameter in model.encoder.parameters()):
        raise RuntimeError("GLD DA3 encoder must remain frozen")
    if world_size > 1:
        model = DDP(model, device_ids=[local_rank], broadcast_buffers=False, find_unused_parameters=False)
    unwrapped = unwrap_model(model)
    criterion = RGBReconstructionLoss(
        use_lpips=True,
        lpips_checkpoint=config["runtime"]["lpips_checkpoint"],
    ).to(device)
    lpips_metric = criterion.perceptual.metric(device)
    optimizer = torch.optim.AdamW(
        [parameter for parameter in unwrapped.parameters() if parameter.requires_grad],
        lr=float(config["training"]["base_lr"]),
        betas=(0.9, 0.95),
        weight_decay=float(config["training"]["weight_decay"]),
    )
    scheduler = make_cosine_warmup_scheduler(
        optimizer,
        int(config["training"]["warmup_steps"]),
        int(config["training"]["steps"]),
        float(config["training"]["final_lr"]) / float(config["training"]["base_lr"]),
    )
    precision = str(config["training"]["precision"])
    scaler = torch.cuda.amp.GradScaler(enabled=precision == "fp16")
    ema = ExponentialMovingAverage(unwrapped, float(config["training"]["ema_decay"]))

    gan = config["gan"]
    discriminator, disc_augment = build_discriminator(
        {
            "arch": {
                "dino_ckpt_path": gan["discriminator_checkpoint"],
                "ks": 9,
                "norm_type": "bn",
                "using_spec_norm": True,
                "recipe": "S_8",
            },
            "augment": {
                "prob": float(gan["augment_probability"]),
                "cutout": float(gan["cutout"]),
            },
        },
        device,
    )
    discriminator.eval()
    if world_size > 1:
        discriminator = DDP(
            discriminator,
            device_ids=[local_rank],
            broadcast_buffers=False,
            find_unused_parameters=False,
        )
    disc_parameters = [
        parameter
        for parameter in discriminator_module(discriminator).heads.parameters()
        if parameter.requires_grad
    ]
    disc_optimizer = torch.optim.AdamW(
        disc_parameters,
        lr=float(gan["optimizer"]["lr"]),
        betas=tuple(float(value) for value in gan["optimizer"]["betas"]),
        weight_decay=float(gan["optimizer"]["weight_decay"]),
    )
    disc_scheduler = make_cosine_warmup_scheduler(
        disc_optimizer,
        int(gan["scheduler"]["warmup_updates"]),
        int(gan["scheduler"]["decay_end_updates"]),
        float(gan["scheduler"]["final_lr"]) / float(gan["optimizer"]["lr"]),
    )
    identity = formal_model_identity(
        RGB_EXPERIMENT,
        "raw_four_level_concat_6144",
        frozen_da3_identity(args.da3_model_dir),
    )
    identity["frozen_discriminator"] = frozen_file_identity(gan["discriminator_checkpoint"])
    identity["frozen_lpips"] = frozen_file_identity(config["runtime"]["lpips_checkpoint"])

    global_step = 0
    data_epoch = 0
    batch_cursor = 0
    best_records: dict[str, Any] = {}
    disc_update_count = 0
    if args.resume is not None:
        checkpoint = torch.load(args.resume, map_location=device, weights_only=False)
        if checkpoint.get("resolved_config") != config:
            raise ValueError("Resume checkpoint resolved config differs from the active config")
        restore_latest_payload(
            checkpoint,
            model,
            ema,
            optimizer,
            scheduler,
            scaler,
            identity,
            manifest_hashes,
            rank_value=rank,
        )
        global_step = int(checkpoint["step"])
        data_epoch = int(checkpoint["stream_position"]["epoch"])
        batch_cursor = int(checkpoint["stream_position"]["batch"])
        best_records = dict(checkpoint["best_records"])
        if checkpoint.get("adversarial") is None:
            raise ValueError("RGB latest checkpoint is missing adversarial state")
        disc_update_count = restore_discriminator_checkpoint(
            checkpoint["adversarial"], discriminator, disc_optimizer, disc_scheduler
        )

    accumulation = int(config["runtime"]["gradient_accumulation"])
    total_steps = int(config["training"]["steps"])
    model.train()
    pending: list[Mapping[str, Any]] = []
    while global_step < total_steps:
        if train_sampler is not None:
            train_sampler.set_epoch(data_epoch)
        for batch_index, batch in enumerate(train_loader):
            if batch_index < batch_cursor:
                continue
            pending.append(batch)
            batch_cursor = batch_index + 1
            if len(pending) < accumulation:
                continue
            losses, advanced = train_rgb_optimizer_step(
                model,
                criterion,
                pending,
                optimizer,
                scheduler,
                ema,
                discriminator,
                disc_augment,
                disc_optimizer,
                disc_scheduler,
                global_step + 1,
                device,
                precision,
                scaler,
            )
            pending.clear()
            if not advanced:
                continue
            global_step += 1
            disc_update_count += int(losses["disc_updates"].item())
            if global_step % int(config["checkpoint"]["loss_log_every"]) == 0:
                record = _train_record(
                    global_step,
                    losses,
                    optimizer.param_groups[0]["lr"],
                    disc_optimizer.param_groups[0]["lr"],
                    disc_update_count,
                )
                if is_main_process():
                    append_jsonl(run_dir / "train_metrics.jsonl", record)
            if global_step % int(config["checkpoint"]["checkpoint_every"]) == 0:
                barrier()
                results = evaluate_rgb_dev_val(
                    model, ema, criterion, lpips_metric, dev_loader, val_loader, device
                )
                for split in ("dev", "val"):
                    validate_evaluation_cardinality(
                        results[split]["metrics"], int(config["evaluation"][f"{split}_samples"])
                    )
                new_best, improved = update_best_rgb(
                    best_records, global_step, results["dev"]["metrics"]
                )
                rng_state = all_rank_rng_state(rank, world_size)
                if is_main_process():
                    append_jsonl(
                        run_dir / "dev_metrics.jsonl",
                        evaluation_record(global_step, results["dev"]),
                    )
                    append_jsonl(
                        run_dir / "val_metrics.jsonl",
                        evaluation_record(global_step, results["val"]),
                    )
                    render_rgb_artifacts(run_dir)
                    if results["dev"]["visual"] is not None:
                        save_rgb_visualization(
                            run_dir / "visuals" / f"step_{global_step:05d}.png",
                            *results["dev"]["visual"],
                        )
                    serializable = {
                        split: {"losses": value["losses"], "metrics": value["metrics"]}
                        for split, value in results.items()
                    }
                    latest = build_latest_payload(
                        model,
                        ema,
                        optimizer,
                        scheduler,
                        scaler,
                        global_step,
                        {"epoch": data_epoch, "batch": batch_cursor},
                        new_best,
                        config,
                        manifest_hashes,
                        identity,
                        serializable,
                        discriminator_checkpoint_state(
                            discriminator, disc_optimizer, disc_scheduler, disc_update_count
                        ),
                        rng_state,
                    )
                    atomic_torch_save(latest, run_dir / "latest.pt")
                    if improved:
                        atomic_torch_save(
                            build_inference_payload(
                                model, ema, global_step, config, manifest_hashes, identity, serializable
                            ),
                            run_dir / "best_rgb.pt",
                        )
                    if global_step % int(config["checkpoint"]["milestone_every"]) == 0:
                        atomic_torch_save(
                            build_inference_payload(
                                model, ema, global_step, config, manifest_hashes, identity, serializable
                            ),
                            run_dir / "milestones" / f"step_{global_step:05d}.pt",
                        )
                best_records = new_best
                barrier()
                model.train()
            if global_step >= total_steps:
                break
        else:
            data_epoch += 1
            batch_cursor = 0
            pending.clear()
            continue
        if global_step >= total_steps:
            break
    cleanup_distributed()


if __name__ == "__main__":
    main()
