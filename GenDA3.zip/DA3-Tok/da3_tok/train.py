"""Step-based joint training for the six-view DA3-Tok baseline."""

from __future__ import annotations

import argparse
import json
import os
from contextlib import nullcontext
from pathlib import Path
from typing import Any, Iterable, Mapping

import torch
import torch.distributed as dist
from torch import nn
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler, Subset

from da3_tok.checkpointing import (
    atomic_torch_save,
    build_inference_payload,
    build_latest_payload,
    capture_rng_state,
    formal_model_identity,
    restore_latest_payload,
    unwrap_model,
)
from da3_tok.config import load_config, validate_config, write_resolved_config
from da3_tok.contracts import (
    CAMERA_ORDER,
    FEATURE_LAYERS,
    SEMANTIC_CLASSES,
    validate_evaluation_cardinality,
)
from da3_tok.data.label_spec import SemanticLabelSpec
from da3_tok.data.manifest import load_manifest, sha256_file
from da3_tok.data.nuscenes_six_view import NuScenesSixViewDataset
from da3_tok.data.subsets import load_or_create_fixed_subset
from da3_tok.distributed import (
    DistributedEvalSampler,
    barrier,
    cleanup_distributed,
    is_main_process,
    reduce_sum,
    setup_distributed,
)
from da3_tok.ema import ExponentialMovingAverage
from da3_tok.evaluation import evaluate_dev_val, update_best_records
from da3_tok.losses import DA3TokLoss, LossWeights
from da3_tok.models import DA3Tok
from da3_tok.plotting import append_jsonl, render_curve_artifacts, save_joint_visualization
from da3_tok.schedules import make_cosine_warmup_scheduler


def parse_args() -> argparse.Namespace:
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=project / "configs" / "train.yaml")
    parser.add_argument("--train-manifest", type=Path)
    parser.add_argument("--dev-manifest", type=Path)
    parser.add_argument("--val-manifest", type=Path)
    parser.add_argument("--semantic-mapping", type=Path, default=project / "configs" / "semantic_label_mapping.json")
    parser.add_argument("--da3-model-dir", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--workers", type=int)
    parser.add_argument("--gradient-accumulation", type=int, default=1)
    parser.add_argument("--view-chunk-size", type=int)
    parser.add_argument("--precision", choices=("bf16", "fp16", "fp32"))
    return parser.parse_args()


def _resolve_runtime_config(args: argparse.Namespace) -> dict[str, Any]:
    config = load_config(args.config)
    for key in ("train_manifest", "dev_manifest", "val_manifest"):
        argument = getattr(args, key)
        if argument is not None:
            config["data"][key] = str(argument.expanduser().resolve())
        if not config["data"].get(key):
            raise ValueError(f"Provide --{key.replace('_', '-')} or set data.{key} in the config")
        config["data"][key] = str(Path(config["data"][key]).expanduser().resolve())
    for key in ("batch_size", "workers", "precision"):
        value = getattr(args, key)
        if value is not None:
            config["training"][key] = value
    if args.view_chunk_size is not None:
        config["model"]["view_chunk_size"] = args.view_chunk_size
    config["runtime"] = {
        "da3_model_dir": str(args.da3_model_dir.expanduser().resolve()),
        "semantic_mapping": str(args.semantic_mapping.expanduser().resolve()),
        "gradient_accumulation": args.gradient_accumulation,
    }
    validate_config(config)
    if int(config["training"]["batch_size"]) <= 0 or int(config["training"]["workers"]) < 0:
        raise ValueError("batch_size must be positive and workers must be non-negative")
    if args.gradient_accumulation <= 0 or int(config["model"]["view_chunk_size"]) <= 0:
        raise ValueError("gradient_accumulation and view_chunk_size must be positive")
    return config


def _device(local_rank: int) -> torch.device:
    if not torch.cuda.is_available():
        raise RuntimeError("Formal DA3 training requires CUDA; CPU is supported only by synthetic tests")
    return torch.device("cuda", local_rank)


def _autocast(device: torch.device, precision: str):
    if precision == "fp32":
        return nullcontext()
    dtype = torch.bfloat16 if precision == "bf16" else torch.float16
    return torch.autocast(device_type=device.type, dtype=dtype)


def _move_batch(batch: Mapping[str, Any], device: torch.device) -> dict[str, Any]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def _semantic_weights(config: Mapping[str, Any], device: torch.device) -> torch.Tensor:
    weights = torch.tensor(config["loss"]["semantic_class_weights"], dtype=torch.float32, device=device)
    if weights.shape != (SEMANTIC_CLASSES,) or not torch.isfinite(weights).all() or (weights <= 0).any():
        raise ValueError("semantic_class_weights must contain ten finite positive values")
    return weights


def _frozen_da3_identity(model_dir: Path) -> dict[str, Any]:
    model_dir = model_dir.expanduser().resolve()
    config_path = model_dir / "config.json"
    weight_candidates = [model_dir / "model.safetensors", model_dir / "pytorch_model.bin"]
    weights = next((path for path in weight_candidates if path.is_file()), None)
    if not config_path.is_file() or weights is None:
        raise FileNotFoundError(f"DA3 directory must contain config.json and model weights: {model_dir}")
    return {
        "path": str(model_dir),
        "config_sha256": sha256_file(config_path),
        "weights_file": weights.name,
        "weights_sha256": sha256_file(weights),
    }


def _all_rank_rng_state(rank: int, world_size: int) -> dict[str, Any]:
    local = capture_rng_state()
    if world_size == 1:
        return local
    gathered: list[Any] = [None] * world_size
    dist.all_gather_object(gathered, local)
    return {"world_size": world_size, "per_rank": gathered}


def _reduced_train_record(
    step: int,
    component_sums: torch.Tensor,
    component_counts: torch.Tensor,
    weights: LossWeights,
    learning_rate: float,
    fusion_weights: torch.Tensor,
) -> dict[str, Any]:
    sums = reduce_sum(component_sums)
    counts = reduce_sum(component_counts)
    if (counts <= 0).any():
        raise RuntimeError("Training loss reduction produced an empty component domain")
    names = ("rgb", "perceptual", "depth", "point", "semantic")
    means = {name: (sums[index] / counts[index]).item() for index, name in enumerate(names)}
    means["total"] = (
        weights.rgb * means["rgb"]
        + weights.perceptual * means["perceptual"]
        + weights.depth * means["depth"]
        + weights.point * means["point"]
        + weights.semantic * means["semantic"]
    )
    return {
        "step": step,
        **means,
        "generator_lr": learning_rate,
        "fusion_weights": fusion_weights.detach().float().cpu().tolist(),
    }


def train_one_optimizer_step(
    model: nn.Module,
    criterion: nn.Module,
    batches: Iterable[Mapping[str, Any]],
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
    ema: ExponentialMovingAverage,
    device: torch.device,
    precision: str,
    scaler: Any = None,
) -> tuple[dict[str, torch.Tensor], int]:
    """Run one complete accumulation cycle; used by the main loop and CPU smoke tests."""
    batches = list(batches)
    if not batches:
        raise ValueError("One optimizer step requires at least one microbatch")
    optimizer.zero_grad(set_to_none=True)
    accumulated: dict[str, torch.Tensor] = {}
    for raw_batch in batches:
        batch = _move_batch(raw_batch, device)
        with _autocast(device, precision):
            prediction = model(batch["image_da3"], batch["intrinsics"], batch["world_to_camera"])
            losses = criterion(prediction, batch)
            backward_loss = losses["total"] / len(batches)
        if scaler is not None and scaler.is_enabled():
            scaler.scale(backward_loss).backward()
        else:
            backward_loss.backward()
        for name in ("rgb", "perceptual", "depth", "point", "semantic"):
            for suffix in ("sum", "count"):
                key = f"{name}_{suffix}"
                value = losses[key].detach().double()
                accumulated[key] = accumulated.get(key, torch.zeros_like(value)) + value
    stepped = True
    if scaler is not None and scaler.is_enabled():
        previous_scale = scaler.get_scale()
        scaler.step(optimizer)
        scaler.update()
        stepped = scaler.get_scale() >= previous_scale
    else:
        optimizer.step()
    if not stepped:
        optimizer.zero_grad(set_to_none=True)
        return accumulated, 0
    scheduler.step()
    ema.update(unwrap_model(model))
    return accumulated, 1


def _make_dataloaders(
    config: Mapping[str, Any],
    semantic_mapping: Path,
    run_dir: Path,
    rank: int,
    world_size: int,
) -> tuple[DataLoader, DataLoader, DataLoader, DistributedSampler | None, dict[str, str]]:
    datasets = {
        split: NuScenesSixViewDataset(config["data"][f"{split}_manifest"], split, semantic_mapping)
        for split in ("train", "dev", "val")
    }
    manifest_hashes = {
        split: sha256_file(Path(config["data"][f"{split}_manifest"])) for split in datasets
    }
    subset_indices = {}
    for split in ("dev", "val"):
        subset_indices[split] = load_or_create_fixed_subset(
            config["data"][f"{split}_manifest"],
            datasets[split].records,
            run_dir / f"{split}_subset.json",
            int(config["evaluation"][f"{split}_samples"]),
            int(config["evaluation"]["subset_seed"]),
            rank,
            barrier,
        )
    train_sampler = (
        DistributedSampler(datasets["train"], num_replicas=world_size, rank=rank, shuffle=True)
        if world_size > 1
        else None
    )
    common = {
        "batch_size": int(config["training"]["batch_size"]),
        "num_workers": int(config["training"]["workers"]),
        "pin_memory": True,
        "persistent_workers": int(config["training"]["workers"]) > 0,
    }
    train_loader = DataLoader(
        datasets["train"], sampler=train_sampler, shuffle=train_sampler is None, drop_last=True, **common
    )
    eval_loaders = []
    for split in ("dev", "val"):
        subset = Subset(datasets[split], subset_indices[split])
        sampler = DistributedEvalSampler(subset, rank, world_size)
        eval_loaders.append(DataLoader(subset, sampler=sampler, shuffle=False, drop_last=False, **common))
    return train_loader, eval_loaders[0], eval_loaders[1], train_sampler, manifest_hashes


def _evaluation_record(step: int, result: Mapping[str, Any]) -> dict[str, Any]:
    return {"step": step, **result["losses"], **result["metrics"]}


def main() -> None:
    args = parse_args()
    config = _resolve_runtime_config(args)
    rank, world_size, local_rank = setup_distributed()
    device = _device(local_rank)
    run_dir = args.run_dir.expanduser().resolve()
    if is_main_process():
        run_dir.mkdir(parents=True, exist_ok=True)
        write_resolved_config(config, run_dir)
    barrier()
    semantic_spec = SemanticLabelSpec.from_json(args.semantic_mapping)
    if semantic_spec.classes != SEMANTIC_CLASSES or semantic_spec.ignore_index != -1:
        raise ValueError("Semantic mapping must define ten classes with ignore_index=-1")
    train_loader, dev_loader, val_loader, train_sampler, manifest_hashes = _make_dataloaders(
        config, args.semantic_mapping, run_dir, rank, world_size
    )

    model = DA3Tok(
        args.da3_model_dir,
        semantic_classes=SEMANTIC_CLASSES,
        view_chunk_size=int(config["model"]["view_chunk_size"]),
        feature_layers=FEATURE_LAYERS,
        feature_dim=int(config["model"]["feature_dim"]),
    ).to(device)
    model.encoder.assert_frozen()
    if world_size > 1:
        model = DDP(model, device_ids=[local_rank], broadcast_buffers=False, find_unused_parameters=False)
    unwrapped = unwrap_model(model)
    loss_config = config["loss"]
    weights = LossWeights(
        rgb=float(loss_config["rgb_charbonnier"]),
        perceptual=float(loss_config["rgb_lpips"]),
        depth=float(loss_config["depth"]),
        point=float(loss_config["point"]),
        semantic=float(loss_config["semantic"]),
    )
    criterion = DA3TokLoss(
        semantic_ignore_index=-1,
        semantic_class_weights=_semantic_weights(config, device),
        use_lpips=True,
        weights=weights,
    ).to(device)
    lpips_metric = criterion.perceptual._get_metric(device)
    trainable = [parameter for parameter in unwrapped.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(
        trainable,
        lr=float(config["training"]["base_lr"]),
        betas=(0.9, 0.95),
        weight_decay=float(config["training"]["weight_decay"]),
    )
    scheduler = make_cosine_warmup_scheduler(
        optimizer,
        int(config["training"]["warmup_steps"]),
        int(config["training"]["steps"]),
        float(config["training"]["final_lr"]) / float(config["training"]["base_lr"]),
    )
    precision = str(config["training"]["precision"])
    scaler = torch.cuda.amp.GradScaler(enabled=precision == "fp16")
    ema = ExponentialMovingAverage(unwrapped, float(config["training"]["ema_decay"]))
    identity = formal_model_identity(
        "da3_tok", "weighted_sum_mean_broadcast", _frozen_da3_identity(args.da3_model_dir)
    )
    global_step = 0
    data_epoch = 0
    batch_cursor = 0
    best_records: dict[str, Any] = {}
    if args.resume is not None:
        checkpoint = torch.load(args.resume, map_location=device, weights_only=False)
        if checkpoint.get("resolved_config") != config:
            raise ValueError("Resume checkpoint resolved config differs from the active formal config")
        restore_latest_payload(
            checkpoint, model, ema, optimizer, scheduler, scaler,
            expected_model_identity=identity,
            expected_manifest_hashes=manifest_hashes,
            rank_value=rank,
        )
        global_step = int(checkpoint["step"])
        data_epoch = int(checkpoint["stream_position"]["epoch"])
        batch_cursor = int(checkpoint["stream_position"]["batch"])
        best_records = dict(checkpoint["best_records"])

    accumulation = int(config["runtime"]["gradient_accumulation"])
    total_steps = int(config["training"]["steps"])
    model.train()
    pending_batches: list[Mapping[str, Any]] = []
    while global_step < total_steps:
        if train_sampler is not None:
            train_sampler.set_epoch(data_epoch)
        for batch_index, batch in enumerate(train_loader):
            if batch_index < batch_cursor:
                continue
            pending_batches.append(batch)
            batch_cursor = batch_index + 1
            if len(pending_batches) < accumulation:
                continue
            losses, advanced = train_one_optimizer_step(
                model, criterion, pending_batches, optimizer, scheduler, ema, device, precision, scaler
            )
            pending_batches.clear()
            if not advanced:
                continue
            global_step += 1
            component_sums = torch.stack([losses[f"{name}_sum"].double() for name in ("rgb", "perceptual", "depth", "point", "semantic")])
            component_counts = torch.stack([losses[f"{name}_count"].double() for name in ("rgb", "perceptual", "depth", "point", "semantic")])
            if global_step % int(config["checkpoint"]["loss_log_every"]) == 0:
                train_record = _reduced_train_record(
                    global_step, component_sums, component_counts, weights,
                    optimizer.param_groups[0]["lr"], losses.get("fusion_weights", unwrapped.fusion.weights),
                )
                if is_main_process():
                    append_jsonl(run_dir / "train_metrics.jsonl", train_record)
            if global_step % int(config["checkpoint"]["checkpoint_every"]) == 0:
                barrier()
                results = evaluate_dev_val(
                    model, ema, criterion, lpips_metric, dev_loader, val_loader, device
                )
                for split in ("dev", "val"):
                    validate_evaluation_cardinality(
                        results[split]["metrics"], int(config["evaluation"][f"{split}_samples"])
                    )
                new_best_records, improved = update_best_records(
                    best_records, global_step, results["dev"]["losses"], results["dev"]["metrics"]
                )
                rng_state = _all_rank_rng_state(rank, world_size)
                if is_main_process():
                    append_jsonl(run_dir / "dev_metrics.jsonl", _evaluation_record(global_step, results["dev"]))
                    append_jsonl(run_dir / "val_metrics.jsonl", _evaluation_record(global_step, results["val"]))
                    render_curve_artifacts(run_dir)
                    if results["dev"]["visual"] is not None:
                        batch_visual, prediction_visual = results["dev"]["visual"]
                        save_joint_visualization(
                            run_dir / "visuals" / f"step_{global_step:05d}.png",
                            batch_visual,
                            prediction_visual,
                        )
                    serializable_results = {
                        split: {"losses": value["losses"], "metrics": value["metrics"]}
                        for split, value in results.items()
                    }
                    latest = build_latest_payload(
                        model, ema, optimizer, scheduler, scaler, global_step,
                        stream_position={"epoch": data_epoch, "batch": batch_cursor},
                        best_records=new_best_records,
                        resolved_config=config,
                        manifest_hashes=manifest_hashes,
                        model_identity=identity,
                        metrics=serializable_results,
                        rng_state=rng_state,
                    )
                    atomic_torch_save(latest, run_dir / "latest.pt")
                    for name in improved:
                        inference = build_inference_payload(
                            model, ema, global_step, config, manifest_hashes, identity,
                            {"criterion": name, **serializable_results},
                        )
                        atomic_torch_save(inference, run_dir / f"{name}.pt")
                    if global_step % int(config["checkpoint"]["milestone_every"]) == 0:
                        milestone = build_inference_payload(
                            model, ema, global_step, config, manifest_hashes, identity, serializable_results
                        )
                        atomic_torch_save(
                            milestone, run_dir / "milestones" / f"step_{global_step:05d}.pt"
                        )
                best_records = new_best_records
                barrier()
                model.train()
            if global_step >= total_steps:
                break
        else:
            data_epoch += 1
            batch_cursor = 0
            pending_batches.clear()
            continue
        if global_step >= total_steps:
            break
    cleanup_distributed()


if __name__ == "__main__":
    main()
