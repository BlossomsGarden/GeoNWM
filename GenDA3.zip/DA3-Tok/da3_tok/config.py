"""Load and validate the immutable formal experiment configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .contracts import (
    CAMERA_ORDER,
    FEATURE_DIM,
    FEATURE_LAYERS,
    SEMANTIC_CLASSES,
    TARGET_HEIGHT,
    TARGET_WIDTH,
)


def _require_mapping(config: dict[str, Any], name: str) -> dict[str, Any]:
    value = config.get(name)
    if not isinstance(value, dict):
        raise ValueError(f"Config section {name!r} must be a mapping")
    return value


def _require_equal(section: dict[str, Any], key: str, expected: Any) -> None:
    actual = section.get(key)
    if actual != expected:
        raise ValueError(f"Formal config {key} must be {expected!r}, got {actual!r}")


def validate_config(config: dict[str, Any]) -> None:
    data = _require_mapping(config, "data")
    model = _require_mapping(config, "model")
    training = _require_mapping(config, "training")
    evaluation = _require_mapping(config, "evaluation")
    checkpoint = _require_mapping(config, "checkpoint")

    _require_equal(data, "camera_order", list(CAMERA_ORDER))
    _require_equal(data, "height", TARGET_HEIGHT)
    _require_equal(data, "width", TARGET_WIDTH)
    _require_equal(model, "feature_layers", list(FEATURE_LAYERS))
    _require_equal(model, "feature_dim", FEATURE_DIM)
    _require_equal(model, "semantic_classes", SEMANTIC_CLASSES)
    _require_equal(evaluation, "dev_samples", 64)
    _require_equal(evaluation, "val_samples", 64)

    for key in ("steps", "warmup_steps"):
        if int(training.get(key, 0)) <= 0:
            raise ValueError(f"{key} must be positive")
    base_lr = float(training.get("base_lr", 0.0))
    final_lr = float(training.get("final_lr", 0.0))
    if base_lr <= 0 or final_lr <= 0 or final_lr > base_lr:
        raise ValueError("base_lr and final_lr must be positive with final_lr <= base_lr")
    decay = float(training.get("ema_decay", 0.0))
    if not 0.0 < decay < 1.0:
        raise ValueError("ema_decay must be in (0, 1)")
    for key in ("checkpoint_every", "milestone_every", "loss_log_every"):
        if int(checkpoint.get(key, 0)) <= 0:
            raise ValueError(f"{key} must be positive")


def load_config(path: Path) -> dict[str, Any]:
    path = Path(path)
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Config root must be a mapping: {path}")
    validate_config(raw)
    return raw


def write_resolved_config(config: dict[str, Any], run_dir: Path) -> None:
    validate_config(config)
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    output = run_dir / "config_resolved.yaml"
    output.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
