# DA3-Tok Six-View Baseline

`DA3-Tok` is the compact non-adversarial baseline in the four-experiment comparison. The frozen DA3-BASE encoder exposes blocks `[5, 7, 9, 11]`. Each level is normalized, combined by four learned scalar softmax weights, and augmented with the normalized block-11 mean token broadcast. The result remains `[B,6,1040,1536]` and is decoded jointly into RGB, depth, and ten semantic classes. Camera-frame points are derived from predicted depth and intrinsics; there is no point Head.

## Data Contract

One item is one nuScenes keyframe `sample`, containing six synchronized views in this exact order:

1. `CAM_FRONT`
2. `CAM_FRONT_RIGHT`
3. `CAM_BACK_RIGHT`
4. `CAM_BACK`
5. `CAM_BACK_LEFT`
6. `CAM_FRONT_LEFT`

RGB, MoGe2 depth, semantic IDs, and camera matrices must already describe the same `280x728` pixel frame. The loader never resizes, crops, warps, reorders, or fills a missing view. A malformed or incomplete sample fails.

Depth validity is the optional file mask intersected with finite positive target depth. Semantic train IDs `0..9` are valid, `255` is ignored, and every other source ID fails taxonomy validation. A non-finite prediction on valid target pixels fails training or evaluation.

Build keyframe manifests:

```powershell
python build_manifests.py `
  --nuscenes-root C:\data\nuscenes `
  --nuscenes-version v1.0-trainval `
  --aligned-rgb-root C:\data\aligned_rgb `
  --aligned-depth-root C:\data\aligned_depth `
  --aligned-semantic-root C:\data\aligned_semantic `
  --output-dir C:\data\da3_tok_manifests `
  --dev-scene-fraction 0.1 `
  --seed 20260729
```

Aligned files are joined only by `(camera, original nuScenes filename stem)`. The builder writes `train.jsonl`, `dev.jsonl`, `val.jsonl`, and `split_manifest.json`.

## Objective And Schedule

The joint baseline objective is:

```text
total = RGB Charbonnier + 0.20 * LPIPS + depth + 0.02 * point + 0.50 * semantic
```

Semantic CE uses class weights `[0.39,0.25,0.36,0.43,1.90,3.00,0.25,0.87,0.56,0.25]`. Training runs for 40,000 optimizer steps with AdamW, betas `(0.9,0.95)`, weight decay `0`, 1,000 warm-up steps, cosine decay from `2e-4` to `2e-5`, and full-generator EMA decay `0.9978`. The DA3 backbone remains frozen and is excluded from EMA and checkpoints.

## Evaluation And Outputs

The first run persists deterministic 64-sample dev and 64-sample val subsets using seed `20260729`. Each subset file records the manifest hash, sample token, and all six camera tokens. Dev alone selects:

- `best_joint.pt`: minimum total loss
- `best_rgb.pt`: minimum RGB L1 + LPIPS
- `best_depth.pt`: minimum AbsRel
- `best_point.pt`: minimum camera-frame 3D mean L2
- `best_semantic.pt`: maximum mIoU

Val is monitoring only. Every 1,000 steps, EMA weights are evaluated once on both subsets. Metrics include RGB L1/LPIPS/PSNR/SSIM, depth AbsRel/RMSE/delta1, point L2/z/xy errors, semantic mIoU/pixel accuracy/per-class IoU/confusion, aggregate six-view values, and per-camera values. JSONL logs and curve images are regenerated at the same event; milestones are written every 5,000 steps.

`latest.pt` is the only resumable checkpoint. It contains raw trainable fusion/decoder state, EMA, optimizer, scheduler, scaler, per-rank RNG, stream position, best records, config, identity, and metrics. Best and milestone files contain EMA inference weights and metadata only. Frozen DA3 and LPIPS weights are never stored.

## Training

Edit manifest paths in `configs/train.yaml` or provide them explicitly:

```powershell
torchrun --standalone --nproc_per_node=2 -m da3_tok.train `
  --config configs/train.yaml `
  --train-manifest C:\data\da3_tok_manifests\train.jsonl `
  --dev-manifest C:\data\da3_tok_manifests\dev.jsonl `
  --val-manifest C:\data\da3_tok_manifests\val.jsonl `
  --semantic-mapping configs\semantic_label_mapping.json `
  --da3-model-dir C:\models\DA3-BASE `
  --run-dir C:\runs\da3_tok
```

Resume only from the matching run's `latest.pt`:

```powershell
torchrun --standalone --nproc_per_node=2 -m da3_tok.train `
  --config C:\runs\da3_tok\config_resolved.yaml `
  --da3-model-dir C:\models\DA3-BASE `
  --run-dir C:\runs\da3_tok `
  --resume C:\runs\da3_tok\latest.pt
```

The resume loader rejects a changed schema, camera order, feature layers, manifest hashes, DA3 identity, or resolved configuration. No legacy checkpoint fallback is provided.
