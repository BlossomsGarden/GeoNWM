from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import torch
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler


THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.raev2_decoder import RectRAEv2Decoder  # noqa: E402
from multimodal_decoders.data import (  # noqa: E402
    NuScenesMultimodalDataset,
    sample_fixed_indices,
    write_subset_manifest,
)
from multimodal_decoders.losses import depth_loss, semantic_loss  # noqa: E402
from multimodal_decoders.metrics import (  # noqa: E402
    depth_metric_sums,
    reduce_depth_sums,
    reduce_semantic_confusion,
    semantic_confusion_matrix,
)
from multimodal_decoders.train_utils import (  # noqa: E402
    all_reduce_mapping,
    all_reduce_tensor,
    append_jsonl,
    barrier,
    cleanup_distributed,
    colorize_depth,
    colorize_semantic,
    cosine_scheduler,
    current_gpu_memory,
    init_distributed,
    make_grad_scaler,
    make_labeled_row,
    move_to_device,
    precision_context,
    save_checkpoint,
    seed_everything,
    tensor_to_pil,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Jointly train RAEv2 depth and semantic decoder heads on nuScenes.")
    parser.add_argument("--train-csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv")
    parser.add_argument("--val-csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv")
    parser.add_argument("--nuscenes-root", default="/data2/DATA/AutoDrive/nuscenes/v1.0-trainval")
    parser.add_argument("--depth-root", default="/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth")
    parser.add_argument("--semantic-root", default="/data4/DATA/wlh/GenDA3/samples_seg")
    parser.add_argument("--raev2-root", default="../RAEv2-main")
    parser.add_argument("--encoder-name", default="dinov3mls-vit-b16[layers=6.7.8.9.10.11]")
    parser.add_argument("--dinov3-ckpt-dir", default="pretrained_models/encoders/dinov3")
    parser.add_argument("--dinov3-repo-dir", default=None)
    parser.add_argument("--decoder-config", default="configs/decoder/ViTXL")
    parser.add_argument("--decoder-ckpt", default="pretrained_models/stage1/imagenet/dinov3b-k6/decoder.pt")
    parser.add_argument("--stats-path", default="pretrained_models/stage1/nuscenes-512/stats.pt")
    parser.add_argument("--out-dir", default="/data/wlh/DeltaWorld/outputs/raev2_nuscenes_decoders/depth_semantic")
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--width", type=int, default=832)
    parser.add_argument("--num-classes", type=int, default=10)
    parser.add_argument("--min-depth", type=float, default=0.1)
    parser.add_argument("--max-depth", type=float, default=120.0)
    parser.add_argument("--init-depth", type=float, default=20.0)
    parser.add_argument("--batch-size", type=int, default=1, help="Per-GPU batch size.")
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--max-steps", type=int, default=100000)
    parser.add_argument("--trunk-lr", type=float, default=1.0e-5)
    parser.add_argument("--head-lr", type=float, default=2.0e-4)
    parser.add_argument("--weight-decay", type=float, default=0.0)
    parser.add_argument("--warmup-steps", type=int, default=1000)
    parser.add_argument("--min-lr-ratio", type=float, default=0.05)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--depth-weight", type=float, default=1.0)
    parser.add_argument("--semantic-weight", type=float, default=0.7)
    parser.add_argument("--depth-grad-weight", type=float, default=0.5)
    parser.add_argument("--depth-metric-weight", type=float, default=0.1)
    parser.add_argument("--semantic-lovasz-weight", type=float, default=0.5)
    parser.add_argument("--lovasz-downsample", type=int, default=4)
    parser.add_argument("--noise-tau", type=float, default=0.8)
    parser.add_argument("--freeze-scheme", choices=["scheme1", "scheme2", "scheme3"], default="scheme3")
    parser.add_argument("--no-gradient-checkpointing", action="store_true")
    parser.add_argument("--precision", choices=["bf16", "fp16", "fp32"], default="bf16")
    parser.add_argument("--seed", type=int, default=20260904)
    parser.add_argument("--log-every", type=int, default=25)
    parser.add_argument("--eval-every", type=int, default=1000)
    parser.add_argument("--save-every", type=int, default=2000)
    parser.add_argument("--val-samples", type=int, default=256)
    parser.add_argument("--resume", default=None)
    return parser.parse_args()


def unwrap_model(model: torch.nn.Module) -> RectRAEv2Decoder:
    return model.module if isinstance(model, DDP) else model  # type: ignore[return-value]


def make_loaders(args: argparse.Namespace, rank: int, world_size: int, distributed: bool):
    image_size = (args.height, args.width)
    train_dataset = NuScenesMultimodalDataset(
        args.train_csv,
        args.nuscenes_root,
        args.depth_root,
        args.semantic_root,
        split="train",
        image_size=image_size,
        num_classes=args.num_classes,
    )
    val_full = NuScenesMultimodalDataset(
        args.val_csv,
        args.nuscenes_root,
        args.depth_root,
        args.semantic_root,
        split="val",
        image_size=image_size,
        num_classes=args.num_classes,
    )
    val_indices = sample_fixed_indices(len(val_full), args.val_samples, args.seed)
    val_dataset = NuScenesMultimodalDataset(
        args.val_csv,
        args.nuscenes_root,
        args.depth_root,
        args.semantic_root,
        split="val",
        image_size=image_size,
        num_classes=args.num_classes,
        indices=val_indices,
    )
    train_sampler = (
        DistributedSampler(train_dataset, num_replicas=world_size, rank=rank, shuffle=True, drop_last=True)
        if distributed
        else None
    )
    val_sampler = (
        DistributedSampler(val_dataset, num_replicas=world_size, rank=rank, shuffle=False, drop_last=False)
        if distributed
        else None
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=train_sampler is None,
        sampler=train_sampler,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True,
        persistent_workers=args.num_workers > 0,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=max(1, min(args.batch_size, 4)),
        shuffle=False,
        sampler=val_sampler,
        num_workers=max(1, min(args.num_workers, 4)),
        pin_memory=True,
        drop_last=False,
        persistent_workers=args.num_workers > 0,
    )
    return train_loader, val_loader, train_sampler, val_full, val_indices


def build_optimizer(model: RectRAEv2Decoder, args: argparse.Namespace) -> torch.optim.Optimizer:
    trunk_params = []
    head_params = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if name.startswith("depth_head.") or name.startswith("semantic_head."):
            head_params.append(param)
        else:
            trunk_params.append(param)
    groups = []
    if trunk_params:
        groups.append({"params": trunk_params, "lr": args.trunk_lr, "weight_decay": args.weight_decay})
    if head_params:
        groups.append({"params": head_params, "lr": args.head_lr, "weight_decay": args.weight_decay})
    return torch.optim.AdamW(groups, betas=(0.9, 0.95))


def save_preview(
    out_dir: Path,
    step: int,
    batch: dict[str, Any],
    outputs: dict[str, torch.Tensor],
    max_items: int = 4,
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    rgb = batch["rgb"].detach().cpu()
    depth_gt = batch["depth"].detach().cpu()
    semantic_gt = batch["semantic"].detach().cpu()
    depth_pred = outputs["depth"].detach().cpu()
    semantic_pred = outputs["semantic_logits"].argmax(dim=1).detach().cpu()
    for idx in range(min(max_items, rgb.shape[0])):
        row = make_labeled_row(
            [
                tensor_to_pil(rgb[idx]),
                colorize_depth(depth_gt[idx]),
                colorize_depth(depth_pred[idx]),
                colorize_semantic(semantic_gt[idx]),
                colorize_semantic(semantic_pred[idx]),
            ],
            ["rgb", "depth gt", "depth pred", "semantic gt", "semantic pred"],
        )
        row.save(out_dir / f"step_{step:08d}_sample_{idx:02d}.jpg", quality=95)


@torch.no_grad()
def evaluate(
    model: torch.nn.Module,
    loader: DataLoader,
    args: argparse.Namespace,
    device: torch.device,
    step: int,
    preview_dir: Path | None,
    is_main: bool,
) -> dict[str, float]:
    unwrapped = unwrap_model(model)
    unwrapped.eval()
    depth_sums = {
        "count": torch.zeros((), device=device),
        "abs_rel_sum": torch.zeros((), device=device),
        "sq_sum": torch.zeros((), device=device),
        "sq_log_sum": torch.zeros((), device=device),
        "delta_1_sum": torch.zeros((), device=device),
        "delta_2_sum": torch.zeros((), device=device),
        "delta_3_sum": torch.zeros((), device=device),
    }
    confusion = torch.zeros(args.num_classes, args.num_classes, device=device, dtype=torch.float64)
    loss_sum = torch.zeros((), device=device)
    item_sum = torch.zeros((), device=device)
    preview_saved = False
    for batch in loader:
        batch = move_to_device(batch, device)
        with precision_context(device, args.precision):
            outputs = unwrapped(batch["rgb"])
            d_loss, _ = depth_loss(
                outputs["depth"].float(),
                batch["depth"].float(),
                min_depth=args.min_depth,
                max_depth=args.max_depth,
                grad_weight=args.depth_grad_weight,
                metric_weight=args.depth_metric_weight,
            )
            s_loss, _ = semantic_loss(
                outputs["semantic_logits"],
                batch["semantic"],
                lovasz_weight=args.semantic_lovasz_weight,
                lovasz_downsample=args.lovasz_downsample,
            )
            total = args.depth_weight * d_loss + args.semantic_weight * s_loss
        batch_items = torch.tensor(float(batch["rgb"].shape[0]), device=device)
        loss_sum += total.detach() * batch_items
        item_sum += batch_items
        for key, value in depth_metric_sums(
            outputs["depth"].float(),
            batch["depth"].float(),
            min_depth=args.min_depth,
            max_depth=args.max_depth,
        ).items():
            depth_sums[key] += value
        confusion += semantic_confusion_matrix(
            outputs["semantic_logits"],
            batch["semantic"],
            num_classes=args.num_classes,
        )
        if is_main and preview_dir is not None and not preview_saved:
            save_preview(preview_dir, step, batch, outputs)
            preview_saved = True
    depth_sums = all_reduce_mapping(depth_sums)
    confusion = all_reduce_tensor(confusion)
    loss_sum = all_reduce_tensor(loss_sum)
    item_sum = all_reduce_tensor(item_sum)
    metrics = {"val_loss": float((loss_sum / item_sum.clamp_min(1.0)).detach().cpu().item())}
    metrics.update(reduce_depth_sums(depth_sums))
    metrics.update(reduce_semantic_confusion(confusion))
    unwrapped.train()
    return metrics


def save_training_checkpoint(
    path: Path,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler.LRScheduler,
    step: int,
    args: argparse.Namespace,
) -> None:
    payload = {
        "step": step,
        "model": unwrap_model(model).decoder_state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict(),
        "args": vars(args),
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    save_checkpoint(path, payload)


def main() -> None:
    args = parse_args()
    dist_info = init_distributed()
    seed_everything(args.seed, dist_info.rank)
    torch.backends.cudnn.benchmark = True

    out_dir = Path(args.out_dir)
    preview_dir = out_dir / "previews"
    ckpt_dir = out_dir / "checkpoints"
    if dist_info.is_main:
        out_dir.mkdir(parents=True, exist_ok=True)
        with (out_dir / "args.json").open("w", encoding="utf-8") as handle:
            json.dump(vars(args), handle, indent=2, ensure_ascii=True)

    train_loader, val_loader, train_sampler, val_full, val_indices = make_loaders(
        args,
        dist_info.rank,
        dist_info.world_size,
        dist_info.distributed,
    )
    if dist_info.is_main:
        write_subset_manifest(out_dir / f"val_subset_{args.val_samples}.jsonl", val_full, val_indices)

    model: torch.nn.Module = RectRAEv2Decoder(
        raev2_root=args.raev2_root,
        encoder_name=args.encoder_name,
        decoder_config_path=args.decoder_config,
        decoder_ckpt_path=args.decoder_ckpt,
        stats_path=args.stats_path,
        dinov3_ckpt_dir=args.dinov3_ckpt_dir,
        dinov3_repo_dir=args.dinov3_repo_dir,
        image_size=(args.height, args.width),
        task_heads=("depth", "semantic"),
        num_classes=args.num_classes,
        min_depth=args.min_depth,
        max_depth=args.max_depth,
        init_depth=args.init_depth,
        noise_tau=args.noise_tau,
        freeze_scheme=args.freeze_scheme,
        gradient_checkpointing=not args.no_gradient_checkpointing,
    ).to(dist_info.device)
    model.train()
    if dist_info.distributed:
        model = DDP(model, device_ids=[dist_info.local_rank], output_device=dist_info.local_rank)

    optimizer = build_optimizer(unwrap_model(model), args)
    scheduler = cosine_scheduler(optimizer, args.warmup_steps, args.max_steps, args.min_lr_ratio)
    scaler = make_grad_scaler(args.precision)
    start_step = 0
    if args.resume:
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
        unwrap_model(model).load_decoder_state_dict(checkpoint["model"], strict=False)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_step = int(checkpoint["step"])

    if dist_info.is_main:
        print(
            f"RAEv2 depth/semantic start: world_size={dist_info.world_size} batch_per_gpu={args.batch_size} "
            f"freeze={args.freeze_scheme} trainable_params={unwrap_model(model).trainable_parameter_count()} "
            f"noise_tau={args.noise_tau} out={out_dir}",
            flush=True,
        )
    barrier()

    epoch = 0
    train_iter = iter(train_loader)
    for step in range(start_step + 1, args.max_steps + 1):
        try:
            batch = next(train_iter)
        except StopIteration:
            epoch += 1
            if train_sampler is not None:
                train_sampler.set_epoch(epoch)
            train_iter = iter(train_loader)
            batch = next(train_iter)
        batch = move_to_device(batch, dist_info.device)
        optimizer.zero_grad(set_to_none=True)
        with precision_context(dist_info.device, args.precision):
            outputs = model(batch["rgb"])
            d_loss, d_stats = depth_loss(
                outputs["depth"].float(),
                batch["depth"].float(),
                min_depth=args.min_depth,
                max_depth=args.max_depth,
                grad_weight=args.depth_grad_weight,
                metric_weight=args.depth_metric_weight,
            )
            s_loss, s_stats = semantic_loss(
                outputs["semantic_logits"],
                batch["semantic"],
                lovasz_weight=args.semantic_lovasz_weight,
                lovasz_downsample=args.lovasz_downsample,
            )
            loss = args.depth_weight * d_loss + args.semantic_weight * s_loss
        scaler.scale(loss).backward()
        if args.grad_clip > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(unwrap_model(model).parameters(), args.grad_clip)
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()

        if step % args.log_every == 0 or step == 1:
            row: dict[str, Any] = {
                "step": step,
                "epoch": epoch,
                "loss": float((all_reduce_tensor(loss.detach().float()) / dist_info.world_size).cpu().item()),
                "lr_trunk": optimizer.param_groups[0]["lr"],
                "lr_head": optimizer.param_groups[-1]["lr"],
            }
            for stat_map in (d_stats, s_stats):
                for key, value in stat_map.items():
                    row[key] = float((all_reduce_tensor(value.detach().float()) / dist_info.world_size).cpu().item())
            row.update(current_gpu_memory())
            if dist_info.is_main:
                append_jsonl(out_dir / "train_log.jsonl", row)
                print(json.dumps(row, ensure_ascii=True), flush=True)

        if args.eval_every > 0 and (step % args.eval_every == 0 or step == 1):
            metrics = evaluate(
                model,
                val_loader,
                args,
                dist_info.device,
                step,
                preview_dir if dist_info.is_main else None,
                dist_info.is_main,
            )
            if dist_info.is_main:
                row = {"step": step, **metrics, **current_gpu_memory()}
                append_jsonl(out_dir / "val_log.jsonl", row)
                print("VAL " + json.dumps(row, ensure_ascii=True), flush=True)

        if dist_info.is_main and args.save_every > 0 and (step % args.save_every == 0 or step == args.max_steps):
            save_training_checkpoint(ckpt_dir / "last.pt", model, optimizer, scheduler, step, args)
            save_training_checkpoint(ckpt_dir / f"step_{step:08d}.pt", model, optimizer, scheduler, step, args)

    cleanup_distributed()


if __name__ == "__main__":
    main()
