from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler


THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.raev2_decoder import RectRAEv2Decoder  # noqa: E402
from multimodal_decoders.data import (  # noqa: E402
    NuScenesMultimodalDataset,
    sample_fixed_indices,
    write_subset_manifest,
)
from multimodal_decoders.metrics import psnr_from_mse, rgb_mse_sum, ssim_index  # noqa: E402
from multimodal_decoders.train_utils import (  # noqa: E402
    all_reduce_tensor,
    append_jsonl,
    barrier,
    cleanup_distributed,
    cosine_scheduler,
    current_gpu_memory,
    init_distributed,
    make_grad_scaler,
    make_labeled_row,
    move_to_device,
    precision_context,
    save_checkpoint,
    seed_everything,
    tensor_to_pil,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fine-tune the RAEv2 DINOv3-B k6 RGB decoder on nuScenes.")
    parser.add_argument("--train-csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv")
    parser.add_argument("--val-csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv")
    parser.add_argument("--nuscenes-root", default="/data2/DATA/AutoDrive/nuscenes/v1.0-trainval")
    parser.add_argument("--raev2-root", default="../RAEv2-main")
    parser.add_argument("--encoder-name", default="dinov3mls-vit-b16[layers=6.7.8.9.10.11]")
    parser.add_argument("--dinov3-ckpt-dir", default="pretrained_models/encoders/dinov3")
    parser.add_argument("--dinov3-repo-dir", default=None)
    parser.add_argument("--decoder-config", default="configs/decoder/ViTXL")
    parser.add_argument("--decoder-ckpt", default="pretrained_models/stage1/imagenet/dinov3b-k6/decoder.pt")
    parser.add_argument("--stats-path", default="pretrained_models/stage1/nuscenes-512/stats.pt")
    parser.add_argument("--disc-dino-ckpt", default="pretrained_models/encoders/dino/dino_vit_small_patch8_224.pth")
    parser.add_argument("--out-dir", default="/data/wlh/DeltaWorld/outputs/raev2_nuscenes_decoders/rgb")
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--width", type=int, default=832)
    parser.add_argument("--batch-size", type=int, default=1, help="Per-GPU batch size.")
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--max-steps", type=int, default=20000)
    parser.add_argument("--trunk-lr", type=float, default=1.0e-5)
    parser.add_argument("--head-lr", type=float, default=1.0e-5)
    parser.add_argument("--disc-lr", type=float, default=2.0e-4)
    parser.add_argument("--weight-decay", type=float, default=0.0)
    parser.add_argument("--warmup-steps", type=int, default=500)
    parser.add_argument("--min-lr-ratio", type=float, default=0.1)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--rec-weight", type=float, default=1.0)
    parser.add_argument("--lpips-weight", type=float, default=1.0)
    parser.add_argument("--disc-weight", type=float, default=0.75)
    parser.add_argument("--gan-start-step", type=int, default=8000)
    parser.add_argument("--disc-update-start-step", type=int, default=6000)
    parser.add_argument("--disc-updates", type=int, default=1)
    parser.add_argument("--disc-loss", choices=["hinge", "vanilla"], default="hinge")
    parser.add_argument("--gen-loss", choices=["vanilla"], default="vanilla")
    parser.add_argument("--disc-aug-prob", type=float, default=1.0)
    parser.add_argument("--disc-aug-cutout", type=float, default=0.0)
    parser.add_argument("--max-d-weight", type=float, default=10000.0)
    parser.add_argument("--noise-tau", type=float, default=0.8)
    parser.add_argument("--freeze-scheme", choices=["scheme1", "scheme2", "scheme3"], default="scheme3")
    parser.add_argument("--no-gradient-checkpointing", action="store_true")
    parser.add_argument("--precision", choices=["bf16", "fp16", "fp32"], default="bf16")
    parser.add_argument("--seed", type=int, default=20260904)
    parser.add_argument("--log-every", type=int, default=25)
    parser.add_argument("--eval-every", type=int, default=500)
    parser.add_argument("--save-every", type=int, default=1000)
    parser.add_argument("--val-samples", type=int, default=256)
    parser.add_argument("--resume", default=None)
    return parser.parse_args()


def unwrap_model(model: torch.nn.Module) -> RectRAEv2Decoder:
    return model.module if isinstance(model, DDP) else model  # type: ignore[return-value]


def make_loaders(args: argparse.Namespace, rank: int, world_size: int, distributed: bool):
    image_size = (args.height, args.width)
    train_dataset = NuScenesMultimodalDataset(
        args.train_csv,
        args.nuscenes_root,
        depth_root=None,
        semantic_root=None,
        split="train",
        image_size=image_size,
        load_rgb=True,
        load_depth=False,
        load_semantic=False,
    )
    val_full = NuScenesMultimodalDataset(
        args.val_csv,
        args.nuscenes_root,
        depth_root=None,
        semantic_root=None,
        split="val",
        image_size=image_size,
        load_rgb=True,
        load_depth=False,
        load_semantic=False,
    )
    val_indices = sample_fixed_indices(len(val_full), args.val_samples, args.seed)
    val_dataset = NuScenesMultimodalDataset(
        args.val_csv,
        args.nuscenes_root,
        depth_root=None,
        semantic_root=None,
        split="val",
        image_size=image_size,
        load_rgb=True,
        load_depth=False,
        load_semantic=False,
        indices=val_indices,
    )
    train_sampler = (
        DistributedSampler(train_dataset, num_replicas=world_size, rank=rank, shuffle=True, drop_last=True)
        if distributed
        else None
    )
    val_sampler = (
        DistributedSampler(val_dataset, num_replicas=world_size, rank=rank, shuffle=False, drop_last=False)
        if distributed
        else None
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=train_sampler is None,
        sampler=train_sampler,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True,
        persistent_workers=args.num_workers > 0,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=max(1, min(args.batch_size, 4)),
        shuffle=False,
        sampler=val_sampler,
        num_workers=max(1, min(args.num_workers, 4)),
        pin_memory=True,
        drop_last=False,
        persistent_workers=args.num_workers > 0,
    )
    return train_loader, val_loader, train_sampler, val_full, val_indices


def build_optimizer(model: RectRAEv2Decoder, args: argparse.Namespace) -> torch.optim.Optimizer:
    trunk_params = []
    head_params = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if name.startswith("rgb_head."):
            head_params.append(param)
        else:
            trunk_params.append(param)
    groups = []
    if trunk_params:
        groups.append({"params": trunk_params, "lr": args.trunk_lr, "weight_decay": args.weight_decay})
    if head_params:
        groups.append({"params": head_params, "lr": args.head_lr, "weight_decay": args.weight_decay})
    return torch.optim.AdamW(groups, betas=(0.9, 0.95))


def save_rgb_preview(out_dir: Path, step: int, batch: dict[str, Any], pred: torch.Tensor, max_items: int = 4) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    target = batch["rgb"].detach().cpu()
    pred = pred.detach().cpu().clamp(0.0, 1.0)
    for idx in range(min(max_items, target.shape[0])):
        err = (pred[idx] - target[idx]).abs().mean(dim=0, keepdim=True).repeat(3, 1, 1).clamp(0.0, 1.0)
        row = make_labeled_row(
            [tensor_to_pil(target[idx]), tensor_to_pil(pred[idx]), tensor_to_pil(err)],
            ["rgb target", "rgb reconstruction", "abs error"],
        )
        row.save(out_dir / f"step_{step:08d}_sample_{idx:02d}.jpg", quality=95)


@torch.no_grad()
def evaluate(
    model: torch.nn.Module,
    loader: DataLoader,
    args: argparse.Namespace,
    device: torch.device,
    step: int,
    preview_dir: Path | None,
    is_main: bool,
) -> dict[str, float]:
    unwrapped = unwrap_model(model)
    unwrapped.eval()
    mse_sum = torch.zeros((), device=device)
    pixel_sum = torch.zeros((), device=device)
    ssim_sum = torch.zeros((), device=device)
    image_sum = torch.zeros((), device=device)
    l1_sum = torch.zeros((), device=device)
    preview_saved = False
    for batch in loader:
        batch = move_to_device(batch, device)
        with precision_context(device, args.precision):
            pred = unwrapped(batch["rgb"])["rgb"]
        mse, pixels = rgb_mse_sum(pred, batch["rgb"])
        mse_sum += mse
        pixel_sum += pixels
        ssim_values = ssim_index(pred, batch["rgb"])
        ssim_sum += ssim_values.sum()
        image_sum += torch.tensor(float(ssim_values.numel()), device=device)
        l1_sum += F.l1_loss(pred.float().clamp(0.0, 1.0), batch["rgb"].float(), reduction="sum")
        if is_main and preview_dir is not None and not preview_saved:
            save_rgb_preview(preview_dir, step, batch, pred)
            preview_saved = True
    mse_sum = all_reduce_tensor(mse_sum)
    pixel_sum = all_reduce_tensor(pixel_sum)
    ssim_sum = all_reduce_tensor(ssim_sum)
    image_sum = all_reduce_tensor(image_sum)
    l1_sum = all_reduce_tensor(l1_sum)
    mse = float((mse_sum / pixel_sum.clamp_min(1.0)).detach().cpu().item())
    ssim = float((ssim_sum / image_sum.clamp_min(1.0)).detach().cpu().item())
    l1 = float((l1_sum / pixel_sum.clamp_min(1.0)).detach().cpu().item())
    unwrapped.train()
    return {"val_rgb_mse": mse, "val_rgb_psnr": psnr_from_mse(mse), "val_rgb_ssim": ssim, "val_rgb_l1": l1}


def ensure_raev2_src(raev2_root: str) -> None:
    src = str((PROJECT_ROOT / raev2_root).resolve() / "src") if not Path(raev2_root).is_absolute() else str(Path(raev2_root) / "src")
    if src not in sys.path:
        sys.path.insert(0, src)


def maybe_build_lpips(args: argparse.Namespace, device: torch.device):
    if args.lpips_weight <= 0:
        return None
    ensure_raev2_src(args.raev2_root)
    from stage1.disc.lpips import LPIPS

    return LPIPS().to(device).eval()


def maybe_build_discriminator(args: argparse.Namespace, device: torch.device):
    if args.disc_weight <= 0:
        return None, None, None, None
    ensure_raev2_src(args.raev2_root)
    from stage1.disc.diffaug import DiffAug
    from stage1.disc.discriminator import DinoDiscriminator
    from stage1.disc.gan_loss import select_gan_losses

    raev2_root = Path(args.raev2_root)
    if not raev2_root.is_absolute():
        raev2_root = (PROJECT_ROOT / raev2_root).resolve()
    disc_ckpt = Path(args.disc_dino_ckpt)
    if not disc_ckpt.is_absolute():
        disc_ckpt = (raev2_root / disc_ckpt).resolve()
    disc = DinoDiscriminator(
        device=device,
        dino_ckpt_path=str(disc_ckpt),
        ks=9,
        norm_type="bn",
        using_spec_norm=True,
        recipe="S_8",
    ).to(device)
    disc_aug = DiffAug(prob=args.disc_aug_prob, cutout=args.disc_aug_cutout)
    disc_loss_fn, gen_loss_fn = select_gan_losses(args.disc_loss, args.gen_loss)
    return disc, disc_aug, disc_loss_fn, gen_loss_fn


def calculate_adaptive_weight(
    recon_loss: torch.Tensor,
    gan_loss: torch.Tensor,
    layer: torch.nn.Parameter,
    max_d_weight: float,
) -> torch.Tensor:
    recon_grads = torch.autograd.grad(recon_loss, layer, retain_graph=True)[0]
    gan_grads = torch.autograd.grad(gan_loss, layer, retain_graph=True)[0]
    d_weight = torch.norm(recon_grads) / (torch.norm(gan_grads) + 1.0e-6)
    return torch.clamp(d_weight, 0.0, float(max_d_weight)).detach()


def broadcast_stop(stop: bool, device: torch.device) -> bool:
    value = torch.tensor(1 if stop else 0, device=device, dtype=torch.int64)
    if dist.is_available() and dist.is_initialized():
        dist.broadcast(value, src=0)
    return bool(value.item())


def save_training_checkpoint(
    path: Path,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler.LRScheduler,
    disc,
    disc_optimizer,
    step: int,
    args: argparse.Namespace,
) -> None:
    payload = {
        "step": step,
        "model": unwrap_model(model).decoder_state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict(),
        "args": vars(args),
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    if disc is not None:
        payload["discriminator"] = disc.state_dict()
    if disc_optimizer is not None:
        payload["disc_optimizer"] = disc_optimizer.state_dict()
    save_checkpoint(path, payload)


def main() -> None:
    args = parse_args()
    dist_info = init_distributed()
    seed_everything(args.seed, dist_info.rank)
    torch.backends.cudnn.benchmark = True

    out_dir = Path(args.out_dir)
    ckpt_dir = out_dir / "checkpoints"
    preview_dir = out_dir / "previews"
    if dist_info.is_main:
        out_dir.mkdir(parents=True, exist_ok=True)
        with (out_dir / "args.json").open("w", encoding="utf-8") as handle:
            json.dump(vars(args), handle, indent=2, ensure_ascii=True)

    train_loader, val_loader, train_sampler, val_full, val_indices = make_loaders(
        args,
        dist_info.rank,
        dist_info.world_size,
        dist_info.distributed,
    )
    if dist_info.is_main:
        write_subset_manifest(out_dir / f"val_subset_{args.val_samples}.jsonl", val_full, val_indices)

    model: torch.nn.Module = RectRAEv2Decoder(
        raev2_root=args.raev2_root,
        encoder_name=args.encoder_name,
        decoder_config_path=args.decoder_config,
        decoder_ckpt_path=args.decoder_ckpt,
        stats_path=args.stats_path,
        dinov3_ckpt_dir=args.dinov3_ckpt_dir,
        dinov3_repo_dir=args.dinov3_repo_dir,
        image_size=(args.height, args.width),
        task_heads=("rgb",),
        noise_tau=args.noise_tau,
        freeze_scheme=args.freeze_scheme,
        gradient_checkpointing=not args.no_gradient_checkpointing,
    ).to(dist_info.device)
    model.train()

    if dist_info.distributed:
        model = DDP(model, device_ids=[dist_info.local_rank], output_device=dist_info.local_rank)
    optimizer = build_optimizer(unwrap_model(model), args)
    scheduler = cosine_scheduler(optimizer, args.warmup_steps, args.max_steps, args.min_lr_ratio)
    scaler = make_grad_scaler(args.precision)
    lpips_model = maybe_build_lpips(args, dist_info.device)
    disc, disc_aug, disc_loss_fn, gen_loss_fn = maybe_build_discriminator(args, dist_info.device)
    disc_optimizer = (
        torch.optim.AdamW([p for p in disc.parameters() if p.requires_grad], lr=args.disc_lr, betas=(0.9, 0.95), weight_decay=0.0)
        if disc is not None
        else None
    )
    start_step = 0
    if args.resume:
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
        unwrap_model(model).load_decoder_state_dict(checkpoint["model"], strict=False)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        if disc is not None and "discriminator" in checkpoint:
            disc.load_state_dict(checkpoint["discriminator"], strict=True)
        if disc_optimizer is not None and "disc_optimizer" in checkpoint:
            disc_optimizer.load_state_dict(checkpoint["disc_optimizer"])
        start_step = int(checkpoint["step"])

    if dist_info.is_main:
        print(
            f"RAEv2 RGB start: world_size={dist_info.world_size} batch_per_gpu={args.batch_size} "
            f"freeze={args.freeze_scheme} trainable_params={unwrap_model(model).trainable_parameter_count()} "
            f"noise_tau={args.noise_tau} out={out_dir}",
            flush=True,
        )
    barrier()

    epoch = 0
    train_iter = iter(train_loader)
    for step in range(start_step + 1, args.max_steps + 1):
        try:
            batch = next(train_iter)
        except StopIteration:
            epoch += 1
            if train_sampler is not None:
                train_sampler.set_epoch(epoch)
            train_iter = iter(train_loader)
            batch = next(train_iter)
        batch = move_to_device(batch, dist_info.device)
        real = batch["rgb"]
        real_normed = real * 2.0 - 1.0

        optimizer.zero_grad(set_to_none=True)
        if disc is not None:
            disc.eval()
        use_gan = disc is not None and step >= args.gan_start_step

        with precision_context(dist_info.device, args.precision):
            recon = model(real)["rgb"]
            recon_normed = recon * 2.0 - 1.0
            rec_loss = F.l1_loss(recon.float(), real.float())
            if lpips_model is not None:
                lpips_loss = lpips_model(real_normed, recon_normed)
            else:
                lpips_loss = rec_loss.new_zeros(())
            recon_total = args.rec_weight * rec_loss + args.lpips_weight * lpips_loss
            if use_gan:
                fake_aug = disc_aug.aug(recon_normed)
                logits_fake, _ = disc(fake_aug, None)
                gan_loss = gen_loss_fn(logits_fake)
            else:
                gan_loss = recon_total.new_zeros(())

        if use_gan:
            last_layer = unwrap_model(model).rgb_head.proj.weight
            adaptive_weight = calculate_adaptive_weight(recon_total, gan_loss, last_layer, args.max_d_weight)
            loss = recon_total + args.disc_weight * adaptive_weight * gan_loss
        else:
            adaptive_weight = recon_total.new_zeros(())
            loss = recon_total

        scaler.scale(loss).backward()
        if args.grad_clip > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(unwrap_model(model).parameters(), args.grad_clip)
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()

        disc_metrics: dict[str, torch.Tensor] = {}
        if disc is not None and disc_optimizer is not None and step >= args.disc_update_start_step:
            unwrap_model(model).eval()
            disc.train()
            for _ in range(args.disc_updates):
                disc_optimizer.zero_grad(set_to_none=True)
                with precision_context(dist_info.device, args.precision):
                    with torch.no_grad():
                        recon_disc = model(real)["rgb"]
                        recon_disc_normed = recon_disc * 2.0 - 1.0
                    fake_detached = recon_disc_normed.clamp(-1.0, 1.0)
                    fake_detached = torch.round((fake_detached + 1.0) * 127.5) / 127.5 - 1.0
                    fake_input = disc_aug.aug(fake_detached)
                    real_input = disc_aug.aug(real_normed)
                    logits_fake, logits_real = disc(fake_input, real_input)
                    d_loss = disc_loss_fn(logits_real, logits_fake)
                    accuracy = (logits_real > logits_fake).float().mean()
                d_loss.backward()
                disc_optimizer.step()
                disc_metrics = {
                    "disc_loss": d_loss.detach(),
                    "disc_accuracy": accuracy.detach(),
                    "logits_real": logits_real.detach().mean(),
                    "logits_fake": logits_fake.detach().mean(),
                }
            unwrap_model(model).train()

        if step % args.log_every == 0 or step == 1:
            row: dict[str, Any] = {
                "step": step,
                "epoch": epoch,
                "loss": float((all_reduce_tensor(loss.detach().float()) / dist_info.world_size).cpu().item()),
                "recon_l1": float((all_reduce_tensor(rec_loss.detach().float()) / dist_info.world_size).cpu().item()),
                "lpips": float((all_reduce_tensor(lpips_loss.detach().float()) / dist_info.world_size).cpu().item()),
                "gan": float((all_reduce_tensor(gan_loss.detach().float()) / dist_info.world_size).cpu().item()),
                "adaptive_weight": float(adaptive_weight.detach().float().cpu().item()),
                "lr_trunk": optimizer.param_groups[0]["lr"],
                "lr_head": optimizer.param_groups[-1]["lr"],
            }
            for key, value in disc_metrics.items():
                row[key] = float((all_reduce_tensor(value.detach().float()) / dist_info.world_size).cpu().item())
            row.update(current_gpu_memory())
            if dist_info.is_main:
                append_jsonl(out_dir / "train_log.jsonl", row)
                print(json.dumps(row, ensure_ascii=True), flush=True)

        if args.eval_every > 0 and (step % args.eval_every == 0 or step == 1):
            metrics = evaluate(
                model,
                val_loader,
                args,
                dist_info.device,
                step,
                preview_dir if dist_info.is_main else None,
                dist_info.is_main,
            )
            if dist_info.is_main:
                row = {"step": step, **metrics, **current_gpu_memory()}
                append_jsonl(out_dir / "val_log.jsonl", row)
                print("VAL " + json.dumps(row, ensure_ascii=True), flush=True)

        if dist_info.is_main and args.save_every > 0 and (step % args.save_every == 0 or step == args.max_steps):
            save_training_checkpoint(
                ckpt_dir / "last.pt",
                model,
                optimizer,
                scheduler,
                disc,
                disc_optimizer,
                step,
                args,
            )
            save_training_checkpoint(
                ckpt_dir / f"step_{step:08d}.pt",
                model,
                optimizer,
                scheduler,
                disc,
                disc_optimizer,
                step,
                args,
            )
        _ = broadcast_stop(False, dist_info.device)

    cleanup_distributed()


if __name__ == "__main__":
    main()
