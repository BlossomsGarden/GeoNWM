# Remote Server Notes

This branch was uploaded and smoke-tested on the server described by the
baseline `REMOTE_SERVER.md`.

Remote paths:

```text
/data/wlh/DeltaWorld/deltatok-nuscenes-RAEv2
/data/wlh/DeltaWorld/RAEv2-main
/data/wlh/DeltaWorld/model/RAEv2
```

The default config uses paths relative to `../RAEv2-main`. On the server,
`/data/wlh/DeltaWorld/RAEv2-main/pretrained_models` is a symlink to
`/data/wlh/DeltaWorld/model/RAEv2`.

Required model files:

```text
/data/wlh/DeltaWorld/model/RAEv2/encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m-73cec8be.pth
/data/wlh/DeltaWorld/model/RAEv2/stage1/imagenet/dinov3b-k6/decoder.pt
/data/wlh/DeltaWorld/model/RAEv2/stage1/imagenet/dinov3b-k6/stats.pt
```

Install the extra RAEv2 encoder dependency without changing the Torch stack:

```bash
/data/wlh/miniconda3/envs/deltaworld/bin/python -m pip install \
  'timm>=1.0.16' \
  -i https://pypi.tuna.tsinghua.edu.cn/simple
```

Download weights through the HF mirror:

```bash
mkdir -p /data/wlh/DeltaWorld/model/RAEv2
HF_ENDPOINT=https://hf-mirror.com \
  /data/wlh/miniconda3/envs/deltaworld/bin/hf download nyu-visionx/RAEv2-models \
  --include "encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m-73cec8be.pth" \
  --include "stage1/imagenet/dinov3b-k6/**" \
  --exclude .gitattributes \
  --local-dir /data/wlh/DeltaWorld/model/RAEv2

ln -s /data/wlh/DeltaWorld/model/RAEv2 \
  /data/wlh/DeltaWorld/RAEv2-main/pretrained_models
```

The DeltaTok config keeps the original nuScenes CSV and root paths:

```text
/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv
/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv
/data2/DATA/AutoDrive/nuscenes/v1.0-trainval
```

Single-GPU smoke test used during setup:

```bash
cd /data/wlh/DeltaWorld/deltatok-nuscenes-RAEv2
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate deltaworld
export CUDA_VISIBLE_DEVICES=0
export WANDB_MODE=disabled

python main.py fit \
  -c configs/deltatok_nuscenes_512.yaml \
  --trainer.devices=1 \
  --trainer.strategy=auto \
  --trainer.fast_dev_run=1
```

The only migrated training line is the 512 config.
