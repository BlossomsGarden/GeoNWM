from __future__ import annotations

import csv
import json
import logging
import math
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import ijson
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

from datasets.base import as_hw, resize_then_principal_crop


CAM_FRONT_NAMES = {"FRONT", "CAM_FRONT"}


@dataclass(frozen=True)
class SampleRow:
    scene_id: str
    frame_id: int
    file: str
    ego_pose_token: str


def _load_token_map(path: Path) -> dict[str, dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return {item["token"]: item for item in json.load(handle)}


def _load_selected_token_map(
    path: Path, tokens: set[str]
) -> dict[str, dict[str, Any]]:
    remaining = set(tokens)
    selected: dict[str, dict[str, Any]] = {}
    with path.open("rb") as handle:
        for item in ijson.items(handle, "item"):
            token = item.get("token")
            if token not in remaining:
                continue
            selected[token] = item
            remaining.remove(token)
            if not remaining:
                break
    if remaining:
        examples = sorted(remaining)[:5]
        raise KeyError(
            f"{path} is missing {len(remaining)} requested tokens; examples: {examples}"
        )
    return selected


@lru_cache(maxsize=4)
def _load_cam_front_intrinsics(
    sample_data_path_str: str, calibrated_sensor_path_str: str
) -> dict[str, np.ndarray]:
    sample_data_path = Path(sample_data_path_str)
    calibrated_sensor_path = Path(calibrated_sensor_path_str)
    if not sample_data_path.exists() or not calibrated_sensor_path.exists():
        return {}

    calibrated = _load_token_map(calibrated_sensor_path)
    intrinsics: dict[str, np.ndarray] = {}
    with sample_data_path.open("rb") as handle:
        for item in ijson.items(handle, "item"):
            filename = str(item.get("filename", ""))
            if "CAM_FRONT" not in Path(filename).parts:
                continue
            sensor = calibrated.get(item.get("calibrated_sensor_token"))
            matrix = sensor.get("camera_intrinsic") if sensor else None
            if not matrix:
                continue
            value = np.asarray(matrix, dtype=np.float32)
            intrinsics[filename] = value
            intrinsics[Path(filename).name] = value
    return intrinsics


def _quat_to_rotation(quaternion: list[float]) -> np.ndarray:
    w, x, y, z = map(float, quaternion)
    return np.asarray(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def compute_action(prev_pose: dict[str, Any], curr_pose: dict[str, Any]) -> torch.Tensor:
    """Return [forward meters, lateral meters, relative yaw degrees]."""
    prev_rotation = _quat_to_rotation(prev_pose["rotation"])
    curr_rotation = _quat_to_rotation(curr_pose["rotation"])
    delta_global = np.asarray(curr_pose["translation"], dtype=np.float64) - np.asarray(
        prev_pose["translation"], dtype=np.float64
    )
    delta_prev = prev_rotation.T @ delta_global
    relative_rotation = prev_rotation.T @ curr_rotation
    delta_yaw = math.degrees(
        math.atan2(relative_rotation[1, 0], relative_rotation[0, 0])
    )
    return torch.tensor(
        [delta_prev[0], delta_prev[1], delta_yaw], dtype=torch.float32
    )


class _NuScenesPairDataset(Dataset):
    def __init__(
        self,
        csv_path: str,
        nuscenes_root: str,
        frame_size: int | tuple[int, int] = 256,
        ego_pose_path: str | None = None,
        sample_data_path: str | None = None,
        calibrated_sensor_path: str | None = None,
    ) -> None:
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.frame_size = as_hw(frame_size)
        metadata_root = self.nuscenes_root / "v1.0-trainval"
        self.ego_pose_path = Path(ego_pose_path or metadata_root / "ego_pose.json")
        self.sample_data_path = Path(
            sample_data_path or metadata_root / "sample_data.json"
        )
        self.calibrated_sensor_path = Path(
            calibrated_sensor_path or metadata_root / "calibrated_sensor.json"
        )
        rows_by_scene = self._build_rows()
        pose_tokens = {
            row.ego_pose_token
            for rows in rows_by_scene.values()
            for row in rows
        }
        self.ego_poses = _load_selected_token_map(self.ego_pose_path, pose_tokens)
        self.intrinsics_by_file = self._load_intrinsics()
        self.pairs = self._build_pairs(rows_by_scene)

    def _load_intrinsics(self) -> dict[str, np.ndarray]:
        intrinsics = _load_cam_front_intrinsics(
            str(self.sample_data_path.resolve()),
            str(self.calibrated_sensor_path.resolve()),
        )
        if not intrinsics:
            logging.warning(
                "No CAM_FRONT intrinsics loaded from %s; falling back to centered crops",
                self.sample_data_path,
            )
        return intrinsics

    def _resolve_image_path(self, filename: str) -> Path:
        path = Path(filename)
        if path.is_absolute():
            return path
        candidates = (
            self.nuscenes_root / path,
            self.nuscenes_root / "samples" / "CAM_FRONT" / path.name,
        )
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(
            f"Could not resolve CSV image path {filename!r}; tried {candidates}"
        )

    def _build_rows(self) -> dict[str, list[SampleRow]]:
        grouped: dict[str, list[SampleRow]] = {}
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            for raw in csv.DictReader(handle):
                if raw.get("cam") not in CAM_FRONT_NAMES:
                    continue
                filename = raw["file"]
                row = SampleRow(
                    scene_id=raw["scene_id"],
                    frame_id=int(raw["frame_id"]),
                    file=filename,
                    ego_pose_token=raw["ego_pose_token"],
                )
                grouped.setdefault(row.scene_id, []).append(row)
        for rows in grouped.values():
            rows.sort(key=lambda row: row.frame_id)
        return grouped

    def _build_pairs(
        self, rows_by_scene: dict[str, list[SampleRow]]
    ) -> list[tuple[SampleRow, SampleRow]]:
        pairs: list[tuple[SampleRow, SampleRow]] = []
        for rows in rows_by_scene.values():
            for prev, curr in zip(rows, rows[1:]):
                if curr.frame_id != prev.frame_id + 1:
                    continue
                pairs.append((prev, curr))
        if not pairs:
            raise ValueError(f"No consecutive CAM_FRONT pairs found in {self.csv_path}")
        return pairs

    def __len__(self) -> int:
        return len(self.pairs)

    def _load_frame(self, row: SampleRow) -> torch.Tensor:
        image_path = self._resolve_image_path(row.file)
        with Image.open(image_path) as image:
            image = np.asarray(image.convert("RGB"))
        intrinsic = self.intrinsics_by_file.get(row.file)
        if intrinsic is None:
            intrinsic = self.intrinsics_by_file.get(Path(row.file).name)
        image = resize_then_principal_crop(image, intrinsic, self.frame_size)
        return torch.from_numpy(image.copy()).permute(2, 0, 1)

    def __getitem__(self, idx: int):
        prev, curr = self.pairs[idx]
        frames = torch.stack((self._load_frame(prev), self._load_frame(curr)))
        action = compute_action(
            self.ego_poses[prev.ego_pose_token],
            self.ego_poses[curr.ego_pose_token],
        )
        return frames, action


class NuScenesTrain(_NuScenesPairDataset):
    pass


class NuScenesVal(_NuScenesPairDataset):
    def __getitem__(self, idx: int):
        frames, action = super().__getitem__(idx)
        return frames, action, idx
