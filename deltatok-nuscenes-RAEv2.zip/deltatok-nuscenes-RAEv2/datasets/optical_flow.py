from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F


FLOW_KEYS = (
    "flow",
    "residual_flow",
    "optical_flow",
    "scene_flow",
    "scene_flow_2d",
)
MASK_KEYS = (
    "valid_mask",
    "mask",
    "valid",
    "flow_mask",
    "valid_flow_mask",
)


def as_hw(size: int | tuple[int, int]) -> tuple[int, int]:
    if isinstance(size, int):
        return size, size
    h, w = size
    return int(h), int(w)


def _coerce_flow_tensor(flow: Any) -> torch.Tensor:
    if isinstance(flow, torch.Tensor):
        tensor = flow.detach().cpu()
    else:
        tensor = torch.as_tensor(np.asarray(flow))
    tensor = tensor.float()
    if tensor.ndim == 4 and tensor.shape[0] == 1:
        tensor = tensor[0]
    if tensor.ndim != 3:
        raise ValueError(f"Expected flow tensor with 3 dims, got {tuple(tensor.shape)}")
    if tensor.shape[0] == 2:
        return tensor
    if tensor.shape[-1] == 2:
        return tensor.permute(2, 0, 1).contiguous()
    raise ValueError(f"Expected flow tensor shaped [2,H,W] or [H,W,2], got {tuple(tensor.shape)}")


def _coerce_mask_tensor(mask: Any, spatial_size: tuple[int, int]) -> torch.Tensor:
    if mask is None:
        return torch.ones(spatial_size, dtype=torch.bool)
    if isinstance(mask, torch.Tensor):
        tensor = mask.detach().cpu()
    else:
        tensor = torch.as_tensor(np.asarray(mask))
    if tensor.ndim == 3 and tensor.shape[0] == 1:
        tensor = tensor[0]
    if tensor.ndim != 2:
        raise ValueError(f"Expected mask tensor with 2 dims, got {tuple(tensor.shape)}")
    if tensor.shape != spatial_size:
        raise ValueError(
            f"Expected mask spatial size {spatial_size}, got {tuple(tensor.shape)}"
        )
    return tensor.bool()


def _extract_value(data: Any, keys: tuple[str, ...]) -> Any:
    if isinstance(data, dict):
        for key in keys:
            if key in data:
                return data[key]
    return None


def load_residual_flow_sample(path: str | Path) -> tuple[torch.Tensor, torch.Tensor]:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".pt", ".pth"}:
        data = torch.load(path, map_location="cpu")
    elif suffix == ".npz":
        with np.load(path, allow_pickle=True) as handle:
            data = {key: handle[key] for key in handle.files}
    elif suffix == ".npy":
        data = np.load(path, allow_pickle=True)
    else:
        raise ValueError(f"Unsupported residual-flow file format: {path}")

    flow = _extract_value(data, FLOW_KEYS)
    if flow is None:
        flow = data
    flow_tensor = _coerce_flow_tensor(flow)

    mask = _extract_value(data, MASK_KEYS)
    mask_tensor = _coerce_mask_tensor(mask, flow_tensor.shape[-2:])
    return flow_tensor, mask_tensor


def build_motion_mask(
    flow: torch.Tensor,
    valid_mask: torch.Tensor | None = None,
    quantile: float = 0.9,
) -> torch.Tensor:
    if flow.ndim != 3 or flow.shape[0] != 2:
        raise ValueError(f"Expected flow [2,H,W], got {tuple(flow.shape)}")
    magnitude = torch.linalg.vector_norm(flow.float(), dim=0)
    if valid_mask is None:
        valid_mask = torch.ones_like(magnitude, dtype=torch.bool)
    else:
        valid_mask = valid_mask.bool()
        if valid_mask.shape != magnitude.shape:
            raise ValueError(
                f"Expected valid mask {tuple(magnitude.shape)}, got {tuple(valid_mask.shape)}"
            )
    valid_magnitude = magnitude[valid_mask]
    if valid_magnitude.numel() == 0:
        raise ValueError("Residual-flow cache has no valid pixels")
    threshold = torch.quantile(valid_magnitude.float(), quantile)
    return (magnitude >= threshold) & valid_mask


def downsample_residual_flow(
    flow: torch.Tensor,
    mask: torch.Tensor | None,
    target_size: int | tuple[int, int],
) -> tuple[torch.Tensor, torch.Tensor]:
    target_h, target_w = as_hw(target_size)
    if flow.ndim != 3 or flow.shape[0] != 2:
        raise ValueError(f"Expected flow [2,H,W], got {tuple(flow.shape)}")
    source_h, source_w = flow.shape[-2:]
    flow_4d = flow.unsqueeze(0)
    flow_down = F.adaptive_avg_pool2d(flow_4d, (target_h, target_w))[0]

    if mask is None:
        mask_4d = torch.ones(1, 1, source_h, source_w, dtype=torch.float32)
    else:
        if mask.ndim != 2:
            raise ValueError(f"Expected mask [H,W], got {tuple(mask.shape)}")
        mask_4d = mask.float().unsqueeze(0).unsqueeze(0)
    mask_down = F.adaptive_max_pool2d(mask_4d, (target_h, target_w))[0, 0] > 0
    return flow_down, mask_down


def prepare_residual_flow_target(
    path: str | Path,
    target_size: int | tuple[int, int] = 128,
    quantile: float = 0.9,
) -> tuple[torch.Tensor, torch.Tensor]:
    flow, valid_mask = load_residual_flow_sample(path)
    motion_mask = build_motion_mask(flow, valid_mask, quantile=quantile)
    return downsample_residual_flow(flow, motion_mask, target_size)


def resolve_residual_flow_path(
    *,
    scene_id: str,
    prev_frame_id: int,
    curr_frame_id: int,
    flow_file: str | None = None,
    flow_root: str | Path | None = None,
    image_path: str | Path | None = None,
) -> Path | None:
    suffixes = (".npz", ".pt", ".pth", ".npy")
    image_path = Path(image_path) if image_path is not None else None
    flow_root = Path(flow_root) if flow_root is not None else None

    def candidate_paths(base: Path) -> list[Path]:
        scene_dir = base / scene_id
        prefixes = [f"{prev_frame_id:06d}_{curr_frame_id:06d}", f"{prev_frame_id:06d}"]
        if image_path is not None:
            prefixes.append(image_path.stem)
        return [scene_dir / f"{prefix}{suffix}" for prefix in prefixes for suffix in suffixes]

    if flow_file:
        explicit = Path(flow_file)
        if explicit.is_absolute() and explicit.exists():
            return explicit
        roots = []
        if flow_root is not None:
            roots.append(flow_root)
        if image_path is not None:
            roots.append(image_path.parent)
        roots.append(Path.cwd())
        for root in roots:
            candidate = root / explicit
            if candidate.exists():
                return candidate

    roots: list[Path] = []
    if flow_root is not None:
        roots.append(flow_root)
    if image_path is not None:
        roots.append(image_path.parent.parent)
    for root in roots:
        for candidate in candidate_paths(root):
            if candidate.exists():
                return candidate
    return None
