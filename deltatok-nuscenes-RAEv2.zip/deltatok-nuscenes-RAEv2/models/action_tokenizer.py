from __future__ import annotations

import torch
import torch.nn as nn


class ActionTokenizer(nn.Module):
    """Encode continuous ego motion into three typed transformer tokens."""

    def __init__(
        self,
        hidden_size: int = 768,
        num_frequencies: int = 8,
        max_period: float = 100.0,
        action_mean: tuple[float, float, float] = (2.5142802, -0.0177921, -0.04997),
        action_std: tuple[float, float, float] = (1.8113501, 0.0518354, 2.4821163),
        clip_value: float = 3.0,
    ) -> None:
        super().__init__()
        self.clip_value = clip_value
        self.register_buffer("mean", torch.tensor(action_mean), persistent=True)
        self.register_buffer("std", torch.tensor(action_std).clamp_min(1e-6), persistent=True)
        frequencies = max_period ** (
            torch.arange(num_frequencies, dtype=torch.float32) / num_frequencies
        )
        self.register_buffer("frequencies", frequencies, persistent=False)
        embedding_size = 2 * num_frequencies
        self.projectors = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(embedding_size, hidden_size),
                    nn.SiLU(),
                    nn.Linear(hidden_size, hidden_size),
                    nn.LayerNorm(hidden_size),
                )
                for _ in range(3)
            ]
        )
        self.type_embedding = nn.Parameter(torch.zeros(3, hidden_size))
        nn.init.normal_(self.type_embedding, std=0.02)

    def normalize(self, action: torch.Tensor) -> torch.Tensor:
        wrapped_yaw = torch.remainder(action[:, 2] + 180.0, 360.0) - 180.0
        action = torch.cat((action[:, :2], wrapped_yaw.unsqueeze(1)), dim=1)
        return ((action - self.mean.to(action)) / self.std.to(action)).clamp(
            -self.clip_value, self.clip_value
        )

    def forward(self, action: torch.Tensor) -> torch.Tensor:
        normalized = self.normalize(action)
        tokens = []
        for axis, projector in enumerate(self.projectors):
            value = normalized[:, axis : axis + 1]
            phase = value * self.frequencies.to(value)
            fourier = torch.cat((phase.sin(), phase.cos()), dim=-1)
            token = projector(fourier) + self.type_embedding[axis]
            tokens.append(token.unsqueeze(1))
        return torch.cat(tokens, dim=1)
