from __future__ import annotations

import os
import sys
import json
from contextlib import contextmanager
from math import sqrt
from pathlib import Path
from typing import Iterator

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


_PROJECT_ROOT = Path(__file__).resolve().parents[1]
_SOURCES_ROOT = _PROJECT_ROOT.parent


def _resolve_path(path: str | os.PathLike | None, base: Path) -> Path | None:
    if path is None:
        return None
    value = Path(path).expanduser()
    if value.is_absolute():
        return value
    return (base / value).resolve()


def _ensure_raev2_src(raev2_root: Path) -> None:
    src = raev2_root / "src"
    if not src.is_dir():
        raise FileNotFoundError(
            f"RAEv2 src directory not found at {src}. Set raev2_root to the RAEv2 checkout."
        )
    src_str = str(src)
    if src_str not in sys.path:
        sys.path.insert(0, src_str)


@contextmanager
def _temporary_env(values: dict[str, str | None]) -> Iterator[None]:
    previous = {key: os.environ.get(key) for key in values}
    try:
        for key, value in values.items():
            if value is not None:
                os.environ[key] = value
        yield
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def _clean_state_dict(state: object) -> dict[str, torch.Tensor]:
    if isinstance(state, dict):
        for key in ("state_dict", "model", "decoder"):
            nested = state.get(key)
            if isinstance(nested, dict):
                state = nested
                break
    if not isinstance(state, dict):
        raise TypeError("Expected a decoder state_dict or a checkpoint dict")

    cleaned: dict[str, torch.Tensor] = {}
    for key, value in state.items():
        if not torch.is_tensor(value):
            continue
        while True:
            original = key
            for prefix in ("module.", "_orig_mod.", "model.", "decoder."):
                if key.startswith(prefix):
                    key = key[len(prefix) :]
            if key == original:
                break
        cleaned[key] = value
    return cleaned


def _resize_decoder_pos_embed(
    value: torch.Tensor,
    target_shape: torch.Size,
) -> torch.Tensor:
    if value.ndim != 3 or len(target_shape) != 3:
        raise ValueError(
            f"Cannot resize decoder_pos_embed with shape {tuple(value.shape)} to {tuple(target_shape)}"
        )
    if value.shape[0] != target_shape[0] or value.shape[2] != target_shape[2]:
        raise ValueError(
            f"Incompatible decoder_pos_embed shape {tuple(value.shape)} for target {tuple(target_shape)}"
        )

    src_tokens = value.shape[1] - 1
    dst_tokens = target_shape[1] - 1
    src_grid = int(sqrt(src_tokens))
    dst_grid = int(sqrt(dst_tokens))
    if src_grid * src_grid != src_tokens or dst_grid * dst_grid != dst_tokens:
        raise ValueError(
            f"decoder_pos_embed requires square grids, got {src_tokens} and {dst_tokens}"
        )

    cls_pos = value[:, :1]
    patch_pos = value[:, 1:].reshape(1, src_grid, src_grid, value.shape[-1])
    patch_pos = patch_pos.permute(0, 3, 1, 2)
    patch_pos = F.interpolate(
        patch_pos,
        size=(dst_grid, dst_grid),
        mode="bicubic",
        align_corners=False,
    )
    patch_pos = patch_pos.permute(0, 2, 3, 1).reshape(1, dst_tokens, value.shape[-1])
    return torch.cat((cls_pos, patch_pos), dim=1)


def _load_decoder(
    config_path: Path,
    hidden_size: int,
    decoder_patch_size: int,
    num_patches: int,
    pretrained_decoder_path: Path | None,
) -> nn.Module:
    from stage1.decoders import GeneralDecoder
    from stage1.decoders.utils import ViTMAEConfig

    config_file = config_path / "config.json" if config_path.is_dir() else config_path
    config_dict = json.loads(config_file.read_text(encoding="utf-8"))
    config_dict["hidden_size"] = hidden_size
    config_dict["patch_size"] = decoder_patch_size
    config_dict["image_size"] = int(decoder_patch_size * sqrt(num_patches))
    config = ViTMAEConfig(**config_dict)
    decoder = GeneralDecoder(config, num_patches=num_patches)

    if pretrained_decoder_path is None:
        raise ValueError("pretrained_decoder_path is required for RAEv2Stage1")
    if not pretrained_decoder_path.is_file():
        raise FileNotFoundError(f"RAEv2 decoder checkpoint not found: {pretrained_decoder_path}")

    state = _clean_state_dict(
        torch.load(pretrained_decoder_path, map_location="cpu", weights_only=False)
    )
    model_state = decoder.state_dict()
    loadable: dict[str, torch.Tensor] = {}
    mismatched: list[str] = []
    unexpected: list[str] = []

    for key, value in state.items():
        if key not in model_state:
            unexpected.append(key)
            continue
        target = model_state[key]
        if value.shape == target.shape:
            loadable[key] = value
            continue
        if key == "decoder_pos_embed":
            loadable[key] = _resize_decoder_pos_embed(value.float(), target.shape).to(
                dtype=target.dtype
            )
            continue
        mismatched.append(f"{key}: checkpoint {tuple(value.shape)} vs model {tuple(target.shape)}")

    if mismatched:
        raise RuntimeError("RAEv2 decoder checkpoint has shape mismatches: " + "; ".join(mismatched[:5]))

    keys = decoder.load_state_dict(loadable, strict=False)
    if keys.missing_keys:
        raise RuntimeError(
            f"RAEv2 decoder checkpoint is missing {len(keys.missing_keys)} keys; "
            f"first keys: {keys.missing_keys[:5]}"
        )
    if unexpected:
        raise RuntimeError(
            f"RAEv2 decoder checkpoint has {len(unexpected)} unexpected keys; first keys: {unexpected[:5]}"
        )
    return decoder


def _load_normalization_stats(
    path: Path | None,
    required: bool,
) -> tuple[torch.Tensor | None, torch.Tensor | None, bool]:
    if path is None:
        if required:
            raise ValueError("normalization_stat_path is required for normalized RAEv2 latents")
        return None, None, False
    if not path.is_file():
        raise FileNotFoundError(f"RAEv2 normalization stats not found: {path}")

    stats = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(stats, dict):
        raise TypeError(f"Unsupported RAEv2 stats format: {path}")
    mean = stats.get("mean")
    var = stats.get("var")
    if mean is not None and not torch.is_tensor(mean):
        raise TypeError("RAEv2 stats mean must be a tensor")
    if var is not None and not torch.is_tensor(var):
        raise TypeError("RAEv2 stats var must be a tensor")
    return mean, var, True


class RAEv2Stage1(nn.Module):
    """Frozen RAEv2 stage1 encoder/decoder for normalized DINOv3-B k6 latents."""

    def __init__(
        self,
        raev2_root: str | None = None,
        encoder_name: str = "dinov3mls-vit-b16[layers=6.7.8.9.10.11]",
        resolution: int = 512,
        decoder_config_path: str = "configs/decoder/ViTXL",
        decoder_patch_size: int = 16,
        pretrained_decoder_path: str | None = "pretrained_models/stage1/imagenet/dinov3b-k6/decoder.pt",
        normalization_stat_path: str | None = "pretrained_models/stage1/imagenet/dinov3b-k6/stats.pt",
        dinov3_ckpt_dir: str | None = "pretrained_models/encoders/dinov3",
        dinov3_repo_dir: str | None = None,
        noise_tau: float = 0.0,
        eps: float = 1e-5,
        require_normalization_stats: bool = True,
    ) -> None:
        super().__init__()
        self.raev2_root = _resolve_path(raev2_root, _PROJECT_ROOT) if raev2_root else _SOURCES_ROOT / "RAEv2-main"
        self.raev2_root = self.raev2_root.resolve()
        _ensure_raev2_src(self.raev2_root)

        decoder_config = _resolve_path(decoder_config_path, self.raev2_root)
        decoder_path = _resolve_path(pretrained_decoder_path, self.raev2_root)
        stats_path = _resolve_path(normalization_stat_path, self.raev2_root)
        ckpt_dir = _resolve_path(dinov3_ckpt_dir, self.raev2_root)
        repo_dir = _resolve_path(dinov3_repo_dir, self.raev2_root)

        if decoder_config is None or not decoder_config.exists():
            raise FileNotFoundError(f"RAEv2 decoder config not found: {decoder_config}")
        if ckpt_dir is not None and not ckpt_dir.is_dir():
            raise FileNotFoundError(f"DINOv3 checkpoint directory not found: {ckpt_dir}")

        from encoders.vision_encoder import create_encoder

        env = {
            "DINOV3_CKPT_DIR": str(ckpt_dir) if ckpt_dir is not None else None,
            "DINOV3_REPO_DIR": str(repo_dir) if repo_dir is not None else None,
        }
        with _temporary_env(env):
            self.encoder = create_encoder(
                encoder_name,
                device=torch.device("cpu"),
                resolution=resolution,
            )

        self.encoder_name = encoder_name
        self.img_size = int(resolution)
        self.resolution = int(resolution)
        self.patch_size = int(self.encoder.patch_size)
        self.hidden_size = int(self.encoder.hidden_size)
        self.num_heads = 12
        self.head_dim = self.hidden_size // self.num_heads
        self.decoder_patch_size = int(decoder_patch_size)
        self.base_patches = (self.resolution // self.patch_size) ** 2
        self.noise_tau = float(noise_tau)
        self.eps = float(eps)

        if self.hidden_size != 768:
            raise ValueError(f"Expected DINOv3-B k6 latent width 768, got {self.hidden_size}")
        if self.head_dim * self.num_heads != self.hidden_size:
            raise ValueError(
                f"hidden_size={self.hidden_size} is not divisible by num_heads={self.num_heads}"
            )

        self.decoder = _load_decoder(
            decoder_config,
            self.hidden_size,
            self.decoder_patch_size,
            self.base_patches,
            decoder_path,
        )
        mean, var, do_normalization = _load_normalization_stats(
            stats_path,
            required=require_normalization_stats,
        )
        if mean is None:
            self.register_buffer("latent_mean", None, persistent=False)
        else:
            self.register_buffer("latent_mean", mean.float(), persistent=False)
        if var is None:
            self.register_buffer("latent_var", None, persistent=False)
        else:
            self.register_buffer("latent_var", var.float(), persistent=False)
        self.do_normalization = do_normalization
        self.eval().requires_grad_(False)

    def _prepare_input(self, frames: torch.Tensor) -> torch.Tensor:
        frames = frames.float()
        if frames.numel() and frames.detach().amax() <= 1.0:
            frames = frames * 255.0
        if frames.shape[-2:] != (self.resolution, self.resolution):
            frames = F.interpolate(
                frames,
                size=(self.resolution, self.resolution),
                mode="bicubic",
                align_corners=False,
            )
        return frames

    def _match_stat(self, stat: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        stat = stat.to(device=z.device, dtype=z.dtype)
        if stat.ndim == 1:
            stat = stat.view(1, -1, 1, 1)
        elif stat.ndim == 3:
            stat = stat.unsqueeze(0)
        elif stat.ndim != 4:
            raise ValueError(f"Expected latent stat [C], [C,H,W], or [1,C,H,W], got {tuple(stat.shape)}")
        if stat.shape[-2:] != z.shape[-2:]:
            stat = F.interpolate(
                stat,
                size=z.shape[-2:],
                mode="bilinear",
                align_corners=False,
            )
        return stat

    def _normalize(self, z: torch.Tensor) -> torch.Tensor:
        if not self.do_normalization:
            return z
        mean = (
            self._match_stat(self.latent_mean, z)
            if self.latent_mean is not None
            else z.new_tensor(0.0)
        )
        var = (
            self._match_stat(self.latent_var, z)
            if self.latent_var is not None
            else z.new_tensor(1.0)
        )
        var = var.clamp_min(0.0)
        return (z - mean) / torch.sqrt(var + self.eps)

    def _denormalize(self, z: torch.Tensor) -> torch.Tensor:
        if not self.do_normalization:
            return z
        mean = (
            self._match_stat(self.latent_mean, z)
            if self.latent_mean is not None
            else z.new_tensor(0.0)
        )
        var = (
            self._match_stat(self.latent_var, z)
            if self.latent_var is not None
            else z.new_tensor(1.0)
        )
        var = var.clamp_min(0.0)
        return z * torch.sqrt(var + self.eps) + mean

    @torch.no_grad()
    def encode(self, frames: torch.Tensor) -> torch.Tensor:
        if frames.ndim != 5:
            raise ValueError(f"Expected frames [B,T,C,H,W], got {tuple(frames.shape)}")
        batch_size, num_frames = frames.shape[:2]
        images = self._prepare_input(frames.flatten(0, 1))
        z = self.encoder(images)
        if self.training and self.noise_tau > 0:
            noise_sigma = self.noise_tau * torch.rand(
                (z.size(0), 1, 1),
                device=z.device,
                dtype=z.dtype,
            )
            z = z + noise_sigma * torch.randn_like(z)

        token_count = z.shape[1]
        grid = int(sqrt(token_count))
        if grid * grid != token_count:
            raise ValueError(f"RAEv2 latent token count must be square, got {token_count}")
        z = rearrange(z, "b (h w) c -> b c h w", h=grid, w=grid)
        z = self._normalize(z)
        z = rearrange(z, "b c h w -> b (h w) c")
        return z.reshape(batch_size, num_frames, token_count, self.hidden_size)

    @torch.no_grad()
    def decode(self, latent: torch.Tensor) -> torch.Tensor:
        original_shape = latent.shape
        if latent.ndim == 4:
            latent = latent.flatten(0, 1)
        elif latent.ndim != 3:
            raise ValueError(f"Expected latent [B,N,C] or [B,T,N,C], got {tuple(original_shape)}")
        if latent.shape[-1] != self.hidden_size:
            raise ValueError(f"Expected latent width {self.hidden_size}, got {latent.shape[-1]}")

        token_count = latent.shape[-2]
        grid = int(sqrt(token_count))
        if grid * grid != token_count:
            raise ValueError(f"RAEv2 latent token count must be square, got {token_count}")
        z = rearrange(latent, "b (h w) c -> b c h w", h=grid, w=grid)
        z = self._denormalize(z)
        z = rearrange(z, "b c h w -> b (h w) c")
        output = self.decoder(z, drop_cls_token=False).logits
        images = self.decoder.unpatchify(output).clamp(0.0, 1.0)
        if len(original_shape) == 4:
            images = images.reshape(original_shape[0], original_shape[1], *images.shape[1:])
        return images

    def feature_slice(self, latent: torch.Tensor) -> torch.Tensor:
        if latent.shape[-1] != self.hidden_size:
            raise ValueError(f"Expected latent width {self.hidden_size}, got {latent.shape[-1]}")
        return latent

    def train(self, mode: bool = True) -> RAEv2Stage1:
        super().train(False)
        return self
