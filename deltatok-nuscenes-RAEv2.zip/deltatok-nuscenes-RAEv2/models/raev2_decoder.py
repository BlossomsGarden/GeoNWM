from __future__ import annotations

import json
import math
import os
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Iterable, Iterator

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


_PROJECT_ROOT = Path(__file__).resolve().parents[1]
_SOURCES_ROOT = _PROJECT_ROOT.parent
_DEFAULT_RAEV2_ROOT = _SOURCES_ROOT / "RAEv2-main"


def _resolve_path(path: str | os.PathLike | None, base: Path) -> Path | None:
    if path is None:
        return None
    value = Path(path).expanduser()
    if value.is_absolute():
        return value
    return (base / value).resolve()


def _ensure_raev2_src(raev2_root: Path) -> None:
    src = raev2_root / "src"
    if not src.is_dir():
        raise FileNotFoundError(f"RAEv2 src directory not found: {src}")
    src_str = str(src)
    if src_str not in sys.path:
        sys.path.insert(0, src_str)


@contextmanager
def _temporary_env(values: dict[str, str | None]) -> Iterator[None]:
    previous = {key: os.environ.get(key) for key in values}
    try:
        for key, value in values.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        yield
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def _clean_state_dict(state: object) -> dict[str, torch.Tensor]:
    if isinstance(state, dict):
        for key in ("state_dict", "model", "decoder"):
            nested = state.get(key)
            if isinstance(nested, dict):
                state = nested
                break
    if not isinstance(state, dict):
        raise TypeError("Expected a state_dict or checkpoint dict")

    cleaned: dict[str, torch.Tensor] = {}
    for key, value in state.items():
        if not torch.is_tensor(value):
            continue
        while True:
            original = key
            for prefix in ("module.", "_orig_mod.", "model.", "decoder."):
                if key.startswith(prefix):
                    key = key[len(prefix) :]
            if key == original:
                break
        cleaned[key] = value
    return cleaned


def _get_1d_sincos_pos_embed_from_grid(embed_dim: int, pos: np.ndarray) -> np.ndarray:
    if embed_dim % 2 != 0:
        raise ValueError("embed_dim must be even")
    omega = np.arange(embed_dim // 2, dtype=float)
    omega /= embed_dim / 2.0
    omega = 1.0 / 10000**omega
    pos = pos.reshape(-1)
    out = np.einsum("m,d->md", pos, omega)
    return np.concatenate([np.sin(out), np.cos(out)], axis=1)


def _get_2d_sincos_pos_embed_rect(
    embed_dim: int,
    grid_h: int,
    grid_w: int,
    add_cls_token: bool = False,
) -> np.ndarray:
    grid_y = np.arange(grid_h, dtype=np.float32)
    grid_x = np.arange(grid_w, dtype=np.float32)
    grid = np.meshgrid(grid_x, grid_y)
    grid = np.stack(grid, axis=0).reshape([2, 1, grid_h, grid_w])

    if embed_dim % 2 != 0:
        raise ValueError("embed_dim must be even")
    emb_h = _get_1d_sincos_pos_embed_from_grid(embed_dim // 2, grid[0])
    emb_w = _get_1d_sincos_pos_embed_from_grid(embed_dim // 2, grid[1])
    pos_embed = np.concatenate([emb_h, emb_w], axis=1)
    if add_cls_token:
        pos_embed = np.concatenate([np.zeros([1, embed_dim]), pos_embed], axis=0)
    return pos_embed


def _match_stat(stat: torch.Tensor | None, z: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    if stat is None:
        return z.new_tensor(0.0)
    stat = stat.to(device=z.device, dtype=z.dtype)
    if stat.ndim == 1:
        stat = stat.view(1, -1, 1, 1)
    elif stat.ndim == 3:
        stat = stat.unsqueeze(0)
    elif stat.ndim != 4:
        raise ValueError(f"Expected latent stat [C], [C,H,W], or [1,C,H,W], got {tuple(stat.shape)}")
    if stat.shape[-2:] != z.shape[-2:]:
        stat = F.interpolate(stat, size=z.shape[-2:], mode="bilinear", align_corners=False)
    return stat


class RectDINOv3MLSBackbone(nn.Module):
    """Frozen DINOv3-B encoder with the RAEv2 k6 multi-layer aggregation."""

    def __init__(
        self,
        raev2_root: Path,
        encoder_name: str = "dinov3mls-vit-b16[layers=6.7.8.9.10.11]",
        image_size: tuple[int, int] = (480, 832),
        dinov3_ckpt_dir: str | os.PathLike | None = "pretrained_models/encoders/dinov3",
        dinov3_repo_dir: str | os.PathLike | None = None,
    ) -> None:
        super().__init__()
        _ensure_raev2_src(raev2_root)

        self.encoder_name = encoder_name
        self.image_height = int(image_size[0])
        self.image_width = int(image_size[1])
        self.patch_size = 16
        if self.image_height % self.patch_size or self.image_width % self.patch_size:
            raise ValueError(f"Image size {image_size} must be divisible by {self.patch_size}")
        self.grid_h = self.image_height // self.patch_size
        self.grid_w = self.image_width // self.patch_size

        ckpt_dir = _resolve_path(dinov3_ckpt_dir, raev2_root)
        repo_dir = _resolve_path(dinov3_repo_dir, raev2_root)
        if ckpt_dir is not None and not ckpt_dir.is_dir():
            raise FileNotFoundError(f"DINOv3 checkpoint directory not found: {ckpt_dir}")

        from encoders.vision_encoder import create_encoder

        env = {
            "DINOV3_CKPT_DIR": str(ckpt_dir) if ckpt_dir is not None else None,
            "DINOV3_REPO_DIR": str(repo_dir) if repo_dir is not None else None,
        }
        with _temporary_env(env):
            self.encoder = create_encoder(
                encoder_name,
                device=torch.device("cpu"),
                resolution=max(self.image_height, self.image_width),
            )
        self.encoder.eval().requires_grad_(False)
        self.model = self.encoder.model
        self.layer_indices = tuple(getattr(self.encoder, "layer_indices", (6, 7, 8, 9, 10, 11)))
        self.hidden_size = int(self.encoder.hidden_size)
        if self.hidden_size != 768:
            raise ValueError(f"Expected DINOv3-B k6 hidden size 768, got {self.hidden_size}")

        self.register_buffer(
            "img_mean",
            torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1),
            persistent=False,
        )
        self.register_buffer(
            "img_std",
            torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1),
            persistent=False,
        )

    def prepare_images(self, images: torch.Tensor) -> torch.Tensor:
        images = images.float()
        if images.numel() and images.detach().amax() > 1.5:
            images = images / 255.0
        if images.shape[-2:] != (self.image_height, self.image_width):
            images = F.interpolate(
                images,
                size=(self.image_height, self.image_width),
                mode="bicubic",
                align_corners=False,
            )
        images = images.clamp(0.0, 1.0)
        return (images - self.img_mean.to(images)) / self.img_std.to(images)

    @torch.no_grad()
    def forward(self, images: torch.Tensor) -> torch.Tensor:
        images = self.prepare_images(images)
        outputs = self.model.get_intermediate_layers(
            images,
            n=self.layer_indices,
            reshape=False,
            return_class_token=False,
            norm=True,
        )
        patch_tokens = torch.stack(outputs, dim=0).mean(dim=0)
        final_mean = outputs[-1].mean(dim=1, keepdim=True)
        patch_tokens = patch_tokens + final_mean
        expected_tokens = self.grid_h * self.grid_w
        if patch_tokens.shape[1] != expected_tokens:
            raise ValueError(
                f"Expected {expected_tokens} patch tokens for {self.grid_h}x{self.grid_w}, "
                f"got {patch_tokens.shape[1]}"
            )
        return patch_tokens

    def train(self, mode: bool = True) -> "RectDINOv3MLSBackbone":
        super().train(False)
        self.encoder.eval().requires_grad_(False)
        return self


class PatchProjectionHead(nn.Module):
    def __init__(self, hidden_size: int, out_channels: int, patch_size: int = 16) -> None:
        super().__init__()
        self.hidden_size = int(hidden_size)
        self.out_channels = int(out_channels)
        self.patch_size = int(patch_size)
        self.proj = nn.Linear(self.hidden_size, self.patch_size**2 * self.out_channels)

    def forward(self, hidden: torch.Tensor) -> torch.Tensor:
        return self.proj(hidden)


class RectRAEv2Decoder(nn.Module):
    """Frozen DINOv3 encoder plus trainable RAEv2 decoder trunk and task heads."""

    def __init__(
        self,
        raev2_root: str | os.PathLike | None = None,
        encoder_name: str = "dinov3mls-vit-b16[layers=6.7.8.9.10.11]",
        decoder_config_path: str | os.PathLike = "configs/decoder/ViTXL",
        decoder_ckpt_path: str | os.PathLike | None = None,
        pretrained_decoder_path: str | os.PathLike | None = "pretrained_models/stage1/imagenet/dinov3b-k6/decoder.pt",
        stats_path: str | os.PathLike | None = "pretrained_models/stage1/nuscenes-512/stats.pt",
        normalization_stat_path: str | os.PathLike | None = None,
        dinov3_ckpt_dir: str | os.PathLike | None = "pretrained_models/encoders/dinov3",
        dinov3_repo_dir: str | os.PathLike | None = None,
        image_size: tuple[int, int] = (480, 832),
        task_heads: Iterable[str] = ("rgb",),
        num_classes: int = 10,
        min_depth: float = 0.1,
        max_depth: float = 120.0,
        init_depth: float = 20.0,
        noise_tau: float = 0.8,
        freeze_scheme: str = "scheme3",
        gradient_checkpointing: bool = True,
        eps: float = 1e-5,
    ) -> None:
        super().__init__()
        self.raev2_root = _resolve_path(raev2_root, _PROJECT_ROOT) if raev2_root else _DEFAULT_RAEV2_ROOT
        self.raev2_root = self.raev2_root.resolve()
        _ensure_raev2_src(self.raev2_root)

        self.image_size = (int(image_size[0]), int(image_size[1]))
        self.patch_size = 16
        if self.image_size[0] % self.patch_size or self.image_size[1] % self.patch_size:
            raise ValueError(f"Image size {self.image_size} must be divisible by {self.patch_size}")
        self.grid_h = self.image_size[0] // self.patch_size
        self.grid_w = self.image_size[1] // self.patch_size
        self.num_patches = self.grid_h * self.grid_w
        self.task_heads = tuple(task_heads)
        self.num_classes = int(num_classes)
        self.min_depth = float(min_depth)
        self.max_depth = float(max_depth)
        self.noise_tau = float(noise_tau)
        self.freeze_scheme = str(freeze_scheme)
        self.eps = float(eps)

        if decoder_ckpt_path is None:
            decoder_ckpt_path = pretrained_decoder_path
        if normalization_stat_path is not None:
            stats_path = normalization_stat_path

        self.encoder = RectDINOv3MLSBackbone(
            raev2_root=self.raev2_root,
            encoder_name=encoder_name,
            image_size=self.image_size,
            dinov3_ckpt_dir=dinov3_ckpt_dir,
            dinov3_repo_dir=dinov3_repo_dir,
        )

        decoder_config = _resolve_path(decoder_config_path, self.raev2_root)
        decoder_path = _resolve_path(decoder_ckpt_path, self.raev2_root)
        stats_file = _resolve_path(stats_path, self.raev2_root)
        if decoder_config is None or not decoder_config.exists():
            raise FileNotFoundError(f"Decoder config not found: {decoder_config}")
        if decoder_path is None or not decoder_path.is_file():
            raise FileNotFoundError(f"Decoder checkpoint not found: {decoder_path}")

        state = _clean_state_dict(torch.load(decoder_path, map_location="cpu", weights_only=False))
        self.trunk, self.decoder_hidden_size = self._build_trunk(decoder_config, state)
        self._load_trunk_state(state)
        self._set_rect_pos_embed()
        self.trunk.gradient_checkpointing = bool(gradient_checkpointing)
        self.trunk.decoder_pred.requires_grad_(False)

        self.rgb_head = (
            PatchProjectionHead(self.decoder_hidden_size, 3, self.patch_size)
            if "rgb" in self.task_heads
            else None
        )
        self.depth_head = (
            PatchProjectionHead(self.decoder_hidden_size, 1, self.patch_size)
            if "depth" in self.task_heads
            else None
        )
        self.semantic_head = (
            PatchProjectionHead(self.decoder_hidden_size, self.num_classes, self.patch_size)
            if "semantic" in self.task_heads
            else None
        )
        if self.rgb_head is not None:
            self.rgb_head.load_state_dict(
                {
                    "proj.weight": state["decoder_pred.weight"],
                    "proj.bias": state["decoder_pred.bias"],
                },
                strict=True,
            )
        if self.depth_head is not None:
            nn.init.zeros_(self.depth_head.proj.weight)
            nn.init.constant_(self.depth_head.proj.bias, math.log(float(init_depth)))

        mean, var, do_normalization = self._load_normalization_stats(stats_file)
        self.register_buffer("latent_mean", mean.float() if mean is not None else None, persistent=False)
        self.register_buffer("latent_var", var.float() if var is not None else None, persistent=False)
        self.do_normalization = do_normalization
        self._set_freeze_scheme()

    def _build_trunk(
        self,
        decoder_config_path: Path,
        state: dict[str, torch.Tensor],
    ) -> tuple[nn.Module, int]:
        from stage1.decoders import GeneralDecoder
        from stage1.decoders.utils import ViTMAEConfig

        config_file = decoder_config_path / "config.json" if decoder_config_path.is_dir() else decoder_config_path
        config_dict = json.loads(config_file.read_text(encoding="utf-8"))
        config_dict["hidden_size"] = self.encoder.hidden_size
        config_dict["patch_size"] = self.patch_size
        source_tokens = int(state["decoder_pos_embed"].shape[1] - 1)
        source_grid = int(math.isqrt(source_tokens))
        if source_grid * source_grid != source_tokens:
            raise ValueError(f"Decoder checkpoint source token count must be square, got {source_tokens}")
        config_dict["image_size"] = source_grid * self.patch_size
        config = ViTMAEConfig(**config_dict)
        trunk = GeneralDecoder(config, num_patches=source_tokens)
        return trunk, int(config.decoder_hidden_size)

    def _load_trunk_state(self, state: dict[str, torch.Tensor]) -> None:
        trunk_state = self.trunk.state_dict()
        loadable: dict[str, torch.Tensor] = {}
        mismatched: list[str] = []
        for key, value in state.items():
            if key not in trunk_state:
                continue
            if value.shape == trunk_state[key].shape:
                loadable[key] = value
                continue
            mismatched.append(f"{key}: {tuple(value.shape)} vs {tuple(trunk_state[key].shape)}")
        if mismatched:
            raise RuntimeError("Decoder checkpoint shape mismatches: " + "; ".join(mismatched[:5]))
        incompatible = self.trunk.load_state_dict(loadable, strict=False)
        if incompatible.missing_keys:
            raise RuntimeError(
                f"Decoder checkpoint missing {len(incompatible.missing_keys)} keys; "
                f"first keys: {incompatible.missing_keys[:5]}"
            )

    def _set_rect_pos_embed(self) -> None:
        value = _get_2d_sincos_pos_embed_rect(
            self.trunk.decoder_pos_embed.shape[-1],
            self.grid_h,
            self.grid_w,
            add_cls_token=True,
        )
        tensor = torch.from_numpy(value).float().unsqueeze(0)
        self.trunk.decoder_pos_embed = nn.Parameter(tensor, requires_grad=False)
        self.trunk.num_patches = self.num_patches
        self.trunk.config.image_size = max(self.image_size)

    def _load_normalization_stats(
        self,
        path: Path | None,
    ) -> tuple[torch.Tensor | None, torch.Tensor | None, bool]:
        if path is None:
            return None, None, False
        if not path.is_file():
            return None, None, False
        stats = torch.load(path, map_location="cpu", weights_only=False)
        if not isinstance(stats, dict):
            raise TypeError(f"Unsupported stats format: {path}")
        mean = stats.get("mean")
        var = stats.get("var")
        if mean is not None and not torch.is_tensor(mean):
            raise TypeError("Stats mean must be a tensor")
        if var is not None and not torch.is_tensor(var):
            raise TypeError("Stats var must be a tensor")
        return mean, var, True

    def _normalize(self, z: torch.Tensor) -> torch.Tensor:
        if not self.do_normalization:
            return z
        mean = _match_stat(self.latent_mean, z)
        var = _match_stat(self.latent_var, z).clamp_min(0.0)
        return (z - mean) / torch.sqrt(var + self.eps)

    def _denormalize(self, z: torch.Tensor) -> torch.Tensor:
        if not self.do_normalization:
            return z
        mean = _match_stat(self.latent_mean, z)
        var = _match_stat(self.latent_var, z).clamp_min(0.0)
        return z * torch.sqrt(var + self.eps) + mean

    @torch.no_grad()
    def encode(self, images: torch.Tensor) -> torch.Tensor:
        latent = self.encoder(images)
        batch_size, token_count, hidden = latent.shape
        if token_count != self.num_patches:
            raise ValueError(f"Expected latent token count {self.num_patches}, got {token_count}")
        latent_map = latent.transpose(1, 2).reshape(batch_size, hidden, self.grid_h, self.grid_w)
        if self.training and self.noise_tau > 0:
            sigma = self.noise_tau * torch.rand(
                (batch_size, 1, 1, 1),
                device=latent_map.device,
                dtype=latent_map.dtype,
            )
            latent_map = latent_map + sigma * torch.randn_like(latent_map)
        latent_map = self._normalize(latent_map)
        return latent_map.flatten(2).transpose(1, 2)

    def _run_decoder_block(self, block: nn.Module, hidden: torch.Tensor) -> torch.Tensor:
        return block(hidden, head_mask=None, output_attentions=False)[0]

    def _decode_hidden(self, latent: torch.Tensor) -> torch.Tensor:
        if latent.ndim != 3:
            raise ValueError(f"Expected latent [B,N,C], got {tuple(latent.shape)}")
        if latent.shape[1] != self.num_patches:
            raise ValueError(f"Expected latent token count {self.num_patches}, got {latent.shape[1]}")
        latent_map = latent.transpose(1, 2).reshape(latent.shape[0], latent.shape[2], self.grid_h, self.grid_w)
        latent_map = self._denormalize(latent_map)
        latent = latent_map.flatten(2).transpose(1, 2)
        hidden = self.trunk.decoder_embed(latent)
        cls_token = self.trunk.trainable_cls_token.expand(hidden.shape[0], -1, -1)
        hidden = torch.cat([cls_token, hidden], dim=1)
        hidden = hidden + self.trunk.decoder_pos_embed.to(device=hidden.device, dtype=hidden.dtype)
        for block in self.trunk.decoder_layers:
            if self.trunk.gradient_checkpointing and self.training:
                hidden = checkpoint(
                    lambda value, module=block: self._run_decoder_block(module, value),
                    hidden,
                    use_reentrant=False,
                )
            else:
                hidden = self._run_decoder_block(block, hidden)
        hidden = self.trunk.decoder_norm(hidden)
        return hidden[:, 1:, :]

    def _unpatchify(self, patches: torch.Tensor, out_channels: int) -> torch.Tensor:
        if patches.ndim != 3:
            raise ValueError(f"Expected patch tensor [B,N,D], got {tuple(patches.shape)}")
        expected = self.patch_size * self.patch_size * int(out_channels)
        if patches.shape[-1] != expected:
            raise ValueError(f"Expected patch dim {expected}, got {patches.shape[-1]}")
        if patches.shape[1] != self.num_patches:
            raise ValueError(f"Expected {self.num_patches} patches, got {patches.shape[1]}")
        batch_size = patches.shape[0]
        patches = patches.reshape(
            batch_size,
            self.grid_h,
            self.grid_w,
            self.patch_size,
            self.patch_size,
            int(out_channels),
        )
        images = torch.einsum("nhwpqc->nchpwq", patches)
        return images.reshape(
            batch_size,
            int(out_channels),
            self.grid_h * self.patch_size,
            self.grid_w * self.patch_size,
        )

    def decode(self, latent: torch.Tensor) -> dict[str, torch.Tensor]:
        hidden = self._decode_hidden(latent)
        outputs: dict[str, torch.Tensor] = {}
        if self.rgb_head is not None:
            rgb = self.rgb_head(hidden)
            outputs["rgb"] = self._unpatchify(rgb, 3)
        if self.depth_head is not None:
            log_depth = self._unpatchify(self.depth_head(hidden), 1)
            log_depth = log_depth.clamp(math.log(self.min_depth), math.log(self.max_depth))
            outputs["depth"] = torch.exp(log_depth)
        if self.semantic_head is not None:
            semantic = self.semantic_head(hidden)
            outputs["semantic_logits"] = self._unpatchify(semantic, self.num_classes)
        return outputs

    def forward(self, images: torch.Tensor, return_latent: bool = False) -> dict[str, torch.Tensor]:
        latent = self.encode(images)
        outputs = self.decode(latent)
        if return_latent:
            outputs["latent"] = latent
        return outputs

    def _set_freeze_scheme(self) -> None:
        self.encoder.eval().requires_grad_(False)
        self.trunk.requires_grad_(True)
        self.trunk.decoder_pos_embed.requires_grad_(False)
        self.trunk.decoder_pred.requires_grad_(False)

        total_blocks = len(self.trunk.decoder_layers)
        freeze_until = 0
        if self.freeze_scheme == "scheme1":
            freeze_until = total_blocks
            self.trunk.decoder_embed.requires_grad_(False)
            self.trunk.decoder_norm.requires_grad_(False)
            self.trunk.trainable_cls_token.requires_grad_(False)
        elif self.freeze_scheme == "scheme2":
            freeze_until = total_blocks // 2
            self.trunk.decoder_embed.requires_grad_(False)
            self.trunk.trainable_cls_token.requires_grad_(False)
        elif self.freeze_scheme == "scheme3":
            freeze_until = 0
        else:
            raise ValueError(f"Unknown freeze scheme: {self.freeze_scheme}")

        for idx, block in enumerate(self.trunk.decoder_layers):
            block.requires_grad_(idx >= freeze_until)

        if self.rgb_head is not None:
            self.rgb_head.requires_grad_(True)
        if self.depth_head is not None:
            self.depth_head.requires_grad_(True)
        if self.semantic_head is not None:
            self.semantic_head.requires_grad_(True)

    def train(self, mode: bool = True) -> "RectRAEv2Decoder":
        super().train(mode)
        self.encoder.eval().requires_grad_(False)
        return self

    def trainable_parameter_count(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def decoder_state_dict(self) -> dict[str, torch.Tensor]:
        return {
            key: value
            for key, value in self.state_dict().items()
            if not key.startswith("encoder.")
        }

    def load_decoder_state_dict(self, state_dict: dict[str, torch.Tensor], strict: bool = False):
        own_state = self.state_dict()
        loadable = {key: value for key, value in state_dict.items() if key in own_state}
        return self.load_state_dict(loadable, strict=strict)
