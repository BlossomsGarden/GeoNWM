from __future__ import annotations

import math

import torch
import torch.nn.functional as F


def depth_metric_sums(
    pred_depth: torch.Tensor,
    target_depth: torch.Tensor,
    min_depth: float = 0.1,
    max_depth: float = 120.0,
) -> dict[str, torch.Tensor]:
    valid = torch.isfinite(target_depth) & (target_depth > min_depth) & (target_depth < max_depth)
    valid = valid & torch.isfinite(pred_depth)
    pred = pred_depth.clamp_min(1.0e-6)
    target = target_depth.clamp_min(1.0e-6)
    diff = pred - target
    ratio = torch.maximum(pred / target, target / pred)
    count = valid.float().sum()
    return {
        "count": count,
        "abs_rel_sum": (diff.abs() / target.clamp_min(1.0e-6) * valid).sum(),
        "sq_sum": (diff.pow(2) * valid).sum(),
        "sq_log_sum": ((torch.log(pred) - torch.log(target)).pow(2) * valid).sum(),
        "delta_1_sum": ((ratio < 1.25) & valid).float().sum(),
        "delta_2_sum": ((ratio < 1.25**2) & valid).float().sum(),
        "delta_3_sum": ((ratio < 1.25**3) & valid).float().sum(),
    }


def reduce_depth_sums(sums: dict[str, torch.Tensor]) -> dict[str, float]:
    count = float(sums["count"].detach().cpu().item())
    denom = max(count, 1.0)
    return {
        "depth_abs_rel": float(sums["abs_rel_sum"].detach().cpu().item()) / denom,
        "depth_rmse": math.sqrt(float(sums["sq_sum"].detach().cpu().item()) / denom),
        "depth_log_rmse": math.sqrt(float(sums["sq_log_sum"].detach().cpu().item()) / denom),
        "depth_delta_lt_1_25": float(sums["delta_1_sum"].detach().cpu().item()) / denom,
        "depth_delta_lt_1_25_2": float(sums["delta_2_sum"].detach().cpu().item()) / denom,
        "depth_delta_lt_1_25_3": float(sums["delta_3_sum"].detach().cpu().item()) / denom,
        "depth_valid_pixels": count,
    }


def semantic_confusion_matrix(
    logits: torch.Tensor,
    labels: torch.Tensor,
    num_classes: int,
    ignore_index: int = 255,
) -> torch.Tensor:
    pred = logits.argmax(dim=1).reshape(-1)
    labels = labels.reshape(-1)
    valid = (labels != int(ignore_index)) & (labels >= 0) & (labels < int(num_classes))
    if valid.sum() == 0:
        return torch.zeros(num_classes, num_classes, device=logits.device, dtype=torch.float64)
    idx = labels[valid].long() * int(num_classes) + pred[valid].long().clamp(0, int(num_classes) - 1)
    matrix = torch.bincount(idx, minlength=int(num_classes) ** 2)
    return matrix.reshape(int(num_classes), int(num_classes)).to(dtype=torch.float64)


def reduce_semantic_confusion(confusion: torch.Tensor) -> dict[str, float]:
    cm = confusion.detach().cpu().double()
    tp = cm.diag()
    denom = cm.sum(dim=1) + cm.sum(dim=0) - tp
    valid = denom > 0
    iou = torch.where(valid, tp / denom.clamp_min(1.0), torch.zeros_like(tp))
    total = cm.sum().clamp_min(1.0)
    metrics = {
        "semantic_miou": float(iou[valid].mean().item()) if valid.any() else 0.0,
        "semantic_pixel_acc": float(tp.sum().item() / total.item()),
        "semantic_valid_classes": int(valid.sum().item()),
    }
    for cls_idx, cls_iou in enumerate(iou.tolist()):
        metrics[f"semantic_iou_class_{cls_idx:02d}"] = float(cls_iou)
    return metrics


def rgb_mse_sum(pred: torch.Tensor, target: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    pred = pred.float().clamp(0.0, 1.0)
    target = target.float().clamp(0.0, 1.0)
    return (pred - target).pow(2).sum(), torch.tensor(float(pred.numel()), device=pred.device)


def psnr_from_mse(mse: float) -> float:
    if mse <= 0.0:
        return float("inf")
    return -10.0 * math.log10(mse)


def ssim_index(pred: torch.Tensor, target: torch.Tensor, window_size: int = 11) -> torch.Tensor:
    pred = pred.float().clamp(0.0, 1.0)
    target = target.float().clamp(0.0, 1.0)
    channels = pred.shape[1]
    window = torch.ones(
        channels,
        1,
        int(window_size),
        int(window_size),
        device=pred.device,
        dtype=pred.dtype,
    ) / float(window_size * window_size)
    pad = int(window_size) // 2
    mu_x = F.conv2d(pred, window, padding=pad, groups=channels)
    mu_y = F.conv2d(target, window, padding=pad, groups=channels)
    mu_x2 = mu_x.pow(2)
    mu_y2 = mu_y.pow(2)
    mu_xy = mu_x * mu_y
    sigma_x2 = F.conv2d(pred * pred, window, padding=pad, groups=channels) - mu_x2
    sigma_y2 = F.conv2d(target * target, window, padding=pad, groups=channels) - mu_y2
    sigma_xy = F.conv2d(pred * target, window, padding=pad, groups=channels) - mu_xy
    c1 = 0.01**2
    c2 = 0.03**2
    score = ((2.0 * mu_xy + c1) * (2.0 * sigma_xy + c2)) / (
        (mu_x2 + mu_y2 + c1) * (sigma_x2 + sigma_y2 + c2)
    ).clamp_min(1.0e-8)
    return score.clamp(-1.0, 1.0).mean(dim=(1, 2, 3))
