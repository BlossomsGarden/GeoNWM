"""nuScenes decoder fine-tuning utilities for the RAEv2 branch."""
