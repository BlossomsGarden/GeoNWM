# DeltaTok nuScenes RAEv2

This directory is a stage1-only DeltaTok branch for testing one controlled change:
the training latent space is replaced with the normalized RAEv2 stage1 DINOv3-B
k6 latent.

The nuScenes data pipeline, action target, pairwise DeltaTok objective, optimizer,
and 512 training setup are kept from the baseline. The migrated experiment line is
only `configs/deltatok_nuscenes_512.yaml`.

## Latent Contract

- Encoder: `dinov3mls-vit-b16[layers=6.7.8.9.10.11]`.
- Decoder config: `configs/decoder/ViTXL`; this keeps latent input width
  768 while matching the public `dinov3b-k6` decoder's 1152-wide internal
  decoder blocks.
- Latent shape at 512: `[B, T, 1024, 768]`.
- The 768 channels are the full RAEv2 k6 latent, not a slice.
- RAEv2 normalization stats are applied inside `RAEv2Stage1.encode()`.
- `latent_loss` is computed in the normalized latent space.
- `RAEv2Stage1.decode()` denormalizes internally, then runs the frozen decoder for
  RGB validation plots only.
- `noise_tau` is fixed to `0.0` in the config.

If the downloaded stats were computed at a 256 latent grid, the wrapper resizes
the stored mean and variance to the current 512 grid before normalize/denormalize.

## Expected RAEv2 Weights

The config resolves these paths relative to `../RAEv2-main`:

```text
pretrained_models/encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m-73cec8be.pth
pretrained_models/stage1/imagenet/dinov3b-k6/decoder.pt
pretrained_models/stage1/imagenet/dinov3b-k6/stats.pt
```

Download example from inside `sources/RAEv2-main`:

```bash
uv run hf download nyu-visionx/RAEv2-models \
  --include "encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m-73cec8be.pth" \
  --include "stage1/imagenet/dinov3b-k6/**" \
  --exclude .gitattributes \
  --local-dir pretrained_models/
```

## Train

```bash
cd sources/deltatok-nuscenes-RAEv2
python main.py fit -c configs/deltatok_nuscenes_512.yaml
```

The optional Cityscapes/KITTI compatibility heads remain diagnostic views only.
They now consume the full normalized 768-channel RAEv2 latent, so their plots
should not be interpreted as primary metrics for this ablation.
