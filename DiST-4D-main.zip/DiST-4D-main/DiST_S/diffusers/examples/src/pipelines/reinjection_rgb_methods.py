from __future__ import annotations

import math
from typing import Dict, Tuple

import cv2
import numpy as np
import torch

EPS = 1e-6

REINJECTION_ATLAS_METHODS = [
    "laplacian_low_quality",
    "tenengrad_low_quality",
    "local_variance_low_texture",
    "local_variance_high_texture",
    "local_entropy_low_texture",
    "local_entropy_high_texture",
    "hf_energy_deficit",
    "multiscale_blur_deficit",
    "edge_spread",
    "phase_structure_low",
    "checkerboard_parity",
    "periodic_autocorrelation",
    "grid_boundary_period8",
    "fft_periodic_peak",
    "dct_periodic_peak",
    "combined_blur_deficit",
    "combined_periodic_artifact",
    "blur_periodic_agreement",
]

REINJECTION_MASK_ALIASES = {
    "laplacian": "laplacian_low_quality",
    "high_frequency": "laplacian_low_quality",
    "high-frequency": "laplacian_low_quality",
    "entropy": "local_entropy_low_texture",
    "low_texture": "local_entropy_low_texture",
    "entropy_low_texture": "local_entropy_low_texture",
}

REINJECTION_MASK_MODES = list(
    dict.fromkeys(
        [
            "laplacian",
            "entropy",
            *REINJECTION_ATLAS_METHODS,
            *REINJECTION_MASK_ALIASES,
        ]
    )
)

REINJECTION_SWEEP_METHODS = list(REINJECTION_ATLAS_METHODS)


def canonical_mask_mode(mask_mode: str | None) -> str:
    mode = (mask_mode or "laplacian").lower()
    return REINJECTION_MASK_ALIASES.get(mode, mode)


def finite_array(value: np.ndarray) -> np.ndarray:
    value = np.asarray(value, dtype=np.float32)
    if np.isfinite(value).all():
        return value
    finite = value[np.isfinite(value)]
    fill = float(np.median(finite)) if finite.size else 0.0
    return np.nan_to_num(value, nan=fill, posinf=fill, neginf=fill).astype(np.float32)


def robust_norm(value: np.ndarray, low: float = 2.0, high: float = 98.0) -> np.ndarray:
    value = finite_array(value)
    lo, hi = np.percentile(value, [low, high])
    if hi - lo < EPS:
        return np.zeros_like(value, dtype=np.float32)
    return np.clip((value - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)


def invert_quality(value: np.ndarray) -> np.ndarray:
    return 1.0 - robust_norm(value)


def gray_from_rgb(rgb: np.ndarray) -> np.ndarray:
    return (
        0.299 * rgb[..., 0]
        + 0.587 * rgb[..., 1]
        + 0.114 * rgb[..., 2]
    ).astype(np.float32)


def box_mean(value: np.ndarray, size: int) -> np.ndarray:
    return cv2.blur(value.astype(np.float32), (size, size), borderType=cv2.BORDER_REFLECT)


def local_variance(value: np.ndarray, size: int = 9) -> np.ndarray:
    mean = box_mean(value, size)
    second = box_mean(value * value, size)
    return np.maximum(second - mean * mean, 0.0).astype(np.float32)


def local_entropy(value: np.ndarray, size: int = 11, bins: int = 8) -> np.ndarray:
    edges = np.linspace(0.0, 1.0 + EPS, bins + 1, dtype=np.float32)
    result = np.zeros_like(value, dtype=np.float32)
    for index in range(bins):
        membership = ((value >= edges[index]) & (value < edges[index + 1])).astype(np.float32)
        probability = np.clip(box_mean(membership, size), 0.0, 1.0)
        result -= probability * np.log2(probability + EPS)
    return result


def gradient_energy(value: np.ndarray, sigma: float) -> np.ndarray:
    smoothed = cv2.GaussianBlur(value, (0, 0), sigmaX=sigma, sigmaY=sigma)
    gx = cv2.Scharr(smoothed, cv2.CV_32F, 1, 0)
    gy = cv2.Scharr(smoothed, cv2.CV_32F, 0, 1)
    return box_mean(gx * gx + gy * gy, 7)


def high_frequency_energy(value: np.ndarray, sigma: float) -> np.ndarray:
    smoothed = cv2.GaussianBlur(value, (0, 0), sigmaX=sigma, sigmaY=sigma)
    return box_mean(np.abs(value - smoothed), 7)


def local_corr(value: np.ndarray, dy: int, dx: int, size: int = 11) -> np.ndarray:
    height, width = value.shape
    shifted = np.zeros_like(value, dtype=np.float32)
    valid = np.zeros_like(value, dtype=np.float32)
    source_y0 = max(0, dy)
    source_y1 = min(height, height + dy)
    source_x0 = max(0, dx)
    source_x1 = min(width, width + dx)
    target_y0 = max(0, -dy)
    target_y1 = target_y0 + max(0, source_y1 - source_y0)
    target_x0 = max(0, -dx)
    target_x1 = target_x0 + max(0, source_x1 - source_x0)
    if target_y1 > target_y0 and target_x1 > target_x0:
        shifted[target_y0:target_y1, target_x0:target_x1] = value[source_y0:source_y1, source_x0:source_x1]
        valid[target_y0:target_y1, target_x0:target_x1] = 1.0

    mean_a = box_mean(value, size)
    mean_b = box_mean(shifted, size)
    mean_ab = box_mean(value * shifted, size)
    var_a = np.maximum(box_mean(value * value, size) - mean_a * mean_a, 0.0)
    var_b = np.maximum(box_mean(shifted * shifted, size) - mean_b * mean_b, 0.0)
    covariance = mean_ab - mean_a * mean_b
    result = np.abs(covariance) / np.sqrt(var_a * var_b + EPS)
    valid_fraction = box_mean(valid, size)
    return np.where(valid_fraction > 0.85, np.clip(result, 0.0, 1.0), 0.0).astype(np.float32)


def shifted_difference(value: np.ndarray, dy: int, dx: int) -> np.ndarray:
    shifted = np.zeros_like(value, dtype=np.float32)
    height, width = value.shape
    source_y0 = max(0, dy)
    source_y1 = min(height, height + dy)
    source_x0 = max(0, dx)
    source_x1 = min(width, width + dx)
    target_y0 = max(0, -dy)
    target_y1 = target_y0 + max(0, source_y1 - source_y0)
    target_x0 = max(0, -dx)
    target_x1 = target_x0 + max(0, source_x1 - source_x0)
    if target_y1 > target_y0 and target_x1 > target_x0:
        shifted[target_y0:target_y1, target_x0:target_x1] = value[source_y0:source_y1, source_x0:source_x1]
    return shifted


def block_frequency_map(value: np.ndarray, kind: str, block: int = 32, stride: int = 16) -> np.ndarray:
    height, width = value.shape
    result = np.zeros_like(value, dtype=np.float32)
    counts = np.zeros_like(value, dtype=np.float32)
    window = np.outer(np.hanning(block), np.hanning(block)).astype(np.float32)
    for top in range(0, height - block + 1, stride):
        for left in range(0, width - block + 1, stride):
            patch = value[top : top + block, left : left + block].astype(np.float32)
            patch = patch - float(patch.mean())
            patch = patch * window
            if kind == "fft":
                spectrum = np.fft.fftshift(np.fft.fft2(patch))
                energy = np.abs(spectrum) ** 2
                center = block // 2
            else:
                coefficients = cv2.dct(patch)
                energy = coefficients * coefficients
                center = 0

            total = float(energy.sum() - energy[center, center]) if kind == "fft" else float(energy.sum() - energy[0, 0])
            total = max(total, EPS)
            targets = []
            for period in (2, 4, 8):
                frequency = block // period
                if kind == "fft":
                    offsets = [
                        (0, frequency), (0, -frequency),
                        (frequency, 0), (-frequency, 0),
                        (frequency, frequency), (frequency, -frequency),
                        (-frequency, frequency), (-frequency, -frequency),
                    ]
                    for oy, ox in offsets:
                        yy, xx = center + oy, center + ox
                        if 0 <= yy < block and 0 <= xx < block:
                            targets.append(float(energy[yy, xx]))
                else:
                    for yy, xx in ((0, frequency), (frequency, 0), (frequency, frequency)):
                        if 0 <= yy < block and 0 <= xx < block:
                            targets.append(float(energy[yy, xx]))
            score = min(max(targets) / total if targets else 0.0, 1.0)
            bottom = min(top + block, height)
            right = min(left + block, width)
            result[top:bottom, left:right] += score
            counts[top:bottom, left:right] += 1.0
    return np.divide(result, counts, out=np.zeros_like(result), where=counts > 0).astype(np.float32)


def compute_methods(rgb: np.ndarray) -> tuple[dict[str, np.ndarray], dict[str, str]]:
    gray = gray_from_rgb(rgb)
    laplacian = np.abs(cv2.Laplacian(gray, cv2.CV_32F, ksize=3))
    scharr_x = cv2.Scharr(gray, cv2.CV_32F, 1, 0)
    scharr_y = cv2.Scharr(gray, cv2.CV_32F, 0, 1)
    tenengrad = box_mean(scharr_x * scharr_x + scharr_y * scharr_y, 7)
    variance = local_variance(gray, 9)
    entropy = local_entropy(gray, 11, 8)
    hf_fine = high_frequency_energy(gray, 1.2)
    hf_coarse = high_frequency_energy(gray, 2.5)
    gradient_coarse = gradient_energy(gray, 2.0)
    gradient_fine = gradient_energy(gray, 0.7)
    coarse_support = robust_norm(gradient_coarse)
    fine_support = robust_norm(gradient_fine)

    fine_to_coarse = hf_fine / (hf_coarse + EPS)
    blur_deficit = np.clip(1.0 - fine_to_coarse, 0.0, 1.0) * robust_norm(hf_coarse)
    edge_spread = np.clip(hf_coarse / (hf_fine + EPS), 0.0, 4.0) / 4.0
    edge_spread *= coarse_support

    phase_energy = np.zeros_like(gray, dtype=np.float32)
    for angle in (0.0, np.pi / 4.0, np.pi / 2.0, 3.0 * np.pi / 4.0):
        even_kernel = cv2.getGaborKernel((21, 21), 3.0, angle, 6.0, 0.5, 0.0, ktype=cv2.CV_32F)
        odd_kernel = cv2.getGaborKernel((21, 21), 3.0, angle, 6.0, 0.5, np.pi / 2.0, ktype=cv2.CV_32F)
        even = cv2.filter2D(gray, cv2.CV_32F, even_kernel)
        odd = cv2.filter2D(gray, cv2.CV_32F, odd_kernel)
        phase_energy += cv2.GaussianBlur(np.sqrt(even * even + odd * odd), (0, 0), 1.0)
    phase_energy /= 4.0
    phase_low = (1.0 - robust_norm(phase_energy)) * (0.25 + 0.75 * coarse_support)

    highpass = gray - cv2.GaussianBlur(gray, (0, 0), 1.0)
    yy, xx = np.indices(gray.shape)
    checker_sign = np.where((xx + yy) % 2 == 0, 1.0, -1.0).astype(np.float32)
    parity = np.abs(box_mean(highpass * checker_sign, 9)) / (box_mean(np.abs(highpass), 9) + EPS)
    parity = np.clip(parity, 0.0, 1.0)
    autocorrelation = np.mean(
        [local_corr(highpass, dy, dx, 11) for dy, dx in ((2, 0), (0, 2), (4, 0), (0, 4), (8, 0), (0, 8))],
        axis=0,
    )

    grid = np.zeros_like(gray, dtype=np.float32)
    horizontal = np.abs(gray[:, 1:] - gray[:, :-1])
    vertical = np.abs(gray[1:, :] - gray[:-1, :])
    for x in range(8, gray.shape[1], 8):
        grid[:, x] = horizontal[:, x - 1]
    for y in range(8, gray.shape[0], 8):
        grid[y, :] = np.maximum(grid[y, :], vertical[y - 1, :])
    block_boundary = box_mean(grid, 5) / (box_mean(np.abs(gray - cv2.GaussianBlur(gray, (0, 0), 1.0)), 5) + EPS)
    block_boundary = np.clip(block_boundary, 0.0, 1.0)
    fft_score = block_frequency_map(highpass, "fft")
    dct_score = block_frequency_map(highpass, "dct")

    methods = {
        "laplacian_low_quality": invert_quality(laplacian),
        "tenengrad_low_quality": invert_quality(tenengrad),
        "local_variance_low_texture": invert_quality(variance),
        "local_variance_high_texture": robust_norm(variance),
        "local_entropy_low_texture": invert_quality(entropy),
        "local_entropy_high_texture": robust_norm(entropy),
        "hf_energy_deficit": invert_quality(hf_fine),
        "multiscale_blur_deficit": blur_deficit,
        "edge_spread": edge_spread,
        "phase_structure_low": phase_low,
        "checkerboard_parity": parity,
        "periodic_autocorrelation": autocorrelation,
        "grid_boundary_period8": block_boundary,
        "fft_periodic_peak": fft_score,
        "dct_periodic_peak": dct_score,
    }
    methods["combined_blur_deficit"] = (
        0.45 * robust_norm(blur_deficit)
        + 0.30 * robust_norm(edge_spread)
        + 0.15 * robust_norm(phase_low)
        + 0.10 * invert_quality(hf_fine)
    ) * (0.25 + 0.75 * coarse_support)
    methods["combined_periodic_artifact"] = (
        0.25 * robust_norm(parity)
        + 0.25 * robust_norm(autocorrelation)
        + 0.25 * robust_norm(fft_score)
        + 0.15 * robust_norm(dct_score)
        + 0.10 * robust_norm(block_boundary)
    )
    methods["blur_periodic_agreement"] = np.sqrt(
        np.clip(methods["combined_blur_deficit"], 0.0, 1.0)
        * np.clip(methods["combined_periodic_artifact"], 0.0, 1.0)
    )
    methods = {name: finite_array(value) for name, value in methods.items()}
    directions = {
        "laplacian_low_quality": "low response means candidate; inverted for display",
        "tenengrad_low_quality": "low response means candidate; inverted for display",
        "local_variance_low_texture": "low response means low texture; not proof of blur",
        "local_variance_high_texture": "high local variance; texture/edge-rich response",
        "local_entropy_low_texture": "low response means low texture; not proof of blur",
        "local_entropy_high_texture": "high local entropy; texture/edge-rich response",
        "hf_energy_deficit": "low fine-scale energy; inverted for display",
        "multiscale_blur_deficit": "coarse variation without fine-scale detail",
        "edge_spread": "coarse edge energy relative to fine edge energy",
        "phase_structure_low": "low oriented phase-energy cue; approximate",
        "checkerboard_parity": "2x2 alternating parity response",
        "periodic_autocorrelation": "absolute local correlation at periods 2/4/8",
        "grid_boundary_period8": "fixed period-8 horizontal/vertical boundary response",
        "fft_periodic_peak": "local FFT energy at periods 2/4/8",
        "dct_periodic_peak": "local DCT energy at periods 2/4/8",
        "combined_blur_deficit": "conservative weighted blur-deficit cue",
        "combined_periodic_artifact": "weighted periodic-artifact cue",
        "blur_periodic_agreement": "geometric agreement of the two combined cues",
    }
    return methods, directions


def _topk_mask(score: np.ndarray, top_percent: float) -> tuple[np.ndarray, float]:
    score = finite_array(score)
    flat = score.reshape(-1)
    count = max(1, min(flat.size, int(math.ceil(flat.size * float(top_percent) / 100.0))))
    if count >= flat.size:
        return np.ones_like(score, dtype=np.float32), float(np.min(flat))
    selected = np.argpartition(flat, flat.size - count)[-count:]
    mask = np.zeros_like(flat, dtype=np.float32)
    mask[selected] = 1.0
    return mask.reshape(score.shape), float(np.min(flat[selected]))


def compute_reinjection_mask(
    video_frames: torch.Tensor,
    mask_mode: str,
    top_percent: float = 20.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if not isinstance(video_frames, torch.Tensor):
        raise TypeError(f"video_frames must be a torch.Tensor, got {type(video_frames)!r}")
    if video_frames.ndim != 5:
        raise ValueError(f"Expected [B, C, F, H, W] video frames, got {tuple(video_frames.shape)}")

    mode = canonical_mask_mode(mask_mode)
    frames = video_frames.detach().float().cpu().permute(0, 2, 3, 4, 1).numpy()
    batch_size, num_frames, height, width, channels = frames.shape
    if channels < 1:
        raise ValueError("video_frames must contain at least one channel")

    mask_stack = np.zeros((batch_size, num_frames, height, width), dtype=np.float32)
    score_stack = np.zeros_like(mask_stack)
    threshold_stack = np.zeros((batch_size, num_frames, 1, 1), dtype=np.float32)

    for batch_index in range(batch_size):
        for frame_index in range(num_frames):
            rgb = frames[batch_index, frame_index].astype(np.float32)
            if rgb.min() < -1e-3 or rgb.max() > 1.0 + 1e-3:
                rgb = (rgb + 1.0) * 0.5
            rgb = np.clip(rgb, 0.0, 1.0)
            methods, _ = compute_methods(rgb)
            if mode not in methods:
                raise ValueError(
                    f"Unknown mask_mode={mask_mode!r}; expected one of {sorted(methods)} or aliases {sorted(REINJECTION_MASK_ALIASES)}"
                )
            score = finite_array(methods[mode])
            mask, threshold = _topk_mask(score, top_percent)
            mask_stack[batch_index, frame_index] = mask
            score_stack[batch_index, frame_index] = score
            threshold_stack[batch_index, frame_index, 0, 0] = threshold

    device = video_frames.device
    return (
        torch.from_numpy(mask_stack).to(device=device, dtype=torch.float32),
        torch.from_numpy(score_stack).to(device=device, dtype=torch.float32),
        torch.from_numpy(threshold_stack).to(device=device, dtype=torch.float32),
    )


def latent_frame_to_rgb_proxy(latent_frame: np.ndarray) -> np.ndarray:
    """Convert one [C, H, W] latent frame to a normalized scalar image proxy."""
    latent_frame = finite_array(latent_frame)
    if latent_frame.ndim != 3:
        raise ValueError(f"Expected one latent frame with shape [C, H, W], got {latent_frame.shape}")
    if latent_frame.shape[0] < 1:
        raise ValueError("latent_frame must contain at least one channel")

    normalized_channels = [robust_norm(latent_frame[channel_index]) for channel_index in range(latent_frame.shape[0])]
    scalar = np.mean(np.stack(normalized_channels, axis=0), axis=0)
    scalar = robust_norm(scalar)
    return np.repeat(scalar[..., None], 3, axis=2).astype(np.float32)


def compute_latent_reinjection_mask(
    latents: torch.Tensor,
    mask_mode: str,
    top_percent: float = 20.0,
    latent_group: str = "rgb",
    latent_proxy_mode: str = "channel_mean",
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if not isinstance(latents, torch.Tensor):
        raise TypeError(f"latents must be a torch.Tensor, got {type(latents)!r}")
    if latents.ndim != 5:
        raise ValueError(f"Expected [B, F, C, H, W] latents, got {tuple(latents.shape)}")

    mode = canonical_mask_mode(mask_mode)
    latent_group = (latent_group or "rgb").lower()
    latent_proxy_mode = (latent_proxy_mode or "channel_mean").lower()
    if latent_group == "rgb":
        channel_count = max(1, latents.shape[2] // 2)
    elif latent_group == "all":
        channel_count = latents.shape[2]
    else:
        raise ValueError(f"Unknown latent_group={latent_group!r}; expected 'rgb' or 'all'")
    if latent_proxy_mode not in {"channel_mean", "halfres_all4"}:
        raise ValueError(
            f"Unknown latent_proxy_mode={latent_proxy_mode!r}; expected 'channel_mean' or 'halfres_all4'"
        )

    latent_np = latents.detach().float().cpu().numpy()
    batch_size, num_frames, _, height, width = latent_np.shape
    mask_stack = np.zeros((batch_size, num_frames, height, width), dtype=np.float32)
    score_stack = np.zeros_like(mask_stack)
    threshold_stack = np.zeros((batch_size, num_frames, 1, 1), dtype=np.float32)

    for batch_index in range(batch_size):
        for frame_index in range(num_frames):
            latent_frame = latent_np[batch_index, frame_index, :channel_count]
            if latent_proxy_mode == "channel_mean":
                methods, _ = compute_methods(latent_frame_to_rgb_proxy(latent_frame))
                if mode not in methods:
                    raise ValueError(
                        f"Unknown mask_mode={mask_mode!r}; expected one of {sorted(methods)} or aliases {sorted(REINJECTION_MASK_ALIASES)}"
                    )
                score = finite_array(methods[mode])
            else:
                proxy_height = height * 4
                proxy_width = width * 4
                channel_scores = []
                for channel_index in range(channel_count):
                    upsampled = cv2.resize(
                        latent_frame[channel_index].astype(np.float32),
                        (proxy_width, proxy_height),
                        interpolation=cv2.INTER_CUBIC,
                    )
                    proxy_rgb = np.repeat(robust_norm(upsampled)[..., None], 3, axis=2)
                    methods, _ = compute_methods(proxy_rgb)
                    if mode not in methods:
                        raise ValueError(
                            f"Unknown mask_mode={mask_mode!r}; expected one of {sorted(methods)} or aliases {sorted(REINJECTION_MASK_ALIASES)}"
                        )
                    channel_scores.append(finite_array(methods[mode]))
                proxy_score = np.mean(np.stack(channel_scores, axis=0), axis=0)
                score = cv2.resize(proxy_score, (width, height), interpolation=cv2.INTER_AREA).astype(np.float32)
            mask, threshold = _topk_mask(score, top_percent)
            mask_stack[batch_index, frame_index] = mask
            score_stack[batch_index, frame_index] = score
            threshold_stack[batch_index, frame_index, 0, 0] = threshold

    device = latents.device
    return (
        torch.from_numpy(mask_stack).to(device=device, dtype=torch.float32),
        torch.from_numpy(score_stack).to(device=device, dtype=torch.float32),
        torch.from_numpy(threshold_stack).to(device=device, dtype=torch.float32),
    )
