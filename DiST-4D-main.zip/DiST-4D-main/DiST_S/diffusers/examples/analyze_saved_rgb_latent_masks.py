#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import inspect
import json
import math
import os
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw

from diffusers.utils.torch_utils import is_compiled_module
from src.pipelines.pipeline_stable_video_diffusion_custom_mm import (
    StableVideoDiffusionPipeline_convnb_multiframe_mm,
    tensor2vid,
)
from src.pipelines.reinjection_rgb_methods import (
    REINJECTION_SWEEP_METHODS,
    _topk_mask,
    compute_methods,
    finite_array,
    robust_norm,
)


SCHEMES = {
    "fullres_all4": {"height_ratio": 1.0, "projection": "all4"},
    "fullres_pool1": {"height_ratio": 1.0, "projection": "pool1"},
    "halfres_all4": {"height_ratio": 0.5, "projection": "all4"},
    "halfres_pool1": {"height_ratio": 0.5, "projection": "pool1"},
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--latent_root", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--video_height", type=int, default=448)
    parser.add_argument("--video_width", type=int, default=768)
    parser.add_argument("--top_percent", type=float, default=20.0)
    parser.add_argument("--sigma", type=float, default=0.3)
    parser.add_argument("--methods", nargs="*", default=REINJECTION_SWEEP_METHODS)
    parser.add_argument("--schemes", nargs="*", default=list(SCHEMES))
    parser.add_argument("--max_files", type=int, default=None)
    parser.add_argument("--file_offset", type=int, default=0)
    parser.add_argument("--file_stride", type=int, default=1)
    parser.add_argument("--summary_suffix", default="")
    parser.add_argument("--decode_perturbed", action="store_true", default=False)
    parser.add_argument("--tile_width", type=int, default=192)
    parser.add_argument("--torch_dtype", choices=["fp32", "fp16"], default="fp32")
    return parser.parse_args()


def ensure_dir(path: str | Path) -> str:
    os.makedirs(path, exist_ok=True)
    return str(path)


def parse_pt_path(path: Path) -> tuple[str, int]:
    chunk = path.parent.name
    step = path.stem
    return chunk, int(step.split("_")[-1])


def discover_latent_files(
    latent_root: str,
    max_files: int | None,
    file_offset: int = 0,
    file_stride: int = 1,
) -> list[Path]:
    if file_offset < 0:
        raise ValueError(f"file_offset must be non-negative, got {file_offset}")
    if file_stride <= 0:
        raise ValueError(f"file_stride must be positive, got {file_stride}")
    files = sorted(Path(latent_root).glob("chunk_*/step_*.pt"))
    files = sorted(files, key=lambda p: (p.parent.name, parse_pt_path(p)[1]))
    files = files[file_offset::file_stride]
    if max_files is not None:
        files = files[:max_files]
    if not files:
        raise FileNotFoundError(f"No step_*.pt files found under {latent_root}")
    return files


def load_pipeline(model_path: str, device: str, torch_dtype: str):
    dtype = torch.float16 if torch_dtype == "fp16" else torch.float32
    pipe = StableVideoDiffusionPipeline_convnb_multiframe_mm.from_pretrained(
        model_path,
        torch_dtype=dtype,
    )
    pipe.to(device)
    pipe.vae.to(device=device, dtype=dtype)
    pipe.vae.eval()
    return pipe


@torch.no_grad()
def decode_rgb_latents_only(pipe, rgb_latents: torch.Tensor, decode_chunk_size: int = 6):
    latents = rgb_latents.flatten(0, 1)
    latents = latents / pipe.vae.config.scaling_factor
    forward_vae_fn = pipe.vae._orig_mod.forward if is_compiled_module(pipe.vae) else pipe.vae.forward
    accepts_num_frames = "num_frames" in set(inspect.signature(forward_vae_fn).parameters.keys())

    frames = []
    for start in range(0, latents.shape[0], decode_chunk_size):
        current = latents[start : start + decode_chunk_size]
        decode_kwargs = {}
        if accepts_num_frames:
            decode_kwargs["num_frames"] = current.shape[0]
        frames.append(pipe.vae.decode(current, **decode_kwargs).sample)

    frames = torch.cat(frames, dim=0)
    batch, num_frames = rgb_latents.shape[:2]
    frames = frames.reshape(batch, num_frames, *frames.shape[1:]).permute(0, 2, 1, 3, 4).float()
    return tensor2vid(frames, pipe.image_processor, output_type="pil")


def latent_pca_frames(rgb_latents: torch.Tensor, size: tuple[int, int]) -> list[Image.Image]:
    latents = rgb_latents.detach().float().cpu().numpy()[0]
    num_frames, channels, height, width = latents.shape
    matrix = np.transpose(latents, (0, 2, 3, 1)).reshape(-1, channels)
    matrix = finite_array(matrix)
    matrix = matrix - matrix.mean(axis=0, keepdims=True)
    scale = matrix.std(axis=0, keepdims=True) + 1e-6
    matrix = matrix / scale
    _, _, vt = np.linalg.svd(matrix, full_matrices=False)
    components = matrix @ vt[:3].T
    components = components.reshape(num_frames, height, width, min(3, components.shape[-1]))
    if components.shape[-1] < 3:
        components = np.pad(components, ((0, 0), (0, 0), (0, 0), (0, 3 - components.shape[-1])))

    frames = []
    for frame_index in range(num_frames):
        rgb = np.stack(
            [robust_norm(components[frame_index, :, :, channel]) for channel in range(3)],
            axis=-1,
        )
        image = Image.fromarray((rgb * 255.0).astype(np.uint8)).resize(size, Image.BICUBIC)
        frames.append(image)
    return frames


def label_image(image: Image.Image, text: str, bar_height: int = 20) -> Image.Image:
    canvas = Image.new("RGB", (image.width, image.height + bar_height), "white")
    canvas.paste(image.convert("RGB"), (0, bar_height))
    draw = ImageDraw.Draw(canvas)
    draw.text((4, 4), text[:80], fill=(0, 0, 0))
    return canvas


def make_sheet(
    rows: list[list[Image.Image]],
    row_labels: list[str],
    col_labels: list[str] | None,
    title: str,
    gap: int = 4,
    label_width: int = 190,
    title_height: int = 28,
) -> Image.Image:
    if not rows or not rows[0]:
        raise ValueError("rows must be non-empty")
    tile_w, tile_h = rows[0][0].size
    col_label_h = 20 if col_labels else 0
    width = label_width + len(rows[0]) * tile_w + max(0, len(rows[0]) - 1) * gap
    height = title_height + col_label_h + len(rows) * tile_h + max(0, len(rows) - 1) * gap
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((4, 7), title[:150], fill=(0, 0, 0))
    y0 = title_height
    if col_labels:
        for col_index, label in enumerate(col_labels):
            x = label_width + col_index * (tile_w + gap)
            draw.text((x + 4, y0 + 3), label[:40], fill=(0, 0, 0))
        y0 += col_label_h
    for row_index, row in enumerate(rows):
        y = y0 + row_index * (tile_h + gap)
        draw.text((4, y + 4), row_labels[row_index][:80], fill=(0, 0, 0))
        for col_index, image in enumerate(row):
            x = label_width + col_index * (tile_w + gap)
            canvas.paste(image.convert("RGB"), (x, y))
    return canvas


def resize_frames(frames: list[Image.Image], tile_width: int) -> list[Image.Image]:
    result = []
    for frame in frames:
        tile_height = max(1, int(round(frame.height * tile_width / frame.width)))
        result.append(frame.resize((tile_width, tile_height), Image.BICUBIC))
    return result


def overlay_mask(frame: Image.Image, mask: np.ndarray, alpha: float = 0.45) -> Image.Image:
    frame_np = np.array(frame.convert("RGB"), dtype=np.float32)
    mask_np = cv2.resize(
        mask.astype(np.float32),
        (frame_np.shape[1], frame_np.shape[0]),
        interpolation=cv2.INTER_NEAREST,
    )
    selected = mask_np > 0.5
    overlay = frame_np.copy()
    red = np.zeros_like(overlay)
    red[..., 0] = 255.0
    overlay[selected] = overlay[selected] * (1.0 - alpha) + red[selected] * alpha
    return Image.fromarray(np.clip(overlay, 0, 255).astype(np.uint8))


def binary_mask_image(mask: np.ndarray, size: tuple[int, int]) -> Image.Image:
    mask_resized = cv2.resize(mask.astype(np.float32), size, interpolation=cv2.INTER_NEAREST)
    rgb = np.repeat((mask_resized[..., None] > 0.5).astype(np.uint8) * 255, 3, axis=2)
    return Image.fromarray(rgb)


def upsample_latent_channels(latent_frame: np.ndarray, target_size: tuple[int, int]) -> np.ndarray:
    channels = []
    for channel in latent_frame:
        up = cv2.resize(channel.astype(np.float32), target_size, interpolation=cv2.INTER_CUBIC)
        channels.append(robust_norm(up))
    return np.stack(channels, axis=0).astype(np.float32)


def score_masks_for_scheme(
    rgb_latents: torch.Tensor,
    scheme: dict,
    methods: list[str],
    top_percent: float,
    target_hw: tuple[int, int],
) -> tuple[dict[str, dict], list[dict]]:
    latent_np = rgb_latents.detach().float().cpu().numpy()[0]
    num_frames, channels, latent_h, latent_w = latent_np.shape
    target_h, target_w = target_hw
    target_size = (target_w, target_h)
    projection = scheme["projection"]
    per_method: dict[str, dict] = {
        method: {
            "display_masks": np.zeros((num_frames, target_h, target_w), dtype=np.uint8),
            "apply_masks": np.zeros((num_frames, channels, latent_h, latent_w), dtype=np.uint8),
            "thresholds": [],
        }
        for method in methods
    }
    records: list[dict] = []

    if projection == "pool1":
        for frame_index in range(num_frames):
            up_channels = upsample_latent_channels(latent_np[frame_index], target_size)
            pooled = robust_norm(up_channels.mean(axis=0))
            rgb_proxy = np.repeat(pooled[..., None], 3, axis=2)
            method_scores, _ = compute_methods(rgb_proxy)
            for method in methods:
                score = finite_array(method_scores[method])
                mask, threshold = _topk_mask(score, top_percent)
                latent_mask = (
                    cv2.resize(mask, (latent_w, latent_h), interpolation=cv2.INTER_NEAREST) > 0.5
                ).astype(np.uint8)
                per_method[method]["display_masks"][frame_index] = (mask > 0.5).astype(np.uint8)
                per_method[method]["apply_masks"][frame_index] = np.repeat(latent_mask[None], channels, axis=0)
                per_method[method]["thresholds"].append(float(threshold))
    elif projection == "all4":
        display_masks_by_method = {
            method: np.zeros((num_frames, channels, target_h, target_w), dtype=np.uint8)
            for method in methods
        }
        for frame_index in range(num_frames):
            up_channels = upsample_latent_channels(latent_np[frame_index], target_size)
            for channel_index in range(channels):
                rgb_proxy = np.repeat(up_channels[channel_index, :, :, None], 3, axis=2)
                method_scores, _ = compute_methods(rgb_proxy)
                for method in methods:
                    score = finite_array(method_scores[method])
                    mask, threshold = _topk_mask(score, top_percent)
                    display_masks_by_method[method][frame_index, channel_index] = (mask > 0.5).astype(np.uint8)
                    per_method[method]["apply_masks"][frame_index, channel_index] = (
                        cv2.resize(mask, (latent_w, latent_h), interpolation=cv2.INTER_NEAREST) > 0.5
                    ).astype(np.uint8)
                    per_method[method]["thresholds"].append(float(threshold))
        for method in methods:
            per_method[method]["display_masks"] = display_masks_by_method[method].max(axis=1)
    else:
        raise ValueError(f"Unknown projection {projection}")

    for method in methods:
        display_masks = per_method[method]["display_masks"]
        apply_masks = per_method[method]["apply_masks"]
        thresholds = per_method[method]["thresholds"]
        channel_coverage = apply_masks.mean(axis=(0, 2, 3)).tolist()
        union_coverage = float(display_masks.mean())
        per_method[method]["channel_coverage"] = channel_coverage
        per_method[method]["union_coverage"] = union_coverage
        records.append(
            {
                "method": method,
                "projection": projection,
                "target_height": target_h,
                "target_width": target_w,
                "top_percent": float(top_percent),
                "union_coverage": union_coverage,
                "channel0_coverage": channel_coverage[0],
                "channel1_coverage": channel_coverage[1],
                "channel2_coverage": channel_coverage[2],
                "channel3_coverage": channel_coverage[3],
                "threshold_mean": float(np.mean(thresholds)),
                "threshold_min": float(np.min(thresholds)),
                "threshold_max": float(np.max(thresholds)),
            }
        )
    return per_method, records


def apply_rgb_noise(
    latents: torch.Tensor,
    apply_mask: np.ndarray,
    sigma: float,
    seed_text: str,
) -> torch.Tensor:
    result = latents.clone()
    device = result.device
    mask = torch.from_numpy(apply_mask.astype(np.float32)).to(device=device, dtype=result.dtype)
    mask = mask.unsqueeze(0)
    seed = int(hashlib.sha256(seed_text.encode("utf-8")).hexdigest()[:8], 16)
    generator = torch.Generator(device=device).manual_seed(seed)
    noise = torch.randn(
        result[:, :, :4].shape,
        generator=generator,
        device=device,
        dtype=result.dtype,
    )
    result[:, :, :4] = result[:, :, :4] + float(sigma) * mask * noise
    return result


def save_scheme_outputs(
    scheme_dir: str,
    chunk_name: str,
    step_number: int,
    baseline_tiles: list[Image.Image],
    methods: list[str],
    per_method: dict[str, dict],
    frame_labels: list[str],
    tile_width: int,
):
    ensure_dir(scheme_dir)
    overlay_rows = []
    binary_rows = []
    for method in methods:
        display_masks = per_method[method]["display_masks"]
        overlay_rows.append(
            [
                overlay_mask(frame, display_masks[index]).resize(baseline_tiles[0].size, Image.BICUBIC)
                for index, frame in enumerate(baseline_tiles)
            ]
        )
        binary_rows.append(
            [
                binary_mask_image(display_masks[index], baseline_tiles[0].size)
                for index in range(len(baseline_tiles))
            ]
        )

    make_sheet(
        overlay_rows,
        methods,
        frame_labels,
        f"{chunk_name} step {step_number:03d} mask overlay",
    ).save(os.path.join(scheme_dir, "mask_overlay_atlas.jpg"), quality=92)
    make_sheet(
        binary_rows,
        methods,
        frame_labels,
        f"{chunk_name} step {step_number:03d} binary masks",
    ).save(os.path.join(scheme_dir, "mask_binary_atlas.jpg"), quality=92)

    latent_masks_path = os.path.join(scheme_dir, "latent_masks_rgb4.npz")
    np.savez_compressed(
        latent_masks_path,
        **{method: per_method[method]["apply_masks"].astype(np.uint8) for method in methods},
    )


@torch.no_grad()
def save_perturbed_decode_atlas(
    pipe,
    latents: torch.Tensor,
    scheme_dir: str,
    scheme_name: str,
    chunk_name: str,
    step_number: int,
    methods: list[str],
    per_method: dict[str, dict],
    sigma: float,
    frame_labels: list[str],
    tile_width: int,
):
    rows = []
    for method in methods:
        perturbed = apply_rgb_noise(
            latents,
            per_method[method]["apply_masks"],
            sigma=sigma,
            seed_text=f"{chunk_name}-{step_number}-{scheme_name}-{method}",
        )
        decoded = decode_rgb_latents_only(pipe, perturbed[:, :, :4], decode_chunk_size=latents.shape[1])[0]
        rows.append(resize_frames(decoded, tile_width))

    make_sheet(
        rows,
        methods,
        frame_labels,
        f"{chunk_name} step {step_number:03d} decoded RGB after sigma={sigma:g}",
    ).save(os.path.join(scheme_dir, f"decoded_after_sigma{sigma:g}_atlas.jpg"), quality=92)


def write_csv(path: str, rows: list[dict]):
    if not rows:
        return
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    unknown = [scheme for scheme in args.schemes if scheme not in SCHEMES]
    if unknown:
        raise ValueError(f"Unknown schemes: {unknown}. Available: {sorted(SCHEMES)}")

    method_set = set(REINJECTION_SWEEP_METHODS)
    unknown_methods = [method for method in args.methods if method not in method_set]
    if unknown_methods:
        raise ValueError(f"Unknown methods: {unknown_methods}. Available: {sorted(method_set)}")

    ensure_dir(args.output_dir)
    files = discover_latent_files(
        args.latent_root,
        args.max_files,
        file_offset=args.file_offset,
        file_stride=args.file_stride,
    )
    pipe = load_pipeline(args.model_path, args.device, args.torch_dtype)

    all_records = []
    summary = {
        "latent_root": args.latent_root,
        "output_dir": args.output_dir,
        "model_path": args.model_path,
        "device": args.device,
        "top_percent": args.top_percent,
        "sigma": args.sigma,
        "decode_perturbed": args.decode_perturbed,
        "methods": args.methods,
        "schemes": args.schemes,
        "file_offset": args.file_offset,
        "file_stride": args.file_stride,
        "files": [],
        "note": "Only the first four RGB latent channels are used for mask computation and perturbation.",
    }

    for file_index, pt_path in enumerate(files, start=1):
        chunk_name, step_number = parse_pt_path(pt_path)
        payload = torch.load(pt_path, map_location="cpu")
        latents = payload["latents"].float().to(args.device)
        if latents.shape[2] < 4:
            raise ValueError(f"{pt_path} has fewer than four channels: {tuple(latents.shape)}")
        rgb_latents = latents[:, :, :4]
        relative_dir = os.path.join(chunk_name, f"step_{step_number:03d}")
        out_dir = ensure_dir(os.path.join(args.output_dir, relative_dir))

        decoded_baseline = decode_rgb_latents_only(pipe, rgb_latents, decode_chunk_size=rgb_latents.shape[1])[0]
        baseline_tiles = resize_frames(decoded_baseline, args.tile_width)
        frame_indices = payload.get("frame_indices_in_selected_window", list(range(rgb_latents.shape[1])))
        frame_groups = payload.get("frame_groups", ["frame"] * rgb_latents.shape[1])
        frame_labels = [
            f"{frame_groups[index]} {int(frame_indices[index]):03d}"
            for index in range(len(frame_indices))
        ]

        make_sheet(
            [baseline_tiles],
            ["decode RGB"],
            frame_labels,
            f"{chunk_name} step {step_number:03d} baseline latent decode",
            label_width=120,
        ).save(os.path.join(out_dir, "decoded_rgb_baseline.jpg"), quality=92)

        pca_tiles = resize_frames(
            latent_pca_frames(rgb_latents, (args.video_width, args.video_height)),
            args.tile_width,
        )
        make_sheet(
            [pca_tiles],
            ["latent PCA"],
            frame_labels,
            f"{chunk_name} step {step_number:03d} RGB latent PCA",
            label_width=120,
        ).save(os.path.join(out_dir, "latent_pca_rgb4.jpg"), quality=92)

        file_summary = {
            "source_pt": str(pt_path),
            "relative_dir": relative_dir,
            "chunk": chunk_name,
            "step_number": step_number,
            "latent_shape": list(latents.shape),
            "rgb_latent_shape": list(rgb_latents.shape),
            "frame_indices_in_selected_window": frame_indices,
            "source_frame_indices": payload.get("source_frame_indices", []),
            "sample_tokens": payload.get("sample_tokens", []),
        }

        for scheme_name in args.schemes:
            scheme = SCHEMES[scheme_name]
            target_h = max(1, int(round(args.video_height * scheme["height_ratio"])))
            target_w = max(1, int(round(args.video_width * scheme["height_ratio"])))
            per_method, records = score_masks_for_scheme(
                rgb_latents,
                scheme,
                args.methods,
                args.top_percent,
                (target_h, target_w),
            )
            scheme_dir = ensure_dir(os.path.join(out_dir, scheme_name))
            save_scheme_outputs(
                scheme_dir,
                chunk_name,
                step_number,
                baseline_tiles,
                args.methods,
                per_method,
                frame_labels,
                args.tile_width,
            )
            if args.decode_perturbed:
                save_perturbed_decode_atlas(
                    pipe,
                    latents,
                    scheme_dir,
                    scheme_name,
                    chunk_name,
                    step_number,
                    args.methods,
                    per_method,
                    args.sigma,
                    frame_labels,
                    args.tile_width,
                )
            for record in records:
                record.update(
                    {
                        "chunk": chunk_name,
                        "step_number": step_number,
                        "source_pt": str(pt_path),
                        "scheme": scheme_name,
                    }
                )
            all_records.extend(records)

        summary["files"].append(file_summary)
        print(f"[{file_index}/{len(files)}] processed {pt_path}", flush=True)

    suffix = args.summary_suffix
    if suffix and not suffix.startswith("_"):
        suffix = "_" + suffix
    write_csv(os.path.join(args.output_dir, f"mask_coverage_summary{suffix}.csv"), all_records)
    with open(os.path.join(args.output_dir, f"summary{suffix}.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
