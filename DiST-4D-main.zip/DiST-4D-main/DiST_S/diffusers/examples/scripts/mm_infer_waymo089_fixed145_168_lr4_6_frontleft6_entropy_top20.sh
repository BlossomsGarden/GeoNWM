#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate dists

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-2}

MODEL_PATH=${MODEL_PATH:-/data4/DATA/wlh/DiST-4D/model/DiST-S-checkpoint-20000}
IMG_ROOT=${IMG_ROOT:-/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val}
OUTPUT_DIR=${OUTPUT_DIR:-/data4/DATA/wlh/DiST-4D/output/waymo089_fixed145_168_lr4_6_frontleft6_entropy_top20_dist_s}
SCENE=${SCENE:-waymo089_145_168}
PSEUDO_FLAG=${PSEUDO_FLAG:-frame_movecam2egoy-6}
FRAME_START=${FRAME_START:-0}
FRAME_COUNT=${FRAME_COUNT:-6}
DEBUG_DIR=${DEBUG_DIR:-$OUTPUT_DIR/reinjection_debug_entropy_top20}
NOISE_REINJECTION_SIGMA=${NOISE_REINJECTION_SIGMA:-0.08}
# Leave NOISE_REINJECTION_STEPS empty to apply reinjection on every denoising step.
NOISE_REINJECTION_STEPS=${NOISE_REINJECTION_STEPS:-}

cd /data4/DATA/wlh/DiST-4D/code/DiST_S/diffusers

cmd=(
python examples/inference_mm_mp_modVis_entropy_top20.py \
  --model_path "$MODEL_PATH" \
  --img_root "$IMG_ROOT" \
  --output_dir "$OUTPUT_DIR" \
  --pesudo_flag_name "$PSEUDO_FLAG" \
  --with_valid_mask \
  --video_width 768 \
  --video_height 448 \
  --video_length 6 \
  --multi_process 1 \
  --scenes "$SCENE" \
  --cameras CAM_FRONT_LEFT \
  --frame_start "$FRAME_START" \
  --frame_count "$FRAME_COUNT" \
  --max_clips 1 \
  --origin_image_mode chunk_first_gt \
  --noise_reinjection_enabled \
  --noise_reinjection_sigma "$NOISE_REINJECTION_SIGMA" \
  --noise_reinjection_latent_group rgb \
  --noise_reinjection_mask_mode entropy \
  --noise_reinjection_entropy_top_percent 20 \
  --noise_reinjection_debug_dir "$DEBUG_DIR"
)

if [[ -n "$NOISE_REINJECTION_STEPS" ]]; then
  cmd+=(--noise_reinjection_steps "$NOISE_REINJECTION_STEPS")
fi

"${cmd[@]}"
