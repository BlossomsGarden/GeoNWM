#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate dists

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-2}

MODEL_PATH=${MODEL_PATH:-/data4/DATA/wlh/DiST-4D/model/DiST-S-checkpoint-20000}
IMG_ROOT=${IMG_ROOT:-/data4/DATA/wlh/DiST-4D/data/inference_reproj}
SCENE=${SCENE:-414_scene}
PSEUDO_FLAG=${1:-frame_movecam2egoy+2}
FRAME_START=${FRAME_START:-110}
FRAME_COUNT=${FRAME_COUNT:-12}
OUTPUT_DIR=${OUTPUT_DIR:-/data4/DATA/wlh/DiST-4D/output/DiST_S_inference_${SCENE}_${FRAME_START}_${FRAME_COUNT}}

cd /data4/DATA/wlh/DiST-4D/code/DiST_S/diffusers

python examples/inference_mm_mp_modVis.py \
  --model_path "$MODEL_PATH" \
  --img_root "$IMG_ROOT" \
  --output_dir "$OUTPUT_DIR" \
  --pesudo_flag_name "$PSEUDO_FLAG" \
  --with_valid_mask \
  --video_width 768 \
  --video_height 448 \
  --video_length 6 \
  --multi_process 1 \
  --scenes "$SCENE" \
  --cameras CAM_FRONT CAM_FRONT_LEFT CAM_FRONT_RIGHT \
  --frame_start "$FRAME_START" \
  --frame_count "$FRAME_COUNT"

python examples/scripts/concat_waymo_triview.py \
  --output-root "$OUTPUT_DIR" \
  --img-root "$IMG_ROOT" \
  --pseudo-flag "$PSEUDO_FLAG" \
  --scene "$SCENE" \
  --frame_start "$FRAME_START" \
  --frame_count "$FRAME_COUNT" \
  --fps 10
