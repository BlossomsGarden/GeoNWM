import sys
import torch
import os
# from src.pipelines.pipeline_stable_video_diffusion_custom import StableVideoDiffusionPipeline_convnb_multiframe
from src.pipelines.pipeline_stable_video_diffusion_custom_mm import (
    StableVideoDiffusionPipeline_convnb_multiframe_mm,
    tensor2vid,
)
from src.pipelines.reinjection_rgb_methods import (
    REINJECTION_MASK_MODES,
    canonical_mask_mode,
    latent_frame_to_rgb_proxy,
)
from diffusers.utils import load_image, export_to_video
from glob import glob
import pickle 
import random
import imageio
import numpy as np
from PIL import Image
import torch.nn.functional as F
import math
import json
import tqdm
import random
import cv2
from PIL import Image, ImageDraw
import matplotlib

import torch.multiprocessing as mp
from functools import partial

import argparse
parser = argparse.ArgumentParser()

# running configurations
parser.add_argument('--model_path', type=str,default='./DiST_S/ckpt/')
parser.add_argument('--img_root', type=str,default = './DiST_S/reproj_nus/val')
parser.add_argument('--output_dir', type=str, default='rendered_waymo_origin') 
parser.add_argument('--video_length', type=int, default=6) # batch frame num
parser.add_argument('--multi_process', type=int, default=2) # mp num for inference
parser.add_argument("--pesudo_flag_name",type=str,default=None,help="pesudo_flag_name")
parser.add_argument("--scenes", type=str, nargs="+", default=None, help="scene ids/names to infer")
parser.add_argument("--cameras", type=str, nargs="+", default=None, help="camera names to infer")
parser.add_argument("--max_clips", type=int, default=None, help="limit clips per camera for quick reproduction")
parser.add_argument("--frame_start", type=int, default=None, help="start index within the scene token list")
parser.add_argument("--frame_count", type=int, default=None, help="number of consecutive frames to keep from frame_start")
parser.add_argument("--variant", type=str, default=None, help="optional diffusers checkpoint variant, e.g. fp16")
parser.add_argument("--torch_dtype", type=str, default="fp32", choices=["fp32", "fp16"], help="dtype used to load model weights")
parser.add_argument(
    "--origin_image_mode",
    type=str,
    default="prev_chunk_last_generated",
    choices=[
        "prev_chunk_last_generated",
        "chunk_first_gt",
        "chunk_first_pseudo",
        "first_gt",
        "first_pseudo",
    ],
    help="reference image strategy for CLIP conditioning",
)
# parser.add_argument("--front_only",action="store_true",default=False,help="whether to randomly flip images horizontally",)
parser.add_argument("--with_valid_mask",action="store_true",default=False,help="whether to use vlaid mask as input condition",)
parser.add_argument(
        "--video_height",
        type=int,
        default=320,
        help="Target height of resized video frames.",
    )
parser.add_argument(
        "--video_width",
        type=int,
        default=512,
        help="Target width of resized video frames.",
    )
parser.add_argument(
    "--noise_reinjection_enabled",
    action="store_true",
    default=False,
    help="Enable DriveLaW-style noise reinjection during denoising",
)
parser.add_argument(
    "--noise_reinjection_mask_mode",
    type=str,
    default="entropy",
    choices=REINJECTION_MASK_MODES,
    help="Mask mode used for reinjection",
)
parser.add_argument(
    "--noise_reinjection_entropy_top_percent",
    type=float,
    default=20.0,
    help="Top-k percent used for mask selection",
)
parser.add_argument(
    "--noise_reinjection_sigma",
    type=float,
    default=0.08,
    help="Noise strength for masked reinjection",
)
parser.add_argument(
    "--noise_reinjection_steps",
    type=int,
    default=None,
    help="Only apply reinjection in the first N denoising steps",
)
parser.add_argument(
    "--noise_reinjection_step_start",
    type=int,
    default=None,
    help="One-based denoising step number to start applying reinjection",
)
parser.add_argument(
    "--noise_reinjection_step_end",
    type=int,
    default=None,
    help="One-based denoising step number to stop applying reinjection",
)
parser.add_argument(
    "--noise_reinjection_latent_group",
    type=str,
    default="rgb",
    choices=["rgb", "all"],
    help="Which latent channels to perturb: rgb or all",
)
parser.add_argument(
    "--noise_reinjection_latent_proxy_mode",
    type=str,
    default="channel_mean",
    choices=["channel_mean", "halfres_all4"],
    help="How latent-space masks are proxied before top-k selection",
)
parser.add_argument(
    "--noise_reinjection_debug_dir",
    type=str,
    default=None,
    help="Directory for saving intermediate reinjection visualizations",
)
parser.add_argument(
    "--noise_reinjection_space",
    type=str,
    default="latent",
    choices=["latent", "decoded_rgb"],
    help="Compute reinjection masks directly in latent space or after RGB decode",
)
parser.add_argument(
    "--noise_reinjection_debug_steps",
    type=str,
    default="5,10,15,20",
    help="Comma-separated one-based denoising step numbers for latent visualizations.",
)
args = parser.parse_args()


def _parse_debug_step_numbers(value):
    if value is None:
        return set()
    if isinstance(value, (list, tuple, set)):
        parts = value
    else:
        parts = [part.strip() for part in str(value).split(",")]
    result = set()
    for part in parts:
        if part in {"", "none", "None", "NONE"}:
            continue
        step_number = int(part)
        if step_number <= 0:
            raise ValueError(f"debug step numbers are one-based and must be positive, got {step_number}")
        result.add(step_number)
    return result

def mask_pseudo_image(pesudo_image, random_aug_ratio=0.65, mask_aug_shape_ratio=0.):
    np_img = np.array(pesudo_image)
    ori_mask = (np.sum(np_img, axis=-1) == 0).astype(np.uint8) * 255

    # debug_path = f"/data/gen_work/code/FreeVS/diffusers/work_dirs/debug/"
    # Image.fromarray(np_img).save(f"{debug_path}/debug_original.jpg")

    # random mask pixels
    new_mask_random = np.zeros_like(ori_mask)[:, :]
    rand = np.random.rand(*new_mask_random.shape)
    new_mask_random[rand < random_aug_ratio] = 1

    # mask shape
    predefined_shapes = [
        [(10, 10), (50, 10), (40, 50), (20, 40)],
        [(15, 15), (45, 15), (45, 45), (15, 45)],
        [(30, 5), (55, 30), (30, 55), (5, 30)],
        [(20, 10), (40, 10), (50, 30), (40, 50), (20, 50), (10, 30)],
        [(25, 5), (35, 5), (45, 25), (35, 45), (25, 45), (15, 25)],
        [(10, 20), (30, 10), (50, 20), (40, 40), (20, 40)],
        [(5, 30), (25, 10), (45, 30), (35, 50), (15, 50)],
        [(20, 20), (40, 20), (40, 40), (20, 40)],
    ]
    large_shapes = [
        [(25, 15), (35, 15), (45, 30), (35, 45), (25, 45), (15, 30)],
        [(10, 25), (30, 10), (50, 25), (40, 40), (20, 40)],
        [(10, 10), (100, 10), (90, 90), (20, 80)],
        [(20, 20), (90, 20), (90, 80), (20, 80)],
        [(30, 5), (80, 30), (30, 95), (5, 30)],
        [(15, 15), (95, 15), (95, 85), (15, 85)],
        [(25, 10), (85, 10), (95, 50), (85, 90), (25, 90), (10, 50)],
        [(10, 20), (50, 10), (100, 20), (80, 80), (20, 80)],
        [(5, 30), (50, 10), (105, 30), (85, 70), (15, 70)],
        [(20, 20), (90, 20), (90, 80), (20, 80)],
        [(25, 15), (85, 15), (95, 50), (85, 85), (25, 85), (15, 50)],
        [(10, 25), (50, 10), (100, 25), (80, 75), (20, 75)],
    ]

    mask_shape = np.zeros_like(ori_mask)[:, :]
    random_var = np.random.rand()
    if random_var < mask_aug_shape_ratio:
        mask_image = Image.fromarray((mask_shape * 255).astype(np.uint8))
        draw = ImageDraw.Draw(mask_image)
        width, height = mask_image.size

        num_shapes_to_add = random.randint(1, 5)
        selected_shapes = random.sample(predefined_shapes, num_shapes_to_add)
        num_large_shapes_to_add = random.randint(1, 3)
        selected_shapes += random.sample(large_shapes, num_large_shapes_to_add)

        for shape in selected_shapes:
            max_x = width - 110
            max_y = height - 110
            top_left_x = random.randint(0, max_x)
            top_left_y = random.randint(0, max_y)
            translated_shape = [(x + top_left_x, y + top_left_y) for (x, y) in shape]
            draw.polygon(translated_shape, fill=1)

        mask_shape = np.array(mask_image)  # // 255

    np_img[new_mask_random == 1, :] = 0
    np_img[mask_shape == 1, :] = 0

    # if not os.path.exists(debug_path):
    #     os.makedirs(debug_path)
    # Image.fromarray(np_img).save(f"{debug_path}/debug_mask_aug.jpg")
    # exit()

    return Image.fromarray(np_img)


def slice_scene_tokens(sample_tokens, frame_start=None, frame_count=None):
    if frame_start is None and frame_count is None:
        return sample_tokens

    start_idx = 0 if frame_start is None else frame_start
    if start_idx < 0:
        raise ValueError(f"frame_start must be non-negative, got {frame_start}")
    if start_idx >= len(sample_tokens):
        raise ValueError(
            f"frame_start {start_idx} is out of range for a scene with {len(sample_tokens)} frames"
        )

    if frame_count is None:
        end_idx = len(sample_tokens)
    else:
        if frame_count <= 0:
            raise ValueError(f"frame_count must be positive, got {frame_count}")
        end_idx = start_idx + frame_count

    if end_idx > len(sample_tokens):
        raise ValueError(
            f"Requested frame window {start_idx}:{end_idx} exceeds scene length {len(sample_tokens)}"
        )

    sliced_tokens = sample_tokens[start_idx:end_idx]
    if not sliced_tokens:
        raise ValueError(f"No frames selected from window {start_idx}:{end_idx}")
    return sliced_tokens

def load_depth(file_name, depth_min=0.5, depth_max=100.0):
        if "gt" in file_name:
            depth = np.load(file_name)['depth_gt']
        else:
            depth = np.load(file_name)['depth_proj']
        depth = np.clip(depth, depth_min, depth_max)
        depth = np.repeat(depth[:, :, np.newaxis], 3, axis=2)
        depth /= depth_max

        return depth

def colorize_depth_maps(
    depth_map, min_depth, max_depth, cmap="Spectral", valid_mask=None
):
    """
    Colorize depth maps.
    """
    assert len(depth_map.shape) >= 2, "Invalid dimension"

    if isinstance(depth_map, torch.Tensor):
        depth = depth_map.detach().clone().squeeze().numpy()
    elif isinstance(depth_map, np.ndarray):
        depth = depth_map.copy().squeeze()
    # reshape to [ (B,) H, W ]
    if depth.ndim < 3:
        depth = depth[np.newaxis, :, :]

    # colorize
    cm = matplotlib.colormaps[cmap]
    depth = ((depth - min_depth) / (max_depth - min_depth)).clip(0, 1)
    img_colored_np = cm(depth, bytes=False)[:, :, :, 0:3]  # value from 0 to 1
    img_colored_np = np.rollaxis(img_colored_np, 3, 1)

    if valid_mask is not None:
        if isinstance(depth_map, torch.Tensor):
            valid_mask = valid_mask.detach().numpy()
        valid_mask = valid_mask.squeeze()  # [H, W] or [B, H, W]
        if valid_mask.ndim < 3:
            valid_mask = valid_mask[np.newaxis, np.newaxis, :, :]
        else:
            valid_mask = valid_mask[:, np.newaxis, :, :]
        valid_mask = np.repeat(valid_mask, 3, axis=1)
        img_colored_np[~valid_mask] = 0

    if isinstance(depth_map, torch.Tensor):
        img_colored = torch.from_numpy(img_colored_np).float()
    elif isinstance(depth_map, np.ndarray):
        img_colored = img_colored_np

    return img_colored


def _ensure_dir(path):
    os.makedirs(path, exist_ok=True)
    return path


def _frames_to_sheet(frames, row_label=None, title=None, pad=8, gap=8, label_width=132):
    if not frames:
        raise ValueError("frames must not be empty")

    tile_w, tile_h = frames[0].size
    cols = len(frames)
    title_h = 28 if title else 0
    label_w = label_width if row_label else 0
    sheet_w = pad * 2 + label_w + cols * tile_w + (cols - 1) * gap
    sheet_h = pad * 2 + title_h + tile_h
    canvas = Image.new("RGB", (sheet_w, sheet_h), (18, 18, 18))
    draw = ImageDraw.Draw(canvas)

    if title:
        draw.text((pad, pad), title, fill=(240, 240, 240))

    x0 = pad + label_w
    y0 = pad + title_h
    if row_label:
        draw.text((pad, y0 + tile_h // 2 - 8), row_label, fill=(220, 220, 220))

    for idx, frame in enumerate(frames):
        canvas.paste(frame, (x0 + idx * (tile_w + gap), y0))

    return canvas


def _stack_row_sheets(rows, row_labels=None, title=None):
    if not rows:
        raise ValueError("rows must not be empty")
    row_labels = row_labels or [None] * len(rows)
    sheets = []
    for row, row_label in zip(rows, row_labels):
        sheets.append(_frames_to_sheet(row, row_label=row_label))

    width = max(sheet.width for sheet in sheets)
    spacing = 8
    title_h = 28 if title else 0
    height = sum(sheet.height for sheet in sheets) + spacing * (len(sheets) - 1) + title_h + 8
    canvas = Image.new("RGB", (width + 16, height), (12, 12, 12))
    draw = ImageDraw.Draw(canvas)

    if title:
        draw.text((8, 8), title, fill=(240, 240, 240))

    y = 8 + title_h
    for sheet in sheets:
        canvas.paste(sheet, (8, y))
        y += sheet.height + spacing

    return canvas


def _video_frames_from_images(images):
    return [np.array(img.convert("RGB")) for img in images]


def _save_video(images, path, fps=4):
    if not images:
        return
    _ensure_dir(os.path.dirname(path))
    with imageio.get_writer(path, fps=fps, codec="libx264", bitrate="5000k", quality=10) as writer:
        for image in images:
            writer.append_data(np.array(image.convert("RGB")))


def _tensor_batch_to_pil_frames(video_tensor, pipe):
    return tensor2vid(video_tensor, pipe.image_processor, output_type="pil")[0]


def _compute_entropy_mask(decoded_rgb, top_percent, bins=8, window_size=11):
    if decoded_rgb.ndim != 5:
        raise ValueError(f"Expected decoded RGB tensor with 5 dims, got {decoded_rgb.shape}")

    if decoded_rgb.shape[1] < 3:
        rgb = decoded_rgb.repeat(1, 3, 1, 1, 1)
    else:
        rgb = decoded_rgb[:, :3]

    if window_size < 1 or window_size % 2 == 0:
        raise ValueError("window_size must be a positive odd integer")
    if bins < 2:
        raise ValueError("bins must be at least 2")

    gray = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
    gray = gray.clamp(-1.0, 1.0)
    gray = ((gray + 1.0) * 0.5).clamp(0.0, 1.0)
    batch, num_frames, height, width = gray.shape
    flat = gray.reshape(batch * num_frames, 1, height, width)
    entropy = torch.zeros_like(flat)
    pad = window_size // 2
    kernel = torch.ones((1, 1, window_size, window_size), device=gray.device, dtype=gray.dtype)
    kernel = kernel / float(window_size * window_size)
    edges = torch.linspace(0.0, 1.0 + 1e-6, bins + 1, device=gray.device, dtype=gray.dtype)

    for index in range(bins):
        lower = edges[index]
        upper = edges[index + 1]
        if index == bins - 1:
            membership = ((flat >= lower) & (flat <= upper)).to(gray.dtype)
        else:
            membership = ((flat >= lower) & (flat < upper)).to(gray.dtype)
        probability = F.conv2d(F.pad(membership, (pad, pad, pad, pad), mode="reflect"), kernel)
        entropy = entropy - probability * torch.log2(probability + 1e-6)

    entropy = entropy.reshape(batch, num_frames, height, width)
    entropy_score = (1.0 - entropy / math.log2(float(bins))).clamp(0.0, 1.0)
    flat_score = entropy_score.reshape(batch * num_frames, -1)
    num_pixels = flat_score.shape[-1]
    k = max(1, min(num_pixels, int(math.ceil(num_pixels * float(top_percent) / 100.0))))
    topk_values, topk_indices = torch.topk(flat_score, k=k, dim=-1, largest=True, sorted=False)
    mask_flat = torch.zeros_like(flat_score)
    mask_flat.scatter_(dim=-1, index=topk_indices, value=1.0)
    threshold = topk_values.amin(dim=-1, keepdim=True).reshape(batch, num_frames, 1, 1)
    mask = mask_flat.reshape(batch, num_frames, height, width)
    return mask, entropy_score, threshold


def _mask_to_pil_frames(mask_tensor):
    mask_np = mask_tensor.detach().float().cpu().numpy()
    frames = []
    for mask in mask_np[0]:
        mask_8 = np.clip(mask * 255.0, 0, 255).astype(np.uint8)
        rgb = np.zeros((mask_8.shape[0], mask_8.shape[1], 3), dtype=np.uint8)
        rgb[..., 0] = mask_8
        frames.append(Image.fromarray(rgb))
    return frames


def _overlay_mask_on_frame(frame, mask_frame, alpha=0.45):
    frame_np = np.array(frame.convert("RGB"), dtype=np.uint8)
    mask_np = mask_frame.detach().float().cpu().numpy()
    if mask_np.max() <= 1.0:
        mask_np = mask_np * 255.0
    mask_bool = mask_np > 127.5
    overlay = frame_np.copy().astype(np.float32)
    red = np.zeros_like(overlay)
    red[..., 0] = 255.0
    overlay[mask_bool] = overlay[mask_bool] * (1.0 - alpha) + red[mask_bool] * alpha
    return Image.fromarray(np.clip(overlay, 0, 255).astype(np.uint8))


def _latent_channel_count(latents, latent_group):
    if latent_group == "rgb":
        return max(1, latents.shape[2] // 2)
    return latents.shape[2]


def _latent_proxy_pil_frames(latents, latent_group="rgb", scale=8):
    if latents is None:
        return []
    latent_np = latents.detach().float().cpu().numpy()
    channel_count = _latent_channel_count(latents, latent_group)
    frames = []
    for latent_frame in latent_np[0]:
        proxy = latent_frame_to_rgb_proxy(latent_frame[:channel_count])
        image = Image.fromarray(np.clip(proxy * 255.0, 0, 255).astype(np.uint8))
        if scale != 1:
            image = image.resize((image.width * scale, image.height * scale), Image.Resampling.BICUBIC)
        frames.append(image)
    return frames


def _latent_mask_pil_frames(mask, scale=8):
    if mask is None:
        return []
    mask_np = mask.detach().float().cpu().numpy()
    frames = []
    for mask_frame in mask_np[0]:
        image = Image.fromarray(np.clip(mask_frame * 255.0, 0, 255).astype(np.uint8), mode="L").convert("RGB")
        if scale != 1:
            image = image.resize((image.width * scale, image.height * scale), Image.Resampling.NEAREST)
        frames.append(image)
    return frames


def _overlay_mask_on_proxy(proxy_frame, mask_frame, alpha=0.45):
    proxy_np = np.array(proxy_frame.convert("RGB"), dtype=np.float32)
    mask_np = np.array(mask_frame.convert("L"), dtype=np.uint8) > 127
    red = np.zeros_like(proxy_np)
    red[..., 0] = 255.0
    proxy_np[mask_np] = proxy_np[mask_np] * (1.0 - alpha) + red[mask_np] * alpha
    return Image.fromarray(np.clip(proxy_np, 0, 255).astype(np.uint8))


class NoiseReinjectionDebugger:
    def __init__(
        self,
        pipe,
        chunk_dir,
        num_frames,
        decode_chunk_size,
        sigma,
        reinjection_steps,
        latent_group="rgb",
        mask_mode="entropy",
        top_percent=20.0,
        save_every_step=True,
    ):
        self.pipe = pipe
        self.chunk_dir = chunk_dir
        self.num_frames = num_frames
        self.decode_chunk_size = decode_chunk_size
        self.sigma = sigma
        self.reinjection_steps = reinjection_steps
        self.latent_group = latent_group
        self.mask_mode = mask_mode
        self.top_percent = top_percent
        self.save_every_step = save_every_step
        self.rgb_triptychs = []
        self.depth_sheets = []
        self.step_records = []

    def _should_reinject(self, step_index):
        if self.reinjection_steps is None:
            return True
        return step_index < self.reinjection_steps

    def __call__(self, pipeline, step_index, timestep, callback_kwargs):
        del pipeline
        latents = callback_kwargs["latents"]
        decoded_before_rgb = callback_kwargs["decoded_before_rgb"]
        decoded_before_depth = callback_kwargs["decoded_before_depth"]
        decoded_after_rgb = callback_kwargs["decoded_after_rgb"]
        decoded_after_depth = callback_kwargs["decoded_after_depth"]
        mask = callback_kwargs["mask"]
        reinject_applied = bool(callback_kwargs.get("reinject_applied", False))
        step_dir = _ensure_dir(os.path.join(self.chunk_dir, f"step_{step_index:03d}"))

        before_rgb_frames = _tensor_batch_to_pil_frames(decoded_before_rgb, self.pipe)
        before_depth_frames = _tensor_batch_to_pil_frames(decoded_before_depth, self.pipe)
        after_rgb_frames = _tensor_batch_to_pil_frames(decoded_after_rgb, self.pipe)
        after_depth_frames = _tensor_batch_to_pil_frames(decoded_after_depth, self.pipe)

        mask_frames = _mask_to_pil_frames(mask)
        mask_overlay_frames = [
            _overlay_mask_on_frame(frame, mask_frame)
            for frame, mask_frame in zip(before_rgb_frames, mask[0])
        ]
        canonical_mode = canonical_mask_mode(self.mask_mode)
        mask_label = (
            f"{canonical_mode} top {self.top_percent:g}%"
        )

        rgb_triptych = _stack_row_sheets(
            [before_rgb_frames, mask_overlay_frames, after_rgb_frames],
            row_labels=["decode before", mask_label, "decode after"],
            title=f"step={step_index:03d} t={float(timestep.reshape(-1)[0]):.4f} reinject={reinject_applied}",
        )
        depth_sheet = _stack_row_sheets(
            [before_depth_frames, after_depth_frames],
            row_labels=["depth before", "depth after"],
            title=f"step={step_index:03d} depth view",
        )
        mask_sheet = _frames_to_sheet(mask_frames, row_label="mask", title=f"step={step_index:03d} raw mask")

        rgb_triptych.save(os.path.join(step_dir, "rgb_triptych.png"))
        depth_sheet.save(os.path.join(step_dir, "depth_pair.png"))
        mask_sheet.save(os.path.join(step_dir, "mask_sheet.png"))
        _frames_to_sheet(before_rgb_frames, row_label="decode before", title=f"step={step_index:03d} before RGB").save(
            os.path.join(step_dir, "rgb_before_sheet.png")
        )
        _frames_to_sheet(after_rgb_frames, row_label="decode after", title=f"step={step_index:03d} after RGB").save(
            os.path.join(step_dir, "rgb_after_sheet.png")
        )
        _frames_to_sheet(before_depth_frames, row_label="depth before", title=f"step={step_index:03d} before depth").save(
            os.path.join(step_dir, "depth_before_sheet.png")
        )
        _frames_to_sheet(after_depth_frames, row_label="depth after", title=f"step={step_index:03d} after depth").save(
            os.path.join(step_dir, "depth_after_sheet.png")
        )

        mask_dir = _ensure_dir(os.path.join(step_dir, "mask_frames"))
        for idx, mask_frame in enumerate(mask_frames):
            mask_frame.save(os.path.join(mask_dir, f"frame_{idx:03d}.png"))

        record = {
            "step_index": int(step_index),
            "timestep": float(timestep.reshape(-1)[0]),
            "reinject_applied": bool(reinject_applied),
            "mask_mean": float(mask.mean().item()),
            "mask_per_frame": [float(x) for x in mask.mean(dim=(2, 3))[0].detach().cpu().tolist()],
            "latent_group": self.latent_group,
            "sigma": float(self.sigma),
            "mask_mode": canonical_mode,
            "top_percent": float(self.top_percent),
        }
        with open(os.path.join(step_dir, "meta.json"), "w", encoding="utf-8") as f:
            json.dump(record, f, indent=2, ensure_ascii=False)

        self.rgb_triptychs.append(rgb_triptych)
        self.depth_sheets.append(depth_sheet)
        self.step_records.append(record)

        return {"latents": latents}

    def finalize(self):
        if not self.save_every_step:
            return

        _save_video(self.rgb_triptychs, os.path.join(self.chunk_dir, "debug_rgb_triptych_steps.mp4"), fps=4)
        _save_video(self.depth_sheets, os.path.join(self.chunk_dir, "debug_depth_pair_steps.mp4"), fps=4)
        with open(os.path.join(self.chunk_dir, "debug_step_records.json"), "w", encoding="utf-8") as f:
            json.dump(self.step_records, f, indent=2, ensure_ascii=False)


class LatentNoiseReinjectionDebugger:
    def __init__(
        self,
        chunk_dir,
        sigma,
        reinjection_steps,
        latent_group="rgb",
        mask_mode="entropy",
        top_percent=20.0,
        debug_step_numbers=None,
        latent_tile_scale=4,
    ):
        self.chunk_dir = chunk_dir
        self.sigma = sigma
        self.reinjection_steps = reinjection_steps
        self.latent_group = latent_group
        self.mask_mode = mask_mode
        self.top_percent = top_percent
        self.debug_step_numbers = set(debug_step_numbers or [])
        self.latent_tile_scale = latent_tile_scale
        self.step_records = []

    def __call__(self, pipeline, step_index, timestep, callback_kwargs):
        del pipeline
        latents = callback_kwargs["latents"]
        mask = callback_kwargs.get("mask")
        latent_mask_source = callback_kwargs.get("latent_mask_source")
        latents_before_reinjection = callback_kwargs.get("latents_before_reinjection")
        latents_after_reinjection = callback_kwargs.get("latents_after_reinjection")
        reinject_applied = bool(callback_kwargs.get("reinject_applied", False))
        step_number = int(step_index) + 1
        record = {
            "step_index": int(step_index),
            "step_number": step_number,
            "timestep": float(timestep.reshape(-1)[0]),
            "reinject_applied": reinject_applied,
            "latent_group": self.latent_group,
            "sigma": float(self.sigma),
            "mask_mode": canonical_mask_mode(self.mask_mode),
            "top_percent": float(self.top_percent),
            "mask_space": "latent",
            "latent_shape": list(latents.shape),
            "visualized": False,
        }
        if mask is not None:
            record["mask_mean"] = float(mask.mean().item())
            record["mask_per_frame"] = [float(x) for x in mask.mean(dim=(2, 3))[0].detach().cpu().tolist()]
            record["mask_shape"] = list(mask.shape)
        else:
            record["mask_mean"] = None
            record["mask_per_frame"] = None
            record["mask_shape"] = None

        if step_number in self.debug_step_numbers:
            step_dir = _ensure_dir(os.path.join(self.chunk_dir, f"step_{step_number:03d}"))
            source_frames = _latent_proxy_pil_frames(
                latent_mask_source, latent_group=self.latent_group, scale=self.latent_tile_scale
            )
            before_frames = _latent_proxy_pil_frames(
                latents_before_reinjection, latent_group=self.latent_group, scale=self.latent_tile_scale
            )
            after_frames = _latent_proxy_pil_frames(
                latents_after_reinjection, latent_group=self.latent_group, scale=self.latent_tile_scale
            )
            current_frames = _latent_proxy_pil_frames(
                latents, latent_group=self.latent_group, scale=self.latent_tile_scale
            )
            mask_frames = _latent_mask_pil_frames(mask, scale=self.latent_tile_scale)
            rows = []
            row_labels = []
            if source_frames:
                rows.append(source_frames)
                row_labels.append("x0 latent proxy")
            if mask_frames:
                rows.append(mask_frames)
                row_labels.append("mask")
            if source_frames and mask_frames:
                overlays = [
                    _overlay_mask_on_proxy(frame, mask_frame)
                    for frame, mask_frame in zip(source_frames, mask_frames)
                ]
                rows.append(overlays)
                row_labels.append("mask overlay")
            if before_frames:
                rows.append(before_frames)
                row_labels.append("latent before")
            if after_frames:
                rows.append(after_frames)
                row_labels.append("latent after")
            if current_frames:
                rows.append(current_frames)
                row_labels.append("latent post step")
            if rows:
                _stack_row_sheets(
                    rows,
                    row_labels=row_labels,
                    title=f"step={step_number:03d} latent reinjection debug",
                ).save(os.path.join(step_dir, "latent_debug_sheet.png"))
            record["visualized"] = True
            with open(os.path.join(step_dir, "meta.json"), "w", encoding="utf-8") as f:
                json.dump(record, f, indent=2, ensure_ascii=False)

        self.step_records.append(record)
        return {"latents": latents}

    def finalize(self):
        _ensure_dir(self.chunk_dir)
        with open(os.path.join(self.chunk_dir, "debug_step_records.json"), "w", encoding="utf-8") as f:
            json.dump(self.step_records, f, indent=2, ensure_ascii=False)


def process_camera(scene_, cam_name, gpu_id, args):
    torch.cuda.set_device(gpu_id)
    torch.cuda.empty_cache()

    model_path = args.model_path
    # img_pickle = args.img_pickle
    img_root = args.img_root
    pseudo_root = os.path.join(img_root, args.pesudo_flag_name)
    GT_root = os.path.join(img_root, 'frame_gt')
    
    dtype_map = {"fp32": torch.float32, "fp16": torch.float16}
    torch_dtype = getattr(args, "torch_dtype", "fp32")
    load_kwargs = {"torch_dtype": dtype_map[torch_dtype]}
    variant = getattr(args, "variant", None)
    if variant:
        load_kwargs["variant"] = variant
    pipe = StableVideoDiffusionPipeline_convnb_multiframe_mm.from_pretrained(
        model_path, **load_kwargs
    )
    pipe.to(f"cuda:{gpu_id}")
    pipe.enable_model_cpu_offload(gpu_id)

    # scenes = get_val_scene_list()

    # scenes = ['12505030131868863688_1740_000_1760_000_FRONT'] #demo case

    video_length=args.video_length

    # savepath=args.output_dir
    savepath=f"{args.output_dir}/{args.pesudo_flag_name}"
    os.makedirs(savepath, exist_ok=True)

    for scene in [scene_]:
        token_josn = os.path.join(pseudo_root, scene, 'pesudo_sampletoken.json')
        with open(token_josn, 'r') as f:
            sample_token_list = json.load(f)

        sample_token_list = slice_scene_tokens(
            sample_token_list,
            frame_start=args.frame_start,
            frame_count=args.frame_count,
        )
        
        scene_sample_len = len(sample_token_list)

        allframes, alldepth_frames, allcombined = [], [], []
        count=0

        os.makedirs(os.path.join(savepath, scene, cam_name),exist_ok=True)

        num_clips = math.floor(scene_sample_len/video_length)
        if args.max_clips is not None:
            num_clips = min(num_clips, args.max_clips)

        prev_chunk_last_frame = None
        first_gt_image = load_image(
            os.path.join(GT_root, scene, cam_name, f"{sample_token_list[0]}.jpg")
        ).resize((int(args.video_width), int(args.video_height)))
        first_pseudo_image = load_image(
            os.path.join(pseudo_root, scene, cam_name, f"{sample_token_list[0]}.jpg")
        ).resize((int(args.video_width), int(args.video_height)))

        for rand_int in tqdm.tqdm(range(0, num_clips), 
                                    desc=f'GPU-{gpu_id} Infer {cam_name} of {scene}'): #5hz

            if rand_int < math.floor(scene_sample_len/video_length):
                images = [os.path.join(pseudo_root, scene, cam_name, f"{sample_token_list[i]}.jpg") 
                            for i in range(rand_int*video_length, rand_int*video_length+video_length)]
                gtimage_names = [os.path.join(GT_root, scene, cam_name, f"{sample_token_list[i]}.jpg") 
                                    for i in range(rand_int*video_length, rand_int*video_length+video_length)]
                depths = [os.path.join(pseudo_root, scene, cam_name, f"{sample_token_list[i]}.npz") 
                            for i in range(rand_int*video_length, rand_int*video_length+video_length)]
                gtdepth_names = [os.path.join(GT_root, scene, cam_name, f"{sample_token_list[i]}.npz") 
                                    for i in range(rand_int*video_length, rand_int*video_length+video_length)]
            else:
                images = [os.path.join(pseudo_root, scene, cam_name, f"{sample_token_list[i]}.jpg") 
                            for i in range(scene_sample_len-video_length, scene_sample_len)]
                gtimage_names = [os.path.join(GT_root, scene, cam_name, f"{sample_token_list[i]}.jpg") 
                                    for i in range(scene_sample_len-video_length, scene_sample_len)]
                depths = [os.path.join(pseudo_root, scene, cam_name, f"{sample_token_list[i]}.npz") 
                            for i in range(scene_sample_len-video_length, scene_sample_len)]
                gtdepth_names = [os.path.join(GT_root, scene, cam_name, f"{sample_token_list[i]}.npz") 
                                    for i in range(scene_sample_len-video_length, scene_sample_len)]
            
            if not sum([os.path.exists(image) for image in images]) == len(images):
                break

            pseudo_images, gt_images, pseudo_depths, gt_depths = [], [], [], []
            for image, gt_image, depth, gt_depth in zip(images, gtimage_names, depths, gtdepth_names):
                image = load_image(image)
                gt_image = load_image(gt_image)

                depth = load_depth(depth, depth_min=0.5, depth_max=100.0)
                gt_depth = load_depth(gt_depth, depth_min=0.5, depth_max=100.0)

                ## NOTE: mask the pseudo image
                # image = mask_pseudo_image(image, random_aug_ratio=0.25, mask_aug_shape_ratio=0.)

                # image = image.resize((int(960),int(384)))
                image = image.resize((int(args.video_width),int(args.video_height)))
                gt_image = gt_image.resize((int(args.video_width),int(args.video_height)))

                depth = cv2.resize(depth, (args.video_width,args.video_height), interpolation=cv2.INTER_NEAREST)
                gt_depth = cv2.resize(gt_depth, (args.video_width,args.video_height), interpolation=cv2.INTER_NEAREST)

                if args.with_valid_mask:
                    valid_mask = (depth[:,:,-1] > 0.5/100.).astype(np.float32)
                    depth[:,:,-1] = valid_mask
                    
                depth = np.transpose(depth, (2,0,1))
                gt_depth = np.transpose(gt_depth, (2,0,1))

                pseudo_images.append(image)
                gt_images.append(gt_image)
                pseudo_depths.append(depth)
                gt_depths.append(gt_depth)
        

            # origin_image = imgs[rand_int*(video_length)]['image']
            # origin_image = gtimage_names[0] # - ----------------------------mod!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            if args.origin_image_mode == "prev_chunk_last_generated" and prev_chunk_last_frame is not None:
                origin_image = prev_chunk_last_frame.copy()
                ref_source = "prev_chunk_last_generated"
            elif args.origin_image_mode == "chunk_first_gt":
                origin_image = gt_images[0].copy()
                ref_source = "chunk_first_gt"
            elif args.origin_image_mode == "chunk_first_pseudo":
                origin_image = pseudo_images[0].copy()
                ref_source = "chunk_first_pseudo"
            elif args.origin_image_mode == "first_gt":
                origin_image = first_gt_image.copy()
                ref_source = "first_gt"
            elif args.origin_image_mode == "first_pseudo":
                origin_image = first_pseudo_image.copy()
                ref_source = "first_pseudo"
            else:
                origin_image = gt_images[0].copy()
                ref_source = "initial_chunk_first_gt"
            origin_image = origin_image.resize((int(args.video_width),int(args.video_height)))
            # origin_image = origin_image.resize((int(960),int(384)))

            print(
                f"[chunk_ref] scene={scene} cam={cam_name} chunk={rand_int} source={ref_source}",
                flush=True,
            )

            # all_gt += [origin_image]
            # all_pseudo += [image]

            generator = torch.manual_seed(42)

            debugger = None
            callback_tensor_inputs = ["latents"]
            debug_step_numbers = _parse_debug_step_numbers(args.noise_reinjection_debug_steps)
            if args.noise_reinjection_enabled and debug_step_numbers:
                debug_root = args.noise_reinjection_debug_dir or os.path.join(
                    savepath, scene, cam_name, "reinjection_debug"
                )
                chunk_debug_dir = os.path.join(debug_root, f"chunk_{rand_int:03d}")
                if args.noise_reinjection_space == "latent":
                    debugger = LatentNoiseReinjectionDebugger(
                        chunk_dir=chunk_debug_dir,
                        sigma=args.noise_reinjection_sigma,
                        reinjection_steps=args.noise_reinjection_steps,
                        latent_group=args.noise_reinjection_latent_group,
                        mask_mode=args.noise_reinjection_mask_mode,
                        top_percent=args.noise_reinjection_entropy_top_percent,
                        debug_step_numbers=debug_step_numbers,
                    )
                    callback_tensor_inputs = [
                        "latents",
                        "mask",
                        "latent_mask_source",
                        "latents_before_reinjection",
                        "latents_after_reinjection",
                        "reinject_applied",
                    ]
                else:
                    debugger = NoiseReinjectionDebugger(
                        pipe=pipe,
                        chunk_dir=chunk_debug_dir,
                        num_frames=video_length,
                        decode_chunk_size=video_length,
                        sigma=args.noise_reinjection_sigma,
                        reinjection_steps=args.noise_reinjection_steps,
                        latent_group=args.noise_reinjection_latent_group,
                        mask_mode=args.noise_reinjection_mask_mode,
                        top_percent=args.noise_reinjection_entropy_top_percent,
                    )
                    callback_tensor_inputs = [
                        "latents",
                        "decoded_before_rgb",
                        "decoded_before_depth",
                        "decoded_after_rgb",
                        "decoded_after_depth",
                        "mask",
                        "reinject_applied",
                    ]

            ret_all = pipe(pseudo_images, pseudo_depths,origin_image=origin_image,
                            width=origin_image.size[0], height=origin_image.size[1],
                            num_frames=video_length, num_inference_steps=25,
                            min_guidance_scale=2.0,max_guidance_scale=2.0,
                            noise_aug_strength=0.02, generator=generator,
                            noise_reinjection_enabled=args.noise_reinjection_enabled,
                            noise_reinjection_sigma=args.noise_reinjection_sigma,
                            noise_reinjection_steps=args.noise_reinjection_steps,
                            noise_reinjection_step_start=args.noise_reinjection_step_start,
                            noise_reinjection_step_end=args.noise_reinjection_step_end,
                            noise_reinjection_latent_group=args.noise_reinjection_latent_group,
                            noise_reinjection_mask_mode=args.noise_reinjection_mask_mode,
                            noise_reinjection_entropy_top_percent=args.noise_reinjection_entropy_top_percent,
                            noise_reinjection_space=args.noise_reinjection_space,
                            noise_reinjection_latent_proxy_mode=args.noise_reinjection_latent_proxy_mode,
                            callback_on_step_end=debugger,
                            callback_on_step_end_tensor_inputs=callback_tensor_inputs)
            
            frames = ret_all.frames[0]
            depth_frames = ret_all.depth_frames[0]  # [6,467,768,3]
            if len(frames) > 0:
                prev_chunk_last_frame = frames[-1].copy()

            # unscale depth prediction
            decode_depth_frames, colored_depth_frames, colored_gt_depths, colored_pseudo_depths = [], [], [], []
            for i in range(depth_frames.shape[0]):
                dep = np.mean(depth_frames[i], axis=-1) * 100.
                decode_depth_frames.append(dep)
                dep_color = colorize_depth_maps(dep, min_depth=0.5, max_depth=100.)[0]
                colored_depth_frames.append(np.transpose(dep_color*255, (1,2,0)).astype(np.uint8))

                dep_pseudo = np.mean(pseudo_depths[i][:2,:,:], axis=0) * 100.
                dep_pseudo_color = colorize_depth_maps(dep_pseudo, min_depth=0.5, max_depth=100.)[0]
                colored_pseudo_depths.append(np.transpose(dep_pseudo_color*255, (1,2,0)).astype(np.uint8))

                dep_gt = np.mean(gt_depths[i], axis=0) * 100.
                dep_gt_color = colorize_depth_maps(dep_gt, min_depth=0.5, max_depth=100.)[0]
                colored_gt_depths.append(np.transpose(dep_gt_color*255, (1,2,0)).astype(np.uint8))


            # import pdb; pdb.set_trace()
            allframes = allframes + frames
            alldepth_frames = alldepth_frames + decode_depth_frames

            for _i,frame in enumerate(frames):
                export_path = os.path.join(savepath, scene, cam_name, os.path.split(gtimage_names[_i])[-1])
                combined_image = np.zeros((frame.size[1] * 2, frame.size[0] * 3, 3), dtype=np.uint8)
                
                frame_cv = cv2.cvtColor(np.array(frame), cv2.COLOR_RGB2BGR) 
                pseudo_cv = cv2.cvtColor(np.array(pseudo_images[_i]), cv2.COLOR_RGB2BGR) 
                gt_cv = cv2.cvtColor(np.array(gt_images[_i]), cv2.COLOR_RGB2BGR) 
                
                # RGB
                combined_image[0:frame.size[1], 0:frame.size[0]] = frame_cv
                combined_image[0:frame.size[1], frame.size[0]:frame.size[0]*2] = pseudo_cv
                combined_image[0:frame.size[1], frame.size[0]*2:frame.size[0]*3] = gt_cv
                
                # Depth
                combined_image[frame.size[1]:frame.size[1]*2, 0:frame.size[0]] = cv2.cvtColor(colored_depth_frames[_i], cv2.COLOR_RGB2BGR) 
                combined_image[frame.size[1]:frame.size[1]*2, frame.size[0]:frame.size[0]*2] = cv2.cvtColor(colored_pseudo_depths[_i], cv2.COLOR_RGB2BGR)
                combined_image[frame.size[1]:frame.size[1]*2, frame.size[0]*2:frame.size[0]*3] = cv2.cvtColor(colored_gt_depths[_i], cv2.COLOR_RGB2BGR)
                
                allcombined += [combined_image]
                frame.save(export_path) # for fid eval
                # cv2.imwrite(export_path, combined_image)
                count += 1

            if debugger is not None:
                debugger.finalize()

        filename = os.path.join(savepath, scene, cam_name)+'.mp4'
        fps = 10
        with imageio.get_writer(filename,fps=fps,codec='libx264', bitrate='5000k', quality=10) as video:
            # for frame in allframes:
            for frame in allcombined:
                # frame = frame.convert('RGB')
                # frame = Image.fromarray(frame)#.convert('RGB')
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                video.append_data(np.array(frame))

        generated_filename = os.path.join(savepath, scene, cam_name) + "_generated_rgb.mp4"
        _save_video(allframes, generated_filename, fps=fps)
                

if __name__ == "__main__":
    mp.set_start_method('spawn', force=True)

    model_path = args.model_path
    # img_pickle = args.img_pickle
    img_root = args.img_root
    pseudo_root = os.path.join(img_root, args.pesudo_flag_name)
    GT_root = os.path.join(img_root, 'frame_gt')

    # scenes = sorted(os.listdir(pseudo_root)[300:500])
    # scenes = [str(i) for i in range(500,600)]
    # scenes = [str(num) for num in range(0,30,1)]
    # scenes = {"10": "36_scene", "13": "75_scene", "17": "79_scene", "21": "83_scene", "22": "84_scene", "25": "87_scene", "26": "88_scene", "28": "90_scene", "29": "91_scene", "30": "92_scene", "32": "214_scene", "43": "257_scene", "45": "259_scene", "47": "261_scene", "48": "262_scene", "51": "410_scene", "53": "412_scene", "55": "414_scene", "56": "436_scene", "59": "439_scene", "62": "442_scene", "63": "443_scene", "64": "444_scene", "65": "445_scene", "66": "446_scene", "67": "447_scene"}.keys()
    # scenes = ["23"]
    scene_map = {"1": "11_scene", "2": "12_scene", "3": "13_scene", "4": "14_scene", "10": "36_scene", "13": "75_scene", "17": "79_scene", "21": "83_scene", "22": "84_scene", "25": "87_scene", "26": "88_scene", "28": "90_scene", "29": "91_scene", "30": "92_scene", "32": "214_scene", "43": "257_scene", "45": "259_scene", "47": "261_scene", "48": "262_scene", "51": "410_scene", "53": "412_scene", "55": "414_scene", "56": "436_scene", "59": "439_scene", "62": "442_scene", "63": "443_scene", "64": "444_scene", "65": "445_scene", "66": "446_scene", "67": "447_scene"}
    scenes = args.scenes if args.scenes is not None else scene_map.keys()
    scenes = [scene_map.get(scene, scene) for scene in scenes]
    
    # rain_list = json.load(open("../misc/rain_night_scene_list.json", 'r'))
    # rain_list = rain_list["val"]

    camera_view = ['CAM_FRONT', 'CAM_BACK','CAM_FRONT_LEFT', 'CAM_FRONT_RIGHT','CAM_BACK_RIGHT' , 'CAM_BACK_LEFT']
    if args.cameras is not None:
        camera_view = args.cameras
    # camera_view = ['CAM_FRONT']
    num_gpus = torch.cuda.device_count()
    processes_per_gpu = args.multi_process  
    
    all_tasks = [(scene, cam) for scene in scenes for cam in camera_view]
    processes = []
    
    print(f" ====! Total {len(all_tasks)} tasks !====")
    for i, (scene, cam_name) in enumerate(all_tasks):
        gpu_id = i % num_gpus
        
        p = mp.Process(
            target=process_camera,
            args=(scene, cam_name, gpu_id, args)
        )
        processes.append(p)
        p.start()
        
        if len(processes) >= num_gpus * processes_per_gpu:
            for p in processes:
                p.join()
            processes = []
    
    for p in processes:
        p.join()
