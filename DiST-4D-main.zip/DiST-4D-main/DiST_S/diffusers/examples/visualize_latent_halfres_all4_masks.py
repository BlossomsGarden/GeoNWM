#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw

from src.pipelines.reinjection_rgb_methods import (
    REINJECTION_SWEEP_METHODS,
    _topk_mask,
    compute_methods,
    finite_array,
    robust_norm,
)


try:
    BICUBIC = Image.Resampling.BICUBIC
except AttributeError:
    BICUBIC = Image.BICUBIC


DEFAULT_METHODS = [
    "blur_periodic_agreement",
    "periodic_autocorrelation",
    "multiscale_blur_deficit",
    "local_entropy_high_texture",
    "local_variance_high_texture",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--latent_root", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--chunk", default="chunk_001")
    parser.add_argument("--steps", type=int, nargs="*", default=None)
    parser.add_argument("--methods", nargs="*", default=DEFAULT_METHODS)
    parser.add_argument("--top_percent", type=float, default=15.0)
    parser.add_argument("--video_height", type=int, default=448)
    parser.add_argument("--video_width", type=int, default=768)
    parser.add_argument("--tile_width", type=int, default=192)
    parser.add_argument("--overlay_alpha", type=float, default=0.45)
    return parser.parse_args()


def ensure_dir(path: str | Path) -> str:
    os.makedirs(path, exist_ok=True)
    return str(path)


def canonical_method_name(name: str) -> str:
    method = name.strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "multiscale_blur_deficit": "multiscale_blur_deficit",
        "local_entropy_high_texture": "local_entropy_high_texture",
        "local_variance_high_texture": "local_variance_high_texture",
    }
    return aliases.get(method, method)


def parse_step_number(path: Path) -> int:
    return int(path.stem.split("_")[-1])


def discover_latent_files(latent_root: str, chunk: str, steps: list[int] | None) -> list[Path]:
    chunk_dir = Path(latent_root) / chunk
    files = sorted(chunk_dir.glob("step_*.pt"), key=parse_step_number)
    if steps:
        wanted = {int(step) for step in steps}
        files = [path for path in files if parse_step_number(path) in wanted]
    if not files:
        raise FileNotFoundError(f"No step_*.pt files found for {chunk_dir}")
    return files


def resize_frames(frames: list[Image.Image], tile_width: int) -> list[Image.Image]:
    result = []
    for frame in frames:
        tile_height = max(1, int(round(frame.height * tile_width / frame.width)))
        result.append(frame.resize((tile_width, tile_height), BICUBIC))
    return result


def make_sheet(
    rows: list[list[Image.Image]],
    row_labels: list[str],
    col_labels: list[str] | None,
    title: str,
    gap: int = 4,
    label_width: int = 220,
    title_height: int = 28,
) -> Image.Image:
    if not rows or not rows[0]:
        raise ValueError("rows must be non-empty")
    tile_w, tile_h = rows[0][0].size
    col_label_h = 20 if col_labels else 0
    width = label_width + len(rows[0]) * tile_w + max(0, len(rows[0]) - 1) * gap
    height = title_height + col_label_h + len(rows) * tile_h + max(0, len(rows) - 1) * gap
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((4, 7), title[:160], fill=(0, 0, 0))
    y0 = title_height
    if col_labels:
        for col_index, label in enumerate(col_labels):
            x = label_width + col_index * (tile_w + gap)
            draw.text((x + 4, y0 + 3), label[:42], fill=(0, 0, 0))
        y0 += col_label_h
    for row_index, row in enumerate(rows):
        y = y0 + row_index * (tile_h + gap)
        draw.text((4, y + 4), row_labels[row_index][:90], fill=(0, 0, 0))
        for col_index, image in enumerate(row):
            x = label_width + col_index * (tile_w + gap)
            canvas.paste(image.convert("RGB"), (x, y))
    return canvas


def latent_pca_frames(rgb_latents: torch.Tensor, size: tuple[int, int]) -> list[Image.Image]:
    latents = rgb_latents.detach().float().cpu().numpy()[0]
    num_frames, channels, height, width = latents.shape
    matrix = np.transpose(latents, (0, 2, 3, 1)).reshape(-1, channels)
    matrix = finite_array(matrix)
    matrix = matrix - matrix.mean(axis=0, keepdims=True)
    matrix = matrix / (matrix.std(axis=0, keepdims=True) + 1e-6)
    _, _, vt = np.linalg.svd(matrix, full_matrices=False)
    components = matrix @ vt[:3].T
    components = components.reshape(num_frames, height, width, min(3, components.shape[-1]))
    if components.shape[-1] < 3:
        components = np.pad(components, ((0, 0), (0, 0), (0, 0), (0, 3 - components.shape[-1])))

    frames = []
    for frame_index in range(num_frames):
        rgb = np.stack(
            [robust_norm(components[frame_index, :, :, channel]) for channel in range(3)],
            axis=-1,
        )
        image = Image.fromarray((rgb * 255.0).astype(np.uint8)).resize(size, BICUBIC)
        frames.append(image)
    return frames


def latent_channel_frames(rgb_latents: torch.Tensor, size: tuple[int, int]) -> list[list[Image.Image]]:
    latents = rgb_latents.detach().float().cpu().numpy()[0]
    num_frames, channels, _, _ = latents.shape
    rows = []
    for channel_index in range(channels):
        frames = []
        for frame_index in range(num_frames):
            image = robust_norm(latents[frame_index, channel_index])
            pil = Image.fromarray((image * 255.0).astype(np.uint8), mode="L").convert("RGB")
            frames.append(pil.resize(size, BICUBIC))
        rows.append(frames)
    return rows


def latent_gray_frames(rgb_latents: torch.Tensor, size: tuple[int, int]) -> list[Image.Image]:
    latents = rgb_latents.detach().float().cpu().numpy()[0]
    num_frames = latents.shape[0]
    frames = []
    for frame_index in range(num_frames):
        gray = finite_array(latents[frame_index].mean(axis=0))
        image = robust_norm(gray)
        pil = Image.fromarray((image * 255.0).astype(np.uint8), mode="L").convert("RGB")
        frames.append(pil.resize(size, BICUBIC))
    return frames


def overlay_mask(frame: Image.Image, mask: np.ndarray, alpha: float) -> Image.Image:
    frame_np = np.array(frame.convert("RGB"), dtype=np.float32)
    mask_np = cv2.resize(
        mask.astype(np.float32),
        (frame_np.shape[1], frame_np.shape[0]),
        interpolation=cv2.INTER_NEAREST,
    )
    selected = mask_np > 0.5
    overlay = frame_np.copy()
    red = np.zeros_like(overlay)
    red[..., 0] = 255.0
    overlay[selected] = overlay[selected] * (1.0 - alpha) + red[selected] * alpha
    return Image.fromarray(np.clip(overlay, 0, 255).astype(np.uint8))


def binary_mask_image(mask: np.ndarray, size: tuple[int, int]) -> Image.Image:
    mask_resized = cv2.resize(mask.astype(np.float32), size, interpolation=cv2.INTER_NEAREST)
    rgb = np.repeat((mask_resized[..., None] > 0.5).astype(np.uint8) * 255, 3, axis=2)
    return Image.fromarray(rgb)


def compute_halfres_all4_masks(
    rgb_latents: torch.Tensor,
    methods: list[str],
    top_percent: float,
    target_hw: tuple[int, int],
) -> tuple[dict[str, dict[str, np.ndarray]], list[dict]]:
    latent_np = rgb_latents.detach().float().cpu().numpy()[0]
    num_frames, channels, latent_h, latent_w = latent_np.shape
    if channels != 4:
        raise ValueError(f"Expected four RGB latent channels, got {channels}")

    target_h, target_w = target_hw
    per_method = {
        method: {
            "diagnostic_channel_masks_halfres": np.zeros((num_frames, channels, target_h, target_w), dtype=np.uint8),
            "avg_score_masks_halfres": np.zeros((num_frames, target_h, target_w), dtype=np.uint8),
            "final_masks_latent": np.zeros((num_frames, latent_h, latent_w), dtype=np.uint8),
            "thresholds": [],
        }
        for method in methods
    }

    for frame_index in range(num_frames):
        channel_scores_by_method = {method: [] for method in methods}
        for channel_index in range(channels):
            upsampled = cv2.resize(
                latent_np[frame_index, channel_index].astype(np.float32),
                (target_w, target_h),
                interpolation=cv2.INTER_CUBIC,
            )
            proxy_rgb = np.repeat(robust_norm(upsampled)[..., None], 3, axis=2)
            method_scores, _ = compute_methods(proxy_rgb)
            for method in methods:
                score = finite_array(method_scores[method])
                diagnostic_mask, _ = _topk_mask(score, top_percent)
                per_method[method]["diagnostic_channel_masks_halfres"][frame_index, channel_index] = (
                    diagnostic_mask > 0.5
                ).astype(np.uint8)
                channel_scores_by_method[method].append(score)

        for method in methods:
            avg_score_halfres = np.mean(np.stack(channel_scores_by_method[method], axis=0), axis=0)
            score_latent = cv2.resize(
                avg_score_halfres,
                (latent_w, latent_h),
                interpolation=cv2.INTER_AREA,
            ).astype(np.float32)
            final_mask_latent, threshold = _topk_mask(score_latent, top_percent)
            final_mask_latent = (final_mask_latent > 0.5).astype(np.uint8)
            display_mask_halfres = cv2.resize(
                final_mask_latent,
                (target_w, target_h),
                interpolation=cv2.INTER_NEAREST,
            ).astype(np.uint8)
            per_method[method]["final_masks_latent"][frame_index] = final_mask_latent
            per_method[method]["avg_score_masks_halfres"][frame_index] = display_mask_halfres
            per_method[method]["thresholds"].append(float(threshold))

    records = []
    for method in methods:
        diagnostic_channel_masks_halfres = per_method[method]["diagnostic_channel_masks_halfres"]
        final_masks_latent = per_method[method]["final_masks_latent"]
        avg_score_masks_halfres = per_method[method]["avg_score_masks_halfres"]
        records.append(
            {
                "method": method,
                "top_percent": float(top_percent),
                "target_height": int(target_h),
                "target_width": int(target_w),
                "final_mask_coverage_halfres_display": float(avg_score_masks_halfres.mean()),
                "final_mask_coverage_latent": float(final_masks_latent.mean()),
                "diagnostic_channel0_coverage_halfres": float(diagnostic_channel_masks_halfres[:, 0].mean()),
                "diagnostic_channel1_coverage_halfres": float(diagnostic_channel_masks_halfres[:, 1].mean()),
                "diagnostic_channel2_coverage_halfres": float(diagnostic_channel_masks_halfres[:, 2].mean()),
                "diagnostic_channel3_coverage_halfres": float(diagnostic_channel_masks_halfres[:, 3].mean()),
                "threshold_mean": float(np.mean(per_method[method]["thresholds"])),
                "threshold_min": float(np.min(per_method[method]["thresholds"])),
                "threshold_max": float(np.max(per_method[method]["thresholds"])),
            }
        )
    return per_method, records


def frame_labels_from_payload(payload: dict, num_frames: int) -> list[str]:
    indices = payload.get("frame_indices_in_selected_window", list(range(num_frames)))
    groups = payload.get("frame_groups", ["frame"] * num_frames)
    labels = []
    for index in range(num_frames):
        group = groups[index] if index < len(groups) else "frame"
        frame_index = int(indices[index]) if index < len(indices) else index
        labels.append(f"{group} {frame_index:03d}")
    return labels


def write_csv(path: str | Path, rows: list[dict]) -> None:
    if not rows:
        return
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    methods = [canonical_method_name(method) for method in args.methods]
    unknown = [method for method in methods if method not in set(REINJECTION_SWEEP_METHODS)]
    if unknown:
        raise ValueError(f"Unknown methods: {unknown}. Available: {sorted(REINJECTION_SWEEP_METHODS)}")

    output_dir = ensure_dir(args.output_dir)
    files = discover_latent_files(args.latent_root, args.chunk, args.steps)
    target_hw = (max(1, args.video_height // 2), max(1, args.video_width // 2))
    display_size = (args.video_width, args.video_height)

    all_records = []
    overview_rows = []
    overview_gray_rows = []
    overview_labels = []
    summary = {
        "latent_root": args.latent_root,
        "output_dir": output_dir,
        "chunk": args.chunk,
        "steps": [parse_step_number(path) for path in files],
        "methods": methods,
        "scheme": "halfres_all4",
        "top_percent": float(args.top_percent),
        "video_height": int(args.video_height),
        "video_width": int(args.video_width),
        "note": "Masks match inference halfres_all4: scores are computed on each of the four RGB latent channels upsampled to half RGB resolution, averaged, downsampled to latent resolution, and top-k selected once. Overlays are drawn on RGB-latent PCA visualizations and grayscale latent averages, not decoded RGB.",
        "overlay_views": ["latent_pca", "latent_gray"],
        "files": [],
    }

    for index, pt_path in enumerate(files, start=1):
        step_number = parse_step_number(pt_path)
        payload = torch.load(pt_path, map_location="cpu")
        latents = payload["latents"].float()
        if latents.ndim != 5 or latents.shape[2] < 4:
            raise ValueError(f"{pt_path} must contain [B,F,C,H,W] latents with at least 4 channels")
        rgb_latents = latents[:, :, :4]
        num_frames = rgb_latents.shape[1]
        frame_labels = frame_labels_from_payload(payload, num_frames)

        step_dir = ensure_dir(Path(output_dir) / args.chunk / f"step_{step_number:03d}")
        pca_tiles = resize_frames(latent_pca_frames(rgb_latents, display_size), args.tile_width)
        gray_tiles = resize_frames(latent_gray_frames(rgb_latents, display_size), args.tile_width)
        make_sheet(
            [pca_tiles],
            ["latent PCA"],
            frame_labels,
            f"{args.chunk} step {step_number:03d} RGB latent PCA",
            label_width=120,
        ).save(Path(step_dir) / "latent_pca_rgb4.jpg", quality=92)

        channel_rows = [resize_frames(row, args.tile_width) for row in latent_channel_frames(rgb_latents, display_size)]
        make_sheet(
            channel_rows,
            [f"latent c{channel}" for channel in range(4)],
            frame_labels,
            f"{args.chunk} step {step_number:03d} normalized RGB latent channels",
            label_width=120,
        ).save(Path(step_dir) / "latent_channels_rgb4.jpg", quality=92)

        per_method, records = compute_halfres_all4_masks(
            rgb_latents,
            methods,
            args.top_percent,
            target_hw,
        )
        scheme_dir = ensure_dir(Path(step_dir) / "halfres_all4")
        overlay_rows = []
        gray_overlay_rows = []
        binary_rows = []
        for method in methods:
            display_masks = per_method[method]["avg_score_masks_halfres"]
            overlays = [
                overlay_mask(pca_tiles[frame_index], display_masks[frame_index], args.overlay_alpha)
                for frame_index in range(num_frames)
            ]
            gray_overlays = [
                overlay_mask(gray_tiles[frame_index], display_masks[frame_index], args.overlay_alpha)
                for frame_index in range(num_frames)
            ]
            binaries = [
                binary_mask_image(display_masks[frame_index], pca_tiles[0].size)
                for frame_index in range(num_frames)
            ]
            overlay_rows.append(overlays)
            gray_overlay_rows.append(gray_overlays)
            binary_rows.append(binaries)
            overview_rows.append(overlays)
            overview_gray_rows.append(gray_overlays)
            overview_labels.append(f"s{step_number:03d} {method}")

            channel_masks = per_method[method]["diagnostic_channel_masks_halfres"]
            channel_mask_rows = []
            channel_overlay_rows = []
            for channel_index in range(4):
                channel_mask_rows.append(
                    [
                        binary_mask_image(channel_masks[frame_index, channel_index], pca_tiles[0].size)
                        for frame_index in range(num_frames)
                    ]
                )
                channel_overlay_rows.append(
                    [
                        overlay_mask(pca_tiles[frame_index], channel_masks[frame_index, channel_index], args.overlay_alpha)
                        for frame_index in range(num_frames)
                    ]
                )
            make_sheet(
                channel_mask_rows,
                [f"c{channel}" for channel in range(4)],
                frame_labels,
                f"{args.chunk} step {step_number:03d} {method} channel masks",
                label_width=90,
            ).save(Path(scheme_dir) / f"{method}_diagnostic_channel_masks.jpg", quality=92)
            make_sheet(
                channel_overlay_rows,
                [f"c{channel}" for channel in range(4)],
                frame_labels,
                f"{args.chunk} step {step_number:03d} {method} diagnostic channel overlays on latent PCA",
                label_width=90,
            ).save(Path(scheme_dir) / f"{method}_diagnostic_channel_overlays_on_latent_pca.jpg", quality=92)

        make_sheet(
            overlay_rows,
            methods,
            frame_labels,
            f"{args.chunk} step {step_number:03d} halfres_all4 averaged-score mask overlay on latent PCA",
        ).save(Path(scheme_dir) / "mask_overlay_on_latent_pca_atlas.jpg", quality=92)
        make_sheet(
            gray_overlay_rows,
            methods,
            frame_labels,
            f"{args.chunk} step {step_number:03d} halfres_all4 averaged-score mask overlay on grayscale latent",
        ).save(Path(scheme_dir) / "mask_overlay_on_latent_gray_atlas.jpg", quality=92)
        make_sheet(
            binary_rows,
            methods,
            frame_labels,
            f"{args.chunk} step {step_number:03d} halfres_all4 averaged-score binary masks",
        ).save(Path(scheme_dir) / "mask_binary_atlas.jpg", quality=92)

        np.savez_compressed(
            Path(scheme_dir) / "halfres_all4_masks_rgb4.npz",
            **{
                f"{method}_diagnostic_channel_masks_halfres": per_method[method]["diagnostic_channel_masks_halfres"]
                for method in methods
            },
            **{
                f"{method}_avg_score_masks_halfres": per_method[method]["avg_score_masks_halfres"]
                for method in methods
            },
            **{
                f"{method}_final_masks_latent": per_method[method]["final_masks_latent"]
                for method in methods
            },
        )

        for record in records:
            record.update(
                {
                    "chunk": args.chunk,
                    "step_number": int(step_number),
                    "source_pt": str(pt_path),
                    "scheme": "halfres_all4",
                }
            )
        all_records.extend(records)
        summary["files"].append(
            {
                "source_pt": str(pt_path),
                "relative_dir": f"{args.chunk}/step_{step_number:03d}",
                "latent_shape": list(latents.shape),
                "rgb_latent_shape": list(rgb_latents.shape),
                "frame_labels": frame_labels,
                "source_frame_indices": payload.get("source_frame_indices", []),
                "sample_tokens": payload.get("sample_tokens", []),
            }
        )
        print(f"[{index}/{len(files)}] processed {pt_path}", flush=True)

    make_sheet(
        overview_rows,
        overview_labels,
        frame_labels if files else None,
        f"{args.chunk} halfres_all4 overlays on latent PCA, top {args.top_percent:g}%",
    ).save(Path(output_dir) / f"{args.chunk}_all_steps_overlay_on_latent_pca.jpg", quality=92)
    make_sheet(
        overview_gray_rows,
        overview_labels,
        frame_labels if files else None,
        f"{args.chunk} halfres_all4 overlays on grayscale latent, top {args.top_percent:g}%",
    ).save(Path(output_dir) / f"{args.chunk}_all_steps_overlay_on_latent_gray.jpg", quality=92)
    write_csv(Path(output_dir) / "mask_coverage_summary.csv", all_records)
    with open(Path(output_dir) / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
