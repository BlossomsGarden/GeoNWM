#!/usr/bin/env python3
"""Preview online nuScenes RGB-D offset supervision for Difix stage 1.

This script validates the first acceptance step in ``train-difix.md``:
take one nuScenes RGB-D sample from the grouped multicamera CSV, render a
camera shifted in ego coordinates, then reproject that shifted RGB-D view back
to the original camera to form an inpainting-style supervision pair.
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


DEPTH_EPS = 1e-6
CAMERA_ORDER: Tuple[str, ...] = (
    "CAM_FRONT_LEFT",
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_LEFT",
    "CAM_BACK",
    "CAM_BACK_RIGHT",
)


@dataclass
class NuScenesSample:
    stem: str
    camera: str
    image_path: Path
    depth_path: Path
    sample_data: dict
    calibrated_sensor: dict
    ego_pose: dict
    sensor: dict
    row_id: str = ""
    frame_id: Optional[int] = None
    scene_id: Optional[int] = None


@dataclass
class OffsetResult:
    input_rgb: np.ndarray
    training_input_depth: np.ndarray
    target_rgb: np.ndarray
    source_depth: np.ndarray
    source_valid: np.ndarray
    source_depth_for_projection: np.ndarray
    source_valid_for_projection: np.ndarray
    shifted_rgb: np.ndarray
    shifted_depth: np.ndarray
    shifted_depth_for_input: np.ndarray
    shifted_valid: np.ndarray
    shifted_depth_leak_mask: np.ndarray
    reprojected_rgb: np.ndarray
    reprojected_depth: np.ndarray
    reprojected_valid: np.ndarray
    invalid_mask: np.ndarray
    timings_ms: Dict[str, float]
    stats: Dict[str, float]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create one online left-offset nuScenes RGB-D supervision preview."
    )
    parser.add_argument(
        "--nuscenes-root",
        type=Path,
        default=Path("/data2/DATA/AutoDrive/nuscenes/v1.0-trainval"),
        help="nuScenes data root containing samples/ and v1.0-trainval/.",
    )
    parser.add_argument(
        "--nuscenes-version-dir",
        type=Path,
        default=None,
        help="Directory containing nuScenes metadata JSON files. Defaults to <root>/v1.0-trainval.",
    )
    parser.add_argument(
        "--depth-root",
        type=Path,
        default=Path("/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth"),
        help="Depth root containing CAM_*/*.npz.",
    )
    parser.add_argument(
        "--project-dir",
        type=Path,
        default=Path("/data4/DATA/wlh/Difix3D+"),
        help="Remote project directory containing nuscenes_train_samples.csv and nuscenes_val_samples.csv.",
    )
    parser.add_argument(
        "--samples-csv",
        type=Path,
        default=None,
        help="Grouped multicamera sample CSV. Defaults to <project-dir>/nuscenes_<split>_samples.csv.",
    )
    parser.add_argument(
        "--split",
        choices=["train", "val"],
        default="train",
        help="CSV split used when --samples-csv is not supplied.",
    )
    parser.add_argument(
        "--frame-id",
        type=int,
        default=0,
        help="frame_id in the grouped CSV.",
    )
    parser.add_argument("--camera", type=str, default="FRONT")
    parser.add_argument(
        "--all-cameras",
        action="store_true",
        help="Generate previews for all six cameras in --frame-id with the same offset.",
    )
    parser.add_argument(
        "--sample",
        type=str,
        default="",
        help="Optional sample stem or image filename. If set, selects the matching row from the grouped CSV.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("/data4/DATA/wlh/Difix3D+/outputs/nuscenes_stage1_offset_preview"),
    )
    parser.add_argument("--shift-left-m", type=float, default=2.0)
    parser.add_argument("--depth-max", type=float, default=120.0)
    parser.add_argument(
        "--invalid-depth-fill",
        type=float,
        default=100.0,
        help="Depth assigned to pixels outside the target valid-depth mask before offset projection.",
    )
    parser.add_argument("--tile-width", type=int, default=400)
    return parser.parse_args()


def load_json_rows(path: Path) -> list:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def resolve_version_dir(nuscenes_root: Path, version_dir: Optional[Path]) -> Path:
    if version_dir is not None:
        return version_dir
    candidate = nuscenes_root / "v1.0-trainval"
    return candidate if candidate.is_dir() else nuscenes_root


def normalize_camera_name(camera: str) -> str:
    camera = camera.strip()
    if camera.startswith("CAM_"):
        return camera
    return f"CAM_{camera}"


def short_camera_name(camera: str) -> str:
    camera = normalize_camera_name(camera)
    return camera[4:] if camera.startswith("CAM_") else camera


def camera_sort_key(camera: str) -> int:
    camera = normalize_camera_name(camera)
    if camera not in CAMERA_ORDER:
        raise ValueError(f"Unsupported camera {camera}; expected one of {CAMERA_ORDER}")
    return CAMERA_ORDER.index(camera)


def default_samples_csv(project_dir: Path, split: str) -> Path:
    return project_dir / f"nuscenes_{split}_samples.csv"


def read_csv_rows(path: Path) -> List[dict]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def select_csv_rows(
    samples_csv: Path,
    frame_id: int,
    camera: str,
    sample: str,
    all_cameras: bool,
) -> List[dict]:
    rows = read_csv_rows(samples_csv)
    if not rows:
        raise RuntimeError(f"No rows found in {samples_csv}")

    if sample:
        sample_name = Path(sample).name
        sample_stem = Path(sample).stem
        selected = [
            row for row in rows
            if Path(row.get("file", "")).name == sample_name or Path(row.get("file", "")).stem == sample_stem
        ]
        if not selected:
            raise FileNotFoundError(f"No CSV row found for sample {sample} in {samples_csv}")
        if all_cameras:
            frame_id = int(selected[0]["frame_id"])
        else:
            return [selected[0]]

    selected = [row for row in rows if int(row["frame_id"]) == int(frame_id)]
    if all_cameras:
        if len(selected) != len(CAMERA_ORDER):
            raise RuntimeError(f"frame_id={frame_id} has {len(selected)} rows in {samples_csv}, expected 6")
        return sorted(selected, key=lambda row: camera_sort_key(row["cam"]))

    normalized = normalize_camera_name(camera)
    selected = [row for row in selected if normalize_camera_name(row["cam"]) == normalized]
    if not selected:
        raise FileNotFoundError(f"No CSV row found for frame_id={frame_id}, camera={normalized} in {samples_csv}")
    return [selected[0]]


def load_metadata_indexes(version_dir: Path) -> Tuple[dict, dict, dict, dict]:
    sample_data_rows = load_json_rows(version_dir / "sample_data.json")
    calibrated_sensor_rows = load_json_rows(version_dir / "calibrated_sensor.json")
    ego_pose_rows = load_json_rows(version_dir / "ego_pose.json")
    sensor_rows = load_json_rows(version_dir / "sensor.json")

    sample_data_by_file = {Path(row.get("filename", "")).name: row for row in sample_data_rows}
    calibrated_by_token = {row["token"]: row for row in calibrated_sensor_rows}
    ego_by_token = {row["token"]: row for row in ego_pose_rows}
    sensor_by_token = {row["token"]: row for row in sensor_rows}
    return sample_data_by_file, calibrated_by_token, ego_by_token, sensor_by_token


def select_depth_path(depth_root: Path, camera: str, sample: str) -> Path:
    camera = normalize_camera_name(camera)
    camera_depth_root = depth_root / camera
    search_root = camera_depth_root if camera_depth_root.is_dir() else depth_root
    if sample:
        stem = Path(sample).stem
        path = search_root / f"{stem}.npz"
        if not path.exists():
            raise FileNotFoundError(f"Depth npz not found for sample {sample}: {path}")
        return path

    paths = sorted(search_root.glob("*.npz"))
    if not paths:
        raise FileNotFoundError(f"No depth npz files found under {search_root}")
    return paths[0]


def find_sample_from_csv_row(
    nuscenes_root: Path,
    depth_root: Path,
    row: dict,
    sample_data_by_file: dict,
    calibrated_by_token: dict,
    ego_by_token: dict,
    sensor_by_token: dict,
) -> NuScenesSample:
    camera = normalize_camera_name(row["cam"])
    filename = Path(row["file"]).name
    if filename not in sample_data_by_file:
        raise FileNotFoundError(f"Could not find sample_data metadata for CSV file {filename}")

    sample_data = sample_data_by_file[filename]
    calibrated = calibrated_by_token[sample_data["calibrated_sensor_token"]]
    sensor = sensor_by_token[calibrated["sensor_token"]]
    if sensor.get("channel") != camera:
        raise RuntimeError(f"CSV camera {camera} does not match metadata channel {sensor.get('channel')} for {filename}")

    ego_pose_token = row.get("ego_pose_token") or sample_data["ego_pose_token"]
    ego_pose = ego_by_token[ego_pose_token]
    image_path = nuscenes_root / sample_data["filename"]
    if not image_path.exists():
        image_path = nuscenes_root / "samples" / camera / filename
    if not image_path.exists():
        raise FileNotFoundError(f"Image path does not exist for {filename}: {image_path}")

    depth_path = depth_root / camera / f"{Path(filename).stem}.npz"
    if not depth_path.exists():
        depth_path = select_depth_path(depth_root, camera, filename)

    return NuScenesSample(
        stem=Path(filename).stem,
        camera=camera,
        image_path=image_path,
        depth_path=depth_path,
        sample_data=sample_data,
        calibrated_sensor=calibrated,
        ego_pose=ego_pose,
        sensor=sensor,
        row_id=str(row.get("id", "")),
        frame_id=int(row["frame_id"]) if row.get("frame_id", "") != "" else None,
        scene_id=int(row["scene_id"]) if row.get("scene_id", "") != "" else None,
    )


def find_sample(
    nuscenes_root: Path,
    version_dir: Path,
    depth_root: Path,
    camera: str,
    sample: str,
) -> NuScenesSample:
    camera = normalize_camera_name(camera)
    depth_path = select_depth_path(depth_root, camera, sample)
    stem = depth_path.stem

    sample_data_rows = load_json_rows(version_dir / "sample_data.json")
    calibrated_sensor_rows = load_json_rows(version_dir / "calibrated_sensor.json")
    ego_pose_rows = load_json_rows(version_dir / "ego_pose.json")
    sensor_rows = load_json_rows(version_dir / "sensor.json")

    calibrated_by_token = {row["token"]: row for row in calibrated_sensor_rows}
    ego_by_token = {row["token"]: row for row in ego_pose_rows}
    sensor_by_token = {row["token"]: row for row in sensor_rows}

    candidates = []
    for row in sample_data_rows:
        filename = row.get("filename", "")
        if Path(filename).stem != stem:
            continue
        calibrated = calibrated_by_token[row["calibrated_sensor_token"]]
        sensor = sensor_by_token[calibrated["sensor_token"]]
        if sensor.get("channel") == camera:
            candidates.append((row, calibrated, ego_by_token[row["ego_pose_token"]], sensor))

    if not candidates:
        raise FileNotFoundError(
            f"Could not find nuScenes sample_data metadata for {stem} and {camera} in {version_dir}"
        )
    if len(candidates) > 1:
        raise RuntimeError(f"Expected one metadata row for {stem}, found {len(candidates)}")

    sample_data, calibrated, ego_pose, sensor = candidates[0]
    image_path = nuscenes_root / sample_data["filename"]
    if not image_path.exists():
        raise FileNotFoundError(f"Image path from metadata does not exist: {image_path}")

    return NuScenesSample(
        stem=stem,
        camera=camera,
        image_path=image_path,
        depth_path=depth_path,
        sample_data=sample_data,
        calibrated_sensor=calibrated,
        ego_pose=ego_pose,
        sensor=sensor,
    )


def quaternion_to_rotation_matrix(q: Iterable[float]) -> np.ndarray:
    w, x, y, z = [float(v) for v in q]
    n = w * w + x * x + y * y + z * z
    if n < DEPTH_EPS:
        return np.eye(3, dtype=np.float32)
    s = 2.0 / n
    wx, wy, wz = s * w * x, s * w * y, s * w * z
    xx, xy, xz = s * x * x, s * x * y, s * x * z
    yy, yz, zz = s * y * y, s * y * z, s * z * z
    return np.array(
        [
            [1.0 - (yy + zz), xy - wz, xz + wy],
            [xy + wz, 1.0 - (xx + zz), yz - wx],
            [xz - wy, yz + wx, 1.0 - (xx + yy)],
        ],
        dtype=np.float32,
    )


def transform_from_translation_rotation(translation: Iterable[float], rotation: Iterable[float]) -> np.ndarray:
    transform = np.eye(4, dtype=np.float32)
    transform[:3, :3] = quaternion_to_rotation_matrix(rotation)
    transform[:3, 3] = np.asarray(list(translation), dtype=np.float32)
    return transform


def scale_intrinsics(k: np.ndarray, source_wh: Tuple[int, int], target_wh: Tuple[int, int]) -> np.ndarray:
    scaled = k.astype(np.float32).copy()
    scaled[0, :] *= float(target_wh[0]) / float(source_wh[0])
    scaled[1, :] *= float(target_wh[1]) / float(source_wh[1])
    return scaled


def load_rgb_depth(
    sample: NuScenesSample,
    depth_max: float,
    invalid_depth_fill: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict]:
    image = Image.open(sample.image_path).convert("RGB")
    with np.load(sample.depth_path) as data:
        depth = data["depth"].astype(np.float32)
        if "mask" in data.files:
            mask = data["mask"].astype(bool)
        else:
            mask = np.isfinite(depth) & (depth > DEPTH_EPS)
        if "intrinsics" in data.files:
            intrinsics = data["intrinsics"].astype(np.float32)
        else:
            official_k = np.asarray(sample.calibrated_sensor["camera_intrinsic"], dtype=np.float32)
            intrinsics = scale_intrinsics(official_k, image.size, (depth.shape[1], depth.shape[0]))
        depth_meta = {
            key: data[key].item() if data[key].shape == () else None
            for key in data.files
            if key not in {"depth", "mask", "intrinsics"}
        }

    valid = mask & np.isfinite(depth) & (depth > DEPTH_EPS) & (depth < depth_max)
    depth = np.where(valid, depth, float(invalid_depth_fill)).astype(np.float32)
    rgb = np.asarray(image.resize((depth.shape[1], depth.shape[0]), Image.BILINEAR), dtype=np.uint8)
    return rgb, depth, valid, intrinsics, depth_meta


def transform_points(transform: np.ndarray, points: np.ndarray) -> np.ndarray:
    return points @ transform[:3, :3].T + transform[:3, 3]


def backproject_rgbd_to_ego(
    rgb: np.ndarray,
    depth: np.ndarray,
    valid: np.ndarray,
    intrinsics: np.ndarray,
    camera_to_ego: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    ys, xs = np.nonzero(valid)
    if xs.size == 0:
        return np.zeros((0, 3), dtype=np.float32), np.zeros((0, 3), dtype=np.uint8)

    z = depth[ys, xs].astype(np.float32)
    fx = float(intrinsics[0, 0])
    fy = float(intrinsics[1, 1])
    cx = float(intrinsics[0, 2])
    cy = float(intrinsics[1, 2])
    points_cam = np.column_stack(
        [
            (xs.astype(np.float32) - cx) * z / fx,
            (ys.astype(np.float32) - cy) * z / fy,
            z,
        ]
    ).astype(np.float32)
    points_ego = transform_points(camera_to_ego, points_cam)
    colors = rgb[ys, xs].astype(np.uint8)
    return points_ego, colors


def project_ego_points_to_rgbd(
    points_ego: np.ndarray,
    colors: np.ndarray,
    camera_to_ego: np.ndarray,
    intrinsics: np.ndarray,
    height: int,
    width: int,
    depth_max: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    rgb = np.zeros((height, width, 3), dtype=np.uint8)
    depth = np.zeros((height, width), dtype=np.float32)
    valid = np.zeros((height, width), dtype=bool)
    if points_ego.size == 0:
        return rgb, depth, valid

    ego_to_camera = np.linalg.inv(camera_to_ego).astype(np.float32)
    points_cam = transform_points(ego_to_camera, points_ego)
    z = points_cam[:, 2]
    front = np.isfinite(z) & (z > DEPTH_EPS) & (z < depth_max)
    if not np.any(front):
        return rgb, depth, valid

    points_cam = points_cam[front]
    colors = colors[front]
    z = z[front].astype(np.float32)
    fx = float(intrinsics[0, 0])
    fy = float(intrinsics[1, 1])
    cx = float(intrinsics[0, 2])
    cy = float(intrinsics[1, 2])
    u = np.rint(points_cam[:, 0] * fx / z + cx).astype(np.int32)
    v = np.rint(points_cam[:, 1] * fy / z + cy).astype(np.int32)
    inside = (u >= 0) & (u < width) & (v >= 0) & (v < height)
    if not np.any(inside):
        return rgb, depth, valid

    u = u[inside]
    v = v[inside]
    z = z[inside]
    colors = colors[inside]
    flat_index = v * width + u

    order = np.lexsort((z, flat_index))
    sorted_flat = flat_index[order]
    keep = np.empty(sorted_flat.shape[0], dtype=bool)
    keep[0] = True
    keep[1:] = sorted_flat[1:] != sorted_flat[:-1]
    chosen = order[keep]

    chosen_u = u[chosen]
    chosen_v = v[chosen]
    rgb[chosen_v, chosen_u] = colors[chosen]
    depth[chosen_v, chosen_u] = z[chosen]
    valid[chosen_v, chosen_u] = True
    return rgb, depth, valid


def filter_far_depth_leaks(
    depth: np.ndarray,
    valid: np.ndarray,
    kernel_size: int = 5,
    abs_threshold_m: float = 0.5,
    rel_threshold: float = 0.05,
) -> np.ndarray:
    """Find far sparse points that leak through nearby foreground surfaces."""
    if kernel_size <= 1 or not np.any(valid):
        return np.zeros_like(valid, dtype=bool)
    if kernel_size % 2 == 0:
        raise ValueError(f"kernel_size must be odd, got {kernel_size}")

    sentinel = np.float32(1e6)
    depth_for_min = np.where(valid, depth.astype(np.float32), sentinel)
    kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
    local_min = cv2.erode(depth_for_min, kernel, borderType=cv2.BORDER_CONSTANT, borderValue=float(sentinel))
    threshold = np.maximum(float(abs_threshold_m), float(rel_threshold) * local_min)
    return valid & (local_min < sentinel * 0.5) & ((depth - local_min) > threshold)


def reproject_virtual_depth_to_original(
    virtual_depth: np.ndarray,
    intrinsics: np.ndarray,
    shifted_camera_to_ego: np.ndarray,
    original_camera_to_ego: np.ndarray,
    projection_depth_max: float,
    invalid_depth_fill: float,
) -> np.ndarray:
    height, width = virtual_depth.shape
    # At this point virtual_depth is already the filled training depth plane:
    # originally invalid pixels and projection holes carry invalid_depth_fill.
    # Do not re-apply the original depth-valid mask here.
    full_valid = np.isfinite(virtual_depth) & (virtual_depth > DEPTH_EPS) & (virtual_depth < projection_depth_max)
    dummy_rgb = np.zeros((height, width, 3), dtype=np.uint8)
    virtual_points_ego, virtual_colors = backproject_rgbd_to_ego(
        dummy_rgb,
        virtual_depth.astype(np.float32),
        full_valid,
        intrinsics,
        shifted_camera_to_ego,
    )
    _, input_depth, input_depth_valid = project_ego_points_to_rgbd(
        virtual_points_ego,
        virtual_colors,
        original_camera_to_ego,
        intrinsics,
        height,
        width,
        projection_depth_max,
    )
    return np.where(input_depth_valid, input_depth, float(invalid_depth_fill)).astype(np.float32)


def fill_target_invalid_depth(
    depth: np.ndarray,
    valid: np.ndarray,
    fill_depth: float,
) -> Tuple[np.ndarray, np.ndarray, int]:
    filled_depth = depth.astype(np.float32, copy=True)
    filled_valid = np.ones_like(valid, dtype=bool)
    invalid = ~valid
    count = int(np.count_nonzero(invalid))
    if count > 0:
        filled_depth[invalid] = float(fill_depth)
    return filled_depth, filled_valid, count


def generate_offset_supervision(
    rgb: np.ndarray,
    depth: np.ndarray,
    valid: np.ndarray,
    intrinsics: np.ndarray,
    camera_to_ego: np.ndarray,
    shift_left_m: float,
    depth_max: float,
    invalid_depth_fill: float,
) -> OffsetResult:
    timings: Dict[str, float] = {}
    total_t0 = time.perf_counter()
    height, width = depth.shape
    projection_depth_max = max(float(depth_max), float(invalid_depth_fill) + 1.0)

    t0 = time.perf_counter()
    source_depth_for_projection, source_valid_for_projection, invalid_depth_fill_pixels = fill_target_invalid_depth(
        depth,
        valid,
        invalid_depth_fill,
    )
    timings["target_invalid_depth_fill_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    source_points_ego, source_colors = backproject_rgbd_to_ego(
        rgb,
        source_depth_for_projection,
        source_valid_for_projection,
        intrinsics,
        camera_to_ego,
    )
    timings["backproject_source_ms"] = elapsed_ms(t0)

    # Shift the whole rig in the nuScenes ego frame: x forward, y left, z up.
    # This intentionally does not use any camera-local axis, so FRONT/BACK/side
    # cameras all move with the vehicle instead of sideways relative to their
    # own optical directions.
    shifted_camera_to_ego = camera_to_ego.copy()
    shifted_camera_to_ego[1, 3] += float(shift_left_m)

    t0 = time.perf_counter()
    shifted_rgb, shifted_depth, shifted_valid = project_ego_points_to_rgbd(
        source_points_ego,
        source_colors,
        shifted_camera_to_ego,
        intrinsics,
        height,
        width,
        projection_depth_max,
    )
    timings["project_to_shifted_left_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    shifted_depth_projected = shifted_depth
    shifted_depth_leak_mask = filter_far_depth_leaks(shifted_depth_projected, shifted_valid)
    if np.any(shifted_depth_leak_mask):
        shifted_valid = shifted_valid & ~shifted_depth_leak_mask
        shifted_rgb = shifted_rgb.copy()
        shifted_rgb[shifted_depth_leak_mask] = 0
    shifted_depth = np.where(shifted_valid, shifted_depth_projected, float(invalid_depth_fill)).astype(np.float32)
    shifted_depth_for_input = shifted_depth
    timings["shifted_depth_leak_filter_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    training_input_depth = reproject_virtual_depth_to_original(
        shifted_depth_for_input,
        intrinsics,
        shifted_camera_to_ego,
        camera_to_ego,
        projection_depth_max,
        invalid_depth_fill,
    )
    timings["project_virtual_depth_back_original_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    shifted_points_ego, shifted_colors = backproject_rgbd_to_ego(
        shifted_rgb, shifted_depth, shifted_valid, intrinsics, shifted_camera_to_ego
    )
    timings["backproject_shifted_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    reprojected_rgb, reprojected_depth, reprojected_valid = project_ego_points_to_rgbd(
        shifted_points_ego,
        shifted_colors,
        camera_to_ego,
        intrinsics,
        height,
        width,
        projection_depth_max,
    )
    reprojected_depth = np.where(
        reprojected_valid,
        reprojected_depth,
        float(invalid_depth_fill),
    ).astype(np.float32)
    timings["project_back_original_ms"] = elapsed_ms(t0)

    invalid_mask = ~reprojected_valid
    input_rgb = reprojected_rgb.copy()
    input_rgb[invalid_mask] = 0

    timings["online_offset_total_ms"] = elapsed_ms(total_t0)
    total_pixels = float(height * width)
    stats = {
        "source_points_after_invalid_depth_fill": int(source_points_ego.shape[0]),
        "shifted_points": int(shifted_points_ego.shape[0]),
        "source_valid_ratio": float(np.count_nonzero(valid) / total_pixels),
        "source_valid_for_projection_ratio": float(np.count_nonzero(source_valid_for_projection) / total_pixels),
        "shifted_valid_ratio": float(np.count_nonzero(shifted_valid) / total_pixels),
        "reprojected_valid_ratio": float(np.count_nonzero(reprojected_valid) / total_pixels),
        "offset_invalid_mask_ratio": float(np.count_nonzero(invalid_mask) / total_pixels),
        "shifted_depth_leak_filtered_pixels": int(np.count_nonzero(shifted_depth_leak_mask)),
        "shifted_depth_leak_filtered_ratio": float(np.count_nonzero(shifted_depth_leak_mask) / total_pixels),
        "target_invalid_depth_fill_pixels": int(invalid_depth_fill_pixels),
        "target_invalid_depth_fill": float(invalid_depth_fill),
        "projection_depth_max": float(projection_depth_max),
        "source_depth_zero_pixels_after_fill": int(np.count_nonzero(source_depth_for_projection <= DEPTH_EPS)),
        "shifted_depth_zero_pixels_after_fill": int(np.count_nonzero(shifted_depth <= DEPTH_EPS)),
        "training_input_depth_zero_pixels_after_fill": int(np.count_nonzero(training_input_depth <= DEPTH_EPS)),
        "width": int(width),
        "height": int(height),
        "shift_left_m": float(shift_left_m),
    }
    return OffsetResult(
        input_rgb=input_rgb,
        training_input_depth=training_input_depth,
        target_rgb=rgb,
        source_depth=depth,
        source_valid=valid,
        source_depth_for_projection=source_depth_for_projection,
        source_valid_for_projection=source_valid_for_projection,
        shifted_rgb=shifted_rgb,
        shifted_depth=shifted_depth,
        shifted_depth_for_input=shifted_depth_for_input,
        shifted_valid=shifted_valid,
        shifted_depth_leak_mask=shifted_depth_leak_mask,
        reprojected_rgb=reprojected_rgb,
        reprojected_depth=reprojected_depth,
        reprojected_valid=reprojected_valid,
        invalid_mask=invalid_mask,
        timings_ms=timings,
        stats=stats,
    )


def elapsed_ms(start: float) -> float:
    return (time.perf_counter() - start) * 1000.0


def depth_to_color(depth: np.ndarray, valid: np.ndarray, max_depth: float) -> np.ndarray:
    clipped = np.clip(depth.astype(np.float32), 0.0, max_depth)
    scaled = np.zeros_like(clipped, dtype=np.uint8)
    scaled[valid] = np.clip((1.0 - clipped[valid] / max_depth) * 255.0, 0, 255).astype(np.uint8)
    color_bgr = cv2.applyColorMap(scaled, cv2.COLORMAP_TURBO)
    color = cv2.cvtColor(color_bgr, cv2.COLOR_BGR2RGB)
    color[~valid] = np.array([18, 18, 18], dtype=np.uint8)
    return color


def mask_to_rgb(mask: np.ndarray, positive_color: Tuple[int, int, int]) -> np.ndarray:
    out = np.zeros((*mask.shape, 3), dtype=np.uint8)
    out[mask] = np.asarray(positive_color, dtype=np.uint8)
    return out


def overlay_mask(rgb: np.ndarray, mask: np.ndarray, color: Tuple[int, int, int] = (255, 48, 48)) -> np.ndarray:
    out = rgb.copy().astype(np.float32)
    color_arr = np.asarray(color, dtype=np.float32)
    out[mask] = out[mask] * 0.35 + color_arr * 0.65
    return np.clip(out, 0, 255).astype(np.uint8)


def resize_tile(tile: np.ndarray, tile_width: int) -> Image.Image:
    image = Image.fromarray(tile)
    height = int(round(tile_width * image.height / image.width))
    return image.resize((tile_width, height), Image.BILINEAR)


def draw_label(draw: ImageDraw.ImageDraw, xy: Tuple[int, int], text: str) -> None:
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None
    x, y = xy
    if hasattr(draw, "textbbox"):
        bbox = draw.textbbox((x, y), text, font=font)
        draw.rectangle((bbox[0] - 4, bbox[1] - 2, bbox[2] + 4, bbox[3] + 2), fill=(255, 255, 255))
    draw.text((x, y), text, fill=(0, 0, 0), font=font)


def make_preview(result: OffsetResult, output_path: Path, tile_width: int, title: str) -> None:
    depth_max_for_view = max(120.0, float(result.stats.get("target_invalid_depth_fill", 100.0)))
    full_depth_valid = np.ones_like(result.source_valid, dtype=bool)
    tiles = [
        ("Target RGB", result.target_rgb),
        ("Target depth (filled)", depth_to_color(result.source_depth, full_depth_valid, depth_max_for_view)),
        ("Target valid depth", mask_to_rgb(result.source_valid, (82, 190, 96))),
        (
            "Source depth for projection (filled)",
            depth_to_color(
                result.source_depth_for_projection,
                full_depth_valid,
                depth_max_for_view,
            ),
        ),
        ("Left-shift virtual RGB", result.shifted_rgb),
        (
            "Left-shift virtual depth (filled)",
            depth_to_color(result.shifted_depth_for_input, full_depth_valid, depth_max_for_view),
        ),
        ("Training input RGB", result.input_rgb),
        ("Invalid mask", mask_to_rgb(result.invalid_mask, (255, 255, 255))),
        (
            "Training input depth (filled)",
            depth_to_color(result.training_input_depth, full_depth_valid, depth_max_for_view),
        ),
    ]

    resized = [(label, resize_tile(tile, tile_width)) for label, tile in tiles]
    tile_h = resized[0][1].height
    label_h = 26
    gap = 10
    cols = 3
    rows = 3
    info_w = 360
    canvas_w = cols * tile_width + (cols + 1) * gap + info_w + gap
    canvas_h = rows * (tile_h + label_h) + (rows + 1) * gap
    canvas = Image.new("RGB", (canvas_w, canvas_h), (245, 246, 248))
    draw = ImageDraw.Draw(canvas)

    for index, (label, image) in enumerate(resized):
        row = index // cols
        col = index % cols
        x = gap + col * (tile_width + gap)
        y = gap + row * (tile_h + label_h + gap)
        draw_label(draw, (x, y), label)
        canvas.paste(image, (x, y + label_h))

    info_x = cols * tile_width + (cols + 1) * gap
    info_y = gap
    draw.rounded_rectangle(
        (info_x, info_y, canvas_w - gap, canvas_h - gap),
        radius=6,
        fill=(255, 255, 255),
        outline=(210, 214, 220),
    )
    info_lines = [title, "", "Timings"]
    for key, value in result.timings_ms.items():
        info_lines.append(f"{key}: {value:.1f} ms")
    info_lines.extend(["", "Stats"])
    for key, value in result.stats.items():
        if isinstance(value, float):
            info_lines.append(f"{key}: {value:.4f}")
        else:
            info_lines.append(f"{key}: {value}")

    y = info_y + 14
    for line in info_lines:
        draw.text((info_x + 14, y), line, fill=(20, 24, 28))
        y += 18

    output_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output_path)


def write_image(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(image).save(path)


def make_six_camera_rgb_summary(
    processed: Sequence[Tuple[NuScenesSample, OffsetResult]],
    output_path: Path,
    tile_width: int,
    title: str,
) -> None:
    ordered = sorted(processed, key=lambda item: camera_sort_key(item[0].camera))
    if len(ordered) != len(CAMERA_ORDER):
        raise ValueError(f"Expected six processed cameras, got {len(ordered)}")

    label_h = 26
    section_h = 30
    gap = 10
    cols = 3
    tile_images = [resize_tile(sample_result[1].input_rgb, tile_width) for sample_result in ordered]
    target_images = [resize_tile(sample_result[1].target_rgb, tile_width) for sample_result in ordered]
    tile_h = tile_images[0].height
    grid_h = section_h + 2 * (label_h + tile_h) + gap
    canvas_w = cols * tile_width + (cols + 1) * gap
    canvas_h = 2 * grid_h + gap + 34
    canvas = Image.new("RGB", (canvas_w, canvas_h), (245, 246, 248))
    draw = ImageDraw.Draw(canvas)
    draw.text((gap, 10), title, fill=(20, 24, 28))

    def paste_grid(section_y: int, section_title: str, images: Sequence[Image.Image]) -> None:
        draw.rectangle((gap, section_y, canvas_w - gap, section_y + section_h), fill=(255, 255, 255))
        draw.text((gap + 8, section_y + 9), section_title, fill=(20, 24, 28))
        for idx, (sample, _) in enumerate(ordered):
            row = idx // cols
            col = idx % cols
            x = gap + col * (tile_width + gap)
            y = section_y + section_h + gap + row * (label_h + tile_h + gap)
            draw_label(draw, (x, y), short_camera_name(sample.camera))
            canvas.paste(images[idx], (x, y + label_h))

    first_y = 34
    second_y = first_y + grid_h + gap
    paste_grid(first_y, "Training input RGB", tile_images)
    paste_grid(second_y, "Target RGB", target_images)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output_path)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    version_dir = resolve_version_dir(args.nuscenes_root, args.nuscenes_version_dir)
    samples_csv = args.samples_csv or default_samples_csv(args.project_dir, args.split)

    t0 = time.perf_counter()
    selected_rows = select_csv_rows(
        samples_csv=samples_csv,
        frame_id=args.frame_id,
        camera=args.camera,
        sample=args.sample,
        all_cameras=args.all_cameras,
    )
    sample_data_by_file, calibrated_by_token, ego_by_token, sensor_by_token = load_metadata_indexes(version_dir)
    metadata_load_ms = elapsed_ms(t0)

    generated = []
    processed_for_summary: List[Tuple[NuScenesSample, OffsetResult]] = []
    for row_index, row in enumerate(selected_rows):
        total_start = time.perf_counter()
        sample = find_sample_from_csv_row(
            nuscenes_root=args.nuscenes_root,
            depth_root=args.depth_root,
            row=row,
            sample_data_by_file=sample_data_by_file,
            calibrated_by_token=calibrated_by_token,
            ego_by_token=ego_by_token,
            sensor_by_token=sensor_by_token,
        )

        t0 = time.perf_counter()
        rgb, depth, valid, intrinsics, depth_meta = load_rgb_depth(
            sample,
            args.depth_max,
            args.invalid_depth_fill,
        )
        read_rgb_depth_ms = elapsed_ms(t0)

        official_k = np.asarray(sample.calibrated_sensor["camera_intrinsic"], dtype=np.float32)
        scaled_official_k = scale_intrinsics(
            official_k,
            (int(sample.sample_data["width"]), int(sample.sample_data["height"])),
            (depth.shape[1], depth.shape[0]),
        )
        intrinsics_max_abs_diff_from_scaled_official = float(np.max(np.abs(intrinsics - scaled_official_k)))

        camera_to_ego = transform_from_translation_rotation(
            sample.calibrated_sensor["translation"],
            sample.calibrated_sensor["rotation"],
        )
        ego_to_global = transform_from_translation_rotation(
            sample.ego_pose["translation"],
            sample.ego_pose["rotation"],
        )

        result = generate_offset_supervision(
            rgb=rgb,
            depth=depth,
            valid=valid,
            intrinsics=intrinsics,
            camera_to_ego=camera_to_ego,
            shift_left_m=args.shift_left_m,
            depth_max=args.depth_max,
            invalid_depth_fill=args.invalid_depth_fill,
        )
        result.timings_ms = {
            "metadata_load_ms": metadata_load_ms if row_index == 0 else 0.0,
            "read_rgb_depth_ms": read_rgb_depth_ms,
            **result.timings_ms,
            "sample_total_ms": elapsed_ms(total_start),
        }

        offset_label = "left" if args.shift_left_m >= 0 else "right"
        offset_m = abs(float(args.shift_left_m))
        frame_label = f"frame{sample.frame_id:06d}_" if sample.frame_id is not None else ""
        stem_prefix = f"{frame_label}{short_camera_name(sample.camera)}_{sample.stem}_{offset_label}_{offset_m:g}m"
        preview_path = args.output_dir / f"{stem_prefix}_supervision_preview.png"
        make_preview(
            result,
            preview_path,
            args.tile_width,
            title=(
                f"{sample.camera} frame_id={sample.frame_id} scene_id={sample.scene_id} "
                f"{sample.stem} {offset_label} {offset_m:g}m"
            ),
        )

        depth_max_for_output = max(120.0, float(args.invalid_depth_fill))
        input_depth_path = args.output_dir / f"{stem_prefix}_input_depth.png"
        write_image(args.output_dir / f"{stem_prefix}_target_rgb.png", result.target_rgb)
        write_image(args.output_dir / f"{stem_prefix}_input_rgb.png", result.input_rgb)
        write_image(args.output_dir / f"{stem_prefix}_invalid_mask.png", (result.invalid_mask.astype(np.uint8) * 255))
        write_image(args.output_dir / f"{stem_prefix}_shifted_rgb.png", result.shifted_rgb)
        write_image(
            input_depth_path,
            depth_to_color(
                result.training_input_depth,
                np.ones_like(result.reprojected_valid, dtype=bool),
                depth_max_for_output,
            ),
        )

        manifest = {
            "csv": {
                "samples_csv": str(samples_csv),
                "row": row,
            },
            "sample": {
                "stem": sample.stem,
                "camera": sample.camera,
                "row_id": sample.row_id,
                "frame_id": sample.frame_id,
                "scene_id": sample.scene_id,
                "image_path": str(sample.image_path),
                "depth_path": str(sample.depth_path),
                "timestamp": sample.sample_data["timestamp"],
                "image_size": [int(sample.sample_data["width"]), int(sample.sample_data["height"])],
                "depth_size": [int(depth.shape[1]), int(depth.shape[0])],
            },
            "geometry": {
                "coordinate_convention": "nuScenes ego: x forward, y left, z up; camera uses calibrated sensor frame",
                "offset": {
                    "camera2ego_translation_y_add_m": float(args.shift_left_m),
                    "label": f"{offset_label} {offset_m:g}m",
                },
                "camera_to_ego": camera_to_ego.tolist(),
                "ego_to_global": ego_to_global.tolist(),
                "intrinsics_used": intrinsics.tolist(),
                "official_intrinsics_scaled_to_depth": scaled_official_k.tolist(),
                "intrinsics_max_abs_diff_from_scaled_official": intrinsics_max_abs_diff_from_scaled_official,
                "depth_max": float(args.depth_max),
                "projection_depth_max": max(float(args.depth_max), float(args.invalid_depth_fill) + 1.0),
                "target_invalid_depth_fill": {
                    "depth": float(args.invalid_depth_fill),
                    "mask": "target_valid_depth == false",
                    "applied_at": "load_rgb_depth; target/source/virtual/training depth arrays keep this fill in data, not only in visualization",
                },
                "training_mask_definition": (
                    "offset/reprojection invalid pixels only; source depth invalid/sky pixels "
                    "are filled to target_invalid_depth_fill and are excluded from the mask"
                ),
            },
            "depth_meta": depth_meta,
            "timings_ms": result.timings_ms,
            "stats": result.stats,
            "outputs": {
                "preview": str(preview_path),
                "target_rgb": str(args.output_dir / f"{stem_prefix}_target_rgb.png"),
                "input_rgb": str(args.output_dir / f"{stem_prefix}_input_rgb.png"),
                "input_depth": str(input_depth_path),
                "invalid_mask": str(args.output_dir / f"{stem_prefix}_invalid_mask.png"),
                "shifted_rgb": str(args.output_dir / f"{stem_prefix}_shifted_rgb.png"),
            },
        }
        manifest_path = args.output_dir / f"{stem_prefix}_manifest.json"
        with manifest_path.open("w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        generated.append({"camera": sample.camera, "preview": str(preview_path), "manifest": str(manifest_path)})
        processed_for_summary.append((sample, result))
        print(json.dumps(generated[-1], indent=2))
        print("timings_ms", json.dumps(result.timings_ms, indent=2))
        print("stats", json.dumps(result.stats, indent=2))

    summary_path = None
    if args.all_cameras and len(processed_for_summary) == len(CAMERA_ORDER):
        first_sample = processed_for_summary[0][0]
        offset_label = "left" if args.shift_left_m >= 0 else "right"
        offset_m = abs(float(args.shift_left_m))
        frame_label = f"frame{first_sample.frame_id:06d}" if first_sample.frame_id is not None else "frame_unknown"
        summary_path = args.output_dir / f"{frame_label}_{offset_label}_{offset_m:g}m_sixcam_input_target_rgb_summary.png"
        make_six_camera_rgb_summary(
            processed_for_summary,
            summary_path,
            args.tile_width,
            title=(
                f"{frame_label} scene_id={first_sample.scene_id} "
                f"ego-frame rig shift: {offset_label} {offset_m:g}m"
            ),
        )
        print(json.dumps({"six_camera_rgb_summary": str(summary_path)}, indent=2))

    print(json.dumps({"generated": generated, "six_camera_rgb_summary": str(summary_path) if summary_path else None}, indent=2))


if __name__ == "__main__":
    main()
