# Anchored Diffusion

Depth-Prior Async stage-1 training lives in `examples/train_anchored_async.py`.

Scheme switch:

```bash
ASYNC_DELTA=0.3 bash examples/scripts/anchor_async_train_stage1.sh  # main
ASYNC_DELTA=0 bash examples/scripts/anchor_async_train_stage1.sh    # ablation B
```

Only `ASYNC_DELTA` changes between the main scheme and ablation B. Both use the
async-capable UNet with dual RGB/depth timestep embeddings and the 17th
max-pooled mask input channel.
