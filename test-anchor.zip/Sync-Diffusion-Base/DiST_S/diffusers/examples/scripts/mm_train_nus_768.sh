#!/usr/bin/env bash
set -euo pipefail

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1}"
export NCCL_P2P_LEVEL="${NCCL_P2P_LEVEL:-NVL}"
export HF_HOME="${HF_HOME:-./huggingface}"

MODEL_NAME="${MODEL_NAME:-/data4/DATA/wlh/Difix3D+/model/SVD_XT}"
if [ ! -d "$MODEL_NAME" ]; then
  MODEL_NAME="${MODEL_FALLBACK:-/data4/DATA/wlh/Difix3D+/model}"
fi

PROJECT_DIR="${PROJECT_DIR:-/data4/DATA/wlh/Difix3D+}"
WORK_DIR="${WORK_DIR:-../ckpt}"
WORK="${WORK:-s1_sync_online_offset_6f}"
EXP="${EXP:-s1_sync_online_offset_6f}"
OUTPUT_DIR="${OUTPUT_DIR:-${WORK_DIR}/${WORK}}"
MAX_TRAIN_STEPS="${MAX_TRAIN_STEPS:-60000}"
CHECKPOINTING_STEPS="${CHECKPOINTING_STEPS:-2500}"
GRAD_ACCUM_STEPS="${GRAD_ACCUM_STEPS:-4}"
DATALOADER_WORKERS="${DATALOADER_WORKERS:-6}"
MAIN_PROCESS_PORT="${MAIN_PROCESS_PORT:-12012}"

accelerate launch --config_file fsdp.yaml --main_process_port "$MAIN_PROCESS_PORT" examples/train_svd_nus_mm.py \
  --pretrained_model_name_or_path="$MODEL_NAME" \
  --anchored_stage1_online \
  --anchor_project_dir="$PROJECT_DIR" \
  --nuscenes_root="${NUSCENES_ROOT:-/data2/DATA/AutoDrive/nuscenes/v1.0-trainval}" \
  --depth_root="${DEPTH_ROOT:-/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth}" \
  --use_ema \
  --train_batch_size 1 \
  --video_width "${VIDEO_WIDTH:-768}" \
  --video_height "${VIDEO_HEIGHT:-448}" \
  --gradient_accumulation_steps "$GRAD_ACCUM_STEPS" \
  --enable_xformers_memory_efficient_attention \
  --max_train_steps "$MAX_TRAIN_STEPS" \
  --learning_rate 5e-05 \
  --max_grad_norm 1 \
  --lr_scheduler="constant" \
  --output_dir="$OUTPUT_DIR" \
  --dataloader_num_workers "$DATALOADER_WORKERS" \
  --nframes 6 \
  --offset_mode "${OFFSET_MODE:-curriculum}" \
  --offset_warmup_fraction "${OFFSET_WARMUP_FRACTION:-0.5}" \
  --conditioning_dropout_prob=0.2 \
  --seed_for_gen=42 \
  --ddim \
  --checkpointing_steps "$CHECKPOINTING_STEPS" \
  --tracker_project_name "$EXP" \
  --initialize_pseudoimg_encoder \
  --use_svd_pretrain
