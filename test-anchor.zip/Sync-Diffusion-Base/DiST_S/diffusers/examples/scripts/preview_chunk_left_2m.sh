#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/data4/DATA/wlh/Difix3D+}"
OUTPUT="${OUTPUT:-${PROJECT_DIR}/outputs/s1_chunk_left_2m_sixcam_supervision.mp4}"

python examples/utils/preview_stage1_offset_chunk.py \
  --project-dir "$PROJECT_DIR" \
  --nuscenes-root "${NUSCENES_ROOT:-/data2/DATA/AutoDrive/nuscenes/v1.0-trainval}" \
  --depth-root "${DEPTH_ROOT:-/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth}" \
  --samples-csv "${SAMPLES_CSV:-${PROJECT_DIR}/nuscenes_train_samples.csv}" \
  --split "${SPLIT:-train}" \
  --scene-id "${SCENE_ID:-}" \
  --chunk-start "${CHUNK_START:-2}" \
  --chunk-length "${CHUNK_LENGTH:-6}" \
  --shift-left-m "${SHIFT_LEFT_M:-2.0}" \
  --tile-width "${TILE_WIDTH:-256}" \
  --fps "${FPS:-1}" \
  --output "$OUTPUT"
