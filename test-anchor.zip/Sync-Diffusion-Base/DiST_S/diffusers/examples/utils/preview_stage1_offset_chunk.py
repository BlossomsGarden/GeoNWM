#!/usr/bin/env python3
"""Create a six-camera chunk preview for the S1 online offset dataset."""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image, ImageDraw


EXAMPLES_DIR = Path(__file__).resolve().parents[1]
if str(EXAMPLES_DIR) not in sys.path:
    sys.path.insert(0, str(EXAMPLES_DIR))

from utils.stage1_offset_geometry import (  # noqa: E402
    CAMERA_ORDER,
    NuScenesSample,
    OffsetResult,
    camera_sort_key,
    default_samples_csv,
    depth_to_color,
    draw_label,
    find_sample_from_csv_row,
    generate_offset_supervision,
    load_metadata_indexes,
    load_rgb_depth,
    mask_to_rgb,
    normalize_camera_name,
    read_csv_rows,
    resize_tile,
    resolve_version_dir,
    short_camera_name,
    transform_from_translation_rotation,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render one S1 online-offset chunk as a stitched six-camera supervision video."
    )
    parser.add_argument(
        "--nuscenes-root",
        type=Path,
        default=Path("/data2/DATA/AutoDrive/nuscenes/v1.0-trainval"),
    )
    parser.add_argument("--nuscenes-version-dir", type=Path, default=None)
    parser.add_argument(
        "--depth-root",
        type=Path,
        default=Path("/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth"),
    )
    parser.add_argument(
        "--project-dir",
        type=Path,
        default=Path("/data4/DATA/wlh/Difix3D+"),
    )
    parser.add_argument("--samples-csv", type=Path, default=None)
    parser.add_argument("--split", choices=["train", "val"], default="train")
    parser.add_argument(
        "--scene-id",
        type=str,
        default="",
        help="Optional scene_id from the grouped CSV. If omitted, the first valid six-camera scene is used.",
    )
    parser.add_argument("--chunk-start", type=int, default=2)
    parser.add_argument("--chunk-length", type=int, default=6)
    parser.add_argument("--shift-left-m", type=float, default=2.0)
    parser.add_argument("--depth-max", type=float, default=120.0)
    parser.add_argument("--invalid-depth-fill", type=float, default=100.0)
    parser.add_argument("--tile-width", type=int, default=256)
    parser.add_argument("--fps", type=float, default=1.0)
    parser.add_argument("--fourcc", type=str, default="mp4v")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("/data4/DATA/wlh/Difix3D+/outputs/s1_chunk_left_2m_sixcam_supervision.mp4"),
    )
    return parser.parse_args()


def _row_frame_id(row: dict) -> int:
    return int(row["frame_id"])


def build_grouped_rows(rows: List[dict]) -> Dict[Tuple[str, str], List[dict]]:
    grouped: Dict[Tuple[str, str], List[dict]] = defaultdict(list)
    valid_cameras = set(CAMERA_ORDER)
    for row in rows:
        camera = normalize_camera_name(row["cam"])
        if camera not in valid_cameras:
            continue
        scene_id = str(row.get("scene_id", ""))
        grouped[(scene_id, camera)].append(row)
    for key, group_rows in grouped.items():
        grouped[key] = sorted(group_rows, key=_row_frame_id)
    return grouped


def select_six_camera_chunk(
    grouped: Dict[Tuple[str, str], List[dict]],
    scene_id: str,
    chunk_start: int,
    chunk_length: int,
) -> Tuple[str, Dict[str, dict], Dict[str, List[dict]]]:
    if chunk_start < 2:
        raise ValueError("S1 chunk_start must be >= 2 because the CLIP condition is chunk_start - 2.")
    if chunk_length <= 0:
        raise ValueError("chunk_length must be positive.")

    candidate_scenes = [scene_id] if scene_id else sorted({key[0] for key in grouped})
    for candidate_scene in candidate_scenes:
        condition_rows: Dict[str, dict] = {}
        chunk_rows: Dict[str, List[dict]] = {}
        for camera in CAMERA_ORDER:
            group_rows = grouped.get((candidate_scene, camera), [])
            end = chunk_start + chunk_length
            if len(group_rows) < end:
                break
            condition_rows[camera] = group_rows[chunk_start - 2]
            chunk_rows[camera] = group_rows[chunk_start:end]
        if len(chunk_rows) == len(CAMERA_ORDER):
            return candidate_scene, condition_rows, chunk_rows

    wanted = scene_id or "any scene"
    raise RuntimeError(
        f"No valid six-camera chunk found for {wanted}, chunk_start={chunk_start}, chunk_length={chunk_length}."
    )


def load_supervision_result(
    row: dict,
    args: argparse.Namespace,
    indexes: Tuple[dict, dict, dict, dict],
) -> Tuple[NuScenesSample, OffsetResult]:
    sample_data_by_file, calibrated_by_token, ego_by_token, sensor_by_token = indexes
    sample = find_sample_from_csv_row(
        nuscenes_root=args.nuscenes_root,
        depth_root=args.depth_root,
        row=row,
        sample_data_by_file=sample_data_by_file,
        calibrated_by_token=calibrated_by_token,
        ego_by_token=ego_by_token,
        sensor_by_token=sensor_by_token,
    )
    rgb, depth, valid, intrinsics, _ = load_rgb_depth(
        sample,
        args.depth_max,
        args.invalid_depth_fill,
    )
    camera_to_ego = transform_from_translation_rotation(
        sample.calibrated_sensor["translation"],
        sample.calibrated_sensor["rotation"],
    )
    result = generate_offset_supervision(
        rgb=rgb,
        depth=depth,
        valid=valid,
        intrinsics=intrinsics,
        camera_to_ego=camera_to_ego,
        shift_left_m=args.shift_left_m,
        depth_max=args.depth_max,
        invalid_depth_fill=args.invalid_depth_fill,
    )
    return sample, result


def pad_even(image: Image.Image) -> Image.Image:
    width = image.width + (image.width % 2)
    height = image.height + (image.height % 2)
    if (width, height) == image.size:
        return image
    out = Image.new("RGB", (width, height), (245, 246, 248))
    out.paste(image, (0, 0))
    return out


def make_video_frame(
    processed: List[Tuple[NuScenesSample, OffsetResult]],
    tile_width: int,
    title: str,
    frame_note: str,
) -> Image.Image:
    ordered = sorted(processed, key=lambda item: camera_sort_key(item[0].camera))
    if len(ordered) != len(CAMERA_ORDER):
        raise ValueError(f"Expected six processed cameras, got {len(ordered)}")

    depth_max_for_view = max(120.0, max(float(item[1].stats.get("target_invalid_depth_fill", 100.0)) for item in ordered))
    full_valid = np.ones_like(ordered[0][1].source_valid, dtype=bool)
    row_tiles = [
        (
            "input rgb",
            [
                resize_tile(result.input_rgb, tile_width)
                for _, result in ordered
            ],
        ),
        (
            "target rgb",
            [
                resize_tile(result.target_rgb, tile_width)
                for _, result in ordered
            ],
        ),
        (
            "mask",
            [
                resize_tile(mask_to_rgb(result.invalid_mask, (255, 255, 255)), tile_width)
                for _, result in ordered
            ],
        ),
        (
            "input depth",
            [
                resize_tile(depth_to_color(result.training_input_depth, full_valid, depth_max_for_view), tile_width)
                for _, result in ordered
            ],
        ),
        (
            "target depth",
            [
                resize_tile(depth_to_color(result.source_depth, full_valid, depth_max_for_view), tile_width)
                for _, result in ordered
            ],
        ),
    ]

    gap = 8
    label_w = 112
    title_h = 54
    label_h = 20
    tile_h = row_tiles[0][1][0].height
    row_h = label_h + tile_h + gap
    canvas_w = label_w + len(CAMERA_ORDER) * (tile_width + gap) + gap
    canvas_h = title_h + len(row_tiles) * row_h + gap
    canvas = Image.new("RGB", (canvas_w, canvas_h), (245, 246, 248))
    draw = ImageDraw.Draw(canvas)
    draw.text((gap, 8), title, fill=(20, 24, 28))
    draw.text((gap, 30), frame_note, fill=(64, 70, 78))

    for row_index, (row_label, images) in enumerate(row_tiles):
        y = title_h + row_index * row_h
        draw.text((gap, y + label_h + tile_h // 2 - 5), row_label, fill=(20, 24, 28))
        for camera_index, ((sample, _), image) in enumerate(zip(ordered, images)):
            x = label_w + camera_index * (tile_width + gap)
            draw_label(draw, (x, y), short_camera_name(sample.camera))
            canvas.paste(image, (x, y + label_h))

    return pad_even(canvas)


def main() -> None:
    args = parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    samples_csv = args.samples_csv or default_samples_csv(args.project_dir, args.split)
    version_dir = resolve_version_dir(args.nuscenes_root, args.nuscenes_version_dir)

    t0 = time.perf_counter()
    rows = read_csv_rows(samples_csv)
    grouped = build_grouped_rows(rows)
    selected_scene, condition_rows, chunk_rows = select_six_camera_chunk(
        grouped,
        args.scene_id,
        args.chunk_start,
        args.chunk_length,
    )
    indexes = load_metadata_indexes(version_dir)

    writer = None
    frames_written = 0
    selected_summary = {}
    try:
        for local_index in range(args.chunk_length):
            processed = []
            for camera in CAMERA_ORDER:
                sample, result = load_supervision_result(
                    chunk_rows[camera][local_index],
                    args,
                    indexes,
                )
                processed.append((sample, result))

            condition_ids = {
                short_camera_name(camera): _row_frame_id(condition_rows[camera])
                for camera in CAMERA_ORDER
            }
            frame_ids = {
                short_camera_name(camera): _row_frame_id(chunk_rows[camera][local_index])
                for camera in CAMERA_ORDER
            }
            selected_summary[str(local_index)] = frame_ids
            title = (
                f"S1 fixed left {args.shift_left_m:g}m, scene_id={selected_scene}, "
                f"chunk_start={args.chunk_start}"
            )
            frame_note = (
                f"local frame {local_index}/{args.chunk_length - 1}; "
                f"frame_ids={frame_ids}; clip_condition_ids={condition_ids}"
            )
            pil_frame = make_video_frame(
                processed,
                tile_width=args.tile_width,
                title=title,
                frame_note=frame_note,
            )
            frame_rgb = np.asarray(pil_frame, dtype=np.uint8)
            frame_bgr = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
            if writer is None:
                fourcc = cv2.VideoWriter_fourcc(*args.fourcc[:4])
                writer = cv2.VideoWriter(str(args.output), fourcc, args.fps, (pil_frame.width, pil_frame.height))
                if not writer.isOpened():
                    raise RuntimeError(f"Could not open video writer for {args.output}")
            writer.write(frame_bgr)
            frames_written += 1
    finally:
        if writer is not None:
            writer.release()

    print(
        json.dumps(
            {
                "output": str(args.output),
                "samples_csv": str(samples_csv),
                "scene_id": selected_scene,
                "chunk_start": args.chunk_start,
                "chunk_length": args.chunk_length,
                "shift_left_m": args.shift_left_m,
                "frames_written": frames_written,
                "selected_frame_ids": selected_summary,
                "elapsed_s": time.perf_counter() - t0,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
