#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate dists

SCENE_ROOT=${SCENE_ROOT:-/data/wlh/OmniRe/data/waymo/processed/training/089}
OUTPUT_ROOT=${OUTPUT_ROOT:-/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val}
SCENE_NAME=${SCENE_NAME:-waymo089_145_168}

cd /data4/DATA/wlh/DiST-4D/code/DiST_S/data_process

for DIRECTION in left right; do
  python reproj_waymo_anchor_trajectory.py \
    --scene-root "$SCENE_ROOT" \
    --output-root "$OUTPUT_ROOT" \
    --scene-name "$SCENE_NAME" \
    --camera-ids 0 1 2 \
    --start-frame 145 \
    --end-frame 168 \
    --anchor-frame 145 \
    --direction "$DIRECTION" \
    --max-offset 6 \
    --target-pose-mode anchor \
    --target-width 768 \
    --target-height 432 \
    --pcd-width 1200 \
    --pcd-height 675
done
