import argparse
import glob
import json
import os
import pickle
from copy import deepcopy

import cv2
import numpy as np
import open3d as o3d
from PIL import Image
from pyquaternion import Quaternion
from tqdm import tqdm

from reproj_utils import (
    build_scene_clip,
    create_point_cloud_with_open3d,
    project_point_cloud_to_image,
    resize_cam_intrinsic,
)


VIS_CAMERAS = [
    "CAM_FRONT_LEFT",
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
]


VAL_USE_DICT = {
    "1": "11_scene",
    "2": "12_scene",
    "3": "13_scene",
    "4": "14_scene",
    "10": "36_scene",
    "13": "75_scene",
    "17": "79_scene",
    "21": "83_scene",
    "22": "84_scene",
    "25": "87_scene",
    "26": "88_scene",
    "28": "90_scene",
    "29": "91_scene",
    "30": "92_scene",
    "32": "214_scene",
    "43": "257_scene",
    "45": "259_scene",
    "47": "261_scene",
    "48": "262_scene",
    "51": "410_scene",
    "53": "412_scene",
    "55": "414_scene",
    "56": "436_scene",
    "59": "439_scene",
    "62": "442_scene",
    "63": "443_scene",
    "64": "444_scene",
    "65": "445_scene",
    "66": "446_scene",
    "67": "447_scene",
}


def load_release_rgb(sample_root, cam):
    candidates = sorted(glob.glob(os.path.join(sample_root, cam, "rgb_depth_*.npz")))
    if not candidates:
        raise FileNotFoundError(f"No rgb_depth_*.npz under {sample_root}/{cam}")
    return np.load(candidates[0], allow_pickle=True)["rgb"].astype(np.uint8)


def load_data_info(info, sample_token2depth, rdepth_root):
    sample_token = info["token"]
    sample_rdepth_root = os.path.join(rdepth_root, sample_token2depth[sample_token])

    data = {
        "token": sample_token,
        "sample_idx": sample_token,
        "timestamp": info["timestamp"],
        "camera2ego": [],
        "camera_intrinsics": [],
        "camera2global": [],
        "refine_depth_path": [],
        "semantic_path": [],
        "sample_rdepth_root": sample_rdepth_root,
    }

    for cam in VIS_CAMERAS:
        camera_info = info["cams"][cam]

        camera_intrinsics = np.eye(4).astype(np.float32)
        camera_intrinsics[:3, :3] = camera_info["camera_intrinsics"]
        data["camera_intrinsics"].append(camera_intrinsics)

        camera2ego = np.eye(4).astype(np.float32)
        camera2ego[:3, :3] = Quaternion(camera_info["sensor2ego_rotation"]).rotation_matrix
        camera2ego[:3, 3] = camera_info["sensor2ego_translation"]
        data["camera2ego"].append(camera2ego)

        camera_ego2global = np.eye(4).astype(np.float32)
        camera_ego2global[:3, :3] = Quaternion(
            camera_info["ego2global_rotation"]
        ).rotation_matrix
        camera_ego2global[:3, 3] = camera_info["ego2global_translation"]
        data["camera2global"].append(camera_ego2global @ camera2ego)

        data["refine_depth_path"].append(
            os.path.join(sample_rdepth_root, cam, "refined_depth.npz")
        )
        data["semantic_path"].append(
            os.path.join(sample_rdepth_root, cam, "semantic_oneformer.npz")
        )

    return data


def get_merged_pcd_release(datainfo, img_wh, cam_back_mask_path):
    new_width, new_height = img_wh
    ori_width, ori_height = 1600, 900

    cam_back_mask = np.asarray(Image.open(cam_back_mask_path))
    cam_back_mask = cv2.resize(
        cam_back_mask, (new_width, new_height), interpolation=cv2.INTER_NEAREST
    )

    merged_pcd = o3d.geometry.PointCloud()
    for cam_idx, cam in enumerate(VIS_CAMERAS):
        intrinsics = resize_cam_intrinsic(
            [ori_width, ori_height],
            [new_width, new_height],
            datainfo["camera_intrinsics"][cam_idx].copy(),
        )
        extrinsics = datainfo["camera2global"][cam_idx]

        rgb = load_release_rgb(datainfo["sample_rdepth_root"], cam)
        rgb = np.asarray(Image.fromarray(rgb).resize((new_width, new_height)))

        depth = np.load(datainfo["refine_depth_path"][cam_idx])["depth_pred"].astype(
            np.float32
        )
        depth = cv2.resize(depth, (new_width, new_height), interpolation=cv2.INTER_CUBIC)

        semantic = np.load(datainfo["semantic_path"][cam_idx])["sem"]
        semantic = cv2.resize(
            semantic, (new_width, new_height), interpolation=cv2.INTER_NEAREST
        )
        depth[semantic == 27] = 100
        if cam == "CAM_BACK":
            depth[cam_back_mask[:, :, 0] == 0] = 0

        merged_pcd += create_point_cloud_with_open3d(rgb, depth, intrinsics, extrinsics)

    return merged_pcd


def save_movecam_frame(datainfo, save_gt_root, save_pseudo_root, cam_back_mask_path, mod_y_d):
    new_width, new_height = 768, 432
    ori_width, ori_height = 1600, 900
    sample_token = datainfo["token"]
    merged_pcd = get_merged_pcd_release(deepcopy(datainfo), (1200, 675), cam_back_mask_path)

    for cam_idx, cam in enumerate(VIS_CAMERAS):
        intrinsics = resize_cam_intrinsic(
            [ori_width, ori_height],
            [new_width, new_height],
            datainfo["camera_intrinsics"][cam_idx].copy(),
        )

        cam2global = datainfo["camera2global"][cam_idx]
        cam2ego = datainfo["camera2ego"][cam_idx]
        ego2global = cam2global @ np.linalg.inv(cam2ego)
        cam2ego_mod = cam2ego.copy()
        cam2ego_mod[1, 3] = cam2ego[1, 3] + mod_y_d
        cam2global_mod = ego2global @ cam2ego_mod

        merged_pcd_cam = deepcopy(merged_pcd)
        merged_pcd_cam.transform(np.linalg.inv(cam2global_mod))
        target_rgb, target_depth = project_point_cloud_to_image(
            merged_pcd_cam, intrinsics, new_width, new_height
        )

        rgb = load_release_rgb(datainfo["sample_rdepth_root"], cam)
        rgb = Image.fromarray(rgb).resize((new_width, new_height))
        depth = np.load(datainfo["refine_depth_path"][cam_idx])["depth_pred"].astype(
            np.float32
        )
        depth = cv2.resize(depth, (new_width, new_height), interpolation=cv2.INTER_CUBIC)
        semantic = np.load(datainfo["semantic_path"][cam_idx])["sem"]
        semantic = cv2.resize(
            semantic, (new_width, new_height), interpolation=cv2.INTER_NEAREST
        )
        depth[semantic == 27] = 100

        gt_cam_path = os.path.join(save_gt_root, cam)
        pseudo_cam_path = os.path.join(save_pseudo_root, cam)
        os.makedirs(gt_cam_path, exist_ok=True)
        os.makedirs(pseudo_cam_path, exist_ok=True)

        rgb.save(os.path.join(gt_cam_path, f"{sample_token}.jpg"))
        np.savez_compressed(os.path.join(gt_cam_path, f"{sample_token}.npz"), depth_gt=depth)

        Image.fromarray(np.uint8(target_rgb * 255)).save(
            os.path.join(pseudo_cam_path, f"{sample_token}.jpg")
        )
        np.savez_compressed(
            os.path.join(pseudo_cam_path, f"{sample_token}.npz"),
            depth_proj=target_depth,
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scene_idx", type=int, default=1)
    parser.add_argument("--mod_y_d", type=float, required=True)
    parser.add_argument("--interval", type=int, default=2)
    parser.add_argument("--rdepth_root", type=str, required=True)
    parser.add_argument("--pkl_root", type=str, required=True)
    parser.add_argument("--sampletoken2depth", type=str, required=True)
    parser.add_argument("--output_root", type=str, required=True)
    parser.add_argument("--cam_back_mask", type=str, required=True)
    args = parser.parse_args()

    scene_idx_key = str(args.scene_idx)
    scene_name = VAL_USE_DICT.get(scene_idx_key, scene_idx_key)

    with open(args.sampletoken2depth, "r") as file:
        sample_token2depth = json.load(file)
    with open(args.pkl_root, "rb") as file:
        anno_data = pickle.load(file)

    data_infos = sorted(anno_data["infos"], key=lambda e: e["timestamp"])
    clip_infos = build_scene_clip(data_infos, anno_data["scene_tokens"])
    sample_idxs = clip_infos[args.scene_idx]

    sample_infos = [
        load_data_info(data_infos[idx], sample_token2depth, args.rdepth_root)
        for idx in sample_idxs
    ]

    save_gt_root = os.path.join(args.output_root, "frame_gt", scene_name)
    save_pseudo_root = os.path.join(
        args.output_root, f"frame_movecam2egoy+{args.mod_y_d:g}", scene_name
    )

    sample_tokens = []
    frame_range = range(0, len(sample_infos) - args.interval, args.interval)
    for i in tqdm(frame_range, desc=f"{scene_name} left {args.mod_y_d:g}m"):
        save_movecam_frame(
            deepcopy(sample_infos[i]),
            save_gt_root,
            save_pseudo_root,
            args.cam_back_mask,
            args.mod_y_d,
        )
        sample_tokens.append(sample_infos[i]["token"])

    with open(os.path.join(save_pseudo_root, "pesudo_sampletoken.json"), "w") as file:
        json.dump(sample_tokens, file)

    print(
        f"Saved {len(sample_tokens)} samples for {scene_name} "
        f"to {save_pseudo_root}"
    )


if __name__ == "__main__":
    main()
