#!/usr/bin/env python3
"""Build DiST-S reprojection inputs for an OmniRe/Waymo processed scene.

This follows the nuScenes DiST-S data convention:

output_root/
  frame_gt/<scene>/<cam>/<frame>.jpg
  frame_gt/<scene>/<cam>/<frame>.npz              # depth_gt
  frame_movecam2egoy+<d>/<scene>/<cam>/<frame>.jpg
  frame_movecam2egoy+<d>/<scene>/<cam>/<frame>.npz # depth_proj
  frame_movecam2egoy+<d>/<scene>/pesudo_sampletoken.json

The geometry resize is explicit and paired with intrinsic scaling.  It does not
crop images.  For Waymo front cameras the source image is 1920x1280 and the
default geometric output is 768x432, mirroring the original DiST-S nuScenes
preprocessing style.  The inference wrapper later resizes these RGB-D frames to
the model's 768x448 tensor size, just like the existing nuScenes scripts.

Waymo sparse conditions keep sky-like upper-image holes by default: invalid
projected pixels in the upper image region are filled from the same-frame RGB
and assigned a far positive depth, so DiST-S treats them as valid conditions.
"""

from __future__ import annotations

import argparse
import json
import os
from copy import deepcopy
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import cv2
import numpy as np
import open3d as o3d
from PIL import Image
from tqdm import tqdm


OPENCV2WAYMO = np.array(
    [[0, 0, 1, 0], [-1, 0, 0, 0], [0, -1, 0, 0], [0, 0, 0, 1]],
    dtype=np.float32,
)

DEFAULT_CAMERA_MAP = {
    0: "CAM_FRONT",
    1: "CAM_FRONT_LEFT",
    2: "CAM_FRONT_RIGHT",
}

WAYMO_SKY_FILL_TOP_RATIO = 0.45
WAYMO_SKY_FILL_DEPTH = 100.0
WAYMO_DEPTH_EPS = 1e-6


def movecam_flag_name(mod_y_d: float) -> str:
    sign = "+" if mod_y_d >= 0 else "-"
    return f"frame_movecam2egoy{sign}{abs(mod_y_d):g}"


def fill_waymo_upper_holes(
    target_rgb: np.ndarray,
    target_depth: np.ndarray,
    source_rgb: Image.Image,
) -> Tuple[np.ndarray, np.ndarray]:
    """Fill upper reprojection holes with same-frame RGB and far valid depth."""
    depth = target_depth.astype(np.float32, copy=True)
    rgb = target_rgb.astype(np.float32, copy=True)
    height, width = depth.shape
    if rgb.shape[:2] != (height, width):
        raise ValueError(f"RGB/depth shape mismatch: {rgb.shape} vs {depth.shape}")

    top_h = max(1, min(height, int(round(height * WAYMO_SKY_FILL_TOP_RATIO))))
    fill_mask = np.zeros((height, width), dtype=bool)
    fill_mask[:top_h, :] = ~np.isfinite(depth[:top_h, :]) | (
        depth[:top_h, :] <= WAYMO_DEPTH_EPS
    )
    if not fill_mask.any():
        return rgb, depth

    source_np = np.asarray(source_rgb.resize((width, height))).astype(np.float32) / 255.0
    rgb[fill_mask] = source_np[fill_mask]
    depth[fill_mask] = WAYMO_SKY_FILL_DEPTH
    return rgb, depth


def resize_cam_intrinsic(
    ori_wh: Tuple[int, int], resize_wh: Tuple[int, int], cam_intrinsics: np.ndarray
) -> np.ndarray:
    cam_intrinsics = cam_intrinsics.copy()
    cam_intrinsics[0] = (resize_wh[0] / ori_wh[0]) * cam_intrinsics[0]
    cam_intrinsics[1] = (resize_wh[1] / ori_wh[1]) * cam_intrinsics[1]
    return cam_intrinsics


def create_point_cloud_with_open3d(
    rgb_image: np.ndarray,
    depth_image: np.ndarray,
    intrinsics: np.ndarray,
    camera_to_world: np.ndarray,
) -> o3d.geometry.PointCloud:
    rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(
        o3d.geometry.Image(rgb_image.astype(np.uint8)),
        o3d.geometry.Image(depth_image.astype(np.float32)),
        depth_scale=1,
        depth_trunc=120,
        convert_rgb_to_intensity=False,
    )

    camera_intrinsics = o3d.camera.PinholeCameraIntrinsic()
    camera_intrinsics.set_intrinsics(
        width=rgb_image.shape[1],
        height=rgb_image.shape[0],
        fx=intrinsics[0, 0],
        fy=intrinsics[1, 1],
        cx=intrinsics[0, 2],
        cy=intrinsics[1, 2],
    )

    pcd = o3d.geometry.PointCloud.create_from_rgbd_image(rgbd_image, camera_intrinsics)
    pcd.transform(camera_to_world)
    return pcd


def project_point_cloud_to_image(
    pcd_ori: o3d.geometry.PointCloud,
    intrinsic: np.ndarray,
    width: int,
    height: int,
) -> Tuple[np.ndarray, np.ndarray]:
    pcd = o3d.t.geometry.PointCloud.from_legacy(pcd_ori)
    o3d_intrinsic = o3d.core.Tensor(intrinsic[:3, :3].astype(np.float32))
    rgbd_reproj = pcd.project_to_rgbd_image(
        width,
        height,
        o3d_intrinsic,
        depth_scale=1,
        depth_max=120,
    )
    return (
        np.asarray(rgbd_reproj.color.to_legacy()),
        np.asarray(rgbd_reproj.depth.to_legacy()),
    )


def parse_camera_map(camera_map: str | None, camera_ids: Iterable[int]) -> Dict[int, str]:
    if camera_map is None:
        return {cam_id: DEFAULT_CAMERA_MAP.get(cam_id, f"WAYMO_CAM_{cam_id}") for cam_id in camera_ids}
    parsed: Dict[int, str] = {}
    for item in camera_map.split(","):
        if not item:
            continue
        cam_id, name = item.split(":", 1)
        parsed[int(cam_id)] = name
    for cam_id in camera_ids:
        parsed.setdefault(cam_id, DEFAULT_CAMERA_MAP.get(cam_id, f"WAYMO_CAM_{cam_id}"))
    return parsed


def load_intrinsic(scene_root: Path, cam_id: int) -> np.ndarray:
    values = np.loadtxt(scene_root / "intrinsics" / f"{cam_id}.txt").astype(np.float32)
    if values.shape != (9,):
        raise ValueError(f"Expected 9 intrinsics values for camera {cam_id}, got {values.shape}")
    intrinsics = np.eye(4, dtype=np.float32)
    intrinsics[0, 0] = values[0]
    intrinsics[1, 1] = values[1]
    intrinsics[0, 2] = values[2]
    intrinsics[1, 2] = values[3]
    return intrinsics


def load_camera_to_ego(scene_root: Path, cam_id: int) -> np.ndarray:
    raw = np.loadtxt(scene_root / "extrinsics" / f"{cam_id}.txt").astype(np.float32)
    if raw.shape != (4, 4):
        raise ValueError(f"Expected 4x4 extrinsic for camera {cam_id}, got {raw.shape}")
    # The processed Waymo extrinsic maps Waymo camera coordinates to vehicle.
    # Convert it to OpenCV camera coordinates because Open3D RGB-D backprojection
    # uses x-right, y-down, z-forward camera coordinates.
    return raw @ OPENCV2WAYMO


def load_depth(scene_root: Path, frame_id: int, cam_id: int) -> Tuple[np.ndarray, np.ndarray]:
    path = scene_root / "depth" / f"{frame_id:03d}_{cam_id}.npz"
    data = np.load(path)
    depth = data["depth"].astype(np.float32)
    if "mask" in data.files:
        mask = data["mask"].astype(bool)
    else:
        mask = np.isfinite(depth) & (depth > 0)
    depth = np.where(mask & np.isfinite(depth) & (depth > 0), depth, 0.0).astype(np.float32)
    return depth, mask


def load_rgb(scene_root: Path, frame_id: int, cam_id: int) -> Image.Image:
    path = scene_root / "images" / f"{frame_id:03d}_{cam_id}.jpg"
    if not path.exists():
        raise FileNotFoundError(path)
    return Image.open(path).convert("RGB")


def collect_frame_ids(scene_root: Path, camera_ids: Iterable[int]) -> List[int]:
    camera_ids = list(camera_ids)
    frames = []
    for image_path in sorted((scene_root / "images").glob("*.jpg")):
        stem = image_path.stem
        try:
            frame_str, cam_str = stem.split("_")
            frame_id, cam_id = int(frame_str), int(cam_str)
        except ValueError:
            continue
        if cam_id == camera_ids[0]:
            if all((scene_root / "images" / f"{frame_id:03d}_{cid}.jpg").exists() for cid in camera_ids):
                if all((scene_root / "depth" / f"{frame_id:03d}_{cid}.npz").exists() for cid in camera_ids):
                    frames.append(frame_id)
    return frames


def resize_depth_and_mask(
    depth: np.ndarray,
    mask: np.ndarray,
    size_wh: Tuple[int, int],
) -> np.ndarray:
    depth_rz = cv2.resize(depth, size_wh, interpolation=cv2.INTER_CUBIC)
    mask_rz = cv2.resize(mask.astype(np.uint8), size_wh, interpolation=cv2.INTER_NEAREST).astype(bool)
    depth_rz = np.where(mask_rz & np.isfinite(depth_rz) & (depth_rz > 0), depth_rz, 0.0)
    return depth_rz.astype(np.float32)


def build_datainfo(scene_root: Path, frame_id: int, camera_ids: Iterable[int]) -> dict:
    ego_to_global = np.loadtxt(scene_root / "ego_pose" / f"{frame_id:03d}.txt").astype(np.float32)
    data = {
        "token": f"{frame_id:03d}",
        "camera_ids": list(camera_ids),
        "camera_intrinsics": [],
        "camera2ego": [],
        "camera2global": [],
    }
    for cam_id in camera_ids:
        cam2ego = load_camera_to_ego(scene_root, cam_id)
        data["camera_intrinsics"].append(load_intrinsic(scene_root, cam_id))
        data["camera2ego"].append(cam2ego)
        data["camera2global"].append(ego_to_global @ cam2ego)
    return data


def get_merged_pcd_waymo(
    scene_root: Path,
    datainfo: dict,
    pcd_wh: Tuple[int, int],
) -> o3d.geometry.PointCloud:
    merged_pcd = o3d.geometry.PointCloud()
    pcd_width, pcd_height = pcd_wh

    for cam_idx, cam_id in enumerate(datainfo["camera_ids"]):
        rgb = load_rgb(scene_root, int(datainfo["token"]), cam_id)
        ori_width, ori_height = rgb.size
        rgb_np = np.asarray(rgb.resize((pcd_width, pcd_height)))
        depth, mask = load_depth(scene_root, int(datainfo["token"]), cam_id)
        depth_rz = resize_depth_and_mask(depth, mask, (pcd_width, pcd_height))
        intrinsics = resize_cam_intrinsic(
            (ori_width, ori_height),
            (pcd_width, pcd_height),
            datainfo["camera_intrinsics"][cam_idx],
        )
        merged_pcd += create_point_cloud_with_open3d(
            rgb_np,
            depth_rz,
            intrinsics,
            datainfo["camera2global"][cam_idx],
        )

    return merged_pcd


def save_movecam_frame(
    scene_root: Path,
    datainfo: dict,
    save_gt_root: Path,
    save_pseudo_root: Path,
    camera_name_map: Dict[int, str],
    target_wh: Tuple[int, int],
    pcd_wh: Tuple[int, int],
    mod_y_d: float,
) -> None:
    sample_token = datainfo["token"]
    target_width, target_height = target_wh
    merged_pcd = get_merged_pcd_waymo(scene_root, deepcopy(datainfo), pcd_wh)

    for cam_idx, cam_id in enumerate(datainfo["camera_ids"]):
        cam_name = camera_name_map[cam_id]
        rgb = load_rgb(scene_root, int(sample_token), cam_id)
        ori_width, ori_height = rgb.size
        intrinsics = resize_cam_intrinsic(
            (ori_width, ori_height),
            (target_width, target_height),
            datainfo["camera_intrinsics"][cam_idx],
        )

        cam2global = datainfo["camera2global"][cam_idx]
        cam2ego = datainfo["camera2ego"][cam_idx]
        ego2global = cam2global @ np.linalg.inv(cam2ego)
        cam2ego_mod = cam2ego.copy()
        cam2ego_mod[1, 3] = cam2ego[1, 3] + mod_y_d
        cam2global_mod = ego2global @ cam2ego_mod

        merged_pcd_cam = deepcopy(merged_pcd)
        merged_pcd_cam.transform(np.linalg.inv(cam2global_mod))
        target_rgb, target_depth = project_point_cloud_to_image(
            merged_pcd_cam,
            intrinsics,
            target_width,
            target_height,
        )
        target_rgb, target_depth = fill_waymo_upper_holes(
            target_rgb,
            target_depth,
            rgb,
        )

        depth, mask = load_depth(scene_root, int(sample_token), cam_id)
        depth_gt = resize_depth_and_mask(depth, mask, (target_width, target_height))
        rgb_gt = rgb.resize((target_width, target_height))

        gt_cam_path = save_gt_root / cam_name
        pseudo_cam_path = save_pseudo_root / cam_name
        gt_cam_path.mkdir(parents=True, exist_ok=True)
        pseudo_cam_path.mkdir(parents=True, exist_ok=True)

        rgb_gt.save(gt_cam_path / f"{sample_token}.jpg")
        np.savez_compressed(gt_cam_path / f"{sample_token}.npz", depth_gt=depth_gt)

        target_rgb_u8 = np.clip(target_rgb * 255.0, 0, 255).astype(np.uint8)
        Image.fromarray(target_rgb_u8).save(pseudo_cam_path / f"{sample_token}.jpg")
        np.savez_compressed(
            pseudo_cam_path / f"{sample_token}.npz",
            depth_proj=target_depth.astype(np.float32),
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--scene-root",
        type=Path,
        default=Path("/data/wlh/OmniRe/data/waymo/processed/training/089"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val"),
    )
    parser.add_argument("--scene-name", type=str, default="waymo089")
    parser.add_argument("--camera-ids", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument(
        "--camera-map",
        type=str,
        default=None,
        help="Comma-separated id:name map, e.g. 0:CAM_FRONT,1:CAM_FRONT_LEFT,2:CAM_FRONT_RIGHT.",
    )
    parser.add_argument("--mod_y_d", type=float, required=True)
    parser.add_argument("--target-width", type=int, default=768)
    parser.add_argument("--target-height", type=int, default=432)
    parser.add_argument("--pcd-width", type=int, default=1200)
    parser.add_argument("--pcd-height", type=int, default=675)
    parser.add_argument("--start-frame", type=int, default=None)
    parser.add_argument("--end-frame", type=int, default=None)
    parser.add_argument("--limit", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    camera_name_map = parse_camera_map(args.camera_map, args.camera_ids)
    frame_ids = collect_frame_ids(args.scene_root, args.camera_ids)
    if args.start_frame is not None:
        frame_ids = [frame_id for frame_id in frame_ids if frame_id >= args.start_frame]
    if args.end_frame is not None:
        frame_ids = [frame_id for frame_id in frame_ids if frame_id <= args.end_frame]
    if args.limit is not None:
        frame_ids = frame_ids[: args.limit]
    if not frame_ids:
        raise RuntimeError("No complete Waymo RGB/depth frames found.")

    save_gt_root = args.output_root / "frame_gt" / args.scene_name
    save_pseudo_root = args.output_root / movecam_flag_name(args.mod_y_d) / args.scene_name
    save_pseudo_root.mkdir(parents=True, exist_ok=True)

    sample_tokens = []
    direction = "left" if args.mod_y_d >= 0 else "right"
    for frame_id in tqdm(frame_ids, desc=f"{args.scene_name} {direction} {abs(args.mod_y_d):g}m"):
        sample_token = f"{frame_id:03d}"
        datainfo = build_datainfo(args.scene_root, frame_id, args.camera_ids)
        save_movecam_frame(
            args.scene_root,
            datainfo,
            save_gt_root,
            save_pseudo_root,
            camera_name_map,
            (args.target_width, args.target_height),
            (args.pcd_width, args.pcd_height),
            args.mod_y_d,
        )
        sample_tokens.append(sample_token)

    with (save_pseudo_root / "pesudo_sampletoken.json").open("w") as file:
        json.dump(sample_tokens, file)

    summary = {
        "scene": args.scene_name,
        "frames": len(sample_tokens),
        "cameras": camera_name_map,
        "frame_gt": str(save_gt_root),
        "pseudo": str(save_pseudo_root),
        "target_size": [args.target_width, args.target_height],
        "pcd_size": [args.pcd_width, args.pcd_height],
        "waymo_sky_fill": {
            "top_ratio": WAYMO_SKY_FILL_TOP_RATIO,
            "depth": WAYMO_SKY_FILL_DEPTH,
        },
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
