#!/usr/bin/env python3
"""Build DiST-S Waymo inputs for an anchored lateral sweep trajectory.

For each timestep this script rebuilds the source point cloud from that frame's
front three RGB-D views, then projects the dynamic point cloud into an anchored
camera trajectory.  The default trajectory uses frame 145 as the anchor pose and
linearly moves in ego-y from 0m to +/-6m across frames 145..168.

Waymo sparse conditions keep sky-like upper-image holes by default through the
shared Waymo sky-fill policy in reproj_waymo_movecam.py.
"""

from __future__ import annotations

import argparse
import json
from copy import deepcopy
from pathlib import Path
from typing import Dict, List, Tuple

import cv2
import numpy as np
from PIL import Image
from tqdm import tqdm

from reproj_waymo_movecam import (
    build_datainfo,
    fill_waymo_upper_holes,
    get_merged_pcd_waymo,
    load_depth,
    load_rgb,
    parse_camera_map,
    project_point_cloud_to_image,
    resize_cam_intrinsic,
    resize_depth_and_mask,
    WAYMO_SKY_FILL_DEPTH,
    WAYMO_SKY_FILL_TOP_RATIO,
)


def signed_flag_name(anchor_frame: int, max_offset: float, direction: str) -> str:
    sign = "+" if direction == "left" else "-"
    return f"frame_anchor{anchor_frame:03d}_egoy{sign}0to{max_offset:g}"


def trajectory_offsets(num_frames: int, max_offset: float, direction: str) -> List[float]:
    sign = 1.0 if direction == "left" else -1.0
    if num_frames <= 1:
        return [0.0]
    return [sign * max_offset * idx / float(num_frames - 1) for idx in range(num_frames)]


def save_gt_frame(
    scene_root: Path,
    frame_id: int,
    camera_ids: List[int],
    camera_name_map: Dict[int, str],
    save_gt_root: Path,
    target_wh: Tuple[int, int],
) -> None:
    target_width, target_height = target_wh
    sample_token = f"{frame_id:03d}"
    for cam_id in camera_ids:
        cam_name = camera_name_map[cam_id]
        rgb = load_rgb(scene_root, frame_id, cam_id).resize((target_width, target_height))
        depth, mask = load_depth(scene_root, frame_id, cam_id)
        depth_gt = resize_depth_and_mask(depth, mask, (target_width, target_height))

        gt_cam_path = save_gt_root / cam_name
        gt_cam_path.mkdir(parents=True, exist_ok=True)
        rgb.save(gt_cam_path / f"{sample_token}.jpg")
        np.savez_compressed(gt_cam_path / f"{sample_token}.npz", depth_gt=depth_gt)


def save_pseudo_frame(
    scene_root: Path,
    source_datainfo: dict,
    target_datainfo: dict,
    offset_y: float,
    camera_ids: List[int],
    camera_name_map: Dict[int, str],
    save_pseudo_root: Path,
    target_wh: Tuple[int, int],
    pcd_wh: Tuple[int, int],
) -> None:
    sample_token = source_datainfo["token"]
    target_width, target_height = target_wh
    merged_pcd = get_merged_pcd_waymo(scene_root, deepcopy(source_datainfo), pcd_wh)

    for cam_idx, cam_id in enumerate(camera_ids):
        cam_name = camera_name_map[cam_id]
        rgb = load_rgb(scene_root, int(sample_token), cam_id)
        ori_width, ori_height = rgb.size
        intrinsics = resize_cam_intrinsic(
            (ori_width, ori_height),
            (target_width, target_height),
            target_datainfo["camera_intrinsics"][cam_idx],
        )

        cam2global = target_datainfo["camera2global"][cam_idx]
        cam2ego = target_datainfo["camera2ego"][cam_idx]
        ego2global = cam2global @ np.linalg.inv(cam2ego)
        cam2ego_mod = cam2ego.copy()
        cam2ego_mod[1, 3] = cam2ego[1, 3] + offset_y
        cam2global_mod = ego2global @ cam2ego_mod

        merged_pcd_cam = deepcopy(merged_pcd)
        merged_pcd_cam.transform(np.linalg.inv(cam2global_mod))
        target_rgb, target_depth = project_point_cloud_to_image(
            merged_pcd_cam,
            intrinsics,
            target_width,
            target_height,
        )
        target_rgb, target_depth = fill_waymo_upper_holes(
            target_rgb,
            target_depth,
            rgb,
        )

        pseudo_cam_path = save_pseudo_root / cam_name
        pseudo_cam_path.mkdir(parents=True, exist_ok=True)
        target_rgb_u8 = np.clip(target_rgb * 255.0, 0, 255).astype(np.uint8)
        Image.fromarray(target_rgb_u8).save(pseudo_cam_path / f"{sample_token}.jpg")
        np.savez_compressed(
            pseudo_cam_path / f"{sample_token}.npz",
            depth_proj=target_depth.astype(np.float32),
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--scene-root",
        type=Path,
        default=Path("/data/wlh/OmniRe/data/waymo/processed/training/089"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val"),
    )
    parser.add_argument("--scene-name", type=str, default="waymo089_145_168")
    parser.add_argument("--camera-ids", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--camera-map", type=str, default=None)
    parser.add_argument("--start-frame", type=int, default=145)
    parser.add_argument("--end-frame", type=int, default=168)
    parser.add_argument("--anchor-frame", type=int, default=145)
    parser.add_argument("--direction", choices=["left", "right"], required=True)
    parser.add_argument("--max-offset", type=float, default=6.0)
    parser.add_argument(
        "--target-pose-mode",
        choices=["anchor", "current"],
        default="anchor",
        help="anchor uses the anchor-frame pose for the whole path; current uses each frame pose with a time-varying offset.",
    )
    parser.add_argument("--target-width", type=int, default=768)
    parser.add_argument("--target-height", type=int, default=432)
    parser.add_argument("--pcd-width", type=int, default=1200)
    parser.add_argument("--pcd-height", type=int, default=675)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    frame_ids = list(range(args.start_frame, args.end_frame + 1))
    camera_name_map = parse_camera_map(args.camera_map, args.camera_ids)
    pseudo_flag = signed_flag_name(args.anchor_frame, args.max_offset, args.direction)

    save_gt_root = args.output_root / "frame_gt" / args.scene_name
    save_pseudo_root = args.output_root / pseudo_flag / args.scene_name
    save_pseudo_root.mkdir(parents=True, exist_ok=True)

    anchor_datainfo = build_datainfo(args.scene_root, args.anchor_frame, args.camera_ids)
    offsets = trajectory_offsets(len(frame_ids), args.max_offset, args.direction)
    sample_tokens = []

    for frame_id, offset_y in tqdm(
        list(zip(frame_ids, offsets)),
        desc=f"{args.scene_name} {args.direction} 0->{args.max_offset:g}m",
    ):
        sample_token = f"{frame_id:03d}"
        sample_tokens.append(sample_token)

        source_datainfo = build_datainfo(args.scene_root, frame_id, args.camera_ids)
        target_datainfo = (
            anchor_datainfo if args.target_pose_mode == "anchor" else source_datainfo
        )
        save_gt_frame(
            args.scene_root,
            frame_id,
            args.camera_ids,
            camera_name_map,
            save_gt_root,
            (args.target_width, args.target_height),
        )
        save_pseudo_frame(
            args.scene_root,
            source_datainfo,
            target_datainfo,
            offset_y,
            args.camera_ids,
            camera_name_map,
            save_pseudo_root,
            (args.target_width, args.target_height),
            (args.pcd_width, args.pcd_height),
        )

    with (save_pseudo_root / "pesudo_sampletoken.json").open("w") as f:
        json.dump(sample_tokens, f)

    summary = {
        "scene": args.scene_name,
        "pseudo_flag": pseudo_flag,
        "frames": sample_tokens,
        "direction": args.direction,
        "max_offset": args.max_offset,
        "target_pose_mode": args.target_pose_mode,
        "anchor_frame": args.anchor_frame,
        "frame_gt": str(save_gt_root),
        "pseudo": str(save_pseudo_root),
        "waymo_sky_fill": {
            "top_ratio": WAYMO_SKY_FILL_TOP_RATIO,
            "depth": WAYMO_SKY_FILL_DEPTH,
        },
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
