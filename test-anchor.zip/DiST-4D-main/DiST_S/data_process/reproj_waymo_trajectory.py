#!/usr/bin/env python3
"""Build DiST-S Waymo inputs for a frame-varying lateral camera trajectory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from tqdm import tqdm

from reproj_waymo_movecam import (
    WAYMO_SKY_FILL_DEPTH,
    WAYMO_SKY_FILL_TOP_RATIO,
    build_datainfo,
    collect_frame_ids,
    parse_camera_map,
    save_movecam_frame,
)


def default_pseudo_name(final_offset: float, start_frame: int, end_frame: int) -> str:
    direction = "left" if final_offset >= 0 else "right"
    mag = f"{abs(final_offset):g}".replace(".", "p")
    return f"frame_trajegoy_{direction}{mag}_f{start_frame}_{end_frame}"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--scene-root",
        type=Path,
        default=Path("/data/wlh/OmniRe/data/waymo/processed/training/089"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val"),
    )
    parser.add_argument("--scene-name", type=str, default="waymo089")
    parser.add_argument("--camera-ids", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument(
        "--camera-map",
        type=str,
        default=None,
        help="Comma-separated id:name map, e.g. 0:CAM_FRONT,1:CAM_FRONT_LEFT,2:CAM_FRONT_RIGHT.",
    )
    parser.add_argument("--start-frame", type=int, default=145)
    parser.add_argument("--end-frame", type=int, default=168)
    parser.add_argument("--final-offset", type=float, required=True)
    parser.add_argument("--pseudo-flag-name", type=str, default=None)
    parser.add_argument("--target-width", type=int, default=768)
    parser.add_argument("--target-height", type=int, default=432)
    parser.add_argument("--pcd-width", type=int, default=1200)
    parser.add_argument("--pcd-height", type=int, default=675)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.end_frame < args.start_frame:
        raise ValueError("--end-frame must be >= --start-frame")

    camera_name_map = parse_camera_map(args.camera_map, args.camera_ids)
    frame_ids = collect_frame_ids(args.scene_root, args.camera_ids)
    frame_ids = [
        frame_id
        for frame_id in frame_ids
        if args.start_frame <= frame_id <= args.end_frame
    ]
    expected_len = args.end_frame - args.start_frame + 1
    if len(frame_ids) != expected_len:
        raise RuntimeError(
            f"Expected {expected_len} complete frames in "
            f"[{args.start_frame}, {args.end_frame}], found {len(frame_ids)}"
        )

    pseudo_flag_name = args.pseudo_flag_name or default_pseudo_name(
        args.final_offset, args.start_frame, args.end_frame
    )
    save_gt_root = args.output_root / "frame_gt" / args.scene_name
    save_pseudo_root = args.output_root / pseudo_flag_name / args.scene_name
    save_pseudo_root.mkdir(parents=True, exist_ok=True)

    offsets = np.linspace(0.0, args.final_offset, len(frame_ids), dtype=np.float32)
    sample_tokens = []
    trajectory_rows = []

    for frame_id, offset in tqdm(
        list(zip(frame_ids, offsets)),
        desc=f"{args.scene_name} trajectory {args.final_offset:g}m",
    ):
        sample_token = f"{frame_id:03d}"
        datainfo = build_datainfo(args.scene_root, frame_id, args.camera_ids)
        save_movecam_frame(
            args.scene_root,
            datainfo,
            save_gt_root,
            save_pseudo_root,
            camera_name_map,
            (args.target_width, args.target_height),
            (args.pcd_width, args.pcd_height),
            float(offset),
        )

        sample_tokens.append(sample_token)
        trajectory_rows.append(
            {
                "frame": frame_id,
                "sample_token": sample_token,
                "lateral_offset_m": float(offset),
            }
        )

    with (save_pseudo_root / "pesudo_sampletoken.json").open("w") as file:
        json.dump(sample_tokens, file)
    with (save_pseudo_root / "trajectory_offsets.json").open("w") as file:
        json.dump(trajectory_rows, file, indent=2)

    summary = {
        "scene": args.scene_name,
        "pseudo_flag_name": pseudo_flag_name,
        "frames": len(sample_tokens),
        "start_frame": args.start_frame,
        "end_frame": args.end_frame,
        "final_offset": args.final_offset,
        "first_offset": float(offsets[0]),
        "last_offset": float(offsets[-1]),
        "step_m": float(offsets[1] - offsets[0]) if len(offsets) > 1 else 0.0,
        "cameras": camera_name_map,
        "pseudo": str(save_pseudo_root),
        "target_size": [args.target_width, args.target_height],
        "waymo_sky_fill": {
            "top_ratio": WAYMO_SKY_FILL_TOP_RATIO,
            "depth": WAYMO_SKY_FILL_DEPTH,
        },
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
