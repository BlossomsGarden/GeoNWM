#!/usr/bin/env python3
"""Visualize DiST-S reprojection RGB/depth folders as videos.

Input should be a scene folder with camera subfolders, for example:

  frame_anchor145_egoy-0to6/waymo089_145_168/
  frame_movecam2egoy+1/11_scene/

Each camera folder is expected to contain matching RGB images and NPZ depth
files.  The script writes multiview RGB, depth, and RGB-over-depth videos.
"""

from __future__ import annotations

import argparse
import json
import math
import re
from contextlib import ExitStack
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import cv2
import imageio.v2 as imageio
import numpy as np


IMAGE_EXTS = (".jpg", ".jpeg", ".png")
DEPTH_KEYS = ("depth_proj", "depth_gt", "depth", "metric_depth", "pred_depth")
CAMERA_ORDER = (
    "CAM_FRONT_LEFT",
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_LEFT",
    "CAM_BACK",
    "CAM_BACK_RIGHT",
)
TOKEN_JSON_NAMES = (
    "pesudo_sampletoken.json",
    "pseudo_sampletoken.json",
    "sampletoken.json",
    "sample_tokens.json",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create RGB/depth multiview videos from DiST-S reprojection folders."
    )
    parser.add_argument("input_dir", type=Path, help="Scene folder containing camera subfolders.")
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--name", type=str, default=None, help="Output filename prefix.")
    parser.add_argument("--fps", type=int, default=10)
    parser.add_argument("--depth-min", type=float, default=0.5)
    parser.add_argument("--depth-max", type=float, default=120.0)
    parser.add_argument(
        "--depth-percentile",
        type=float,
        default=None,
        help="If set, estimate depth max from this percentile of valid depths.",
    )
    parser.add_argument(
        "--camera-order",
        nargs="+",
        default=None,
        help="Explicit camera order. Missing cameras are ignored.",
    )
    parser.add_argument(
        "--layout",
        choices=("auto", "row", "grid"),
        default="auto",
        help="auto: 3 front cams as 1x3, 6 cams as 2x3.",
    )
    parser.add_argument("--cols", type=int, default=None, help="Column count for grid layout.")
    parser.add_argument("--tile-width", type=int, default=None, help="Resize each camera tile.")
    parser.add_argument("--tile-height", type=int, default=None, help="Resize each camera tile.")
    parser.add_argument("--max-frames", type=int, default=None)
    parser.add_argument("--bitrate", type=str, default="8000k")
    parser.add_argument("--no-labels", action="store_true")
    parser.add_argument(
        "--per-camera",
        action="store_true",
        help="Also write per-camera rgb/depth/rgb_depth videos.",
    )
    return parser.parse_args()


def natural_key(value: str) -> List[object]:
    return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", value)]


def sanitize_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.+-]+", "_", value).strip("_")


def read_tokens(input_dir: Path) -> List[str] | None:
    for name in TOKEN_JSON_NAMES:
        path = input_dir / name
        if path.exists():
            with path.open("r") as file:
                tokens = json.load(file)
            return [str(token) for token in tokens]
    return None


def list_images(camera_dir: Path) -> Dict[str, Path]:
    files: Dict[str, Path] = {}
    for ext in IMAGE_EXTS:
        for path in camera_dir.glob(f"*{ext}"):
            files[path.stem] = path
    return files


def list_depths(camera_dir: Path) -> Dict[str, Path]:
    return {path.stem: path for path in camera_dir.glob("*.npz")}


def discover_cameras(input_dir: Path) -> List[str]:
    cameras = []
    for child in input_dir.iterdir():
        if not child.is_dir():
            continue
        if list_images(child) and list_depths(child):
            cameras.append(child.name)
    known_rank = {name: idx for idx, name in enumerate(CAMERA_ORDER)}
    return sorted(cameras, key=lambda name: (known_rank.get(name, 999), natural_key(name)))


def ordered_cameras(discovered: Sequence[str], explicit: Sequence[str] | None) -> List[str]:
    if explicit:
        ordered = [cam for cam in explicit if cam in discovered]
        ordered += [cam for cam in discovered if cam not in ordered]
        return ordered
    return list(discovered)


def collect_token_maps(input_dir: Path, cameras: Sequence[str]) -> Tuple[Dict[str, Dict[str, Path]], Dict[str, Dict[str, Path]], List[str]]:
    image_maps = {cam: list_images(input_dir / cam) for cam in cameras}
    depth_maps = {cam: list_depths(input_dir / cam) for cam in cameras}

    valid_sets = []
    for cam in cameras:
        valid_sets.append(set(image_maps[cam]).intersection(depth_maps[cam]))
    common_tokens = set.intersection(*valid_sets) if valid_sets else set()

    json_tokens = read_tokens(input_dir)
    if json_tokens is not None:
        tokens = [token for token in json_tokens if token in common_tokens]
    else:
        tokens = sorted(common_tokens, key=natural_key)

    return image_maps, depth_maps, tokens


def load_rgb(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(path)
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)


def load_depth(path: Path) -> np.ndarray:
    data = np.load(path)
    key = next((name for name in DEPTH_KEYS if name in data.files), None)
    if key is None:
        for name in data.files:
            arr = data[name]
            if np.issubdtype(arr.dtype, np.number) and arr.ndim >= 2:
                key = name
                break
    if key is None:
        raise KeyError(f"No numeric depth array found in {path}")

    depth = np.asarray(data[key], dtype=np.float32)
    depth = np.squeeze(depth)
    if depth.ndim == 3:
        if depth.shape[0] in (1, 3):
            depth = np.nanmean(depth, axis=0)
        elif depth.shape[-1] in (1, 3):
            depth = np.nanmean(depth, axis=-1)
        else:
            depth = depth[..., 0]
    if depth.ndim != 2:
        raise ValueError(f"Depth array in {path} must be 2D after squeeze, got {depth.shape}")
    return depth.astype(np.float32)


def estimate_depth_max(depth_paths: Iterable[Path], percentile: float, fallback: float) -> float:
    samples = []
    for idx, path in enumerate(depth_paths):
        if idx % 5 != 0:
            continue
        depth = load_depth(path)
        valid = depth[np.isfinite(depth) & (depth > 0)]
        if valid.size:
            samples.append(valid.ravel()[:: max(1, valid.size // 20000)])
    if not samples:
        return fallback
    merged = np.concatenate(samples)
    value = float(np.percentile(merged, percentile))
    return value if math.isfinite(value) and value > 0 else fallback


def colorize_depth(depth: np.ndarray, depth_min: float, depth_max: float) -> np.ndarray:
    valid = np.isfinite(depth) & (depth > 0)
    clipped = np.clip(depth, depth_min, depth_max)
    denom = max(depth_max - depth_min, 1e-6)
    norm = ((clipped - depth_min) / denom * 255.0).astype(np.uint8)
    colored_bgr = cv2.applyColorMap(norm, cv2.COLORMAP_TURBO)
    colored = cv2.cvtColor(colored_bgr, cv2.COLOR_BGR2RGB)
    colored[~valid] = 0
    return colored


def resize_image(image: np.ndarray, size_wh: Tuple[int, int]) -> np.ndarray:
    width, height = size_wh
    if image.shape[1] == width and image.shape[0] == height:
        return image
    return cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)


def draw_label(image: np.ndarray, label: str) -> np.ndarray:
    result = image.copy()
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = max(0.45, min(result.shape[:2]) / 900.0)
    thickness = max(1, int(round(scale * 2)))
    (text_w, text_h), baseline = cv2.getTextSize(label, font, scale, thickness)
    pad = 8
    overlay = result.copy()
    cv2.rectangle(
        overlay,
        (0, 0),
        (text_w + pad * 2, text_h + baseline + pad * 2),
        (0, 0, 0),
        -1,
    )
    result = cv2.addWeighted(overlay, 0.45, result, 0.55, 0)
    cv2.putText(
        result,
        label,
        (pad, pad + text_h),
        font,
        scale,
        (255, 255, 255),
        thickness,
        cv2.LINE_AA,
    )
    return result


def make_rows(num_cameras: int, layout: str, cols: int | None) -> List[List[int]]:
    if layout == "row":
        return [list(range(num_cameras))]
    if layout == "auto":
        if num_cameras == 6:
            return [list(range(3)), list(range(3, 6))]
        if num_cameras <= 4:
            return [list(range(num_cameras))]
        cols = cols or 3
    else:
        cols = cols or 3

    return [list(range(start, min(start + cols, num_cameras))) for start in range(0, num_cameras, cols)]


def tile_grid(images: Sequence[np.ndarray], rows: Sequence[Sequence[int]]) -> np.ndarray:
    tile_h, tile_w = images[0].shape[:2]
    row_frames = []
    for row in rows:
        tiles = [images[idx] for idx in row]
        missing = max(len(rows[0]) - len(row), 0)
        if missing:
            tiles += [np.zeros((tile_h, tile_w, 3), dtype=np.uint8) for _ in range(missing)]
        row_frames.append(np.concatenate(tiles, axis=1))
    return np.concatenate(row_frames, axis=0)


def open_writer(path: Path, fps: int, bitrate: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    return imageio.get_writer(
        path,
        fps=fps,
        codec="libx264",
        bitrate=bitrate,
        quality=10,
        macro_block_size=1,
    )


def default_output_name(input_dir: Path) -> str:
    return sanitize_name(f"{input_dir.parent.name}_{input_dir.name}")


def main() -> None:
    args = parse_args()
    input_dir = args.input_dir.resolve()
    if not input_dir.is_dir():
        raise NotADirectoryError(input_dir)

    discovered = discover_cameras(input_dir)
    cameras = ordered_cameras(discovered, args.camera_order)
    if not cameras:
        raise RuntimeError(f"No camera folders with matching RGB/NPZ files found in {input_dir}")

    image_maps, depth_maps, tokens = collect_token_maps(input_dir, cameras)
    if args.max_frames is not None:
        tokens = tokens[: args.max_frames]
    if not tokens:
        raise RuntimeError(f"No common RGB/depth tokens found across cameras: {cameras}")

    first_rgb = load_rgb(image_maps[cameras[0]][tokens[0]])
    if args.tile_width and args.tile_height:
        tile_size = (args.tile_width, args.tile_height)
    elif args.tile_width:
        tile_size = (args.tile_width, round(first_rgb.shape[0] * args.tile_width / first_rgb.shape[1]))
    elif args.tile_height:
        tile_size = (round(first_rgb.shape[1] * args.tile_height / first_rgb.shape[0]), args.tile_height)
    else:
        tile_size = (first_rgb.shape[1], first_rgb.shape[0])

    depth_max = args.depth_max
    if args.depth_percentile is not None:
        paths = [depth_maps[cam][token] for cam in cameras for token in tokens]
        depth_max = estimate_depth_max(paths, args.depth_percentile, args.depth_max)

    output_dir = (args.output_dir or (input_dir / "_viz")).resolve()
    name = sanitize_name(args.name) if args.name else default_output_name(input_dir)
    rows = make_rows(len(cameras), args.layout, args.cols)

    output_paths = {
        "rgb": output_dir / f"{name}_rgb_multiview.mp4",
        "depth": output_dir / f"{name}_depth_multiview.mp4",
        "rgb_depth": output_dir / f"{name}_rgb_depth_multiview.mp4",
    }

    with ExitStack() as stack:
        writers = {
            key: stack.enter_context(open_writer(path, args.fps, args.bitrate))
            for key, path in output_paths.items()
        }
        per_camera_writers = {}
        if args.per_camera:
            for cam in cameras:
                safe_cam = sanitize_name(cam)
                per_camera_writers[(cam, "rgb")] = stack.enter_context(
                    open_writer(output_dir / "per_camera" / f"{safe_cam}_rgb.mp4", args.fps, args.bitrate)
                )
                per_camera_writers[(cam, "depth")] = stack.enter_context(
                    open_writer(output_dir / "per_camera" / f"{safe_cam}_depth.mp4", args.fps, args.bitrate)
                )
                per_camera_writers[(cam, "rgb_depth")] = stack.enter_context(
                    open_writer(output_dir / "per_camera" / f"{safe_cam}_rgb_depth.mp4", args.fps, args.bitrate)
                )

        for token in tokens:
            rgb_tiles = []
            depth_tiles = []
            for cam in cameras:
                rgb = resize_image(load_rgb(image_maps[cam][token]), tile_size)
                depth = load_depth(depth_maps[cam][token])
                depth_color = resize_image(colorize_depth(depth, args.depth_min, depth_max), tile_size)
                if not args.no_labels:
                    rgb = draw_label(rgb, cam)
                    depth_color = draw_label(depth_color, f"{cam} depth")
                rgb_tiles.append(rgb)
                depth_tiles.append(depth_color)

                if args.per_camera:
                    per_camera_writers[(cam, "rgb")].append_data(rgb)
                    per_camera_writers[(cam, "depth")].append_data(depth_color)
                    per_camera_writers[(cam, "rgb_depth")].append_data(
                        np.concatenate([rgb, depth_color], axis=0)
                    )

            rgb_grid = tile_grid(rgb_tiles, rows)
            depth_grid = tile_grid(depth_tiles, rows)
            writers["rgb"].append_data(rgb_grid)
            writers["depth"].append_data(depth_grid)
            writers["rgb_depth"].append_data(np.concatenate([rgb_grid, depth_grid], axis=0))

    summary = {
        "input_dir": str(input_dir),
        "output_dir": str(output_dir),
        "cameras": cameras,
        "num_frames": len(tokens),
        "first_token": tokens[0],
        "last_token": tokens[-1],
        "tile_size": {"width": tile_size[0], "height": tile_size[1]},
        "layout_rows": [[cameras[idx] for idx in row] for row in rows],
        "depth_min": args.depth_min,
        "depth_max": depth_max,
        "videos": {key: str(path) for key, path in output_paths.items()},
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
