#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate dists

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-2}

MODEL_PATH=${MODEL_PATH:-/data4/DATA/wlh/DiST-4D/model/DiST-S-checkpoint-20000}
IMG_ROOT=${IMG_ROOT:-/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val}
OUTPUT_DIR=${OUTPUT_DIR:-/data4/DATA/wlh/DiST-4D/output/waymo089_dist_s}
PSEUDO_FLAG=${1:-frame_movecam2egoy+3}
MAX_CLIPS_ARGS=()

if [[ -n "${MAX_CLIPS:-}" ]]; then
  MAX_CLIPS_ARGS=(--max_clips "$MAX_CLIPS")
fi

cd /data4/DATA/wlh/DiST-4D/code/DiST_S/diffusers

python examples/inference_mm_mp_modVis.py \
  --model_path "$MODEL_PATH" \
  --img_root "$IMG_ROOT" \
  --output_dir "$OUTPUT_DIR" \
  --pesudo_flag_name "$PSEUDO_FLAG" \
  --with_valid_mask \
  --video_width 768 \
  --video_height 448 \
  --video_length 6 \
  --multi_process 1 \
  --scenes waymo089 \
  --cameras CAM_FRONT CAM_FRONT_LEFT CAM_FRONT_RIGHT \
  "${MAX_CLIPS_ARGS[@]}"
