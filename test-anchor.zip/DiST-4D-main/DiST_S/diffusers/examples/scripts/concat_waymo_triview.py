#!/usr/bin/env python3
"""Concatenate Waymo front-left/front/front-right generated RGB/depth views.

The DiST-S inference script writes one debug MP4 per camera.  Each frame is a
2x3 panel:

  generated RGB | pseudo RGB | GT RGB
  generated dep | pseudo dep | GT dep

For Waymo reporting we keep the generated column only, concatenate the front
three cameras horizontally, and write a fixed 2x3 video:

  FRONT_LEFT RGB | FRONT RGB | FRONT_RIGHT RGB
  FRONT_LEFT dep | FRONT dep | FRONT_RIGHT dep
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from contextlib import ExitStack

import imageio.v2 as imageio
import numpy as np
from PIL import Image


CAMERA_ORDER = ("CAM_FRONT_LEFT", "CAM_FRONT", "CAM_FRONT_RIGHT")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--img-root", type=Path, required=True)
    parser.add_argument("--pseudo-flag", type=str, required=True)
    parser.add_argument("--scene", type=str, default="waymo089_145_168")
    parser.add_argument("--fps", type=int, default=10)
    parser.add_argument("--bitrate", type=str, default="8000k")
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument("--frames-dir", type=Path, default=None)
    parser.add_argument("--no-save-frames", action="store_true")
    return parser.parse_args()


def load_tokens(img_root: Path, pseudo_flag: str, scene: str) -> list[str]:
    token_path = img_root / pseudo_flag / scene / "pesudo_sampletoken.json"
    with token_path.open("r") as f:
        return json.load(f)


def generated_rgb_depth_column(debug_frame: np.ndarray) -> np.ndarray:
    """Return the generated RGB/depth column from a DiST-S per-camera panel."""
    frame = np.asarray(debug_frame)
    if frame.ndim != 3 or frame.shape[2] < 3:
        raise ValueError(f"Expected RGB video frame, got {frame.shape}")
    frame = frame[:, :, :3]
    height, width = frame.shape[:2]
    if height < 2 or width < 3:
        raise ValueError(f"Debug frame is too small to be a 2x3 panel: {frame.shape}")
    tile_width = width // 3
    return frame[:, :tile_width, :]


def resize_to_height(frame: np.ndarray, height: int) -> np.ndarray:
    if frame.shape[0] == height:
        return frame
    width = round(frame.shape[1] * height / frame.shape[0])
    return np.asarray(Image.fromarray(frame).resize((width, height)))


def main() -> None:
    args = parse_args()
    scene_dir = args.output_root / args.pseudo_flag / args.scene
    tokens = load_tokens(args.img_root, args.pseudo_flag, args.scene)
    out_path = args.out or (
        scene_dir / f"{args.scene}_{args.pseudo_flag}_front_triview_rgb_depth.mp4"
    )
    out_path.parent.mkdir(parents=True, exist_ok=True)
    frames_dir = args.frames_dir or (
        scene_dir / f"{args.scene}_{args.pseudo_flag}_front_triview_rgb_depth_frames"
    )
    if not args.no_save_frames:
        frames_dir.mkdir(parents=True, exist_ok=True)

    with ExitStack() as stack:
        readers = {}
        for cam in CAMERA_ORDER:
            video_path = scene_dir / f"{cam}.mp4"
            if not video_path.exists():
                raise FileNotFoundError(video_path)
            reader = imageio.get_reader(video_path)
            stack.callback(reader.close)
            readers[cam] = reader

        writer = stack.enter_context(
            imageio.get_writer(
                out_path,
                fps=args.fps,
                codec="libx264",
                bitrate=args.bitrate,
                quality=10,
                macro_block_size=1,
            )
        )

        for frame_idx, token in enumerate(tokens):
            camera_tiles = []
            for cam in CAMERA_ORDER:
                try:
                    debug_frame = readers[cam].get_data(frame_idx)
                except IndexError as exc:
                    raise IndexError(
                        f"{scene_dir / (cam + '.mp4')} has fewer frames than token list"
                    ) from exc
                camera_tiles.append(generated_rgb_depth_column(debug_frame))

            height = min(tile.shape[0] for tile in camera_tiles)
            camera_tiles = [resize_to_height(tile, height) for tile in camera_tiles]
            frame = np.concatenate(camera_tiles, axis=1)
            writer.append_data(frame)
            if not args.no_save_frames:
                Image.fromarray(frame).save(frames_dir / f"{token}.jpg", quality=95)

    print(out_path)
    if not args.no_save_frames:
        print(frames_dir)


if __name__ == "__main__":
    main()
