#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate dists

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-2}

MODEL_PATH=${MODEL_PATH:-/data4/DATA/wlh/DiST-4D/model/DiST-S-checkpoint-20000}
IMG_ROOT=${IMG_ROOT:-/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val}
OUTPUT_DIR=${OUTPUT_DIR:-/data4/DATA/wlh/DiST-4D/output/waymo089_fixed145_168_lr4_6_dist_s}
SCENE=${SCENE:-waymo089_145_168}
PSEUDO_FLAGS=("$@")

if [[ ${#PSEUDO_FLAGS[@]} -eq 0 ]]; then
  PSEUDO_FLAGS=(frame_movecam2egoy+4 frame_movecam2egoy+6 frame_movecam2egoy-4 frame_movecam2egoy-6)
fi

MAX_CLIPS_ARGS=()
if [[ -n "${MAX_CLIPS:-}" ]]; then
  MAX_CLIPS_ARGS=(--max_clips "$MAX_CLIPS")
fi

cd /data4/DATA/wlh/DiST-4D/code/DiST_S/diffusers

for PSEUDO_FLAG in "${PSEUDO_FLAGS[@]}"; do
  python examples/inference_mm_mp_modVis.py \
    --model_path "$MODEL_PATH" \
    --img_root "$IMG_ROOT" \
    --output_dir "$OUTPUT_DIR" \
    --pesudo_flag_name "$PSEUDO_FLAG" \
    --with_valid_mask \
    --video_width 768 \
    --video_height 448 \
    --video_length 6 \
    --multi_process 1 \
    --scenes "$SCENE" \
    --cameras CAM_FRONT CAM_FRONT_LEFT CAM_FRONT_RIGHT \
    "${MAX_CLIPS_ARGS[@]}"

  python examples/scripts/concat_waymo_triview.py \
    --output-root "$OUTPUT_DIR" \
    --img-root "$IMG_ROOT" \
    --pseudo-flag "$PSEUDO_FLAG" \
    --scene "$SCENE" \
    --fps 10
done
