#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate dists

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-2}

MODEL_PATH=${MODEL_PATH:-/data4/DATA/wlh/DiST-4D/model/DiST-S-checkpoint-20000}
IMG_ROOT=${IMG_ROOT:-/data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val}
OUTPUT_DIR=${OUTPUT_DIR:-/data4/DATA/wlh/DiST-4D/output/waymo089_anchor145_lr6_dist_s}
SCENE=${SCENE:-waymo089_145_168}
ORIGIN_IMAGE_MODE=${ORIGIN_IMAGE_MODE:-prev_chunk_last_generated}
PSEUDO_FLAGS=("$@")

if [[ ${#PSEUDO_FLAGS[@]} -eq 0 ]]; then
  PSEUDO_FLAGS=(frame_anchor145_egoy+0to6 frame_anchor145_egoy-0to6)
fi

MAX_CLIPS_ARGS=()
if [[ -n "${MAX_CLIPS:-}" ]]; then
  MAX_CLIPS_ARGS=(--max_clips "$MAX_CLIPS")
fi

cd /data4/DATA/wlh/DiST-4D/code/DiST_S/diffusers

for PSEUDO_FLAG in "${PSEUDO_FLAGS[@]}"; do
  python examples/inference_mm_mp_modVis.py \
    --model_path "$MODEL_PATH" \
    --img_root "$IMG_ROOT" \
    --output_dir "$OUTPUT_DIR" \
    --pesudo_flag_name "$PSEUDO_FLAG" \
    --with_valid_mask \
    --video_width 768 \
    --video_height 448 \
    --video_length 6 \
    --multi_process 1 \
    --origin_image_mode "$ORIGIN_IMAGE_MODE" \
    --scenes "$SCENE" \
    --cameras CAM_FRONT CAM_FRONT_LEFT CAM_FRONT_RIGHT \
    "${MAX_CLIPS_ARGS[@]}"

  python examples/scripts/concat_waymo_triview.py \
    --output-root "$OUTPUT_DIR" \
    --img-root "$IMG_ROOT" \
    --pseudo-flag "$PSEUDO_FLAG" \
    --scene "$SCENE" \
    --fps 10
done
