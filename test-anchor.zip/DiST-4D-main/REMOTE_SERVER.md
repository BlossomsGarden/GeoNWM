<!-- 我已经把论文 [FreeVS.pdf](FreeVS.pdf) 的源码下载到 [FreeVS-master](FreeVS-master/) 里了，你帮我在 [REMOTE_SERVER.md](deltatok-main/REMOTE_SERVER.md) 所示的远程服务器上复现一下，conda环境、waymo数据集路径（没有pkl文件你需要自己生成）、waymo上的预训练模型也都给你了，你自己传代码到服务器、如果依赖没装完就安装补上，我想看他找一些行人比较多的场景看看新视角下free trajectory的轨迹如何，判断其对行人的保真能力。记住，复现完毕后不要全拉回本地，节省网络流量，一两个视频到本地就行，使用superpowers执行框架，认真地分析代码、我的需求并执行 -->

ip: 219.223.207.223

port: 22

user_name: wlh

password: wlh@2025

connect-tool: paramiko (already installed) or scp

# 请注意，不要创建什么文件软链接，直接让代码文件里的路径指向这些地方就行了

# 如果需要修改文件，直接在本地改改文件（如果没有就把必要文件拉下来），改完再scp推上去就完事了

# 除了可视化结果图片或视频可以拉取到本地，其他计算尽量都在云端完成，而且要尽量减少拉取到本地，节省流量

# 服务器无法访问中国境外网站，如果需要克隆代码或者下载权重，可使用中国境内的代理网站

# 一切搜索查询仅限于 project_dir ，这里没有就是没有，不要到路径之外去查找搜索东西，解决不了就报错让我来手动解决

project_dir: /data4/DATA/wlh/DiST-4D

code_dir: /data4/DATA/wlh/DiST-4D/code

model_dir: /data4/DATA/wlh/DiST-4D/model

waymo_test_scene: /data/wlh/OmniRe/data/waymo/processed/training/089

nuscenes_test_scnene: /data4/DATA/wlh/DiST-4D/data/release_data_nus_Rdepth

nuscenes_dir: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval

conda_dir:/data/wlh/miniconda3

conda_env_name: dists

