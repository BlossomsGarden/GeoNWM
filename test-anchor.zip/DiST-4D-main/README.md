<!-- # <center> DiST-4D: Disentangled Spatiotemporal Diffusion with Metric Depth for 4D Driving Scene Generation -->

<div align="center">

___<font size="10">***DiST-4D: Disentangled Spatiotemporal Diffusion with Metric Depth for 4D Driving Scene Generation***</font>___
<br>
<br>
<a href='https://arxiv.org/pdf/2503.15208'><img src='https://img.shields.io/badge/arXiv-2503.15208-b31b1b.svg'></a>
&nbsp;
<a href='https://royalmelon0505.github.io/DiST-4D/'><img src='https://img.shields.io/badge/Project-Page-Green'></a>
&nbsp;

_**[Jiazhe Guo](https://scholar.google.com/citations?hl=zh-CN&user=pWLqZnoAAAAJ), [Yikang Ding](https://scholar.google.com/citations?hl=zh-CN&user=gdP9StQAAAAJ), [Xiwu Chen](https://scholar.google.com/citations?user=PVMQa-IAAAAJ), [Shuo Chen](), [Bohan Li](https://scholar.google.com/citations?hl=zh-CN&user=V-YdQiAAAAAJ), [Yingshuang Zou](https://heiheishuang.xyz), <br>[Xiaoyang Lyu](https://shawlyu.github.io/), [Feiyang Tan](https://scholar.google.com/citations?hl=zh-CN&user=KeiZBdMAAAAJ), [Xiaojuan Qi](https://scholar.google.com/citations?hl=zh-CN&user=bGn0uacAAAAJ), [Zhiheng Li](https://www.sigs.tsinghua.edu.cn/lzh_en/main.htm), [Hao Zhao](https://scholar.google.com/citations?hl=zh-CN&user=ygQznUQAAAAJ)**_
<br><br>
<font size="10">ICCV 2025</font>
</div>

<!-- ## DiST-4D: Disentangled Spatiotemporal Diffusion with Metric Depth for 4D Driving Scene Generation -->

<!-- [![arXiv paper](https://img.shields.io/badge/arXiv%20%2B%20supp-2503.-purple)](https://arxiv.org/abs/)
[![Code page](https://img.shields.io/badge/Project%20Page-DiST4D-red)](https://royalmelon0505.github.io/DiST-4D/) -->


*DiST-4D* is the first framework to achieve **feed-forward** dynamic 4D driving scene generation with both temporal extrapolation and spatial novel view synthesis.

## 💫  Framework
<div align=center><img width="960" height="372" src="./assets/Fig_ppl.png"/></div>

DiST-4D is a disentangled spatiotemporal diffusion framework for 4D driving scene generation, leveraging metric depth as the core geometric representation to enable both temporal extrapolation and spatial novel view synthesis (NVS). 
**(Top: Temporal Generation)** DiST-T employs a diffusion model to predict future multi-camera RGB-D sequences from historical multi-camera images and control signals. The generated RGB-D sequences are then aggregated into point clouds, allowing for bullet time rendering. **(Bottom: Spatial Generation)** To enable spatial NVS, DiST-S leverages the predicted RGB-D sequences to generate novel viewpoints by first projecting them into sparse conditions and then refining them into dense RGB-D outputs.

## 🔆 News
- [2025/7]: Code and pre-trained weights are released.
- [2025/6]: Paper is accepted on **ICCV 2025**.
- [2025/3]: Check out our other latest works on generative world models: [UniScene](https://github.com/Arlo0o/UniScene-Unified-Occupancy-centric-Driving-Scene-Generation/blob/master/README.md), [MuDG](https://github.com/heiheishuang/MuDG), [HERMES](https://lmd0311.github.io/HERMES/).
- [2025/3]: Paper is on [arxiv](https://arxiv.org/abs/2503.15208).
- [2025/3]: Demo is released on [Project Page](https://royalmelon0505.github.io/DiST-4D/).

## 👀 Abstract
Current generative models struggle to synthesize dynamic 4D driving scenes that simultaneously support temporal extrapolation and spatial novel view synthesis (NVS) without per-scene optimization. A key challenge lies in finding an efficient and generalizable geometric representation that seamlessly connects temporal and spatial synthesis. To address this, we propose DiST-4D, the first disentangled spatiotemporal diffusion framework for 4D driving scene generation, which leverages metric depth as the core geometric representation. DiST-4D decomposes the problem into two diffusion processes: DiST-T, which predicts future metric depth and multi-view RGB sequences directly from past observations, and DiST-S, which enables spatial NVS by training only on existing viewpoints while enforcing cycle consistency. This cycle consistency mechanism introduces a forward-backward rendering constraint, reducing the generalization gap between observed and unseen viewpoints. Metric depth is essential for both accurate reliable forecasting and accurate spatial NVS, as it provides a view-consistent geometric representation that generalizes well to unseen perspectives. Experiments demonstrate that DiST-4D achieves state-of-the-art performance in both temporal prediction and NVS tasks, while also delivering competitive performance in planning-related evaluations.


## 🕹️ Getting Started

### Prepare NuScenes Dataset
1. Download nuScenes dataset 
Download all splits of Trainval in Full dataset (v1.0) to your device following nuscenes official instructions and put them to "/data/nuscenes".

2. Download advanced_12Hz_trainval metadata from [MagicDrive](https://coda-dataset.github.io/w-coda2024/track2/)
```
$./data/nuscenes
├── samples
├── sweeps
├── ...
├── v1.0-trainval
└── advanced_12Hz_trainval
```

3. Download metadata (preprocessing pkl) as [MagicDriveDiT](https://github.com/flymin/MagicDriveDiT) and put them to "/data/nuscenes_mmdet3d-12Hz/"

### Preprocess Depth of NuScenes

1. conda environment

- pre_py39: `depth_process/requirement/pre_py39.txt` which is modified from [DepthLab](https://github.com/ant-research/DepthLab)

- mvs_py38: `depth_process/requirement/mvs_py38.txt` which is used for semantic segmentation in visual reconstruction.

2. DownLoad the ckpt of [DepthLab](https://github.com/ant-research/DepthLab) in `depth_process/DepthLab/checkpoints`

3. Prepare the ckpt of [SegFormer](https://github.com/NVlabs/SegFormer) to `depth_process/visualrecon/SemSeg/SegFormer` and [Oneformer](https://github.com/SHI-Labs/OneFormer) to `depth_process/visualrecon/SemSeg/OneFormer`

4. Preprocess one scene in NuScenes (for example indice = 1)
```bash
# MVS part
cd depth_process
./visualrecon/mvs_pipe_nus.sh $indice

# DepthLab refine depth
./DepthLab/scripts/infer_nus_video_mp.sh $indice
```
**Note:**  In order to preprocessing all scene, you need to run the above script from `indice=0` to `indice=849`, which is time consuming. Since we already have multi-processing setup in our MVS code, it is more recommended to use a loop to process each scene like `depth_process/visualrecon/batch_mvs_nus.sh`

5. Semantic Segmenation with [Oneformer](https://github.com/SHI-Labs/OneFormer) form scene-0 to scene-849 using 8gpu and mp=1
```bash
cd depth_process/visualrecon
./Batch_SemSeg_nus_oneformer.sh 0 849 8 1

# We recommend to use multiple processes or nodes to handle the above tasks
#./Batch_SemSeg_nus_oneformer.sh 0 99 8 1
#./Batch_SemSeg_nus_oneformer.sh 100 199 8 1
# ...
```

The processed depth and semantic will be put in `depth_process/nus_Rdepth` (A scene takes up about 3GB)

We have also provided some preprocessed scenes on the validation set to facilitate testing. Please download these scenes from [Hugging Face](https://huggingface.co/datasets/melon287/nus_Rdepth/blob/main/release_data_nus_Rdepth.zip)

### DiST-T
omitted.


### DiST-S

#### DiST-S training loss notes

The original DiST-S training code uses a single latent-space diffusion denoising MSE. There is no separate RGB loss, depth loss, LPIPS, SSIM, mask-only loss, or differentiable cycle-consistency loss in the training objective.

Relevant files:

- Stage 1: `DiST_S/diffusers/examples/train_svd_nus_mm.py`
- Stage 2 with SCC data: `DiST_S/diffusers/examples/train_svd_nus_mm_modVis.py`
- Training launch scripts: `DiST_S/diffusers/examples/scripts/mm_train_nus_768.sh` and `DiST_S/diffusers/examples/scripts/mm_train_nus_modVis.sh`

The loss pipeline is:

1. Encode dense target RGB frames with the SVD VAE:
   `z_rgb = VAE(rgb_gt)`.
2. Encode dense target depth frames with the same VAE, treating depth as a 3-channel pseudo image:
   `z_depth = VAE(depth_gt)`.
3. Concatenate RGB and depth latents:
   `z = concat(z_rgb, z_depth)`, producing an 8-channel latent.
4. Sample continuous EDM/SVD-style noise:
   `noisy_latents = z + randn_like(z) * sigma`.
5. Run the UNet on the noisy RGB-D latent plus sparse RGB/depth conditions.
6. Apply SVD preconditioning:
   `pred_final = c_out * model_pred + c_skip * noisy_latents`.
7. Optimize weighted MSE over all RGB and depth latent channels:
   `loss = ((pred_final - z) ** 2 * loss_weight).mean()`.

The code computes:

```python
P_std = 1.6
P_mean = 0.7
rnd_normal = torch.randn([bsz, 1, 1, 1, 1], device=latents.device)
sigma = (rnd_normal * P_std + P_mean).exp()
c_skip = 1 / (sigma**2 + 1)
c_out = -sigma / (sigma**2 + 1) ** 0.5
c_in = 1 / (sigma**2 + 1) ** 0.5
c_noise = (sigma.log() / 4).reshape([bsz])
loss_weight = (sigma ** 2 + 1) / sigma ** 2

latents = torch.cat([latents, depth_latents], dim=2)
noisy_latents = latents + torch.randn_like(latents) * sigma
pred_final = c_out * model_pred + c_skip * noisy_latents
loss = ((pred_final - latents) ** 2 * loss_weight).mean()
```

So the effective objective is:

```text
L = mean( w(sigma) * || D_theta(z + sigma * eps, cond, sigma) - z ||^2 )
w(sigma) = (sigma^2 + 1) / sigma^2
z = concat(z_rgb, z_depth)
```

Stage 2 keeps the same loss formula. Its main difference is the data mixture: `train_svd_nus_mm_modVis.py` changes the pseudo-condition list to include `cycle_reproj`, so SCC/cycle information enters through generated training data rather than through an additional differentiable cycle loss.

`--with_valid_mask` is also a conditioning choice, not a loss mask. In `DiST_S/diffusers/examples/utils/video_datasets_mm.py`, it replaces the third pseudo-depth channel with a valid mask before the depth condition is encoded. The final loss still averages over the full RGB-D latent tensor without explicit valid-region or hole-region weighting.

1. conda environment
- dists: `DiST_S/requirement/dists.txt` which is modified from [FreeVS](https://github.com/esdolo/FreeVS)

2. Data process
```bash
cd DiST_S
#Train set forward or backward projection (current only +2frame)
./data_process/batch_reproj_nus_train_2frame.sh $start_idx $end_idx
#For example:
#./data_process/batch_reproj_nus_train_2frame.sh 0 700

#Val set lateral camera move (+1m +2m +4m)
./data_process/batch_reproj_nus_val_movecam.sh $start_idx $end_idx
#For example:
#./data_process/batch_reproj_nus_val_movecam.sh 0 150
```
**Note:**  We recommend to use multiple processes for data process. The processed condition is in `DiST_S/reproj_nus`

3. Download SVD ckpt from  https://huggingface.co/stabilityai/stable-video-diffusion-img2vid-xt. and put it in `DiST_S/pretrained`

4. Train stage1
```bash
cd DiST_S/diffusers/
./examples/scripts/mm_train_nus_768.sh
```

5. SCC Data process
```bash
cd DiST_S/diffusers/
./examples/scripts/mm_infer_nus_cycle_reproj.sh
```

6. Train stage2 with SCC Data
```bash
cd DiST_S/diffusers/
./examples/scripts/mm_train_nus_modVis.sh
```

7. Final inference after SCC training
```bash
cd DiST_S/diffusers/
./examples/scripts/mm_infer_nus_mp_768_modVis.sh
```

#### Only inference the DiST-S model for test 

1. Run the data process of Val set. 
```bash
# lateral camera move (+1m +2m +4m) 
./data_process/batch_reproj_nus_val_movecam.sh $start_idx $end_idx
```

2. Download the pretrained [DiST-S ckpt](https://drive.google.com/drive/folders/1rKHV6to2J_frU7WOkfLergJjik02HN46?usp=sharing) and put it in `DiST_S/ckpt/mm_multi_cam_hybridD_valid_mask_768_mod_cycle_p`

3. Run the inference code
```bash
cd DiST_S/diffusers/
./examples/scripts/mm_infer_nus_mp_768_modVis.sh
```

##### Waymo089 front-three-camera test inference

The Waymo test scene used here is
`/data/wlh/OmniRe/data/waymo/processed/training/089`.  The helper scripts below
prepare frames `145..168` for the first three Waymo cameras only:
`0:CAM_FRONT`, `1:CAM_FRONT_LEFT`, `2:CAM_FRONT_RIGHT`.

For fixed lateral translation, rebuild the sparse RGB/depth conditions with:

```bash
cd /data4/DATA/wlh/DiST-4D/code/DiST_S
bash data_process/batch_reproj_waymo089_fixed145_168_lr4_6.sh 6 -6
```

This wraps `data_process/reproj_waymo_movecam.py` with the key arguments:
`--scene-root /data/wlh/OmniRe/data/waymo/processed/training/089`,
`--output-root /data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val`,
`--scene-name waymo089_145_168`, `--camera-ids 0 1 2`,
`--mod_y_d 6` or `--mod_y_d -6`, `--start-frame 145`,
`--end-frame 168`, `--target-width 768`, `--target-height 432`,
`--pcd-width 1200`, and `--pcd-height 675`.

For the anchored gradual trajectory from frame 145 to a 6 m lateral offset, run:

```bash
cd /data4/DATA/wlh/DiST-4D/code/DiST_S
bash data_process/batch_reproj_waymo089_anchor145_lr6.sh
```

This wraps `data_process/reproj_waymo_anchor_trajectory.py` with
`--start-frame 145`, `--end-frame 168`, `--anchor-frame 145`,
`--direction left/right`, `--max-offset 6`, and `--target-pose-mode anchor`.
For every timestep it rebuilds the point cloud from the same frame's front
three RGB-D views and then projects it into the target camera trajectory.

Run DiST-S on the fixed left/right 6 m conditions:

```bash
CUDA_VISIBLE_DEVICES=2 \
bash /data4/DATA/wlh/DiST-4D/code/DiST_S/diffusers/examples/scripts/mm_infer_waymo089_fixed145_168_lr4_6.sh \
  frame_movecam2egoy+6 frame_movecam2egoy-6
```

Run DiST-S on the anchored gradual left/right 0-to-6 m conditions:

```bash
CUDA_VISIBLE_DEVICES=2 \
bash /data4/DATA/wlh/DiST-4D/code/DiST_S/diffusers/examples/scripts/mm_infer_waymo089_anchor145_lr6.sh \
  frame_anchor145_egoy+0to6 frame_anchor145_egoy-0to6
```

Both inference wrappers call `examples/inference_mm_mp_modVis.py` with
`--img_root /data4/DATA/wlh/DiST-4D/data/inference_reproj_waymo/val`,
`--with_valid_mask`, `--video_width 768`, `--video_height 448`,
`--video_length 6`, `--multi_process 1`, `--scenes waymo089_145_168`, and
`--cameras CAM_FRONT CAM_FRONT_LEFT CAM_FRONT_RIGHT`.  `--pesudo_flag_name`
selects the prepared condition folder, for example `frame_movecam2egoy+6`.

The Waymo sparse condition generation keeps upper-image sky holes by default:
invalid projected pixels in the upper image region are filled from the same
frame RGB and assigned a far positive depth, so `--with_valid_mask` treats
them as valid sparse RGB/depth conditions.

The returned Waymo visualization format is fixed.  Each sample writes
per-camera RGB frames and a `*_front_triview_rgb_depth.mp4` video.  The video
uses the camera order `CAM_FRONT_LEFT | CAM_FRONT | CAM_FRONT_RIGHT`; the first
row is generated RGB and the second row is the corresponding generated depth
visualization.  Matching single-frame 2x3 panels are saved in the adjacent
`*_front_triview_rgb_depth_frames/` directory.
