#!/usr/bin/env python3
"""Repair failed MoGe-2/LiDAR depth alignments in-place.

For records whose original affine fit produced zero training mask, try several
positive/monotonic re-calibration models against projected LiDAR depth. The
best model is selected by deterministic spatial cross-validation and then used
to rewrite align_depth. This avoids silently dropping samples while preserving
quality metadata in the manifest.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from collections import Counter, defaultdict
from pathlib import Path
from typing import Callable, Dict, Iterable, Tuple

import numpy as np
from tqdm import tqdm


def atomic_npz(path: Path, **arrays) -> None:
    tmp = path.with_suffix(path.suffix + f'.tmp.{os.getpid()}')
    np.savez(str(tmp), **arrays)
    actual = Path(str(tmp) + '.npz')
    if actual.exists():
        actual.replace(path)
    else:
        tmp.replace(path)


def load_rows(path: Path):
    rows = []
    with path.open('r') as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def eval_pred(z: np.ndarray, y: np.ndarray):
    valid = np.isfinite(z) & np.isfinite(y) & (z > 0.1) & (z < 120.0) & (y > 0.1) & (y < 120.0)
    if int(valid.sum()) < 20:
        return None
    res = z[valid] - y[valid]
    absrel = float(np.mean(np.abs(res) / np.maximum(y[valid], 1e-3)))
    rmse = float(np.sqrt(np.mean(res * res)))
    inlier = float(np.mean(np.abs(res) < np.maximum(1.0, 0.1 * y[valid])))
    return {'absrel': absrel, 'rmse': rmse, 'inlier': inlier, 'n': int(valid.sum())}


def score_metric(metric, fit_metric):
    if metric is None:
        return np.inf
    gap = 0.0 if fit_metric is None else abs(metric['absrel'] - fit_metric['absrel'])
    return metric['absrel'] - 0.10 * metric['inlier'] + 0.25 * gap


def trimmed_log_scale(x: np.ndarray, y: np.ndarray):
    ratio = y / np.maximum(x, 1e-3)
    ratio = ratio[np.isfinite(ratio) & (ratio > 0)]
    if ratio.size < 5:
        scale = 1.0
    else:
        lr = np.log(ratio)
        med = np.median(lr)
        mad = np.median(np.abs(lr - med))
        keep = np.abs(lr - med) < max(1.0, 2.5 * 1.4826 * mad)
        scale = float(np.exp(np.mean(lr[keep]))) if int(keep.sum()) >= 10 else float(np.exp(med))
    return {'method': 'trimmed_scale', 'params': {'scale': scale}, 'fn': lambda t: scale * t}


def median_log_scale(x: np.ndarray, y: np.ndarray):
    ratio = y / np.maximum(x, 1e-3)
    ratio = ratio[np.isfinite(ratio) & (ratio > 0)]
    scale = float(np.exp(np.median(np.log(ratio)))) if ratio.size else 1.0
    return {'method': 'median_scale', 'params': {'scale': scale}, 'fn': lambda t: scale * t}


def positive_affine(x: np.ndarray, y: np.ndarray):
    a_mat = np.stack([x, np.ones_like(x)], axis=1)
    try:
        coeff = np.linalg.lstsq(a_mat, y, rcond=None)[0]
        scale, shift = float(coeff[0]), float(coeff[1])
    except np.linalg.LinAlgError:
        return trimmed_log_scale(x, y)
    if not np.isfinite(scale) or scale <= 1e-6:
        return trimmed_log_scale(x, y)
    for _ in range(15):
        residual = scale * x + shift - y
        mad = np.median(np.abs(residual - np.median(residual)))
        sigma = max(1.4826 * mad, 1e-3)
        threshold = 1.345 * sigma
        w = np.minimum(1.0, threshold / (np.abs(residual) + 1e-6))
        sw = np.sqrt(w)
        try:
            coeff = np.linalg.lstsq(a_mat * sw[:, None], y * sw, rcond=None)[0]
            scale2, shift2 = float(coeff[0]), float(coeff[1])
        except np.linalg.LinAlgError:
            break
        if not np.isfinite(scale2) or scale2 <= 1e-6:
            break
        scale, shift = scale2, shift2
    return {'method': 'positive_affine', 'params': {'scale': scale, 'shift': shift}, 'fn': lambda t: scale * t + shift}


def power_law(x: np.ndarray, y: np.ndarray):
    valid = np.isfinite(x) & np.isfinite(y) & (x > 0.1) & (y > 0.1)
    if int(valid.sum()) < 20:
        return trimmed_log_scale(x, y)
    lx = np.log(x[valid])
    ly = np.log(y[valid])
    a_mat = np.stack([lx, np.ones_like(lx)], axis=1)
    try:
        coeff = np.linalg.lstsq(a_mat, ly, rcond=None)[0]
        beta, log_alpha = float(coeff[0]), float(coeff[1])
    except np.linalg.LinAlgError:
        return trimmed_log_scale(x, y)
    beta = float(np.clip(beta, 0.25, 3.0))
    log_alpha = float(np.clip(log_alpha, -5.0, 5.0))
    for _ in range(15):
        residual = beta * lx + log_alpha - ly
        mad = np.median(np.abs(residual - np.median(residual)))
        sigma = max(1.4826 * mad, 1e-3)
        threshold = 1.345 * sigma
        w = np.minimum(1.0, threshold / (np.abs(residual) + 1e-6))
        sw = np.sqrt(w)
        try:
            coeff = np.linalg.lstsq(a_mat * sw[:, None], ly * sw, rcond=None)[0]
            beta, log_alpha = float(coeff[0]), float(coeff[1])
        except np.linalg.LinAlgError:
            break
        beta = float(np.clip(beta, 0.25, 3.0))
        log_alpha = float(np.clip(log_alpha, -5.0, 5.0))
    alpha = float(np.exp(log_alpha))
    return {'method': 'power', 'params': {'alpha': alpha, 'beta': beta}, 'fn': lambda t: alpha * np.power(np.maximum(t, 1e-3), beta)}


def pava(values: np.ndarray, weights: np.ndarray) -> np.ndarray:
    vals, ws, starts, ends = [], [], [], []
    for idx, (value, weight) in enumerate(zip(values, weights)):
        vals.append(float(value)); ws.append(float(weight)); starts.append(idx); ends.append(idx)
        while len(vals) >= 2 and vals[-2] > vals[-1]:
            new_w = ws[-2] + ws[-1]
            new_v = (vals[-2] * ws[-2] + vals[-1] * ws[-1]) / new_w
            vals[-2] = new_v; ws[-2] = new_w; ends[-2] = ends[-1]
            vals.pop(); ws.pop(); starts.pop(); ends.pop()
    out = np.empty(len(values), dtype=np.float64)
    for value, start, end in zip(vals, starts, ends):
        out[start:end + 1] = value
    return out


def monotonic_bins(x: np.ndarray, y: np.ndarray, bins: int = 24):
    order = np.argsort(x)
    xs, ys = x[order], y[order]
    n = len(x)
    bx, by, bw = [], [], []
    for i in range(bins):
        lo = int(i * n / bins)
        hi = int((i + 1) * n / bins)
        if hi - lo < 15:
            continue
        xb, yb = xs[lo:hi], ys[lo:hi]
        bx.append(float(np.median(xb)))
        by.append(float(np.median(yb)))
        bw.append(float(hi - lo))
    if len(bx) < 5:
        return trimmed_log_scale(x, y)
    bx_arr = np.asarray(bx, dtype=np.float64)
    by_arr = pava(np.asarray(by, dtype=np.float64), np.asarray(bw, dtype=np.float64))
    bx_arr = np.concatenate([[max(0.01, float(np.min(x)))] , bx_arr, [float(np.max(x))]])
    by_arr = np.concatenate([[max(0.1, float(by_arr[0]))], by_arr, [max(float(by_arr[-1]), float(by_arr[-2]))]])
    return {
        'method': 'mono24',
        'params': {'bin_x': bx_arr.tolist(), 'bin_y': by_arr.tolist()},
        'fn': lambda t: np.interp(t, bx_arr, by_arr, left=by_arr[0], right=by_arr[-1])
    }


def choose_fit(row: dict, pred_depth: np.ndarray, pred_mask: np.ndarray, proj_depth: np.ndarray, proj_mask: np.ndarray):
    valid = pred_mask & proj_mask & np.isfinite(pred_depth) & np.isfinite(proj_depth) & (pred_depth > 0.1) & (proj_depth > 0.1) & (proj_depth < 120.0)
    yy, xx = np.where(valid)
    x = pred_depth[valid].astype(np.float64)
    y = proj_depth[valid].astype(np.float64)
    if len(x) < 40:
        return {'method': 'identity_unfit', 'params': {}, 'fn': lambda t: t, 'quality': 'low', 'cv': None, 'all': None, 'num_fit_points': int(len(x))}
    parity = int(hashlib.md5(row['sample_data_token'].encode()).hexdigest(), 16) % 2
    fit_mask = ((xx + yy + parity) % 2) == 0
    if int(fit_mask.sum()) < 20 or int((~fit_mask).sum()) < 20:
        fit_mask = (np.arange(len(x)) % 2) == 0
    xf, yf = x[fit_mask], y[fit_mask]
    xv, yv = x[~fit_mask], y[~fit_mask]
    candidates = [
        median_log_scale(xf, yf),
        trimmed_log_scale(xf, yf),
        positive_affine(xf, yf),
        power_law(xf, yf),
        monotonic_bins(xf, yf, 24),
    ]
    best = None
    for cand in candidates:
        cv = eval_pred(cand['fn'](xv), yv)
        fit = eval_pred(cand['fn'](xf), yf)
        cand_score = score_metric(cv, fit)
        if best is None or cand_score < best[0]:
            best = (cand_score, cand, cv, fit)
    _, cand, cv, fit = best
    all_metric = eval_pred(cand['fn'](x), y)
    quality = 'high' if cv and ((cv['absrel'] <= 0.35 and cv['inlier'] >= 0.25) or cv['absrel'] <= 0.22) else 'low'
    cand.update({'quality': quality, 'cv': cv, 'fit': fit, 'all': all_metric, 'num_fit_points': int(len(x))})
    return cand


def repair(output_root: Path, dry_run: bool):
    report = {'total_candidates': 0, 'rewritten': 0, 'high': 0, 'low': 0, 'by_method': Counter(), 'by_camera': Counter(), 'by_split': Counter()}
    detailed = []
    for split in ['train', 'val']:
        manifest_path = output_root / 'meta' / f'manifest_{split}.jsonl'
        rows = load_rows(manifest_path)
        changed = False
        for row in tqdm(rows, desc=f'repair {split}'):
            needs_repair = row.get('success', 1.0) == 0.0 or row.get('train_mask_coverage', 1.0) == 0.0
            if not needs_repair:
                continue
            report['total_candidates'] += 1
            pred = np.load(row['pred_depth_path'])
            proj = np.load(row['proj_depth_path'])
            pred_depth = pred['depth'].astype(np.float32)
            pred_mask = pred['mask'].astype(bool) if 'mask' in pred else np.isfinite(pred_depth) & (pred_depth > 0.0)
            proj_depth = proj['depth'].astype(np.float32)
            proj_mask = proj['mask'].astype(bool) if 'mask' in proj else np.isfinite(proj_depth) & (proj_depth > 0.0)
            fit = choose_fit(row, pred_depth, pred_mask, proj_depth, proj_mask)
            aligned = fit['fn'](pred_depth.astype(np.float64)).astype(np.float32)
            mask = pred_mask & np.isfinite(aligned) & (aligned > 0.1) & (aligned < 120.0)
            aligned_save = np.where(mask, aligned, 0.0).astype(np.float16)
            confidence = np.full(aligned_save.shape, 1.0 if fit['quality'] == 'high' else 0.25, dtype=np.float16)
            confidence[~mask] = 0.0
            old_align = np.load(row['align_depth_path'])
            intrinsics = old_align['intrinsics'].astype(np.float32) if 'intrinsics' in old_align else pred['intrinsics'].astype(np.float32)
            params_json = json.dumps(fit['params'], separators=(',', ':'))
            if not dry_run:
                atomic_npz(
                    Path(row['align_depth_path']),
                    depth=aligned_save,
                    mask=mask.astype(np.uint8),
                    confidence=confidence,
                    scale=np.asarray(fit['params'].get('scale', fit['params'].get('alpha', 1.0)), dtype=np.float32),
                    shift=np.asarray(fit['params'].get('shift', 0.0), dtype=np.float32),
                    fit_absrel=np.asarray(fit['all']['absrel'] if fit['all'] else np.nan, dtype=np.float32),
                    fit_rmse=np.asarray(fit['all']['rmse'] if fit['all'] else np.nan, dtype=np.float32),
                    fit_inlier_ratio=np.asarray(fit['all']['inlier'] if fit['all'] else np.nan, dtype=np.float32),
                    intrinsics=intrinsics,
                    repair_quality=np.asarray(1 if fit['quality'] == 'high' else 0, dtype=np.uint8),
                    repair_method=np.asarray(fit['method']),
                    repair_params_json=np.asarray(params_json),
                    repair_cv_absrel=np.asarray(fit['cv']['absrel'] if fit['cv'] else np.nan, dtype=np.float32),
                    repair_cv_rmse=np.asarray(fit['cv']['rmse'] if fit['cv'] else np.nan, dtype=np.float32),
                    repair_cv_inlier_ratio=np.asarray(fit['cv']['inlier'] if fit['cv'] else np.nan, dtype=np.float32),
                )
            row['original_success_before_repair'] = row.get('success')
            row['original_fit_absrel_before_repair'] = row.get('fit_absrel')
            row['success'] = 1.0
            row['repair_applied'] = True
            row['repair_quality'] = fit['quality']
            row['repair_method'] = fit['method']
            row['repair_params'] = fit['params']
            row['repair_cv_absrel'] = None if fit['cv'] is None else fit['cv']['absrel']
            row['repair_cv_rmse'] = None if fit['cv'] is None else fit['cv']['rmse']
            row['repair_cv_inlier_ratio'] = None if fit['cv'] is None else fit['cv']['inlier']
            row['num_fit_points'] = float(fit['num_fit_points'])
            if fit['all'] is not None:
                row['fit_absrel'] = fit['all']['absrel']
                row['fit_rmse'] = fit['all']['rmse']
                row['fit_inlier_ratio'] = fit['all']['inlier']
            row['train_mask_coverage'] = float(mask.mean())
            changed = True
            report['rewritten'] += 1
            report[fit['quality']] += 1
            report['by_method'][fit['method']] += 1
            report['by_camera'][row['camera']] += 1
            report['by_split'][split] += 1
            detailed.append({
                'split': split,
                'sample_data_token': row['sample_data_token'],
                'camera': row['camera'],
                'quality': fit['quality'],
                'method': fit['method'],
                'cv': fit['cv'],
                'all': fit['all'],
                'mask_coverage': float(mask.mean()),
                'align_depth_path': row['align_depth_path'],
            })
        if changed and not dry_run:
            backup = manifest_path.with_suffix(manifest_path.suffix + '.before_repair')
            if not backup.exists():
                manifest_path.replace(backup)
            else:
                # If rerun, keep the first backup and overwrite manifest only.
                pass
            with manifest_path.open('w') as f:
                for row in rows:
                    f.write(json.dumps(row, ensure_ascii=False) + '\n')
    report_out = {
        'total_candidates': report['total_candidates'],
        'rewritten': report['rewritten'],
        'high': report['high'],
        'low': report['low'],
        'by_method': dict(report['by_method']),
        'by_camera': dict(report['by_camera']),
        'by_split': dict(report['by_split']),
    }
    if not dry_run:
        report_path = output_root / 'meta' / 'repair_failed_alignments_report.json'
        detail_path = output_root / 'meta' / 'repair_failed_alignments_detail.jsonl'
        report_path.write_text(json.dumps(report_out, indent=2, ensure_ascii=False), encoding='utf-8')
        with detail_path.open('w') as f:
            for item in detailed:
                f.write(json.dumps(item, ensure_ascii=False) + '\n')
    print(json.dumps(report_out, indent=2, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    repair(args.output_root, args.dry_run)


if __name__ == '__main__':
    main()
