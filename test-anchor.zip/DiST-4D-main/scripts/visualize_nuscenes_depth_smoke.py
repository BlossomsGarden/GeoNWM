#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import matplotlib
import numpy as np
from PIL import Image, ImageDraw


def colorize_depth(depth: np.ndarray, mask: np.ndarray) -> Image.Image:
    depth = depth.astype(np.float32)
    valid = (mask > 0) & np.isfinite(depth) & (depth > 0)
    normalized = np.zeros(depth.shape, dtype=np.float32)
    if np.any(valid):
        near, far = np.percentile(depth[valid], [2, 98])
        if far <= near:
            far = near + 1e-6
        normalized = np.clip((depth - near) / (far - near), 0.0, 1.0)

    rgb = (matplotlib.colormaps["turbo"](normalized)[..., :3] * 255).astype(np.uint8)
    rgb[~valid] = 0
    return Image.fromarray(rgb)


def load_manifest_rows(output_root: Path) -> list[dict]:
    rows = []
    meta = output_root / "meta"
    for manifest in sorted(meta.glob("manifest_*.jsonl")):
        with manifest.open("r") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
    return rows


def make_pair(rgb_path: Path, depth_png_path: Path, out_path: Path) -> None:
    rgb = Image.open(rgb_path).convert("RGB")
    depth = Image.open(depth_png_path).convert("RGB").resize(rgb.size, Image.BILINEAR)
    canvas = Image.new("RGB", (rgb.width * 2, rgb.height + 30), "white")
    canvas.paste(rgb, (0, 30))
    canvas.paste(depth, (rgb.width, 30))
    draw = ImageDraw.Draw(canvas)
    draw.text((8, 8), "832x480 RGB", fill=(0, 0, 0))
    draw.text((rgb.width + 8, 8), "estimated aligned depth", fill=(0, 0, 0))
    canvas.save(out_path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("/data/wlh/MoGe-2/nuscenes_depth_smoke_832x480"),
    )
    parser.add_argument("--num-samples", type=int, default=2)
    args = parser.parse_args()

    preview_dir = args.output_root / "preview"
    preview_dir.mkdir(parents=True, exist_ok=True)

    rows = load_manifest_rows(args.output_root)
    if len(rows) < args.num_samples:
        raise RuntimeError(f"Only found {len(rows)} manifest rows in {args.output_root}")

    summary = []
    for idx, row in enumerate(rows[: args.num_samples]):
        image_path = Path(row["image_path"])
        depth_npz_path = Path(row["align_depth_path"])
        stem = f"{idx:02d}_{row['split']}_{Path(row['image_path']).stem}"
        rgb_out = preview_dir / f"{stem}.jpg"
        depth_png_out = preview_dir / f"{stem}_depth.png"
        pair_out = preview_dir / f"{stem}_pair.png"

        shutil.copy2(image_path, rgb_out)
        data = np.load(depth_npz_path)
        depth = data["depth"]
        mask = data["mask"] if "mask" in data.files else np.ones(depth.shape, dtype=np.uint8)
        colorize_depth(depth, mask).save(depth_png_out)
        make_pair(rgb_out, depth_png_out, pair_out)

        intr = data["intrinsics"].astype(float)
        summary.append(
            {
                "split": row["split"],
                "image": str(rgb_out),
                "depth_npz": str(depth_npz_path),
                "depth_png": str(depth_png_out),
                "pair_png": str(pair_out),
                "depth_shape": list(depth.shape),
                "intrinsics": intr.tolist(),
                "original_width": row["original_width"],
                "original_height": row["original_height"],
                "width": row["width"],
                "height": row["height"],
            }
        )

    summary_path = preview_dir / "preview_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
