#!/usr/bin/env python3
"""Generate LiDAR-aligned MoGe-2 depth for an OmniRe/Waymo processed scene.

The script keeps each RGB image at its original resolution: no resize and no
crop are applied before MoGe inference or LiDAR projection.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import time
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import cv2
import numpy as np
import torch
from tqdm import tqdm


OPENCV2DATASET = np.array(
    [[0, 0, 1, 0], [-1, 0, 0, 0], [0, -1, 0, 0], [0, 0, 0, 1]],
    dtype=np.float64,
)


def fov_x_from_intrinsics(k: np.ndarray, width: int) -> float:
    fx = float(k[0, 0])
    return math.degrees(2.0 * math.atan(width / (2.0 * fx)))


def atomic_save_npz(path: Path, compress: bool, **arrays) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    if compress:
        np.savez_compressed(str(tmp), **arrays)
    else:
        np.savez(str(tmp), **arrays)
    actual_tmp = Path(str(tmp) + ".npz")
    if actual_tmp.exists() and actual_tmp != tmp:
        actual_tmp.replace(path)
    else:
        tmp.replace(path)


def load_waymo_intrinsics(scene_root: Path, cam_id: int) -> Tuple[np.ndarray, np.ndarray]:
    raw = np.loadtxt(scene_root / "intrinsics" / f"{cam_id}.txt").astype(np.float64)
    if raw.shape != (9,):
        raise ValueError(f"Expected 9 Waymo intrinsics values for camera {cam_id}, got {raw.shape}")
    fx, fy, cx, cy = raw[:4]
    k = np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64)
    distortion = raw[4:].astype(np.float64)
    return k, distortion


def load_waymo_camera_to_vehicle(scene_root: Path, cam_id: int) -> np.ndarray:
    extrinsic = np.loadtxt(scene_root / "extrinsics" / f"{cam_id}.txt").astype(np.float64)
    if extrinsic.shape != (4, 4):
        raise ValueError(f"Expected 4x4 extrinsic for camera {cam_id}, got {extrinsic.shape}")
    # The processed Waymo extrinsic maps Waymo camera coordinates to vehicle.
    # MoGe/LiDAR projection below uses OpenCV camera coordinates
    # (x right, y down, z forward), matching OmniRe's camera loader.
    return extrinsic @ OPENCV2DATASET


def read_waymo_lidar_points(path: Path) -> np.ndarray:
    raw = np.fromfile(str(path), dtype=np.float32)
    if raw.size % 14 != 0:
        raise ValueError(f"Unexpected Waymo lidar shape in {path}: {raw.size} floats")
    lidar_info = raw.reshape(-1, 14)
    return lidar_info[:, 3:6].astype(np.float64)


def project_lidar_to_camera_depth(
    lidar_path: Path,
    vehicle_to_camera: np.ndarray,
    intrinsics: np.ndarray,
    image_hw: Tuple[int, int],
    min_depth: float,
    max_depth: float,
) -> Tuple[np.ndarray, int]:
    height, width = image_hw
    points = read_waymo_lidar_points(lidar_path)
    if points.size == 0:
        return np.zeros((height, width), dtype=np.float32), 0

    points_h = np.concatenate([points, np.ones((points.shape[0], 1), dtype=np.float64)], axis=1).T
    cam_points = (vehicle_to_camera @ points_h)[:3]
    z = cam_points[2]
    valid = (z > min_depth) & (z < max_depth)
    if not np.any(valid):
        return np.zeros((height, width), dtype=np.float32), 0

    cam_points = cam_points[:, valid]
    z = z[valid]
    u = intrinsics[0, 0] * cam_points[0] / z + intrinsics[0, 2]
    v = intrinsics[1, 1] * cam_points[1] / z + intrinsics[1, 2]
    inside = (u >= 0) & (u < width) & (v >= 0) & (v < height)
    if not np.any(inside):
        return np.zeros((height, width), dtype=np.float32), 0

    u_i = np.floor(u[inside]).astype(np.int64)
    v_i = np.floor(v[inside]).astype(np.int64)
    z_i = z[inside].astype(np.float32)
    flat = v_i * width + u_i

    depth_flat = np.full(height * width, np.inf, dtype=np.float32)
    np.minimum.at(depth_flat, flat, z_i)
    depth = depth_flat.reshape(height, width)
    depth[~np.isfinite(depth)] = 0.0
    return depth, int(np.count_nonzero(depth > 0))


def robust_scale_shift_fit(
    pred: np.ndarray,
    target: np.ndarray,
    min_points: int,
    huber_k: float,
    max_iters: int,
) -> Tuple[float, float, Dict[str, float]]:
    valid = np.isfinite(pred) & np.isfinite(target) & (target > 0) & (pred > 0)
    x = pred[valid].astype(np.float64)
    y = target[valid].astype(np.float64)
    n = int(x.size)
    if n < min_points:
        return 1.0, 0.0, {"success": 0.0, "num_fit_points": float(n)}

    a = np.vstack([x, np.ones_like(x)]).T
    try:
        coeff, *_ = np.linalg.lstsq(a, y, rcond=None)
    except np.linalg.LinAlgError:
        return 1.0, 0.0, {"success": 0.0, "num_fit_points": float(n)}

    weights = np.ones_like(y, dtype=np.float64)
    for _ in range(max_iters):
        residual = coeff[0] * x + coeff[1] - y
        mad = np.median(np.abs(residual - np.median(residual)))
        sigma = max(1.4826 * mad, 1e-3)
        threshold = huber_k * sigma
        weights = np.minimum(1.0, threshold / (np.abs(residual) + 1e-6))
        aw = a * np.sqrt(weights[:, None])
        yw = y * np.sqrt(weights)
        try:
            coeff, *_ = np.linalg.lstsq(aw, yw, rcond=None)
        except np.linalg.LinAlgError:
            break

    scale, shift = float(coeff[0]), float(coeff[1])
    aligned_samples = scale * x + shift
    residual = aligned_samples - y
    abs_rel = float(np.mean(np.abs(residual) / np.maximum(y, 1e-3)))
    rmse = float(np.sqrt(np.mean(residual * residual)))
    inlier = np.abs(residual) < np.maximum(1.0, 0.1 * y)
    inlier_ratio = float(np.mean(inlier))

    success = float(np.isfinite(scale) and np.isfinite(shift) and scale > 0.0)
    return scale, shift, {
        "success": success,
        "num_fit_points": float(n),
        "scale": scale,
        "shift": shift,
        "fit_absrel": abs_rel,
        "fit_rmse": rmse,
        "fit_inlier_ratio": inlier_ratio,
        "fit_weight_mean": float(np.mean(weights)),
    }


def collect_images(scene_root: Path, camera_ids: Iterable[int]) -> List[Path]:
    camera_set = {str(cam_id) for cam_id in camera_ids}
    pattern = re.compile(r"^(\d+)_(\d+)\.jpg$")
    images = []
    for path in (scene_root / "images").glob("*.jpg"):
        match = pattern.match(path.name)
        if match and match.group(2) in camera_set:
            images.append(path)
    return sorted(images, key=lambda p: (int(p.stem.split("_")[0]), int(p.stem.split("_")[1])))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--scene-root",
        type=Path,
        default=Path("/data/wlh/OmniRe/data/waymo/processed/training/089"),
    )
    parser.add_argument("--model-path", type=Path, default=Path("/data/wlh/MoGe-2/model/moge-2-vitl"))
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--cameras", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--use-fp16", action="store_true", default=True)
    parser.add_argument("--no-fp16", dest="use_fp16", action="store_false")
    parser.add_argument("--resolution-level", type=int, default=9)
    parser.add_argument("--num-tokens", type=int, default=None)
    parser.add_argument("--min-depth", type=float, default=0.1)
    parser.add_argument("--max-depth", type=float, default=120.0)
    parser.add_argument("--min-fit-points", type=int, default=20)
    parser.add_argument("--huber-k", type=float, default=1.5)
    parser.add_argument("--fit-iters", type=int, default=8)
    parser.add_argument("--skip-existing", action="store_true")
    parser.add_argument("--compress", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--manifest-every", type=int, default=1)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scene_root = args.scene_root
    output_dir = args.output_dir if args.output_dir is not None else scene_root / "depth"
    meta_dir = output_dir / "meta"
    output_dir.mkdir(parents=True, exist_ok=True)
    meta_dir.mkdir(parents=True, exist_ok=True)

    image_paths = collect_images(scene_root, args.cameras)
    if args.start_index:
        image_paths = image_paths[args.start_index :]
    if args.limit is not None:
        image_paths = image_paths[: args.limit]
    if not image_paths:
        raise RuntimeError(f"No images found under {scene_root / 'images'} for cameras {args.cameras}")

    intrinsics_by_cam: Dict[int, np.ndarray] = {}
    distortion_by_cam: Dict[int, np.ndarray] = {}
    vehicle_to_camera_by_cam: Dict[int, np.ndarray] = {}
    camera_to_vehicle_by_cam: Dict[int, np.ndarray] = {}
    for cam_id in args.cameras:
        intrinsics, distortion = load_waymo_intrinsics(scene_root, cam_id)
        camera_to_vehicle = load_waymo_camera_to_vehicle(scene_root, cam_id)
        intrinsics_by_cam[cam_id] = intrinsics
        distortion_by_cam[cam_id] = distortion
        camera_to_vehicle_by_cam[cam_id] = camera_to_vehicle
        vehicle_to_camera_by_cam[cam_id] = np.linalg.inv(camera_to_vehicle)

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    checkpoint_path = args.model_path / "model.pt" if args.model_path.is_dir() else args.model_path
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"MoGe checkpoint not found: {checkpoint_path}")

    from moge.model.v2 import MoGeModel

    model = MoGeModel.from_pretrained(checkpoint_path).to(device).eval()
    if args.use_fp16 and device.type == "cuda":
        model.half()

    run_config_path = meta_dir / f"run_config_{int(time.time())}.json"
    manifest_path = meta_dir / "manifest.jsonl"
    with run_config_path.open("w") as f:
        json.dump(
            {
                "scene_root": str(scene_root),
                "model_path": str(args.model_path),
                "checkpoint_path": str(checkpoint_path),
                "output_dir": str(output_dir),
                "cameras": args.cameras,
                "num_items": len(image_paths),
                "image_transform": "none",
                "use_fp16": args.use_fp16,
                "resolution_level": args.resolution_level,
                "num_tokens": args.num_tokens,
                "min_depth": args.min_depth,
                "max_depth": args.max_depth,
                "min_fit_points": args.min_fit_points,
                "huber_k": args.huber_k,
                "fit_iters": args.fit_iters,
                "torch": torch.__version__,
                "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
            },
            f,
            indent=2,
        )

    processed = 0
    skipped = 0
    failures = 0
    fit_failures = 0

    with manifest_path.open("a") as manifest:
        for idx, image_path in enumerate(tqdm(image_paths, desc="Waymo MoGe-2 depth")):
            frame_id_str, cam_id_str = image_path.stem.split("_")
            frame_id = int(frame_id_str)
            cam_id = int(cam_id_str)
            out_path = output_dir / f"{image_path.stem}.npz"
            if args.skip_existing and out_path.exists():
                skipped += 1
                continue

            try:
                image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
                if image_bgr is None:
                    raise FileNotFoundError(f"Failed to read image: {image_path}")
                height, width = image_bgr.shape[:2]

                intrinsics = intrinsics_by_cam[cam_id]
                fov_x = fov_x_from_intrinsics(intrinsics, width)

                image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
                image_tensor = (
                    torch.from_numpy(image_rgb).to(device=device, dtype=torch.float32).permute(2, 0, 1)
                    / 255.0
                )

                output = model.infer(
                    image_tensor,
                    fov_x=fov_x,
                    resolution_level=args.resolution_level,
                    num_tokens=args.num_tokens,
                    use_fp16=args.use_fp16 and device.type == "cuda",
                    apply_mask=False,
                )
                pred_depth = output["depth"].detach().float().cpu().numpy().astype(np.float32)
                if pred_depth.shape != (height, width):
                    raise RuntimeError(
                        f"MoGe returned depth shape {pred_depth.shape}, expected {(height, width)} for {image_path}"
                    )
                pred_mask = output.get("mask")
                if pred_mask is None:
                    pred_mask_np = np.isfinite(pred_depth)
                else:
                    pred_mask_np = pred_mask.detach().cpu().numpy().astype(bool)
                pred_depth[~np.isfinite(pred_depth)] = 0.0

                lidar_path = scene_root / "lidar" / f"{frame_id:03d}.bin"
                proj_depth, num_lidar_points = project_lidar_to_camera_depth(
                    lidar_path,
                    vehicle_to_camera_by_cam[cam_id],
                    intrinsics,
                    (height, width),
                    args.min_depth,
                    args.max_depth,
                )

                scale, shift, fit_stats = robust_scale_shift_fit(
                    pred_depth,
                    proj_depth,
                    args.min_fit_points,
                    args.huber_k,
                    args.fit_iters,
                )
                aligned = (scale * pred_depth + shift).astype(np.float32)
                depth_mask = (
                    pred_mask_np
                    & np.isfinite(aligned)
                    & (aligned > args.min_depth)
                    & (aligned < args.max_depth)
                    & (fit_stats.get("success", 0.0) > 0.0)
                )
                if fit_stats.get("success", 0.0) <= 0.0:
                    fit_failures += 1
                depth = np.where(depth_mask, aligned, 0.0).astype(np.float32)

                atomic_save_npz(
                    out_path,
                    args.compress,
                    depth=depth,
                    mask=depth_mask.astype(np.uint8),
                    scale=np.asarray(scale, dtype=np.float32),
                    shift=np.asarray(shift, dtype=np.float32),
                    fit_absrel=np.asarray(fit_stats.get("fit_absrel", np.nan), dtype=np.float32),
                    fit_rmse=np.asarray(fit_stats.get("fit_rmse", np.nan), dtype=np.float32),
                    fit_inlier_ratio=np.asarray(
                        fit_stats.get("fit_inlier_ratio", np.nan), dtype=np.float32
                    ),
                    num_lidar_points=np.asarray(num_lidar_points, dtype=np.int32),
                    intrinsics=intrinsics.astype(np.float32),
                    distortion=distortion_by_cam[cam_id].astype(np.float32),
                    camera_to_vehicle=camera_to_vehicle_by_cam[cam_id].astype(np.float32),
                )

                if idx % args.manifest_every == 0:
                    row = {
                        "index": args.start_index + idx,
                        "frame": frame_id,
                        "camera": cam_id,
                        "image_path": str(image_path),
                        "lidar_path": str(lidar_path),
                        "depth_path": str(out_path),
                        "height": height,
                        "width": width,
                        "image_transform": "none",
                        "fov_x_deg": fov_x,
                        "num_lidar_points": num_lidar_points,
                        "mask_coverage": float(np.mean(depth_mask)),
                        "model": "Ruicheng/moge-2-vitl",
                        "checkpoint_path": str(checkpoint_path),
                    }
                    row.update({k: float(v) for k, v in fit_stats.items()})
                    manifest.write(json.dumps(row, ensure_ascii=False) + "\n")
                    manifest.flush()

                processed += 1
                del image_tensor, output
                if device.type == "cuda":
                    torch.cuda.empty_cache()
            except Exception as exc:  # noqa: BLE001 - long-running annotation should continue.
                failures += 1
                err_path = meta_dir / "errors.jsonl"
                with err_path.open("a") as ef:
                    ef.write(
                        json.dumps(
                            {
                                "index": args.start_index + idx,
                                "image_path": str(image_path),
                                "error": repr(exc),
                            },
                            ensure_ascii=False,
                        )
                        + "\n"
                    )

    summary = {
        "processed": processed,
        "skipped": skipped,
        "failures": failures,
        "fit_failures": fit_failures,
        "manifest": str(manifest_path),
        "output_dir": str(output_dir),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
