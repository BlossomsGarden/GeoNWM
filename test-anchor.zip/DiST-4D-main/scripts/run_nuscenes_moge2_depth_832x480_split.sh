#!/usr/bin/env bash
set -eo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 train|val" >&2
  exit 2
fi

SPLIT="$1"
if [[ "$SPLIT" != "train" && "$SPLIT" != "val" ]]; then
  echo "Invalid split: $SPLIT" >&2
  exit 2
fi

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate moge

export PYTHONPATH=/data/wlh/MoGe-2/code/MoGe:${PYTHONPATH:-}

ROOT=/data2/DATA/AutoDrive/nuscenes/v1.0-trainval
MODEL=/data/wlh/MoGe-2/model/moge-2-vitl
OUT=/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16
SCRIPT=/data/wlh/MoGe-2/scripts/generate_nuscenes_moge2_depth.py

python "$SCRIPT" \
  --nuscenes-root "$ROOT" \
  --model-path "$MODEL" \
  --output-root "$OUT" \
  --height 480 \
  --width 832 \
  --image-transform resize \
  --camera all \
  --split "$SPLIT" \
  --manifest-every 1
