#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate moge

export PYTHONPATH=/data/wlh/MoGe-2/code/MoGe:${PYTHONPATH:-}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-6}

ROOT=/data2/DATA/AutoDrive/nuscenes/v1.0-trainval
MODEL=/data/wlh/MoGe-2/model/moge-2-vitl
OUT=/data/wlh/MoGe-2/nuscenes_depth_smoke_832x480
SCRIPT=/data/wlh/MoGe-2/scripts/generate_nuscenes_moge2_depth.py

COMMON=(
  --nuscenes-root "$ROOT"
  --model-path "$MODEL"
  --output-root "$OUT"
  --height 480
  --width 832
  --image-transform resize
  --camera CAM_FRONT
  --limit 1
  --manifest-every 1
)

python "$SCRIPT" "${COMMON[@]}" --split train
python "$SCRIPT" "${COMMON[@]}" --split val
