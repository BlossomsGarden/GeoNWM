#!/usr/bin/env bash
set -eo pipefail

OUT=/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16
LOG_DIR=/data/wlh/MoGe-2/logs/nuscenes_moge2_depth_832x480_full
RUN_SCRIPT=/data/wlh/MoGe-2/scripts/run_nuscenes_moge2_depth_832x480_split.sh

mkdir -p "$LOG_DIR"
rm -rf "$OUT"
mkdir -p "$OUT"

date +%Y-%m-%dT%H:%M:%S > "$LOG_DIR/launch_time.txt"
echo "$OUT" > "$LOG_DIR/output_root.txt"

CUDA_VISIBLE_DEVICES=6 nohup bash "$RUN_SCRIPT" train \
  > "$LOG_DIR/train_cuda6.log" 2>&1 &
echo $! > "$LOG_DIR/train.pid"

CUDA_VISIBLE_DEVICES=7 nohup bash "$RUN_SCRIPT" val \
  > "$LOG_DIR/val_cuda7.log" 2>&1 &
echo $! > "$LOG_DIR/val.pid"

echo "train_pid=$(cat "$LOG_DIR/train.pid")"
echo "val_pid=$(cat "$LOG_DIR/val.pid")"
echo "log_dir=$LOG_DIR"
echo "output_root=$OUT"
