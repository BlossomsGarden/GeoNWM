#!/usr/bin/env bash
set -eo pipefail
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate moge
export PYTHONPATH=/data/wlh/MoGe-2/code/MoGe:${PYTHONPATH:-}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-3}
ROOT=/data2/DATA/AutoDrive/nuscenes/v1.0-trainval
MODEL=/data/wlh/MoGe-2/model/moge-2-vitl
OUT=/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_dvgtcrop_256x704_fp16
SCRIPT=/data/wlh/MoGe-2/scripts/generate_nuscenes_moge2_depth.py
COMMON=(
  --nuscenes-root "$ROOT"
  --model-path "$MODEL"
  --output-root "$OUT"
  --height 256
  --width 704
  --image-transform dvgt_resize_crop
  --camera all
  --skip-existing
)
python "$SCRIPT" "${COMMON[@]}" --split train
python "$SCRIPT" "${COMMON[@]}" --split val
