#!/usr/bin/env bash
set -eo pipefail

source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate moge

export PYTHONPATH=/data/wlh/MoGe-2/code/MoGe:${PYTHONPATH:-}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-2}

SCENE=/data/wlh/OmniRe/data/waymo/processed/training/089
MODEL=/data/wlh/MoGe-2/model/moge-2-vitl
SCRIPT=/data/wlh/MoGe-2/scripts/generate_waymo_moge2_depth.py

python "$SCRIPT" \
  --scene-root "$SCENE" \
  --model-path "$MODEL" \
  --output-dir "$SCENE/depth" \
  --cameras 0 1 2 \
  --resolution-level 9 \
  --manifest-every 1 \
  --skip-existing
