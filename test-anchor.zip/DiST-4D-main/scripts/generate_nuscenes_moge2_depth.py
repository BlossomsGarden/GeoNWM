#!/usr/bin/env python3
"""Generate MoGe-2 dense depth supervision for nuScenes.

The output intentionally follows the DriveTok/DVGT-style annotation flow:
DVGT-style image preprocessing -> MoGe dense prediction -> LiDAR projected
sparse metric depth -> robust scale/shift alignment -> fp16 training target.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import cv2
import numpy as np
import torch
from PIL import Image
from tqdm import tqdm


CAMERA_ORDER = (
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_FRONT_LEFT",
)


def load_json(path: Path):
    with path.open("r") as f:
        return json.load(f)


def quaternion_to_rotation(q: Iterable[float]) -> np.ndarray:
    w, x, y, z = [float(v) for v in q]
    n = w * w + x * x + y * y + z * z
    if n < 1e-12:
        return np.eye(3, dtype=np.float64)
    s = 2.0 / n
    wx, wy, wz = s * w * x, s * w * y, s * w * z
    xx, xy, xz = s * x * x, s * x * y, s * x * z
    yy, yz, zz = s * y * y, s * y * z, s * z * z
    return np.array(
        [
            [1.0 - (yy + zz), xy - wz, xz + wy],
            [xy + wz, 1.0 - (xx + zz), yz - wx],
            [xz - wy, yz + wx, 1.0 - (xx + yy)],
        ],
        dtype=np.float64,
    )


def transform_matrix(translation: Iterable[float], rotation: Iterable[float]) -> np.ndarray:
    mat = np.eye(4, dtype=np.float64)
    mat[:3, :3] = quaternion_to_rotation(rotation)
    mat[:3, 3] = np.asarray(translation, dtype=np.float64)
    return mat


def principal_point_crop(
    width: int,
    height: int,
    intrinsics: np.ndarray,
    target_width: int,
    target_height: int,
    *,
    strict: bool,
) -> Tuple[int, int, int, int, np.ndarray]:
    """Match Stage1/Stage2 principal-point crop geometry."""
    intr = intrinsics.copy()
    cx = float(intr[0, 2])
    cy = float(intr[1, 2])
    if strict:
        crop_w = int(target_width)
        crop_h = int(target_height)
        start_x = int(math.floor(cx - crop_w / 2.0))
        start_y = int(math.floor(cy - crop_h / 2.0))
        start_x = max(0, min(start_x, width - crop_w))
        start_y = max(0, min(start_y, height - crop_h))
    else:
        half_x = min(target_width / 2.0, cx, width - cx)
        half_y = min(target_height / 2.0, cy, height - cy)
        crop_w = max(1, min(width, 2 * int(math.floor(half_x))))
        crop_h = max(1, min(height, 2 * int(math.floor(half_y))))
        start_x = int(math.floor(cx) - crop_w // 2)
        start_y = int(math.floor(cy) - crop_h // 2)
        start_x = max(0, min(start_x, width - crop_w))
        start_y = max(0, min(start_y, height - crop_h))
    intr[0, 2] -= float(start_x)
    intr[1, 2] -= float(start_y)
    return start_x, start_y, crop_w, crop_h, intr


def process_image_and_intrinsics(
    image_bgr: np.ndarray,
    k: np.ndarray,
    target_hw: Tuple[int, int],
    mode: str,
    safe_bound: int = 4,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, float]]:
    """Process image and intrinsics atomically so RGB/depth geometry stays aligned."""
    target_h, target_w = target_hw
    orig_h, orig_w = image_bgr.shape[:2]
    k_new = k.astype(np.float32, copy=True)

    if mode == "resize":
        sx = target_w / float(orig_w)
        sy = target_h / float(orig_h)
        image_proc = cv2.resize(image_bgr, (target_w, target_h), interpolation=cv2.INTER_AREA)
        k_new[0, :] *= sx
        k_new[1, :] *= sy
        return image_proc, k_new, {
            "mode": mode,
            "scale_x": sx,
            "scale_y": sy,
            "resize_width": float(target_w),
            "resize_height": float(target_h),
            "crop_left": 0.0,
            "crop_top": 0.0,
        }

    if mode not in {"dvgt_resize_crop", "resize_crop"}:
        raise ValueError(f"Unsupported image transform mode: {mode}")

    pre_x, pre_y, pre_w, pre_h, k_new = principal_point_crop(
        orig_w,
        orig_h,
        k_new,
        orig_w,
        orig_h,
        strict=False,
    )
    image = Image.fromarray(image_bgr)
    if pre_x or pre_y or pre_w != orig_w or pre_h != orig_h:
        image = image.crop((pre_x, pre_y, pre_x + pre_w, pre_y + pre_h))

    resize_scale = max(
        (float(target_w) + float(safe_bound)) / float(pre_w),
        (float(target_h) + float(safe_bound)) / float(pre_h),
    )
    resized_w = max(target_w, int(math.floor(pre_w * resize_scale)))
    resized_h = max(target_h, int(math.floor(pre_h * resize_scale)))
    resample = Image.Resampling.LANCZOS if resize_scale < 1.0 else Image.Resampling.BICUBIC
    image = image.resize((resized_w, resized_h), resample=resample)

    scale_x = resized_w / float(pre_w)
    scale_y = resized_h / float(pre_h)
    k_new[0, 2] += 0.5
    k_new[1, 2] += 0.5
    k_new[0, 0] *= scale_x
    k_new[1, 1] *= scale_y
    k_new[0, 2] *= scale_x
    k_new[1, 2] *= scale_y
    k_new[0, 2] -= 0.5
    k_new[1, 2] -= 0.5

    final_x, final_y, crop_w, crop_h, k_new = principal_point_crop(
        resized_w,
        resized_h,
        k_new,
        target_w,
        target_h,
        strict=True,
    )
    if crop_w != target_w or crop_h != target_h:
        raise RuntimeError(f"Invalid final crop {(crop_w, crop_h)} for target {(target_w, target_h)}")
    image = image.crop((final_x, final_y, final_x + target_w, final_y + target_h))
    image_proc = np.asarray(image)
    return image_proc, k_new, {
        "mode": "dvgt_resize_crop",
        "requested_mode": mode,
        "safe_bound": float(safe_bound),
        "pixel_center": 1.0,
        "pre_crop_left": float(pre_x),
        "pre_crop_top": float(pre_y),
        "pre_crop_width": float(pre_w),
        "pre_crop_height": float(pre_h),
        "scale_x": float(scale_x),
        "scale_y": float(scale_y),
        "resize_width": float(resized_w),
        "resize_height": float(resized_h),
        "crop_left": float(final_x),
        "crop_top": float(final_y),
        "target_width": float(target_w),
        "target_height": float(target_h),
    }


def fov_x_from_intrinsics(k: np.ndarray, width: int) -> float:
    fx = float(k[0, 0])
    return math.degrees(2.0 * math.atan(width / (2.0 * fx)))


def read_lidar_points(path: Path) -> np.ndarray:
    raw = np.fromfile(str(path), dtype=np.float32)
    if raw.size % 5 != 0:
        raise ValueError(f"Unexpected nuScenes lidar shape in {path}: {raw.size}")
    return raw.reshape(-1, 5)[:, :3].astype(np.float64)


def project_lidar_to_camera_depth(
    lidar_path: Path,
    lidar_sd: dict,
    cam_sd: dict,
    calibrated: Dict[str, dict],
    ego_pose: Dict[str, dict],
    k_new: np.ndarray,
    target_hw: Tuple[int, int],
    min_depth: float,
    max_depth: float,
) -> Tuple[np.ndarray, int]:
    target_h, target_w = target_hw
    points = read_lidar_points(lidar_path)
    if points.size == 0:
        return np.zeros((target_h, target_w), dtype=np.float32), 0

    points_h = np.concatenate([points, np.ones((points.shape[0], 1), dtype=np.float64)], axis=1).T

    lidar_calib = calibrated[lidar_sd["calibrated_sensor_token"]]
    lidar_pose = ego_pose[lidar_sd["ego_pose_token"]]
    cam_calib = calibrated[cam_sd["calibrated_sensor_token"]]
    cam_pose = ego_pose[cam_sd["ego_pose_token"]]

    t_ego_from_lidar = transform_matrix(lidar_calib["translation"], lidar_calib["rotation"])
    t_global_from_ego_lidar = transform_matrix(lidar_pose["translation"], lidar_pose["rotation"])
    t_global_from_ego_cam = transform_matrix(cam_pose["translation"], cam_pose["rotation"])
    t_ego_from_cam = transform_matrix(cam_calib["translation"], cam_calib["rotation"])

    t_cam_from_lidar = (
        np.linalg.inv(t_ego_from_cam)
        @ np.linalg.inv(t_global_from_ego_cam)
        @ t_global_from_ego_lidar
        @ t_ego_from_lidar
    )
    cam_points = (t_cam_from_lidar @ points_h)[:3]
    z = cam_points[2]
    valid = (z > min_depth) & (z < max_depth)
    if not np.any(valid):
        return np.zeros((target_h, target_w), dtype=np.float32), 0

    cam_points = cam_points[:, valid]
    z = z[valid]
    u = k_new[0, 0] * cam_points[0] / z + k_new[0, 2]
    v = k_new[1, 1] * cam_points[1] / z + k_new[1, 2]
    inside = (u >= 0) & (u < target_w) & (v >= 0) & (v < target_h)
    if not np.any(inside):
        return np.zeros((target_h, target_w), dtype=np.float32), 0

    u_i = np.floor(u[inside]).astype(np.int64)
    v_i = np.floor(v[inside]).astype(np.int64)
    z_i = z[inside].astype(np.float32)
    flat = v_i * target_w + u_i

    depth_flat = np.full(target_h * target_w, np.inf, dtype=np.float32)
    np.minimum.at(depth_flat, flat, z_i)
    depth = depth_flat.reshape(target_h, target_w)
    depth[~np.isfinite(depth)] = 0.0
    return depth, int(np.count_nonzero(depth > 0))


def robust_scale_shift_fit(
    pred: np.ndarray,
    target: np.ndarray,
    min_points: int,
    huber_k: float,
    max_iters: int,
) -> Tuple[float, float, Dict[str, float]]:
    valid = np.isfinite(pred) & np.isfinite(target) & (target > 0) & (pred > 0)
    x = pred[valid].astype(np.float64)
    y = target[valid].astype(np.float64)
    n = int(x.size)
    if n < min_points:
        return 1.0, 0.0, {"success": 0.0, "num_fit_points": float(n)}

    a = np.vstack([x, np.ones_like(x)]).T
    try:
        coeff, *_ = np.linalg.lstsq(a, y, rcond=None)
    except np.linalg.LinAlgError:
        return 1.0, 0.0, {"success": 0.0, "num_fit_points": float(n)}

    weights = np.ones_like(y, dtype=np.float64)
    for _ in range(max_iters):
        residual = coeff[0] * x + coeff[1] - y
        mad = np.median(np.abs(residual - np.median(residual)))
        sigma = max(1.4826 * mad, 1e-3)
        threshold = huber_k * sigma
        weights = np.minimum(1.0, threshold / (np.abs(residual) + 1e-6))
        aw = a * np.sqrt(weights[:, None])
        yw = y * np.sqrt(weights)
        try:
            coeff, *_ = np.linalg.lstsq(aw, yw, rcond=None)
        except np.linalg.LinAlgError:
            break

    scale, shift = float(coeff[0]), float(coeff[1])
    aligned_samples = scale * x + shift
    residual = aligned_samples - y
    abs_rel = float(np.mean(np.abs(residual) / np.maximum(y, 1e-3)))
    rmse = float(np.sqrt(np.mean(residual * residual)))
    inlier = np.abs(residual) < np.maximum(1.0, 0.1 * y)
    inlier_ratio = float(np.mean(inlier))

    success = float(np.isfinite(scale) and np.isfinite(shift) and scale > 0.0)
    return scale, shift, {
        "success": success,
        "num_fit_points": float(n),
        "scale": scale,
        "shift": shift,
        "fit_absrel": abs_rel,
        "fit_rmse": rmse,
        "fit_inlier_ratio": inlier_ratio,
        "fit_weight_mean": float(np.mean(weights)),
    }


def atomic_save_npz(path: Path, compress: bool, **arrays) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    if compress:
        np.savez_compressed(str(tmp), **arrays)
    else:
        np.savez(str(tmp), **arrays)
    actual_tmp = Path(str(tmp) + ".npz")
    if actual_tmp.exists() and actual_tmp != tmp:
        actual_tmp.replace(path)
    else:
        tmp.replace(path)


def build_indexes(nuscenes_root: Path):
    meta_root = nuscenes_root / "v1.0-trainval"
    sensors = {r["token"]: r for r in load_json(meta_root / "sensor.json")}
    calibrated = {r["token"]: r for r in load_json(meta_root / "calibrated_sensor.json")}
    ego_pose = {r["token"]: r for r in load_json(meta_root / "ego_pose.json")}
    sample_data = load_json(meta_root / "sample_data.json")

    channel_by_calibrated = {
        token: sensors[rec["sensor_token"]]["channel"] for token, rec in calibrated.items()
    }

    lidar_by_sample = {}
    cameras = []
    sample_token_by_lidar_rel = {}
    for rec in sample_data:
        channel = channel_by_calibrated[rec["calibrated_sensor_token"]]
        if not rec.get("is_key_frame", False):
            continue
        if channel == "LIDAR_TOP":
            lidar_by_sample[rec["sample_token"]] = rec
            sample_token_by_lidar_rel[rec["filename"]] = rec["sample_token"]
        elif channel in CAMERA_ORDER:
            rec = dict(rec)
            rec["channel"] = channel
            cameras.append(rec)

    return calibrated, ego_pose, lidar_by_sample, cameras, sample_token_by_lidar_rel


def load_split_tokens(nuscenes_root: Path, split: str, sample_token_by_lidar_rel: Dict[str, str]):
    if split == "all":
        return None
    split_file = nuscenes_root / f"{split}_paths.txt"
    if not split_file.exists():
        raise FileNotFoundError(f"Missing split file: {split_file}")
    tokens = set()
    root_str = str(nuscenes_root)
    with split_file.open("r") as f:
        for line in f:
            path = line.strip()
            if not path:
                continue
            if path.startswith(root_str):
                rel = os.path.relpath(path, root_str).replace("\\", "/")
            else:
                rel = path.replace("\\", "/")
            token = sample_token_by_lidar_rel.get(rel)
            if token is not None:
                tokens.add(token)
    return tokens


def output_path(output_root: Path, kind: str, camera: str, image_filename: str) -> Path:
    stem = Path(image_filename).stem
    return output_root / kind / camera / f"{stem}.npz"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--nuscenes-root", type=Path, required=True)
    parser.add_argument("--model-path", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--split", choices=["train", "val", "all"], default="all")
    parser.add_argument("--camera", choices=list(CAMERA_ORDER) + ["all"], default="all")
    parser.add_argument("--height", type=int, default=256)
    parser.add_argument("--width", type=int, default=704)
    parser.add_argument(
        "--image-transform",
        choices=["dvgt_resize_crop", "resize_crop", "resize"],
        default="dvgt_resize_crop",
        help=(
            "dvgt_resize_crop matches Stage1/Stage2 principal-point crop, aspect-preserving resize, "
            "and final principal-point crop; resize_crop is accepted as a legacy alias; resize warps directly to HxW."
        ),
    )
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--use-fp16", action="store_true", default=True)
    parser.add_argument("--no-fp16", dest="use_fp16", action="store_false")
    parser.add_argument("--resolution-level", type=int, default=9)
    parser.add_argument("--num-tokens", type=int, default=None)
    parser.add_argument("--min-depth", type=float, default=0.1)
    parser.add_argument("--max-depth", type=float, default=120.0)
    parser.add_argument("--min-fit-points", type=int, default=20)
    parser.add_argument("--huber-k", type=float, default=1.5)
    parser.add_argument("--fit-iters", type=int, default=8)
    parser.add_argument("--skip-existing", action="store_true")
    parser.add_argument("--compress", action="store_true")
    parser.add_argument("--save-pred-depth", action="store_true", default=True)
    parser.add_argument("--save-proj-depth", action="store_true", default=True)
    parser.add_argument("--no-save-pred-depth", dest="save_pred_depth", action="store_false")
    parser.add_argument("--no-save-proj-depth", dest="save_proj_depth", action="store_false")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--sample-data-token", default=None)
    parser.add_argument("--manifest-every", type=int, default=1)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    target_hw = (args.height, args.width)
    args.output_root.mkdir(parents=True, exist_ok=True)
    (args.output_root / "meta").mkdir(parents=True, exist_ok=True)

    calibrated, ego_pose, lidar_by_sample, cameras, sample_token_by_lidar_rel = build_indexes(
        args.nuscenes_root
    )
    split_tokens = load_split_tokens(args.nuscenes_root, args.split, sample_token_by_lidar_rel)
    if split_tokens is not None:
        cameras = [r for r in cameras if r["sample_token"] in split_tokens]
    if args.camera != "all":
        cameras = [r for r in cameras if r["channel"] == args.camera]
    if args.sample_data_token:
        cameras = [r for r in cameras if r["token"] == args.sample_data_token]
        if not cameras:
            raise RuntimeError(f"No camera sample_data found for token={args.sample_data_token}")

    channel_rank = {name: i for i, name in enumerate(CAMERA_ORDER)}
    cameras.sort(key=lambda r: (r["timestamp"], r["sample_token"], channel_rank[r["channel"]]))
    if args.start_index:
        cameras = cameras[args.start_index :]
    if args.limit is not None:
        cameras = cameras[: args.limit]

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    checkpoint_path = args.model_path / "model.pt" if args.model_path.is_dir() else args.model_path
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"MoGe checkpoint not found: {checkpoint_path}")
    from moge.model.v2 import MoGeModel

    model = MoGeModel.from_pretrained(checkpoint_path).to(device).eval()
    if args.use_fp16 and device.type == "cuda":
        model.half()

    manifest_path = args.output_root / "meta" / f"manifest_{args.split}.jsonl"
    run_config_path = args.output_root / "meta" / f"run_config_{args.split}_{int(time.time())}.json"
    with run_config_path.open("w") as f:
        json.dump(
            {
                "nuscenes_root": str(args.nuscenes_root),
                "model_path": str(args.model_path),
                "checkpoint_path": str(checkpoint_path),
                "output_root": str(args.output_root),
                "split": args.split,
                "camera": args.camera,
                "height": args.height,
                "width": args.width,
                "image_transform": args.image_transform,
                "use_fp16": args.use_fp16,
                "resolution_level": args.resolution_level,
                "num_tokens": args.num_tokens,
                "sample_data_token": args.sample_data_token,
                "min_depth": args.min_depth,
                "max_depth": args.max_depth,
                "min_fit_points": args.min_fit_points,
                "huber_k": args.huber_k,
                "fit_iters": args.fit_iters,
                "num_items": len(cameras),
                "torch": torch.__version__,
                "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
            },
            f,
            indent=2,
        )

    processed = 0
    skipped = 0
    failures = 0
    fit_failures = 0

    with manifest_path.open("a") as manifest:
        for idx, cam_sd in enumerate(tqdm(cameras, desc=f"MoGe-2 depth {args.split}")):
            camera = cam_sd["channel"]
            align_path = output_path(args.output_root, "align_depth", camera, cam_sd["filename"])
            pred_path = output_path(args.output_root, "pred_depth", camera, cam_sd["filename"])
            proj_path = output_path(args.output_root, "proj_depth", camera, cam_sd["filename"])
            if args.skip_existing and align_path.exists():
                skipped += 1
                continue

            try:
                lidar_sd = lidar_by_sample[cam_sd["sample_token"]]
                image_path = args.nuscenes_root / cam_sd["filename"]
                lidar_path = args.nuscenes_root / lidar_sd["filename"]
                image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
                if image_bgr is None:
                    raise FileNotFoundError(f"Failed to read {image_path}")
                orig_h, orig_w = image_bgr.shape[:2]

                cam_calib = calibrated[cam_sd["calibrated_sensor_token"]]
                k_orig = np.asarray(cam_calib["camera_intrinsic"], dtype=np.float64)
                image_proc, k_new, transform_meta = process_image_and_intrinsics(
                    image_bgr, k_orig, target_hw, args.image_transform
                )
                image_rgb = cv2.cvtColor(image_proc, cv2.COLOR_BGR2RGB)
                image_tensor = (
                    torch.from_numpy(image_rgb).to(device=device, dtype=torch.float32).permute(2, 0, 1)
                    / 255.0
                )

                fov_x = fov_x_from_intrinsics(k_new, args.width)
                output = model.infer(
                    image_tensor,
                    fov_x=fov_x,
                    resolution_level=args.resolution_level,
                    num_tokens=args.num_tokens,
                    use_fp16=args.use_fp16 and device.type == "cuda",
                    apply_mask=False,
                )
                pred_depth = output["depth"].detach().float().cpu().numpy().astype(np.float32)
                pred_mask = output.get("mask")
                if pred_mask is None:
                    pred_mask_np = np.isfinite(pred_depth)
                else:
                    pred_mask_np = pred_mask.detach().cpu().numpy().astype(bool)
                pred_depth[~np.isfinite(pred_depth)] = 0.0

                proj_depth, num_lidar_points = project_lidar_to_camera_depth(
                    lidar_path,
                    lidar_sd,
                    cam_sd,
                    calibrated,
                    ego_pose,
                    k_new,
                    target_hw,
                    args.min_depth,
                    args.max_depth,
                )
                scale, shift, fit_stats = robust_scale_shift_fit(
                    pred_depth,
                    proj_depth,
                    args.min_fit_points,
                    args.huber_k,
                    args.fit_iters,
                )
                aligned = (scale * pred_depth + shift).astype(np.float32)
                train_mask = (
                    pred_mask_np
                    & np.isfinite(aligned)
                    & (aligned > args.min_depth)
                    & (aligned < args.max_depth)
                    & (fit_stats.get("success", 0.0) > 0.0)
                )
                if fit_stats.get("success", 0.0) <= 0.0:
                    fit_failures += 1
                aligned_to_save = np.where(train_mask, aligned, 0.0).astype(np.float16)

                atomic_save_npz(
                    align_path,
                    args.compress,
                    depth=aligned_to_save,
                    mask=train_mask.astype(np.uint8),
                    scale=np.asarray(scale, dtype=np.float32),
                    shift=np.asarray(shift, dtype=np.float32),
                    fit_absrel=np.asarray(fit_stats.get("fit_absrel", np.nan), dtype=np.float32),
                    fit_rmse=np.asarray(fit_stats.get("fit_rmse", np.nan), dtype=np.float32),
                    fit_inlier_ratio=np.asarray(
                        fit_stats.get("fit_inlier_ratio", np.nan), dtype=np.float32
                    ),
                    intrinsics=k_new.astype(np.float32),
                )
                if args.save_pred_depth:
                    pred_to_save = np.where(
                        np.isfinite(pred_depth) & (pred_depth > 0), pred_depth, 0.0
                    ).astype(np.float16)
                    atomic_save_npz(
                        pred_path,
                        args.compress,
                        depth=pred_to_save,
                        mask=pred_mask_np.astype(np.uint8),
                        intrinsics=k_new.astype(np.float32),
                    )
                if args.save_proj_depth:
                    atomic_save_npz(
                        proj_path,
                        True,
                        depth=proj_depth.astype(np.float16),
                        mask=(proj_depth > 0).astype(np.uint8),
                        intrinsics=k_new.astype(np.float32),
                    )

                if idx % args.manifest_every == 0:
                    row = {
                        "split": args.split,
                        "index": args.start_index + idx,
                        "sample_token": cam_sd["sample_token"],
                        "sample_data_token": cam_sd["token"],
                        "lidar_sample_data_token": lidar_sd["token"],
                        "camera": camera,
                        "timestamp": cam_sd["timestamp"],
                        "image_path": str(image_path),
                        "lidar_path": str(lidar_path),
                        "align_depth_path": str(align_path),
                        "pred_depth_path": str(pred_path) if args.save_pred_depth else "",
                        "proj_depth_path": str(proj_path) if args.save_proj_depth else "",
                        "height": args.height,
                        "width": args.width,
                        "original_height": orig_h,
                        "original_width": orig_w,
                        "image_transform": transform_meta,
                        "fov_x_deg": fov_x,
                        "num_lidar_points": num_lidar_points,
                        "train_mask_coverage": float(np.mean(train_mask)),
                        "model": "Ruicheng/moge-2-vitl",
                        "checkpoint_path": str(checkpoint_path),
                    }
                    row.update({k: float(v) for k, v in fit_stats.items()})
                    manifest.write(json.dumps(row, ensure_ascii=False) + "\n")
                    manifest.flush()

                processed += 1
            except Exception as exc:  # noqa: BLE001 - long-running annotation should continue.
                failures += 1
                err_path = args.output_root / "meta" / f"errors_{args.split}.jsonl"
                with err_path.open("a") as ef:
                    ef.write(
                        json.dumps(
                            {
                                "index": args.start_index + idx,
                                "sample_data_token": cam_sd.get("token"),
                                "filename": cam_sd.get("filename"),
                                "error": repr(exc),
                            },
                            ensure_ascii=False,
                        )
                        + "\n"
                    )

    summary = {
        "processed": processed,
        "skipped": skipped,
        "failures": failures,
        "fit_failures": fit_failures,
        "manifest": str(manifest_path),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
