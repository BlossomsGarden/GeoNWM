# Async-Diffusion S1+async

Depth-Prior Async S1 ablation training lives in `examples/train_anchored_async.py`.
It uses the online six-frame S1 offset dataset, the CLIP condition from two
frames before the chunk start, and no chunk-internal anchor copy.
All six nuScenes cameras are used as independent single-view video samples;
the model still sees one camera stream per item.

## Scope

- `nframes=6`; all six frames are generated online and all six participate in
  the loss.
- No mask channel and no mask-region loss; UNet input remains 16 channels and
  output remains 8 channels.
- Keep async RGB/depth noise schedules, dual RGB/depth timestep embeddings, and
  per-modality preconditioning.
- `OFFSET_MODE=curriculum` uses warmup offsets for the first half of training,
  then switches to all 14 offsets.

## Scheme Switch

```bash
ASYNC_DELTA=0.3 bash examples/scripts/anchor_async_train_stage1.sh  # main
ASYNC_DELTA=0 bash examples/scripts/anchor_async_train_stage1.sh    # ablation B
```

Only `ASYNC_DELTA` changes between the main scheme and ablation B.
