# Sync-Diffusion Reproduction A

This directory is a trimmed DiST-S synchronous RGB-D baseline for the
`train-anchored-diffusion.md` reproduction-A experiment.

## Scope

- Start from the original SVD checkpoint and initialize the DiST-S 16-channel
  input / 8-channel output UNet.
- Keep the original synchronous RGB-D training path: one shared EDM sigma /
  timestep, original preconditioning, and the original full-latent weighted MSE.
- Replace the old pre-generated reprojection dataset with online nuScenes
  RGB-D offset chunks.
- Train with `nframes=7`: frame 0 is the GT anchor, frames 1-6 are warped
  RGB-D conditions with dense RGB-D targets.
- Do not add Async changes: no 17th mask channel, no mask-region loss, no dual
  timestep, and no async time embedding.

## Key Files

- `DiST_S/diffusers/examples/train_svd_nus_mm.py` - Sync DiST-S training loop.
- `DiST_S/diffusers/examples/utils/dataset_nuscenes.py` - online anchored
  nuScenes RGB-D dataset.
- `DiST_S/diffusers/examples/utils/stage1_offset_geometry.py` - CPU geometry
  for ego-left/right offset rendering and reprojection.
- `DiST_S/diffusers/examples/scripts/mm_train_nus_768.sh` - FSDP launch script.
- `DiST_S/diffusers/fsdp.yaml` - two-process FSDP config.

## Run

From `DiST_S/diffusers`:

```bash
bash examples/scripts/mm_train_nus_768.sh
```

The script defaults to CUDA devices `0,1` and these data roots:

```bash
NUSCENES_ROOT=/data2/DATA/AutoDrive/nuscenes/v1.0-trainval
DEPTH_ROOT=/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth
PROJECT_DIR=/data4/DATA/wlh/Difix3D+
MODEL_NAME=/data4/DATA/wlh/Difix3D+/model/SVD_XT
```

Useful overrides:

```bash
MODEL_NAME=/path/to/svd \
PROJECT_DIR=/path/to/project-with-nuscenes-csv \
OFFSET_MODE=curriculum \
MAX_TRAIN_STEPS=30000 \
bash examples/scripts/mm_train_nus_768.sh
```

`OFFSET_MODE=curriculum` uses the 10 warmup offsets for the first half of
training steps, then switches to all 14 offsets. Static modes `warmup`, `all`,
`acceptance`, or a comma-separated list of offset names are also supported.
