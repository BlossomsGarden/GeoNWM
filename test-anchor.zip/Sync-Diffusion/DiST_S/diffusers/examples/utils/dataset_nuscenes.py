import math
import multiprocessing as mp
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
import torch
import torch.utils.data as data
from PIL import Image
from torchvision import transforms as tr

from utils.stage1_offset_geometry import (
    CAMERA_ORDER,
    OffsetResult,
    default_samples_csv,
    find_sample_from_csv_row,
    generate_offset_supervision,
    load_metadata_indexes,
    load_rgb_depth,
    normalize_camera_name,
    read_csv_rows,
    resolve_version_dir,
    transform_from_translation_rotation,
)


CURRICULUM_OFFSET_MODE = "curriculum"


@dataclass(frozen=True)
class OffsetSpec:
    name: str
    shifts_left_m: Tuple[float, ...]


def _format_meter(value: float) -> str:
    return f"{abs(float(value)):g}".replace(".", "p") + "m"


def progressive_schedule(start_m: float, end_m: float, sign: float, chunk_length: int) -> Tuple[float, ...]:
    if chunk_length <= 1:
        return (0.0,)
    values = np.linspace(start_m, end_m, chunk_length - 1)
    return (0.0, *tuple(float(sign * value) for value in values))


def fixed_schedule(value_m: float, sign: float, chunk_length: int) -> Tuple[float, ...]:
    if chunk_length <= 1:
        return (0.0,)
    return (0.0, *tuple(float(sign * value_m) for _ in range(chunk_length - 1)))


def build_offset_specs(chunk_length: int) -> Dict[str, OffsetSpec]:
    specs: Dict[str, OffsetSpec] = {}
    for direction, sign in (("left", 1.0), ("right", -1.0)):
        for start_m, end_m in ((0.0, 2.0), (2.0, 4.0), (4.0, 6.0)):
            name = f"progressive_{direction}_{_format_meter(start_m)}_{_format_meter(end_m)}"
            specs[name] = OffsetSpec(name=name, shifts_left_m=progressive_schedule(start_m, end_m, sign, chunk_length))
        for value_m in (1.0, 2.0, 4.0, 6.0):
            name = f"fixed_{direction}_{_format_meter(value_m)}"
            specs[name] = OffsetSpec(name=name, shifts_left_m=fixed_schedule(value_m, sign, chunk_length))
    return specs


def select_offset_specs(mode: str, chunk_length: int) -> List[OffsetSpec]:
    specs = build_offset_specs(chunk_length)
    warmup_names = [
        "progressive_left_0m_2m",
        "progressive_right_0m_2m",
        "progressive_left_2m_4m",
        "progressive_right_2m_4m",
        "fixed_left_1m",
        "fixed_right_1m",
        "fixed_left_2m",
        "fixed_right_2m",
        "fixed_left_4m",
        "fixed_right_4m",
    ]
    if mode == "warmup":
        names = warmup_names
    elif mode == "all":
        names = list(specs.keys())
    elif mode == "acceptance":
        names = ["progressive_left_2m_4m", "fixed_left_4m"]
    else:
        names = [part.strip() for part in mode.split(",") if part.strip()]

    missing = [name for name in names if name not in specs]
    if missing:
        raise ValueError(f"Unknown offset spec(s): {missing}. Available: {', '.join(specs)}")
    return [specs[name] for name in names]


def _lcm_many(values: Tuple[int, ...]) -> int:
    out = 1
    for value in values:
        out = abs(out * value) // math.gcd(out, value)
    return out


def make_anchor_copy_result(rgb: np.ndarray, depth: np.ndarray, valid: np.ndarray, invalid_depth_fill: float) -> OffsetResult:
    height, width = depth.shape
    full_valid = np.ones((height, width), dtype=bool)
    no_mask = np.zeros((height, width), dtype=bool)
    return OffsetResult(
        input_rgb=rgb.copy(),
        training_input_depth=depth.copy(),
        target_rgb=rgb.copy(),
        source_depth=depth.copy(),
        source_valid=valid.copy(),
        source_depth_for_projection=depth.copy(),
        source_valid_for_projection=full_valid.copy(),
        shifted_rgb=rgb.copy(),
        shifted_depth=depth.copy(),
        shifted_depth_for_input=depth.copy(),
        shifted_valid=full_valid.copy(),
        shifted_depth_leak_mask=no_mask.copy(),
        reprojected_rgb=rgb.copy(),
        reprojected_depth=depth.copy(),
        reprojected_valid=full_valid.copy(),
        invalid_mask=no_mask.copy(),
        timings_ms={},
        stats={"offset_invalid_mask_ratio": 0.0, "target_invalid_depth_fill": float(invalid_depth_fill)},
    )


class VideoNuscenesAnchoredStage1Dataset(data.Dataset):
    """Online nuScenes RGB-D offset chunks for the synchronous DiST-S baseline.

    Each item is a single-camera chunk. Frame 0 is a direct-copy anchor, and
    frames 1..T-1 are generated online from the selected ego-left/right offset
    schedule. The returned keys intentionally match the original DiST-S training
    script and do not append a mask channel or introduce mask-region losses.
    """

    def __init__(
        self,
        nuscenes_root: str = "/data2/DATA/AutoDrive/nuscenes/v1.0-trainval",
        depth_root: str = "/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth",
        project_dir: str = "/data4/DATA/wlh/Difix3D+",
        samples_csv: Optional[str] = None,
        split_name: str = "train",
        video_length: int = 7,
        video_transforms=None,
        single_cam: bool = True,
        pros_w: int = 704,
        pros_h: int = 256,
        offset_mode: str = CURRICULUM_OFFSET_MODE,
        offset_warmup_fraction: float = 0.5,
        anchor_stride: int = 6,
        max_train_samples: Optional[int] = None,
        depth_min: float = 0.5,
        depth_norm_max: float = 100.0,
        projection_depth_max: float = 120.0,
        invalid_depth_fill: float = 100.0,
        seed: int = 0,
    ):
        super().__init__()
        self.nuscenes_root = Path(nuscenes_root)
        self.depth_root = Path(depth_root)
        self.project_dir = Path(project_dir)
        self.samples_csv = Path(samples_csv) if samples_csv else default_samples_csv(self.project_dir, split_name)
        self.split_name = split_name
        self.video_length = int(video_length)
        self.img_transform = video_transforms
        self.pros_w = int(pros_w)
        self.pros_h = int(pros_h)
        self.offset_mode = offset_mode
        self.offset_warmup_fraction = min(max(float(offset_warmup_fraction), 0.0), 1.0)
        self.warmup_offset_specs = select_offset_specs("warmup", self.video_length)
        self.all_offset_specs = select_offset_specs("all", self.video_length)
        if self.offset_mode == CURRICULUM_OFFSET_MODE:
            self.offset_specs = self.all_offset_specs
            self.offset_slots_per_anchor = _lcm_many(
                (len(self.warmup_offset_specs), len(self.all_offset_specs))
            )
        else:
            self.offset_specs = select_offset_specs(offset_mode, self.video_length)
            self.offset_slots_per_anchor = len(self.offset_specs)
        self._shared_global_step = mp.Value("i", 0, lock=False)
        self._shared_max_train_steps = mp.Value("i", 1, lock=False)
        self.anchor_stride = int(anchor_stride)
        self.depth_min = float(depth_min)
        self.depth_norm_max = float(depth_norm_max)
        self.projection_depth_max = float(projection_depth_max)
        self.invalid_depth_fill = float(invalid_depth_fill)
        self.default_transforms = tr.Compose([tr.ToTensor()])
        self.clip_transform = tr.ToTensor()

        self.camera_view = ["CAM_FRONT"] if single_cam else list(CAMERA_ORDER)
        self.version_dir = resolve_version_dir(self.nuscenes_root, None)
        (
            self.sample_data_by_file,
            self.calibrated_by_token,
            self.ego_by_token,
            self.sensor_by_token,
        ) = load_metadata_indexes(self.version_dir)
        self.anchors = self._build_anchor_chunks(max_train_samples=max_train_samples)
        if not self.anchors:
            raise RuntimeError(f"No valid {self.video_length}-frame anchor chunks found in {self.samples_csv}")

    def _build_anchor_chunks(self, max_train_samples: Optional[int]) -> List[List[dict]]:
        rows = read_csv_rows(self.samples_csv)
        allowed_cameras = {normalize_camera_name(camera) for camera in self.camera_view}
        grouped: Dict[Tuple[str, str], List[dict]] = defaultdict(list)
        for row in rows:
            camera = normalize_camera_name(row["cam"])
            if camera not in allowed_cameras:
                continue
            scene_id = str(row.get("scene_id", ""))
            grouped[(scene_id, camera)].append(row)

        anchors: List[List[dict]] = []
        for _, group_rows in sorted(grouped.items()):
            group_rows = sorted(group_rows, key=lambda row: int(row["frame_id"]))
            for start in range(0, len(group_rows), self.anchor_stride):
                chunk = group_rows[start : start + self.video_length]
                if len(chunk) == self.video_length:
                    anchors.append(chunk)

        if max_train_samples is not None:
            anchors = anchors[: int(max_train_samples)]
        return anchors

    def __len__(self):
        return len(self.anchors) * self.offset_slots_per_anchor

    def set_training_step(self, global_step: int, max_train_steps: Optional[int]) -> None:
        self._shared_global_step.value = int(global_step)
        self._shared_max_train_steps.value = max(1, int(max_train_steps or 1))

    def _active_offset_specs(self) -> List[OffsetSpec]:
        if self.offset_mode != CURRICULUM_OFFSET_MODE:
            return self.offset_specs
        warmup_steps = int(round(self._shared_max_train_steps.value * self.offset_warmup_fraction))
        if self._shared_global_step.value < warmup_steps:
            return self.warmup_offset_specs
        return self.all_offset_specs

    def _load_prepared_frame(self, row: dict):
        sample = find_sample_from_csv_row(
            nuscenes_root=self.nuscenes_root,
            depth_root=self.depth_root,
            row=row,
            sample_data_by_file=self.sample_data_by_file,
            calibrated_by_token=self.calibrated_by_token,
            ego_by_token=self.ego_by_token,
            sensor_by_token=self.sensor_by_token,
        )
        rgb, depth, valid, intrinsics, _ = load_rgb_depth(
            sample,
            self.projection_depth_max,
            self.invalid_depth_fill,
        )
        camera_to_ego = transform_from_translation_rotation(
            sample.calibrated_sensor["translation"],
            sample.calibrated_sensor["rotation"],
        )
        return rgb, depth, valid, intrinsics, camera_to_ego

    def _to_rgb_tensor(self, image: np.ndarray) -> torch.Tensor:
        pil = Image.fromarray(image).resize((self.pros_w, self.pros_h), Image.BILINEAR)
        if self.img_transform is not None:
            return self.img_transform(pil)
        return self.default_transforms(pil)

    def _to_clip_tensor(self, image: np.ndarray) -> torch.Tensor:
        pil = Image.fromarray(image).resize((self.pros_w, self.pros_h), Image.BILINEAR)
        return self.clip_transform(pil)

    def _to_depth_tensor(self, depth: np.ndarray) -> torch.Tensor:
        depth = np.clip(depth.astype(np.float32), self.depth_min, self.depth_norm_max) / self.depth_norm_max
        depth = np.repeat(depth[:, :, None], 3, axis=2)
        depth = cv2.resize(depth, (self.pros_w, self.pros_h), interpolation=cv2.INTER_NEAREST)
        if self.img_transform is not None:
            return self.img_transform(depth.astype(np.float32))
        return self.default_transforms(depth.astype(np.float32))

    def __getitem__(self, index):
        active_offset_specs = self._active_offset_specs()
        slot_index = int(index) % self.offset_slots_per_anchor
        anchor_index = (int(index) // self.offset_slots_per_anchor) % len(self.anchors)
        spec = active_offset_specs[slot_index % len(active_offset_specs)]
        rows = self.anchors[anchor_index]

        target_rgb_frames = []
        input_rgb_frames = []
        target_depth_frames = []
        input_depth_frames = []
        clip_frames = []

        for chunk_index, row in enumerate(rows):
            rgb, depth, valid, intrinsics, camera_to_ego = self._load_prepared_frame(row)
            if chunk_index == 0:
                result = make_anchor_copy_result(rgb, depth, valid, self.invalid_depth_fill)
            else:
                result = generate_offset_supervision(
                    rgb=rgb,
                    depth=depth,
                    valid=valid,
                    intrinsics=intrinsics,
                    camera_to_ego=camera_to_ego,
                    shift_left_m=spec.shifts_left_m[chunk_index],
                    depth_max=self.projection_depth_max,
                    invalid_depth_fill=self.invalid_depth_fill,
                )

            target_rgb_frames.append(self._to_rgb_tensor(result.target_rgb))
            input_rgb_frames.append(self._to_rgb_tensor(result.input_rgb))
            target_depth_frames.append(self._to_depth_tensor(result.source_depth))
            input_depth_frames.append(self._to_depth_tensor(result.training_input_depth))
            clip_frames.append(self._to_clip_tensor(result.target_rgb).view(3, 1, self.pros_h, self.pros_w))

        return {
            "pixel_values": torch.stack(target_rgb_frames, dim=0),
            "pseudo_pixel_values": torch.stack(input_rgb_frames, dim=0),
            "depth_values": torch.stack(target_depth_frames, dim=0),
            "pseudo_depth_values": torch.stack(input_depth_frames, dim=0),
            "clip_first_frame": clip_frames[0].squeeze(1),
            "images": clip_frames,
            "offset_name": spec.name,
            "anchor_frame_id": int(rows[0]["frame_id"]),
        }
