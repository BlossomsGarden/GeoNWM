# Sync-Diffusion S1+mask

This directory is the synchronous S1+mask ablation from `ablation.md`.

## Scope

- Start from the original SVD checkpoint and initialize the DiST-S 17-channel
  input / 8-channel output UNet.
- Keep the original synchronous RGB-D training path: one shared EDM sigma /
  timestep and original preconditioning.
- Replace the old pre-generated reprojection dataset with online nuScenes
  RGB-D offset chunks.
- Use all six nuScenes cameras as independent single-view video samples. The
  model still sees one camera stream per item; six views are not packed
  together.
- Train with `nframes=6`: all six frames are online warped RGB-D conditions
  with dense RGB-D targets. No frame inside the chunk is copied as an anchor.
- Use the same camera's frame two steps before the chunk start as the CLIP
  image condition. Chunk starts are local indices `2, 8, 14, ...`.
- Add a max-pooled invalid-region mask as the 17th UNet input channel and use
  RGB/depth mask-region losses. Do not add Async changes: no dual timestep and
  no async time embedding.

## Key Files

- `DiST_S/diffusers/examples/train_svd_nus_mm.py` - Sync DiST-S training loop.
- `DiST_S/diffusers/examples/utils/dataset_nuscenes.py` - online S1 nuScenes
  RGB-D dataset.
- `DiST_S/diffusers/examples/utils/stage1_offset_geometry.py` - CPU geometry
  for ego-left/right offset rendering and reprojection.
- `DiST_S/diffusers/examples/scripts/mm_train_nus_768.sh` - FSDP launch script.
- `DiST_S/diffusers/fsdp.yaml` - two-process FSDP config.

## Run

From `DiST_S/diffusers`:

```bash
bash examples/scripts/mm_train_nus_768.sh
```

The script defaults to CUDA devices `0,1` and these data roots:

```bash
NUSCENES_ROOT=/data2/DATA/AutoDrive/nuscenes/v1.0-trainval
DEPTH_ROOT=/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth
PROJECT_DIR=/data4/DATA/wlh/Difix3D+
MODEL_NAME=/data4/DATA/wlh/Difix3D+/model/SVD_XT
```

Useful overrides:

```bash
MODEL_NAME=/path/to/svd \
PROJECT_DIR=/path/to/project-with-nuscenes-csv \
OFFSET_MODE=curriculum \
MAX_TRAIN_STEPS=60000 \
bash examples/scripts/mm_train_nus_768.sh
```

`OFFSET_MODE=curriculum` uses the 10 warmup offsets for the first half of
training steps, then switches to all 14 offsets. Static modes `warmup`, `all`,
`acceptance`, or a comma-separated list of offset names are also supported.
