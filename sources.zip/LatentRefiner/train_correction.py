from __future__ import annotations

import logging
import sys
import warnings
from datetime import datetime
from importlib.metadata import distributions
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DELTATOK_ROOT = ROOT.parent / "deltatok-nuscenes"
DELTAWORLD_ROOT = DELTATOK_ROOT / "deltaworld-flow"
for path in (ROOT, DELTATOK_ROOT, DELTAWORLD_ROOT):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

import torch
from dotenv import load_dotenv
from lightning import Trainer
from lightning.pytorch import cli
from lightning.pytorch.callbacks import Callback, LearningRateMonitor, ModelCheckpoint, ModelSummary

from latent_refiner.training import CorrectionLatentRefinerModule


class LogRun(Callback):
    def setup(self, trainer: Trainer, pl_module: CorrectionLatentRefinerModule, stage: str) -> None:
        if trainer.logger is not None:
            trainer.logger.experiment.log_code(
                ".",
                include_fn=lambda filename: filename.endswith((".py", ".yaml", ".md", ".env")),
            )

    def on_train_start(self, trainer: Trainer, pl_module: CorrectionLatentRefinerModule) -> None:
        if not trainer.is_global_zero or trainer.logger is None:
            return
        experiment = trainer.logger.experiment
        experiment_dir = experiment.dir
        if callable(experiment_dir):
            experiment_dir = experiment_dir()
        if experiment_dir and Path(experiment_dir).exists():
            pkg_path = Path(experiment_dir) / f"pip-freeze-step{trainer.global_step}.txt"
            pkg_path.write_text("\n".join(sorted(f"{d.name}=={d.version}" for d in distributions())))
            experiment.save(str(pkg_path), policy="now")
        entry = f"[step {trainer.global_step}] {datetime.now().isoformat()}\n$ {' '.join(sys.argv)}"
        experiment.notes = f"{experiment.notes or ''}\n{entry}".strip()


class LightningCLI(cli.LightningCLI):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        load_dotenv()
        torch.set_float32_matmul_precision("high")
        torch.backends.cudnn.benchmark = True
        logging.getLogger().setLevel(logging.INFO)
        warnings.filterwarnings("ignore", message=r".*Found .* module\(s\) in eval mode.*")
        warnings.filterwarnings("ignore", message=r".*Precision bf16-mixed is not supported.*")
        super().__init__(*args, **kwargs)


def cli_main() -> None:
    LightningCLI(
        CorrectionLatentRefinerModule,
        subclass_mode_data=True,
        save_config_callback=None,
        seed_everything_default=0,
        trainer_defaults={
            "max_epochs": -1,
            "accelerator": "gpu",
            "devices": 1,
            "precision": "bf16-mixed",
            "enable_model_summary": False,
            "log_every_n_steps": 1,
            "check_val_every_n_epoch": None,
            "val_check_interval": 5000,
            "callbacks": [
                ModelSummary(max_depth=3),
                LearningRateMonitor(logging_interval="step"),
                LogRun(),
                ModelCheckpoint(every_n_train_steps=50000, save_top_k=-1),
                ModelCheckpoint(monitor="val/refined_latent_mse", mode="min", save_top_k=1),
                ModelCheckpoint(every_n_train_steps=500, save_last=True, save_top_k=0, enable_version_counter=False),
            ],
        },
    )


if __name__ == "__main__":
    cli_main()

