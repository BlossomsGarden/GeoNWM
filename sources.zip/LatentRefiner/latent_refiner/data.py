from __future__ import annotations

import csv
import importlib
import logging
import os
from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset

try:
    from lightning import LightningDataModule
except ImportError:
    LightningDataModule = object  # type: ignore[assignment,misc]


def _load_cls(cls_path: str) -> type:
    module_path, cls_name = cls_path.rsplit(".", 1)
    return getattr(importlib.import_module(module_path), cls_name)


def _load_nuscenes_helpers():
    from datasets.base import as_hw, resize_then_principal_crop
    from datasets.nuscenes import (
        CAM_FRONT_NAMES,
        SampleRow,
        _load_cam_front_intrinsics,
        _load_selected_token_map,
        compute_action,
    )
    from deltaflow.windowing import build_consecutive_windows

    return {
        "as_hw": as_hw,
        "resize_then_principal_crop": resize_then_principal_crop,
        "CAM_FRONT_NAMES": CAM_FRONT_NAMES,
        "SampleRow": SampleRow,
        "_load_cam_front_intrinsics": _load_cam_front_intrinsics,
        "_load_selected_token_map": _load_selected_token_map,
        "compute_action": compute_action,
        "build_consecutive_windows": build_consecutive_windows,
    }


class NuScenesSevenFrameDataset(Dataset):
    def __init__(
        self,
        csv_path: str,
        nuscenes_root: str,
        frame_size: int | tuple[int, int] = 512,
        sequence_length: int = 7,
        ego_pose_path: str | None = None,
        sample_data_path: str | None = None,
        calibrated_sensor_path: str | None = None,
    ) -> None:
        if sequence_length != 7:
            raise ValueError("LatentRefiner curriculum requires sequence_length=7")
        helpers = _load_nuscenes_helpers()
        self._resize_then_principal_crop = helpers["resize_then_principal_crop"]
        self._compute_action = helpers["compute_action"]
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.frame_size = helpers["as_hw"](frame_size)

        metadata_root = self.nuscenes_root / "v1.0-trainval"
        self.ego_pose_path = Path(ego_pose_path or metadata_root / "ego_pose.json")
        self.sample_data_path = Path(sample_data_path or metadata_root / "sample_data.json")
        self.calibrated_sensor_path = Path(calibrated_sensor_path or metadata_root / "calibrated_sensor.json")

        grouped: dict[str, list[Any]] = {}
        sample_row = helpers["SampleRow"]
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            for raw in csv.DictReader(handle):
                if raw.get("cam") not in helpers["CAM_FRONT_NAMES"]:
                    continue
                row = sample_row(raw["scene_id"], int(raw["frame_id"]), raw["file"], raw["ego_pose_token"])
                grouped.setdefault(row.scene_id, []).append(row)
        self.sequences: list[tuple[Any, ...]] = []
        for rows in grouped.values():
            rows.sort(key=lambda row: row.frame_id)
            frame_ids = [row.frame_id for row in rows]
            self.sequences.extend(helpers["build_consecutive_windows"](rows, frame_ids, sequence_length))
        if not self.sequences:
            raise ValueError(f"No consecutive 7-frame CAM_FRONT windows found in {self.csv_path}")

        tokens = {row.ego_pose_token for seq in self.sequences for row in seq}
        self.ego_poses = helpers["_load_selected_token_map"](self.ego_pose_path, tokens)
        self.intrinsics_by_file = helpers["_load_cam_front_intrinsics"](
            str(self.sample_data_path.resolve()),
            str(self.calibrated_sensor_path.resolve()),
        )

    def _resolve(self, filename: str) -> Path:
        path = Path(filename)
        candidates = (
            path if path.is_absolute() else self.nuscenes_root / path,
            self.nuscenes_root / "samples" / "CAM_FRONT" / path.name,
        )
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(f"Could not resolve image path {filename!r}")

    def _frame(self, row: Any) -> torch.Tensor:
        with Image.open(self._resolve(row.file)) as image:
            image_np = np.asarray(image.convert("RGB"))
        intrinsic = self.intrinsics_by_file.get(row.file)
        if intrinsic is None:
            intrinsic = self.intrinsics_by_file.get(Path(row.file).name)
        image_np = self._resize_then_principal_crop(image_np, intrinsic, self.frame_size)
        return torch.from_numpy(image_np.copy()).permute(2, 0, 1)

    def __len__(self) -> int:
        return len(self.sequences)

    def _get_sequence(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        rows = self.sequences[idx]
        frames = torch.stack([self._frame(row) for row in rows])
        actions = torch.stack(
            [
                self._compute_action(
                    self.ego_poses[prev.ego_pose_token],
                    self.ego_poses[curr.ego_pose_token],
                )
                for prev, curr in zip(rows, rows[1:])
            ]
        )
        return frames, actions

    def __getitem__(self, idx: int):
        return self._get_sequence(idx)


class NuScenesSevenFrameTrain(NuScenesSevenFrameDataset):
    pass


class NuScenesSevenFrameVal(NuScenesSevenFrameDataset):
    def __getitem__(self, idx: int):
        frames, actions = self._get_sequence(idx)
        return frames, actions, idx


def val_collate_fn(batch: list[tuple]) -> tuple[torch.Tensor, ...]:
    if len(batch[0]) == 3:
        frames, actions, indices = zip(*batch)
        return torch.stack(frames), torch.stack(actions), torch.tensor(indices)
    frames, actions = zip(*batch)
    return torch.stack(frames), torch.stack(actions)


class DataModule(LightningDataModule):
    def __init__(
        self,
        val_datasets_cfg: dict[str, dict[str, Any]] | None = None,
        num_workers: int = 8,
        prefetch_factor: int | None = None,
        train_dataset_cfg: dict[str, Any] | None = None,
        batch_size: int = 1,
        frame_size: int | tuple[int, int] = 512,
    ) -> None:
        if LightningDataModule is object:
            raise ImportError("lightning is required to use latent_refiner.data.DataModule")
        super().__init__()
        self.val_datasets_cfg = val_datasets_cfg
        self.num_workers = int(num_workers)
        self.prefetch_factor = prefetch_factor
        self.train_dataset_cfg = train_dataset_cfg
        self.batch_size = int(batch_size)
        self.frame_size = frame_size
        self.train_dataset = None
        self.val_datasets: dict[str, Dataset] = {}

    def setup(self, stage: str | None = None) -> None:
        if self.train_dataset_cfg is not None and stage in ("fit", None):
            cls = _load_cls(self.train_dataset_cfg["class_path"])
            init_args = dict(self.train_dataset_cfg.get("init_args", {}))
            init_args.setdefault("frame_size", self.frame_size)
            self.train_dataset = cls(**init_args)
        self.val_datasets = {}
        for name, cfg in (self.val_datasets_cfg or {}).items():
            cls = _load_cls(cfg["class_path"])
            init_args = dict(cfg.get("init_args", {}))
            init_args.setdefault("frame_size", self.frame_size)
            try:
                self.val_datasets[name] = cls(**init_args)
            except (KeyError, FileNotFoundError) as exc:
                logging.info("Skipping %s dataset: %s", name, exc)

    def _loader_kwargs(self) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "num_workers": self.num_workers,
            "pin_memory": True,
            "persistent_workers": self.num_workers > 0,
        }
        if self.num_workers > 0:
            kwargs["prefetch_factor"] = self.prefetch_factor
            if os.name != "nt":
                kwargs["multiprocessing_context"] = "fork"
        return kwargs

    def train_dataloader(self) -> DataLoader:
        if self.train_dataset is None:
            raise RuntimeError("train_dataset is not configured")
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            drop_last=True,
            **self._loader_kwargs(),
        )

    def val_dataloader(self) -> list[DataLoader]:
        loaders = []
        for name, dataset in self.val_datasets.items():
            loader = DataLoader(
                dataset,
                batch_size=self.batch_size,
                shuffle=False,
                collate_fn=val_collate_fn,
                **self._loader_kwargs(),
            )
            loader.dataset_name = name
            loaders.append(loader)
        return loaders
