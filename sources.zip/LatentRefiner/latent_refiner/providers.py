from __future__ import annotations

from pathlib import Path
from typing import Protocol

import torch
import torch.nn as nn

from .config import CodecInfo
from .rf import validate_latent


class LatentProvider(Protocol):
    @property
    def codec_info(self) -> CodecInfo:
        ...

    def encode_frames(self, frames: torch.Tensor) -> torch.Tensor:
        ...

    def sample_first_future(
        self,
        input_latent: torch.Tensor,
        actions: torch.Tensor,
        num_steps: int = 1,
        generator: torch.Generator | None = None,
    ) -> torch.Tensor:
        ...

    def decode_latents(self, latents: torch.Tensor) -> torch.Tensor:
        ...


def _freeze(module: nn.Module) -> nn.Module:
    module.eval()
    module.requires_grad_(False)
    return module


def _module_fingerprint(module: nn.Module) -> str:
    param_count = sum(p.numel() for p in module.parameters())
    trainable_count = sum(p.numel() for p in module.parameters() if p.requires_grad)
    return f"{module.__class__.__name__}:params={param_count}:trainable={trainable_count}"


def _load_flow_checkpoint(flow: nn.Module, checkpoint_path: str | None) -> str:
    if checkpoint_path is None:
        return "unloaded"
    path = Path(checkpoint_path)
    if not path.is_file():
        raise FileNotFoundError(f"DeltaWorld checkpoint not found: {path}")
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    state = checkpoint.get("state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint
    if not isinstance(state, dict):
        raise TypeError(f"unsupported DeltaWorld checkpoint format: {path}")
    cleaned = {}
    for key, value in state.items():
        if not torch.is_tensor(value):
            continue
        for prefix in ("network._orig_mod.", "network.", "_orig_mod.", "module."):
            if key.startswith(prefix):
                key = key[len(prefix) :]
        cleaned[key] = value
    incompatible = flow.load_state_dict(cleaned, strict=False)
    unexpected = [key for key in incompatible.unexpected_keys if not key.startswith("delta_tok.")]
    missing = [key for key in incompatible.missing_keys if not key.startswith("delta_tok.")]
    if unexpected:
        raise RuntimeError(f"unexpected DeltaWorld checkpoint keys: {unexpected[:5]}")
    if missing:
        raise RuntimeError(f"missing DeltaWorld checkpoint keys: {missing[:5]}")
    return str(path.resolve())


class DeltaWorldDinoProvider(nn.Module):
    def __init__(
        self,
        flow: nn.Module,
        flow_ckpt_path: str | None = None,
        delta_world_sampling_steps: int = 1,
        normalization_id: str = "dino-full-mean-std",
    ) -> None:
        super().__init__()
        if int(delta_world_sampling_steps) != 1:
            raise ValueError("DeltaWorld provider must use exactly one Euler step")
        if flow is None:
            raise ValueError("flow must be a frozen DeltaWorldFlow instance")
        delta_tok = getattr(flow, "delta_tok", None)
        if delta_tok is None:
            raise ValueError("flow must expose delta_tok")
        loaded_from = _load_flow_checkpoint(flow, flow_ckpt_path)
        self.flow = _freeze(flow)
        self.delta_tok = _freeze(delta_tok)
        self.delta_world_sampling_steps = 1
        self.normalization_id = normalization_id
        self.loaded_from = loaded_from
        self._token_grid: tuple[int, int] | None = None

    @property
    def codec_info(self) -> CodecInfo:
        return CodecInfo(
            family="dino",
            latent_width=832,
            num_heads=13,
            token_grid=self._token_grid,
            checkpoint_fingerprint=f"{self.loaded_from}:{_module_fingerprint(self.flow)}",
            normalization_id=self.normalization_id,
        )

    @torch.no_grad()
    def encode_frames(self, frames: torch.Tensor) -> torch.Tensor:
        if frames.ndim != 5 or frames.shape[1] != 7:
            raise ValueError(f"expected frames [B,7,3,H,W], got {tuple(frames.shape)}")
        latents = self.delta_tok.backbone.encode(frames).detach()
        if latents.ndim != 4 or latents.shape[:2] != frames.shape[:2]:
            raise ValueError(f"codec returned unexpected latent shape {tuple(latents.shape)}")
        if latents.shape[-1] != 832:
            raise ValueError(f"DINO provider expected latent width 832, got {latents.shape[-1]}")
        grid = int(latents.shape[-2] ** 0.5)
        if grid * grid != latents.shape[-2]:
            raise ValueError(f"DINO latent token count must be square, got {latents.shape[-2]}")
        self._token_grid = (grid, grid)
        return latents.detach()

    @torch.no_grad()
    def sample_first_future(
        self,
        input_latent: torch.Tensor,
        actions: torch.Tensor,
        num_steps: int = 1,
        generator: torch.Generator | None = None,
    ) -> torch.Tensor:
        validate_latent("input_latent", input_latent, 832)
        if int(num_steps) != 1:
            raise ValueError("DeltaWorld sampler must use exactly one Euler step")
        if actions.shape != (input_latent.shape[0], 4, 3):
            raise ValueError(f"expected actions [B,4,3], got {tuple(actions.shape)}")
        sampled_residuals = self.flow.sample(
            input_latent.detach(),
            actions.detach(),
            num_steps=1,
            generator=generator,
        )
        if sampled_residuals.ndim != 4 or sampled_residuals.shape[1] < 1:
            raise ValueError(f"DeltaWorld sample returned {tuple(sampled_residuals.shape)}")
        first_latent = self.delta_tok.decode(sampled_residuals[:, 0], input_latent.detach())
        validate_latent("first_latent", first_latent, 832)
        return first_latent.detach()

    @torch.no_grad()
    def decode_latents(self, latents: torch.Tensor) -> torch.Tensor:
        if latents.ndim not in (3, 4):
            raise ValueError(f"expected latents [B,N,C] or [B,T,N,C], got {tuple(latents.shape)}")
        if latents.shape[-1] != 832:
            raise ValueError(f"DINO provider expected latent width 832, got {latents.shape[-1]}")
        return self.delta_tok.backbone.decode(latents).detach()

    def train(self, mode: bool = True) -> "DeltaWorldDinoProvider":
        super().train(False)
        _freeze(self.flow)
        _freeze(self.delta_tok)
        return self


class MockLatentProvider(nn.Module):
    def __init__(
        self,
        latent_width: int = 832,
        token_grid: tuple[int, int] = (4, 4),
        num_heads: int = 13,
        family: str = "dino",
    ) -> None:
        super().__init__()
        self.latent_width = int(latent_width)
        self.token_grid = (int(token_grid[0]), int(token_grid[1]))
        self.num_heads = int(num_heads)
        self.family = family

    @property
    def codec_info(self) -> CodecInfo:
        return CodecInfo(
            family=self.family,
            latent_width=self.latent_width,
            num_heads=self.num_heads,
            token_grid=self.token_grid,
            checkpoint_fingerprint="mock",
            normalization_id="mock",
        )

    def encode_frames(self, frames: torch.Tensor) -> torch.Tensor:
        if frames.ndim == 4 and frames.shape[-1] == self.latent_width:
            return frames.detach()
        if frames.ndim == 5 and frames.shape[-1] == self.latent_width:
            return frames.detach()
        if frames.ndim != 5:
            raise ValueError(f"mock frames must be [B,T,...] or latent [B,T,N,C], got {tuple(frames.shape)}")
        batch, frames_count = frames.shape[:2]
        tokens = self.token_grid[0] * self.token_grid[1]
        base = frames.float().flatten(2).mean(dim=-1, keepdim=True).unsqueeze(-1)
        offsets = torch.linspace(0.0, 1.0, tokens, device=frames.device).view(1, 1, tokens, 1)
        channels = torch.linspace(0.0, 0.01, self.latent_width, device=frames.device).view(1, 1, 1, -1)
        return (base + offsets + channels).expand(batch, frames_count, tokens, self.latent_width).detach()

    def sample_first_future(
        self,
        input_latent: torch.Tensor,
        actions: torch.Tensor,
        num_steps: int = 1,
        generator: torch.Generator | None = None,
    ) -> torch.Tensor:
        validate_latent("input_latent", input_latent, self.latent_width)
        if int(num_steps) != 1:
            raise ValueError("mock DeltaWorld sampler also enforces one step")
        if actions.shape != (input_latent.shape[0], 4, 3):
            raise ValueError(f"expected actions [B,4,3], got {tuple(actions.shape)}")
        action_offset = actions[:, 0].float().sum(dim=-1).view(-1, 1, 1) * 0.01
        return (input_latent.detach() + action_offset.to(input_latent)).detach()

    def decode_latents(self, latents: torch.Tensor) -> torch.Tensor:
        return latents.detach()
