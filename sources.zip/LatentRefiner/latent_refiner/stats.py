from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch


def _clamp_std(std: torch.Tensor) -> torch.Tensor:
    std = std.float()
    median = torch.median(std)
    if not torch.isfinite(median) or median <= 0:
        raise ValueError("latent std median must be positive and finite")
    return std.clamp(0.1 * median, 10.0 * median)


@dataclass
class CleanLatentStats:
    mean: torch.Tensor
    std: torch.Tensor
    sample_count: int
    codec_family: str = "dino"
    normalization_id: str = "dino-full-mean-std"
    metadata: dict[str, Any] | None = None

    def save(self, path: str | Path) -> None:
        payload = {
            "schema_version": 1,
            "mean": self.mean.detach().cpu().float(),
            "std": self.std.detach().cpu().float(),
            "clamped_std": _clamp_std(self.std.detach().cpu().float()),
            "sample_count": int(self.sample_count),
            "codec_family": self.codec_family,
            "normalization_id": self.normalization_id,
            "metadata": self.metadata or {},
        }
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        torch.save(payload, path)


def load_clean_latent_stats(path: str | Path | None, width: int) -> tuple[torch.Tensor, torch.Tensor]:
    if path is None:
        return torch.zeros(width), torch.ones(width)
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict):
        raise TypeError(f"unsupported latent stats format: {path}")
    mean = payload.get("mean")
    std = payload.get("clamped_std", payload.get("std", payload.get("raw_std")))
    if mean is None:
        mean = torch.zeros(width)
    if std is None:
        raise ValueError(f"latent stats at {path} must contain std, clamped_std, or raw_std")
    mean = torch.as_tensor(mean).float().flatten()
    std = torch.as_tensor(std).float().flatten()
    if mean.numel() != width:
        raise ValueError(f"latent mean width {mean.numel()} != expected {width}")
    if std.numel() != width:
        raise ValueError(f"latent std width {std.numel()} != expected {width}")
    return mean, _clamp_std(std)


@torch.no_grad()
def scan_clean_latent_stats(dataloader, provider, device: torch.device, max_batches: int | None = None) -> CleanLatentStats:
    count = 0
    mean = None
    m2 = None
    for batch_idx, batch in enumerate(dataloader):
        if max_batches is not None and batch_idx >= max_batches:
            break
        frames = batch[0].to(device)
        latents = provider.encode_frames(frames).float()
        values = latents.reshape(-1, latents.shape[-1]).double()
        batch_count = values.shape[0]
        batch_mean = values.mean(dim=0)
        batch_m2 = ((values - batch_mean) ** 2).sum(dim=0)
        if mean is None:
            count = batch_count
            mean = batch_mean
            m2 = batch_m2
            continue
        delta = batch_mean - mean
        total = count + batch_count
        m2 = m2 + batch_m2 + delta.square() * count * batch_count / total
        mean = mean + delta * batch_count / total
        count = total
    if mean is None or m2 is None or count < 2:
        raise ValueError("at least two latent observations are required to scan stats")
    std = (m2 / (count - 1)).sqrt().float()
    info = provider.codec_info
    return CleanLatentStats(
        mean=mean.float(),
        std=std,
        sample_count=count,
        codec_family=info.family,
        normalization_id=info.normalization_id,
        metadata={"checkpoint_fingerprint": info.checkpoint_fingerprint},
    )

