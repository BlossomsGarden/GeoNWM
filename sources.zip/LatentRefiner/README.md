# LatentRefiner: DINO-Tok

This folder contains the DINO-Tok latent refiner for the current `deltatok-nuscenes` DeltaWorld entry. It is independent from the older `deltaworld-flow/refiner` folder.

## Schemes

Both schemes use conditional Rectified Flow with endpoint prediction:

```python
endpoint_hat = backbone(x_tau, z_coarse_condition, tau)
loss = ((endpoint_hat.float() - target.float()) / (1.0 - tau).clamp_min(0.05)).square().mean()
```

C, correction endpoint:

```python
target = (z_gt_raw - z_coarse_raw) / clean_latent_std
z_refined_raw = z_coarse_raw + clean_latent_std * endpoint_sample
```

D, full-latent endpoint:

```python
target = (z_gt_raw - full_latent_mean) / full_latent_std
z_refined_raw = full_latent_mean + full_latent_std * endpoint_sample
```

The condition is always normalized coarse full latent:

```python
z_coarse_condition = (z_coarse_raw - full_latent_mean) / full_latent_std
```

## Architecture

- DDT backbone.
- Width 832, 13 heads, 64 channels per head.
- Block order: state self-attention, state-to-coarse cross-attention, MLP.
- AdaLN time conditioning.
- Corrected axial 2D RoPE: row and column halves rotate independently in adjacent pairs.
- `time_embed_scale: 1000.0` is a checkpoint architecture parameter.

RoPE is applied to Q and K only. Cross-attention uses the state grid for Q and the coarse-condition grid for K.

## Curriculum

Each sample is a 7-frame window with 6 actions. The chain schedule is:

```python
[1, 1, 2, 1, 1, 3, 1, 2, 1, 1]
```

Each hop performs an independent optimizer update. DeltaWorld sampling is fixed to one Euler step. Refiner feedback is disabled during the first 50% of optimizer progress and enabled after that, using a detached sampled refiner output.

## Sampling

- Scheme C uses 20 Euler steps.
- Scheme D uses 25 Euler steps.
- The sampler starts from standard Gaussian noise and never calls the model at `tau=1`.
- The state is kept in fp32; the model can still run under Lightning bf16 autocast.

## Training

Update the paths in the configs first.

Correction endpoint:

```bash
python sources/LatentRefiner/train_correction.py fit --config sources/LatentRefiner/configs/correction_512.yaml
```

Full-latent endpoint:

```bash
python sources/LatentRefiner/train_full_latent.py fit --config sources/LatentRefiner/configs/full_latent_512.yaml
```

`stats_path` must point to clean DINO latent mean/std statistics. `flow_ckpt_path` must point to the trained DeltaWorld-flow checkpoint. If either is omitted, the code remains useful for smoke tests but not for a real refiner run.

## Tests

```bash
python -m pytest sources/LatentRefiner/tests -q
python -m compileall sources/LatentRefiner
```
