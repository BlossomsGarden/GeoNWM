import sys
from pathlib import Path

import torch
import torch.nn as nn

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from latent_refiner.config import Scheme
from latent_refiner.rf import LatentTransforms, endpoint_loss, sample_endpoint


def test_endpoint_loss_uses_stable_weighted_endpoint_error():
    endpoint_hat = torch.tensor([[[2.0, 4.0]], [[1.0, -1.0]]])
    target = torch.tensor([[[1.0, 1.0]], [[0.0, 1.0]]])
    tau = torch.tensor([0.5, 0.99])

    loss = endpoint_loss(endpoint_hat, target, tau, sigma_min_loss=0.05)

    denom = torch.tensor([0.5, 0.05]).view(2, 1, 1)
    expected = ((endpoint_hat - target) / denom).square().mean()
    assert torch.allclose(loss, expected)


def test_dino_correction_finalization_uses_raw_coarse_and_clean_std():
    transforms = LatentTransforms(
        scheme=Scheme.CORRECTION,
        codec_family="dino",
        latent_width=832,
        full_mean=torch.ones(832) * 10.0,
        full_std=torch.ones(832) * 2.0,
        clean_std=torch.ones(832) * 3.0,
    )
    coarse = torch.ones(1, 4, 832) * 5.0
    gt = coarse + 6.0

    target = transforms.target(gt, coarse)
    refined = transforms.finalize(target, coarse)

    assert torch.allclose(target, torch.ones_like(target) * 2.0)
    assert torch.allclose(refined, gt)


def test_dino_full_latent_finalization_denormalizes_endpoint():
    transforms = LatentTransforms(
        scheme=Scheme.FULL_LATENT,
        codec_family="dino",
        latent_width=832,
        full_mean=torch.ones(832),
        full_std=torch.ones(832) * 2.0,
    )
    gt = torch.ones(1, 4, 832) * 7.0
    coarse = torch.zeros_like(gt)

    target = transforms.target(gt, coarse)
    refined = transforms.finalize(target, coarse)

    assert torch.allclose(target, torch.ones_like(target) * 3.0)
    assert torch.allclose(refined, gt)


class RecordingBackbone(nn.Module):
    def __init__(self, endpoint: torch.Tensor) -> None:
        super().__init__()
        self.endpoint = endpoint
        self.taus: list[torch.Tensor] = []

    def forward(self, x_state, condition, tau):
        self.taus.append(tau.detach().cpu())
        return self.endpoint.to(x_state)


def test_sampler_plus_direction_and_no_tau_one_final_endpoint():
    endpoint = torch.ones(1, 4, 832) * 3.0
    model = RecordingBackbone(endpoint)
    condition = torch.zeros(1, 4, 832)
    generator = torch.Generator().manual_seed(7)

    sample = sample_endpoint(model, condition, num_steps=4, sigma_min_sampler=0.001, generator=generator)

    assert torch.allclose(sample, endpoint, atol=1.0e-6)
    taus = torch.cat(model.taus)
    assert torch.all(taus < 1.0)
    assert torch.allclose(taus, torch.tensor([0.0, 0.25, 0.5, 0.75]))

