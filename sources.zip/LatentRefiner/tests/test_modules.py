import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from latent_refiner.modules import LatentRefinerDDT, timestep_embedding


def test_dino_ddt_shape_contract():
    model = LatentRefinerDDT(latent_dim=832, depth=2, num_heads=13, time_embed_scale=1000.0)
    x_tau = torch.randn(2, 16, 832)
    condition = torch.randn(2, 16, 832)
    tau = torch.tensor([0.0, 0.5])

    endpoint_hat = model(x_tau, condition, tau)

    assert endpoint_hat.shape == x_tau.shape


def test_time_embedding_scales_tau_before_sinusoid():
    tau = torch.tensor([0.001], dtype=torch.float32)
    emb_scaled = timestep_embedding(tau, 8, scale=1000.0)
    emb_unscaled_at_one = timestep_embedding(torch.tensor([1.0]), 8, scale=1.0)

    assert torch.allclose(emb_scaled, emb_unscaled_at_one, atol=1.0e-6)
