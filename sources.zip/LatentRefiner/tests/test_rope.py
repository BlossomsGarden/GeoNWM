import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from latent_refiner.rope import DynamicAxial2DRoPE


def test_rope_preserves_norm_for_dino_heads():
    rope = DynamicAxial2DRoPE(head_dim=64)
    cache = rope.build_cache((4, 4), torch.device("cpu"))
    x = torch.randn(2, 13, 16, 64)

    y = rope.apply(x, cache)

    assert y.shape == x.shape
    assert torch.allclose(y.float().norm(dim=-1), x.float().norm(dim=-1), atol=1.0e-5)


def test_rope_keeps_row_and_column_halves_isolated():
    rope = DynamicAxial2DRoPE(head_dim=64)
    cache = rope.build_cache((4, 4), torch.device("cpu"))

    row_only = torch.zeros(1, 13, 16, 64)
    row_only[..., :32] = torch.randn(1, 13, 16, 32)
    row_rotated = rope.apply(row_only, cache)
    assert torch.allclose(row_rotated[..., 32:], torch.zeros_like(row_rotated[..., 32:]))

    col_only = torch.zeros(1, 13, 16, 64)
    col_only[..., 32:] = torch.randn(1, 13, 16, 32)
    col_rotated = rope.apply(col_only, cache)
    assert torch.allclose(col_rotated[..., :32], torch.zeros_like(col_rotated[..., :32]))


def test_rope_rejects_mismatched_grid():
    rope = DynamicAxial2DRoPE(head_dim=64)
    cache = rope.build_cache((4, 4), torch.device("cpu"))
    x = torch.randn(2, 13, 9, 64)

    try:
        rope.apply(x, cache)
    except ValueError as exc:
        assert "tensor has 9" in str(exc)
    else:
        raise AssertionError("expected mismatched grid to raise")

