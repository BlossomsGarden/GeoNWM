import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from latent_refiner.curriculum import (
    CHAIN_SCHEDULE,
    average_optimizer_updates_per_data_step,
    chain_length_for_data_step,
    hop_update_counts_per_cycle,
    iter_hops,
    should_use_refined_feedback,
)


def test_chain_schedule_and_counts():
    assert CHAIN_SCHEDULE == (1, 1, 2, 1, 1, 3, 1, 2, 1, 1)
    assert [chain_length_for_data_step(i) for i in range(10)] == list(CHAIN_SCHEDULE)
    assert hop_update_counts_per_cycle() == {1: 10, 2: 3, 3: 1}
    assert average_optimizer_updates_per_data_step() == 1.4


def test_hop_specs_use_first_future_targets():
    hops = iter_hops(3)
    assert [hop.action_start for hop in hops] == [0, 1, 2]
    assert [hop.target_index for hop in hops] == [1, 2, 3]
    assert [hop.is_last for hop in hops] == [False, False, True]


def test_feedback_switch_uses_optimizer_progress():
    assert not should_use_refined_feedback(49, 100, 0.5)
    assert should_use_refined_feedback(50, 100, 0.5)

