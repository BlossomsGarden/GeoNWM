# LatentRefiner-RAEv2

This folder contains the RAEv2 latent refiner. It mirrors `sources/LatentRefiner` structurally, but uses the RAEv2 normalized latent space and does not import the DINO project.

## Schemes

Both schemes use conditional Rectified Flow with endpoint prediction:

```python
endpoint_hat = backbone(x_tau, z_coarse, tau)
loss = ((endpoint_hat.float() - target.float()) / (1.0 - tau).clamp_min(0.05)).square().mean()
```

C, correction endpoint:

```python
target = (z_gt - z_coarse) / clean_latent_std
z_refined = z_coarse + clean_latent_std * endpoint_sample
```

D, full-latent endpoint:

```python
target = z_gt
z_refined = endpoint_sample
```

`z_gt`, `z_coarse`, and `z_refined` are RAEv2 normalized latents. The RAEv2 decoder performs its own inverse normalization.

## Architecture

- DDT backbone.
- Width 768, 12 heads, 64 channels per head.
- Block order: state self-attention, state-to-coarse cross-attention, MLP.
- AdaLN time conditioning.
- Corrected axial 2D RoPE: row and column halves rotate independently in adjacent pairs.
- `time_embed_scale: 1000.0` is a checkpoint architecture parameter.

## Current Upstream Boundary

This iteration intentionally does not implement a RAEv2 DeltaWorld-flow provider. The default configs use `UnavailableRAEv2DeltaWorldProvider`, which raises a clear startup error. Use `MockLatentProvider` only for tests or smoke checks.

## Curriculum

The training curriculum matches the DINO version:

```python
[1, 1, 2, 1, 1, 3, 1, 2, 1, 1]
```

Each hop performs an independent optimizer update. DeltaWorld sampling is fixed to one Euler step when a real provider is added. Refiner feedback is disabled during the first 50% of optimizer progress and enabled after that, using a detached sampled refiner output.

## Training

The entrypoints are in place, but online training needs a future real RAEv2 provider:

```bash
python sources/LatentRefiner-RAEv2/train_correction.py fit --config sources/LatentRefiner-RAEv2/configs/correction_512.yaml
python sources/LatentRefiner-RAEv2/train_full_latent.py fit --config sources/LatentRefiner-RAEv2/configs/full_latent_512.yaml
```

## Tests

```bash
python -m pytest sources/LatentRefiner-RAEv2/tests -q
python -m compileall sources/LatentRefiner-RAEv2
```

