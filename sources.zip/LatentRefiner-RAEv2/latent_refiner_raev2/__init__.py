from .config import CodecInfo, RefinerConfig, Scheme

__all__ = [
    "CodecInfo",
    "LatentRefinerDDT",
    "LatentTransforms",
    "RefinerConfig",
    "Scheme",
    "endpoint_loss",
    "make_noisy_endpoint",
    "sample_endpoint",
]


def __getattr__(name: str):
    if name == "LatentRefinerDDT":
        from .modules import LatentRefinerDDT

        return LatentRefinerDDT
    if name in {"LatentTransforms", "endpoint_loss", "make_noisy_endpoint", "sample_endpoint"}:
        from . import rf

        return getattr(rf, name)
    raise AttributeError(name)
