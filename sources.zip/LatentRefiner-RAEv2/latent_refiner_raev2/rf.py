from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn

from .config import Scheme


def _batch_view(values: torch.Tensor, ndim: int) -> tuple[int, ...]:
    return (values.shape[0],) + (1,) * (ndim - 1)


def _channel_view(values: torch.Tensor, latent: torch.Tensor) -> torch.Tensor:
    values = values.to(device=latent.device, dtype=latent.dtype)
    if values.ndim != 1 or values.numel() != latent.shape[-1]:
        raise ValueError(f"expected channel vector [{latent.shape[-1]}], got {tuple(values.shape)}")
    return values.view((1,) * (latent.ndim - 1) + (latent.shape[-1],))


def validate_latent(name: str, latent: torch.Tensor, latent_width: int) -> None:
    if latent.ndim != 3 or latent.shape[-1] != latent_width:
        raise ValueError(f"{name} must be [B,N,{latent_width}], got {tuple(latent.shape)}")
    tokens = latent.shape[1]
    grid = int(tokens**0.5)
    if grid * grid != tokens:
        raise ValueError(f"{name} token count must be square, got {tokens}")
    if not torch.isfinite(latent).all():
        raise ValueError(f"{name} contains NaN or Inf")


@dataclass
class LatentTransforms:
    scheme: Scheme | str
    codec_family: str
    latent_width: int
    full_mean: torch.Tensor | None = None
    full_std: torch.Tensor | None = None
    clean_std: torch.Tensor | None = None

    def __post_init__(self) -> None:
        self.scheme = Scheme.coerce(self.scheme)
        if self.codec_family != "raev2":
            raise ValueError(f"RAEv2 transforms require codec_family='raev2', got {self.codec_family!r}")
        if self.latent_width != 768:
            raise ValueError(f"RAEv2 transforms require latent_width=768, got {self.latent_width}")
        if self.clean_std is None:
            self.clean_std = torch.ones(self.latent_width)

    def condition(self, z_coarse: torch.Tensor) -> torch.Tensor:
        validate_latent("z_coarse", z_coarse, self.latent_width)
        return z_coarse

    def target(self, z_gt: torch.Tensor, z_coarse: torch.Tensor) -> torch.Tensor:
        validate_latent("z_gt", z_gt, self.latent_width)
        validate_latent("z_coarse", z_coarse, self.latent_width)
        if self.scheme == Scheme.CORRECTION:
            return (z_gt - z_coarse) / _channel_view(self.clean_std, z_gt).clamp_min(1.0e-8)
        return z_gt

    def finalize(self, endpoint_sample: torch.Tensor, z_coarse: torch.Tensor) -> torch.Tensor:
        validate_latent("endpoint_sample", endpoint_sample, self.latent_width)
        validate_latent("z_coarse", z_coarse, self.latent_width)
        if self.scheme == Scheme.CORRECTION:
            return z_coarse + endpoint_sample * _channel_view(self.clean_std, endpoint_sample)
        return endpoint_sample

    def normalized_latent(self, z: torch.Tensor) -> torch.Tensor:
        validate_latent("z", z, self.latent_width)
        return z


def make_noisy_endpoint(
    target: torch.Tensor,
    tau: torch.Tensor,
    noise: torch.Tensor | None = None,
    generator: torch.Generator | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    if tau.shape != (target.shape[0],):
        raise ValueError(f"tau must be [B], got {tuple(tau.shape)}")
    if noise is None:
        noise = torch.randn(target.shape, device=target.device, dtype=target.dtype, generator=generator)
    if noise.shape != target.shape:
        raise ValueError(f"noise shape {tuple(noise.shape)} must match target {tuple(target.shape)}")
    tau_view = tau.reshape(_batch_view(tau, target.ndim)).to(device=target.device, dtype=target.dtype)
    return (1.0 - tau_view) * noise + tau_view * target, noise


def endpoint_loss(
    endpoint_hat: torch.Tensor,
    target: torch.Tensor,
    tau: torch.Tensor,
    sigma_min_loss: float = 0.05,
) -> torch.Tensor:
    if endpoint_hat.shape != target.shape:
        raise ValueError(f"endpoint_hat shape {tuple(endpoint_hat.shape)} != target {tuple(target.shape)}")
    if tau.shape != (target.shape[0],):
        raise ValueError(f"tau must be [B], got {tuple(tau.shape)}")
    denom = (1.0 - tau.float()).clamp_min(float(sigma_min_loss)).reshape(_batch_view(tau, target.ndim))
    error = (endpoint_hat.float() - target.float()) / denom.to(device=target.device)
    loss = error.square().mean()
    if not torch.isfinite(loss):
        raise ValueError("endpoint loss is NaN or Inf")
    return loss


@torch.no_grad()
def sample_endpoint(
    backbone: nn.Module,
    condition: torch.Tensor,
    num_steps: int,
    sigma_min_sampler: float = 0.001,
    generator: torch.Generator | None = None,
) -> torch.Tensor:
    if num_steps < 1:
        raise ValueError("num_steps must be at least 1")
    if condition.ndim != 3:
        raise ValueError(f"condition must be [B,N,C], got {tuple(condition.shape)}")
    x_state = torch.randn(
        condition.shape,
        device=condition.device,
        dtype=torch.float32,
        generator=generator,
    )
    dt = 1.0 / float(num_steps)
    for step in range(num_steps):
        tau = torch.full((condition.shape[0],), step * dt, device=condition.device, dtype=torch.float32)
        endpoint_hat = backbone(x_state, condition, tau)
        remaining = (1.0 - tau).clamp_min(float(sigma_min_sampler)).reshape(_batch_view(tau, x_state.ndim))
        velocity = (endpoint_hat.float() - x_state) / remaining.to(device=x_state.device)
        x_state = x_state + dt * velocity
        if not torch.isfinite(x_state).all():
            raise ValueError(f"Euler sampler produced NaN or Inf at step {step}")
    return x_state

