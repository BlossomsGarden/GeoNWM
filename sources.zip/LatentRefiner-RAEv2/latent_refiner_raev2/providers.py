from __future__ import annotations

from typing import Protocol

import torch
import torch.nn as nn

from .config import CodecInfo
from .rf import validate_latent


RAEV2_PROVIDER_ERROR = (
    "RAEv2 DeltaWorld provider is not implemented in this iteration; "
    "pass a real provider object or use MockLatentProvider for tests."
)


class LatentProvider(Protocol):
    @property
    def codec_info(self) -> CodecInfo:
        ...

    def encode_frames(self, frames: torch.Tensor) -> torch.Tensor:
        ...

    def sample_first_future(
        self,
        input_latent: torch.Tensor,
        actions: torch.Tensor,
        num_steps: int = 1,
        generator: torch.Generator | None = None,
    ) -> torch.Tensor:
        ...

    def decode_latents(self, latents: torch.Tensor) -> torch.Tensor:
        ...


class UnavailableRAEv2DeltaWorldProvider(nn.Module):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__()
        raise RuntimeError(RAEV2_PROVIDER_ERROR)


class MockLatentProvider(nn.Module):
    def __init__(
        self,
        latent_width: int = 768,
        token_grid: tuple[int, int] = (4, 4),
        num_heads: int = 12,
        family: str = "raev2",
    ) -> None:
        super().__init__()
        self.latent_width = int(latent_width)
        self.token_grid = (int(token_grid[0]), int(token_grid[1]))
        self.num_heads = int(num_heads)
        self.family = family

    @property
    def codec_info(self) -> CodecInfo:
        return CodecInfo(
            family=self.family,
            latent_width=self.latent_width,
            num_heads=self.num_heads,
            token_grid=self.token_grid,
            checkpoint_fingerprint="mock",
            normalization_id="raev2-normalized",
        )

    def encode_frames(self, frames: torch.Tensor) -> torch.Tensor:
        if frames.ndim == 4 and frames.shape[-1] == self.latent_width:
            return frames.detach()
        if frames.ndim == 5 and frames.shape[-1] == self.latent_width:
            return frames.detach()
        if frames.ndim != 5:
            raise ValueError(f"mock frames must be [B,T,...] or latent [B,T,N,C], got {tuple(frames.shape)}")
        batch, frames_count = frames.shape[:2]
        tokens = self.token_grid[0] * self.token_grid[1]
        base = frames.float().flatten(2).mean(dim=-1, keepdim=True).unsqueeze(-1)
        offsets = torch.linspace(0.0, 1.0, tokens, device=frames.device).view(1, 1, tokens, 1)
        channels = torch.linspace(0.0, 0.01, self.latent_width, device=frames.device).view(1, 1, 1, -1)
        return (base + offsets + channels).expand(batch, frames_count, tokens, self.latent_width).detach()

    def sample_first_future(
        self,
        input_latent: torch.Tensor,
        actions: torch.Tensor,
        num_steps: int = 1,
        generator: torch.Generator | None = None,
    ) -> torch.Tensor:
        validate_latent("input_latent", input_latent, self.latent_width)
        if int(num_steps) != 1:
            raise ValueError("mock DeltaWorld sampler also enforces one step")
        if actions.shape != (input_latent.shape[0], 4, 3):
            raise ValueError(f"expected actions [B,4,3], got {tuple(actions.shape)}")
        action_offset = actions[:, 0].float().sum(dim=-1).view(-1, 1, 1) * 0.01
        return (input_latent.detach() + action_offset.to(input_latent)).detach()

    def decode_latents(self, latents: torch.Tensor) -> torch.Tensor:
        return latents.detach()

