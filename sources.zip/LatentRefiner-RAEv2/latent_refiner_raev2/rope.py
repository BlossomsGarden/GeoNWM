from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from math import isqrt

import torch


Grid = tuple[int, int]


@dataclass(frozen=True)
class RopeCache:
    grid: Grid
    row_cos: torch.Tensor
    row_sin: torch.Tensor
    col_cos: torch.Tensor
    col_sin: torch.Tensor


def infer_grid(token_count: int) -> Grid:
    grid = isqrt(int(token_count))
    if grid * grid != int(token_count):
        raise ValueError(f"token count must be a square grid, got {token_count}")
    return grid, grid


@lru_cache(maxsize=128)
def _cpu_positions(grid: Grid) -> tuple[torch.Tensor, torch.Tensor]:
    height, width = grid
    rows = torch.arange(height, dtype=torch.float32)
    cols = torch.arange(width, dtype=torch.float32)
    row, col = torch.meshgrid(rows, cols, indexing="ij")
    return row.reshape(-1), col.reshape(-1)


class DynamicAxial2DRoPE:
    def __init__(self, head_dim: int = 64, theta: float = 10000.0) -> None:
        if head_dim < 4 or head_dim % 4:
            raise ValueError("head_dim must be divisible by four")
        self.head_dim = int(head_dim)
        self.axis_dim = self.head_dim // 2
        if self.axis_dim % 2:
            raise ValueError("half head_dim must be even for pairwise rotation")
        self.theta = float(theta)

    def build_cache(self, grid: Grid | int, device: torch.device) -> RopeCache:
        if isinstance(grid, int):
            grid = (grid, grid)
        row_cpu, col_cpu = _cpu_positions((int(grid[0]), int(grid[1])))
        row = row_cpu.to(device=device, dtype=torch.float32)
        col = col_cpu.to(device=device, dtype=torch.float32)
        inv_freq = 1.0 / (
            self.theta
            ** (
                torch.arange(0, self.axis_dim, 2, device=device, dtype=torch.float32)
                / max(float(self.axis_dim), 1.0)
            )
        )
        row_angle = row[:, None] * inv_freq[None, :]
        col_angle = col[:, None] * inv_freq[None, :]
        return RopeCache(
            grid=(int(grid[0]), int(grid[1])),
            row_cos=row_angle.cos(),
            row_sin=row_angle.sin(),
            col_cos=col_angle.cos(),
            col_sin=col_angle.sin(),
        )

    @staticmethod
    def _rotate_pairs(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x_float = x.float()
        even = x_float[..., 0::2]
        odd = x_float[..., 1::2]
        cos = cos.view(1, 1, cos.shape[0], cos.shape[1])
        sin = sin.view(1, 1, sin.shape[0], sin.shape[1])
        rotated = torch.stack((even * cos - odd * sin, even * sin + odd * cos), dim=-1)
        return rotated.flatten(-2).to(dtype=dtype)

    def apply(self, x: torch.Tensor, cache: RopeCache) -> torch.Tensor:
        if x.ndim != 4 or x.shape[-1] != self.head_dim:
            raise ValueError(f"expected [B,H,N,{self.head_dim}], got {tuple(x.shape)}")
        if x.shape[-2] != cache.row_cos.shape[0]:
            raise ValueError(
                f"RoPE cache grid {cache.grid} has {cache.row_cos.shape[0]} tokens, "
                f"but tensor has {x.shape[-2]}"
            )
        row_x, col_x = x.chunk(2, dim=-1)
        row_x = self._rotate_pairs(row_x, cache.row_cos, cache.row_sin)
        col_x = self._rotate_pairs(col_x, cache.col_cos, cache.col_sin)
        return torch.cat((row_x, col_x), dim=-1)

