from __future__ import annotations

from collections import Counter
from dataclasses import dataclass


CHAIN_SCHEDULE: tuple[int, ...] = (1, 1, 2, 1, 1, 3, 1, 2, 1, 1)


@dataclass(frozen=True)
class HopSpec:
    index: int
    action_start: int
    target_index: int
    is_last: bool


def chain_length_for_data_step(data_step: int) -> int:
    if data_step < 0:
        raise ValueError("data_step must be non-negative")
    return CHAIN_SCHEDULE[data_step % len(CHAIN_SCHEDULE)]


def iter_hops(chain_length: int) -> list[HopSpec]:
    if chain_length not in (1, 2, 3):
        raise ValueError(f"chain_length must be 1, 2, or 3, got {chain_length}")
    return [
        HopSpec(index=hop, action_start=hop, target_index=hop + 1, is_last=hop == chain_length - 1)
        for hop in range(chain_length)
    ]


def hop_update_counts_per_cycle() -> Counter[int]:
    counts: Counter[int] = Counter()
    for chain_length in CHAIN_SCHEDULE:
        for hop in range(chain_length):
            counts[hop + 1] += 1
    return counts


def average_optimizer_updates_per_data_step() -> float:
    return sum(CHAIN_SCHEDULE) / float(len(CHAIN_SCHEDULE))


def should_use_refined_feedback(
    optimizer_step: int,
    max_optimizer_steps: int,
    transition_fraction: float = 0.5,
) -> bool:
    if max_optimizer_steps <= 0:
        raise ValueError("max_optimizer_steps must be positive")
    if not 0.0 <= transition_fraction <= 1.0:
        raise ValueError("transition_fraction must be in [0,1]")
    progress = float(optimizer_step) / float(max_optimizer_steps)
    return progress >= transition_fraction

