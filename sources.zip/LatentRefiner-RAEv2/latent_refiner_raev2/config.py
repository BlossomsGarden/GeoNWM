from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Scheme(str, Enum):
    CORRECTION = "correction"
    FULL_LATENT = "full_latent"

    @classmethod
    def coerce(cls, value: str | "Scheme") -> "Scheme":
        if isinstance(value, cls):
            return value
        return cls(str(value))


@dataclass(frozen=True)
class CodecInfo:
    family: str
    latent_width: int
    num_heads: int
    token_grid: tuple[int, int] | None = None
    checkpoint_fingerprint: str = "unknown"
    normalization_id: str = "raev2-normalized"

    @property
    def head_dim(self) -> int:
        if self.latent_width % self.num_heads:
            raise ValueError(
                f"latent_width={self.latent_width} is not divisible by num_heads={self.num_heads}"
            )
        return self.latent_width // self.num_heads


@dataclass(frozen=True)
class RefinerConfig:
    scheme: Scheme
    codec_family: str = "raev2"
    latent_width: int = 768
    num_heads: int = 12
    depth: int = 8
    mlp_ratio: float = 4.0
    dropout: float = 0.0
    time_embed_scale: float = 1000.0
    sigma_min_loss: float = 0.05
    sigma_min_sampler: float = 0.001
    correction_sampling_steps: int = 20
    full_latent_sampling_steps: int = 25
    delta_world_sampling_steps: int = 1
    rope_version: str = "axial_split_pairs_v1"

    @property
    def head_dim(self) -> int:
        if self.latent_width % self.num_heads:
            raise ValueError(
                f"latent_width={self.latent_width} is not divisible by num_heads={self.num_heads}"
            )
        return self.latent_width // self.num_heads

    @property
    def sampling_steps(self) -> int:
        scheme = Scheme.coerce(self.scheme)
        if scheme == Scheme.CORRECTION:
            return self.correction_sampling_steps
        return self.full_latent_sampling_steps

    def validate(self) -> None:
        if self.codec_family != "raev2":
            raise ValueError(f"RAEv2 LatentRefiner requires codec_family='raev2', got {self.codec_family!r}")
        if self.latent_width != 768:
            raise ValueError(f"RAEv2 LatentRefiner requires latent_width=768, got {self.latent_width}")
        if self.num_heads != 12:
            raise ValueError(f"RAEv2 LatentRefiner requires num_heads=12, got {self.num_heads}")
        if self.head_dim != 64:
            raise ValueError(f"RAEv2 LatentRefiner requires 64 channels per head, got {self.head_dim}")
        if self.time_embed_scale != 1000.0:
            raise ValueError("time_embed_scale is an architecture parameter and must be 1000.0")
        if self.delta_world_sampling_steps != 1:
            raise ValueError("DeltaWorld sampler must use exactly one Euler step")
        if self.sigma_min_loss <= 0:
            raise ValueError("sigma_min_loss must be positive")
        if self.sigma_min_sampler <= 0:
            raise ValueError("sigma_min_sampler must be positive")
        if self.sigma_min_sampler > 1.0 / float(self.sampling_steps):
            raise ValueError("sigma_min_sampler must be <= 1 / refiner_sampling_steps")
        if self.rope_version != "axial_split_pairs_v1":
            raise ValueError(f"Unsupported RoPE version: {self.rope_version}")


def raev2_config(scheme: str | Scheme) -> RefinerConfig:
    cfg = RefinerConfig(scheme=Scheme.coerce(scheme))
    cfg.validate()
    return cfg

