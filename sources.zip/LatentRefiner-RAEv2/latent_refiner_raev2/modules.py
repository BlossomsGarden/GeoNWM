from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .rope import DynamicAxial2DRoPE, Grid, RopeCache, infer_grid


def zero_init(module: nn.Module) -> nn.Module:
    if isinstance(module, nn.Linear):
        nn.init.zeros_(module.weight)
        if module.bias is not None:
            nn.init.zeros_(module.bias)
    return module


def timestep_embedding(tau: torch.Tensor, dim: int, scale: float = 1000.0, max_period: int = 10000) -> torch.Tensor:
    tau_scaled = tau.float() * float(scale)
    half = dim // 2
    freqs = torch.exp(
        -math.log(float(max_period))
        * torch.arange(half, device=tau.device, dtype=torch.float32)
        / max(float(half), 1.0)
    )
    args = tau_scaled.unsqueeze(-1) * freqs.unsqueeze(0)
    emb = torch.cat((args.cos(), args.sin()), dim=-1)
    if dim % 2:
        emb = torch.cat((emb, torch.zeros_like(emb[:, :1])), dim=-1)
    return emb


class AdaLayerNorm(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(dim, elementwise_affine=False)
        self.modulation = nn.Sequential(nn.SiLU(), zero_init(nn.Linear(dim, 2 * dim)))

    def forward(self, x: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        scale, shift = self.modulation(cond).chunk(2, dim=-1)
        return self.norm(x) * (1.0 + scale.unsqueeze(1)) + shift.unsqueeze(1)


class MLP(nn.Module):
    def __init__(self, dim: int, mlp_ratio: float = 4.0) -> None:
        super().__init__()
        hidden = int(dim * mlp_ratio)
        self.net = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(approximate="tanh"),
            nn.Linear(hidden, dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class DDTBlock(nn.Module):
    def __init__(self, dim: int, num_heads: int, mlp_ratio: float = 4.0, dropout: float = 0.0) -> None:
        super().__init__()
        if dim % num_heads:
            raise ValueError(f"dim={dim} must be divisible by num_heads={num_heads}")
        self.dim = int(dim)
        self.num_heads = int(num_heads)
        self.head_dim = self.dim // self.num_heads
        self.dropout = float(dropout)
        self.rope = DynamicAxial2DRoPE(self.head_dim)

        self.self_norm = AdaLayerNorm(dim)
        self.self_qkv = nn.Linear(dim, 3 * dim)
        self.self_out = nn.Linear(dim, dim)

        self.cross_norm = AdaLayerNorm(dim)
        self.cond_norm = nn.LayerNorm(dim)
        self.cross_q = nn.Linear(dim, dim)
        self.cross_kv = nn.Linear(dim, 2 * dim)
        self.cross_out = nn.Linear(dim, dim)

        self.mlp_norm = AdaLayerNorm(dim)
        self.mlp = MLP(dim, mlp_ratio)
        self.gates = nn.Parameter(torch.zeros(3))

    def _shape(self, x: torch.Tensor) -> torch.Tensor:
        batch, tokens, _ = x.shape
        return x.view(batch, tokens, self.num_heads, self.head_dim).transpose(1, 2)

    def _merge(self, x: torch.Tensor) -> torch.Tensor:
        batch, _, tokens, _ = x.shape
        return x.transpose(1, 2).reshape(batch, tokens, self.dim)

    def _attn(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        q_rope: RopeCache,
        k_rope: RopeCache,
    ) -> torch.Tensor:
        q = self.rope.apply(self._shape(q), q_rope)
        k = self.rope.apply(self._shape(k), k_rope)
        v = self._shape(v)
        dropout_p = self.dropout if self.training else 0.0
        out = F.scaled_dot_product_attention(q, k, v, dropout_p=dropout_p)
        return self._merge(out)

    def forward(
        self,
        x: torch.Tensor,
        condition: torch.Tensor,
        time_cond: torch.Tensor,
        state_rope: RopeCache,
        condition_rope: RopeCache,
    ) -> torch.Tensor:
        q, k, v = self.self_qkv(self.self_norm(x, time_cond)).chunk(3, dim=-1)
        x = x + self.gates[0].tanh() * self.self_out(self._attn(q, k, v, state_rope, state_rope))

        q = self.cross_q(self.cross_norm(x, time_cond))
        k, v = self.cross_kv(self.cond_norm(condition)).chunk(2, dim=-1)
        x = x + self.gates[1].tanh() * self.cross_out(self._attn(q, k, v, state_rope, condition_rope))

        x = x + self.gates[2].tanh() * self.mlp(self.mlp_norm(x, time_cond))
        return x


class LatentRefinerDDT(nn.Module):
    def __init__(
        self,
        latent_dim: int = 768,
        depth: int = 8,
        num_heads: int = 12,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
        time_embed_scale: float = 1000.0,
    ) -> None:
        super().__init__()
        if latent_dim % num_heads:
            raise ValueError(f"latent_dim={latent_dim} must be divisible by num_heads={num_heads}")
        if latent_dim // num_heads != 64:
            raise ValueError("LatentRefinerDDT expects 64 channels per attention head")
        self.latent_dim = int(latent_dim)
        self.num_heads = int(num_heads)
        self.time_embed_scale = float(time_embed_scale)

        self.input_proj = nn.Linear(latent_dim, latent_dim)
        self.condition_proj = nn.Linear(latent_dim, latent_dim)
        self.time_mlp = nn.Sequential(
            nn.Linear(latent_dim, 4 * latent_dim),
            nn.SiLU(),
            nn.Linear(4 * latent_dim, latent_dim),
        )
        self.rope = DynamicAxial2DRoPE(latent_dim // num_heads)
        self.blocks = nn.ModuleList(
            [DDTBlock(latent_dim, num_heads, mlp_ratio, dropout) for _ in range(depth)]
        )
        self.output_norm = nn.LayerNorm(latent_dim)
        self.output_proj = zero_init(nn.Linear(latent_dim, latent_dim))

    def _validate(self, name: str, x: torch.Tensor) -> None:
        if x.ndim != 3 or x.shape[-1] != self.latent_dim:
            raise ValueError(f"{name} must be [B,N,{self.latent_dim}], got {tuple(x.shape)}")

    def forward(
        self,
        x_tau: torch.Tensor,
        z_coarse_condition: torch.Tensor,
        tau: torch.Tensor,
        state_grid: Grid | None = None,
        condition_grid: Grid | None = None,
    ) -> torch.Tensor:
        self._validate("x_tau", x_tau)
        self._validate("z_coarse_condition", z_coarse_condition)
        if x_tau.shape[0] != z_coarse_condition.shape[0]:
            raise ValueError("x_tau and z_coarse_condition batch sizes must match")
        if tau.shape != (x_tau.shape[0],):
            raise ValueError(f"tau must be [B], got {tuple(tau.shape)}")
        state_grid = state_grid or infer_grid(x_tau.shape[1])
        condition_grid = condition_grid or infer_grid(z_coarse_condition.shape[1])

        state_rope = self.rope.build_cache(state_grid, x_tau.device)
        condition_rope = self.rope.build_cache(condition_grid, x_tau.device)
        time_cond = self.time_mlp(
            timestep_embedding(tau, self.latent_dim, self.time_embed_scale).to(
                device=x_tau.device,
                dtype=self.time_mlp[0].weight.dtype,
            )
        ).to(dtype=x_tau.dtype)

        x = self.input_proj(x_tau)
        condition = self.condition_proj(z_coarse_condition)
        for block in self.blocks:
            x = block(x, condition, time_cond, state_rope, condition_rope)
        return self.output_proj(self.output_norm(x))

