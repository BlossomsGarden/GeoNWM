from __future__ import annotations

import math
from typing import Any

import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import LambdaLR

try:
    import lightning
except ImportError as exc:  # pragma: no cover - exercised only by training entrypoints
    raise ImportError("lightning is required for latent_refiner_raev2.training") from exc

from .config import RefinerConfig, Scheme
from .curriculum import (
    CHAIN_SCHEDULE,
    average_optimizer_updates_per_data_step,
    chain_length_for_data_step,
    iter_hops,
    should_use_refined_feedback,
)
from .metrics import checkerboard_energy, laplacian_error, rgb_psnr, rgb_ssim
from .modules import LatentRefinerDDT
from .rf import LatentTransforms, endpoint_loss, make_noisy_endpoint, sample_endpoint, validate_latent
from .stats import load_clean_latent_stats


def _as_optimizer(optimizer: Any):
    if isinstance(optimizer, (list, tuple)):
        return optimizer[0]
    return optimizer


class LatentRefinerModule(lightning.LightningModule):
    automatic_optimization = False

    def __init__(
        self,
        scheme: str | Scheme,
        provider: nn.Module,
        backbone: nn.Module | None = None,
        stats_path: str | None = None,
        lr: float = 1.0e-4,
        weight_decay: float = 1.0e-2,
        lr_warmup_optimizer_steps: int = 5000,
        max_optimizer_steps: int | None = None,
        gradient_clip_val: float = 1.0,
        transition_fraction: float = 0.5,
        decode_validation_rgb: bool = True,
        validation_seed: int = 20260908,
        depth: int = 8,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
        time_embed_scale: float = 1000.0,
        sigma_min_loss: float = 0.05,
        sigma_min_sampler: float = 0.001,
        correction_sampling_steps: int = 20,
        full_latent_sampling_steps: int = 25,
    ) -> None:
        super().__init__()
        self.scheme = Scheme.coerce(scheme)
        self.config = RefinerConfig(
            scheme=self.scheme,
            depth=depth,
            mlp_ratio=mlp_ratio,
            dropout=dropout,
            time_embed_scale=time_embed_scale,
            sigma_min_loss=sigma_min_loss,
            sigma_min_sampler=sigma_min_sampler,
            correction_sampling_steps=correction_sampling_steps,
            full_latent_sampling_steps=full_latent_sampling_steps,
        )
        self.config.validate()

        self.provider = provider.eval().requires_grad_(False)
        info = self.provider.codec_info
        if info.family != "raev2" or info.latent_width != 768 or info.num_heads != 12:
            raise ValueError(f"RAEv2 provider codec mismatch: {info}")

        self.backbone = backbone or LatentRefinerDDT(
            latent_dim=768,
            depth=depth,
            num_heads=12,
            mlp_ratio=mlp_ratio,
            dropout=dropout,
            time_embed_scale=time_embed_scale,
        )
        clean_std = load_clean_latent_stats(stats_path, width=768)
        self.register_buffer("full_mean", torch.zeros(768), persistent=True)
        self.register_buffer("full_std", torch.ones(768), persistent=True)
        self.register_buffer("clean_std", clean_std.float(), persistent=True)

        self.lr = float(lr)
        self.weight_decay = float(weight_decay)
        self.lr_warmup_optimizer_steps = int(lr_warmup_optimizer_steps)
        self.max_optimizer_steps = max_optimizer_steps
        self.gradient_clip_val = float(gradient_clip_val)
        self.transition_fraction = float(transition_fraction)
        self.decode_validation_rgb = bool(decode_validation_rgb)
        self.validation_seed = int(validation_seed)

        self.data_step_count = 0
        self.optimizer_step_count = 0
        self.cycle_position = 0
        self.save_hyperparameters(ignore=["provider", "backbone"])

    @property
    def transforms(self) -> LatentTransforms:
        return LatentTransforms(
            scheme=self.scheme,
            codec_family="raev2",
            latent_width=768,
            full_mean=self.full_mean,
            full_std=self.full_std,
            clean_std=self.clean_std,
        )

    def configure_optimizers(self) -> dict[str, Any]:
        optimizer = AdamW(
            [p for p in self.backbone.parameters() if p.requires_grad],
            lr=self.lr,
            weight_decay=self.weight_decay,
        )

        def lr_lambda(step: int) -> float:
            if self.lr_warmup_optimizer_steps <= 0:
                return 1.0
            return min(1.0, float(step + 1) / float(self.lr_warmup_optimizer_steps))

        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": LambdaLR(optimizer, lr_lambda),
                "interval": "step",
            },
        }

    def train(self, mode: bool = True) -> "LatentRefinerModule":
        super().train(mode)
        self.provider.eval().requires_grad_(False)
        self.backbone.train(mode)
        return self

    def _validate_batch(self, frames: torch.Tensor, actions: torch.Tensor) -> None:
        if frames.ndim != 5 or frames.shape[1] != 7:
            raise ValueError(f"expected frames [B,7,3,H,W], got {tuple(frames.shape)}")
        if actions.shape != (frames.shape[0], 6, 3):
            raise ValueError(f"expected actions [B,6,3], got {tuple(actions.shape)}")

    def _max_optimizer_steps(self) -> int:
        if self.max_optimizer_steps is not None:
            return int(self.max_optimizer_steps)
        trainer_steps = int(getattr(self.trainer, "max_steps", 1) or 1)
        return max(1, math.ceil(trainer_steps * average_optimizer_updates_per_data_step()))

    def _step_scheduler(self) -> None:
        scheduler = self.lr_schedulers()
        if scheduler is None:
            return
        if isinstance(scheduler, (list, tuple)):
            for item in scheduler:
                item.step()
            return
        scheduler.step()

    def _optimizer_step(self, loss: torch.Tensor) -> None:
        optimizer = _as_optimizer(self.optimizers())
        optimizer.zero_grad(set_to_none=True)
        self.manual_backward(loss)
        self.clip_gradients(
            optimizer,
            gradient_clip_val=self.gradient_clip_val,
            gradient_clip_algorithm="norm",
        )
        optimizer.step()
        self._step_scheduler()
        self.optimizer_step_count += 1

    def _sample_training_endpoint(self, target: torch.Tensor, condition: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        tau = torch.rand(target.shape[0], device=target.device, dtype=torch.float32)
        x_tau, noise = make_noisy_endpoint(target, tau)
        endpoint_hat = self.backbone(x_tau, condition, tau)
        return endpoint_hat, tau, noise

    def training_step(self, batch: tuple[torch.Tensor, ...], batch_idx: int) -> torch.Tensor:
        frames, actions = batch[:2]
        self._validate_batch(frames, actions)
        with torch.no_grad():
            gt_latents = self.provider.encode_frames(frames).detach()
        if gt_latents.shape[:2] != (frames.shape[0], 7):
            raise ValueError(f"provider returned gt_latents {tuple(gt_latents.shape)}")

        chain_length = chain_length_for_data_step(self.data_step_count)
        use_refined_feedback = should_use_refined_feedback(
            self.optimizer_step_count,
            self._max_optimizer_steps(),
            self.transition_fraction,
        )
        previous = gt_latents[:, 0].detach()
        losses: list[torch.Tensor] = []

        for hop in iter_hops(chain_length):
            hop_actions = actions[:, hop.action_start : hop.action_start + 4].detach()
            target_latent = gt_latents[:, hop.target_index].detach()
            with torch.no_grad():
                z_coarse = self.provider.sample_first_future(previous, hop_actions, num_steps=1).detach()
            validate_latent("z_coarse", z_coarse, 768)

            transforms = self.transforms
            condition = transforms.condition(z_coarse).detach()
            target = transforms.target(target_latent, z_coarse).detach()
            endpoint_hat, tau, _ = self._sample_training_endpoint(target, condition)
            loss = endpoint_loss(endpoint_hat, target, tau, self.config.sigma_min_loss)
            if not torch.isfinite(loss):
                raise ValueError(
                    f"non-finite loss at batch={batch_idx} hop={hop.index} "
                    f"tau=({float(tau.min())},{float(tau.max())}) "
                    f"coarse_norm={float(z_coarse.float().norm())}"
                )
            self._optimizer_step(loss)
            losses.append(loss.detach())

            if not hop.is_last:
                if use_refined_feedback:
                    with torch.no_grad():
                        endpoint_sample = sample_endpoint(
                            self.backbone,
                            condition,
                            num_steps=self.config.sampling_steps,
                            sigma_min_sampler=self.config.sigma_min_sampler,
                        )
                        previous = transforms.finalize(endpoint_sample, z_coarse).detach()
                else:
                    previous = z_coarse.detach()

        mean_loss = torch.stack(losses).mean()
        self.log("train/loss", mean_loss, prog_bar=True, sync_dist=True)
        self.log("train/chain_length", float(chain_length), prog_bar=True, sync_dist=True)
        self.log("train/use_refined_feedback", float(use_refined_feedback), sync_dist=True)
        self.log("train/optimizer_step_count", float(self.optimizer_step_count), sync_dist=True)
        self.data_step_count += 1
        self.cycle_position = self.data_step_count % len(CHAIN_SCHEDULE)
        return mean_loss

    def _generator(self, device: torch.device, seed: int) -> torch.Generator:
        generator = torch.Generator(device=device)
        generator.manual_seed(seed)
        return generator

    def validation_step(self, batch: tuple[torch.Tensor, ...], batch_idx: int, dataloader_idx: int = 0) -> torch.Tensor:
        frames, actions = batch[:2]
        self._validate_batch(frames, actions)
        transforms = self.transforms
        with torch.no_grad():
            gt_latents = self.provider.encode_frames(frames).detach()
            previous_refined = gt_latents[:, 0].detach()
            previous_coarse = gt_latents[:, 0].detach()
            refined_latents = []
            coarse_latents = []
            target_latents = []

            for hop in iter_hops(3):
                hop_actions = actions[:, hop.action_start : hop.action_start + 4].detach()
                seed = self.validation_seed + batch_idx * 17 + hop.index
                coarse_for_refiner = self.provider.sample_first_future(
                    previous_refined,
                    hop_actions,
                    num_steps=1,
                    generator=self._generator(previous_refined.device, seed),
                ).detach()
                coarse_baseline = self.provider.sample_first_future(
                    previous_coarse,
                    hop_actions,
                    num_steps=1,
                    generator=self._generator(previous_coarse.device, seed),
                ).detach()
                condition = transforms.condition(coarse_for_refiner).detach()
                endpoint_sample = sample_endpoint(
                    self.backbone,
                    condition,
                    num_steps=self.config.sampling_steps,
                    sigma_min_sampler=self.config.sigma_min_sampler,
                    generator=self._generator(previous_refined.device, seed + 100000),
                )
                refined = transforms.finalize(endpoint_sample, coarse_for_refiner).detach()
                target = gt_latents[:, hop.target_index].detach()
                refined_latents.append(refined)
                coarse_latents.append(coarse_baseline)
                target_latents.append(target)
                previous_refined = refined
                previous_coarse = coarse_baseline

            refined_seq = torch.stack(refined_latents, dim=1)
            coarse_seq = torch.stack(coarse_latents, dim=1)
            target_seq = torch.stack(target_latents, dim=1)
            refined_norm = transforms.normalized_latent(refined_seq.flatten(0, 1)).reshape_as(refined_seq)
            coarse_norm = transforms.normalized_latent(coarse_seq.flatten(0, 1)).reshape_as(coarse_seq)
            target_norm = transforms.normalized_latent(target_seq.flatten(0, 1)).reshape_as(target_seq)
            refined_mse = (refined_norm.float() - target_norm.float()).square().mean(dim=(2, 3))
            coarse_mse = (coarse_norm.float() - target_norm.float()).square().mean(dim=(2, 3))

        self.log("val/refined_latent_mse", refined_mse.mean(), prog_bar=True, sync_dist=True)
        self.log("val/coarse_latent_mse", coarse_mse.mean(), sync_dist=True)
        for offset in range(refined_seq.shape[1]):
            self.log(f"val/refined_latent_mse_h{offset + 1}", refined_mse[:, offset].mean(), sync_dist=True)
            self.log(f"val/coarse_latent_mse_h{offset + 1}", coarse_mse[:, offset].mean(), sync_dist=True)

        if self.decode_validation_rgb:
            self._log_rgb_validation(frames, refined_seq, coarse_seq)
        return refined_mse.mean()

    def _log_rgb_validation(self, frames: torch.Tensor, refined_seq: torch.Tensor, coarse_seq: torch.Tensor) -> None:
        with torch.no_grad():
            target_rgb = frames[:, 1:4].float()
            if target_rgb.numel() and target_rgb.detach().amax() > 1.5:
                target_rgb = target_rgb / 255.0
            refined_rgb = self.provider.decode_latents(refined_seq).float()
            coarse_rgb = self.provider.decode_latents(coarse_seq).float()
            if refined_rgb.ndim != 5 or coarse_rgb.ndim != 5:
                return
            for name, rgb in (("refined", refined_rgb), ("coarse", coarse_rgb)):
                flat_rgb = rgb.flatten(0, 1)
                flat_target = target_rgb.flatten(0, 1).to(flat_rgb.device)
                self.log(f"val/{name}_rgb_psnr", rgb_psnr(flat_rgb, flat_target).mean(), sync_dist=True)
                self.log(f"val/{name}_rgb_ssim", rgb_ssim(flat_rgb, flat_target).mean(), sync_dist=True)
                self.log(f"val/{name}_laplacian_error", laplacian_error(flat_rgb, flat_target).mean(), sync_dist=True)
                self.log(f"val/{name}_checkerboard_energy", checkerboard_energy(flat_rgb, flat_target).mean(), sync_dist=True)

    def on_save_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        state = checkpoint.get("state_dict")
        if isinstance(state, dict):
            checkpoint["state_dict"] = {
                key: value for key, value in state.items() if not key.startswith("provider.")
            }
        checkpoint["latent_refiner_counters"] = {
            "data_step_count": int(self.data_step_count),
            "optimizer_step_count": int(self.optimizer_step_count),
            "cycle_position": int(self.cycle_position),
        }
        checkpoint["latent_refiner_arch"] = {
            "scheme": self.scheme.value,
            "codec_family": self.config.codec_family,
            "latent_width": self.config.latent_width,
            "num_heads": self.config.num_heads,
            "time_embed_scale": self.config.time_embed_scale,
            "rope_version": self.config.rope_version,
            "sigma_min_loss": self.config.sigma_min_loss,
            "sigma_min_sampler": self.config.sigma_min_sampler,
            "sampling_steps": self.config.sampling_steps,
            "delta_world_sampling_steps": self.config.delta_world_sampling_steps,
            "provider": self.provider.codec_info.__dict__,
        }

    def on_load_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        arch = checkpoint.get("latent_refiner_arch", {})
        expected = {
            "scheme": self.scheme.value,
            "codec_family": self.config.codec_family,
            "latent_width": self.config.latent_width,
            "num_heads": self.config.num_heads,
            "time_embed_scale": self.config.time_embed_scale,
            "rope_version": self.config.rope_version,
            "sigma_min_sampler": self.config.sigma_min_sampler,
            "delta_world_sampling_steps": self.config.delta_world_sampling_steps,
        }
        for key, value in expected.items():
            if key in arch and arch[key] != value:
                raise ValueError(f"checkpoint architecture mismatch for {key}: {arch[key]!r} != {value!r}")
        counters = checkpoint.get("latent_refiner_counters", {})
        self.data_step_count = int(counters.get("data_step_count", self.data_step_count))
        self.optimizer_step_count = int(counters.get("optimizer_step_count", self.optimizer_step_count))
        self.cycle_position = int(counters.get("cycle_position", self.cycle_position))

    def load_state_dict(self, state_dict: dict[str, torch.Tensor], strict: bool = False) -> torch._C._IncompatibleKeys:
        return super().load_state_dict(state_dict, strict=False)


class CorrectionLatentRefinerModule(LatentRefinerModule):
    def __init__(
        self,
        provider: nn.Module,
        backbone: nn.Module | None = None,
        stats_path: str | None = None,
        lr: float = 1.0e-4,
        weight_decay: float = 1.0e-2,
        lr_warmup_optimizer_steps: int = 5000,
        max_optimizer_steps: int | None = None,
        gradient_clip_val: float = 1.0,
        transition_fraction: float = 0.5,
        decode_validation_rgb: bool = True,
        validation_seed: int = 20260908,
        depth: int = 8,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
        time_embed_scale: float = 1000.0,
        sigma_min_loss: float = 0.05,
        sigma_min_sampler: float = 0.001,
        correction_sampling_steps: int = 20,
        full_latent_sampling_steps: int = 25,
    ) -> None:
        super().__init__(
            scheme=Scheme.CORRECTION,
            provider=provider,
            backbone=backbone,
            stats_path=stats_path,
            lr=lr,
            weight_decay=weight_decay,
            lr_warmup_optimizer_steps=lr_warmup_optimizer_steps,
            max_optimizer_steps=max_optimizer_steps,
            gradient_clip_val=gradient_clip_val,
            transition_fraction=transition_fraction,
            decode_validation_rgb=decode_validation_rgb,
            validation_seed=validation_seed,
            depth=depth,
            mlp_ratio=mlp_ratio,
            dropout=dropout,
            time_embed_scale=time_embed_scale,
            sigma_min_loss=sigma_min_loss,
            sigma_min_sampler=sigma_min_sampler,
            correction_sampling_steps=correction_sampling_steps,
            full_latent_sampling_steps=full_latent_sampling_steps,
        )


class FullLatentRefinerModule(LatentRefinerModule):
    def __init__(
        self,
        provider: nn.Module,
        backbone: nn.Module | None = None,
        stats_path: str | None = None,
        lr: float = 1.0e-4,
        weight_decay: float = 1.0e-2,
        lr_warmup_optimizer_steps: int = 5000,
        max_optimizer_steps: int | None = None,
        gradient_clip_val: float = 1.0,
        transition_fraction: float = 0.5,
        decode_validation_rgb: bool = True,
        validation_seed: int = 20260908,
        depth: int = 8,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
        time_embed_scale: float = 1000.0,
        sigma_min_loss: float = 0.05,
        sigma_min_sampler: float = 0.001,
        correction_sampling_steps: int = 20,
        full_latent_sampling_steps: int = 25,
    ) -> None:
        super().__init__(
            scheme=Scheme.FULL_LATENT,
            provider=provider,
            backbone=backbone,
            stats_path=stats_path,
            lr=lr,
            weight_decay=weight_decay,
            lr_warmup_optimizer_steps=lr_warmup_optimizer_steps,
            max_optimizer_steps=max_optimizer_steps,
            gradient_clip_val=gradient_clip_val,
            transition_fraction=transition_fraction,
            decode_validation_rgb=decode_validation_rgb,
            validation_seed=validation_seed,
            depth=depth,
            mlp_ratio=mlp_ratio,
            dropout=dropout,
            time_embed_scale=time_embed_scale,
            sigma_min_loss=sigma_min_loss,
            sigma_min_sampler=sigma_min_sampler,
            correction_sampling_steps=correction_sampling_steps,
            full_latent_sampling_steps=full_latent_sampling_steps,
        )
