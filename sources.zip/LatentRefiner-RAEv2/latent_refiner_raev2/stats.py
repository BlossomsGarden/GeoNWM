from __future__ import annotations

from pathlib import Path

import torch


def _clamp_std(std: torch.Tensor) -> torch.Tensor:
    std = std.float()
    median = torch.median(std)
    if not torch.isfinite(median) or median <= 0:
        raise ValueError("latent std median must be positive and finite")
    return std.clamp(0.1 * median, 10.0 * median)


def load_clean_latent_stats(path: str | Path | None, width: int) -> torch.Tensor:
    if path is None:
        return torch.ones(width)
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict):
        raise TypeError(f"unsupported latent stats format: {path}")
    std = payload.get("clean_std", payload.get("clamped_std", payload.get("std", payload.get("raw_std"))))
    if std is None:
        raise ValueError(f"latent stats at {path} must contain clean_std, std, clamped_std, or raw_std")
    std = torch.as_tensor(std).float().flatten()
    if std.numel() != width:
        raise ValueError(f"latent std width {std.numel()} != expected {width}")
    return _clamp_std(std)

