from __future__ import annotations

import math

import torch
import torch.nn.functional as F


def latent_mse(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch: pred={tuple(pred.shape)} target={tuple(target.shape)}")
    return (pred.float() - target.float()).square().mean(dim=tuple(range(1, pred.ndim)))


def psnr_from_mse(mse: torch.Tensor, max_value: float = 1.0) -> torch.Tensor:
    return 10.0 * torch.log10(torch.tensor(max_value * max_value, device=mse.device) / mse.clamp_min(1.0e-12))


def rgb_psnr(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    mse = (pred.float() - target.float()).square().flatten(1).mean(dim=1)
    return psnr_from_mse(mse)


def rgb_ssim(pred: torch.Tensor, target: torch.Tensor, window_size: int = 11) -> torch.Tensor:
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch: pred={tuple(pred.shape)} target={tuple(target.shape)}")
    channels = pred.shape[1]
    pad = window_size // 2
    weight = torch.ones(channels, 1, window_size, window_size, device=pred.device, dtype=pred.dtype)
    weight = weight / float(window_size * window_size)
    pred = pred.float()
    target = target.float()
    weight = weight.float()
    mu_x = F.conv2d(pred, weight, padding=pad, groups=channels)
    mu_y = F.conv2d(target, weight, padding=pad, groups=channels)
    sigma_x = F.conv2d(pred * pred, weight, padding=pad, groups=channels) - mu_x.square()
    sigma_y = F.conv2d(target * target, weight, padding=pad, groups=channels) - mu_y.square()
    sigma_xy = F.conv2d(pred * target, weight, padding=pad, groups=channels) - mu_x * mu_y
    c1 = 0.01**2
    c2 = 0.03**2
    value = ((2 * mu_x * mu_y + c1) * (2 * sigma_xy + c2)) / (
        (mu_x.square() + mu_y.square() + c1) * (sigma_x + sigma_y + c2)
    )
    return value.flatten(1).mean(dim=1)


def laplacian_error(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch: pred={tuple(pred.shape)} target={tuple(target.shape)}")
    channels = pred.shape[1]
    kernel = pred.new_tensor([[0.0, 1.0, 0.0], [1.0, -4.0, 1.0], [0.0, 1.0, 0.0]])
    kernel = kernel.view(1, 1, 3, 3).repeat(channels, 1, 1, 1)
    pred_lap = F.conv2d(pred.float(), kernel.float(), padding=1, groups=channels)
    target_lap = F.conv2d(target.float(), kernel.float(), padding=1, groups=channels)
    return (pred_lap - target_lap).abs().flatten(1).mean(dim=1)


def checkerboard_energy(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch: pred={tuple(pred.shape)} target={tuple(target.shape)}")
    error = pred.float() - target.float()
    height, width = error.shape[-2:]
    row = torch.arange(height, device=error.device).view(1, 1, height, 1)
    col = torch.arange(width, device=error.device).view(1, 1, 1, width)
    sign = ((row + col) % 2).float() * 2.0 - 1.0
    energy = (error * sign).flatten(1).mean(dim=1).abs()
    return energy / error.abs().flatten(1).mean(dim=1).clamp_min(1.0e-8)


def as_float(value: torch.Tensor) -> float:
    return float(value.detach().float().mean().cpu().item()) if value.numel() else math.nan

