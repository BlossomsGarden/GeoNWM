import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from latent_refiner_raev2.rope import DynamicAxial2DRoPE


def test_rope_preserves_norm_for_raev2_heads():
    rope = DynamicAxial2DRoPE(head_dim=64)
    cache = rope.build_cache((4, 4), torch.device("cpu"))
    x = torch.randn(2, 12, 16, 64)

    y = rope.apply(x, cache)

    assert y.shape == x.shape
    assert torch.allclose(y.float().norm(dim=-1), x.float().norm(dim=-1), atol=1.0e-5)


def test_rope_keeps_row_and_column_halves_isolated():
    rope = DynamicAxial2DRoPE(head_dim=64)
    cache = rope.build_cache((4, 4), torch.device("cpu"))

    row_only = torch.zeros(1, 12, 16, 64)
    row_only[..., :32] = torch.randn(1, 12, 16, 32)
    row_rotated = rope.apply(row_only, cache)
    assert torch.allclose(row_rotated[..., 32:], torch.zeros_like(row_rotated[..., 32:]))

    col_only = torch.zeros(1, 12, 16, 64)
    col_only[..., 32:] = torch.randn(1, 12, 16, 32)
    col_rotated = rope.apply(col_only, cache)
    assert torch.allclose(col_rotated[..., :32], torch.zeros_like(col_rotated[..., :32]))

