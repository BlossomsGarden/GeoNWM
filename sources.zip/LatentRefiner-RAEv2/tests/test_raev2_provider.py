import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from latent_refiner_raev2.providers import RAEV2_PROVIDER_ERROR, UnavailableRAEv2DeltaWorldProvider


def test_unavailable_provider_fails_clearly():
    try:
        UnavailableRAEv2DeltaWorldProvider()
    except RuntimeError as exc:
        assert str(exc) == RAEV2_PROVIDER_ERROR
    else:
        raise AssertionError("expected unavailable provider to raise")

