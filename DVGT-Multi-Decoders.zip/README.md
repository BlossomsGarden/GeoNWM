# DVGT Multi-Decoders on nuScenes

This project trains downstream decoders on frozen DVGT-1 features for nuScenes surround-view data at `704x256`.

The current training layout is:

- RGB reconstruction is trained by one RGB decoder with the GLD-style reconstruction recipe.
- Geometry is trained jointly with three task decoders: depth, semantic, and occupancy. All three decoders consume the raw four-level DVGT concat token directly (`3072*4=12288`) without a shared bottleneck adapter.
- DVGT-1 is always frozen and is never saved inside decoder checkpoints.
- Training uses variable-frame batches instead of fixed `T=8`.

## Data and Weights

The config files contain all remote paths:

```yaml
paths:
  dvgt_ckpt_path: /data/wlh/GLD/DVGT-model/DVGT-1/dvgt1.pt
  results_dir: results/stage1-nuscenes-704x256
data:
  nuscenes_root: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval
  table_dir: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval/v1.0-trainval
  depth_root: /data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth
  lidarseg_root: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval/lidarseg
  occupancy_root: /data/wlh/SurroundOcc/nuscenes_occ
  semantic_classes: 17
  occupancy_classes: 17
```

RGB additionally needs local LPIPS/VGG/DINO discriminator weights configured in
`configs/stage1_rgb_nuscenes_704x256.yaml`.

## Variable-Frame Training

Both RGB and Geometry use batch-level variable sequence sampling:

```yaml
sequence_sampling:
  enabled: true
  lengths: [1, 2, 4]
  probs: [0.6, 0.3, 0.1]
```

The sampler chooses one `T` per batch, then all samples in that batch use the same number of continuous frames.
This keeps collation simple and mirrors DVGT's dynamic-frame training style.

Dynamic batch sizes are controlled by camera-image budget per GPU:

- RGB: `max_camera_images_per_gpu: 24`
- Geometry: `max_camera_images_per_gpu: 24`

With six cameras, RGB uses local batch sizes `4/2/1` for `T=1/2/4`; Geometry also uses `4/2/1`.
`36` camera-images/GPU OOMed during the occupancy upsample, and `30` was still too close to the 24 GB limit for longer formal runs. `24` keeps all sampled frame lengths at roughly the same camera-image load per GPU.

RGB also applies GLD's level-wise feature dropout during training:

```yaml
dvgt:
  token_dim_per_level: 3072
  level_dropout_prob: 0.5
  level_dropout_min_keep: 1
```

This randomly masks complete DVGT feature levels in the concatenated latent while always leaving at least one level available. It is separate from transformer hidden/attention dropout.

## DriveTok Alignment

The implementation follows DriveTok's task supervision where it fits this DVGT-decoder setup:

- RGB: L1 + LPIPS + adversarial reconstruction loss from the start of training, matching the GLD decoder recipe. The decoder remains the integrated GLD MAE decoder rather than DriveTok's DPT head.
- Depth: aligned MoGe dense depth with masked Charbonnier and gradient consistency.
- Semantic: projected LiDARSeg labels with cross-entropy and `ignore_index=255`. The image-space semantic head uses 17 labels where `0=other/noise` and `1..16` follow the nuScenes occupancy semantic order.
- Occupancy: SurroundOcc sparse occupancy labels are densified with `0=empty/non-occupied`, sparse label `0 -> 255 ignore`, and `1..16` as occupied semantic classes. This gives empty voxels an explicit CE penalty so the decoder is trained not to hallucinate occupancy in free space. CE uses a reduced empty-class weight, while Lovasz-Softmax skips empty and focuses on occupied semantic IoU.
- Geometry joint training: depth, semantic, and occupancy losses update only their own task decoders. There is no shared adapter or token compression in front of the decoders, so the run measures the direct decode upper bound from the frozen DVGT concat token.

DriveTok's latent semantic regularization is not copied directly because DriveTok regularizes BEV scene tokens, while this project uses frozen DVGT image patch tokens.

A remote label audit over 200 samples found SurroundOcc sparse labels in `0..16`; the sparse `0` label is handled as ignore, not as dense empty space. LiDARSeg maps into `0..16` too, but its class `0` is image-space `other/noise`, while occupancy class `0` is free/empty.

The occupancy decoder intentionally does not consume camera intrinsics or extrinsics. To better follow DVGT-1's special-token design, each view feature is modulated by a learned view token and a lightweight cross-view transformer before BEV fusion. It also conditions on the current depth decoder logits: depth logits are converted with `softplus`, compressed with `log1p`, downsampled to the DVGT patch grid, and projected into the occupancy feature stream. The condition is detached by default so occupancy gradients do not destabilize the depth decoder.

Occupancy loss starts at `global_step=2000`. Before that point, the training loop optimizes only depth and semantic losses; the occupancy branch still runs with a zero loss term so DDP sees the parameters, but no occupancy supervision is applied. This lets the depth decoder become a useful condition before occupancy supervision is introduced.

## GLD-Style RGB Alignment

The RGB decoder follows the official GLD stage-1 decoder code where it is compatible with DVGT features:

- The decoder config is ViT-XL: 28 decoder blocks, decoder hidden size 1152, FFN size 4096, 16 heads, and hidden/attention dropout 0.0.
- `patch_size: 16` is kept because DVGT-1 patch tokens are on a 16-pixel grid. GLD's DA3 config uses patch size 14 for DA3.
- The 0.5 dropout mentioned in GLD Sec. 4.2 is implemented as level-wise feature dropout, not as transformer dropout.
- RGB loss starts with L1, LPIPS, and GAN active from step 0. The discriminator uses the GLD/StyleGAN-T recipe with differentiable augmentation and the configured DINO `S_8` checkpoint.
- Images are loaded in `[0,1]`, DVGT performs its own input normalization internally, and RGB reconstruction is supervised after converting decoder output from ImageNet-normalized pixels back to `[0,1]`.
- DVGT feature `per_level_layernorm` is retained to stabilize frozen DVGT layer scales. GLD's channel-wise zero-mean/unit-variance feature statistics are used before diffusion training, not for the stage-1 RGB decoder.

## Checkpoints

Checkpoints are saved only at configured step intervals. There is no `last.pt`.

RGB:

```text
results/stage1-nuscenes-704x256/rgb/checkpoints/step_XXXXXXXX.pt
```

The RGB checkpoint contains only:

- one RGB decoder `model` state, using EMA weights when EMA is enabled
- step, epoch, config metadata

It does not contain DVGT-1, optimizer state, scheduler state, discriminator state, or a second raw/EMA copy for resume.

Geometry:

```text
results/stage1-nuscenes-704x256/geometry/checkpoints/step_XXXXXXXX.pt
```

Each geometry checkpoint contains one full `GeometryDecoders` model state: depth decoder, semantic decoder, and occupancy decoder together, plus metadata. When EMA is enabled, the saved `model` state is the EMA geometry decoder; otherwise it is the raw training model.
It does not contain DVGT-1, optimizer state, scheduler state, or discriminator state.

Geometry checkpoints produced before the adapter removal or before the single-checkpoint geometry format are not loadable by the current eval script. Start a fresh geometry run and do not mix old geometry decoder checkpoints with this no-adapter setup.

## Remote Upload

`scripts/upload_remote.py` can upload this project to the training server.
Use `--clean-remote` for fresh experiments so deleted local files do not remain on the server:

```bash
python scripts/upload_remote.py --clean-remote
```

This deletes `/data/wlh/GLD/code/DVGT-Multi-Decoders` before uploading the local tree.
The uploader skips local `results/`, `logs/`, `__pycache__/`, and `.pytest_cache/`.

## Training

Run from `/data/wlh/GLD/code/DVGT-Multi-Decoders` on the remote server.

RGB formal training on GPUs 4 and 5:

```bash
GPUS=4,5 NPROC_PER_NODE=2 \
CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
nohup setsid bash scripts/start_stage1_rgb_2gpu_ddp.sh > logs/rgb_formal_launcher.log 2>&1 &
```

Geometry formal training on GPUs 6 and 7:

```bash
GPUS=6,7 NPROC_PER_NODE=2 \
CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
nohup setsid bash scripts/start_stage1_geometry_2gpu_ddp.sh > logs/geometry_formal_launcher.log 2>&1 &
```

Short gate runs can override step intervals:

```bash
GPUS=4,5 NPROC_PER_NODE=2 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_stage1_rgb_2gpu_ddp.sh --max-steps 2 --ckpt-interval 2 --val-batches 1

GPUS=6,7 NPROC_PER_NODE=2 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_stage1_geometry_2gpu_ddp.sh --max-steps 2 --ckpt-interval 2 --val-batches 1
```

## Evaluation

RGB evaluation loads frozen DVGT-1 plus the latest RGB decoder step checkpoint by default:

```bash
python scripts/eval_rgb.py --num-samples 8 --num-workers 2 --precision bf16
```

It saves RGB visualizations, including two randomly selected qualitative summaries under
`eval_rgb_step_*/qualitative_random/`, and reports L1, PSNR, and SSIM.

Geometry evaluation loads frozen DVGT-1 and the latest full geometry decoder checkpoint:

```bash
python scripts/eval_geometry.py --modality all --num-samples 128 --num-workers 2 --precision bf16
```

Use `--ckpt /path/to/step_XXXXXXXX.pt` to evaluate a specific geometry checkpoint, or `--ckpt-root /path/to/checkpoints` to choose the latest `step_*.pt` under a directory. The eval script no longer accepts separate depth, semantic, or occupancy checkpoints.

It also plots the geometry training losses from `geometry/reports/metrics.csv` directly to
`geometry/reports/loss_curve.png`, and saves two randomly selected qualitative summaries under
`geometry/eval/*/qualitative_random/`. For each selected sample it writes a combined view summary plus
separate depth, semantic, and occupancy BEV PNGs when those modalities are evaluated.

It reports:

- Depth: L1 and AbsRel
- Semantic: CE, pixel accuracy, mIoU
- Occupancy: CE, voxel accuracy, mIoU over occupied semantic classes, all-class mIoU including empty, and binary occupied IoU

## Remote Server

Connection and data roots are documented in `REMOTE_SERVER.md`.
Current recommended formal allocation is RGB on GPUs `4,5` and Geometry on GPUs `6,7`, because those 24 GB cards are idle in the latest check.
