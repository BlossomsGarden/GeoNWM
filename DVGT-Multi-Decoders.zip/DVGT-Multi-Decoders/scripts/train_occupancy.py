#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.models import BEVOccupancyDecoder, DVGTFeatureExtractor
from dvgt_multimodal.utils import (
    append_csv,
    build_loader,
    build_optimizer_and_scheduler,
    create_ema,
    densify_occupancy,
    get_device,
    load_decoder_state,
    precision_context,
    save_checkpoint,
    save_json,
    setup_logger,
    update_ema,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_occupancy_nuscenes_704x256.yaml"))
    parser.add_argument("--results-dir", default=None)
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--val-batches", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    return parser.parse_args()


@torch.no_grad()
def validate(dvgt, decoder, loader, device, precision, max_batches, cfg):
    decoder.eval()
    total_correct = total_valid = total_loss = 0.0
    for i, batch in enumerate(tqdm(loader, desc="val", leave=False)):
        if i >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        b, _, _, _, _ = images.shape
        target = densify_occupancy(batch["occupancy_sparse"], shape=tuple(int(x) for x in cfg.occupancy.grid_shape), ignore_index=int(cfg.loss.ignore_index), device=device)
        with precision_context(device, precision):
            logits = decoder(dvgt(images), batch_size=b)
        loss = F.cross_entropy(logits.float(), target, ignore_index=int(cfg.loss.ignore_index))
        pred = logits.argmax(dim=1)
        valid = target != int(cfg.loss.ignore_index)
        total_loss += loss.item()
        total_correct += ((pred == target) & valid).sum().item()
        total_valid += valid.sum().item()
    decoder.train()
    return {"val/ce": total_loss / max(max_batches, 1), "val/voxel_acc": total_correct / max(total_valid, 1.0), "val/valid_voxels": total_valid}


def main():
    args = parse_args()
    cfg = OmegaConf.load(args.config)
    if args.num_workers is not None:
        cfg.training.num_workers = args.num_workers
    precision = args.precision or str(cfg.training.precision)
    torch.manual_seed(int(cfg.training.get("seed", 0)))
    device = get_device()
    exp_dir = Path(args.results_dir or cfg.paths.results_dir) / "occupancy"
    logger = setup_logger(exp_dir)

    train_loader = build_loader(cfg, "train", require={"occupancy": True}, max_samples=cfg.training.get("max_train_samples"))
    val_loader = build_loader(cfg, "val", require={"occupancy": True}, max_samples=cfg.training.get("max_val_samples"))
    steps_per_epoch = len(train_loader)
    dvgt = DVGTFeatureExtractor(str(cfg.paths.dvgt_code_dir), str(cfg.paths.dvgt_ckpt_dir), list(cfg.dvgt.feature_indices), bool(cfg.dvgt.per_level_layernorm), device)
    decoder = BEVOccupancyDecoder(
        in_dim=int(cfg.decoder.hidden_size),
        num_classes=int(cfg.data.semantic_classes),
        num_views=6,
        image_size=(int(cfg.data.image_size[1]), int(cfg.data.image_size[0])),
        patch_size=int(cfg.decoder.patch_size),
        bev_h=int(cfg.occupancy.grid_shape[1]),
        bev_w=int(cfg.occupancy.grid_shape[2]),
        occ_z=int(cfg.occupancy.grid_shape[0]),
        hidden_dim=int(cfg.decoder.hidden_dim),
    ).to(device)
    ema = create_ema(decoder, bool(cfg.training.get("ema", True)))
    optimizer, scheduler = build_optimizer_and_scheduler(decoder, cfg, steps_per_epoch)
    if args.ckpt:
        load_decoder_state(args.ckpt, decoder, prefer_ema=False)
    global_step = 0
    ignore_index = int(cfg.loss.ignore_index)
    metrics_csv = exp_dir / "reports/metrics.csv"
    for epoch in range(int(cfg.training.epochs)):
        for batch in tqdm(train_loader, desc=f"occupancy epoch {epoch}"):
            images = batch["images"].to(device, non_blocking=True)
            b = images.shape[0]
            target = densify_occupancy(batch["occupancy_sparse"], shape=tuple(int(x) for x in cfg.occupancy.grid_shape), ignore_index=ignore_index, device=device)
            optimizer.zero_grad(set_to_none=True)
            with precision_context(device, precision):
                with torch.no_grad():
                    tokens = dvgt(images)
                logits = decoder(tokens, batch_size=b)
                loss = F.cross_entropy(logits.float(), target, ignore_index=ignore_index)
            loss.backward()
            if float(cfg.training.get("clip_grad", 0.0)) > 0:
                torch.nn.utils.clip_grad_norm_(decoder.parameters(), float(cfg.training.clip_grad))
            optimizer.step()
            if scheduler is not None:
                scheduler.step()
            update_ema(ema, decoder, float(cfg.training.get("ema_decay", 0.9978)))
            valid = (target != ignore_index).sum().item()
            if global_step % int(cfg.training.log_interval) == 0:
                row = {"step": global_step, "epoch": epoch, "loss/ce": float(loss.item()), "valid_voxels": valid, "lr": optimizer.param_groups[0]["lr"]}
                logger.info(", ".join(f"{k}={v:.6f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
                append_csv(metrics_csv, row)
            global_step += 1
            if global_step % int(cfg.training.val_interval) == 0:
                metrics = validate(dvgt, ema or decoder, val_loader, device, precision, args.val_batches or int(cfg.reporting.val_batches), cfg)
                metrics["step"] = global_step
                save_json(exp_dir / f"reports/eval/step_{global_step:07d}.json", metrics)
                logger.info("[val] " + ", ".join(f"{k}={v:.6f}" for k, v in metrics.items() if isinstance(v, float)))
            if global_step % int(cfg.training.ckpt_interval) == 0:
                save_checkpoint(exp_dir / f"checkpoints/step_{global_step:07d}.pt", "occupancy", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
            if args.max_steps is not None and global_step >= args.max_steps:
                save_checkpoint(exp_dir / "checkpoints/smoke_last.pt", "occupancy", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
                return
        save_checkpoint(exp_dir / f"checkpoints/epoch_{epoch + 1:04d}.pt", "occupancy", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)


if __name__ == "__main__":
    main()

