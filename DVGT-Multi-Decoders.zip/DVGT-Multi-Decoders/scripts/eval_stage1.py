#!/usr/bin/env python
from __future__ import annotations

from visualize_stage1 import main


if __name__ == "__main__":
    main()
