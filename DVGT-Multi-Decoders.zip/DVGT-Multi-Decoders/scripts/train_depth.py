#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.models import DVGTFeatureExtractor, PatchTokenDecoder
from dvgt_multimodal.utils import (
    append_csv,
    build_loader,
    build_optimizer_and_scheduler,
    create_ema,
    depth_gradient_loss,
    get_device,
    load_decoder_state,
    masked_charbonnier,
    precision_context,
    save_checkpoint,
    save_json,
    setup_logger,
    update_ema,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_depth_nuscenes_704x256.yaml"))
    parser.add_argument("--results-dir", default=None)
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--val-batches", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    return parser.parse_args()


@torch.no_grad()
def validate(dvgt, decoder, loader, device, precision, max_batches):
    decoder.eval()
    total_absrel = total_l1 = count = 0.0
    for i, batch in enumerate(tqdm(loader, desc="val", leave=False)):
        if i >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        depth = batch["depth"].to(device, non_blocking=True)
        mask = batch["depth_mask"].to(device, non_blocking=True)
        b, v, _, h, w = images.shape
        with precision_context(device, precision):
            pred = torch.nn.functional.softplus(decoder(dvgt(images), image_size=(h, w)))
        gt = depth.reshape(b * v, 1, h, w)
        mk = mask.reshape(b * v, 1, h, w)
        denom = mk.sum().clamp_min(1.0)
        total_l1 += ((pred - gt).abs() * mk).sum().item()
        total_absrel += (((pred - gt).abs() / gt.clamp_min(1e-3)) * mk).sum().item()
        count += denom.item()
    decoder.train()
    return {"val/depth_l1": total_l1 / max(count, 1.0), "val/absrel": total_absrel / max(count, 1.0), "val/pixels": count}


def main():
    args = parse_args()
    cfg = OmegaConf.load(args.config)
    if args.num_workers is not None:
        cfg.training.num_workers = args.num_workers
    precision = args.precision or str(cfg.training.precision)
    torch.manual_seed(int(cfg.training.get("seed", 0)))
    device = get_device()
    exp_dir = Path(args.results_dir or cfg.paths.results_dir) / "depth"
    logger = setup_logger(exp_dir)

    train_loader = build_loader(cfg, "train", require={"depth": True}, max_samples=cfg.training.get("max_train_samples"))
    val_loader = build_loader(cfg, "val", require={"depth": True}, max_samples=cfg.training.get("max_val_samples"))
    steps_per_epoch = len(train_loader)
    dvgt = DVGTFeatureExtractor(str(cfg.paths.dvgt_code_dir), str(cfg.paths.dvgt_ckpt_dir), list(cfg.dvgt.feature_indices), bool(cfg.dvgt.per_level_layernorm), device)
    decoder = PatchTokenDecoder(
        str(cfg.paths.gld_src_dir),
        str(ROOT / cfg.decoder.config_path),
        int(cfg.decoder.hidden_size),
        1,
        int(cfg.decoder.patch_size),
        tuple(int(x) for x in cfg.decoder.base_image_size),
        cfg.decoder.get("decoder_hidden_size"),
        cfg.decoder.get("decoder_layers"),
        cfg.decoder.get("decoder_heads"),
    ).to(device)
    ema = create_ema(decoder, bool(cfg.training.get("ema", True)))
    optimizer, scheduler = build_optimizer_and_scheduler(decoder, cfg, steps_per_epoch)
    if args.ckpt:
        load_decoder_state(args.ckpt, decoder, prefer_ema=False)
    global_step = 0
    metrics_csv = exp_dir / "reports/metrics.csv"
    for epoch in range(int(cfg.training.epochs)):
        for batch in tqdm(train_loader, desc=f"depth epoch {epoch}"):
            images = batch["images"].to(device, non_blocking=True)
            depth = batch["depth"].to(device, non_blocking=True)
            mask = batch["depth_mask"].to(device, non_blocking=True)
            b, v, _, h, w = images.shape
            gt = depth.reshape(b * v, 1, h, w)
            mk = mask.reshape(b * v, 1, h, w)
            optimizer.zero_grad(set_to_none=True)
            with precision_context(device, precision):
                with torch.no_grad():
                    tokens = dvgt(images)
                pred = torch.nn.functional.softplus(decoder(tokens, image_size=(h, w)))
                charbonnier = masked_charbonnier(pred, gt, mk, float(cfg.loss.charbonnier_eps))
                grad = depth_gradient_loss(pred, gt, mk)
                loss = charbonnier + float(cfg.loss.gradient_weight) * grad
            loss.backward()
            if float(cfg.training.get("clip_grad", 0.0)) > 0:
                torch.nn.utils.clip_grad_norm_(decoder.parameters(), float(cfg.training.clip_grad))
            optimizer.step()
            if scheduler is not None:
                scheduler.step()
            update_ema(ema, decoder, float(cfg.training.get("ema_decay", 0.9978)))
            if global_step % int(cfg.training.log_interval) == 0:
                row = {"step": global_step, "epoch": epoch, "loss/total": float(loss.item()), "loss/charbonnier": float(charbonnier.item()), "loss/gradient": float(grad.item()), "lr": optimizer.param_groups[0]["lr"]}
                logger.info(", ".join(f"{k}={v:.6f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
                append_csv(metrics_csv, row)
            global_step += 1
            if global_step % int(cfg.training.val_interval) == 0:
                metrics = validate(dvgt, ema or decoder, val_loader, device, precision, args.val_batches or int(cfg.reporting.val_batches))
                metrics["step"] = global_step
                save_json(exp_dir / f"reports/eval/step_{global_step:07d}.json", metrics)
                logger.info("[val] " + ", ".join(f"{k}={v:.6f}" for k, v in metrics.items() if isinstance(v, float)))
            if global_step % int(cfg.training.ckpt_interval) == 0:
                save_checkpoint(exp_dir / f"checkpoints/step_{global_step:07d}.pt", "depth", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
            if args.max_steps is not None and global_step >= args.max_steps:
                save_checkpoint(exp_dir / "checkpoints/smoke_last.pt", "depth", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
                return
        save_checkpoint(exp_dir / f"checkpoints/epoch_{epoch + 1:04d}.pt", "depth", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)


if __name__ == "__main__":
    main()

