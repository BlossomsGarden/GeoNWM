#!/bin/bash
set -u -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONDA_SH="${CONDA_SH:-}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-gld}"
LOG_DIR="${LOG_DIR:-${PROJECT_DIR}/logs/stage1_8gpu_ddp}"
NNODES="${NNODES:-1}"
NPROC_PER_NODE="${NPROC_PER_NODE:-2}"
MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
BASE_PORT="${BASE_PORT:-29510}"
PYTHON_BIN="${PYTHON_BIN:-python}"
TORCHRUN_BIN="${TORCHRUN_BIN:-torchrun}"

COMMON_ARGS=("$@")

mkdir -p "${LOG_DIR}"

if [[ -n "${CONDA_SH}" && -f "${CONDA_SH}" ]]; then
  set +u
  source "${CONDA_SH}"
  conda activate "${CONDA_ENV_NAME}"
  set -u
fi

export PYTHONPATH="${PROJECT_DIR}:${PYTHONPATH:-}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

cd "${PROJECT_DIR}"

declare -a JOB_NAMES=("rgb" "depth" "semantic" "occupancy")
declare -a JOB_GPUS=("0,1" "2,3" "4,5" "6,7")
declare -a JOB_SCRIPTS=(
  "scripts/train_rgb.py"
  "scripts/train_depth.py"
  "scripts/train_semantic.py"
  "scripts/train_occupancy.py"
)
declare -a JOB_CONFIGS=(
  "configs/stage1_rgb_nuscenes_704x256.yaml"
  "configs/stage1_depth_nuscenes_704x256.yaml"
  "configs/stage1_semantic_nuscenes_704x256.yaml"
  "configs/stage1_occupancy_nuscenes_704x256.yaml"
)

declare -a PIDS=()
declare -a PID_NAMES=()

stop_children() {
  echo "Stopping child jobs..." >&2
  for pid in "${PIDS[@]:-}"; do
    if kill -0 "${pid}" 2>/dev/null; then
      kill "${pid}" 2>/dev/null || true
    fi
  done
}
trap stop_children INT TERM

start_job() {
  local idx="$1"
  local name="${JOB_NAMES[$idx]}"
  local gpus="${JOB_GPUS[$idx]}"
  local script="${JOB_SCRIPTS[$idx]}"
  local config="${JOB_CONFIGS[$idx]}"
  local port=$((BASE_PORT + idx * 10))
  local log_file="${LOG_DIR}/train_${name}.log"
  local pid_file="${LOG_DIR}/train_${name}.pid"
  local exit_file="${LOG_DIR}/train_${name}.exit"

  rm -f "${pid_file}" "${exit_file}"
  echo "Starting ${name} on CUDA_VISIBLE_DEVICES=${gpus}, master_port=${port}"
  (
    set -e
    export CUDA_VISIBLE_DEVICES="${gpus}"
    export MASTER_ADDR="${MASTER_ADDR}"
    "${TORCHRUN_BIN}" \
      --nnodes="${NNODES}" \
      --nproc_per_node="${NPROC_PER_NODE}" \
      --master_addr="${MASTER_ADDR}" \
      --master_port="${port}" \
      "${script}" \
      --config "${config}" \
      "${COMMON_ARGS[@]}"
  ) > "${log_file}" 2>&1 &

  local pid=$!
  echo "${pid}" > "${pid_file}"
  PIDS+=("${pid}")
  PID_NAMES+=("${name}")
  echo "  pid=${pid}"
  echo "  log=${log_file}"
}

for idx in "${!JOB_NAMES[@]}"; do
  start_job "${idx}"
done

echo "All Stage 1 jobs launched. Waiting for completion..."
overall_status=0
for idx in "${!PIDS[@]}"; do
  pid="${PIDS[$idx]}"
  name="${PID_NAMES[$idx]}"
  exit_file="${LOG_DIR}/train_${name}.exit"
  if wait "${pid}"; then
    status=0
    echo "${status}" > "${exit_file}"
    echo "${name} finished successfully."
  else
    status=$?
    echo "${status}" > "${exit_file}"
    echo "${name} failed with exit code ${status}. See ${LOG_DIR}/train_${name}.log" >&2
    overall_status=1
  fi
done

if [[ "${overall_status}" -eq 0 ]]; then
  echo "All Stage 1 jobs completed successfully."
else
  echo "One or more Stage 1 jobs failed." >&2
fi

exit "${overall_status}"
