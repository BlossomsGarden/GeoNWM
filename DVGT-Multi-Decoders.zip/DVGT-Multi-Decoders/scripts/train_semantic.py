#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.distributed import any_rank_true, barrier, cleanup_distributed, init_distributed, set_loader_epoch, wrap_ddp
from dvgt_multimodal.models import DVGTFeatureExtractor, PatchTokenDecoder
from dvgt_multimodal.utils import (
    append_csv,
    build_loader,
    build_optimizer_and_scheduler,
    create_ema,
    load_decoder_state,
    precision_context,
    require_stage1_sequence_images,
    resolve_project_path,
    save_checkpoint,
    save_json,
    setup_logger,
    update_ema,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_semantic_nuscenes_704x256.yaml"))
    parser.add_argument("--results-dir", default=None)
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--max-duration-seconds", type=float, default=None)
    parser.add_argument("--val-batches", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    return parser.parse_args()


@torch.no_grad()
def validate(dvgt, decoder, loader, device, precision, max_batches, ignore_index):
    decoder.eval()
    total_correct = total_valid = total_loss = 0.0
    for i, batch in enumerate(tqdm(loader, desc="val", leave=False)):
        if i >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        target = batch["semantic"].to(device, non_blocking=True)
        b, t, v, _, h, w = require_stage1_sequence_images(images, "Semantic validation")
        with precision_context(device, precision):
            tokens = dvgt(images)
            tokens = tokens.reshape(b * t * v, tokens.shape[-2], tokens.shape[-1])
            logits = decoder(tokens, image_size=(h, w))
        y = target.reshape(b * t * v, h, w)
        loss = F.cross_entropy(logits.float(), y, ignore_index=ignore_index)
        pred = logits.argmax(dim=1)
        valid = y != ignore_index
        total_loss += loss.item()
        total_correct += ((pred == y) & valid).sum().item()
        total_valid += valid.sum().item()
    decoder.train()
    return {"val/ce": total_loss / max(max_batches, 1), "val/pixel_acc": total_correct / max(total_valid, 1.0), "val/valid_pixels": total_valid}


def main():
    args = parse_args()
    dist_ctx = init_distributed()
    cfg = OmegaConf.load(args.config)
    if args.num_workers is not None:
        cfg.training.num_workers = args.num_workers
    if args.batch_size is not None:
        cfg.training.batch_size = args.batch_size
    precision = args.precision or str(cfg.training.precision)
    torch.manual_seed(int(cfg.training.get("seed", 0)) + dist_ctx.rank)
    device = dist_ctx.device
    out_root = Path(args.results_dir) if args.results_dir else resolve_project_path(cfg.paths.results_dir, ROOT)
    exp_dir = out_root / "semantic"
    logger = setup_logger(exp_dir, enabled=dist_ctx.is_main, rank=dist_ctx.rank)

    train_loader = build_loader(
        cfg,
        "train",
        require={"semantic": True},
        max_samples=cfg.training.get("max_train_samples"),
        distributed=dist_ctx.enabled,
        rank=dist_ctx.rank,
        world_size=dist_ctx.world_size,
    )
    val_loader = (
        build_loader(cfg, "val", require={"semantic": True}, max_samples=cfg.training.get("max_val_samples"))
        if dist_ctx.is_main
        else None
    )
    steps_per_epoch = len(train_loader)
    dvgt = DVGTFeatureExtractor(
        str(resolve_project_path(cfg.paths.dvgt_ckpt_path, ROOT)),
        list(cfg.dvgt.feature_indices),
        bool(cfg.dvgt.per_level_layernorm),
        device,
    )
    decoder = PatchTokenDecoder(
        str(resolve_project_path(cfg.decoder.config_path, ROOT)),
        int(cfg.decoder.hidden_size),
        int(cfg.data.semantic_classes),
        int(cfg.decoder.patch_size),
        tuple(int(x) for x in cfg.decoder.base_image_size),
        cfg.decoder.get("decoder_hidden_size"),
        cfg.decoder.get("decoder_layers"),
        cfg.decoder.get("decoder_heads"),
    ).to(device)
    ema = create_ema(decoder, bool(cfg.training.get("ema", True)))
    optimizer, scheduler = build_optimizer_and_scheduler(decoder, cfg, steps_per_epoch)
    if args.ckpt:
        load_decoder_state(args.ckpt, decoder, prefer_ema=False)
    decoder_train = wrap_ddp(decoder, dist_ctx)
    global_step = 0
    start_time = time.monotonic()
    ignore_index = int(cfg.loss.ignore_index)
    metrics_csv = exp_dir / "reports/metrics.csv"
    for epoch in range(int(cfg.training.epochs)):
        set_loader_epoch(train_loader, epoch)
        decoder_train.train()
        for batch in tqdm(train_loader, desc=f"semantic epoch {epoch}", disable=not dist_ctx.is_main):
            images = batch["images"].to(device, non_blocking=True)
            target = batch["semantic"].to(device, non_blocking=True)
            b, t, v, _, h, w = require_stage1_sequence_images(images, "Semantic training")
            y = target.reshape(b * t * v, h, w)
            optimizer.zero_grad(set_to_none=True)
            with precision_context(device, precision):
                with torch.no_grad():
                    tokens = dvgt(images)
                tokens = tokens.reshape(b * t * v, tokens.shape[-2], tokens.shape[-1])
                logits = decoder_train(tokens, image_size=(h, w))
                loss = F.cross_entropy(logits.float(), y, ignore_index=ignore_index)
            loss.backward()
            if float(cfg.training.get("clip_grad", 0.0)) > 0:
                torch.nn.utils.clip_grad_norm_(decoder.parameters(), float(cfg.training.clip_grad))
            optimizer.step()
            if scheduler is not None:
                scheduler.step()
            update_ema(ema, decoder, float(cfg.training.get("ema_decay", 0.9978)))
            valid = (y != ignore_index).sum().item()
            if dist_ctx.is_main and global_step % int(cfg.training.log_interval) == 0:
                row = {"step": global_step, "epoch": epoch, "loss/ce": float(loss.item()), "valid_pixels": valid, "lr": optimizer.param_groups[0]["lr"]}
                logger.info(", ".join(f"{k}={v:.6f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
                append_csv(metrics_csv, row)
            global_step += 1
            if global_step % int(cfg.training.val_interval) == 0:
                if dist_ctx.is_main and val_loader is not None:
                    metrics = validate(dvgt, ema or decoder, val_loader, device, precision, args.val_batches or int(cfg.reporting.val_batches), ignore_index)
                    metrics["step"] = global_step
                    save_json(exp_dir / f"reports/eval/step_{global_step:07d}.json", metrics)
                    logger.info("[val] " + ", ".join(f"{k}={v:.6f}" for k, v in metrics.items() if isinstance(v, float)))
                barrier(dist_ctx)
            if global_step % int(cfg.training.ckpt_interval) == 0:
                if dist_ctx.is_main:
                    save_checkpoint(exp_dir / f"checkpoints/step_{global_step:07d}.pt", "semantic", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
                barrier(dist_ctx)
            stop_for_steps = args.max_steps is not None and global_step >= args.max_steps
            stop_for_time = args.max_duration_seconds is not None and time.monotonic() - start_time >= float(args.max_duration_seconds)
            if any_rank_true(dist_ctx, stop_for_steps or stop_for_time):
                if dist_ctx.is_main:
                    save_checkpoint(exp_dir / "checkpoints/last.pt", "semantic", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
                barrier(dist_ctx)
                cleanup_distributed(dist_ctx)
                return
        if dist_ctx.is_main:
            save_checkpoint(exp_dir / f"checkpoints/epoch_{epoch + 1:04d}.pt", "semantic", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
        barrier(dist_ctx)
    cleanup_distributed(dist_ctx)


if __name__ == "__main__":
    main()
