#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.models import DVGTFeatureExtractor, PatchTokenDecoder
from dvgt_multimodal.utils import (
    IMAGENET_MEAN,
    IMAGENET_STD,
    add_gld_src,
    append_csv,
    build_loader,
    build_optimizer_and_scheduler,
    calculate_psnr,
    create_ema,
    get_device,
    load_decoder_state,
    precision_context,
    save_checkpoint,
    save_json,
    setup_logger,
    update_ema,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_rgb_nuscenes_704x256.yaml"))
    parser.add_argument("--results-dir", default=None)
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--val-batches", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    return parser.parse_args()


@torch.no_grad()
def validate(dvgt, decoder, loader, cfg, device, precision, max_batches):
    decoder.eval()
    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    total_l1 = total_psnr = count = 0.0
    for i, batch in enumerate(tqdm(loader, desc="val", leave=False)):
        if i >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        b, v, c, h, w = images.shape
        with precision_context(device, precision):
            tokens = dvgt(images)
            pred_norm = decoder(tokens, image_size=(h, w))
        target = images.reshape(b * v, c, h, w)
        pred = pred_norm * std + mean
        pred = pred.float().clamp(0, 1)
        n = pred.shape[0]
        total_l1 += F.l1_loss(pred, target, reduction="none").mean(dim=(1, 2, 3)).sum().item()
        total_psnr += calculate_psnr(pred, target).sum().item()
        count += n
    decoder.train()
    return {"val/l1": total_l1 / max(count, 1.0), "val/psnr": total_psnr / max(count, 1.0), "val/images": count}


def main():
    args = parse_args()
    cfg = OmegaConf.load(args.config)
    if args.num_workers is not None:
        cfg.training.num_workers = args.num_workers
    precision = args.precision or str(cfg.training.precision)
    torch.manual_seed(int(cfg.training.get("seed", 0)))
    device = get_device()
    add_gld_src(str(cfg.paths.gld_src_dir))

    out_root = Path(args.results_dir or cfg.paths.results_dir)
    exp_dir = out_root / "rgb"
    logger = setup_logger(exp_dir)
    logger.info(f"config={args.config}")
    logger.info(f"device={device} precision={precision}")

    train_loader = build_loader(cfg, "train", require={}, max_samples=cfg.training.get("max_train_samples"))
    val_loader = build_loader(cfg, "val", require={}, max_samples=cfg.training.get("max_val_samples"))
    steps_per_epoch = len(train_loader)
    if steps_per_epoch == 0:
        raise RuntimeError("train_loader is empty")

    dvgt = DVGTFeatureExtractor(
        code_dir=str(cfg.paths.dvgt_code_dir),
        ckpt_dir=str(cfg.paths.dvgt_ckpt_dir),
        feature_indices=list(cfg.dvgt.feature_indices),
        per_level_layernorm=bool(cfg.dvgt.per_level_layernorm),
        device=device,
    )
    decoder = PatchTokenDecoder(
        gld_src_dir=str(cfg.paths.gld_src_dir),
        config_path=str(ROOT / cfg.decoder.config_path),
        hidden_size=int(cfg.decoder.hidden_size),
        out_channels=3,
        patch_size=int(cfg.decoder.patch_size),
        base_image_size=tuple(int(x) for x in cfg.decoder.base_image_size),
        decoder_hidden_size=cfg.decoder.get("decoder_hidden_size"),
        decoder_layers=cfg.decoder.get("decoder_layers"),
        decoder_heads=cfg.decoder.get("decoder_heads"),
    ).to(device)
    ema = create_ema(decoder, bool(cfg.training.get("ema", True)))
    optimizer, scheduler = build_optimizer_and_scheduler(decoder, cfg, steps_per_epoch)
    if args.ckpt:
        load_decoder_state(args.ckpt, decoder, prefer_ema=False)
        if ema is not None:
            load_decoder_state(args.ckpt, ema, prefer_ema=True)

    lpips_fn = None
    perceptual_weight = float(cfg.loss.get("perceptual_weight", 0.0))
    if perceptual_weight > 0:
        from disc import LPIPS

        lpips_fn = LPIPS().to(device).eval()
        lpips_fn.requires_grad_(False)

    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    global_step = 0
    metrics_csv = exp_dir / "reports/metrics.csv"
    max_steps = args.max_steps
    for epoch in range(int(cfg.training.epochs)):
        decoder.train()
        for batch in tqdm(train_loader, desc=f"rgb epoch {epoch}"):
            images = batch["images"].to(device, non_blocking=True)
            b, v, c, h, w = images.shape
            target = images.reshape(b * v, c, h, w)
            target_norm = (target - mean) / std
            optimizer.zero_grad(set_to_none=True)
            with precision_context(device, precision):
                with torch.no_grad():
                    tokens = dvgt(images)
                pred_norm = decoder(tokens, image_size=(h, w))
                pred = pred_norm * std + mean
                l1 = F.l1_loss(pred, target)
                if lpips_fn is not None:
                    lpips = lpips_fn(target * 2.0 - 1.0, pred * 2.0 - 1.0)
                else:
                    lpips = l1.new_zeros(())
                loss = float(cfg.loss.recon_weight) * l1 + perceptual_weight * lpips
            loss.backward()
            if float(cfg.training.get("clip_grad", 0.0)) > 0:
                torch.nn.utils.clip_grad_norm_(decoder.parameters(), float(cfg.training.clip_grad))
            optimizer.step()
            if scheduler is not None:
                scheduler.step()
            update_ema(ema, decoder, float(cfg.training.get("ema_decay", 0.9978)))

            if global_step % int(cfg.training.log_interval) == 0:
                row = {
                    "step": global_step,
                    "epoch": epoch,
                    "loss/total": float(loss.detach().item()),
                    "loss/l1": float(l1.detach().item()),
                    "loss/lpips": float(lpips.detach().item()),
                    "lr": optimizer.param_groups[0]["lr"],
                }
                logger.info(", ".join(f"{k}={v:.6f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
                append_csv(metrics_csv, row)

            global_step += 1
            if global_step % int(cfg.training.val_interval) == 0:
                metrics = validate(
                    dvgt,
                    ema or decoder,
                    val_loader,
                    cfg,
                    device,
                    precision,
                    args.val_batches or int(cfg.reporting.val_batches),
                )
                metrics["step"] = global_step
                save_json(exp_dir / f"reports/eval/step_{global_step:07d}.json", metrics)
                logger.info("[val] " + ", ".join(f"{k}={v:.6f}" for k, v in metrics.items() if isinstance(v, float)))
            if global_step % int(cfg.training.ckpt_interval) == 0:
                save_checkpoint(exp_dir / f"checkpoints/step_{global_step:07d}.pt", "rgb", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
            if max_steps is not None and global_step >= max_steps:
                save_checkpoint(exp_dir / "checkpoints/smoke_last.pt", "rgb", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)
                return
        save_checkpoint(exp_dir / f"checkpoints/epoch_{epoch + 1:04d}.pt", "rgb", global_step, epoch, decoder, optimizer, scheduler, cfg, ema)


if __name__ == "__main__":
    main()

