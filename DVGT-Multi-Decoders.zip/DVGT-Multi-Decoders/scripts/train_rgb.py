#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
import torch.utils.checkpoint
import torchvision.transforms as T
import torchvision.transforms.functional as TF
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.distributed import any_rank_true, barrier, cleanup_distributed, init_distributed, set_loader_epoch, wrap_ddp
from dvgt_multimodal.gld.disc import build_discriminator, hinge_d_loss, vanilla_d_loss, vanilla_g_loss
from dvgt_multimodal.gld.stage1.decoders import GeneralDecoder_Variable
from dvgt_multimodal.gld.stage1.decoders.utils import ViTMAEConfig
from dvgt_multimodal.gld.utils.optim_utils import build_optimizer, build_scheduler
from dvgt_multimodal.models import DVGTFeatureExtractor, LPIPS
from dvgt_multimodal.utils import (
    IMAGENET_MEAN,
    IMAGENET_STD,
    append_csv,
    build_loader,
    calculate_psnr,
    create_ema,
    precision_context,
    require_stage1_sequence_images,
    resolve_project_path,
    save_json,
    setup_logger,
    update_ema,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_rgb_nuscenes_704x256.yaml"))
    parser.add_argument("--results-dir", default=None)
    parser.add_argument("--ckpt", default=None, help="Full resumable checkpoint or EMA inference checkpoint.")
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--max-duration-seconds", type=float, default=None)
    parser.add_argument("--val-batches", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    return parser.parse_args()


def _resolve_existing_file(path_value: str | Path | None, label: str) -> Path:
    path = resolve_project_path(path_value, ROOT)
    if path is None or not path.is_file():
        raise FileNotFoundError(f"{label} must be a local file path, got: {path_value}")
    return path


def _resolve_decoder_config(config_path: str | Path) -> Path:
    path = resolve_project_path(config_path, ROOT)
    if path is None:
        raise FileNotFoundError("decoder.config_path is required")
    if path.is_dir():
        path = path / "config.json"
    if not path.is_file():
        raise FileNotFoundError(f"Decoder config must be a local JSON file, got: {path}")
    return path


def build_decoder(cfg, device: torch.device) -> GeneralDecoder_Variable:
    config_path = _resolve_decoder_config(cfg.decoder.config_path)
    with config_path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    dec_config = ViTMAEConfig(**data)
    dec_config.hidden_size = int(cfg.decoder.hidden_size)
    dec_config.patch_size = int(cfg.decoder.patch_size)
    dec_config.num_channels = 3
    if cfg.decoder.get("decoder_hidden_size") is not None:
        dec_config.decoder_hidden_size = int(cfg.decoder.decoder_hidden_size)
    if cfg.decoder.get("decoder_layers") is not None:
        dec_config.decoder_num_hidden_layers = int(cfg.decoder.decoder_layers)
    if cfg.decoder.get("decoder_heads") is not None:
        dec_config.decoder_num_attention_heads = int(cfg.decoder.decoder_heads)
    base_image_size = tuple(int(x) for x in cfg.decoder.base_image_size)
    return GeneralDecoder_Variable(dec_config, base_image_size=base_image_size).to(device)


def calculate_adaptive_weight(
    recon_loss: torch.Tensor,
    gan_loss: torch.Tensor,
    layer: torch.Tensor,
    max_d_weight: float = 1e4,
) -> torch.Tensor:
    recon_grads = torch.autograd.grad(recon_loss, layer, retain_graph=True)[0]
    gan_grads = torch.autograd.grad(gan_loss, layer, retain_graph=True)[0]
    weight = torch.norm(recon_grads) / (torch.norm(gan_grads) + 1e-6)
    return torch.clamp(weight, 0.0, max_d_weight).detach()


def select_gan_losses(disc_kind: str, gen_kind: str):
    disc_losses = {"hinge": hinge_d_loss, "vanilla": vanilla_d_loss}
    gen_losses = {"vanilla": vanilla_g_loss}
    if disc_kind not in disc_losses:
        raise ValueError(f"Unsupported discriminator loss: {disc_kind}")
    if gen_kind not in gen_losses:
        raise ValueError(f"Unsupported generator loss: {gen_kind}")
    return disc_losses[disc_kind], gen_losses[gen_kind]


def set_requires_grad(parameters, enabled: bool) -> None:
    for param in parameters:
        param.requires_grad_(enabled)


def checkpointed_lpips_mean(
    lpips_fn: torch.nn.Module,
    real_pm1: torch.Tensor,
    pred_pm1: torch.Tensor,
    chunk_size: int,
    use_checkpoint: bool,
) -> torch.Tensor:
    chunk_size = max(int(chunk_size), 1)
    total = pred_pm1.new_zeros(())
    count = 0
    for start in range(0, pred_pm1.shape[0], chunk_size):
        end = min(start + chunk_size, pred_pm1.shape[0])
        real_chunk = real_pm1[start:end]
        pred_chunk = pred_pm1[start:end]
        if use_checkpoint and pred_chunk.requires_grad:
            value = torch.utils.checkpoint.checkpoint(
                lambda x: lpips_fn(real_chunk, x),
                pred_chunk,
                use_reentrant=False,
            )
        else:
            value = lpips_fn(real_chunk, pred_chunk)
        total = total + value * float(end - start)
        count += end - start
    return total / float(max(count, 1))


def save_loss_plot(csv_path: Path, png_path: Path) -> None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return
    if not csv_path.is_file():
        return
    with csv_path.open("r", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        return
    steps = [int(r["step"]) for r in rows]
    plt.figure(figsize=(10, 5))
    for key in ["loss/recon", "loss/lpips", "loss/gan", "loss/disc", "loss/total"]:
        vals = [float(r.get(key, 0.0)) for r in rows]
        if len(vals) == len(steps):
            plt.plot(steps, vals, label=key)
    plt.xlabel("step")
    plt.ylabel("loss")
    plt.grid(True, alpha=0.25)
    plt.legend()
    plt.tight_layout()
    png_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(png_path, dpi=160)
    plt.close()


def save_rgb_checkpoint(
    path: Path,
    step: int,
    epoch: int,
    decoder: torch.nn.Module,
    ema_decoder: torch.nn.Module | None,
    optimizer: torch.optim.Optimizer | None,
    scheduler: Any,
    discriminator: torch.nn.Module | None,
    disc_optimizer: torch.optim.Optimizer | None,
    disc_scheduler: Any,
    cfg,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {
        "modality": "rgb",
        "format": "dvgt_stage1_gld_rgb",
        "step": int(step),
        "epoch": int(epoch),
        "model": decoder.state_dict(),
        "ema_model": ema_decoder.state_dict() if ema_decoder is not None else None,
        "optimizer": optimizer.state_dict() if optimizer is not None else None,
        "scheduler": scheduler.state_dict() if scheduler is not None else None,
        "disc": discriminator.state_dict() if discriminator is not None else None,
        "disc_optimizer": disc_optimizer.state_dict() if disc_optimizer is not None else None,
        "disc_scheduler": disc_scheduler.state_dict() if disc_scheduler is not None else None,
        "config": OmegaConf.to_container(cfg, resolve=True),
    }
    torch.save(state, path)


def load_rgb_checkpoint(
    path: str | Path,
    decoder: torch.nn.Module,
    ema_decoder: torch.nn.Module | None,
    optimizer: torch.optim.Optimizer | None,
    scheduler: Any,
    discriminator: torch.nn.Module | None,
    disc_optimizer: torch.optim.Optimizer | None,
    disc_scheduler: Any,
) -> tuple[int, int]:
    ckpt = torch.load(path, map_location="cpu")
    if not isinstance(ckpt, dict):
        decoder.load_state_dict(ckpt, strict=True)
        if ema_decoder is not None:
            ema_decoder.load_state_dict(ckpt, strict=True)
        return 0, 0

    model_state = ckpt.get("model", ckpt.get("decoder"))
    ema_state = ckpt.get("ema_model", ckpt.get("ema_decoder", model_state))
    if model_state is None and ema_state is None:
        raise RuntimeError(f"Checkpoint has no RGB decoder state: {path}")
    decoder.load_state_dict(model_state if model_state is not None else ema_state, strict=True)
    if ema_decoder is not None and ema_state is not None:
        ema_decoder.load_state_dict(ema_state, strict=True)
    if optimizer is not None and ckpt.get("optimizer") is not None:
        optimizer.load_state_dict(ckpt["optimizer"])
    if scheduler is not None and ckpt.get("scheduler") is not None:
        scheduler.load_state_dict(ckpt["scheduler"])
    if discriminator is not None and ckpt.get("disc") is not None:
        discriminator.load_state_dict(ckpt["disc"])
    if disc_optimizer is not None and ckpt.get("disc_optimizer") is not None:
        disc_optimizer.load_state_dict(ckpt["disc_optimizer"])
    if disc_scheduler is not None and ckpt.get("disc_scheduler") is not None:
        disc_scheduler.load_state_dict(ckpt["disc_scheduler"])
    return int(ckpt.get("epoch", 0)), int(ckpt.get("step", 0))


@torch.no_grad()
def validate(dvgt, decoder, loader, cfg, lpips_fn, device, precision, max_batches: int):
    decoder.eval()
    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    sums = defaultdict(float)
    count = 0
    for i, batch in enumerate(tqdm(loader, desc="val", leave=False)):
        if i >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        b, t, v, c, h, w = require_stage1_sequence_images(images, "RGB validation")
        with precision_context(device, precision):
            tokens = dvgt(images)
            tokens = tokens.reshape(b * t * v, tokens.shape[-2], tokens.shape[-1])
            logits = decoder(tokens, input_size=(h, w), drop_cls_token=False).logits
            pred_norm = decoder.unpatchify(logits, (h, w))
            pred = pred_norm * std + mean
        target = images.reshape(b * t * v, c, h, w).float()
        pred = pred.float().clamp(0, 1)
        n = pred.shape[0]
        sums["l1"] += F.l1_loss(pred, target, reduction="none").mean(dim=(1, 2, 3)).sum().item()
        sums["psnr"] += calculate_psnr(pred, target).sum().item()
        lpips_value = checkpointed_lpips_mean(
            lpips_fn,
            target * 2.0 - 1.0,
            pred * 2.0 - 1.0,
            int(cfg.loss.get("lpips_chunk_size", 4)),
            use_checkpoint=False,
        )
        sums["lpips"] += lpips_value.item() * n
        count += n
    decoder.train()
    return {f"val/{k}": v / max(count, 1) for k, v in sums.items()} | {"val/images": count}


def main():
    args = parse_args()
    dist_ctx = init_distributed()
    cfg = OmegaConf.load(args.config)
    if args.num_workers is not None:
        cfg.training.num_workers = args.num_workers
    if args.batch_size is not None:
        cfg.training.batch_size = args.batch_size
    precision = args.precision or str(cfg.training.precision)
    seed = int(cfg.training.get("seed", cfg.training.get("global_seed", 0))) + dist_ctx.rank
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    device = dist_ctx.device
    out_root = Path(args.results_dir) if args.results_dir else resolve_project_path(cfg.paths.results_dir, ROOT)
    exp_dir = out_root / "rgb"
    logger = setup_logger(exp_dir, enabled=dist_ctx.is_main, rank=dist_ctx.rank)
    logger.info(f"config={args.config}")
    logger.info(f"device={device} precision={precision} distributed={dist_ctx.enabled} world_size={dist_ctx.world_size}")

    train_loader = build_loader(
        cfg,
        "train",
        require={},
        max_samples=cfg.training.get("max_train_samples"),
        distributed=dist_ctx.enabled,
        rank=dist_ctx.rank,
        world_size=dist_ctx.world_size,
    )
    val_loader = (
        build_loader(cfg, "val", require={}, max_samples=cfg.training.get("max_val_samples"))
        if dist_ctx.is_main
        else None
    )
    steps_per_epoch = len(train_loader)
    if steps_per_epoch == 0:
        raise RuntimeError("train_loader is empty")

    dvgt = DVGTFeatureExtractor(
        str(resolve_project_path(cfg.paths.dvgt_ckpt_path, ROOT)),
        list(cfg.dvgt.feature_indices),
        bool(cfg.dvgt.per_level_layernorm),
        device,
    )
    decoder = build_decoder(cfg, device)
    decoder.gradient_checkpointing = bool(cfg.training.get("decoder_gradient_checkpointing", True))
    ema_decoder = create_ema(decoder, bool(cfg.training.get("ema", True)))

    training_cfg = OmegaConf.to_container(cfg.training, resolve=True)
    optimizer, opt_msg = build_optimizer([p for p in decoder.parameters() if p.requires_grad], training_cfg)
    scheduler = build_scheduler(optimizer, steps_per_epoch, training_cfg)[0] if training_cfg.get("scheduler") else None
    logger.info(opt_msg)

    loss_cfg = OmegaConf.to_container(cfg.gan.loss, resolve=True)
    disc_cfg = OmegaConf.to_container(cfg.gan.disc, resolve=True)
    dino_ckpt = _resolve_existing_file(disc_cfg.get("arch", {}).get("dino_ckpt_path"), "DINO discriminator checkpoint")
    disc_cfg["arch"]["dino_ckpt_path"] = str(dino_ckpt)
    discriminator, disc_aug = build_discriminator(disc_cfg, device)
    disc_trainable_params = [p for p in discriminator.parameters() if p.requires_grad]
    disc_optimizer, disc_opt_msg = build_optimizer(disc_trainable_params, disc_cfg)
    disc_scheduler = build_scheduler(disc_optimizer, steps_per_epoch, disc_cfg)[0] if disc_cfg.get("scheduler") else None
    disc_loss_fn, gen_loss_fn = select_gan_losses(
        str(loss_cfg.get("disc_loss", "hinge")),
        str(loss_cfg.get("gen_loss", "vanilla")),
    )
    logger.info(disc_opt_msg)
    logger.info(f"DINO discriminator checkpoint={dino_ckpt}")

    lpips_fn = LPIPS(
        lpips_weight_path=_resolve_existing_file(cfg.loss.lpips_weight_path, "LPIPS linear checkpoint"),
        vgg16_weight_path=_resolve_existing_file(cfg.loss.vgg16_weight_path, "VGG16 checkpoint"),
    ).to(device).eval()
    lpips_fn.requires_grad_(False)

    start_epoch = 0
    global_step = 0
    if args.ckpt:
        start_epoch, global_step = load_rgb_checkpoint(
            args.ckpt,
            decoder,
            ema_decoder,
            optimizer,
            scheduler,
            discriminator,
            disc_optimizer,
            disc_scheduler,
        )
        logger.info(f"resumed ckpt={args.ckpt} epoch={start_epoch} step={global_step}")
    decoder_train = wrap_ddp(decoder, dist_ctx)
    discriminator_train = wrap_ddp(discriminator, dist_ctx)

    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    patch_size = int(cfg.decoder.patch_size)
    recon_weight = float(loss_cfg.get("recon_weight", 1.0))
    perceptual_weight = float(loss_cfg.get("perceptual_weight", 1.0))
    disc_weight = float(loss_cfg.get("disc_weight", 0.75))
    gan_start_step = int(loss_cfg.get("disc_start", 0)) * steps_per_epoch
    disc_update_step = int(loss_cfg.get("disc_upd_start", loss_cfg.get("disc_start", 0))) * steps_per_epoch
    lpips_start_step = int(loss_cfg.get("lpips_start", 0)) * steps_per_epoch
    disc_updates = int(loss_cfg.get("disc_updates", 1))
    max_d_weight = float(loss_cfg.get("max_d_weight", 1e4))
    last_layer = decoder.decoder_pred.weight
    metrics_csv = exp_dir / "reports/metrics.csv"
    max_steps = args.max_steps
    start_time = time.monotonic()
    scaler = torch.cuda.amp.GradScaler(enabled=(precision == "fp16" and device.type == "cuda"))

    logger.info(
        f"bs={cfg.training.batch_size}, steps_per_epoch={steps_per_epoch}, "
        f"gan_start_step={gan_start_step}, disc_update_step={disc_update_step}, lpips_start_step={lpips_start_step}, "
        f"decoder_gradient_checkpointing={decoder.gradient_checkpointing}"
    )

    for epoch in range(start_epoch, int(cfg.training.epochs)):
        set_loader_epoch(train_loader, epoch)
        decoder_train.train()
        for batch in tqdm(train_loader, desc=f"rgb epoch {epoch}", disable=not dist_ctx.is_main):
            use_gan = global_step >= gan_start_step and disc_weight > 0.0
            train_disc = global_step >= disc_update_step and disc_weight > 0.0
            use_lpips = global_step >= lpips_start_step and perceptual_weight > 0.0

            images = batch["images"].to(device, non_blocking=True)
            b, t, v, c, h, w = require_stage1_sequence_images(images, "RGB training")
            if h % patch_size != 0 or w % patch_size != 0:
                raise ValueError(f"Image size {(h, w)} must be divisible by patch_size={patch_size}")
            images_flat = images.reshape(b * t * v, c, h, w).contiguous()
            real_pm1 = images_flat * 2.0 - 1.0

            optimizer.zero_grad(set_to_none=True)
            discriminator.eval()
            set_requires_grad(disc_trainable_params, False)
            with precision_context(device, precision):
                with torch.no_grad():
                    tokens = dvgt(images)
                tokens = tokens.reshape(b * t * v, tokens.shape[-2], tokens.shape[-1])
                logits = decoder_train(tokens, input_size=(h, w), drop_cls_token=False).logits
                recon_norm = decoder.unpatchify(logits, (h, w))
                recon_01 = recon_norm * std + mean
                recon_pm1 = recon_01 * 2.0 - 1.0
                rec_loss = F.l1_loss(recon_01, images_flat)
                lpips_loss = (
                    checkpointed_lpips_mean(
                        lpips_fn,
                        real_pm1,
                        recon_pm1,
                        int(cfg.loss.get("lpips_chunk_size", 4)),
                        use_checkpoint=bool(cfg.loss.get("lpips_checkpoint", True)),
                    )
                    if use_lpips
                    else rec_loss.new_zeros(())
                )
                recon_total = recon_weight * rec_loss + perceptual_weight * lpips_loss
                if use_gan:
                    i_crop, j_crop, h_crop, w_crop = T.RandomCrop.get_params(recon_pm1, output_size=(224, 224))
                    fake_aug = disc_aug.aug(TF.crop(recon_pm1, i_crop, j_crop, h_crop, w_crop))
                    logits_fake, _ = discriminator(fake_aug, None)
                    gan_loss = gen_loss_fn(logits_fake)
                else:
                    gan_loss = recon_total.new_zeros(())

            if use_gan:
                adaptive_weight = calculate_adaptive_weight(recon_total, gan_loss, last_layer, max_d_weight)
                total_loss = recon_total + disc_weight * adaptive_weight * gan_loss
            else:
                adaptive_weight = recon_total.new_zeros(())
                total_loss = recon_total

            if scaler.is_enabled():
                scaler.scale(total_loss).backward()
                if float(cfg.training.get("clip_grad", 0.0)) > 0:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(decoder.parameters(), float(cfg.training.clip_grad))
                scaler.step(optimizer)
                scaler.update()
            else:
                total_loss.backward()
                if float(cfg.training.get("clip_grad", 0.0)) > 0:
                    torch.nn.utils.clip_grad_norm_(decoder.parameters(), float(cfg.training.clip_grad))
                optimizer.step()
            if scheduler is not None:
                scheduler.step()
            update_ema(ema_decoder, decoder, float(cfg.training.get("ema_decay", 0.9978)))

            disc_metrics: dict[str, torch.Tensor] = {}
            if train_disc:
                set_requires_grad(disc_trainable_params, True)
                discriminator_train.train()
                decoder.eval()
                for _ in range(disc_updates):
                    disc_optimizer.zero_grad(set_to_none=True)
                    with precision_context(device, precision):
                        with torch.no_grad():
                            logits_d = decoder(tokens, input_size=(h, w), drop_cls_token=False).logits
                            recon_d = decoder.unpatchify(logits_d, (h, w))
                            recon_d_01 = recon_d * std + mean
                            fake_det = (recon_d_01 * 2.0 - 1.0).clamp(-1.0, 1.0)
                            fake_det = torch.round((fake_det + 1.0) * 127.5) / 127.5 - 1.0
                        i_crop, j_crop, h_crop, w_crop = T.RandomCrop.get_params(real_pm1, output_size=(224, 224))
                        fake_input = disc_aug.aug(TF.crop(fake_det, i_crop, j_crop, h_crop, w_crop))
                        real_input = disc_aug.aug(TF.crop(real_pm1, i_crop, j_crop, h_crop, w_crop))
                        logits_fake_d, logits_real_d = discriminator_train(fake_input, real_input)
                        d_loss = disc_loss_fn(logits_real_d, logits_fake_d)
                        accuracy = (logits_real_d > logits_fake_d).float().mean()
                    d_loss.backward()
                    disc_optimizer.step()
                    if disc_scheduler is not None:
                        disc_scheduler.step()
                    disc_metrics = {"loss/disc": d_loss.detach(), "disc/accuracy": accuracy.detach()}
                discriminator_train.eval()
                decoder_train.train()

            if dist_ctx.is_main and global_step % int(cfg.training.log_interval) == 0:
                row = {
                    "step": global_step,
                    "epoch": epoch,
                    "loss/total": float(total_loss.detach().item()),
                    "loss/recon": float(rec_loss.detach().item()),
                    "loss/lpips": float(lpips_loss.detach().item()),
                    "loss/gan": float(gan_loss.detach().item()),
                    "loss/disc": float(disc_metrics.get("loss/disc", torch.zeros(())).item()) if disc_metrics else 0.0,
                    "disc/accuracy": float(disc_metrics.get("disc/accuracy", torch.zeros(())).item()) if disc_metrics else 0.0,
                    "gan/weight": float(adaptive_weight.detach().item()),
                    "lr/generator": float(optimizer.param_groups[0]["lr"]),
                    "lr/discriminator": float(disc_optimizer.param_groups[0]["lr"]),
                }
                logger.info(", ".join(f"{k}={v:.6f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
                append_csv(metrics_csv, row)

            global_step += 1
            if global_step % int(cfg.training.val_interval) == 0:
                if dist_ctx.is_main and val_loader is not None:
                    metrics = validate(
                        dvgt,
                        ema_decoder or decoder,
                        val_loader,
                        cfg,
                        lpips_fn,
                        device,
                        precision,
                        args.val_batches or int(cfg.reporting.val_batches),
                    )
                    metrics["step"] = global_step
                    save_json(exp_dir / f"reports/eval/step_{global_step:07d}.json", metrics)
                    logger.info("[val] " + ", ".join(f"{k}={v:.6f}" for k, v in metrics.items() if isinstance(v, float)))
                    save_loss_plot(metrics_csv, exp_dir / "reports/loss_curve.png")
                barrier(dist_ctx)
            if global_step % int(cfg.training.ckpt_interval) == 0:
                if dist_ctx.is_main:
                    save_rgb_checkpoint(
                        exp_dir / f"checkpoints/step_{global_step:07d}.pt",
                        global_step,
                        epoch,
                        decoder,
                        ema_decoder,
                        optimizer,
                        scheduler,
                        discriminator,
                        disc_optimizer,
                        disc_scheduler,
                        cfg,
                    )
                barrier(dist_ctx)
            stop_for_steps = max_steps is not None and global_step >= max_steps
            stop_for_time = args.max_duration_seconds is not None and time.monotonic() - start_time >= float(args.max_duration_seconds)
            if any_rank_true(dist_ctx, stop_for_steps or stop_for_time):
                if dist_ctx.is_main:
                    save_rgb_checkpoint(exp_dir / "checkpoints/last.pt", global_step, epoch, decoder, ema_decoder, optimizer, scheduler, discriminator, disc_optimizer, disc_scheduler, cfg)
                barrier(dist_ctx)
                cleanup_distributed(dist_ctx)
                return
        if dist_ctx.is_main:
            save_rgb_checkpoint(
                exp_dir / f"checkpoints/epoch_{epoch + 1:04d}.pt",
                global_step,
                epoch,
                decoder,
                ema_decoder,
                optimizer,
                scheduler,
                discriminator,
                disc_optimizer,
                disc_scheduler,
                cfg,
            )
        barrier(dist_ctx)
    cleanup_distributed(dist_ctx)


if __name__ == "__main__":
    main()
