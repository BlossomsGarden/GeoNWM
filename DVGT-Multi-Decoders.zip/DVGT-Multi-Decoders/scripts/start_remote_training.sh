#!/bin/bash
set -euo pipefail

MODALITY="${1:?usage: bash scripts/start_remote_training.sh rgb|depth|semantic|occupancy [extra args...]}"
shift || true

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONDA_SH="${CONDA_SH:-}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-gld}"
LOG_DIR="${PROJECT_DIR}/logs"
mkdir -p "${LOG_DIR}"

if [[ -n "${CONDA_SH}" && -f "${CONDA_SH}" ]]; then
  set +u
  source "${CONDA_SH}"
  conda activate "${CONDA_ENV_NAME}"
  set -u
fi

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTHONPATH="${PROJECT_DIR}:${PYTHONPATH:-}"

case "${MODALITY}" in
  rgb) SCRIPT="scripts/train_rgb.py"; CONFIG="configs/stage1_rgb_nuscenes_704x256.yaml" ;;
  depth) SCRIPT="scripts/train_depth.py"; CONFIG="configs/stage1_depth_nuscenes_704x256.yaml" ;;
  semantic) SCRIPT="scripts/train_semantic.py"; CONFIG="configs/stage1_semantic_nuscenes_704x256.yaml" ;;
  occupancy) SCRIPT="scripts/train_occupancy.py"; CONFIG="configs/stage1_occupancy_nuscenes_704x256.yaml" ;;
  *) echo "Unknown modality: ${MODALITY}" >&2; exit 2 ;;
esac

cd "${PROJECT_DIR}"
LOG_FILE="${LOG_DIR}/train_${MODALITY}.log"
PID_FILE="${LOG_DIR}/train_${MODALITY}.pid"

setsid nohup python "${SCRIPT}" --config "${CONFIG}" "$@" > "${LOG_FILE}" 2>&1 < /dev/null &
echo $! > "${PID_FILE}"
echo "Started ${MODALITY} training"
echo "PID: $(cat "${PID_FILE}")"
echo "Log: ${LOG_FILE}"
