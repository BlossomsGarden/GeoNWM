#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from PIL import Image
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.gld.stage1.decoders import GeneralDecoder_Variable
from dvgt_multimodal.gld.stage1.decoders.utils import ViTMAEConfig
from dvgt_multimodal.models import BEVOccupancyDecoder, DVGTFeatureExtractor, PatchTokenDecoder
from dvgt_multimodal.utils import (
    IMAGENET_MEAN,
    IMAGENET_STD,
    build_loader,
    calculate_psnr,
    densify_occupancy,
    get_device,
    load_decoder_state,
    precision_context,
    require_stage1_sequence_images,
    resolve_project_path,
    save_json,
)


PALETTE = np.array(
    [
        [0, 0, 0],
        [255, 158, 0],
        [255, 99, 71],
        [255, 69, 0],
        [0, 0, 230],
        [255, 61, 99],
        [255, 0, 0],
        [0, 0, 128],
        [255, 140, 0],
        [112, 128, 144],
        [222, 184, 135],
        [0, 207, 191],
        [175, 0, 75],
        [75, 0, 75],
        [112, 180, 60],
        [222, 184, 135],
        [0, 175, 0],
    ],
    dtype=np.uint8,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--modality", choices=["rgb", "depth", "semantic", "occupancy"], required=True)
    parser.add_argument("--config", default=None)
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--split", choices=["train", "val"], default="val")
    parser.add_argument("--out-dir", default=None)
    parser.add_argument("--num-samples", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default="bf16")
    return parser.parse_args()


def default_config(modality: str) -> Path:
    return ROOT / f"configs/stage1_{modality}_nuscenes_704x256.yaml"


def colorize_semantic(labels: np.ndarray, ignore_index: int = 255) -> np.ndarray:
    out = np.zeros((*labels.shape, 3), dtype=np.uint8)
    valid = labels != ignore_index
    safe = np.clip(labels, 0, len(PALETTE) - 1)
    out[valid] = PALETTE[safe[valid]]
    return out


def colorize_depth(depth: np.ndarray, mask: np.ndarray | None = None) -> np.ndarray:
    d = depth.astype(np.float32)
    if mask is not None and np.any(mask):
        vals = d[mask]
        lo, hi = np.percentile(vals, [2, 98])
    else:
        lo, hi = np.percentile(d, [2, 98])
    norm = np.clip((d - lo) / max(hi - lo, 1e-6), 0, 1)
    r = (norm * 255).astype(np.uint8)
    g = ((1.0 - np.abs(norm - 0.5) * 2.0) * 255).astype(np.uint8)
    b = ((1.0 - norm) * 255).astype(np.uint8)
    return np.stack([r, g, b], axis=-1)


def save_grid(rows: list[np.ndarray], path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    max_w = max(r.shape[1] for r in rows)
    padded = []
    for row in rows:
        if row.shape[1] < max_w:
            pad = np.zeros((row.shape[0], max_w - row.shape[1], 3), dtype=np.uint8)
            row = np.concatenate([row, pad], axis=1)
        padded.append(row)
    Image.fromarray(np.concatenate(padded, axis=0)).save(path)


def build_model(modality: str, cfg, device):
    if modality == "occupancy":
        model = BEVOccupancyDecoder(
            in_dim=int(cfg.decoder.hidden_size),
            num_classes=int(cfg.data.semantic_classes),
            num_views=6,
            image_size=(int(cfg.data.image_size[1]), int(cfg.data.image_size[0])),
            patch_size=int(cfg.decoder.patch_size),
            bev_h=int(cfg.occupancy.grid_shape[1]),
            bev_w=int(cfg.occupancy.grid_shape[2]),
            occ_z=int(cfg.occupancy.grid_shape[0]),
            hidden_dim=int(cfg.decoder.hidden_dim),
        ).to(device)
    elif modality == "rgb":
        config_path = resolve_project_path(cfg.decoder.config_path, ROOT)
        if config_path is None:
            raise FileNotFoundError("decoder.config_path is required")
        if config_path.is_dir():
            config_path = config_path / "config.json"
        if not config_path.is_file():
            raise FileNotFoundError(f"RGB decoder config must be local JSON, got: {config_path}")
        with config_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        dec_cfg = ViTMAEConfig(**data)
        dec_cfg.hidden_size = int(cfg.decoder.hidden_size)
        dec_cfg.patch_size = int(cfg.decoder.patch_size)
        dec_cfg.num_channels = 3
        if cfg.decoder.get("decoder_hidden_size") is not None:
            dec_cfg.decoder_hidden_size = int(cfg.decoder.decoder_hidden_size)
        if cfg.decoder.get("decoder_layers") is not None:
            dec_cfg.decoder_num_hidden_layers = int(cfg.decoder.decoder_layers)
        if cfg.decoder.get("decoder_heads") is not None:
            dec_cfg.decoder_num_attention_heads = int(cfg.decoder.decoder_heads)
        model = GeneralDecoder_Variable(
            dec_cfg,
            base_image_size=tuple(int(x) for x in cfg.decoder.base_image_size),
        ).to(device)
    else:
        out_channels = {"depth": 1, "semantic": int(cfg.data.semantic_classes)}[modality]
        model = PatchTokenDecoder(
            str(resolve_project_path(cfg.decoder.config_path, ROOT)),
            int(cfg.decoder.hidden_size),
            out_channels,
            int(cfg.decoder.patch_size),
            tuple(int(x) for x in cfg.decoder.base_image_size),
            cfg.decoder.get("decoder_hidden_size"),
            cfg.decoder.get("decoder_layers"),
            cfg.decoder.get("decoder_heads"),
        ).to(device)
    load_decoder_state(args.ckpt, model, prefer_ema=True)
    model.eval()
    return model


def main():
    global args
    args = parse_args()
    cfg = OmegaConf.load(args.config or default_config(args.modality))
    cfg.training.batch_size = 1
    cfg.training.num_workers = args.num_workers
    device = get_device()
    require = {
        "depth": args.modality == "depth",
        "semantic": args.modality == "semantic",
        "occupancy": args.modality == "occupancy",
    }
    loader = build_loader(cfg, args.split, require=require, max_samples=args.num_samples)
    dvgt = DVGTFeatureExtractor(
        str(resolve_project_path(cfg.paths.dvgt_ckpt_path, ROOT)),
        list(cfg.dvgt.feature_indices),
        bool(cfg.dvgt.per_level_layernorm),
        device,
    )
    model = build_model(args.modality, cfg, device)
    out_dir = Path(args.out_dir or (Path(args.ckpt).parent.parent / f"vis_{args.modality}"))
    metrics = {}

    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    for i, batch in enumerate(tqdm(loader, desc=f"visualize {args.modality}")):
        images = batch["images"].to(device, non_blocking=True)
        b, t, v, c, h, w = require_stage1_sequence_images(images, "Stage 1 visualization")
        with torch.no_grad(), precision_context(device, args.precision):
            tokens = dvgt(images)
            flat_tokens = tokens.reshape(b * t * v, tokens.shape[-2], tokens.shape[-1])
            if args.modality == "occupancy":
                logits = model(flat_tokens, batch_size=b * t)
            elif args.modality == "rgb":
                out = model(flat_tokens, input_size=(h, w), drop_cls_token=False).logits
                logits = model.unpatchify(out, (h, w))
            else:
                logits = model(flat_tokens, image_size=(h, w))

        if args.modality == "rgb":
            pred = (logits * std + mean).float().clamp(0, 1)
            gt = images.reshape(b * t * v, c, h, w).float()
            metrics[f"sample_{i}/psnr"] = float(calculate_psnr(pred, gt).mean().item())
            pred_np = (pred.reshape(b, t, v, c, h, w).cpu().permute(0, 1, 2, 4, 5, 3).numpy() * 255).astype(np.uint8)
            gt_np = (images.float().cpu().permute(0, 1, 2, 4, 5, 3).numpy() * 255).astype(np.uint8)
            for bi in range(b):
                seq_dir = out_dir / f"sample_{i:04d}_seq_{bi:02d}"
                for ti in range(t):
                    save_grid(
                        [np.concatenate(gt_np[bi, ti], axis=1), np.concatenate(pred_np[bi, ti], axis=1)],
                        seq_dir / f"t{ti:02d}_rgb.png",
                    )
        elif args.modality == "depth":
            pred = F.softplus(logits).float().cpu().numpy()[:, 0]
            gt = batch["depth"].reshape(b * t * v, 1, h, w).numpy()[:, 0]
            mask = batch["depth_mask"].reshape(b * t * v, 1, h, w).numpy()[:, 0] > 0.5
            metrics[f"sample_{i}/absrel"] = float(np.mean(np.abs(pred[mask] - gt[mask]) / np.maximum(gt[mask], 1e-3))) if np.any(mask) else 0.0
            pred_c = np.stack([colorize_depth(x, m) for x, m in zip(pred, mask)], axis=0).reshape(b, t, v, h, w, 3)
            gt_c = np.stack([colorize_depth(x, m) for x, m in zip(gt, mask)], axis=0).reshape(b, t, v, h, w, 3)
            for bi in range(b):
                seq_dir = out_dir / f"sample_{i:04d}_seq_{bi:02d}"
                for ti in range(t):
                    save_grid(
                        [np.concatenate(gt_c[bi, ti], axis=1), np.concatenate(pred_c[bi, ti], axis=1)],
                        seq_dir / f"t{ti:02d}_depth.png",
                    )
        elif args.modality == "semantic":
            pred = logits.argmax(dim=1).cpu().numpy()
            gt = batch["semantic"].reshape(b * t * v, h, w).numpy()
            valid = gt != int(cfg.loss.ignore_index)
            metrics[f"sample_{i}/pixel_acc"] = float(((pred == gt) & valid).sum() / max(valid.sum(), 1))
            pred_c = np.stack([colorize_semantic(x, int(cfg.loss.ignore_index)) for x in pred], axis=0).reshape(b, t, v, h, w, 3)
            gt_c = np.stack([colorize_semantic(x, int(cfg.loss.ignore_index)) for x in gt], axis=0).reshape(b, t, v, h, w, 3)
            for bi in range(b):
                seq_dir = out_dir / f"sample_{i:04d}_seq_{bi:02d}"
                for ti in range(t):
                    save_grid(
                        [np.concatenate(gt_c[bi, ti], axis=1), np.concatenate(pred_c[bi, ti], axis=1)],
                        seq_dir / f"t{ti:02d}_semantic.png",
                    )
        else:
            target = densify_occupancy(batch["occupancy_sparse"], shape=tuple(int(x) for x in cfg.occupancy.grid_shape), ignore_index=int(cfg.loss.ignore_index), device=device)
            pred = logits.argmax(dim=1)
            valid = target != int(cfg.loss.ignore_index)
            metrics[f"sample_{i}/voxel_acc"] = float(((pred == target) & valid).sum().item() / max(valid.sum().item(), 1))
            pred_bev = torch.where(valid, pred, torch.zeros_like(pred)).amax(dim=1).cpu().numpy().reshape(b, t, *target.shape[-2:])
            gt_bev = torch.where(valid, target, torch.zeros_like(target)).amax(dim=1).cpu().numpy().reshape(b, t, *target.shape[-2:])
            for bi in range(b):
                seq_dir = out_dir / f"sample_{i:04d}_seq_{bi:02d}"
                for ti in range(t):
                    save_grid(
                        [colorize_semantic(gt_bev[bi, ti]), colorize_semantic(pred_bev[bi, ti])],
                        seq_dir / f"t{ti:02d}_occupancy_bev.png",
                    )
    save_json(out_dir / "metrics.json", metrics)


if __name__ == "__main__":
    main()
