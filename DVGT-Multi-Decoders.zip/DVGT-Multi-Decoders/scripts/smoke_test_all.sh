#!/bin/bash
set -euo pipefail

cd /data/wlh/GLD/code/DVGT-Multi-Decoders

set +u
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate gld
set -u

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTHONPATH="/data/wlh/GLD/code/DVGT-Multi-Decoders:/data/wlh/GLD/code/src:${PYTHONPATH:-}"

python -m compileall -q .

python scripts/train_rgb.py --config configs/stage1_rgb_nuscenes_704x256.yaml --max-steps 2 --num-workers 0 --val-batches 1
python scripts/train_depth.py --config configs/stage1_depth_nuscenes_704x256.yaml --max-steps 2 --num-workers 0 --val-batches 1
python scripts/train_semantic.py --config configs/stage1_semantic_nuscenes_704x256.yaml --max-steps 2 --num-workers 0 --val-batches 1
python scripts/train_occupancy.py --config configs/stage1_occupancy_nuscenes_704x256.yaml --max-steps 2 --num-workers 0 --val-batches 1

echo "All modality smoke tests completed."
