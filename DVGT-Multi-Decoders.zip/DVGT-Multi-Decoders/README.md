# DVGT Multi-Decoders on nuScenes

Stage-1 proof code for training lightweight RGB, Depth, Semantic, and Occupancy decoders on frozen DVGT-1 features.

The old Waymo three-camera RGB-only experiment has been removed. This project now uses nuScenes 6-view keyframes at `704x256`, freezes the DVGT DINO encoder and DVGT Transformer backbone, and trains only one decoder per modality.

## Layout

```text
DVGT-Multi-Decoders/
  configs/
    stage1_rgb_nuscenes_704x256.yaml
    stage1_depth_nuscenes_704x256.yaml
    stage1_semantic_nuscenes_704x256.yaml
    stage1_occupancy_nuscenes_704x256.yaml
  decoder_ViTXL/config.json
  dvgt_multimodal/
    data/nuscenes_stage1.py      # nuScenes 6-view RGB/depth/lidarseg/occ loader
    models/dvgt_features.py      # frozen DVGT-1 feature extractor
    models/image_decoders.py     # MAE-style RGB/Depth/Semantic decoder
    models/occ_decoder.py        # efficient BEV occupancy decoder
    utils.py                     # losses, checkpointing, loaders, metrics
  scripts/
    train_rgb.py
    train_depth.py
    train_semantic.py
    train_occupancy.py
    visualize_stage1.py
    upload_remote.py
    start_remote_training.sh
    smoke_test_all.sh
```

## Data And Supervision

Default remote paths are encoded in the YAML configs:

```text
nuScenes root:      /data2/DATA/AutoDrive/nuscenes/v1.0-trainval
nuScenes tables:    /data2/DATA/AutoDrive/nuscenes/v1.0-trainval/v1.0-trainval
MoGe depth:         /data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth
lidarseg:           /data2/DATA/AutoDrive/nuscenes/v1.0-trainval/lidarseg
SurroundOcc labels: /data/wlh/SurroundOcc/nuscenes_occ
DVGT code:          /data/wlh/GLD/DVGT-code
DVGT checkpoint:    /data/wlh/GLD/DVGT-model/DVGT-1
GLD src:            /data/wlh/GLD/code/src
```

The loader reads `nuscenes_infos_train.pkl` and `nuscenes_infos_val.pkl` for sample metadata. RGB uses all six cameras. Depth reads per-camera `.npz` files with `depth` and `mask`. Semantic supervision projects LIDAR_TOP points with lidarseg labels into every camera and maps raw nuScenes 32 classes into the planned 17-class space. Occupancy reads SurroundOcc sparse arrays `(x, y, z, label)` and densifies them to `16x200x200`.

## Training

On the remote server:

```bash
cd /data/wlh/GLD/code/DVGT-Multi-Decoders

bash scripts/start_remote_training.sh rgb --max-steps 30000
bash scripts/start_remote_training.sh depth --max-steps 20000
bash scripts/start_remote_training.sh semantic --max-steps 20000
bash scripts/start_remote_training.sh occupancy --max-steps 40000
```


Logs are written to:

```text
/data/wlh/GLD/code/DVGT-Multi-Decoders/logs/train_<modality>.log
```

Outputs are written under:

```text
/data/wlh/GLD/code/DVGT-Multi-Decoders/results/stage1-nuscenes-704x256/<modality>/
  checkpoints/
  reports/
```

## Smoke Test

Upload and run all four short training checks from the local machine:

```bash
python DVGT-Multi-Decoders/scripts/upload_remote.py --smoke-test
```

Or run on remote:

```bash
cd /data/wlh/GLD/code/DVGT-Multi-Decoders
bash scripts/smoke_test_all.sh
```

Each modality runs two optimizer steps with `num_workers=0` and writes a `smoke_last.pt` checkpoint.

## Visualization

`scripts/visualize_stage1.py` evaluates and visualizes a checkpoint. Select the modality with `--modality`:

```bash
python scripts/visualize_stage1.py \
  --modality rgb \
  --ckpt results/stage1-nuscenes-704x256/rgb/checkpoints/smoke_last.pt

python scripts/visualize_stage1.py \
  --modality depth \
  --ckpt results/stage1-nuscenes-704x256/depth/checkpoints/smoke_last.pt

python scripts/visualize_stage1.py \
  --modality semantic \
  --ckpt results/stage1-nuscenes-704x256/semantic/checkpoints/smoke_last.pt

python scripts/visualize_stage1.py \
  --modality occupancy \
  --ckpt results/stage1-nuscenes-704x256/occupancy/checkpoints/smoke_last.pt
```

RGB saves GT/pred 6-view strips. Depth saves colored depth strips. Semantic saves GT/pred sparse projection maps. Occupancy saves BEV max-height GT/pred maps.

## Notes

- The DVGT feature extractor is frozen and wrapped in `torch.no_grad()`.
- RGB/Depth/Semantic use a GLD MAE-style token decoder with explicit output channels.
- Occupancy uses a lightweight FlashOcc-inspired BEV decoder: reshape six-view DVGT patch tokens, fuse view features, process in BEV with 2D conv, then channel-to-height into `17 x 16 x 200 x 200` logits.
- No Waymo dataset fallback or old experiment path remains.
- If installing any missing dependency on the remote server becomes necessary, use a China mirror, for example `pip -i https://pypi.tuna.tsinghua.edu.cn/simple`.
