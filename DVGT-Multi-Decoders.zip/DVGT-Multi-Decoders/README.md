# DVGT Multi-Decoders on nuScenes

Stage 1 trains RGB, depth, semantic, and occupancy decoders on frozen DVGT-1 features for fixed nuScenes `T=8`, `V=6` sequences at `704x256`.

## Implemented

- Project-local DVGT core code under `dvgt/` and project-local DINOv3 code under `third_party/dinov3/`.
- Offline-only DVGT loading. `paths.dvgt_ckpt_path` must point to a local checkpoint file.
- No separate DINOv3 patch-embed weight interface is exposed: DVGT is initialized from project-local code and populated by `paths.dvgt_ckpt_path`.
- nuScenes RGB, MoGe depth, lidarseg semantic projection, and SurroundOcc sparse occupancy loading from config paths.
- Raw nuScenes camera images are processed with DVGT-style geometry: principal-point crop, aspect-preserving resize, and a final principal-point crop to `704x256`. Images are not stretched. The updated intrinsics are reused for lidarseg projection.
- The dataset, DVGT feature wrapper, training loops, and visualization/eval path now use one shape only: `[B, 8, 6, 3, H, W]`. The old single-keyframe `T=1` path is intentionally removed.
- RGB follows the GLD decoder recipe: project-integrated MAE ViT decoder, ImageNet-normalized patch reconstruction, L1 + LPIPS + adaptive DINO/StyleGAN-T-style adversarial loss, 224x224 discriminator crops, DiffAug, EMA, and cosine schedules.
- Depth/semantic keep the local MAE-style token decoder and occupancy keeps the lightweight BEV decoder.
- RGB LPIPS and discriminator checkpoints are local config paths; no runtime download path is used by the training code.
- Relative-path bash launch scripts that work from any checkout location.

## Config Paths

The YAML configs provide all dataset and weight roots:

```yaml
paths:
  dvgt_ckpt_path: /data/wlh/GLD/DVGT-model/DVGT-1/dvgt1.pt
data:
  nuscenes_root: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval
  table_dir: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval/v1.0-trainval
  depth_root: /data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_dvgtcrop_256x704_fp16/align_depth
  lidarseg_root: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval/lidarseg
  occupancy_root: /data/wlh/SurroundOcc/nuscenes_occ
  sequence_length: 8
  original_fps: 2
  target_fps: 2
  window_stride: 1
  max_frame_gap_factor: 1.5
gan:
  disc:
    arch:
      dino_ckpt_path: /data/wlh/GLD/code/models/discs/dino_vit_small_patch8_224.pth
loss:
  lpips_weight_path: /data/wlh/.cache/torch/hub/checkpoints/vgg.pth
  vgg16_weight_path: /data/wlh/.cache/torch/hub/checkpoints/vgg16-397923af.pth
```

`lidarseg_root` is read directly from config. The loader does not keep old fallback search logic.

## Migration Checklist

Before moving this project to another training machine, prepare these local files and update the YAML paths:

```yaml
paths:
  dvgt_ckpt_path: /path/to/dvgt1.pt
gan:
  disc:
    arch:
      dino_ckpt_path: /path/to/dino_vit_small_patch8_224.pth
loss:
  lpips_weight_path: /path/to/lpips/vgg.pth
  vgg16_weight_path: /path/to/torchvision/vgg16-397923af.pth
```

Required local pretrained weights:

- `dvgt1.pt`: DVGT-1 checkpoint used by all four decoders. This is the only DVGT/DINOv3 backbone weight entry; there is no separate `dino_v3_weight_path`.
- `dino_vit_small_patch8_224.pth`: local DINO checkpoint for the RGB GLD-style discriminator.
- `vgg.pth`: LPIPS linear-layer checkpoint for RGB perceptual loss.
- `vgg16-397923af.pth`: torchvision VGG16 checkpoint used as the LPIPS feature backbone.

Project code already includes the required DVGT core under `dvgt/`, DINOv3 code under `third_party/dinov3/`, and decoder config under `decoder_ViTXL/config.json`; those are not external pretrained weights. Runtime model download is disabled. Missing pretrained files fail immediately with `FileNotFoundError`.

Also prepare the training data roots in config: nuScenes trainval root and tables, nuScenes `lidarseg`, SurroundOcc occupancy labels, and MoGe depth generated with the same DVGT-style resize/crop. The expected depth root is the DVGT-crop output, for example:

```text
/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_dvgtcrop_256x704_fp16/align_depth
```

Do not reuse the old top-crop MoGe output merely because it is `256x704`; RGB/depth/semantic geometry will not align.

## Formal Config Status

The four YAML files under `configs/` are intended for real training, not smoke tests:

- All use full fixed `T=8`, `V=6` nuScenes sequences at final `704x256`.
- `max_train_samples: null`; there is no train-set truncation or hidden `max_steps` in config.
- RGB keeps the GLD-style `L1 + LPIPS + adaptive DINO GAN` recipe, EMA, BF16, cosine schedule, decoder checkpointing, and local LPIPS/DINO weights.
- Depth keeps masked Charbonnier plus image-gradient supervision, EMA, BF16, grad clip, and cosine schedule.
- Semantic keeps cross-entropy with `ignore_index: 255` on lidarseg projection labels.
- Occupancy keeps sparse SurroundOcc supervision with the BEV occupancy decoder and cross-entropy `ignore_index: 255`.

`batch_size` is a formal default and is counted per DDP process. It can be overridden at launch for hardware fit. In the latest one-step DDP launch verification, RGB required the 48 GB cards for batch size 1; depth, semantic, and occupancy ran on 24 GB cards at batch size 1.

## Training

From the project directory on the training server:

```bash
CUDA_VISIBLE_DEVICES=2 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_remote_training.sh rgb --max-duration-seconds 25200 --batch-size 2

CUDA_VISIBLE_DEVICES=3 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_remote_training.sh semantic --max-duration-seconds 25200 --batch-size 2
```

`batch_size` counts full 8-frame sequences, so one RGB/Semantic batch item contains `8 x 6 = 48` supervised camera images. Frame sampling follows DVGT: the source metadata is treated as `original_fps`, first downsampled by `original_fps // target_fps`, then continuous windows are built on that target-FPS sequence. For nuScenes the default is `2 -> 2`, so it uses consecutive 2Hz keyframes, with timestamp-gap filtering to reject broken clips. Logs are written to `logs/train_<modality>.log`. Resumeable checkpoints are written under:

`data.image_size: [704, 256]` is the final network input size after aspect-preserving resize and crop, not a direct resize target. Existing RGB/semantic eval images produced before this fix were generated from stretched supervision and should be treated as invalid. Depth files that are already `256x704` must have been generated with the same DVGT-style crop; otherwise regenerate them, because shape alone cannot prove geometric alignment.

```text
results/stage1-nuscenes-704x256/<modality>/checkpoints/
```

The duration stop writes `checkpoints/last.pt`.

### Single-node 8-GPU launcher

`scripts/start_stage1_8gpu_ddp.sh` starts the four Stage 1 trainings as four independent `torchrun` jobs and waits until all of them finish:

```bash
CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_stage1_8gpu_ddp.sh --max-duration-seconds 25200 --batch-size 2
```

Default GPU assignment is RGB on `0,1`, depth on `2,3`, semantic on `4,5`, and occupancy on `6,7`. Each job uses `--nproc_per_node=2`; `training.batch_size` and `--batch-size` are per process, so the effective batch for each modality is `batch_size x 2` full 8-frame sequences. Logs, pids, and exit codes are written under `logs/stage1_8gpu_ddp/`.

For single-modality debugging, use the dedicated 2-GPU DDP launchers:

```bash
GPUS=2,3 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_stage1_rgb_2gpu_ddp.sh --batch-size 2

GPUS=2,3 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_stage1_depth_2gpu_ddp.sh --batch-size 2

GPUS=2,3 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_stage1_semantic_2gpu_ddp.sh --batch-size 2

GPUS=2,3 CONDA_SH=/data/wlh/miniconda3/etc/profile.d/conda.sh CONDA_ENV_NAME=gld \
  bash scripts/start_stage1_occupancy_2gpu_ddp.sh --batch-size 2
```

Each single-modality launcher runs in the foreground and exits with the underlying `torchrun` status. It accepts the same extra arguments as the matching `train_*.py` file, so short manual probes can still pass `--max-steps`, but the checked-in YAML configs themselves are full training configs. Defaults are `NPROC_PER_NODE=2` and unique ports `29511/29521/29531/29541`; override `MASTER_PORT` when running multiple single-modality debug jobs at the same time. Logs and exit codes are written under `logs/stage1_<modality>_2gpu_ddp/`.

## Visualization

```bash
python scripts/eval_stage1.py \
  --modality rgb \
  --ckpt results/stage1-nuscenes-704x256/rgb/checkpoints/last.pt
```

Supported modalities are `rgb`, `depth`, `semantic`, and `occupancy`. Eval/visualization also feeds DVGT with full `[B,8,6,3,H,W]` sequences and saves per-frame six-view outputs:

```text
vis_<modality>/sample_0000_seq_00/t00_<modality>.png
...
vis_<modality>/sample_0000_seq_00/t07_<modality>.png
```

For RGB/depth/semantic, each `tXX` image is a two-row grid: six-view ground truth followed by six-view decoder prediction. Occupancy saves per-frame BEV grids. Old checkpoints trained with `T=1` features are not distribution-matched to this `T=8` path; retraining or finetuning with the current scripts is recommended.

## Offline Policy

- No external `gld_src_dir` or `dvgt_code_dir` is accepted.
- Model weights are never downloaded at runtime.
- Missing local pretrained files raise `FileNotFoundError`.
- `torch.hub.load` is monkeypatched while building DVGT so it can only load the project-local DINO repo.

## Deferred Items

- RGB uses PyTorch SDPA attention in the integrated GLD MAE decoder and DINO discriminator, decoder activation checkpointing, and exact chunked LPIPS to keep the full GLD loss trainable on one 48 GB GPU.
- Horizontal flip augmentation is not enabled yet because camera indices, trajectory transforms, intrinsics/extrinsics, lidarseg projection, and point maps must be synchronized.
- Long-horizon benchmarks, TensorRT export, extra decoder eval suites, and occupancy-loss ablations are left for later passes.
