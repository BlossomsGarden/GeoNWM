ip: 219.223.207.223

port: 22

user_name: wlh

password: wlh@2025

connect-tool: paramiko (already installed) or scp

# 请注意，不要创建什么文件软链接，直接让代码文件里的路径指向这些地方就行了

# 如果需要修改文件，直接在本地改改文件（如果没有就把必要文件拉下来），改完再scp推上去就完事了

# 除了可视化结果图片或视频，其他计算尽量都在云端完成

project_dir: /data/wlh/GLD/

work_dir: /data/wlh/GLD/code/

model_dir: /data/wlh/GLD/model/

nuscenes_dir: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval

nuscenes_depth_dir: /data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth 

nuscenes_semantic_dir: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval/lidarseg

nuscenes_occupancy_dir:  /data/wlh/SurroundOcc/nuscenes_occ 

conda_dir:/data/wlh/miniconda3

conda_env_name: gld

