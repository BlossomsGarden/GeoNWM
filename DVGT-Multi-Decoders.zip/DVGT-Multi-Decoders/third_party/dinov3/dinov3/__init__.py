"""Project-local DINOv3 subset required by DVGT."""
