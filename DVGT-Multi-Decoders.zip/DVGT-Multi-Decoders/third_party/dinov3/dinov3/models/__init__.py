"""DINOv3 model subset."""
