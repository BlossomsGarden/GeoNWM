from __future__ import annotations

from pathlib import Path

import torch

from dinov3.models.vision_transformer import DinoVisionTransformer


dependencies = ["torch", "numpy"]


def dinov3_vitl16(*, pretrained: bool = False, weights: str | None = None, **kwargs):
    model = DinoVisionTransformer(
        img_size=224,
        patch_size=16,
        in_chans=3,
        pos_embed_rope_base=100,
        pos_embed_rope_normalize_coords="separate",
        pos_embed_rope_rescale_coords=2,
        pos_embed_rope_dtype="fp32",
        embed_dim=1024,
        depth=24,
        num_heads=16,
        ffn_ratio=4,
        qkv_bias=True,
        drop_path_rate=0.0,
        layerscale_init=1.0e-05,
        norm_layer="layernormbf16",
        ffn_layer="mlp",
        ffn_bias=True,
        proj_bias=True,
        n_storage_tokens=4,
        mask_k_bias=True,
        pretrained=False,
        **kwargs,
    )
    if pretrained or weights is not None:
        if not weights:
            raise FileNotFoundError("DINOv3 weights must be provided as a local file path.")
        weight_path = Path(weights)
        if not weight_path.is_file():
            raise FileNotFoundError(f"DINOv3 weights not found: {weight_path}")
        state = torch.load(weight_path, map_location="cpu")
        if isinstance(state, dict):
            state = state.get("model", state.get("state_dict", state))
        model.load_state_dict(state, strict=True)
    else:
        model.init_weights()
    return model
