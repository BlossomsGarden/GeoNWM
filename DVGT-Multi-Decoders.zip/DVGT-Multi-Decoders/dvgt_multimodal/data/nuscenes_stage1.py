from __future__ import annotations

import json
import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF


CAMERAS = (
    "CAM_FRONT",
    "CAM_FRONT_LEFT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_BACK_RIGHT",
)

RAW_TO_17 = np.full(32, 255, dtype=np.uint8)
RAW_TO_17[[0, 1, 5, 7, 8, 10, 11, 13, 19, 20, 29, 31]] = 0
RAW_TO_17[9] = 1
RAW_TO_17[14] = 2
RAW_TO_17[15] = 3
RAW_TO_17[16] = 3
RAW_TO_17[17] = 4
RAW_TO_17[18] = 5
RAW_TO_17[21] = 6
RAW_TO_17[2] = 7
RAW_TO_17[3] = 7
RAW_TO_17[4] = 7
RAW_TO_17[6] = 7
RAW_TO_17[12] = 8
RAW_TO_17[22] = 9
RAW_TO_17[23] = 10
RAW_TO_17[24] = 11
RAW_TO_17[25] = 12
RAW_TO_17[26] = 13
RAW_TO_17[27] = 14
RAW_TO_17[28] = 15
RAW_TO_17[30] = 16


def _resolve_nuscenes_path(root: Path, path_value: str) -> Path:
    rel = path_value.replace("./data/nuscenes/", "")
    return root / rel


def _quat_to_rotmat(q: list[float] | np.ndarray) -> np.ndarray:
    w, x, y, z = [float(v) for v in q]
    n = w * w + x * x + y * y + z * z
    if n < 1e-12:
        return np.eye(3, dtype=np.float32)
    s = 2.0 / n
    wx, wy, wz = s * w * x, s * w * y, s * w * z
    xx, xy, xz = s * x * x, s * x * y, s * x * z
    yy, yz, zz = s * y * y, s * y * z, s * z * z
    return np.array(
        [
            [1.0 - (yy + zz), xy - wz, xz + wy],
            [xy + wz, 1.0 - (xx + zz), yz - wx],
            [xz - wy, yz + wx, 1.0 - (xx + yy)],
        ],
        dtype=np.float32,
    )


def _make_transform(rotation: list[float], translation: list[float]) -> np.ndarray:
    mat = np.eye(4, dtype=np.float32)
    mat[:3, :3] = _quat_to_rotmat(rotation)
    mat[:3, 3] = np.asarray(translation, dtype=np.float32)
    return mat


def _invert_transform(mat: np.ndarray) -> np.ndarray:
    out = np.eye(4, dtype=np.float32)
    out[:3, :3] = mat[:3, :3].T
    out[:3, 3] = -out[:3, :3] @ mat[:3, 3]
    return out


def _scatter_nearest_semantic(
    uv: np.ndarray,
    depth: np.ndarray,
    labels: np.ndarray,
    height: int,
    width: int,
    ignore_index: int,
) -> np.ndarray:
    valid = (
        (depth > 0.05)
        & np.isfinite(depth)
        & (uv[:, 0] >= 0)
        & (uv[:, 0] < width)
        & (uv[:, 1] >= 0)
        & (uv[:, 1] < height)
        & (labels != ignore_index)
    )
    sem = np.full((height, width), ignore_index, dtype=np.uint8)
    if not np.any(valid):
        return sem
    xs = np.clip(np.rint(uv[valid, 0]).astype(np.int64), 0, width - 1)
    ys = np.clip(np.rint(uv[valid, 1]).astype(np.int64), 0, height - 1)
    ds = depth[valid]
    ls = labels[valid]
    order = np.argsort(ds)[::-1]
    sem[ys[order], xs[order]] = ls[order]
    return sem


class NuScenesStage1Dataset(Dataset):
    """nuScenes keyframe loader for stage-1 decoder training."""

    def __init__(
        self,
        root: str,
        split: str,
        image_size: list[int] | tuple[int, int] = (704, 256),
        depth_root: str | None = None,
        occ_root: str | None = None,
        table_dir: str | None = None,
        cameras: list[str] | tuple[str, ...] = CAMERAS,
        max_samples: int | None = None,
        filter_scan_limit: int | None = None,
        require_depth: bool = False,
        require_semantic: bool = False,
        require_occupancy: bool = False,
        semantic_classes: int = 17,
        ignore_index: int = 255,
    ):
        self.root = Path(root)
        self.split = split
        self.width, self.height = int(image_size[0]), int(image_size[1])
        self.depth_root = Path(depth_root) if depth_root else None
        self.occ_root = Path(occ_root) if occ_root else None
        self.table_dir = Path(table_dir) if table_dir else self.root / "v1.0-trainval"
        self.cameras = tuple(cameras)
        self.require_depth = bool(require_depth)
        self.require_semantic = bool(require_semantic)
        self.require_occupancy = bool(require_occupancy)
        self.semantic_classes = int(semantic_classes)
        self.ignore_index = int(ignore_index)
        if self.semantic_classes != 17:
            raise ValueError("NuScenesStage1Dataset currently exposes the planned 17-class semantic space only.")
        if self.width % 16 != 0 or self.height % 16 != 0:
            raise ValueError(f"image_size must be divisible by DVGT patch size 16, got {(self.width, self.height)}")

        info_path = self.root / f"nuscenes_infos_{'train' if split == 'train' else 'val'}.pkl"
        with info_path.open("rb") as f:
            self.infos = pickle.load(f)["infos"]
        self.max_samples = None if max_samples is None else int(max_samples)
        self.filter_scan_limit = None if filter_scan_limit is None else int(filter_scan_limit)

        self._sample_data_by_filename: dict[str, dict[str, Any]] | None = None
        self._lidarseg_by_sample_data_token: dict[str, str] | None = None
        if self.require_semantic:
            self._load_lidarseg_tables()

        self._filter_missing_targets()

    def _load_lidarseg_tables(self) -> None:
        with (self.table_dir / "sample_data.json").open("r", encoding="utf-8") as f:
            sample_data = json.load(f)
        self._sample_data_by_filename = {str(row["filename"]): row for row in sample_data}
        with (self.table_dir / "lidarseg.json").open("r", encoding="utf-8") as f:
            lidarseg = json.load(f)
        self._lidarseg_by_sample_data_token = {
            str(row["sample_data_token"]): str(row["filename"]) for row in lidarseg
        }

    def _filter_missing_targets(self) -> None:
        kept = []
        scanned = 0
        for info in self.infos:
            scanned += 1
            try:
                self._target_paths(info)
            except FileNotFoundError:
                if self.filter_scan_limit is not None and scanned >= self.filter_scan_limit:
                    break
                continue
            kept.append(info)
            if self.max_samples is not None and len(kept) >= self.max_samples:
                break
            if self.filter_scan_limit is not None and scanned >= self.filter_scan_limit:
                break
        if not kept:
            raise RuntimeError(f"No usable nuScenes samples found for split={self.split}")
        self.infos = kept

    def _target_paths(self, info: dict[str, Any]) -> dict[str, Any]:
        paths: dict[str, Any] = {"images": {}, "depth": {}}
        for cam in self.cameras:
            image_path = _resolve_nuscenes_path(self.root, info["cams"][cam]["data_path"])
            if not image_path.exists():
                raise FileNotFoundError(image_path)
            paths["images"][cam] = image_path
            if self.require_depth:
                if self.depth_root is None:
                    raise FileNotFoundError("depth_root is not configured")
                depth_path = self.depth_root / cam / f"{image_path.stem}.npz"
                if not depth_path.exists():
                    raise FileNotFoundError(depth_path)
                paths["depth"][cam] = depth_path

        lidar_rel = info["lidar_path"].replace("./data/nuscenes/", "")
        lidar_path = self.root / lidar_rel
        if self.require_semantic:
            if self._sample_data_by_filename is None or self._lidarseg_by_sample_data_token is None:
                raise RuntimeError("lidarseg tables were not loaded")
            row = self._sample_data_by_filename.get(lidar_rel)
            if row is None:
                raise FileNotFoundError(lidar_rel)
            seg_rel = self._lidarseg_by_sample_data_token.get(row["token"])
            if seg_rel is None:
                raise FileNotFoundError(row["token"])
            seg_path = self.root / seg_rel
            if not lidar_path.exists() or not seg_path.exists():
                raise FileNotFoundError(f"{lidar_path} / {seg_path}")
            paths["lidar"] = lidar_path
            paths["lidarseg"] = seg_path

        if self.require_occupancy:
            if self.occ_root is None:
                raise FileNotFoundError("occ_root is not configured")
            occ_path = self.occ_root / "samples" / f"{Path(info['lidar_path']).name}.npy"
            if not occ_path.exists():
                raise FileNotFoundError(occ_path)
            paths["occupancy"] = occ_path
        return paths

    def __len__(self) -> int:
        return len(self.infos)

    def _load_image(self, path: Path) -> torch.Tensor:
        image = Image.open(path).convert("RGB")
        image = image.resize((self.width, self.height), Image.Resampling.BICUBIC)
        return TF.to_tensor(image)

    def _scaled_intrinsics(self, cam_info: dict[str, Any]) -> np.ndarray:
        intr = np.array(cam_info["camera_intrinsics"], dtype=np.float32)
        sx = self.width / 1600.0
        sy = self.height / 900.0
        intr[0, :] *= sx
        intr[1, :] *= sy
        return intr

    def _load_depth(self, path: Path) -> tuple[torch.Tensor, torch.Tensor]:
        data = np.load(path)
        depth = torch.from_numpy(data["depth"].astype(np.float32))[None]
        mask = torch.from_numpy(data["mask"].astype(np.float32))[None]
        if depth.shape[-2:] != (self.height, self.width):
            depth = F.interpolate(depth[None], size=(self.height, self.width), mode="nearest")[0]
            mask = F.interpolate(mask[None], size=(self.height, self.width), mode="nearest")[0]
        mask = (mask > 0.5) & torch.isfinite(depth) & (depth > 0)
        return depth, mask.float()

    def _load_semantic_views(self, info: dict[str, Any], paths: dict[str, Any]) -> torch.Tensor:
        points = np.fromfile(paths["lidar"], dtype=np.float32).reshape(-1, 5)[:, :3]
        raw_labels = np.fromfile(paths["lidarseg"], dtype=np.uint8)
        if points.shape[0] != raw_labels.shape[0]:
            raise ValueError(f"LiDAR points and lidarseg labels mismatch for {paths['lidar']}")
        labels = RAW_TO_17[np.minimum(raw_labels, 31)]

        sem_views = []
        pts_h = np.concatenate([points.astype(np.float32), np.ones((points.shape[0], 1), dtype=np.float32)], axis=1)
        for cam in self.cameras:
            cam_info = info["cams"][cam]
            sensor_to_lidar = np.eye(4, dtype=np.float32)
            sensor_to_lidar[:3, :3] = np.asarray(cam_info["sensor2lidar_rotation"], dtype=np.float32)
            sensor_to_lidar[:3, 3] = np.asarray(cam_info["sensor2lidar_translation"], dtype=np.float32)
            lidar_to_sensor = _invert_transform(sensor_to_lidar)
            cam_points = (lidar_to_sensor @ pts_h.T).T[:, :3]
            intr = self._scaled_intrinsics(cam_info)
            proj = cam_points @ intr.T
            depth = cam_points[:, 2]
            uv = proj[:, :2] / np.maximum(proj[:, 2:3], 1e-6)
            sem = _scatter_nearest_semantic(uv, depth, labels, self.height, self.width, self.ignore_index)
            sem_views.append(torch.from_numpy(sem.astype(np.int64)))
        return torch.stack(sem_views, dim=0)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        info = self.infos[idx]
        paths = self._target_paths(info)
        images, intrinsics, sensor_to_lidar = [], [], []
        labels = []
        for cam in self.cameras:
            cam_info = info["cams"][cam]
            images.append(self._load_image(paths["images"][cam]))
            intrinsics.append(torch.from_numpy(self._scaled_intrinsics(cam_info)))
            s2l = np.eye(4, dtype=np.float32)
            s2l[:3, :3] = np.asarray(cam_info["sensor2lidar_rotation"], dtype=np.float32)
            s2l[:3, 3] = np.asarray(cam_info["sensor2lidar_translation"], dtype=np.float32)
            sensor_to_lidar.append(torch.from_numpy(s2l))
            labels.append(str(paths["images"][cam].relative_to(self.root)))

        sample: dict[str, Any] = {
            "sample_token": info["token"],
            "lidar_path": str(_resolve_nuscenes_path(self.root, info["lidar_path"])),
            "images": torch.stack(images, dim=0),
            "intrinsics": torch.stack(intrinsics, dim=0),
            "sensor_to_lidar": torch.stack(sensor_to_lidar, dim=0),
            "labels": labels,
        }
        if self.require_depth:
            depths, depth_masks = [], []
            for cam in self.cameras:
                depth, mask = self._load_depth(paths["depth"][cam])
                depths.append(depth)
                depth_masks.append(mask)
            sample["depth"] = torch.stack(depths, dim=0)
            sample["depth_mask"] = torch.stack(depth_masks, dim=0)
        if self.require_semantic:
            sample["semantic"] = self._load_semantic_views(info, paths)
        if self.require_occupancy:
            occ = np.load(paths["occupancy"]).astype(np.int64)
            sample["occupancy_sparse"] = torch.from_numpy(occ)
            sample["occupancy_path"] = str(paths["occupancy"])
        return sample


def collate_stage1_batch(samples: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    tensor_keys = {
        "images",
        "intrinsics",
        "sensor_to_lidar",
        "depth",
        "depth_mask",
        "semantic",
    }
    for key in samples[0].keys():
        if key in tensor_keys and torch.is_tensor(samples[0][key]):
            out[key] = torch.stack([s[key] for s in samples], dim=0)
        elif key == "occupancy_sparse":
            out[key] = [s[key] for s in samples]
        else:
            out[key] = [s[key] for s in samples]
    return out
