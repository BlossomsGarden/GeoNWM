"""nuScenes multi-modal decoders on frozen DVGT features."""

