from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


def _get_1d_sincos_pos_embed(embed_dim: int, positions: np.ndarray) -> np.ndarray:
    if embed_dim % 2 != 0:
        raise ValueError(f"embed_dim must be even for sin-cos embedding, got {embed_dim}")
    omega = np.arange(embed_dim // 2, dtype=np.float64)
    omega /= embed_dim / 2.0
    omega = 1.0 / (10000**omega)
    out = np.einsum("m,d->md", positions.reshape(-1), omega)
    return np.concatenate([np.sin(out), np.cos(out)], axis=1)


def _get_2d_sincos_pos_embed(embed_dim: int, grid_h: int, grid_w: int, add_cls_token: bool) -> np.ndarray:
    if embed_dim % 2 != 0:
        raise ValueError(f"embed_dim must be even for 2D sin-cos embedding, got {embed_dim}")
    grid_y = np.arange(grid_h, dtype=np.float64)
    grid_x = np.arange(grid_w, dtype=np.float64)
    grid = np.meshgrid(grid_x, grid_y)
    emb_x = _get_1d_sincos_pos_embed(embed_dim // 2, grid[0])
    emb_y = _get_1d_sincos_pos_embed(embed_dim // 2, grid[1])
    emb = np.concatenate([emb_x, emb_y], axis=1)
    if add_cls_token:
        emb = np.concatenate([np.zeros((1, embed_dim), dtype=np.float64), emb], axis=0)
    return emb.astype(np.float32)


def _load_local_config(config_path: str | Path) -> SimpleNamespace:
    path = Path(config_path)
    if path.is_dir():
        path = path / "config.json"
    if not path.is_file():
        raise FileNotFoundError(f"Decoder config must be a local JSON file, got: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return SimpleNamespace(**data)


class _DecoderOutput(SimpleNamespace):
    pass


class GeneralDecoderVariable(nn.Module):
    """Local MAE-style patch decoder used instead of importing GLD stage1 code."""

    def __init__(self, config: SimpleNamespace, base_image_size: tuple[int, int]):
        super().__init__()
        self.config = config
        self.decoder_embed = nn.Linear(config.hidden_size, config.decoder_hidden_size, bias=True)
        p = int(config.patch_size)
        h0, w0 = int(base_image_size[0]), int(base_image_size[1])
        if h0 % p != 0 or w0 % p != 0:
            raise ValueError(f"base_image_size {base_image_size} must be divisible by patch_size={p}")
        self.base_grid = (h0 // p, w0 // p)
        base_num_patches = self.base_grid[0] * self.base_grid[1]
        self.decoder_pos_embed = nn.Parameter(
            torch.zeros(1, base_num_patches + 1, int(config.decoder_hidden_size)),
            requires_grad=False,
        )
        self.trainable_cls_token = nn.Parameter(torch.zeros(1, 1, int(config.decoder_hidden_size)))
        layer = nn.TransformerEncoderLayer(
            d_model=int(config.decoder_hidden_size),
            nhead=int(config.decoder_num_attention_heads),
            dim_feedforward=int(getattr(config, "decoder_intermediate_size", config.decoder_hidden_size * 4)),
            dropout=float(getattr(config, "hidden_dropout_prob", 0.0)),
            activation=str(getattr(config, "hidden_act", "gelu")),
            batch_first=True,
            norm_first=True,
        )
        self.decoder_layers = nn.TransformerEncoder(layer, num_layers=int(config.decoder_num_hidden_layers))
        self.decoder_norm = nn.LayerNorm(int(config.decoder_hidden_size), eps=float(getattr(config, "layer_norm_eps", 1e-12)))
        self.decoder_pred = nn.Linear(
            int(config.decoder_hidden_size),
            int(config.patch_size) ** 2 * int(config.num_channels),
            bias=True,
        )
        self.initialize_weights()

    def initialize_weights(self) -> None:
        h0p, w0p = self.base_grid
        pe = _get_2d_sincos_pos_embed(self.decoder_pos_embed.shape[-1], h0p, w0p, add_cls_token=True)
        self.decoder_pos_embed.data.copy_(torch.from_numpy(pe).float().unsqueeze(0))
        nn.init.normal_(self.trainable_cls_token, std=0.02)
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.LayerNorm):
                nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)

    def interpolate_pos_encoding(self, target_grid: tuple[int, int]) -> torch.Tensor:
        hp, wp = int(target_grid[0]), int(target_grid[1])
        h0p, w0p = self.base_grid
        cls_pos = self.decoder_pos_embed[:, :1]
        patch_pos = self.decoder_pos_embed[:, 1:].reshape(1, h0p, w0p, -1).permute(0, 3, 1, 2)
        patch_pos = nn.functional.interpolate(patch_pos, size=(hp, wp), mode="bicubic", align_corners=False)
        patch_pos = patch_pos.permute(0, 2, 3, 1).reshape(1, hp * wp, -1)
        return torch.cat([cls_pos, patch_pos], dim=1)

    def forward(self, hidden_states: torch.Tensor, input_size: tuple[int, int], drop_cls_token: bool = False, **_) -> _DecoderOutput:
        x = self.decoder_embed(hidden_states)
        h, w = int(input_size[0]), int(input_size[1])
        p = int(self.config.patch_size)
        if h % p != 0 or w % p != 0:
            raise ValueError(f"input_size {input_size} must be divisible by patch_size={p}")
        target_grid = (h // p, w // p)
        target_num_patches = target_grid[0] * target_grid[1]
        x_tokens = x[:, 1:] if drop_cls_token else x
        if x_tokens.shape[1] != target_num_patches:
            raise ValueError(
                f"Patch token length mismatch: got N={x_tokens.shape[1]}, expected {target_num_patches} "
                f"for input_size={input_size}, patch_size={p}."
            )
        cls_token = self.trainable_cls_token.expand(x_tokens.shape[0], -1, -1)
        x = torch.cat([cls_token, x_tokens], dim=1)
        pos = self.interpolate_pos_encoding(target_grid).to(device=x.device, dtype=x.dtype)
        x = self.decoder_layers(x + pos)
        x = self.decoder_norm(x)
        logits = self.decoder_pred(x)[:, 1:]
        return _DecoderOutput(logits=logits, hidden_states=None, attentions=None)

    def unpatchify(self, patchified_pixel_values: torch.Tensor, original_image_size: tuple[int, int]) -> torch.Tensor:
        p = int(self.config.patch_size)
        c = int(self.config.num_channels)
        h, w = int(original_image_size[0]), int(original_image_size[1])
        if h % p != 0 or w % p != 0:
            raise ValueError(f"original_image_size {original_image_size} must be divisible by patch_size={p}")
        gh, gw = h // p, w // p
        if patchified_pixel_values.shape[1] != gh * gw:
            raise ValueError(f"patch count mismatch: got {patchified_pixel_values.shape[1]}, expected {gh * gw}")
        x = patchified_pixel_values.reshape(patchified_pixel_values.shape[0], gh, gw, p, p, c)
        x = torch.einsum("nhwpqc->nchpwq", x)
        return x.reshape(patchified_pixel_values.shape[0], c, h, w)


class PatchTokenDecoder(nn.Module):
    """MAE-style token decoder with configurable output channels."""

    def __init__(
        self,
        config_path: str,
        hidden_size: int,
        out_channels: int,
        patch_size: int = 16,
        base_image_size: tuple[int, int] = (256, 256),
        decoder_hidden_size: int | None = None,
        decoder_layers: int | None = None,
        decoder_heads: int | None = None,
    ):
        super().__init__()
        cfg = _load_local_config(config_path)
        cfg.hidden_size = int(hidden_size)
        cfg.patch_size = int(patch_size)
        cfg.num_channels = int(out_channels)
        if decoder_hidden_size is not None:
            cfg.decoder_hidden_size = int(decoder_hidden_size)
        if decoder_layers is not None:
            cfg.decoder_num_hidden_layers = int(decoder_layers)
        if decoder_heads is not None:
            cfg.decoder_num_attention_heads = int(decoder_heads)
        if not hasattr(cfg, "decoder_intermediate_size"):
            cfg.decoder_intermediate_size = int(cfg.decoder_hidden_size) * 4
        self.decoder = GeneralDecoderVariable(cfg, base_image_size=tuple(base_image_size))
        self.config = cfg
        self.out_channels = int(out_channels)

    @property
    def decoder_pred(self):
        return self.decoder.decoder_pred

    def forward(self, tokens: torch.Tensor, image_size: tuple[int, int]) -> torch.Tensor:
        logits = self.decoder(tokens, input_size=image_size, drop_cls_token=False).logits
        return self.decoder.unpatchify(logits, image_size)
