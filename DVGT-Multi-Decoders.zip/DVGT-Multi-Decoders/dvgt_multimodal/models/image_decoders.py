from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Optional

import torch
from torch import nn
from transformers import AutoConfig


class PatchTokenDecoder(nn.Module):
    """GLD MAE-style token decoder with configurable output channels."""

    def __init__(
        self,
        gld_src_dir: str,
        config_path: str,
        hidden_size: int,
        out_channels: int,
        patch_size: int = 16,
        base_image_size: tuple[int, int] = (256, 256),
        decoder_hidden_size: int | None = None,
        decoder_layers: int | None = None,
        decoder_heads: int | None = None,
    ):
        super().__init__()
        import sys

        src = str(Path(gld_src_dir))
        if src not in sys.path:
            sys.path.insert(0, src)
        from stage1.decoders import GeneralDecoder_Variable

        cfg = AutoConfig.from_pretrained(str(config_path))
        cfg.hidden_size = int(hidden_size)
        cfg.patch_size = int(patch_size)
        cfg.num_channels = int(out_channels)
        if decoder_hidden_size is not None:
            cfg.decoder_hidden_size = int(decoder_hidden_size)
        if decoder_layers is not None:
            cfg.decoder_num_hidden_layers = int(decoder_layers)
        if decoder_heads is not None:
            cfg.decoder_num_attention_heads = int(decoder_heads)
        self.decoder = GeneralDecoder_Variable(cfg, base_image_size=tuple(base_image_size))
        self.config = cfg
        self.out_channels = int(out_channels)

    @property
    def decoder_pred(self):
        return self.decoder.decoder_pred

    def forward(self, tokens: torch.Tensor, image_size: tuple[int, int]) -> torch.Tensor:
        logits = self.decoder(tokens, input_size=image_size, drop_cls_token=False).logits
        return self.decoder.unpatchify(logits, image_size)

