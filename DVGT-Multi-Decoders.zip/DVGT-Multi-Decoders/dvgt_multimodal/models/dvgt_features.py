from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path

import torch
import torch.nn.functional as F


class DVGTFeatureExtractor(torch.nn.Module):
    """Frozen DVGT-1 aggregator wrapper returning concatenated patch tokens."""

    def __init__(
        self,
        ckpt_path: str,
        feature_indices: list[int] | tuple[int, ...] = (4, 11, 17, 23),
        per_level_layernorm: bool = True,
        device: torch.device | str = "cuda",
    ):
        super().__init__()
        self.project_dir = Path(__file__).resolve().parents[2]
        self.ckpt_path = self._resolve_existing_file(ckpt_path, "DVGT checkpoint")
        self.feature_indices = [int(x) for x in feature_indices]
        self.per_level_layernorm = bool(per_level_layernorm)
        self.device = torch.device(device)
        self.model = self._build_model().to(self.device).eval()
        for p in self.model.parameters():
            p.requires_grad_(False)

    @staticmethod
    def _resolve_existing_file(path_value: str | Path, label: str) -> Path:
        path = Path(path_value)
        if path.is_dir():
            ckpt_files = sorted(path.glob("*.pt")) + sorted(path.glob("*.pth"))
            if ckpt_files:
                path = ckpt_files[0]
        if not path.is_file():
            raise FileNotFoundError(f"{label} must be provided as a local file path, got: {path_value}")
        return path

    def _build_model(self):
        sys.path.insert(0, str(self.project_dir))
        module = importlib.import_module("dvgt.models.architectures.dvgt1")
        builder = getattr(module, "DVGT1")

        old_cwd = os.getcwd()
        orig_hub_load = torch.hub.load

        def hub_load_offline(repo_or_dir, model, *args, **kwargs):
            repo = Path(str(repo_or_dir))
            if not repo.is_absolute():
                repo = (self.project_dir / repo).resolve()
            if not repo.is_dir():
                raise RuntimeError(f"Online torch.hub.load is disabled; missing local hub repo: {repo}")
            if kwargs.get("pretrained", False) and not kwargs.get("weights") and not kwargs.get("checkpoint"):
                raise RuntimeError("Online pretrained torch.hub.load is disabled; pass local weights via config.")
            kwargs["source"] = "local"
            return orig_hub_load(str(repo), model, *args, **kwargs)

        torch.hub.load = hub_load_offline
        os.chdir(str(self.project_dir))
        try:
            model = builder(
                enable_ego_pose=False,
                enable_point=False,
            )
        finally:
            torch.hub.load = orig_hub_load
            os.chdir(old_cwd)

        state = torch.load(self.ckpt_path, map_location="cpu")
        if isinstance(state, dict):
            state = state.get("model", state.get("state_dict", state))
        missing, unexpected = model.load_state_dict(state, strict=False)
        print(f"[DVGT] loaded {self.ckpt_path} missing={len(missing)} unexpected={len(unexpected)}")
        return model

    @torch.no_grad()
    def forward(self, images_01: torch.Tensor) -> torch.Tensor:
        """Return features shaped (B,T,V,N,C_total) from images (B,T,V,3,H,W)."""
        if images_01.ndim != 6:
            raise ValueError(f"Stage 1 expects images shaped (B,T,V,3,H,W), got {tuple(images_01.shape)}")
        images = images_01.to(self.device, non_blocking=True)
        b, t, v = images.shape[:3]
        if t != 8:
            raise ValueError(f"Stage 1 decoders now require fixed T=8 sequences, got T={t}")
        if v != 6:
            raise ValueError(f"Stage 1 decoders now require fixed V=6 nuScenes cameras, got V={v}")
        out_list, patch_start_idx = self.model.aggregator(images)
        feats = []
        for idx in self.feature_indices:
            out = out_list[idx]
            if out.ndim != 5:
                raise ValueError(f"Unexpected DVGT output rank for layer {idx}: {tuple(out.shape)}")
            feat = out[:, :, :, patch_start_idx:, :]
            if self.per_level_layernorm:
                feat = F.layer_norm(feat, (feat.shape[-1],))
            feats.append(feat)
        z = torch.cat(feats, dim=-1)
        return z.reshape(b, t, v, z.shape[-2], z.shape[-1]).contiguous()
