from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path

import torch
import torch.nn.functional as F


class DVGTFeatureExtractor(torch.nn.Module):
    """Frozen DVGT-1 aggregator wrapper returning concatenated patch tokens."""

    def __init__(
        self,
        code_dir: str,
        ckpt_dir: str,
        feature_indices: list[int] | tuple[int, ...] = (4, 11, 17, 23),
        per_level_layernorm: bool = True,
        device: torch.device | str = "cuda",
    ):
        super().__init__()
        self.code_dir = Path(code_dir)
        self.ckpt_dir = Path(ckpt_dir)
        self.feature_indices = [int(x) for x in feature_indices]
        self.per_level_layernorm = bool(per_level_layernorm)
        self.device = torch.device(device)
        self.model = self._build_model().to(self.device).eval()
        for p in self.model.parameters():
            p.requires_grad_(False)

    def _build_model(self):
        if not self.code_dir.is_dir():
            raise FileNotFoundError(f"DVGT code_dir does not exist: {self.code_dir}")
        sys.path.insert(0, str(self.code_dir))
        module = importlib.import_module("dvgt.models.architectures.dvgt1")
        builder = getattr(module, "DVGT1")

        old_cwd = os.getcwd()
        orig_hub_load = torch.hub.load

        def hub_load_no_pretrain(repo_or_dir, model, *args, **kwargs):
            if "dinov3" in str(repo_or_dir) and "pretrained" not in kwargs:
                kwargs["pretrained"] = False
            return orig_hub_load(repo_or_dir, model, *args, **kwargs)

        torch.hub.load = hub_load_no_pretrain
        os.chdir(str(self.code_dir))
        try:
            try:
                model = builder(dino_v3_weight_path=None, enable_ego_pose=False, enable_point=False)
            except TypeError:
                model = builder(enable_ego_pose=False, enable_point=False)
        finally:
            torch.hub.load = orig_hub_load
            os.chdir(old_cwd)

        ckpt_files = sorted(self.ckpt_dir.glob("*.pt")) + sorted(self.ckpt_dir.glob("*.pth"))
        if not ckpt_files:
            raise FileNotFoundError(f"No DVGT checkpoint found under {self.ckpt_dir}")
        state = torch.load(ckpt_files[0], map_location="cpu")
        if isinstance(state, dict):
            state = state.get("model", state.get("state_dict", state))
        missing, unexpected = model.load_state_dict(state, strict=False)
        print(f"[DVGT] loaded {ckpt_files[0]} missing={len(missing)} unexpected={len(unexpected)}")
        return model

    @torch.no_grad()
    def forward(self, images_01: torch.Tensor) -> torch.Tensor:
        """Return features shaped (B*V, N, C_total) from images (B,V,3,H,W)."""
        if images_01.ndim != 5:
            raise ValueError(f"Expected images shaped (B,V,3,H,W), got {tuple(images_01.shape)}")
        images = images_01.unsqueeze(1).to(self.device, non_blocking=True)
        out_list, patch_start_idx = self.model.aggregator(images)
        b, one, v = images.shape[:3]
        feats = []
        for idx in self.feature_indices:
            out = out_list[idx]
            if out.ndim != 5:
                raise ValueError(f"Unexpected DVGT output rank for layer {idx}: {tuple(out.shape)}")
            feat = out[:, :, :, patch_start_idx:, :].mean(dim=1)
            if self.per_level_layernorm:
                feat = F.layer_norm(feat, (feat.shape[-1],))
            feats.append(feat)
        z = torch.cat(feats, dim=-1)
        return z.reshape(b * v, z.shape[-2], z.shape[-1]).contiguous()
