from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


class BEVOccupancyDecoder(nn.Module):
    """Efficient FlashOcc-style BEV decoder from frozen multi-view DVGT tokens."""

    def __init__(
        self,
        in_dim: int,
        num_classes: int = 17,
        num_views: int = 6,
        image_size: tuple[int, int] = (256, 704),
        patch_size: int = 16,
        bev_h: int = 200,
        bev_w: int = 200,
        occ_z: int = 16,
        hidden_dim: int = 256,
    ):
        super().__init__()
        self.num_classes = int(num_classes)
        self.num_views = int(num_views)
        self.image_size = tuple(int(x) for x in image_size)
        self.patch_size = int(patch_size)
        self.patch_h = self.image_size[0] // self.patch_size
        self.patch_w = self.image_size[1] // self.patch_size
        self.bev_h = int(bev_h)
        self.bev_w = int(bev_w)
        self.occ_z = int(occ_z)

        self.view_proj = nn.Sequential(
            nn.Conv2d(int(in_dim), hidden_dim, kernel_size=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(hidden_dim * self.num_views, hidden_dim, kernel_size=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.bev_net = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.head = nn.Conv2d(hidden_dim, self.num_classes * self.occ_z, kernel_size=1)

    def forward(self, tokens: torch.Tensor, batch_size: int) -> torch.Tensor:
        """Return logits shaped (B,C,Z,H,W)."""
        expected = self.patch_h * self.patch_w
        if tokens.shape[1] != expected:
            raise ValueError(f"Expected {expected} patch tokens, got {tokens.shape[1]}")
        x = tokens.transpose(1, 2).reshape(batch_size, self.num_views, tokens.shape[-1], self.patch_h, self.patch_w)
        x = x.reshape(batch_size * self.num_views, tokens.shape[-1], self.patch_h, self.patch_w)
        x = self.view_proj(x)
        x = F.interpolate(x, size=(self.bev_h, self.bev_w), mode="bilinear", align_corners=False)
        x = x.reshape(batch_size, self.num_views * x.shape[1], self.bev_h, self.bev_w)
        x = self.fuse(x)
        x = self.bev_net(x)
        x = self.head(x)
        return x.reshape(batch_size, self.num_classes, self.occ_z, self.bev_h, self.bev_w)

