from __future__ import annotations

import csv
import json
import logging
import os
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import DictConfig, OmegaConf
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler

from .data import NuScenesStage1Dataset, collate_stage1_batch


IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
IMAGENET_STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def resolve_project_path(path_value: str | Path | None, root: Path | None = None) -> Path | None:
    if path_value is None or str(path_value).strip().lower() in {"", "none", "null"}:
        return None
    path = Path(path_value)
    if path.is_absolute():
        return path
    return (root or project_root()) / path


def setup_logger(out_dir: Path, enabled: bool = True, rank: int = 0) -> logging.Logger:
    logger_name = str(out_dir) if enabled else f"{out_dir}.rank{rank}"
    logger = logging.getLogger(logger_name)
    logger.handlers.clear()
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not enabled:
        logger.addHandler(logging.NullHandler())
        return logger
    out_dir.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("[%(asctime)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    stream = logging.StreamHandler()
    stream.setFormatter(fmt)
    file_handler = logging.FileHandler(out_dir / "log.txt", encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def get_device(local_rank: int | None = None) -> torch.device:
    if not torch.cuda.is_available():
        return torch.device("cpu")
    index = int(local_rank) if local_rank is not None else 0
    return torch.device("cuda", index)


def precision_context(device: torch.device, precision: str):
    enabled = precision in ("fp16", "bf16") and device.type == "cuda"
    dtype = torch.float16 if precision == "fp16" else torch.bfloat16
    return torch.autocast(device_type="cuda", dtype=dtype, enabled=enabled)


def build_loader(
    cfg: DictConfig,
    split: str,
    require: dict[str, bool],
    max_samples: int | None = None,
    *,
    distributed: bool = False,
    rank: int = 0,
    world_size: int = 1,
) -> DataLoader:
    data_cfg = cfg.data
    dataset = NuScenesStage1Dataset(
        root=str(data_cfg.nuscenes_root),
        split=split,
        image_size=tuple(int(x) for x in data_cfg.image_size),
        sequence_length=int(data_cfg.get("sequence_length", 8)),
        original_fps=int(data_cfg.get("original_fps", 2)),
        target_fps=int(data_cfg.get("target_fps", 2)),
        window_stride=int(data_cfg.get("window_stride", 1)),
        max_frame_gap_factor=float(data_cfg.get("max_frame_gap_factor", 1.5)),
        depth_root=str(data_cfg.get("depth_root", "")) if data_cfg.get("depth_root") else None,
        occ_root=str(data_cfg.get("occupancy_root", "")) if data_cfg.get("occupancy_root") else None,
        lidarseg_root=str(data_cfg.get("lidarseg_root", "")) if data_cfg.get("lidarseg_root") else None,
        table_dir=str(data_cfg.get("table_dir", "")) if data_cfg.get("table_dir") else None,
        max_samples=max_samples,
        filter_scan_limit=cfg.training.get("filter_scan_limit"),
        semantic_classes=int(data_cfg.get("semantic_classes", 17)),
        require_depth=require.get("depth", False),
        require_semantic=require.get("semantic", False),
        require_occupancy=require.get("occupancy", False),
    )
    sampler = None
    is_train = split == "train"
    if distributed:
        sampler = DistributedSampler(
            dataset,
            num_replicas=int(world_size),
            rank=int(rank),
            shuffle=is_train,
            drop_last=is_train,
        )

    return DataLoader(
        dataset,
        batch_size=int(cfg.training.batch_size),
        shuffle=(is_train and sampler is None),
        num_workers=int(cfg.training.num_workers),
        pin_memory=True,
        drop_last=is_train,
        sampler=sampler,
        collate_fn=collate_stage1_batch,
    )


def require_stage1_sequence_images(images: torch.Tensor, caller: str = "Stage 1") -> tuple[int, int, int, int, int, int]:
    if images.ndim != 6:
        raise ValueError(f"{caller} expects images shaped [B,8,6,3,H,W], got {tuple(images.shape)}")
    b, t, v, c, h, w = images.shape
    if t != 8 or v != 6 or c != 3:
        raise ValueError(f"{caller} expects fixed [B,8,6,3,H,W], got {tuple(images.shape)}")
    return int(b), int(t), int(v), int(c), int(h), int(w)


def build_optimizer_and_scheduler(model: torch.nn.Module, cfg: DictConfig, steps_per_epoch: int):
    opt_cfg = cfg.training.optimizer
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=float(opt_cfg.lr),
        betas=tuple(float(x) for x in opt_cfg.get("betas", [0.9, 0.95])),
        weight_decay=float(opt_cfg.get("weight_decay", 0.0)),
    )
    sched_cfg = cfg.training.get("scheduler")
    if not sched_cfg:
        return optimizer, None
    warmup_steps = int(sched_cfg.get("warmup_steps", int(float(sched_cfg.get("warmup_epochs", 0)) * steps_per_epoch)))
    decay_end_steps = int(sched_cfg.get("decay_end_steps", int(float(sched_cfg.get("decay_end_epoch", cfg.training.epochs)) * steps_per_epoch)))
    base_lr = float(sched_cfg.get("base_lr", opt_cfg.lr))
    final_lr = float(sched_cfg.get("final_lr", base_lr))
    final_ratio = final_lr / base_lr if base_lr > 0 else 1.0
    decay_end_steps = max(decay_end_steps, warmup_steps + 1)

    def lr_lambda(step: int) -> float:
        if warmup_steps > 0 and step < warmup_steps:
            return float(step + 1) / float(warmup_steps)
        if step >= decay_end_steps:
            return final_ratio
        progress = (step - warmup_steps) / max(decay_end_steps - warmup_steps, 1)
        return final_ratio + (1.0 - final_ratio) * 0.5 * (1.0 + np.cos(np.pi * progress))

    return optimizer, torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lr_lambda)


@torch.no_grad()
def update_ema(ema_model: torch.nn.Module | None, model: torch.nn.Module, decay: float) -> None:
    if ema_model is None:
        return
    ema_params = dict(ema_model.named_parameters())
    for name, param in model.named_parameters():
        if name in ema_params:
            ema_params[name].mul_(decay).add_(param.data, alpha=1.0 - decay)


def create_ema(model: torch.nn.Module, enabled: bool) -> torch.nn.Module | None:
    if not enabled:
        return None
    ema = deepcopy(model).eval()
    ema.requires_grad_(False)
    return ema


def append_csv(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def save_checkpoint(
    path: Path,
    modality: str,
    step: int,
    epoch: int,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer | None,
    scheduler: Any,
    cfg: DictConfig,
    ema_model: torch.nn.Module | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {
        "modality": modality,
        "step": int(step),
        "epoch": int(epoch),
        "model": model.state_dict(),
        "ema_model": ema_model.state_dict() if ema_model is not None else None,
        "optimizer": optimizer.state_dict() if optimizer is not None else None,
        "scheduler": scheduler.state_dict() if scheduler is not None else None,
        "config": OmegaConf.to_container(cfg, resolve=True),
    }
    torch.save(state, path)


def load_decoder_state(path: str | Path, model: torch.nn.Module, prefer_ema: bool = True) -> dict[str, Any]:
    ckpt = torch.load(path, map_location="cpu")
    state = ckpt
    if isinstance(ckpt, dict):
        if prefer_ema and ckpt.get("ema_model") is not None:
            state = ckpt["ema_model"]
        elif "model" in ckpt:
            state = ckpt["model"]
    model.load_state_dict(state, strict=True)
    return ckpt if isinstance(ckpt, dict) else {"step": -1}


def calculate_psnr(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    mse = (pred.clamp(0, 1) - target.clamp(0, 1)).pow(2).flatten(1).mean(dim=1)
    return -10.0 * torch.log10(mse.clamp_min(1e-10))


def masked_charbonnier(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, eps: float = 1e-3) -> torch.Tensor:
    loss = torch.sqrt((pred - target).pow(2) + eps * eps)
    return (loss * mask).sum() / mask.sum().clamp_min(1.0)


def depth_gradient_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    px = pred[..., :, 1:] - pred[..., :, :-1]
    tx = target[..., :, 1:] - target[..., :, :-1]
    mx = mask[..., :, 1:] * mask[..., :, :-1]
    py = pred[..., 1:, :] - pred[..., :-1, :]
    ty = target[..., 1:, :] - target[..., :-1, :]
    my = mask[..., 1:, :] * mask[..., :-1, :]
    lx = ((px - tx).abs() * mx).sum() / mx.sum().clamp_min(1.0)
    ly = ((py - ty).abs() * my).sum() / my.sum().clamp_min(1.0)
    return lx + ly


def densify_occupancy(
    sparse_list: list[torch.Tensor] | list[list[torch.Tensor]],
    shape: tuple[int, int, int] = (16, 200, 200),
    ignore_index: int = 255,
    device: torch.device | None = None,
) -> torch.Tensor:
    z, h, w = shape
    targets = []
    flat_sparse = []
    for item in sparse_list:
        if torch.is_tensor(item):
            flat_sparse.append(item)
        else:
            flat_sparse.extend(item)
    for sparse in flat_sparse:
        dense = torch.full((z, h, w), int(ignore_index), dtype=torch.long)
        if sparse.numel() > 0:
            xyzl = sparse.long()
            x_idx = xyzl[:, 0].clamp(0, w - 1)
            y_idx = xyzl[:, 1].clamp(0, h - 1)
            z_idx = xyzl[:, 2].clamp(0, z - 1)
            lab = xyzl[:, 3].clamp(0, 16)
            dense[z_idx, y_idx, x_idx] = lab
        targets.append(dense)
    out = torch.stack(targets, dim=0)
    return out.to(device) if device is not None else out


def save_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
