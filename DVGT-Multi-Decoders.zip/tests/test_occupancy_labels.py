import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.models.occ_decoder import BEVOccupancyDecoder
from dvgt_multimodal.utils import densify_occupancy


def test_densify_occupancy_uses_empty_background_and_sparse_ignore():
    sparse = torch.tensor(
        [
            [0, 0, 0, 1],
            [1, 1, 0, 0],
            [2, 2, 0, 16],
            [3, 3, 0, 99],
        ],
        dtype=torch.long,
    )

    dense = densify_occupancy(
        [sparse],
        shape=(1, 4, 4),
        ignore_index=255,
        empty_index=0,
        sparse_ignore_index=0,
        num_classes=17,
    )

    assert dense.shape == (1, 1, 4, 4)
    target = dense[0, 0]
    assert target[0, 0].item() == 1
    assert target[1, 1].item() == 255
    assert target[2, 2].item() == 16
    assert target[3, 3].item() == 255
    assert target[0, 1].item() == 0


def test_bev_occupancy_decoder_outputs_configured_class_count():
    decoder = BEVOccupancyDecoder(
        in_dim=8,
        num_classes=17,
        num_views=6,
        image_size=(32, 32),
        patch_size=16,
        bev_h=5,
        bev_w=6,
        occ_z=3,
        hidden_dim=16,
        view_mixer_layers=1,
        view_mixer_heads=4,
        depth_condition=True,
    )
    tokens = torch.randn(2 * 6, 4, 8)
    depth_logits = torch.randn(2 * 6, 1, 32, 32)

    logits = decoder(tokens, batch_size=2, depth_condition=depth_logits)

    assert logits.shape == (2, 17, 3, 5, 6)
