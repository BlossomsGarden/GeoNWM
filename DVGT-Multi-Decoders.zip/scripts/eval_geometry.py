#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from PIL import Image
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from train_geometry import (
    GeometryDecoders,
    confusion_metrics,
    make_occupancy_target,
    occupancy_binary_metrics,
    occupancy_empty_index,
    occupancy_loss_weights,
    occupancy_num_classes,
    semantic_num_classes,
    update_confusion,
)
from dvgt_multimodal.models import DVGTFeatureExtractor
from dvgt_multimodal.utils import (
    build_loader,
    get_device,
    precision_context,
    require_stage1_sequence_images,
    resolve_project_path,
    save_json,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_geometry_nuscenes_704x256.yaml"))
    parser.add_argument("--modality", choices=["all", "depth", "semantic", "occupancy"], default="all")
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--ckpt-root", default=None)
    parser.add_argument("--split", choices=["train", "val"], default="val")
    parser.add_argument("--out-dir", default=None)
    parser.add_argument("--num-samples", type=int, default=128)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default="bf16")
    return parser.parse_args()


SEMANTIC_PALETTE = np.array(
    [
        [0, 0, 0],
        [220, 20, 60],
        [119, 11, 32],
        [0, 0, 142],
        [0, 0, 230],
        [106, 0, 228],
        [0, 60, 100],
        [0, 80, 100],
        [0, 0, 70],
        [0, 0, 192],
        [250, 170, 30],
        [100, 170, 30],
        [220, 220, 0],
        [175, 116, 175],
        [250, 0, 30],
        [165, 42, 42],
        [255, 77, 255],
    ],
    dtype=np.uint8,
)

OCCUPANCY_PALETTE = np.array(
    [
        [0, 0, 0],
        [220, 20, 60],
        [119, 11, 32],
        [0, 0, 142],
        [0, 0, 230],
        [106, 0, 228],
        [0, 60, 100],
        [0, 80, 100],
        [0, 0, 70],
        [0, 0, 192],
        [250, 170, 30],
        [100, 170, 30],
        [220, 220, 0],
        [175, 116, 175],
        [250, 0, 30],
        [165, 42, 42],
        [255, 77, 255],
    ],
    dtype=np.uint8,
)


def latest_checkpoint(checkpoint_dir: Path) -> Path:
    ckpts = sorted(checkpoint_dir.glob("step_*.pt"))
    if not ckpts:
        raise FileNotFoundError(f"No step checkpoints found in {checkpoint_dir}")
    return ckpts[-1]


def load_geometry_checkpoint(path: Path, model: GeometryDecoders) -> dict:
    ckpt = torch.load(path, map_location="cpu")
    if not isinstance(ckpt, dict) or ckpt.get("format") != "dvgt_geometry_decoders":
        raise ValueError(f"Expected a dvgt_geometry_decoders checkpoint, got {path}")
    state = ckpt.get("model")
    if state is None:
        raise KeyError(f"Checkpoint {path} does not contain 'model' weights")
    model.load_state_dict(state, strict=True)
    return {
        "checkpoint": str(path),
        "step": int(ckpt.get("step", -1)),
        "epoch": int(ckpt.get("epoch", -1)),
        "model_source": str(ckpt.get("model_source", "model")),
    }


def save_loss_plot(csv_path: Path, png_path: Path) -> Path | None:
    if not csv_path.is_file():
        return None
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return None

    with csv_path.open("r", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        return None

    steps = []
    for row in rows:
        try:
            steps.append(int(float(row["step"])))
        except (KeyError, TypeError, ValueError):
            return None

    keys = [
        "loss/total",
        "loss/depth",
        "loss/depth_charbonnier",
        "loss/depth_gradient",
        "loss/semantic_ce",
        "loss/occupancy_ce",
        "loss/occupancy_lovasz",
    ]
    plt.figure(figsize=(11, 5.5))
    plotted = False
    for key in keys:
        values = []
        for row in rows:
            try:
                values.append(float(row[key]))
            except (KeyError, TypeError, ValueError):
                values = []
                break
        if len(values) == len(steps):
            plt.plot(steps, values, label=key)
            plotted = True
    if not plotted:
        plt.close()
        return None

    plt.xlabel("step")
    plt.ylabel("loss")
    plt.grid(True, alpha=0.25)
    plt.legend(ncol=2, fontsize=8)
    plt.tight_layout()
    png_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(png_path, dpi=160)
    plt.close()
    return png_path


def _rgb_to_uint8(rgb: torch.Tensor) -> np.ndarray:
    return (rgb.float().clamp(0, 1).permute(0, 2, 3, 1).cpu().numpy() * 255).astype(np.uint8)


def _concat_views(images: list[np.ndarray] | np.ndarray) -> np.ndarray:
    return np.concatenate(list(images), axis=1)


def _colorize_depth(depth: np.ndarray, mask: np.ndarray, vmax: float) -> np.ndarray:
    value = np.clip(depth / max(vmax, 1e-6), 0.0, 1.0)
    rgb = np.stack(
        [
            255.0 * value,
            255.0 * (1.0 - np.abs(value - 0.5) * 2.0),
            255.0 * (1.0 - value),
        ],
        axis=-1,
    ).astype(np.uint8)
    rgb[~mask] = 0
    return rgb


def _colorize_labels(labels: np.ndarray, ignore_index: int = 255) -> np.ndarray:
    labels = labels.astype(np.int64, copy=False)
    out = np.zeros(labels.shape + (3,), dtype=np.uint8)
    valid = (labels != int(ignore_index)) & (labels >= 0)
    out[valid] = SEMANTIC_PALETTE[labels[valid] % len(SEMANTIC_PALETTE)]
    return out


def _colorize_occupancy(labels: np.ndarray, ignore_index: int = 255) -> np.ndarray:
    labels = labels.astype(np.int64, copy=False)
    out = np.zeros(labels.shape + (3,), dtype=np.uint8)
    valid = (labels != int(ignore_index)) & (labels >= 0)
    out[valid] = OCCUPANCY_PALETTE[labels[valid] % len(OCCUPANCY_PALETTE)]
    return out


def _occupancy_bev(labels_zyx: np.ndarray, ignore_index: int = 255, empty_index: int = 0) -> np.ndarray:
    valid = (labels_zyx != int(ignore_index)) & (labels_zyx != int(empty_index))
    first_z = valid.argmax(axis=0)
    has_label = valid.any(axis=0)
    yy, xx = np.indices(labels_zyx.shape[1:])
    bev = np.full(labels_zyx.shape[1:], int(empty_index), dtype=np.int64)
    bev[has_label] = labels_zyx[first_z[has_label], yy[has_label], xx[has_label]]
    return bev


def _save_image(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(image).save(path)


def _save_geometry_qualitative(samples: list[dict], out_dir: Path, ignore_index: int, occ_empty_index: int) -> Path | None:
    if not samples:
        return None
    qual_dir = out_dir / "qualitative_random"
    qual_dir.mkdir(parents=True, exist_ok=True)
    for rank, sample in enumerate(samples):
        prefix = f"random_{rank:02d}_sample_{sample['index']:04d}"
        rows = [_concat_views(sample["rgb"])]
        if "depth_gt" in sample and "depth_pred" in sample:
            valid = sample["depth_mask"]
            combined = np.concatenate([sample["depth_gt"][valid], sample["depth_pred"][valid]])
            vmax = float(np.percentile(combined, 95)) if combined.size else 80.0
            depth_gt = [_colorize_depth(d, m, vmax) for d, m in zip(sample["depth_gt"], sample["depth_mask"])]
            depth_pred = [_colorize_depth(d, m, vmax) for d, m in zip(sample["depth_pred"], sample["depth_mask"])]
            rows.extend([_concat_views(depth_gt), _concat_views(depth_pred)])
            _save_image(qual_dir / f"{prefix}_depth.png", np.concatenate([_concat_views(depth_gt), _concat_views(depth_pred)], axis=0))
        if "semantic_gt" in sample and "semantic_pred" in sample:
            semantic_gt = [_colorize_labels(x, ignore_index) for x in sample["semantic_gt"]]
            semantic_pred = [_colorize_labels(x, ignore_index) for x in sample["semantic_pred"]]
            rows.extend([_concat_views(semantic_gt), _concat_views(semantic_pred)])
            _save_image(
                qual_dir / f"{prefix}_semantic.png",
                np.concatenate([_concat_views(semantic_gt), _concat_views(semantic_pred)], axis=0),
            )
        if len(rows) > 1:
            _save_image(qual_dir / f"{prefix}_views.png", np.concatenate(rows, axis=0))
        if "occupancy_gt" in sample and "occupancy_pred" in sample:
            occ_gt = _colorize_occupancy(_occupancy_bev(sample["occupancy_gt"], ignore_index, occ_empty_index), ignore_index)
            occ_pred = _colorize_occupancy(_occupancy_bev(sample["occupancy_pred"], ignore_index, occ_empty_index), ignore_index)
            occ = np.concatenate([occ_gt, occ_pred], axis=1)
            occ = np.asarray(Image.fromarray(occ).resize((occ.shape[1] * 3, occ.shape[0] * 3), Image.Resampling.NEAREST))
            _save_image(qual_dir / f"{prefix}_occupancy_bev.png", occ)
    return qual_dir


def main():
    args = parse_args()
    cfg = OmegaConf.load(args.config)
    cfg.training.batch_size = 1
    cfg.training.num_workers = args.num_workers
    device = get_device()
    out_root = resolve_project_path(cfg.paths.results_dir, ROOT)
    ckpt_root = Path(args.ckpt_root) if args.ckpt_root else out_root / "geometry" / "checkpoints"
    ckpt_path = Path(args.ckpt) if args.ckpt else latest_checkpoint(ckpt_root)
    require = {
        "depth": args.modality in {"all", "depth"},
        "semantic": args.modality in {"all", "semantic"},
        "occupancy": args.modality in {"all", "occupancy"},
    }
    occ_uses_depth_condition = bool(cfg.decoder.occupancy.get("depth_condition", True))
    need_depth_decoder = require["depth"] or (require["occupancy"] and occ_uses_depth_condition)
    loader = build_loader(cfg, args.split, require=require, max_samples=args.num_samples)
    dvgt = DVGTFeatureExtractor(
        str(resolve_project_path(cfg.paths.dvgt_ckpt_path, ROOT)),
        list(cfg.dvgt.feature_indices),
        bool(cfg.dvgt.per_level_layernorm),
        device,
    )
    model = GeometryDecoders(cfg).to(device)
    ckpt_meta = load_geometry_checkpoint(ckpt_path, model)
    model.eval()

    sem_classes = semantic_num_classes(cfg)
    occ_classes = occupancy_num_classes(cfg)
    sem_ignore = int(cfg.loss.semantic.ignore_index)
    occ_ignore = int(cfg.loss.occupancy.ignore_index)
    occ_empty = occupancy_empty_index(cfg)
    sem_conf = torch.zeros(sem_classes, sem_classes, dtype=torch.long)
    occ_conf = torch.zeros(occ_classes, occ_classes, dtype=torch.long)
    depth_l1 = depth_absrel = depth_count = 0.0
    sem_loss_total = occ_loss_total = batch_count = 0.0
    qualitative_samples: list[dict] = []
    qualitative_seen = 0
    qualitative_rng = random.Random(0)

    for batch in tqdm(loader, desc=f"eval geometry {args.modality}"):
        images = batch["images"].to(device, non_blocking=True)
        b, t, v, _, h, w = require_stage1_sequence_images(images, "Geometry eval")
        with torch.no_grad(), precision_context(device, args.precision):
            tokens = dvgt(images).reshape(b * t * v, -1, int(cfg.decoder.hidden_size))
            if need_depth_decoder:
                depth_logits = model.depth(tokens, image_size=(h, w))
            if require["semantic"]:
                sem_logits = model.semantic(tokens, image_size=(h, w))
            if require["occupancy"]:
                depth_condition = None
                if occ_uses_depth_condition:
                    depth_condition = depth_logits.detach() if model.detach_occ_depth_condition else depth_logits
                occ_logits = model.occupancy(tokens, batch_size=b * t, depth_condition=depth_condition)

        if require["depth"]:
            pred_depth = F.softplus(depth_logits).float()
            gt_depth = batch["depth"].to(device, non_blocking=True).reshape(b * t * v, 1, h, w)
            gt_mask = batch["depth_mask"].to(device, non_blocking=True).reshape(b * t * v, 1, h, w)
            denom = gt_mask.sum().clamp_min(1.0)
            depth_l1 += ((pred_depth - gt_depth).abs() * gt_mask).sum().item()
            depth_absrel += (((pred_depth - gt_depth).abs() / gt_depth.clamp_min(1e-3)) * gt_mask).sum().item()
            depth_count += denom.item()
            depth_pred_vis = pred_depth.detach().reshape(b, t, v, h, w).cpu().numpy()
            depth_gt_vis = gt_depth.detach().reshape(b, t, v, h, w).cpu().numpy()
            depth_mask_vis = gt_mask.detach().reshape(b, t, v, h, w).bool().cpu().numpy()
        if require["semantic"]:
            sem_y = batch["semantic"].to(device, non_blocking=True).reshape(b * t * v, h, w)
            sem_loss_total += F.cross_entropy(sem_logits.float(), sem_y, ignore_index=sem_ignore).item()
            sem_conf = update_confusion(sem_conf, sem_logits.argmax(1), sem_y, sem_classes, sem_ignore)
            semantic_pred_vis = sem_logits.argmax(1).detach().reshape(b, t, v, h, w).cpu().numpy()
            semantic_gt_vis = sem_y.detach().reshape(b, t, v, h, w).cpu().numpy()
        if require["occupancy"]:
            occ_target = make_occupancy_target(batch, cfg, device)
            occ_loss_total += F.cross_entropy(
                occ_logits.float(),
                occ_target,
                weight=occupancy_loss_weights(cfg, occ_logits.device),
                ignore_index=occ_ignore,
            ).item()
            occ_conf = update_confusion(occ_conf, occ_logits.argmax(1), occ_target, occ_classes, occ_ignore)
            occ_shape = occ_target.shape[-3:]
            occupancy_pred_vis = occ_logits.argmax(1).detach().reshape(b, t, *occ_shape).cpu().numpy()
            occupancy_gt_vis = occ_target.detach().reshape(b, t, *occ_shape).cpu().numpy()
        batch_count += 1

        for bi in range(b):
            sample = {"index": qualitative_seen, "rgb": _rgb_to_uint8(images[bi, 0].detach().cpu())}
            if require["depth"]:
                sample.update(
                    {
                        "depth_gt": depth_gt_vis[bi, 0],
                        "depth_pred": depth_pred_vis[bi, 0],
                        "depth_mask": depth_mask_vis[bi, 0],
                    }
                )
            if require["semantic"]:
                sample.update(
                    {
                        "semantic_gt": semantic_gt_vis[bi, 0],
                        "semantic_pred": semantic_pred_vis[bi, 0],
                    }
                )
            if require["occupancy"]:
                sample.update(
                    {
                        "occupancy_gt": occupancy_gt_vis[bi, 0],
                        "occupancy_pred": occupancy_pred_vis[bi, 0],
                    }
                )
            qualitative_seen += 1
            if len(qualitative_samples) < 2:
                qualitative_samples.append(sample)
            else:
                slot = qualitative_rng.randrange(qualitative_seen)
                if slot < 2:
                    qualitative_samples[slot] = sample

    metrics = dict(ckpt_meta)
    if require["depth"]:
        metrics.update(
            {
                "eval/depth_l1": depth_l1 / max(depth_count, 1.0),
                "eval/depth_absrel": depth_absrel / max(depth_count, 1.0),
                "eval/depth_pixels": depth_count,
            }
        )
    if require["semantic"]:
        metrics["eval/semantic_ce"] = sem_loss_total / max(batch_count, 1.0)
        metrics.update(confusion_metrics(sem_conf, "eval/semantic"))
    if require["occupancy"]:
        metrics["eval/occupancy_ce"] = occ_loss_total / max(batch_count, 1.0)
        metrics.update(confusion_metrics(occ_conf, "eval/occupancy", exclude_classes={occ_empty}))
        metrics.update(occupancy_binary_metrics(occ_conf, "eval/occupancy", occ_empty))

    out_dir = Path(args.out_dir or (out_root / "geometry" / "eval" / f"{args.modality}_step_{metrics.get('step', -1):08d}"))
    qualitative_dir = _save_geometry_qualitative(qualitative_samples, out_dir, sem_ignore, occ_empty)
    if qualitative_dir is not None:
        metrics["qualitative_dir"] = str(qualitative_dir)
    saved_plot = save_loss_plot(out_root / "geometry" / "reports" / "metrics.csv", out_root / "geometry" / "reports" / "loss_curve.png")
    if saved_plot is not None:
        metrics["loss_curve"] = str(saved_plot)
    save_json(out_dir / "metrics.json", metrics)
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
