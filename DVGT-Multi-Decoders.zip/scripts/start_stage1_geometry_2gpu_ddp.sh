#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONDA_SH="${CONDA_SH:-}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-gld}"
LOG_DIR="${LOG_DIR:-${PROJECT_DIR}/logs/stage1_geometry_2gpu_ddp}"
NNODES="${NNODES:-1}"
NPROC_PER_NODE="${NPROC_PER_NODE:-2}"
MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
MASTER_PORT="${MASTER_PORT:-29551}"
TORCHRUN_BIN="${TORCHRUN_BIN:-torchrun}"
GPUS="${GPUS:-${STAGE1_DDP_GPUS:-6,7}}"

mkdir -p "${LOG_DIR}"

if [[ -n "${CONDA_SH}" && -f "${CONDA_SH}" ]]; then
  set +u
  source "${CONDA_SH}"
  conda activate "${CONDA_ENV_NAME}"
  set -u
fi

export CUDA_VISIBLE_DEVICES="${GPUS}"
export PYTHONPATH="${PROJECT_DIR}:${PYTHONPATH:-}"
export MASTER_ADDR="${MASTER_ADDR}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

cd "${PROJECT_DIR}"

log_file="${LOG_DIR}/train_geometry_$(date +%Y%m%d_%H%M%S).log"
exit_file="${LOG_DIR}/train_geometry.exit"
rm -f "${exit_file}"

echo "Starting Stage 1 Geometry DDP"
echo "  CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"
echo "  nproc_per_node=${NPROC_PER_NODE}, master_port=${MASTER_PORT}"
echo "  log=${log_file}"

set +e
"${TORCHRUN_BIN}" \
  --nnodes="${NNODES}" \
  --nproc_per_node="${NPROC_PER_NODE}" \
  --master_addr="${MASTER_ADDR}" \
  --master_port="${MASTER_PORT}" \
  scripts/train_geometry.py \
  --config configs/stage1_geometry_nuscenes_704x256.yaml \
  "$@" 2>&1 | tee "${log_file}"
status=${PIPESTATUS[0]}
set -e

echo "${status}" > "${exit_file}"
echo "Stage 1 Geometry DDP finished with exit code ${status}."
exit "${status}"
