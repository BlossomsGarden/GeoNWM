#!/usr/bin/env python
from __future__ import annotations

import argparse
import posixpath
import shlex
import stat
import sys
import time
from pathlib import Path

import paramiko


def sftp_mkdirs(sftp, remote_dir: str):
    parts = []
    cur = remote_dir
    while cur not in ("", "/"):
        parts.append(cur)
        cur = posixpath.dirname(cur)
    for d in reversed(parts):
        try:
            sftp.stat(d)
        except FileNotFoundError:
            sftp.mkdir(d)


def upload_tree(sftp, local_root: Path, remote_root: str):
    skip_dirs = {"__pycache__", ".pytest_cache", "results", "logs"}
    for path in local_root.rglob("*"):
        if any(part in skip_dirs for part in path.parts):
            continue
        rel = path.relative_to(local_root).as_posix()
        remote = posixpath.join(remote_root, rel)
        if path.is_dir():
            sftp_mkdirs(sftp, remote)
            continue
        sftp_mkdirs(sftp, posixpath.dirname(remote))
        sftp.put(str(path), remote)
        if path.suffix in {".py", ".sh"}:
            sftp.chmod(
                remote,
                stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR |
                stat.S_IRGRP | stat.S_IXGRP |
                stat.S_IROTH | stat.S_IXOTH,
            )


def stream_command(ssh, command: str, timeout: int | None = None) -> int:
    print(f"\n$ {command}", flush=True)
    chan = ssh.get_transport().open_session(timeout=30)
    chan.get_pty()
    chan.exec_command(command)
    start = time.time()
    while True:
        while chan.recv_ready():
            sys.stdout.buffer.write(chan.recv(4096))
            sys.stdout.buffer.flush()
        while chan.recv_stderr_ready():
            sys.stderr.buffer.write(chan.recv_stderr(4096))
            sys.stderr.buffer.flush()
        if chan.exit_status_ready():
            break
        if timeout is not None and time.time() - start > timeout:
            chan.close()
            raise TimeoutError(command)
        time.sleep(0.5)
    return chan.recv_exit_status()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="219.223.207.223")
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--user", default="wlh")
    parser.add_argument("--password", default="wlh@2025")
    parser.add_argument("--remote-code-dir", default="/data/wlh/GLD/code")
    parser.add_argument("--remote-name", default="DVGT-Multi-Decoders")
    parser.add_argument("--remote-python", default="/data/wlh/miniconda3/envs/gld/bin/python")
    parser.add_argument("--clean-remote", action="store_true", help="Delete the remote project directory before upload.")
    args = parser.parse_args()

    local_root = Path(__file__).resolve().parents[1]
    remote_root = posixpath.join(args.remote_code_dir, args.remote_name)

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(args.host, port=args.port, username=args.user, password=args.password, timeout=20, banner_timeout=20, auth_timeout=20)
    try:
        if args.clean_remote:
            expected_suffix = f"/{args.remote_name}"
            if not remote_root.endswith(expected_suffix) or args.remote_name != "DVGT-Multi-Decoders":
                raise RuntimeError(f"Refusing to clean unexpected remote path: {remote_root}")
            code = stream_command(ssh, f"rm -rf -- {shlex.quote(remote_root)}")
            if code != 0:
                raise SystemExit(code)
        sftp = ssh.open_sftp()
        try:
            upload_tree(sftp, local_root, remote_root)
        finally:
            sftp.close()
        code = stream_command(ssh, f"cd {remote_root} && find . -maxdepth 3 -type f | sort | sed -n '1,160p'")
        if code != 0:
            raise SystemExit(code)
        code = stream_command(ssh, f"cd {remote_root} && {args.remote_python} -m compileall -q .")
        if code != 0:
            raise SystemExit(code)
    finally:
        ssh.close()


if __name__ == "__main__":
    main()
