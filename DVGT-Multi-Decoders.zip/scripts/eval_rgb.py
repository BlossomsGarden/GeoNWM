#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from PIL import Image
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from train_rgb import build_decoder
from dvgt_multimodal.models import DVGTFeatureExtractor
from dvgt_multimodal.utils import (
    IMAGENET_MEAN,
    IMAGENET_STD,
    build_loader,
    calculate_psnr,
    get_device,
    precision_context,
    require_stage1_sequence_images,
    resolve_project_path,
    save_json,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_rgb_nuscenes_704x256.yaml"))
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--split", choices=["train", "val"], default="val")
    parser.add_argument("--out-dir", default=None)
    parser.add_argument("--num-samples", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default="bf16")
    return parser.parse_args()


def latest_checkpoint(checkpoint_dir: Path) -> Path:
    ckpts = sorted(checkpoint_dir.glob("step_*.pt"))
    if not ckpts:
        raise FileNotFoundError(f"No step checkpoints found in {checkpoint_dir}")
    return ckpts[-1]


def load_decoder_checkpoint(path: Path, decoder: torch.nn.Module) -> dict:
    ckpt = torch.load(path, map_location="cpu")
    state = ckpt.get("ema_model") or ckpt.get("model") or ckpt
    decoder.load_state_dict(state, strict=True)
    return ckpt if isinstance(ckpt, dict) else {"step": -1}


def calculate_ssim(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    c1 = 0.01 ** 2
    c2 = 0.03 ** 2
    mu_x = F.avg_pool2d(pred, 11, stride=1, padding=5)
    mu_y = F.avg_pool2d(target, 11, stride=1, padding=5)
    sigma_x = F.avg_pool2d(pred * pred, 11, stride=1, padding=5) - mu_x.pow(2)
    sigma_y = F.avg_pool2d(target * target, 11, stride=1, padding=5) - mu_y.pow(2)
    sigma_xy = F.avg_pool2d(pred * target, 11, stride=1, padding=5) - mu_x * mu_y
    ssim = ((2 * mu_x * mu_y + c1) * (2 * sigma_xy + c2)) / (
        (mu_x.pow(2) + mu_y.pow(2) + c1) * (sigma_x + sigma_y + c2)
    ).clamp_min(1e-8)
    return ssim.flatten(1).mean(1)


def save_grid(rows: list[np.ndarray], path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(np.concatenate(rows, axis=0)).save(path)


def save_rgb_qualitative(samples: list[dict], out_dir: Path) -> Path | None:
    if not samples:
        return None
    qual_dir = out_dir / "qualitative_random"
    qual_dir.mkdir(parents=True, exist_ok=True)
    for rank, sample in enumerate(samples):
        rows = []
        for ti in range(sample["gt"].shape[0]):
            rows.append(np.concatenate(sample["gt"][ti], axis=1))
            rows.append(np.concatenate(sample["pred"][ti], axis=1))
        save_grid(rows, qual_dir / f"random_{rank:02d}_sample_{sample['index']:04d}_rgb.png")
    return qual_dir


def main():
    args = parse_args()
    cfg = OmegaConf.load(args.config)
    cfg.training.batch_size = 1
    cfg.training.num_workers = args.num_workers
    device = get_device()
    out_root = resolve_project_path(cfg.paths.results_dir, ROOT)
    ckpt = Path(args.ckpt) if args.ckpt else latest_checkpoint(out_root / "rgb" / "checkpoints")
    out_dir = Path(args.out_dir or (ckpt.parent.parent / f"eval_rgb_step_{ckpt.stem.split('_')[-1]}"))

    loader = build_loader(cfg, args.split, require={}, max_samples=args.num_samples)
    dvgt = DVGTFeatureExtractor(
        str(resolve_project_path(cfg.paths.dvgt_ckpt_path, ROOT)),
        list(cfg.dvgt.feature_indices),
        bool(cfg.dvgt.per_level_layernorm),
        device,
    )
    decoder = build_decoder(cfg, device)
    ckpt_meta = load_decoder_checkpoint(ckpt, decoder)
    decoder.eval()
    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    sums = {"l1": 0.0, "psnr": 0.0, "ssim": 0.0}
    count = 0
    qualitative_samples: list[dict] = []
    qualitative_seen = 0
    qualitative_rng = random.Random(0)

    for i, batch in enumerate(tqdm(loader, desc="eval rgb")):
        images = batch["images"].to(device, non_blocking=True)
        b, t, v, c, h, w = require_stage1_sequence_images(images, "RGB eval")
        with torch.no_grad(), precision_context(device, args.precision):
            tokens = dvgt(images).reshape(b * t * v, -1, int(cfg.decoder.hidden_size))
            logits = decoder(tokens, input_size=(h, w), drop_cls_token=False).logits
            pred_norm = decoder.unpatchify(logits, (h, w))
            pred = (pred_norm * std + mean).float().clamp(0, 1)
        target = images.reshape(b * t * v, c, h, w).float()
        n = pred.shape[0]
        sums["l1"] += F.l1_loss(pred, target, reduction="none").mean(dim=(1, 2, 3)).sum().item()
        sums["psnr"] += calculate_psnr(pred, target).sum().item()
        sums["ssim"] += calculate_ssim(pred, target).sum().item()
        count += n

        pred_np = (pred.reshape(b, t, v, c, h, w).cpu().permute(0, 1, 2, 4, 5, 3).numpy() * 255).astype(np.uint8)
        gt_np = (images.float().cpu().permute(0, 1, 2, 4, 5, 3).numpy() * 255).astype(np.uint8)
        for bi in range(b):
            seq_dir = out_dir / f"sample_{i:04d}_seq_{bi:02d}"
            for ti in range(t):
                save_grid(
                    [np.concatenate(gt_np[bi, ti], axis=1), np.concatenate(pred_np[bi, ti], axis=1)],
                    seq_dir / f"t{ti:02d}_rgb.png",
                )
            sample = {"index": qualitative_seen, "gt": gt_np[bi].copy(), "pred": pred_np[bi].copy()}
            qualitative_seen += 1
            if len(qualitative_samples) < 2:
                qualitative_samples.append(sample)
            else:
                slot = qualitative_rng.randrange(qualitative_seen)
                if slot < 2:
                    qualitative_samples[slot] = sample

    metrics = {f"eval/{k}": v / max(count, 1) for k, v in sums.items()}
    metrics.update({"checkpoint": str(ckpt), "step": int(ckpt_meta.get("step", -1)), "images": count})
    qualitative_dir = save_rgb_qualitative(qualitative_samples, out_dir)
    if qualitative_dir is not None:
        metrics["qualitative_dir"] = str(qualitative_dir)
    save_json(out_dir / "metrics.json", metrics)
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
