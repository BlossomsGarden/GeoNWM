#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_multimodal.distributed import any_rank_true, barrier, cleanup_distributed, init_distributed, set_loader_epoch, wrap_ddp
from dvgt_multimodal.models import BEVOccupancyDecoder, DVGTFeatureExtractor, PatchTokenDecoder
from dvgt_multimodal.utils import (
    append_csv,
    build_loader,
    build_optimizer_and_scheduler,
    create_ema,
    densify_occupancy,
    depth_gradient_loss,
    lovasz_softmax_loss,
    masked_charbonnier,
    precision_context,
    require_stage1_sequence_images,
    resolve_project_path,
    save_json,
    setup_logger,
    update_ema,
)


def semantic_num_classes(cfg) -> int:
    return int(cfg.data.get("semantic_classes", 17))


def occupancy_num_classes(cfg) -> int:
    return int(cfg.data.get("occupancy_classes", cfg.occupancy.get("num_classes", semantic_num_classes(cfg))))


def occupancy_empty_index(cfg) -> int:
    return int(cfg.occupancy.get("empty_index", 0))


def occupancy_sparse_ignore_index(cfg) -> int | None:
    value = cfg.occupancy.get("sparse_ignore_index", 0)
    return None if value is None else int(value)


def occupancy_loss_weights(cfg, device: torch.device) -> torch.Tensor:
    weights = torch.ones(occupancy_num_classes(cfg), device=device)
    empty_idx = occupancy_empty_index(cfg)
    if 0 <= empty_idx < weights.numel():
        weights[empty_idx] = float(cfg.loss.occupancy.get("empty_weight", 0.1))
    return weights


def make_occupancy_target(batch: dict[str, Any], cfg, device: torch.device) -> torch.Tensor:
    return densify_occupancy(
        batch["occupancy_sparse"],
        shape=tuple(int(x) for x in cfg.occupancy.grid_shape),
        ignore_index=int(cfg.loss.occupancy.ignore_index),
        empty_index=occupancy_empty_index(cfg),
        sparse_ignore_index=occupancy_sparse_ignore_index(cfg),
        num_classes=occupancy_num_classes(cfg),
        device=device,
    )


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage1_geometry_nuscenes_704x256.yaml"))
    parser.add_argument("--results-dir", default=None)
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--max-duration-seconds", type=float, default=None)
    parser.add_argument("--val-batches", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    parser.add_argument("--ckpt-interval", type=int, default=None)
    parser.add_argument("--val-interval", type=int, default=None)
    parser.add_argument("--max-camera-images-per-gpu", type=int, default=None)
    return parser.parse_args()


class GeometryDecoders(torch.nn.Module):
    def __init__(self, cfg):
        super().__init__()
        hidden_size = int(cfg.decoder.hidden_size)
        patch_size = int(cfg.decoder.patch_size)
        self.depth = PatchTokenDecoder(
            str(resolve_project_path(cfg.decoder.image.config_path, ROOT)),
            hidden_size,
            1,
            patch_size,
            tuple(int(x) for x in cfg.decoder.image.base_image_size),
            cfg.decoder.image.get("decoder_hidden_size"),
            cfg.decoder.image.get("decoder_layers"),
            cfg.decoder.image.get("decoder_heads"),
        )
        self.semantic = PatchTokenDecoder(
            str(resolve_project_path(cfg.decoder.image.config_path, ROOT)),
            hidden_size,
            semantic_num_classes(cfg),
            patch_size,
            tuple(int(x) for x in cfg.decoder.image.base_image_size),
            cfg.decoder.image.get("decoder_hidden_size"),
            cfg.decoder.image.get("decoder_layers"),
            cfg.decoder.image.get("decoder_heads"),
        )
        self.occupancy = BEVOccupancyDecoder(
            in_dim=hidden_size,
            num_classes=occupancy_num_classes(cfg),
            num_views=6,
            image_size=(int(cfg.data.image_size[1]), int(cfg.data.image_size[0])),
            patch_size=patch_size,
            bev_h=int(cfg.occupancy.grid_shape[1]),
            bev_w=int(cfg.occupancy.grid_shape[2]),
            occ_z=int(cfg.occupancy.grid_shape[0]),
            hidden_dim=int(cfg.decoder.occupancy.hidden_dim),
            view_mixer_layers=int(cfg.decoder.occupancy.get("view_mixer_layers", 2)),
            view_mixer_heads=int(cfg.decoder.occupancy.get("view_mixer_heads", 8)),
            depth_condition=bool(cfg.decoder.occupancy.get("depth_condition", True)),
        )
        self.detach_occ_depth_condition = bool(cfg.decoder.occupancy.get("depth_condition_detach", True))

    def forward(
        self,
        tokens: torch.Tensor,
        image_size: tuple[int, int],
        batch_size_bt: int,
        run_occupancy: bool = True,
    ) -> dict[str, torch.Tensor]:
        depth_logits = self.depth(tokens, image_size=image_size)
        outputs = {
            "depth": depth_logits,
            "semantic": self.semantic(tokens, image_size=image_size),
        }
        if run_occupancy:
            depth_condition = depth_logits.detach() if self.detach_occ_depth_condition else depth_logits
            outputs["occupancy"] = self.occupancy(tokens, batch_size=batch_size_bt, depth_condition=depth_condition)
        return outputs


def save_geometry_checkpoint(path: Path, step: int, epoch: int, model: GeometryDecoders, cfg, ema_model: GeometryDecoders | None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    source_model = ema_model if ema_model is not None else model
    source_name = "ema_model" if ema_model is not None else "model"
    state = {
        "format": "dvgt_geometry_decoders",
        "step": int(step),
        "epoch": int(epoch),
        "model": source_model.state_dict(),
        "model_source": source_name,
        "config": OmegaConf.to_container(cfg, resolve=True),
    }
    torch.save(state, path)


def update_confusion(confusion: torch.Tensor, pred: torch.Tensor, target: torch.Tensor, num_classes: int, ignore_index: int) -> torch.Tensor:
    pred = pred.reshape(-1).long().cpu()
    target = target.reshape(-1).long().cpu()
    valid = (target != int(ignore_index)) & (target >= 0) & (target < int(num_classes))
    if valid.sum() == 0:
        return confusion
    indices = target[valid] * int(num_classes) + pred[valid].clamp(0, int(num_classes) - 1)
    bins = torch.bincount(indices, minlength=int(num_classes) * int(num_classes)).reshape(int(num_classes), int(num_classes))
    return confusion + bins


def confusion_metrics(confusion: torch.Tensor, prefix: str, exclude_classes: set[int] | None = None) -> dict[str, float]:
    confusion = confusion.float()
    diag = confusion.diag()
    denom = confusion.sum(1) + confusion.sum(0) - diag
    valid = denom > 0
    iou = torch.where(valid, diag / denom.clamp_min(1.0), torch.zeros_like(diag))
    miou_valid = valid.clone()
    if exclude_classes:
        for cls in exclude_classes:
            if 0 <= int(cls) < miou_valid.numel():
                miou_valid[int(cls)] = False
    total = confusion.sum().clamp_min(1.0)
    metrics = {
        f"{prefix}/acc": float(diag.sum().item() / total.item()),
        f"{prefix}/miou": float(iou[miou_valid].mean().item()) if bool(miou_valid.any()) else 0.0,
    }
    if exclude_classes:
        metrics[f"{prefix}/miou_all"] = float(iou[valid].mean().item()) if bool(valid.any()) else 0.0
    return metrics


def occupancy_binary_metrics(confusion: torch.Tensor, prefix: str, empty_index: int) -> dict[str, float]:
    confusion = confusion.float()
    num_classes = confusion.shape[0]
    occupied = torch.ones(num_classes, dtype=torch.bool, device=confusion.device)
    if 0 <= int(empty_index) < num_classes:
        occupied[int(empty_index)] = False
    empty = ~occupied
    tp = confusion[occupied][:, occupied].sum()
    fp = confusion[empty][:, occupied].sum()
    fn = confusion[occupied][:, empty].sum()
    tn = confusion[empty][:, empty].sum()
    denom = (tp + fp + fn).clamp_min(1.0)
    total = (tp + fp + fn + tn).clamp_min(1.0)
    return {
        f"{prefix}/iou": float((tp / denom).item()),
        f"{prefix}/binary_acc": float(((tp + tn) / total).item()),
    }


@torch.no_grad()
def validate(dvgt, model, loader, device, precision, max_batches: int, cfg) -> dict[str, float]:
    model.eval()
    sem_classes = semantic_num_classes(cfg)
    occ_classes = occupancy_num_classes(cfg)
    sem_ignore = int(cfg.loss.semantic.ignore_index)
    occ_ignore = int(cfg.loss.occupancy.ignore_index)
    occ_empty = occupancy_empty_index(cfg)
    sem_conf = torch.zeros(sem_classes, sem_classes, dtype=torch.long)
    occ_conf = torch.zeros(occ_classes, occ_classes, dtype=torch.long)
    depth_l1 = depth_absrel = depth_count = 0.0
    sem_loss_total = occ_loss_total = 0.0
    batch_count = 0
    for i, batch in enumerate(tqdm(loader, desc="val", leave=False)):
        if i >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        depth = batch["depth"].to(device, non_blocking=True)
        depth_mask = batch["depth_mask"].to(device, non_blocking=True)
        semantic = batch["semantic"].to(device, non_blocking=True)
        b, t, v, _, h, w = require_stage1_sequence_images(images, "Geometry validation")
        occ_target = make_occupancy_target(batch, cfg, device)
        with precision_context(device, precision):
            tokens = dvgt(images).reshape(b * t * v, -1, int(cfg.decoder.hidden_size))
            outputs = model(tokens, image_size=(h, w), batch_size_bt=b * t)
        pred_depth = F.softplus(outputs["depth"]).float()
        gt_depth = depth.reshape(b * t * v, 1, h, w)
        gt_mask = depth_mask.reshape(b * t * v, 1, h, w)
        denom = gt_mask.sum().clamp_min(1.0)
        depth_l1 += ((pred_depth - gt_depth).abs() * gt_mask).sum().item()
        depth_absrel += (((pred_depth - gt_depth).abs() / gt_depth.clamp_min(1e-3)) * gt_mask).sum().item()
        depth_count += denom.item()

        sem_y = semantic.reshape(b * t * v, h, w)
        sem_logits = outputs["semantic"]
        sem_loss_total += F.cross_entropy(sem_logits.float(), sem_y, ignore_index=sem_ignore).item()
        sem_conf = update_confusion(sem_conf, sem_logits.argmax(1), sem_y, sem_classes, sem_ignore)

        occ_logits = outputs["occupancy"]
        occ_loss_total += F.cross_entropy(
            occ_logits.float(),
            occ_target,
            weight=occupancy_loss_weights(cfg, occ_logits.device),
            ignore_index=occ_ignore,
        ).item()
        occ_conf = update_confusion(occ_conf, occ_logits.argmax(1), occ_target, occ_classes, occ_ignore)
        batch_count += 1
    model.train()
    metrics = {
        "val/depth_l1": depth_l1 / max(depth_count, 1.0),
        "val/depth_absrel": depth_absrel / max(depth_count, 1.0),
        "val/depth_pixels": depth_count,
        "val/semantic_ce": sem_loss_total / max(batch_count, 1),
        "val/occupancy_ce": occ_loss_total / max(batch_count, 1),
    }
    metrics.update(confusion_metrics(sem_conf, "val/semantic"))
    metrics.update(confusion_metrics(occ_conf, "val/occupancy", exclude_classes={occ_empty}))
    metrics.update(occupancy_binary_metrics(occ_conf, "val/occupancy", occ_empty))
    return metrics


def main():
    args = parse_args()
    dist_ctx = init_distributed()
    cfg = OmegaConf.load(args.config)
    if args.num_workers is not None:
        cfg.training.num_workers = args.num_workers
    if args.batch_size is not None:
        cfg.training.batch_size = args.batch_size
    if args.ckpt_interval is not None:
        cfg.training.ckpt_interval = args.ckpt_interval
    if args.val_interval is not None:
        cfg.training.val_interval = args.val_interval
    if args.max_camera_images_per_gpu is not None:
        cfg.data.sequence_sampling.max_camera_images_per_gpu = args.max_camera_images_per_gpu
    precision = args.precision or str(cfg.training.precision)
    torch.manual_seed(int(cfg.training.get("seed", 0)) + dist_ctx.rank)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(cfg.training.get("seed", 0)) + dist_ctx.rank)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    device = dist_ctx.device
    out_root = Path(args.results_dir) if args.results_dir else resolve_project_path(cfg.paths.results_dir, ROOT)
    exp_dir = out_root / "geometry"
    logger = setup_logger(exp_dir, enabled=dist_ctx.is_main, rank=dist_ctx.rank)
    logger.info(f"config={args.config}")
    logger.info(f"device={device} precision={precision} distributed={dist_ctx.enabled} world_size={dist_ctx.world_size}")

    train_loader = build_loader(
        cfg,
        "train",
        require={"depth": True, "semantic": True, "occupancy": True},
        max_samples=cfg.training.get("max_train_samples"),
        distributed=dist_ctx.enabled,
        rank=dist_ctx.rank,
        world_size=dist_ctx.world_size,
    )
    val_loader = (
        build_loader(
            cfg,
            "val",
            require={"depth": True, "semantic": True, "occupancy": True},
            max_samples=cfg.training.get("max_val_samples"),
        )
        if dist_ctx.is_main
        else None
    )
    steps_per_epoch = len(train_loader)
    if steps_per_epoch == 0:
        raise RuntimeError("geometry train_loader is empty")

    dvgt = DVGTFeatureExtractor(
        str(resolve_project_path(cfg.paths.dvgt_ckpt_path, ROOT)),
        list(cfg.dvgt.feature_indices),
        bool(cfg.dvgt.per_level_layernorm),
        device,
    )
    model = GeometryDecoders(cfg).to(device)
    ema_model = create_ema(model, bool(cfg.training.get("ema", True)))
    optimizer, scheduler = build_optimizer_and_scheduler(model, cfg, steps_per_epoch)
    model_train = wrap_ddp(model, dist_ctx)

    global_step = 0
    start_time = time.monotonic()
    metrics_csv = exp_dir / "reports/metrics.csv"
    ckpt_root = exp_dir / "checkpoints"
    sem_ignore = int(cfg.loss.semantic.ignore_index)
    occ_ignore = int(cfg.loss.occupancy.ignore_index)
    occ_empty = occupancy_empty_index(cfg)
    depth_weight = float(cfg.loss.depth.weight)
    sem_weight = float(cfg.loss.semantic.weight)
    occ_weight = float(cfg.loss.occupancy.weight)
    lovasz_weight = float(cfg.loss.occupancy.get("lovasz_weight", 0.0))
    occ_start_step = int(cfg.loss.occupancy.get("start_step", 0))
    occ_ce_weight = occupancy_loss_weights(cfg, device)

    logger.info(
        f"steps_per_epoch={steps_per_epoch}, max_camera_images_per_gpu={cfg.data.sequence_sampling.max_camera_images_per_gpu}, "
        f"loss_weights depth={depth_weight} semantic={sem_weight} occupancy={occ_weight}, "
        f"occ_start_step={occ_start_step}, "
        f"occ_empty_weight={float(occ_ce_weight[occ_empty].item()) if 0 <= occ_empty < occ_ce_weight.numel() else 1.0}, "
        f"lovasz={lovasz_weight}"
    )

    for epoch in range(int(cfg.training.epochs)):
        set_loader_epoch(train_loader, epoch)
        model_train.train()
        for batch in tqdm(train_loader, desc=f"geometry epoch {epoch}", disable=not dist_ctx.is_main):
            images = batch["images"].to(device, non_blocking=True)
            depth = batch["depth"].to(device, non_blocking=True)
            depth_mask = batch["depth_mask"].to(device, non_blocking=True)
            semantic = batch["semantic"].to(device, non_blocking=True)
            b, t, v, _, h, w = require_stage1_sequence_images(images, "Geometry training")
            occ_active = global_step >= occ_start_step
            occ_target = make_occupancy_target(batch, cfg, device) if occ_active else None
            gt_depth = depth.reshape(b * t * v, 1, h, w)
            gt_mask = depth_mask.reshape(b * t * v, 1, h, w)
            sem_y = semantic.reshape(b * t * v, h, w)

            optimizer.zero_grad(set_to_none=True)
            with precision_context(device, precision):
                with torch.no_grad():
                    tokens = dvgt(images)
                tokens = tokens.reshape(b * t * v, tokens.shape[-2], tokens.shape[-1])
                outputs = model_train(tokens, image_size=(h, w), batch_size_bt=b * t, run_occupancy=True)
                pred_depth = F.softplus(outputs["depth"])
                depth_charb = masked_charbonnier(pred_depth, gt_depth, gt_mask, float(cfg.loss.depth.charbonnier_eps))
                depth_grad = depth_gradient_loss(pred_depth, gt_depth, gt_mask)
                depth_loss = depth_charb + float(cfg.loss.depth.gradient_weight) * depth_grad
                sem_loss = F.cross_entropy(outputs["semantic"].float(), sem_y, ignore_index=sem_ignore)
                if occ_active:
                    occ_ce = F.cross_entropy(
                        outputs["occupancy"].float(),
                        occ_target,
                        weight=occ_ce_weight,
                        ignore_index=occ_ignore,
                    )
                    occ_lovasz = lovasz_softmax_loss(
                        outputs["occupancy"],
                        occ_target,
                        ignore_index=occ_ignore,
                        exclude_classes={occ_empty},
                    )
                else:
                    occ_ce = outputs["occupancy"].float().sum() * 0.0
                    occ_lovasz = outputs["occupancy"].float().sum() * 0.0
                occ_loss = occ_ce + lovasz_weight * occ_lovasz
                loss = depth_weight * depth_loss + sem_weight * sem_loss + occ_weight * occ_loss

            loss.backward()
            if float(cfg.training.get("clip_grad", 0.0)) > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg.training.clip_grad))
            optimizer.step()
            if scheduler is not None:
                scheduler.step()
            update_ema(ema_model, model, float(cfg.training.get("ema_decay", 0.9978)))

            if dist_ctx.is_main and global_step % int(cfg.training.log_interval) == 0:
                row = {
                    "step": global_step,
                    "epoch": epoch,
                    "local_batch": b,
                    "sampled_t": t,
                    "occupancy_active": int(occ_active),
                    "loss/total": float(loss.detach().item()),
                    "loss/depth": float(depth_loss.detach().item()),
                    "loss/depth_charbonnier": float(depth_charb.detach().item()),
                    "loss/depth_gradient": float(depth_grad.detach().item()),
                    "loss/semantic_ce": float(sem_loss.detach().item()),
                    "loss/occupancy_ce": float(occ_ce.detach().item()),
                    "loss/occupancy_lovasz": float(occ_lovasz.detach().item()),
                    "lr": optimizer.param_groups[0]["lr"],
                }
                logger.info(", ".join(f"{k}={v:.6f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
                append_csv(metrics_csv, row)

            global_step += 1
            if global_step % int(cfg.training.val_interval) == 0:
                if dist_ctx.is_main and val_loader is not None:
                    metrics = validate(
                        dvgt,
                        ema_model or model,
                        val_loader,
                        device,
                        precision,
                        args.val_batches or int(cfg.reporting.val_batches),
                        cfg,
                    )
                    metrics["step"] = global_step
                    save_json(exp_dir / f"reports/eval/step_{global_step:08d}.json", metrics)
                    logger.info("[val] " + ", ".join(f"{k}={v:.6f}" for k, v in metrics.items() if isinstance(v, float)))
                barrier(dist_ctx)
            if global_step % int(cfg.training.ckpt_interval) == 0:
                if dist_ctx.is_main:
                    save_geometry_checkpoint(ckpt_root / f"step_{global_step:08d}.pt", global_step, epoch, model, cfg, ema_model)
                barrier(dist_ctx)

            stop_for_steps = args.max_steps is not None and global_step >= args.max_steps
            stop_for_time = args.max_duration_seconds is not None and time.monotonic() - start_time >= float(args.max_duration_seconds)
            if any_rank_true(dist_ctx, stop_for_steps or stop_for_time):
                cleanup_distributed(dist_ctx)
                return

        barrier(dist_ctx)
    cleanup_distributed(dist_ctx)


if __name__ == "__main__":
    main()
