from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


class BEVOccupancyDecoder(nn.Module):
    """Efficient FlashOcc-style BEV decoder from frozen multi-view DVGT tokens."""

    def __init__(
        self,
        in_dim: int,
        num_classes: int = 17,
        num_views: int = 6,
        image_size: tuple[int, int] = (256, 704),
        patch_size: int = 16,
        bev_h: int = 200,
        bev_w: int = 200,
        occ_z: int = 16,
        hidden_dim: int = 256,
        view_mixer_layers: int = 2,
        view_mixer_heads: int = 8,
        depth_condition: bool = True,
    ):
        super().__init__()
        self.num_classes = int(num_classes)
        self.num_views = int(num_views)
        self.image_size = tuple(int(x) for x in image_size)
        self.patch_size = int(patch_size)
        self.patch_h = self.image_size[0] // self.patch_size
        self.patch_w = self.image_size[1] // self.patch_size
        self.bev_h = int(bev_h)
        self.bev_w = int(bev_w)
        self.occ_z = int(occ_z)
        self.hidden_dim = int(hidden_dim)
        self.depth_condition = bool(depth_condition)

        self.view_proj = nn.Sequential(
            nn.Conv2d(int(in_dim), hidden_dim, kernel_size=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.depth_proj = (
            nn.Sequential(
                nn.Conv2d(1, hidden_dim, kernel_size=1),
                nn.GroupNorm(16, hidden_dim),
                nn.SiLU(inplace=True),
            )
            if self.depth_condition
            else None
        )
        self.view_token = nn.Parameter(torch.zeros(1, self.num_views, hidden_dim))
        nn.init.normal_(self.view_token, std=1e-6)
        if int(view_mixer_layers) > 0:
            encoder_layer = nn.TransformerEncoderLayer(
                d_model=hidden_dim,
                nhead=int(view_mixer_heads),
                dim_feedforward=hidden_dim * 4,
                dropout=0.0,
                activation="gelu",
                batch_first=True,
                norm_first=True,
            )
            self.view_mixer = nn.TransformerEncoder(encoder_layer, num_layers=int(view_mixer_layers))
        else:
            self.view_mixer = nn.Identity()
        self.view_mod = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim * 2),
        )
        nn.init.zeros_(self.view_mod[-1].weight)
        nn.init.zeros_(self.view_mod[-1].bias)
        self.fuse = nn.Sequential(
            nn.Conv2d(hidden_dim * self.num_views, hidden_dim, kernel_size=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.bev_net = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GroupNorm(16, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.head = nn.Conv2d(hidden_dim, self.num_classes * self.occ_z, kernel_size=1)

    def forward(self, tokens: torch.Tensor, batch_size: int, depth_condition: torch.Tensor | None = None) -> torch.Tensor:
        """Return logits shaped (B,C,Z,H,W)."""
        expected = self.patch_h * self.patch_w
        if tokens.shape[1] != expected:
            raise ValueError(f"Expected {expected} patch tokens, got {tokens.shape[1]}")
        x = tokens.transpose(1, 2).reshape(batch_size, self.num_views, tokens.shape[-1], self.patch_h, self.patch_w)
        x = x.reshape(batch_size * self.num_views, tokens.shape[-1], self.patch_h, self.patch_w)
        x = self.view_proj(x)
        if self.depth_proj is not None and depth_condition is not None:
            if depth_condition.ndim != 4 or depth_condition.shape[0] != x.shape[0] or depth_condition.shape[1] != 1:
                raise ValueError(
                    "depth_condition must be shaped "
                    f"(B*num_views,1,H,W), got {tuple(depth_condition.shape)} for feature batch {x.shape[0]}"
                )
            depth = F.softplus(depth_condition.float()).clamp_max(200.0)
            depth = torch.log1p(depth)
            depth = F.interpolate(depth, size=(self.patch_h, self.patch_w), mode="area")
            x = x + self.depth_proj(depth.to(device=x.device, dtype=x.dtype))
        x = x.reshape(batch_size, self.num_views, self.hidden_dim, self.patch_h, self.patch_w)
        view_token = self.view_token.to(device=x.device, dtype=x.dtype)
        x = x + view_token.view(1, self.num_views, self.hidden_dim, 1, 1)
        view_summary = x.flatten(3).mean(-1)
        view_context = self.view_mixer(view_summary)
        scale, shift = self.view_mod(view_context).chunk(2, dim=-1)
        scale = torch.tanh(scale).view(batch_size, self.num_views, self.hidden_dim, 1, 1)
        shift = shift.view(batch_size, self.num_views, self.hidden_dim, 1, 1)
        x = x * (1.0 + scale) + shift
        x = x.reshape(batch_size * self.num_views, self.hidden_dim, self.patch_h, self.patch_w)
        x = F.interpolate(x, size=(self.bev_h, self.bev_w), mode="bilinear", align_corners=False)
        x = x.reshape(batch_size, self.num_views * x.shape[1], self.bev_h, self.bev_w)
        x = self.fuse(x)
        x = self.bev_net(x)
        x = self.head(x)
        return x.reshape(batch_size, self.num_classes, self.occ_z, self.bev_h, self.bev_w)
