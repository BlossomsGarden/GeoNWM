from __future__ import annotations

import json
import math
import pickle
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF


CAMERAS = (
    "CAM_FRONT",
    "CAM_FRONT_LEFT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_BACK_RIGHT",
)

SEMANTIC_CLASS_NAMES = (
    "other",
    "barrier",
    "bicycle",
    "bus",
    "car",
    "construction_vehicle",
    "motorcycle",
    "pedestrian",
    "traffic_cone",
    "trailer",
    "truck",
    "driveable_surface",
    "other_flat",
    "sidewalk",
    "terrain",
    "manmade",
    "vegetation",
)

OCCUPANCY_CLASS_NAMES = (
    "empty",
    "barrier",
    "bicycle",
    "bus",
    "car",
    "construction_vehicle",
    "motorcycle",
    "pedestrian",
    "traffic_cone",
    "trailer",
    "truck",
    "driveable_surface",
    "other_flat",
    "sidewalk",
    "terrain",
    "manmade",
    "vegetation",
)


@dataclass(frozen=True)
class ImageGeometry:
    original_hw: tuple[int, int]
    pre_crop_yx: tuple[int, int]
    pre_crop_hw: tuple[int, int]
    resized_hw: tuple[int, int]
    final_crop_yx: tuple[int, int]
    target_hw: tuple[int, int]

RAW_TO_17 = np.full(32, 255, dtype=np.uint8)
RAW_TO_17[[0, 1, 5, 7, 8, 10, 11, 13, 19, 20, 29, 31]] = 0
RAW_TO_17[9] = 1
RAW_TO_17[14] = 2
RAW_TO_17[15] = 3
RAW_TO_17[16] = 3
RAW_TO_17[17] = 4
RAW_TO_17[18] = 5
RAW_TO_17[21] = 6
RAW_TO_17[2] = 7
RAW_TO_17[3] = 7
RAW_TO_17[4] = 7
RAW_TO_17[6] = 7
RAW_TO_17[12] = 8
RAW_TO_17[22] = 9
RAW_TO_17[23] = 10
RAW_TO_17[24] = 11
RAW_TO_17[25] = 12
RAW_TO_17[26] = 13
RAW_TO_17[27] = 14
RAW_TO_17[28] = 15
RAW_TO_17[30] = 16


def _resolve_nuscenes_path(root: Path, path_value: str) -> Path:
    rel = path_value.replace("./data/nuscenes/", "")
    return root / rel


def _principal_point_crop(
    width: int,
    height: int,
    intrinsics: np.ndarray,
    target_width: int,
    target_height: int,
    *,
    strict: bool,
) -> tuple[int, int, int, int, np.ndarray]:
    intr = intrinsics.copy()
    cx = float(intr[0, 2])
    cy = float(intr[1, 2])
    if strict:
        crop_w = int(target_width)
        crop_h = int(target_height)
        start_x = int(math.floor(cx - crop_w / 2.0))
        start_y = int(math.floor(cy - crop_h / 2.0))
        start_x = max(0, min(start_x, width - crop_w))
        start_y = max(0, min(start_y, height - crop_h))
    else:
        half_x = min(target_width / 2.0, cx, width - cx)
        half_y = min(target_height / 2.0, cy, height - cy)
        crop_w = max(1, min(width, 2 * int(math.floor(half_x))))
        crop_h = max(1, min(height, 2 * int(math.floor(half_y))))
        start_x = int(math.floor(cx) - crop_w // 2)
        start_y = int(math.floor(cy) - crop_h // 2)
        start_x = max(0, min(start_x, width - crop_w))
        start_y = max(0, min(start_y, height - crop_h))
    intr[0, 2] -= float(start_x)
    intr[1, 2] -= float(start_y)
    return start_x, start_y, crop_w, crop_h, intr


def _resize_crop_image_and_intrinsics(
    image: Image.Image,
    intrinsics: np.ndarray,
    target_width: int,
    target_height: int,
    *,
    safe_bound: int = 4,
) -> tuple[torch.Tensor, np.ndarray, ImageGeometry]:
    """DVGT-style aspect-preserving resize followed by principal-point crop."""
    original_width, original_height = image.size
    intr = intrinsics.astype(np.float32, copy=True)

    pre_x, pre_y, pre_w, pre_h, intr = _principal_point_crop(
        original_width,
        original_height,
        intr,
        original_width,
        original_height,
        strict=False,
    )
    if pre_x or pre_y or pre_w != original_width or pre_h != original_height:
        image = image.crop((pre_x, pre_y, pre_x + pre_w, pre_y + pre_h))

    scale = max(
        (float(target_width) + float(safe_bound)) / float(pre_w),
        (float(target_height) + float(safe_bound)) / float(pre_h),
    )
    resized_width = max(target_width, int(math.floor(pre_w * scale)))
    resized_height = max(target_height, int(math.floor(pre_h * scale)))
    resample = Image.Resampling.LANCZOS if scale < 1.0 else Image.Resampling.BICUBIC
    image = image.resize((resized_width, resized_height), resample=resample)

    scale_x = resized_width / float(pre_w)
    scale_y = resized_height / float(pre_h)
    intr[0, 2] += 0.5
    intr[1, 2] += 0.5
    intr[0, 0] *= scale_x
    intr[1, 1] *= scale_y
    intr[0, 2] *= scale_x
    intr[1, 2] *= scale_y
    intr[0, 2] -= 0.5
    intr[1, 2] -= 0.5

    final_x, final_y, crop_w, crop_h, intr = _principal_point_crop(
        resized_width,
        resized_height,
        intr,
        target_width,
        target_height,
        strict=True,
    )
    if crop_w != target_width or crop_h != target_height:
        raise RuntimeError(f"Invalid final crop {(crop_w, crop_h)} for target {(target_width, target_height)}")
    image = image.crop((final_x, final_y, final_x + target_width, final_y + target_height))
    geometry = ImageGeometry(
        original_hw=(original_height, original_width),
        pre_crop_yx=(pre_y, pre_x),
        pre_crop_hw=(pre_h, pre_w),
        resized_hw=(resized_height, resized_width),
        final_crop_yx=(final_y, final_x),
        target_hw=(target_height, target_width),
    )
    return TF.to_tensor(image), intr.astype(np.float32, copy=False), geometry


def _quat_to_rotmat(q: list[float] | np.ndarray) -> np.ndarray:
    w, x, y, z = [float(v) for v in q]
    n = w * w + x * x + y * y + z * z
    if n < 1e-12:
        return np.eye(3, dtype=np.float32)
    s = 2.0 / n
    wx, wy, wz = s * w * x, s * w * y, s * w * z
    xx, xy, xz = s * x * x, s * x * y, s * x * z
    yy, yz, zz = s * y * y, s * y * z, s * z * z
    return np.array(
        [
            [1.0 - (yy + zz), xy - wz, xz + wy],
            [xy + wz, 1.0 - (xx + zz), yz - wx],
            [xz - wy, yz + wx, 1.0 - (xx + yy)],
        ],
        dtype=np.float32,
    )


def _make_transform(rotation: list[float], translation: list[float]) -> np.ndarray:
    mat = np.eye(4, dtype=np.float32)
    mat[:3, :3] = _quat_to_rotmat(rotation)
    mat[:3, 3] = np.asarray(translation, dtype=np.float32)
    return mat


def _invert_transform(mat: np.ndarray) -> np.ndarray:
    out = np.eye(4, dtype=np.float32)
    out[:3, :3] = mat[:3, :3].T
    out[:3, 3] = -out[:3, :3] @ mat[:3, 3]
    return out


def _scatter_nearest_semantic(
    uv: np.ndarray,
    depth: np.ndarray,
    labels: np.ndarray,
    height: int,
    width: int,
    ignore_index: int,
) -> np.ndarray:
    valid = (
        (depth > 0.05)
        & np.isfinite(depth)
        & (uv[:, 0] >= 0)
        & (uv[:, 0] < width)
        & (uv[:, 1] >= 0)
        & (uv[:, 1] < height)
        & (labels != ignore_index)
    )
    sem = np.full((height, width), ignore_index, dtype=np.uint8)
    if not np.any(valid):
        return sem
    xs = np.clip(np.rint(uv[valid, 0]).astype(np.int64), 0, width - 1)
    ys = np.clip(np.rint(uv[valid, 1]).astype(np.int64), 0, height - 1)
    ds = depth[valid]
    ls = labels[valid]
    order = np.argsort(ds)[::-1]
    sem[ys[order], xs[order]] = ls[order]
    return sem


class NuScenesStage1Dataset(Dataset):
    """nuScenes sequence loader for stage-1 decoder training."""

    def __init__(
        self,
        root: str,
        split: str,
        image_size: list[int] | tuple[int, int] = (704, 256),
        depth_root: str | None = None,
        occ_root: str | None = None,
        lidarseg_root: str | None = None,
        table_dir: str | None = None,
        cameras: list[str] | tuple[str, ...] = CAMERAS,
        sequence_length: int = 8,
        original_fps: int = 2,
        target_fps: int = 2,
        window_stride: int = 1,
        max_frame_gap_factor: float = 1.5,
        max_samples: int | None = None,
        filter_scan_limit: int | None = None,
        require_depth: bool = False,
        require_semantic: bool = False,
        require_occupancy: bool = False,
        semantic_classes: int = 17,
        ignore_index: int = 255,
    ):
        self.root = Path(root)
        self.split = split
        self.width, self.height = int(image_size[0]), int(image_size[1])
        self.depth_root = Path(depth_root) if depth_root else None
        self.occ_root = Path(occ_root) if occ_root else None
        self.lidarseg_root = Path(lidarseg_root) if lidarseg_root else None
        self.table_dir = Path(table_dir) if table_dir else self.root / "v1.0-trainval"
        self.cameras = tuple(cameras)
        if len(self.cameras) != 6:
            raise ValueError(f"Stage 1 decoders now require fixed V=6 nuScenes cameras, got V={len(self.cameras)}")
        self.sequence_length = int(sequence_length)
        if self.sequence_length < 1:
            raise ValueError(f"sequence_length must be positive, got {self.sequence_length}")
        self.original_fps = int(original_fps)
        self.target_fps = int(target_fps)
        if self.original_fps <= 0 or self.target_fps <= 0:
            raise ValueError(f"original_fps and target_fps must be positive, got {self.original_fps}/{self.target_fps}")
        self.fps_step = max(1, self.original_fps // self.target_fps)
        self.window_stride = max(int(window_stride), 1)
        self.max_frame_gap_factor = float(max_frame_gap_factor)
        self.require_depth = bool(require_depth)
        self.require_semantic = bool(require_semantic)
        self.require_occupancy = bool(require_occupancy)
        self.semantic_classes = int(semantic_classes)
        self.ignore_index = int(ignore_index)
        if self.semantic_classes != 17:
            raise ValueError("NuScenesStage1Dataset currently exposes the planned 17-class semantic space only.")
        if self.width % 16 != 0 or self.height % 16 != 0:
            raise ValueError(f"image_size must be divisible by DVGT patch size 16, got {(self.width, self.height)}")

        info_path = self.root / f"nuscenes_infos_{'train' if split == 'train' else 'val'}.pkl"
        with info_path.open("rb") as f:
            self.infos = pickle.load(f)["infos"]
        self.max_samples = None if max_samples is None else int(max_samples)
        self.filter_scan_limit = None if filter_scan_limit is None else int(filter_scan_limit)

        self._sample_data_by_filename: dict[str, dict[str, Any]] | None = None
        self._lidarseg_by_sample_data_token: dict[str, str] | None = None
        if self.require_semantic:
            if self.lidarseg_root is None:
                raise FileNotFoundError("lidarseg_root is not configured")
            self._load_lidarseg_tables()

        self._filter_missing_targets()

    def _load_lidarseg_tables(self) -> None:
        with (self.table_dir / "sample_data.json").open("r", encoding="utf-8") as f:
            sample_data = json.load(f)
        self._sample_data_by_filename = {str(row["filename"]): row for row in sample_data}
        with (self.table_dir / "lidarseg.json").open("r", encoding="utf-8") as f:
            lidarseg = json.load(f)
        self._lidarseg_by_sample_data_token = {
            str(row["sample_data_token"]): str(row["filename"]) for row in lidarseg
        }

    def _filter_missing_targets(self) -> None:
        kept_frames = []
        scanned = 0
        for info in self.infos:
            scanned += 1
            try:
                self._target_paths(info)
            except FileNotFoundError:
                if self.filter_scan_limit is not None and scanned >= self.filter_scan_limit:
                    break
                continue
            kept_frames.append(info)
            if self.filter_scan_limit is not None and scanned >= self.filter_scan_limit:
                break
        if not kept_frames:
            raise RuntimeError(f"No usable nuScenes samples found for split={self.split}")
        self.frame_infos = kept_frames
        self.sequences = self._build_sequences(kept_frames)
        if self.max_samples is not None:
            self.sequences = self.sequences[: self.max_samples]
        if not self.sequences:
            raise RuntimeError(
                f"No usable T={self.sequence_length} nuScenes sequences found for split={self.split}; "
                f"usable_frames={len(kept_frames)}"
            )
        self.infos = self.sequences

    def _sequence_key(self, info: dict[str, Any]) -> str:
        if info.get("scene_token"):
            return str(info["scene_token"])
        lidar_name = Path(str(info["lidar_path"])).name
        if "__" in lidar_name:
            return lidar_name.split("__", 1)[0]
        raise KeyError(f"nuScenes info has no scene_token and lidar filename cannot provide a sequence key: {lidar_name}")

    def _timestamp(self, info: dict[str, Any]) -> int:
        if info.get("timestamp") is not None:
            return int(info["timestamp"])
        lidar_name = Path(str(info["lidar_path"])).name
        parts = lidar_name.split("__")
        if len(parts) >= 3:
            return int(parts[2].split(".", 1)[0])
        raise KeyError(f"nuScenes info has no timestamp and lidar filename cannot provide one: {lidar_name}")

    def _is_continuous_target_fps_window(self, window: list[dict[str, Any]]) -> bool:
        times = [self._timestamp(x) for x in window]
        if not all(a < b for a, b in zip(times, times[1:])):
            return False
        expected_gap_us = 1_000_000.0 / float(self.target_fps)
        max_gap_us = expected_gap_us * self.max_frame_gap_factor
        return all((b - a) <= max_gap_us for a, b in zip(times, times[1:]))

    def _build_sequences(self, infos: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
        groups: dict[str, list[dict[str, Any]]] = {}
        for info in infos:
            groups.setdefault(self._sequence_key(info), []).append(info)

        sequences: list[list[dict[str, Any]]] = []
        for group in groups.values():
            ordered = sorted(group, key=self._timestamp)
            sampled = ordered[:: self.fps_step]
            if len(sampled) < self.sequence_length:
                continue
            for start in range(0, len(sampled) - self.sequence_length + 1, self.window_stride):
                window = sampled[start : start + self.sequence_length]
                if self._is_continuous_target_fps_window(window):
                    sequences.append(window)
        sequences.sort(key=lambda seq: (self._sequence_key(seq[0]), self._timestamp(seq[0])))
        return sequences

    def _target_paths(self, info: dict[str, Any]) -> dict[str, Any]:
        paths: dict[str, Any] = {"images": {}, "depth": {}}
        for cam in self.cameras:
            image_path = _resolve_nuscenes_path(self.root, info["cams"][cam]["data_path"])
            if not image_path.exists():
                raise FileNotFoundError(image_path)
            paths["images"][cam] = image_path
            if self.require_depth:
                if self.depth_root is None:
                    raise FileNotFoundError("depth_root is not configured")
                depth_path = self.depth_root / cam / f"{image_path.stem}.npz"
                if not depth_path.exists():
                    raise FileNotFoundError(depth_path)
                paths["depth"][cam] = depth_path

        lidar_rel = info["lidar_path"].replace("./data/nuscenes/", "")
        lidar_path = self.root / lidar_rel
        if self.require_semantic:
            if self._sample_data_by_filename is None or self._lidarseg_by_sample_data_token is None:
                raise RuntimeError("lidarseg tables were not loaded")
            row = self._sample_data_by_filename.get(lidar_rel)
            if row is None:
                raise FileNotFoundError(lidar_rel)
            seg_rel = self._lidarseg_by_sample_data_token.get(row["token"])
            if seg_rel is None:
                raise FileNotFoundError(row["token"])
            seg_path = self._resolve_lidarseg_path(seg_rel)
            if not lidar_path.exists() or not seg_path.exists():
                raise FileNotFoundError(f"{lidar_path} / {seg_path}")
            paths["lidar"] = lidar_path
            paths["lidarseg"] = seg_path

        if self.require_occupancy:
            if self.occ_root is None:
                raise FileNotFoundError("occ_root is not configured")
            occ_path = self.occ_root / "samples" / f"{Path(info['lidar_path']).name}.npy"
            if not occ_path.exists():
                raise FileNotFoundError(occ_path)
            paths["occupancy"] = occ_path
        return paths

    def _resolve_lidarseg_path(self, seg_rel: str) -> Path:
        rel = seg_rel.replace("./data/nuscenes/", "")
        if rel.startswith("lidarseg/"):
            rel = rel[len("lidarseg/") :]
        if self.lidarseg_root is None:
            raise FileNotFoundError("lidarseg_root is not configured")
        return self.lidarseg_root / rel

    def __len__(self) -> int:
        return len(self.sequences)

    def _load_image(self, path: Path, cam_info: dict[str, Any]) -> tuple[torch.Tensor, np.ndarray, ImageGeometry]:
        image = Image.open(path).convert("RGB")
        intr = np.array(cam_info["camera_intrinsics"], dtype=np.float32)
        return _resize_crop_image_and_intrinsics(image, intr, self.width, self.height)

    def _apply_depth_geometry(self, value: torch.Tensor, geometry: ImageGeometry) -> torch.Tensor:
        if tuple(value.shape[-2:]) == geometry.target_hw:
            return value

        if tuple(value.shape[-2:]) == geometry.original_hw:
            pre_y, pre_x = geometry.pre_crop_yx
            pre_h, pre_w = geometry.pre_crop_hw
            value = value[:, pre_y : pre_y + pre_h, pre_x : pre_x + pre_w]
        elif tuple(value.shape[-2:]) != geometry.pre_crop_hw:
            return self._sample_full_image_depth_to_target(value, geometry)

        if tuple(value.shape[-2:]) != geometry.resized_hw:
            value = F.interpolate(value[None], size=geometry.resized_hw, mode="nearest")[0]
        final_y, final_x = geometry.final_crop_yx
        target_h, target_w = geometry.target_hw
        return value[:, final_y : final_y + target_h, final_x : final_x + target_w]

    def _sample_full_image_depth_to_target(self, value: torch.Tensor, geometry: ImageGeometry) -> torch.Tensor:
        """Align dense depth saved as a full-image resize to the current DVGT crop."""
        depth_h, depth_w = value.shape[-2:]
        original_h, original_w = geometry.original_hw
        pre_y, pre_x = geometry.pre_crop_yx
        pre_h, pre_w = geometry.pre_crop_hw
        resized_h, resized_w = geometry.resized_hw
        final_y, final_x = geometry.final_crop_yx
        target_h, target_w = geometry.target_hw

        device = value.device
        dtype = value.dtype
        yy, xx = torch.meshgrid(
            torch.arange(target_h, device=device, dtype=dtype),
            torch.arange(target_w, device=device, dtype=dtype),
            indexing="ij",
        )
        scale_x = float(resized_w) / float(pre_w)
        scale_y = float(resized_h) / float(pre_h)
        original_x = ((xx + float(final_x) + 0.5) / scale_x) - 0.5 + float(pre_x)
        original_y = ((yy + float(final_y) + 0.5) / scale_y) - 0.5 + float(pre_y)
        depth_x = ((original_x + 0.5) * float(depth_w) / float(original_w)) - 0.5
        depth_y = ((original_y + 0.5) * float(depth_h) / float(original_h)) - 0.5
        grid_x = ((depth_x + 0.5) / float(depth_w)) * 2.0 - 1.0
        grid_y = ((depth_y + 0.5) / float(depth_h)) * 2.0 - 1.0
        grid = torch.stack((grid_x, grid_y), dim=-1).unsqueeze(0)
        return F.grid_sample(value.unsqueeze(0), grid, mode="nearest", padding_mode="zeros", align_corners=False)[0]

    def _load_depth(self, path: Path, geometry: ImageGeometry) -> tuple[torch.Tensor, torch.Tensor]:
        data = np.load(path)
        depth = torch.from_numpy(data["depth"].astype(np.float32))[None]
        mask = torch.from_numpy(data["mask"].astype(np.float32))[None]
        if depth.shape[-2:] != (self.height, self.width):
            depth = self._apply_depth_geometry(depth, geometry)
            mask = self._apply_depth_geometry(mask, geometry)
        mask = (mask > 0.5) & torch.isfinite(depth) & (depth > 0)
        return depth, mask.float()

    def _load_semantic_views(
        self,
        info: dict[str, Any],
        paths: dict[str, Any],
        intrinsics_by_cam: dict[str, np.ndarray],
    ) -> torch.Tensor:
        points = np.fromfile(paths["lidar"], dtype=np.float32).reshape(-1, 5)[:, :3]
        raw_labels = np.fromfile(paths["lidarseg"], dtype=np.uint8)
        if points.shape[0] != raw_labels.shape[0]:
            raise ValueError(f"LiDAR points and lidarseg labels mismatch for {paths['lidar']}")
        labels = RAW_TO_17[np.minimum(raw_labels, 31)]

        sem_views = []
        pts_h = np.concatenate([points.astype(np.float32), np.ones((points.shape[0], 1), dtype=np.float32)], axis=1)
        for cam in self.cameras:
            cam_info = info["cams"][cam]
            sensor_to_lidar = np.eye(4, dtype=np.float32)
            sensor_to_lidar[:3, :3] = np.asarray(cam_info["sensor2lidar_rotation"], dtype=np.float32)
            sensor_to_lidar[:3, 3] = np.asarray(cam_info["sensor2lidar_translation"], dtype=np.float32)
            lidar_to_sensor = _invert_transform(sensor_to_lidar)
            cam_points = (lidar_to_sensor @ pts_h.T).T[:, :3]
            intr = intrinsics_by_cam[cam]
            proj = cam_points @ intr.T
            depth = cam_points[:, 2]
            uv = proj[:, :2] / np.maximum(proj[:, 2:3], 1e-6)
            sem = _scatter_nearest_semantic(uv, depth, labels, self.height, self.width, self.ignore_index)
            sem_views.append(torch.from_numpy(sem.astype(np.int64)))
        return torch.stack(sem_views, dim=0)

    def _load_frame(self, info: dict[str, Any]) -> dict[str, Any]:
        paths = self._target_paths(info)
        images, intrinsics, sensor_to_lidar = [], [], []
        intrinsics_by_cam: dict[str, np.ndarray] = {}
        image_geometries: list[ImageGeometry] = []
        labels = []
        for cam in self.cameras:
            cam_info = info["cams"][cam]
            image, intr, geometry = self._load_image(paths["images"][cam], cam_info)
            images.append(image)
            intrinsics_by_cam[cam] = intr
            image_geometries.append(geometry)
            intrinsics.append(torch.from_numpy(intr))
            s2l = np.eye(4, dtype=np.float32)
            s2l[:3, :3] = np.asarray(cam_info["sensor2lidar_rotation"], dtype=np.float32)
            s2l[:3, 3] = np.asarray(cam_info["sensor2lidar_translation"], dtype=np.float32)
            sensor_to_lidar.append(torch.from_numpy(s2l))
            labels.append(str(paths["images"][cam].relative_to(self.root)))

        sample: dict[str, Any] = {
            "sample_token": info["token"],
            "lidar_path": str(_resolve_nuscenes_path(self.root, info["lidar_path"])),
            "images": torch.stack(images, dim=0),
            "intrinsics": torch.stack(intrinsics, dim=0),
            "sensor_to_lidar": torch.stack(sensor_to_lidar, dim=0),
            "labels": labels,
            "image_geometry": image_geometries,
        }
        if self.require_depth:
            depths, depth_masks = [], []
            for cam, geometry in zip(self.cameras, image_geometries):
                depth, mask = self._load_depth(paths["depth"][cam], geometry)
                depths.append(depth)
                depth_masks.append(mask)
            sample["depth"] = torch.stack(depths, dim=0)
            sample["depth_mask"] = torch.stack(depth_masks, dim=0)
        if self.require_semantic:
            sample["semantic"] = self._load_semantic_views(info, paths, intrinsics_by_cam)
        if self.require_occupancy:
            occ = np.load(paths["occupancy"]).astype(np.int64)
            sample["occupancy_sparse"] = torch.from_numpy(occ)
            sample["occupancy_path"] = str(paths["occupancy"])
        return sample

    def __getitem__(self, idx: int | tuple[int, int]) -> dict[str, Any]:
        sampled_length = None
        if isinstance(idx, tuple):
            idx, sampled_length = int(idx[0]), int(idx[1])
        sequence = self.sequences[idx]
        if sampled_length is not None:
            if sampled_length < 1:
                raise ValueError(f"sampled sequence length must be positive, got {sampled_length}")
            if sampled_length > len(sequence):
                raise ValueError(f"sampled sequence length {sampled_length} exceeds window length {len(sequence)}")
            if sampled_length < len(sequence):
                max_start = len(sequence) - sampled_length
                start = random.randint(0, max_start) if self.split == "train" else 0
                sequence = sequence[start : start + sampled_length]
        frames = [self._load_frame(info) for info in sequence]
        sample: dict[str, Any] = {
            "sample_token": [frame["sample_token"] for frame in frames],
            "lidar_path": [frame["lidar_path"] for frame in frames],
            "images": torch.stack([frame["images"] for frame in frames], dim=0),
            "intrinsics": torch.stack([frame["intrinsics"] for frame in frames], dim=0),
            "sensor_to_lidar": torch.stack([frame["sensor_to_lidar"] for frame in frames], dim=0),
            "labels": [frame["labels"] for frame in frames],
        }
        if self.require_depth:
            sample["depth"] = torch.stack([frame["depth"] for frame in frames], dim=0)
            sample["depth_mask"] = torch.stack([frame["depth_mask"] for frame in frames], dim=0)
        if self.require_semantic:
            sample["semantic"] = torch.stack([frame["semantic"] for frame in frames], dim=0)
        if self.require_occupancy:
            sample["occupancy_sparse"] = [frame["occupancy_sparse"] for frame in frames]
            sample["occupancy_path"] = [frame["occupancy_path"] for frame in frames]
        return sample


def collate_stage1_batch(samples: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    tensor_keys = {
        "images",
        "intrinsics",
        "sensor_to_lidar",
        "depth",
        "depth_mask",
        "semantic",
    }
    for key in samples[0].keys():
        if key in tensor_keys and torch.is_tensor(samples[0][key]):
            out[key] = torch.stack([s[key] for s in samples], dim=0)
        elif key == "occupancy_sparse":
            out[key] = [s[key] for s in samples]
        else:
            out[key] = [s[key] for s in samples]
    return out
