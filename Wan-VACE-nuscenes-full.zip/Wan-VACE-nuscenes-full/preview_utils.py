from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Sequence

from PIL import Image, ImageDraw

from diffsynth.utils.data import save_video


def make_comparison_frames(
    target: Sequence[Image.Image],
    control: Sequence[Image.Image],
    mask: Sequence[Image.Image],
    generated: Sequence[Image.Image] | None = None,
) -> list[Image.Image]:
    columns = [target, control, mask]
    labels = ["target", "vace input", "mask (white = generate)"]
    if generated is not None:
        columns.append(generated)
        labels.append("generated")
    count = len(target)
    if any(len(column) != count for column in columns):
        raise ValueError("All comparison videos must have the same frame count")
    width, height = target[0].size
    header = 28
    frames = []
    for frame_index in range(count):
        canvas = Image.new("RGB", (width * len(columns), height + header), (245, 245, 245))
        draw = ImageDraw.Draw(canvas)
        for column_index, (column, label) in enumerate(zip(columns, labels)):
            x = column_index * width
            canvas.paste(column[frame_index].convert("RGB"), (x, header))
            draw.text((x + 8, 8), label, fill=(12, 12, 12))
        frames.append(canvas)
    return frames


def save_pil_video(frames: Iterable[Image.Image], path: Path, fps: float = 2.0) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    save_video([frame.convert("RGB") for frame in frames], str(path), fps=fps, quality=5)


def save_dry_run_item(item: dict, output_dir: Path, fps: float = 2.0) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    save_pil_video(item["video"], output_dir / "target.mp4", fps)
    save_pil_video(item["vace_video"], output_dir / "vace_input.mp4", fps)
    save_pil_video(item["vace_video_mask"], output_dir / "mask.mp4", fps)
    comparison = make_comparison_frames(item["video"], item["vace_video"], item["vace_video_mask"])
    save_pil_video(comparison, output_dir / "comparison.mp4", fps)
    item["video"][0].save(output_dir / "reference.png")
    manifest = {
        "scene_id": item["scene_id"],
        "camera": item["camera"],
        "start_frame_id": item["start_frame_id"],
        "frame_ids": item["frame_ids"],
        "offset": item["offset"],
        "offset_shifts_left_m": item["offset_shifts_left_m"],
        "mask_ratios": item["mask_ratios"],
    }
    with (output_dir / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
