from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"
os.environ["DIFFSYNTH_SKIP_DOWNLOAD"] = "true"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import accelerate
import torch
from accelerate import Accelerator
from safetensors.torch import save_file
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from diffsynth.core import ModelConfig, load_state_dict
from diffsynth.diffusion import DiffusionTrainingModule, FlowMatchSFTLoss
from diffsynth.pipelines.wan_video import WanVideoPipeline
from nuscenes_vace_dataset import NuScenesVaceDataset, describe_item
from preview_utils import save_dry_run_item


def require_file(path: Path, description: str) -> Path:
    if not path.is_file():
        raise FileNotFoundError(f"Missing {description}: {path}")
    return path


def validate_model_directory(model_path: str | Path) -> dict[str, str | Path | list[str]]:
    root = Path(model_path).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"--model-path is not a directory: {root}")
    diffusion_files = sorted(root.glob("diffusion_pytorch_model*.safetensors"))
    if not diffusion_files:
        raise FileNotFoundError(f"No diffusion_pytorch_model*.safetensors under {root}")
    tokenizer = root / "google" / "umt5-xxl"
    require_file(tokenizer / "tokenizer_config.json", "tokenizer config")
    require_file(tokenizer / "spiece.model", "tokenizer sentencepiece model")
    diffusion: str | list[str]
    diffusion = str(diffusion_files[0]) if len(diffusion_files) == 1 else [str(path) for path in diffusion_files]
    return {
        "root": root,
        "diffusion": diffusion,
        "text_encoder": require_file(root / "models_t5_umt5-xxl-enc-bf16.pth", "T5 encoder"),
        "vae": require_file(root / "Wan2.1_VAE.pth", "Wan VAE"),
        "tokenizer": tokenizer,
    }


class WanVaceTrainingModule(DiffusionTrainingModule):
    def __init__(self, model_path: str, use_gradient_checkpointing: bool, resume_from_checkpoint: str | None):
        super().__init__()
        paths = validate_model_directory(model_path)
        model_configs = [
            ModelConfig(path=paths["diffusion"]),
            ModelConfig(path=str(paths["text_encoder"])),
            ModelConfig(path=str(paths["vae"])),
        ]
        self.pipe = WanVideoPipeline.from_pretrained(
            torch_dtype=torch.bfloat16,
            device="cpu",
            model_configs=model_configs,
            tokenizer_config=ModelConfig(path=str(paths["tokenizer"])),
            redirect_common_files=False,
        )
        if self.pipe.dit is None or self.pipe.vace is None or self.pipe.text_encoder is None or self.pipe.vae is None:
            raise RuntimeError("Local model directory did not load DiT, VACE, T5, and VAE")
        self.pipe.scheduler.set_timesteps(1000, training=True)
        self.pipe.freeze_except(["vace"])
        self.use_gradient_checkpointing = bool(use_gradient_checkpointing)
        if resume_from_checkpoint:
            state_dict = load_state_dict(resume_from_checkpoint)
            if state_dict and all(key.startswith("pipe.vace.") for key in state_dict):
                state_dict = {key[len("pipe.vace."):]: value for key, value in state_dict.items()}
            missing, unexpected = self.pipe.vace.load_state_dict(state_dict, strict=False)
            if unexpected:
                raise ValueError(f"Unexpected VACE checkpoint keys: {unexpected[:20]}")
            if missing:
                raise ValueError(f"Missing VACE checkpoint keys: {missing[:20]}")

    def get_pipeline_inputs(self, data: dict):
        shared = {
            "input_video": data["video"],
            "vace_video": data["vace_video"],
            "vace_video_mask": data["vace_video_mask"],
            "vace_reference_image": data["vace_reference_image"][0],
            "height": data["video"][0].height,
            "width": data["video"][0].width,
            "num_frames": len(data["video"]),
            "cfg_scale": 1,
            "tiled": False,
            "rand_device": self.pipe.device,
            "use_gradient_checkpointing": self.use_gradient_checkpointing,
            "use_gradient_checkpointing_offload": False,
            "cfg_merge": False,
            "vace_scale": 1.0,
            "max_timestep_boundary": 1.0,
            "min_timestep_boundary": 0.0,
        }
        return shared, {"prompt": data["prompt"]}, {}

    def forward(self, data: dict):
        inputs = self.get_pipeline_inputs(data)
        inputs = self.transfer_data_to_device(inputs, self.pipe.device, self.pipe.torch_dtype)
        for unit in self.pipe.units:
            inputs = self.pipe.unit_runner(unit, self.pipe, *inputs)
        return FlowMatchSFTLoss(self.pipe, **inputs[0], **inputs[1])


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Full-parameter VACE training on online nuScenes offset pairs")
    parser.add_argument("--model-path", type=Path)
    parser.add_argument("--nuscenes-root", type=Path, required=True)
    parser.add_argument("--nuscenes-version-dir", type=Path)
    parser.add_argument("--depth-root", type=Path, required=True)
    parser.add_argument("--train-csv", type=Path, required=True)
    parser.add_argument("--val-csv", type=Path)
    parser.add_argument("--output-path", type=Path, default=Path("outputs/wan-vace-nuscenes-full"))
    parser.add_argument("--height", type=int, default=480, choices=[480])
    parser.add_argument("--width", type=int, default=832, choices=[832])
    parser.add_argument("--num-frames", type=int, default=17, choices=[17])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--depth-max", type=float, default=120.0)
    parser.add_argument("--invalid-depth-fill", type=float, default=100.0)
    parser.add_argument("--dataset-num-workers", type=int, default=4)
    parser.add_argument("--prefetch-factor", type=int, default=2)
    parser.add_argument("--learning-rate", type=float, default=5e-5)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--num-epochs", type=int, default=2)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=1)
    parser.add_argument("--save-steps", type=int, default=1000)
    parser.add_argument("--resume-from-checkpoint", type=Path)
    parser.add_argument("--use-gradient-checkpointing", action="store_true")
    parser.add_argument("--max-train-items", type=int)
    parser.add_argument("--max-train-steps", type=int)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--dry-run-items", type=int, default=1)
    return parser


def save_vace_checkpoint(accelerator: Accelerator, model: WanVaceTrainingModule, path: Path) -> None:
    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        unwrapped = accelerator.unwrap_model(model)
        state_dict = {key: value.detach().cpu().contiguous() for key, value in unwrapped.pipe.vace.state_dict().items()}
        path.parent.mkdir(parents=True, exist_ok=True)
        save_file(state_dict, str(path))
    accelerator.wait_for_everyone()


def build_dataset(args: argparse.Namespace, rank: int = 0) -> NuScenesVaceDataset:
    return NuScenesVaceDataset(
        samples_csv=args.train_csv,
        nuscenes_root=args.nuscenes_root,
        depth_root=args.depth_root,
        nuscenes_version_dir=args.nuscenes_version_dir,
        seed=args.seed,
        rank=rank,
        depth_max=args.depth_max,
        invalid_depth_fill=args.invalid_depth_fill,
        max_items=args.max_train_items,
        expected_height=args.height,
        expected_width=args.width,
    )


def run_dry_run(args: argparse.Namespace) -> None:
    dataset = build_dataset(args)
    output_dir = args.output_path / "dry_run"
    summaries = []
    for index in range(min(args.dry_run_items, len(dataset))):
        item = dataset[index]
        summaries.append(describe_item(item))
        save_dry_run_item(item, output_dir / f"sample_{index:04d}")
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summaries, handle, indent=2)
    print(json.dumps(summaries, indent=2))


def main() -> None:
    args = build_parser().parse_args()
    if args.dry_run:
        run_dry_run(args)
        return
    if args.model_path is None:
        raise ValueError("--model-path is required unless --dry-run is used")
    if args.gradient_accumulation_steps != 1:
        raise ValueError("This 8xH200 configuration requires --gradient-accumulation-steps 1")

    torch.manual_seed(args.seed)
    torch.set_float32_matmul_precision("high")
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    accelerator = accelerate.Accelerator(
        mixed_precision="bf16",
        gradient_accumulation_steps=1,
        kwargs_handlers=[accelerate.DistributedDataParallelKwargs(find_unused_parameters=False)],
    )
    dataset = build_dataset(args, rank=accelerator.process_index)
    loader_kwargs = {
        "dataset": dataset,
        "batch_size": 1,
        "shuffle": True,
        "num_workers": args.dataset_num_workers,
        "collate_fn": lambda batch: batch[0],
        "pin_memory": True,
        "persistent_workers": args.dataset_num_workers > 0,
    }
    if args.dataset_num_workers > 0:
        loader_kwargs["prefetch_factor"] = args.prefetch_factor
    dataloader = DataLoader(**loader_kwargs)

    model = WanVaceTrainingModule(
        model_path=str(args.model_path),
        use_gradient_checkpointing=args.use_gradient_checkpointing,
        resume_from_checkpoint=str(args.resume_from_checkpoint) if args.resume_from_checkpoint else None,
    )
    optimizer = torch.optim.AdamW(model.trainable_modules(), lr=args.learning_rate, weight_decay=args.weight_decay)
    # `ConstantLR` defaults to a warmup factor of 1/3; factor=1 keeps the
    # requested learning rate constant from the first optimizer step.
    scheduler = torch.optim.lr_scheduler.ConstantLR(optimizer, factor=1.0, total_iters=1)
    model.to(accelerator.device)
    model, optimizer, dataloader, scheduler = accelerator.prepare(model, optimizer, dataloader, scheduler)

    args.output_path.mkdir(parents=True, exist_ok=True)
    if accelerator.is_main_process:
        with (args.output_path / "training_args.json").open("w", encoding="utf-8") as handle:
            json.dump(vars(args), handle, indent=2, default=str)

    global_step = 0
    stop = False
    for epoch in range(args.num_epochs):
        dataset.set_epoch(epoch)
        if hasattr(dataloader, "set_epoch"):
            dataloader.set_epoch(epoch)
        progress = tqdm(dataloader, disable=not accelerator.is_local_main_process, desc=f"epoch {epoch}")
        for data in progress:
            with accelerator.accumulate(model):
                optimizer.zero_grad(set_to_none=True)
                loss = model(data)
                accelerator.backward(loss)
                optimizer.step()
                scheduler.step()
            global_step += 1
            progress.set_postfix(loss=f"{loss.detach().float().item():.5f}", step=global_step)
            if global_step % args.save_steps == 0:
                save_vace_checkpoint(accelerator, model, args.output_path / f"step-{global_step}.safetensors")
            if args.max_train_steps is not None and global_step >= args.max_train_steps:
                stop = True
                break
        save_vace_checkpoint(accelerator, model, args.output_path / f"epoch-{epoch}.safetensors")
        if stop:
            break
    if global_step % args.save_steps != 0:
        save_vace_checkpoint(accelerator, model, args.output_path / f"step-{global_step}.safetensors")
    accelerator.wait_for_everyone()


if __name__ == "__main__":
    main()
