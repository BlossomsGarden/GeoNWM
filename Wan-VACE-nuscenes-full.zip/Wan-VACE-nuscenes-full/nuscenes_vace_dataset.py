from __future__ import annotations

import csv
import hashlib
from collections import defaultdict
from dataclasses import dataclass
from multiprocessing import Value
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, get_worker_info

from nuscenes_offset import (
    find_sample_from_csv_row,
    generate_offset_supervision,
    load_metadata_indexes,
    load_rgb_depth,
    normalize_camera_name,
    resolve_version_dir,
    transform_from_translation_rotation,
)


CAMERA_ORDER: Tuple[str, ...] = (
    "CAM_FRONT_LEFT",
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_LEFT",
    "CAM_BACK",
    "CAM_BACK_RIGHT",
)
PROMPT = "A realistic driving scene captured by a vehicle-mounted camera."
CHUNK_LENGTH = 17
CHUNK_STRIDE = 16


@dataclass(frozen=True)
class OffsetSpec:
    name: str
    label: str
    shifts_left_m: Tuple[float, ...]


@dataclass(frozen=True)
class CameraChunk:
    scene_id: int
    camera: str
    start_frame_id: int
    rows: Tuple[dict, ...]


def format_meter(value: float) -> str:
    return f"{abs(float(value)):g}".replace(".", "p") + "m"


def progressive_schedule(start_m: float, end_m: float, sign: float) -> Tuple[float, ...]:
    shifted = np.linspace(start_m, end_m, CHUNK_LENGTH - 1)
    return (0.0, *tuple(float(sign * value) for value in shifted))


def fixed_schedule(value_m: float, sign: float) -> Tuple[float, ...]:
    return (0.0, *tuple(float(sign * value_m) for _ in range(CHUNK_LENGTH - 1)))


def build_offset_specs() -> Dict[str, OffsetSpec]:
    specs: Dict[str, OffsetSpec] = {}
    for direction, sign in (("left", 1.0), ("right", -1.0)):
        for start_m, end_m in ((0.0, 2.0), (2.0, 4.0), (4.0, 6.0)):
            name = f"progressive_{direction}_{format_meter(start_m)}_{format_meter(end_m)}"
            specs[name] = OffsetSpec(
                name=name,
                label=f"progressive {direction} {start_m:g}->{end_m:g}m",
                shifts_left_m=progressive_schedule(start_m, end_m, sign),
            )
        for value_m in (1.0, 2.0, 4.0, 6.0):
            name = f"fixed_{direction}_{format_meter(value_m)}"
            specs[name] = OffsetSpec(
                name=name,
                label=f"fixed {direction} {value_m:g}m",
                shifts_left_m=fixed_schedule(value_m, sign),
            )
    return specs


OFFSET_SPECS = build_offset_specs()


def select_offset_specs(mode: str) -> List[OffsetSpec]:
    if mode == "all":
        names = list(OFFSET_SPECS)
    elif mode == "acceptance":
        names = ["progressive_left_2m_4m", "fixed_left_4m"]
    else:
        names = [part.strip() for part in mode.split(",") if part.strip()]
    unknown = [name for name in names if name not in OFFSET_SPECS]
    if unknown:
        raise ValueError(f"Unknown offset spec(s): {unknown}. Available: {list(OFFSET_SPECS)}")
    return [OFFSET_SPECS[name] for name in names]


def read_grouped_csv(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    required = {"frame_id", "scene_id", "cam", "file"}
    missing = required.difference(rows[0].keys() if rows else set())
    if missing:
        raise ValueError(f"CSV {path} is missing columns: {sorted(missing)}")
    usable = [
        row for row in rows
        if all(row.get(key) is not None and str(row.get(key)).strip() for key in required)
    ]
    skipped = len(rows) - len(usable)
    if skipped:
        print(f"Warning: skipped {skipped} malformed/blank rows in {path}")
    if not usable:
        raise ValueError(f"CSV {path} contains no usable rows")
    return usable


def build_chunk_index(rows: Sequence[dict]) -> List[CameraChunk]:
    by_scene_camera: Dict[Tuple[int, str], Dict[int, dict]] = defaultdict(dict)
    scene_frames: Dict[int, set[int]] = defaultdict(set)
    for row in rows:
        scene_id = int(row["scene_id"])
        frame_id = int(row["frame_id"])
        camera = normalize_camera_name(row["cam"])
        if camera not in CAMERA_ORDER:
            continue
        by_scene_camera[(scene_id, camera)][frame_id] = dict(row)
        scene_frames[scene_id].add(frame_id)

    chunks: List[CameraChunk] = []
    for scene_id in sorted(scene_frames):
        frame_ids = sorted(scene_frames[scene_id])
        for start in range(0, len(frame_ids) - CHUNK_LENGTH + 1, CHUNK_STRIDE):
            window = frame_ids[start : start + CHUNK_LENGTH]
            if len(window) != CHUNK_LENGTH or any(b != a + 1 for a, b in zip(window, window[1:])):
                continue
            per_camera = {}
            complete = True
            for camera in CAMERA_ORDER:
                rows_by_frame = by_scene_camera.get((scene_id, camera), {})
                camera_rows = [rows_by_frame.get(frame_id) for frame_id in window]
                if any(row is None for row in camera_rows):
                    complete = False
                    break
                per_camera[camera] = tuple(camera_rows)
            if not complete:
                continue
            for camera in CAMERA_ORDER:
                chunks.append(CameraChunk(scene_id, camera, window[0], per_camera[camera]))
    return chunks


def find_chunk(
    rows: Sequence[dict],
    start_frame_id: int,
    camera: str,
) -> CameraChunk:
    camera = normalize_camera_name(camera)
    candidates = [
        row for row in rows
        if int(row["frame_id"]) == int(start_frame_id)
        and normalize_camera_name(row["cam"]) == camera
    ]
    if not candidates:
        raise ValueError(f"No row found for camera={camera}, start_frame_id={start_frame_id}")
    if len(candidates) != 1:
        raise ValueError(f"Expected one start row for camera={camera}, frame_id={start_frame_id}, got {len(candidates)}")
    scene_id = int(candidates[0]["scene_id"])
    selected = {
        int(row["frame_id"]): dict(row)
        for row in rows
        if int(row["scene_id"]) == scene_id and normalize_camera_name(row["cam"]) == camera
    }
    frame_ids = list(range(int(start_frame_id), int(start_frame_id) + CHUNK_LENGTH))
    if any(frame_id not in selected for frame_id in frame_ids):
        raise ValueError(
            f"Requested chunk camera={camera}, start_frame_id={start_frame_id} is not a complete 17-frame sequence"
        )
    return CameraChunk(scene_id, camera, int(start_frame_id), tuple(selected[frame_id] for frame_id in frame_ids))


def _stable_schedule_index(seed: int, epoch: int, sample_index: int, rank: int, worker_id: int) -> int:
    payload = f"{seed}:{epoch}:{sample_index}:{rank}:{worker_id}".encode("utf-8")
    digest = hashlib.blake2b(payload, digest_size=8).digest()
    return int.from_bytes(digest, "little") % len(OFFSET_SPECS)


def _rgb_image(array: np.ndarray) -> Image.Image:
    return Image.fromarray(np.asarray(array, dtype=np.uint8), mode="RGB")


def _mask_image(mask: np.ndarray) -> Image.Image:
    mask_rgb = np.repeat(mask.astype(np.uint8)[..., None] * 255, 3, axis=2)
    return Image.fromarray(mask_rgb, mode="RGB")


class NuScenesVaceDataset(Dataset):
    """Online single-camera 17-frame RGB VACE pairs from grouped nuScenes CSV."""

    def __init__(
        self,
        samples_csv: str | Path,
        nuscenes_root: str | Path,
        depth_root: str | Path,
        nuscenes_version_dir: str | Path | None = None,
        seed: int = 42,
        rank: int = 0,
        depth_max: float = 120.0,
        invalid_depth_fill: float = 100.0,
        max_items: int | None = None,
        chunks: Sequence[CameraChunk] | None = None,
        offset_override: str | None = None,
        expected_height: int = 480,
        expected_width: int = 832,
    ):
        self.samples_csv = Path(samples_csv)
        self.nuscenes_root = Path(nuscenes_root)
        self.depth_root = Path(depth_root)
        self.version_dir = resolve_version_dir(self.nuscenes_root, Path(nuscenes_version_dir) if nuscenes_version_dir else None)
        self.seed = int(seed)
        self.rank = int(rank)
        self.depth_max = float(depth_max)
        self.invalid_depth_fill = float(invalid_depth_fill)
        self.expected_height = int(expected_height)
        self.expected_width = int(expected_width)
        if offset_override is not None:
            if offset_override not in OFFSET_SPECS:
                raise ValueError(f"Unknown offset override {offset_override!r}; available: {list(OFFSET_SPECS)}")
        self.offset_override = offset_override
        self.rows = read_grouped_csv(self.samples_csv)
        self.items = list(chunks) if chunks is not None else build_chunk_index(self.rows)
        if max_items is not None:
            self.items = self.items[: int(max_items)]
        if not self.items:
            raise ValueError(f"No complete 17-frame camera chunks found in {self.samples_csv}")
        self.sample_data_by_file, self.calibrated_by_token, self.ego_by_token, self.sensor_by_token = load_metadata_indexes(self.version_dir)
        self._epoch = Value("q", 0)

    def set_epoch(self, epoch: int) -> None:
        with self._epoch.get_lock():
            self._epoch.value = int(epoch)

    @property
    def epoch(self) -> int:
        return int(self._epoch.value)

    def __len__(self) -> int:
        return len(self.items)

    def _offset_for_item(self, index: int) -> OffsetSpec:
        if self.offset_override is not None:
            return OFFSET_SPECS[self.offset_override]
        worker = get_worker_info()
        worker_id = 0 if worker is None else int(worker.id)
        schedule_index = _stable_schedule_index(self.seed, self.epoch, index, self.rank, worker_id)
        return list(OFFSET_SPECS.values())[schedule_index]

    def __getitem__(self, index: int) -> dict:
        chunk = self.items[int(index)]
        offset = self._offset_for_item(int(index))
        target_video: List[Image.Image] = []
        vace_video: List[Image.Image] = []
        vace_mask: List[Image.Image] = []

        for frame_index, row in enumerate(chunk.rows):
            sample = find_sample_from_csv_row(
                nuscenes_root=self.nuscenes_root,
                depth_root=self.depth_root,
                row=row,
                sample_data_by_file=self.sample_data_by_file,
                calibrated_by_token=self.calibrated_by_token,
                ego_by_token=self.ego_by_token,
                sensor_by_token=self.sensor_by_token,
            )
            rgb, depth, valid, intrinsics, _ = load_rgb_depth(
                sample,
                depth_max=self.depth_max,
                invalid_depth_fill=self.invalid_depth_fill,
            )
            if depth.shape != (self.expected_height, self.expected_width):
                raise ValueError(
                    f"Expected depth/RGB resolution {(self.expected_height, self.expected_width)}, "
                    f"got {depth.shape} for scene={chunk.scene_id}, camera={chunk.camera}, "
                    f"frame_id={row['frame_id']}"
                )
            camera_to_ego = transform_from_translation_rotation(
                sample.calibrated_sensor["translation"],
                sample.calibrated_sensor["rotation"],
            )
            if frame_index == 0:
                input_rgb = rgb
                invalid_mask = np.zeros(depth.shape, dtype=bool)
            else:
                result = generate_offset_supervision(
                    rgb=rgb,
                    depth=depth,
                    valid=valid,
                    intrinsics=intrinsics,
                    camera_to_ego=camera_to_ego,
                    shift_left_m=offset.shifts_left_m[frame_index],
                    depth_max=self.depth_max,
                    invalid_depth_fill=self.invalid_depth_fill,
                )
                input_rgb = result.input_rgb
                invalid_mask = result.invalid_mask
            target_image = _rgb_image(rgb)
            target_video.append(target_image)
            vace_video.append(_rgb_image(input_rgb))
            vace_mask.append(_mask_image(invalid_mask))

        return {
            "video": target_video,
            "vace_video": vace_video,
            "vace_video_mask": vace_mask,
            "vace_reference_image": [target_video[0]],
            "prompt": PROMPT,
            "scene_id": chunk.scene_id,
            "camera": chunk.camera,
            "start_frame_id": chunk.start_frame_id,
            "frame_ids": [int(row["frame_id"]) for row in chunk.rows],
            "offset": offset.name,
            "offset_shifts_left_m": list(offset.shifts_left_m),
            "mask_ratios": [float(np.asarray(mask)[..., 0].mean() / 255.0) for mask in vace_mask],
        }


def describe_item(item: dict) -> dict:
    return {
        "scene_id": int(item["scene_id"]),
        "camera": item["camera"],
        "start_frame_id": int(item["start_frame_id"]),
        "frame_ids": item["frame_ids"],
        "offset": item["offset"],
        "num_frames": len(item["video"]),
        "size": [item["video"][0].width, item["video"][0].height],
        "mask_ratios": item["mask_ratios"],
    }
