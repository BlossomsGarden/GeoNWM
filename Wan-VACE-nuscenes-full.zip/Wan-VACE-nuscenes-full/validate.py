from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"
os.environ["DIFFSYNTH_SKIP_DOWNLOAD"] = "true"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch

from diffsynth.core import ModelConfig, load_state_dict
from diffsynth.pipelines.wan_video import WanVideoPipeline

from nuscenes_vace_dataset import (
    NuScenesVaceDataset,
    find_chunk,
    read_grouped_csv,
    select_offset_specs,
)
from preview_utils import make_comparison_frames, save_pil_video
from train import validate_model_directory


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate a local Wan2.1-VACE-1.3B checkpoint on one explicit nuScenes chunk."
    )
    parser.add_argument("--model-path", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--nuscenes-root", type=Path, required=True)
    parser.add_argument("--nuscenes-version-dir", type=Path)
    parser.add_argument("--depth-root", type=Path, required=True)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--split", choices=("train", "val"), required=True)
    parser.add_argument("--start-frame-id", type=int, required=True)
    parser.add_argument("--camera", required=True)
    parser.add_argument("--offset-mode", default="acceptance")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/vace-validation"))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-inference-steps", type=int, default=50)
    parser.add_argument("--cfg-scale", type=float, default=5.0)
    parser.add_argument("--vace-scale", type=float, default=1.0)
    parser.add_argument("--height", type=int, default=480, choices=(480,))
    parser.add_argument("--width", type=int, default=832, choices=(832,))
    parser.add_argument("--num-frames", type=int, default=17, choices=(17,))
    parser.add_argument("--depth-max", type=float, default=120.0)
    parser.add_argument("--invalid-depth-fill", type=float, default=100.0)
    parser.add_argument("--fps", type=float, default=2.0)
    return parser


def load_pipeline(model_path: Path, checkpoint: Path) -> WanVideoPipeline:
    paths = validate_model_directory(model_path)
    checkpoint = checkpoint.expanduser().resolve()
    if not checkpoint.is_file():
        raise FileNotFoundError(f"--checkpoint does not exist: {checkpoint}")
    pipe = WanVideoPipeline.from_pretrained(
        torch_dtype=torch.bfloat16,
        device="cuda" if torch.cuda.is_available() else "cpu",
        model_configs=[
            ModelConfig(path=paths["diffusion"]),
            ModelConfig(path=str(paths["text_encoder"])),
            ModelConfig(path=str(paths["vae"])),
        ],
        tokenizer_config=ModelConfig(path=str(paths["tokenizer"])),
        redirect_common_files=False,
    )
    if pipe.vace is None:
        raise RuntimeError("The local model did not contain a VACE module")
    state_dict = load_state_dict(str(checkpoint))
    # Accept both this project's direct VACE exports and official prefixed exports.
    if state_dict and all(key.startswith("pipe.vace.") for key in state_dict):
        state_dict = {key[len("pipe.vace."):]: value for key, value in state_dict.items()}
    missing, unexpected = pipe.vace.load_state_dict(state_dict, strict=False)
    if missing or unexpected:
        raise ValueError(
            f"Checkpoint does not match pipe.vace (missing={list(missing)[:10]}, "
            f"unexpected={list(unexpected)[:10]})"
        )
    pipe.to(pipe.device)
    pipe.eval()
    return pipe


def safe_name(value: str) -> str:
    return "".join(char if char.isalnum() or char in "._-" else "_" for char in value)


def validate_one(pipe: WanVideoPipeline, item: dict, output_dir: Path, args: argparse.Namespace) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    with torch.inference_mode():
        generated = pipe(
            prompt=item["prompt"],
            vace_video=item["vace_video"],
            vace_video_mask=item["vace_video_mask"],
            vace_reference_image=item["vace_reference_image"][0],
            seed=args.seed,
            num_inference_steps=args.num_inference_steps,
            cfg_scale=args.cfg_scale,
            vace_scale=args.vace_scale,
            height=args.height,
            width=args.width,
            num_frames=args.num_frames,
            tiled=False,
        )
    if len(generated) != args.num_frames:
        raise RuntimeError(f"Pipeline returned {len(generated)} frames, expected {args.num_frames}")
    if generated[0].size != (args.width, args.height):
        raise RuntimeError(f"Pipeline returned {generated[0].size}, expected {(args.width, args.height)}")

    save_pil_video(generated, output_dir / "generated.mp4", args.fps)
    save_pil_video(item["video"], output_dir / "target.mp4", args.fps)
    save_pil_video(item["vace_video"], output_dir / "vace_input.mp4", args.fps)
    save_pil_video(item["vace_video_mask"], output_dir / "mask.mp4", args.fps)
    comparison = make_comparison_frames(
        item["video"], item["vace_video"], item["vace_video_mask"], generated
    )
    save_pil_video(comparison, output_dir / "comparison.mp4", args.fps)
    item["video"][0].save(output_dir / "reference.png")
    manifest = {
        "split": args.split,
        "scene_id": item["scene_id"],
        "camera": item["camera"],
        "start_frame_id": item["start_frame_id"],
        "frame_ids": item["frame_ids"],
        "offset": item["offset"],
        "seed": args.seed,
        "num_inference_steps": args.num_inference_steps,
        "cfg_scale": args.cfg_scale,
        "vace_scale": args.vace_scale,
        "height": args.height,
        "width": args.width,
        "num_frames": args.num_frames,
        "prompt": item["prompt"],
        "model_path": str(args.model_path.resolve()),
        "checkpoint": str(args.checkpoint.resolve()),
        "outputs": {
            "generated": str((output_dir / "generated.mp4").resolve()),
            "target": str((output_dir / "target.mp4").resolve()),
            "vace_input": str((output_dir / "vace_input.mp4").resolve()),
            "mask": str((output_dir / "mask.mp4").resolve()),
            "comparison": str((output_dir / "comparison.mp4").resolve()),
        },
    }
    with (output_dir / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    return manifest


def main() -> None:
    args = build_parser().parse_args()
    if args.num_frames != 17:
        raise ValueError("This validation entry point only supports 17 frames")
    rows = read_grouped_csv(args.csv)
    chunk = find_chunk(rows, args.start_frame_id, args.camera)
    offset_specs = select_offset_specs(args.offset_mode)
    pipe = load_pipeline(args.model_path, args.checkpoint)
    all_manifests = []
    for offset in offset_specs:
        dataset = NuScenesVaceDataset(
            samples_csv=args.csv,
            nuscenes_root=args.nuscenes_root,
            depth_root=args.depth_root,
            nuscenes_version_dir=args.nuscenes_version_dir,
            seed=args.seed,
            depth_max=args.depth_max,
            invalid_depth_fill=args.invalid_depth_fill,
            chunks=[chunk],
            offset_override=offset.name,
            expected_height=args.height,
            expected_width=args.width,
        )
        item = dataset[0]
        output_dir = args.output_dir / safe_name(offset.name)
        all_manifests.append(validate_one(pipe, item, output_dir, args))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(all_manifests, handle, indent=2)
    print(json.dumps(all_manifests, indent=2))


if __name__ == "__main__":
    main()
