# Wan2.1-VACE-1.3B nuScenes full training

This directory is a portable training project. It contains the DiffSynth
runtime files needed by Wan VACE and does not import the neighboring
`DiffSynth-Studio-main` checkout at runtime.

The trainer updates only `pipe.vace`. The Wan DiT, T5 text encoder and VAE are
frozen. Each item is one camera and one contiguous 17-frame video. Chunks are
formed within a scene with starts `0, 16, 32, ...` relative to the sorted scene
sequence; incomplete windows and scene-crossing windows are discarded. The six
nuScenes cameras are independent items, not a six-camera model input.

## Model directory

Pass a local `Wan2.1-VACE-1.3B` directory with these files:

```text
diffusion_pytorch_model*.safetensors
models_t5_umt5-xxl-enc-bf16.pth
Wan2.1_VAE.pth
google/umt5-xxl/tokenizer_config.json
google/umt5-xxl/spiece.model
```

No network download or model fallback is allowed. Missing files fail before
model construction.

## Training

Install the dependencies on the target machine, then launch eight GPUs:

```bash
cd Wan-VACE-nuscenes-full
python -m pip install -r requirements.txt
bash run_train_8gpu.sh \
  --model-path /models/Wan2.1-VACE-1.3B \
  --nuscenes-root /data/nuscenes/v1.0-trainval \
  --depth-root /data/nuscenes-depth-480x832 \
  --train-csv /data/nuscenes_train_samples.csv \
  --val-csv /data/nuscenes_val_samples.csv \
  --output-path /outputs/wan-vace-nuscenes-full
```

Defaults are `480x832`, 17 frames, one sample per GPU, four workers per GPU,
BF16, AdamW with learning rate `5e-5`, weight decay `0.01`, ConstantLR, and two
epochs. Offset geometry is generated online. Every sample chooses one of the
14 schedules deterministically for the current epoch; the next epoch chooses
again. Depth is used only by the geometry code and never passed to VACE. The
RGB is resized to the depth plane only; depth, validity, and camera intrinsics
are used directly at the source `480x832` training resolution. No depth resize
is performed. A complete source depth tree is required.

For a one-step target-machine smoke test, add `--max-train-steps 1
--max-train-items 8 --dataset-num-workers 0`. `--use-gradient-checkpointing`
is available but disabled by default on the 140 GB H200 configuration.

Checkpoints contain VACE weights only:

```text
step-1000.safetensors
epoch-0.safetensors
epoch-1.safetensors
```

Use `--resume-from-checkpoint` to load a VACE-only checkpoint. Optimizer,
scheduler, epoch, step and RNG state are intentionally not serialized.

## Dataset dry run

Dry run does not load the model. It still reads nuScenes metadata and one or
more online RGB-D chunks, then writes videos and manifests:

```bash
python train.py --dry-run --dry-run-items 2 \
  --nuscenes-root /data/nuscenes/v1.0-trainval \
  --depth-root /data/nuscenes-depth-480x832 \
  --train-csv /data/nuscenes_train_samples.csv \
  --output-path outputs/dry-run
```

Each item contains `video`, `vace_video`, `vace_video_mask`,
`vace_reference_image`, and the fixed prompt
`A realistic driving scene captured by a vehicle-mounted camera.`. The first
frame is an unchanged GT anchor and its mask is all black. On later frames,
black (`0`) means observed/conditioned pixels and white (`255`) means pixels
that VACE must generate. Masks are stored as three-channel RGB images.

## Independent validation

Validation selects one exact chunk and one camera. `--offset-mode` accepts one
name, a comma-separated list, `acceptance`, or `all`:

```bash
python validate.py \
  --model-path /models/Wan2.1-VACE-1.3B \
  --checkpoint /outputs/wan-vace-nuscenes-full/epoch-1.safetensors \
  --nuscenes-root /data/nuscenes/v1.0-trainval \
  --depth-root /data/nuscenes-depth-480x832 \
  --csv /data/nuscenes_val_samples.csv \
  --split val \
  --start-frame-id 160 \
  --camera CAM_FRONT \
  --offset-mode progressive_left_2m_4m,fixed_left_4m \
  --output-dir outputs/validation
```

Each offset directory contains `generated.mp4`, `target.mp4`,
`vace_input.mp4`, `mask.mp4`, a four-way `comparison.mp4`, `reference.png`,
and a JSON manifest. Validation uses 50 inference steps, CFG 5, VACE scale 1,
seed 42, and 17 output frames by default.

## Tests

On a machine with the dependencies installed:

```bash
python -m compileall -q .
python -m unittest discover -s tests -v
```

The tests cover schedule count and anchor semantics, scene-local stride-16
chunking, missing-frame rejection, six-camera expansion, deterministic epoch
selection, and VACE RGB mask construction. A full forward/backward smoke test
requires the local model and a CUDA machine, so it is intentionally separate
from the CPU unit tests.

## Remote smoke test

On the configured Wan server, run the one-step check in the existing `wan`
environment. The paths below match the reference nuScenes preparation layout;
adjust only the dataset paths if your mount differs:

```bash
cd /data4/DATA/wlh/Wan/Wan-VACE-nuscenes-full
conda run -n wan python train.py \
  --model-path /data4/DATA/wlh/Wan/model/Wan2.1-VACE-1.3B \
  --nuscenes-root /data2/DATA/AutoDrive/nuscenes/v1.0-trainval \
  --depth-root /data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth \
  --train-csv /data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv \
  --val-csv /data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv \
  --output-path /data4/DATA/wlh/Wan/outputs/vace-smoke \
  --max-train-items 8 --max-train-steps 1 --dataset-num-workers 0
```

This verifies local model discovery, VACE forward/backward, and VACE-only
checkpoint export. A 24 GB RTX 4090 may run out of memory during the forward
pass; that is an environment limitation, not a reason to change the official
8xH200 configuration. The production launch remains `run_train_8gpu.sh` with
one sample per H200 and no offload.
