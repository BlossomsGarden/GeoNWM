# DiffSynth attribution

The `diffsynth/` directory is a self-contained copy of the runtime files used
by DiffSynth-Studio for Wan video/VACE loading and training. The upstream
project is available at:

<https://github.com/modelscope/DiffSynth-Studio>

This project keeps the upstream Python source attribution and does not modify
the original checkout under `test-wan/DiffSynth-Studio-main/`. Verify the
upstream repository's current license and any third-party notices before
redistributing this bundle. The nuScenes geometry and training files in this
directory are project-specific additions.
