from __future__ import annotations

import sys
import tempfile
import unittest
from multiprocessing import Value
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from PIL import Image

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

try:
    import nuscenes_vace_dataset as dataset_module
    IMPORT_ERROR = None
except Exception as exc:  # pragma: no cover - exercised on minimal CPU environments
    dataset_module = None
    IMPORT_ERROR = exc


class DatasetContractTests(unittest.TestCase):
    def test_source_contract_is_present(self):
        source = (PROJECT_ROOT / "nuscenes_vace_dataset.py").read_text(encoding="utf-8")
        self.assertIn("CHUNK_LENGTH = 17", source)
        self.assertIn("CHUNK_STRIDE = 16", source)
        self.assertIn("A realistic driving scene captured by a vehicle-mounted camera.", source)
        self.assertIn("expected_height: int = 480", source)
        self.assertIn("expected_width: int = 832", source)
        self.assertIn("np.repeat(mask.astype(np.uint8)[..., None] * 255, 3, axis=2)", source)

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_csv_reader_skips_trailing_malformed_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "samples.csv"
            path.write_text(
                "frame_id,scene_id,cam,file\n0,1,FRONT,a.jpg\n2020\n",
                encoding="utf-8",
            )
            rows = dataset_module.read_grouped_csv(path)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["frame_id"], "0")

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_fourteen_schedules_have_anchor_and_length(self):
        specs = dataset_module.OFFSET_SPECS
        self.assertEqual(len(specs), 14)
        self.assertEqual(len(set(specs)), 14)
        for spec in specs.values():
            self.assertEqual(len(spec.shifts_left_m), 17)
            self.assertEqual(spec.shifts_left_m[0], 0.0)

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_scene_local_stride_and_six_camera_expansion(self):
        rows = []
        cameras = dataset_module.CAMERA_ORDER
        for scene_id, frame_count in ((10, 51), (20, 33)):
            for frame_id in range(frame_count):
                for camera in cameras:
                    rows.append({
                        "scene_id": str(scene_id),
                        "frame_id": str(frame_id),
                        "cam": camera,
                        "file": f"scene{scene_id}_{camera}_{frame_id:06d}.jpg",
                    })
        chunks = dataset_module.build_chunk_index(rows)
        self.assertEqual(len(chunks), 5 * 6)
        starts_by_scene = {
            scene_id: sorted({chunk.start_frame_id for chunk in chunks if chunk.scene_id == scene_id})
            for scene_id in (10, 20)
        }
        self.assertEqual(starts_by_scene[10], [0, 16, 32])
        self.assertEqual(starts_by_scene[20], [0, 16])
        for scene_id, scene_starts in starts_by_scene.items():
            for start in scene_starts:
                self.assertEqual(
                    sum(chunk.start_frame_id == start and chunk.scene_id == scene_id for chunk in chunks),
                    6,
                )
        self.assertTrue(all(len(chunk.rows) == 17 for chunk in chunks))

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_missing_frame_discards_window(self):
        rows = []
        for frame_id in range(33):
            for camera in dataset_module.CAMERA_ORDER:
                if frame_id == 17 and camera == "CAM_BACK":
                    continue
                rows.append({
                    "scene_id": "1",
                    "frame_id": str(frame_id),
                    "cam": camera,
                    "file": f"{camera}_{frame_id:06d}.jpg",
                })
        chunks = dataset_module.build_chunk_index(rows)
        # The first 0..16 window remains valid; only windows containing frame 17
        # are rejected.
        self.assertEqual(len(chunks), 6)
        self.assertTrue(all(chunk.start_frame_id == 0 for chunk in chunks))

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_exact_validation_chunk_does_not_search_forward(self):
        rows = [
            {"scene_id": "1", "frame_id": str(frame), "cam": "CAM_FRONT", "file": f"{frame}.jpg"}
            for frame in range(1, 18)
        ]
        with self.assertRaises(ValueError):
            dataset_module.find_chunk(rows, start_frame_id=0, camera="CAM_FRONT")

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_epoch_selection_changes_and_override_is_stable(self):
        dataset = dataset_module.NuScenesVaceDataset.__new__(dataset_module.NuScenesVaceDataset)
        dataset.seed = 42
        dataset.rank = 0
        dataset._epoch = Value("q", 0)
        dataset.offset_override = None
        first = [dataset._offset_for_item(index).name for index in range(32)]
        dataset.set_epoch(1)
        second = [dataset._offset_for_item(index).name for index in range(32)]
        self.assertNotEqual(first, second)
        dataset.offset_override = "fixed_left_4m"
        self.assertEqual(dataset._offset_for_item(7).name, "fixed_left_4m")

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_item_contract_and_anchor_mask(self):
        rows = tuple({"scene_id": "1", "frame_id": str(i), "cam": "CAM_FRONT", "file": f"{i}.jpg"} for i in range(17))
        dataset = dataset_module.NuScenesVaceDataset.__new__(dataset_module.NuScenesVaceDataset)
        dataset.seed = 1
        dataset.rank = 0
        dataset._epoch = Value("q", 0)
        dataset.items = [dataset_module.CameraChunk(1, "CAM_FRONT", 0, rows)]
        dataset.depth_max = 120.0
        dataset.invalid_depth_fill = 100.0
        dataset.expected_height = 4
        dataset.expected_width = 6
        dataset.offset_override = "fixed_left_4m"
        rgb = np.full((4, 6, 3), 17, dtype=np.uint8)
        depth = np.ones((4, 6), dtype=np.float32)
        valid = np.ones((4, 6), dtype=bool)
        intrinsics = np.eye(3, dtype=np.float32)
        dataset_module.find_sample_from_csv_row = lambda **kwargs: SimpleNamespace(
            calibrated_sensor={"translation": [0, 0, 0], "rotation": [1, 0, 0, 0]}
        )
        dataset_module.load_rgb_depth = lambda *args, **kwargs: (rgb, depth, valid, intrinsics, {})
        dataset_module.transform_from_translation_rotation = lambda *args, **kwargs: np.eye(4, dtype=np.float32)
        dataset_module.generate_offset_supervision = lambda **kwargs: SimpleNamespace(
            input_rgb=np.full((4, 6, 3), 3, dtype=np.uint8),
            invalid_mask=np.pad(np.ones((1, 1), dtype=bool), ((0, 3), (0, 5))),
        )
        dataset.nuscenes_root = Path(".")
        dataset.depth_root = Path(".")
        dataset.sample_data_by_file = dataset.calibrated_by_token = dataset.ego_by_token = dataset.sensor_by_token = {}
        item = dataset[0]
        self.assertEqual(set(("video", "vace_video", "vace_video_mask", "vace_reference_image", "prompt")) - set(item), set())
        self.assertEqual(len(item["video"]), 17)
        self.assertEqual(item["video"][0], item["vace_reference_image"][0])
        self.assertEqual(item["vace_video_mask"][0].mode, "RGB")
        self.assertEqual(np.asarray(item["vace_video_mask"][0]).max(), 0)
        self.assertEqual(np.asarray(item["vace_video_mask"][1]).max(), 255)

    @unittest.skipIf(IMPORT_ERROR is not None, f"dataset dependencies unavailable: {IMPORT_ERROR}")
    def test_rgb_is_aligned_to_native_depth_without_depth_resize(self):
        import nuscenes_offset

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            image_path = root / "frame.jpg"
            depth_path = root / "frame.npz"
            Image.new("RGB", (1600, 900), (10, 20, 30)).save(image_path)
            depth = np.full((480, 832), 12.0, dtype=np.float32)
            mask = np.ones((480, 832), dtype=np.uint8)
            intrinsics = np.array([[650, 0, 410], [0, 670, 240], [0, 0, 1]], dtype=np.float32)
            np.savez(depth_path, depth=depth, mask=mask, intrinsics=intrinsics)
            sample = SimpleNamespace(
                image_path=image_path,
                depth_path=depth_path,
                calibrated_sensor={"camera_intrinsic": intrinsics.tolist()},
            )
            rgb, loaded_depth, valid, loaded_intrinsics, _ = nuscenes_offset.load_rgb_depth(
                sample, depth_max=120.0, invalid_depth_fill=100.0
            )
        self.assertEqual(rgb.shape, (480, 832, 3))
        self.assertEqual(loaded_depth.shape, (480, 832))
        self.assertEqual(valid.shape, (480, 832))
        np.testing.assert_array_equal(loaded_depth, depth)
        np.testing.assert_array_equal(loaded_intrinsics, intrinsics)


if __name__ == "__main__":
    unittest.main()
