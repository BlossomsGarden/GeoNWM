#!/usr/bin/env bash
set -euo pipefail

cd /data/wlh/Triplane/code/Triplane-Stage-1

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/data/wlh/Triplane/model/hf_cache}"
export HUGGINGFACE_HUB_CACHE="${HUGGINGFACE_HUB_CACHE:-${HF_HOME}/hub}"

PYTHON="${PYTHON:-/data/wlh/miniconda3/envs/omninwm/bin/python}"
extra_args=()
save_visuals="${SAVE_VISUALS:-1}"
if [[ -n "${save_visuals}" && "${save_visuals}" != "0" && "${save_visuals}" != "false" ]]; then
  extra_args+=(--save-visuals)
fi
if [[ -n "${LIMIT_SAMPLES:-}" ]]; then
  extra_args+=(--limit-samples "${LIMIT_SAMPLES}")
fi
if [[ -n "${LIMIT_BATCHES:-}" ]]; then
  extra_args+=(--limit-batches "${LIMIT_BATCHES}")
fi
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-7}" \
"${PYTHON}" -m geonwm_stage1.eval \
  --config configs/stage1_nuscenes.yaml \
  --checkpoint "${CHECKPOINT:?Set CHECKPOINT}" \
  --checkpoint-kind "${CHECKPOINT_KIND:-full}" \
  --split "${SPLIT:-val}" \
  --batch-size "${BATCH_SIZE:-1}" \
  --num-workers "${NUM_WORKERS:-0}" \
  --output-dir "${OUTPUT_DIR:-/data/wlh/Triplane/model/stage1_eval}" \
  --visual-count "${VISUAL_COUNT:-2}" \
  --amp "${AMP:-bf16}" \
  "${extra_args[@]}"
