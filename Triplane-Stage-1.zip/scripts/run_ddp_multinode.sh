#!/usr/bin/env bash
set -euo pipefail

cd /data/wlh/Triplane/code/Triplane-Stage-1

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/data/wlh/Triplane/model/hf_cache}"
export HUGGINGFACE_HUB_CACHE="${HUGGINGFACE_HUB_CACHE:-${HF_HOME}/hub}"
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1

PYTHON="${PYTHON:-/data/wlh/miniconda3/envs/omninwm/bin/python}"
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}" \
"${PYTHON}" -m torch.distributed.run \
  --nnodes="${NNODES:?Set NNODES}" \
  --node_rank="${NODE_RANK:?Set NODE_RANK}" \
  --nproc_per_node="${NPROC_PER_NODE:-4}" \
  --master_addr="${MASTER_ADDR:?Set MASTER_ADDR}" \
  --master_port="${MASTER_PORT:-29500}" \
  -m geonwm_stage1.train \
  --config configs/stage1_nuscenes.yaml \
  --output-dir "${OUTPUT_DIR:-/data/wlh/Triplane/model/stage1_fullscale}" \
  --resume "${RESUME:-auto}" \
  --num-workers "${NUM_WORKERS:-2}" \
  --amp "${AMP:-bf16}" \
  --save-full-hours "${SAVE_FULL_HOURS:-6}" \
  --save-weights-hours "${SAVE_WEIGHTS_HOURS:-3}" \
  ${FIND_UNUSED_PARAMETERS:-}
