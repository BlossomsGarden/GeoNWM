#!/usr/bin/env bash
set -euo pipefail

cd /data/wlh/Triplane/code/Triplane-Stage-1

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/data/wlh/Triplane/model/hf_cache}"
export HUGGINGFACE_HUB_CACHE="${HUGGINGFACE_HUB_CACHE:-${HF_HOME}/hub}"
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1

PYTHON="${PYTHON:-/data/wlh/miniconda3/envs/omninwm/bin/python}"
TRAIN_GPUS="${TRAIN_GPUS:-4}"
extra_args=()
if [[ -n "${MAX_HOURS:-}" ]]; then
  extra_args+=(--max-hours "${MAX_HOURS}")
fi
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-4,5,6,7}" \
"${PYTHON}" -m torch.distributed.run \
  --standalone \
  --nproc_per_node="${TRAIN_GPUS}" \
  -m geonwm_stage1.train \
  --config configs/stage1_nuscenes.yaml \
  --output-dir "${OUTPUT_DIR:-/data/wlh/Triplane/model/stage1_fullscale}" \
  --resume "${RESUME:-auto}" \
  --batch-size "${BATCH_SIZE:-3}" \
  --num-workers "${NUM_WORKERS:-2}" \
  --amp "${AMP:-bf16}" \
  --save-full-hours "${SAVE_FULL_HOURS:-6}" \
  --save-weights-hours "${SAVE_WEIGHTS_HOURS:-3}" \
  "${extra_args[@]}" \
  ${FIND_UNUSED_PARAMETERS:-}
