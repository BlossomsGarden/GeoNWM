#!/usr/bin/env bash
set -euo pipefail

cd /data/wlh/Triplane/code/Triplane-Stage-1

PYTHON="${PYTHON:-/data/wlh/miniconda3/envs/omninwm/bin/python}"
DINOV3_PATH="${DINOV3_PATH:-/data/wlh/Triplane/model/vit_large_patch16_dinov3}"
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-7}" \
"${PYTHON}" -m geonwm_stage1.train \
  --config configs/stage1_nuscenes.yaml \
  --dinov3-path "${DINOV3_PATH}" \
  --output-dir /data/wlh/Triplane/model/stage1_fullscale_verify \
  --max-steps "${MAX_STEPS:-2}" \
  --limit-samples "${LIMIT_SAMPLES:-8}" \
  --num-workers "${NUM_WORKERS:-0}" \
  --amp "${AMP:-bf16}"
