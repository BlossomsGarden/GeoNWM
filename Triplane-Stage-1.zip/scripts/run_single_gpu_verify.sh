#!/usr/bin/env bash
set -euo pipefail

cd /data/wlh/Triplane/code/Triplane-Stage-1

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-/data/wlh/Triplane/model/hf_cache}"
export HUGGINGFACE_HUB_CACHE="${HUGGINGFACE_HUB_CACHE:-${HF_HOME}/hub}"

PYTHON="${PYTHON:-/data/wlh/miniconda3/envs/omninwm/bin/python}"
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-7}" \
"${PYTHON}" -m geonwm_stage1.train \
  --config configs/stage1_nuscenes.yaml \
  --output-dir /data/wlh/Triplane/model/stage1_fullscale_verify \
  --max-steps "${MAX_STEPS:-2}" \
  --limit-samples "${LIMIT_SAMPLES:-8}" \
  --num-workers "${NUM_WORKERS:-0}" \
  --amp "${AMP:-bf16}"
