#!/usr/bin/env bash
set -euo pipefail

cd /data/wlh/Triplane/code/Triplane-Stage-1

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
export TRAIN_GPUS="${TRAIN_GPUS:-8}"
export BATCH_SIZE="${BATCH_SIZE:-3}"
export NUM_WORKERS="${NUM_WORKERS:-2}"
export RESUME="${RESUME:-auto}"
export OUTPUT_DIR="${OUTPUT_DIR:-/data/wlh/Triplane/model/stage1_fullscale}"
export MAX_HOURS="${MAX_HOURS:-7}"
export SAVE_FULL_HOURS="${SAVE_FULL_HOURS:-6}"
export SAVE_WEIGHTS_HOURS="${SAVE_WEIGHTS_HOURS:-3}"
export AMP="${AMP:-bf16}"

run_stamp="$(date +%Y%m%d_%H%M%S)"
train_log="${OUTPUT_DIR}/train_8gpu_7h_${run_stamp}.log"
eval_dir="${EVAL_OUTPUT_DIR:-/data/wlh/Triplane/model/stage1_eval_${run_stamp}}"

mkdir -p "${OUTPUT_DIR}"

bash scripts/run_ddp_train_4gpu.sh 2>&1 | tee "${train_log}"

CHECKPOINT="${OUTPUT_DIR}/checkpoint_latest.pt" \
CHECKPOINT_KIND=full \
CUDA_VISIBLE_DEVICES="${EVAL_CUDA_VISIBLE_DEVICES:-7}" \
OUTPUT_DIR="${eval_dir}" \
SAVE_VISUALS="${SAVE_VISUALS:-1}" \
BATCH_SIZE="${EVAL_BATCH_SIZE:-1}" \
NUM_WORKERS="${EVAL_NUM_WORKERS:-2}" \
LIMIT_BATCHES="${EVAL_LIMIT_BATCHES:-64}" \
bash scripts/run_eval_visualize.sh 2>&1 | tee "${eval_dir}.log"

echo "Training log: ${train_log}"
echo "Eval output: ${eval_dir}"
