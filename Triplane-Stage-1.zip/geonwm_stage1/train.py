from __future__ import annotations

import argparse
import json
import math
import os
import random
import signal
import time
from pathlib import Path
from typing import Any

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from tqdm import tqdm

from geonwm_stage1.data.nuscenes_stage1 import NuScenesStage1Dataset, collate_stage1
from geonwm_stage1.losses.stage1_losses import Stage1Loss
from geonwm_stage1.models.attention import flash_attn_available
from geonwm_stage1.models.stage1 import GeoNWMStage1
from geonwm_stage1.utils.config import load_config
from geonwm_stage1.utils.runtime import ensure_dir, finite_dict, seed_everything, to_device


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train GeoNWM Phase1 Triplane model.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--limit-samples", type=int, default=None)
    parser.add_argument("--amp", choices=["none", "fp16", "bf16"], default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--resume", default=None)
    parser.add_argument("--dinov3-path", default=None, help="Local DINOv3 checkpoint file or directory.")
    parser.add_argument("--save-full-hours", type=float, default=None)
    parser.add_argument("--save-weights-hours", type=float, default=None)
    parser.add_argument("--max-hours", type=float, default=None)
    parser.add_argument("--find-unused-parameters", action="store_true")
    return parser.parse_args()


def ddp_state() -> tuple[bool, int, int, int]:
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    return world_size > 1, rank, local_rank, world_size


def setup_distributed() -> tuple[bool, int, int, int]:
    distributed, rank, local_rank, world_size = ddp_state()
    if distributed:
        torch.cuda.set_device(local_rank)
        dist.init_process_group(backend="nccl", init_method="env://")
    return distributed, rank, local_rank, world_size


def cleanup_distributed(distributed: bool) -> None:
    if distributed and dist.is_initialized():
        dist.destroy_process_group()


def is_rank0(rank: int) -> bool:
    return rank == 0


def unwrap_module(module: torch.nn.Module) -> torch.nn.Module:
    return module.module if isinstance(module, DistributedDataParallel) else module


def make_view_keep_mask(batch_size: int, num_views: int, step: int, cfg: dict[str, Any], device: torch.device) -> torch.Tensor:
    sampling = cfg["train"].get("view_sampling", {})
    if step < int(sampling.get("full_until_step", 0)):
        return torch.ones(batch_size, num_views, dtype=torch.bool, device=device)
    probs = sampling.get("probabilities", {"six": 1.0})
    names = list(probs.keys())
    weights = [float(probs[n]) for n in names]
    strategy = random.choices(names, weights=weights, k=1)[0]
    if strategy in {"one", "single"}:
        n_keep = 1
    elif strategy in {"three", "drop3"}:
        n_keep = min(3, num_views)
    else:
        n_keep = num_views
    if n_keep == num_views:
        return torch.ones(batch_size, num_views, dtype=torch.bool, device=device)
    keep_idx = torch.randperm(num_views, device=device)[:n_keep]
    mask = torch.zeros(batch_size, num_views, dtype=torch.bool, device=device)
    mask[:, keep_idx] = True
    return mask


def cosine_lr(step: int, cfg: dict[str, Any]) -> float:
    tr = cfg["train"]
    lr = float(tr["lr"])
    min_lr = float(tr.get("min_lr", 1e-6))
    warmup = int(tr.get("warmup_steps", 0))
    total = int(tr.get("total_steps", 400000))
    if warmup > 0 and step < warmup:
        return lr * float(step + 1) / float(warmup)
    progress = min(1.0, max(0.0, (step - warmup) / max(total - warmup, 1)))
    return min_lr + 0.5 * (lr - min_lr) * (1.0 + math.cos(math.pi * progress))


def set_lr(optimizer: torch.optim.Optimizer, lr: float) -> None:
    for group in optimizer.param_groups:
        group["lr"] = lr


def find_latest_checkpoint(out_dir: Path) -> Path | None:
    latest = out_dir / "checkpoint_latest.pt"
    if latest.exists():
        return latest
    ckpts = sorted(out_dir.glob("checkpoint_step_*.pt"))
    return ckpts[-1] if ckpts else None


def save_full_checkpoint(
    out_dir: Path,
    model: torch.nn.Module,
    criterion: Stage1Loss,
    optimizer: torch.optim.Optimizer,
    scaler: torch.cuda.amp.GradScaler,
    step: int,
    cfg: dict[str, Any],
    name: str,
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    state = {
        "step": step,
        "model": unwrap_module(model).state_dict(),
        "criterion": unwrap_module(criterion).state_dict(),
        "optimizer": optimizer.state_dict(),
        "scaler": scaler.state_dict() if scaler.is_enabled() else None,
        "config": cfg,
    }
    path = out_dir / name
    torch.save(state, path)
    torch.save(state, out_dir / "checkpoint_latest.pt")


def save_weights(out_dir: Path, model: torch.nn.Module, step: int) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    state = {"step": step, "model": unwrap_module(model).state_dict()}
    torch.save(state, out_dir / f"weights_step_{step:07d}.pt")
    torch.save(state, out_dir / "weights_latest.pt")


def amp_context(mode: str, device: torch.device):
    if device.type != "cuda" or mode == "none":
        return torch.autocast(device_type="cpu", enabled=False)
    dtype = torch.bfloat16 if mode == "bf16" else torch.float16
    return torch.autocast(device_type="cuda", dtype=dtype)


def main() -> None:
    args = parse_args()
    distributed, rank, local_rank, world_size = setup_distributed()
    cfg = load_config(args.config)
    seed_everything(int(cfg.get("seed", 2026)) + rank)
    train_cfg = cfg["train"]
    if args.amp is not None:
        train_cfg["amp"] = args.amp
    if args.batch_size is not None:
        train_cfg["batch_size"] = args.batch_size
    if args.num_workers is not None:
        train_cfg["num_workers"] = args.num_workers
    if args.output_dir is not None:
        cfg["paths"]["output_dir"] = args.output_dir
    if args.dinov3_path is not None:
        cfg["model"]["image_encoder"]["pretrained_path"] = args.dinov3_path
    save_full_hours = float(args.save_full_hours if args.save_full_hours is not None else train_cfg.get("save_full_hours", 6.0))
    save_weights_hours = float(
        args.save_weights_hours if args.save_weights_hours is not None else train_cfg.get("save_weights_hours", 3.0)
    )

    out_dir = ensure_dir(cfg["paths"]["output_dir"])
    log_path = out_dir / "train_log.jsonl"
    device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")

    dataset = NuScenesStage1Dataset(cfg, split="train", limit_samples=args.limit_samples)
    sampler = DistributedSampler(dataset, num_replicas=world_size, rank=rank, shuffle=True, drop_last=False) if distributed else None
    num_workers = int(train_cfg.get("num_workers", 2))
    loader_kwargs: dict[str, Any] = {
        "batch_size": int(train_cfg.get("batch_size", 1)),
        "shuffle": sampler is None,
        "sampler": sampler,
        "num_workers": num_workers,
        "pin_memory": device.type == "cuda",
        "collate_fn": collate_stage1,
        "drop_last": False,
    }
    if num_workers > 0:
        loader_kwargs["persistent_workers"] = bool(train_cfg.get("persistent_workers", True))
        loader_kwargs["prefetch_factor"] = int(train_cfg.get("prefetch_factor", 2))
    loader = DataLoader(dataset, **loader_kwargs)

    model = GeoNWMStage1(cfg).to(device)
    criterion = Stage1Loss(cfg).to(device)
    if distributed:
        model = DistributedDataParallel(
            model,
            device_ids=[local_rank],
            output_device=local_rank,
            find_unused_parameters=args.find_unused_parameters,
        )
        criterion = DistributedDataParallel(
            criterion,
            device_ids=[local_rank],
            output_device=local_rank,
            find_unused_parameters=args.find_unused_parameters,
        )
    params = list(model.parameters()) + list(criterion.parameters())
    optimizer = torch.optim.AdamW(
        params,
        lr=float(train_cfg["lr"]),
        weight_decay=float(train_cfg.get("weight_decay", 0.01)),
        betas=(0.9, 0.999),
    )

    max_steps = args.max_steps if args.max_steps is not None else int(train_cfg["total_steps"])
    amp_mode = str(train_cfg.get("amp", "bf16"))
    scaler = torch.cuda.amp.GradScaler(enabled=(device.type == "cuda" and amp_mode == "fp16"))
    start_step = 0
    resume_path = args.resume
    if resume_path == "auto":
        latest = find_latest_checkpoint(out_dir)
        resume_path = str(latest) if latest is not None else None
    if resume_path:
        ckpt = torch.load(resume_path, map_location="cpu")
        unwrap_module(model).load_state_dict(ckpt["model"])
        unwrap_module(criterion).load_state_dict(ckpt["criterion"])
        optimizer.load_state_dict(ckpt["optimizer"])
        if scaler.is_enabled() and ckpt.get("scaler") is not None:
            scaler.load_state_dict(ckpt["scaler"])
        start_step = int(ckpt.get("step", -1)) + 1

    if is_rank0(rank):
        print(json.dumps({
            "distributed": distributed,
            "world_size": world_size,
            "flash_attn": flash_attn_available(),
            "device": str(device),
            "batch_size_per_rank": int(train_cfg.get("batch_size", 1)),
            "num_workers_per_rank": num_workers,
            "grad_accum_steps": int(train_cfg.get("grad_accum_steps", 1)),
            "start_step": start_step,
            "max_steps": max_steps,
            "max_hours": args.max_hours,
        }, ensure_ascii=False))

    grad_accum = max(1, int(train_cfg.get("grad_accum_steps", 1)))
    pbar = tqdm(total=max_steps, initial=start_step, desc="stage1-train", disable=not is_rank0(rank))
    step = start_step
    epoch = 0
    model.train()
    criterion.train()
    loader_iter = iter(loader)
    train_start_time = time.monotonic()
    last_full_save = time.monotonic()
    last_weights_save = time.monotonic()
    last_step_time = time.monotonic()
    shutdown_requested = False

    def request_shutdown(signum: int, _frame: Any) -> None:
        nonlocal shutdown_requested
        shutdown_requested = True
        if is_rank0(rank):
            print(f"Received signal {signum}; stopping after the current step and saving checkpoints.", flush=True)

    signal.signal(signal.SIGTERM, request_shutdown)
    signal.signal(signal.SIGINT, request_shutdown)

    log_f = open(log_path, "a", encoding="utf-8") if is_rank0(rank) else None
    try:
        while step < max_steps and not shutdown_requested:
            if sampler is not None:
                sampler.set_epoch(epoch)
            optimizer.zero_grad(set_to_none=True)
            accum_logs: dict[str, torch.Tensor] | None = None
            current_lr = cosine_lr(step, cfg)
            set_lr(optimizer, current_lr)
            if device.type == "cuda":
                torch.cuda.reset_peak_memory_stats(device)
            data_wait_seconds = 0.0
            for _ in range(grad_accum):
                data_wait_start = time.monotonic()
                try:
                    batch = next(loader_iter)
                except StopIteration:
                    epoch += 1
                    if sampler is not None:
                        sampler.set_epoch(epoch)
                    loader_iter = iter(loader)
                    batch = next(loader_iter)
                data_wait_seconds += time.monotonic() - data_wait_start
                batch = to_device(batch, device)
                keep_mask = make_view_keep_mask(batch["images"].shape[0], batch["images"].shape[1], step, cfg, device)
                with amp_context(amp_mode, device):
                    pred = model(batch, view_keep_mask=keep_mask)
                    loss, logs = criterion(
                        pred,
                        batch,
                        step=step,
                        force_all=bool(train_cfg.get("force_enable_all_losses", False)),
                    )
                    loss = loss / float(grad_accum)
                if not torch.isfinite(loss) or not finite_dict(logs):
                    raise FloatingPointError(f"Non-finite loss at step {step}: {logs}")
                accum_logs = logs
                if scaler.is_enabled():
                    scaler.scale(loss).backward()
                else:
                    loss.backward()
            if scaler.is_enabled():
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(params, float(train_cfg.get("grad_clip", 35.0)))
                scaler.step(optimizer)
                scaler.update()
            else:
                torch.nn.utils.clip_grad_norm_(params, float(train_cfg.get("grad_clip", 35.0)))
                optimizer.step()

            now = time.monotonic()
            step_seconds = now - last_step_time
            last_step_time = now
            if is_rank0(rank) and step % int(train_cfg.get("log_every", 1)) == 0 and accum_logs is not None:
                mem_gb = torch.cuda.max_memory_allocated(device) / (1024**3) if device.type == "cuda" else 0.0
                alloc_gb = torch.cuda.memory_allocated(device) / (1024**3) if device.type == "cuda" else 0.0
                reserved_gb = torch.cuda.memory_reserved(device) / (1024**3) if device.type == "cuda" else 0.0
                rec = {
                    "step": step,
                    "lr": current_lr,
                    "tokens": batch["token"],
                    "step_seconds": step_seconds,
                    "data_wait_seconds": data_wait_seconds,
                    "cuda_max_allocated_gb": mem_gb,
                    "cuda_allocated_gb": alloc_gb,
                    "cuda_reserved_gb": reserved_gb,
                    "flash_attn": flash_attn_available(),
                    **{k: float(v.detach().cpu()) for k, v in accum_logs.items()},
                }
                assert log_f is not None
                log_f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                log_f.flush()
                pbar.set_postfix({
                    "sec": f"{step_seconds:.2f}",
                    "data": f"{data_wait_seconds:.2f}",
                    "peak_gb": f"{mem_gb:.1f}",
                    **{k: f"{rec[k]:.4f}" for k in rec if k in ("total", "raw_rgb", "raw_depth")},
                })

            if is_rank0(rank) and now - last_weights_save >= save_weights_hours * 3600.0:
                save_weights(out_dir, model, step)
                last_weights_save = now
            if is_rank0(rank) and now - last_full_save >= save_full_hours * 3600.0:
                save_full_checkpoint(out_dir, model, criterion, optimizer, scaler, step, cfg, f"checkpoint_step_{step:07d}.pt")
                last_full_save = now
            if is_rank0(rank) and step > 0 and step % int(train_cfg.get("save_every", 1000)) == 0:
                save_full_checkpoint(out_dir, model, criterion, optimizer, scaler, step, cfg, f"checkpoint_step_{step:07d}.pt")

            step += 1
            pbar.update(1)
            if args.max_hours is not None and time.monotonic() - train_start_time >= float(args.max_hours) * 3600.0:
                if is_rank0(rank):
                    print(f"Reached --max-hours={args.max_hours}; saving final checkpoint and exiting.", flush=True)
                break
    finally:
        if is_rank0(rank):
            save_full_checkpoint(out_dir, model, criterion, optimizer, scaler, step - 1, cfg, f"checkpoint_step_{step - 1:07d}.pt")
            save_weights(out_dir, model, step - 1)
            pbar.close()
            if log_f is not None:
                log_f.close()
        cleanup_distributed(distributed)

    if is_rank0(rank):
        print(f"Training finished at step {step}. Output: {out_dir}")


if __name__ == "__main__":
    main()
