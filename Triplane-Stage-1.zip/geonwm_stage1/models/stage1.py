from __future__ import annotations

from typing import Any

import torch
from torch import nn

from geonwm_stage1.models.decoder import MultiTaskDecoder
from geonwm_stage1.models.encoder import build_image_encoder
from geonwm_stage1.models.triplane import DepthGuidedTriplaneScatter, TriplaneRefiner, TriplaneSpec


class GeoNWMStage1(nn.Module):
    def __init__(self, cfg: dict[str, Any]):
        super().__init__()
        enc_cfg = cfg["model"]["image_encoder"]
        tp_cfg = cfg["model"]["triplane"]
        self.spec = TriplaneSpec(
            channels=int(tp_cfg["channels"]),
            xy_size=int(tp_cfg["xy_size"]),
            z_size=int(tp_cfg["z_size"]),
            x_range=tuple(float(x) for x in tp_cfg["x_range"]),
            y_range=tuple(float(x) for x in tp_cfg["y_range"]),
            z_range=tuple(float(x) for x in tp_cfg["z_range"]),
        )
        self.image_encoder = build_image_encoder(enc_cfg)
        self.scatter = DepthGuidedTriplaneScatter(self.spec)
        self.refiner = TriplaneRefiner(
            self.spec,
            layers=int(tp_cfg.get("transformer_layers", 2)),
            heads=int(tp_cfg.get("transformer_heads", 4)),
            mlp_ratio=float(tp_cfg.get("transformer_mlp_ratio", 2.0)),
        )
        self.decoder = MultiTaskDecoder(cfg, self.spec)


    @staticmethod
    def _select_target_views(
        batch: dict[str, torch.Tensor],
        view_keep_mask: torch.Tensor | None,
    ) -> dict[str, torch.Tensor]:
        if view_keep_mask is None or bool(view_keep_mask.all()):
            return batch
        selected: list[int] = []
        for bi in range(view_keep_mask.shape[0]):
            idx = torch.nonzero(view_keep_mask[bi], as_tuple=False).flatten()
            if idx.numel() == 0:
                idx = torch.arange(view_keep_mask.shape[1], device=view_keep_mask.device)
            if bi == 0:
                selected = idx.detach().cpu().tolist()
            elif selected != idx.detach().cpu().tolist():
                return batch
        out = dict(batch)
        for key in [
            "images",
            "depth",
            "depth_mask",
            "pointmap",
            "semantic",
            "intrinsics",
            "cam_to_lidar_rot",
            "cam_to_lidar_trans",
            "lidar_to_cam_rot",
            "lidar_to_cam_trans",
        ]:
            if key in out and torch.is_tensor(out[key]):
                out[key] = out[key][:, selected]
        out["view_indices"] = torch.tensor(selected, device=view_keep_mask.device, dtype=torch.long)
        return out

    def forward(
        self,
        batch: dict[str, torch.Tensor],
        view_keep_mask: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        features = self.image_encoder(batch["images"])
        planes0 = self.scatter(features, batch["pointmap"], batch["depth_mask"], view_keep_mask)
        planes = self.refiner(planes0)
        target_batch = self._select_target_views(batch, view_keep_mask)
        out = self.decoder(planes, target_batch)
        out["target_view_indices"] = target_batch.get("view_indices")
        out["planes"] = planes
        return out
