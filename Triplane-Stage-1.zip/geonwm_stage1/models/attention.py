from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F

try:
    from flash_attn import flash_attn_func

    _FLASH_ATTN_AVAILABLE = True
except Exception:
    flash_attn_func = None
    _FLASH_ATTN_AVAILABLE = False


def flash_attn_available() -> bool:
    return _FLASH_ATTN_AVAILABLE


class EfficientSelfAttention(nn.Module):
    """Self-attention that prefers flash-attn and falls back to PyTorch SDPA."""

    def __init__(self, dim: int, heads: int, dropout: float = 0.0):
        super().__init__()
        if dim % heads != 0:
            raise ValueError(f"Attention dim {dim} must be divisible by heads {heads}.")
        self.dim = dim
        self.heads = heads
        self.head_dim = dim // heads
        self.dropout = dropout
        self.qkv = nn.Linear(dim, dim * 3)
        self.proj = nn.Linear(dim, dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, n, c = x.shape
        qkv = self.qkv(x).reshape(b, n, 3, self.heads, self.head_dim)
        q, k, v = qkv.unbind(dim=2)
        dropout_p = self.dropout if self.training else 0.0
        if (
            _FLASH_ATTN_AVAILABLE
            and x.is_cuda
            and x.dtype in (torch.float16, torch.bfloat16)
            and flash_attn_func is not None
        ):
            out = flash_attn_func(q, k, v, dropout_p=dropout_p, causal=False)
        else:
            q = q.transpose(1, 2)
            k = k.transpose(1, 2)
            v = v.transpose(1, 2)
            out = F.scaled_dot_product_attention(q, k, v, dropout_p=dropout_p, is_causal=False)
            out = out.transpose(1, 2)
        return self.proj(out.reshape(b, n, c))
