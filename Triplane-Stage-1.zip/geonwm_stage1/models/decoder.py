from __future__ import annotations

from typing import Any

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint

from geonwm_stage1.data.geometry import voxel_centers
from geonwm_stage1.models.attention import EfficientSelfAttention
from geonwm_stage1.models.triplane import TriplaneSpec


def _to_grid(v: torch.Tensor, vrange: tuple[float, float]) -> torch.Tensor:
    return 2.0 * (v - vrange[0]) / max(vrange[1] - vrange[0], 1e-6) - 1.0


class TriplaneSampler(nn.Module):
    def __init__(self, spec: TriplaneSpec, combine: str = "sum"):
        super().__init__()
        self.spec = spec
        self.combine = combine
        if combine == "concat":
            self.proj = nn.Linear(spec.channels * 3, spec.channels)
        else:
            self.proj = nn.Identity()

    def forward(self, planes: dict[str, torch.Tensor], points: torch.Tensor) -> torch.Tensor:
        b, n, _ = points.shape
        x = _to_grid(points[..., 0], self.spec.x_range)
        y = _to_grid(points[..., 1], self.spec.y_range)
        z = _to_grid(points[..., 2], self.spec.z_range)

        def sample(plane: torch.Tensor, grid_2: torch.Tensor) -> torch.Tensor:
            grid = grid_2.reshape(b, n, 1, 2)
            feat = F.grid_sample(plane, grid, align_corners=True, mode="bilinear", padding_mode="zeros")
            return feat.squeeze(-1).transpose(1, 2)

        f_xy = sample(planes["xy"], torch.stack([x, y], dim=-1))
        f_xz = sample(planes["xz"], torch.stack([x, z], dim=-1))
        f_yz = sample(planes["yz"], torch.stack([y, z], dim=-1))
        if self.combine == "concat":
            return self.proj(torch.cat([f_xy, f_xz, f_yz], dim=-1))
        return f_xy + f_xz + f_yz


class SampleTransformerBlock(nn.Module):
    def __init__(self, hidden_dim: int, attn_heads: int):
        super().__init__()
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.attn = EfficientSelfAttention(hidden_dim, attn_heads)
        self.norm2 = nn.LayerNorm(hidden_dim)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 4),
            nn.GELU(),
            nn.Linear(hidden_dim * 4, hidden_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, v, n, s, c = x.shape
        tokens = x.reshape(b * v * n, s, c)
        y = self.norm1(tokens)
        tokens = tokens + self.attn(y)
        tokens = tokens + self.mlp(self.norm2(tokens))
        return tokens.reshape(b, v, n, s, c)


class ViewFusionBlock(nn.Module):
    def __init__(self, hidden_dim: int, attn_heads: int):
        super().__init__()
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.attn = EfficientSelfAttention(hidden_dim, attn_heads)
        self.norm2 = nn.LayerNorm(hidden_dim)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 4),
            nn.GELU(),
            nn.Linear(hidden_dim * 4, hidden_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, v, n, c = x.shape
        tokens = x.permute(0, 2, 1, 3).reshape(b * n, v, c)
        y = self.norm1(tokens)
        tokens = tokens + self.attn(y)
        tokens = tokens + self.mlp(self.norm2(tokens))
        return tokens.reshape(b, n, v, c).permute(0, 2, 1, 3).contiguous()


class RayMultiTaskDecoder(nn.Module):
    """Full-resolution arbitrary-camera decoder with chunked multi-view ray queries."""

    def __init__(
        self,
        spec: TriplaneSpec,
        image_size: tuple[int, int],
        decode_stride: int,
        ray_samples: int,
        near: float,
        far: float,
        hidden_dim: int,
        num_semantic_classes: int,
        chunk_pixels: int = 1536,
        gradient_checkpoint_chunks: bool = True,
        sample_transformer_layers: int = 2,
        cross_view_layers: int = 4,
        attn_heads: int = 8,
    ):
        super().__init__()
        self.spec = spec
        self.image_size = image_size
        self.decode_stride = decode_stride
        self.decode_hw = (image_size[0] // decode_stride, image_size[1] // decode_stride)
        self.ray_samples = ray_samples
        self.near = near
        self.far = far
        self.chunk_pixels = chunk_pixels
        self.gradient_checkpoint_chunks = gradient_checkpoint_chunks
        self.sampler = TriplaneSampler(spec)
        c = spec.channels
        self.sample_input = nn.Linear(c, hidden_dim)
        self.sample_blocks = nn.ModuleList(
            [SampleTransformerBlock(hidden_dim, attn_heads) for _ in range(sample_transformer_layers)]
        )
        self.sample_refine = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.camera_embed = nn.Sequential(
            nn.Linear(21, hidden_dim),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.view_blocks = nn.ModuleList([ViewFusionBlock(hidden_dim, attn_heads) for _ in range(cross_view_layers)])
        self.sigma = nn.Linear(hidden_dim, 1)
        self.rgb_head = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.SiLU(inplace=True), nn.Linear(hidden_dim, 3))
        self.sem_head = nn.Linear(hidden_dim, num_semantic_classes)
        self.point_delta = nn.Linear(hidden_dim, 3)
        self.point_uncertainty = nn.Linear(hidden_dim, 1)

    def _make_rays(
        self,
        intrinsics: torch.Tensor,
        cam_to_lidar_rot: torch.Tensor,
        cam_to_lidar_trans: torch.Tensor,
        pixel_indices: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        b, v, _, _ = intrinsics.shape
        h, w = self.decode_hw
        device = intrinsics.device
        dtype = intrinsics.dtype
        ys = torch.div(pixel_indices, w, rounding_mode="floor").to(dtype=dtype)
        xs = (pixel_indices % w).to(dtype=dtype)
        pix_y = ys * (self.image_size[0] - 1) / max(h - 1, 1)
        pix_x = xs * (self.image_size[1] - 1) / max(w - 1, 1)
        pix = torch.stack([pix_x, pix_y, torch.ones_like(pix_x)], dim=-1).reshape(1, 1, -1, 3)
        k_inv = torch.inverse(intrinsics)
        dirs_cam = torch.einsum("bvij,bvnj->bvni", k_inv, pix.expand(b, v, -1, -1))
        dirs_lidar = torch.einsum("bvij,bvnj->bvni", cam_to_lidar_rot, dirs_cam)
        origins = cam_to_lidar_trans.unsqueeze(2).expand_as(dirs_lidar)
        return origins, dirs_lidar

    @staticmethod
    def _volume_weights(sigma: torch.Tensor, depths: torch.Tensor) -> torch.Tensor:
        deltas = torch.empty_like(depths)
        deltas[:-1] = depths[1:] - depths[:-1]
        deltas[-1] = deltas[-2] if depths.numel() > 1 else 1.0
        alpha = 1.0 - torch.exp(-F.softplus(sigma) * deltas.view(1, 1, 1, -1))
        trans = torch.cumprod(
            torch.cat([torch.ones_like(alpha[..., :1]), (1.0 - alpha + 1e-6)], dim=-1),
            dim=-1,
        )[..., :-1]
        weights = trans * alpha
        return weights / weights.sum(dim=-1, keepdim=True).clamp_min(1e-6)

    def _camera_tokens(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        intr = batch["intrinsics"].flatten(-2)
        rot = batch["cam_to_lidar_rot"].flatten(-2)
        trans = batch["cam_to_lidar_trans"]
        cam = torch.cat([intr, rot, trans], dim=-1)
        return self.camera_embed(cam)

    def _decode_chunk(
        self,
        planes: dict[str, torch.Tensor],
        batch: dict[str, torch.Tensor],
        pixel_slice: slice,
        camera_tokens: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        b, v = batch["intrinsics"].shape[:2]
        h, w = self.decode_hw
        sel = torch.arange(h * w, device=batch["intrinsics"].device)[pixel_slice]
        origins, dirs = self._make_rays(
            batch["intrinsics"],
            batch["cam_to_lidar_rot"],
            batch["cam_to_lidar_trans"],
            sel,
        )
        depths = torch.linspace(self.near, self.far, self.ray_samples, device=origins.device, dtype=origins.dtype)
        points = origins.unsqueeze(3) + dirs.unsqueeze(3) * depths.view(1, 1, 1, -1, 1)
        feat = self.sampler(planes, points.reshape(b, v * sel.numel() * self.ray_samples, 3))
        hidden = self.sample_input(feat).reshape(b, v, sel.numel(), self.ray_samples, -1)
        for block in self.sample_blocks:
            hidden = block(hidden)
        hidden = self.sample_refine(hidden)
        sigma = self.sigma(hidden).squeeze(-1)
        weights = self._volume_weights(sigma, depths)
        ray_feat = (weights.unsqueeze(-1) * hidden).sum(dim=3)
        expected_depth = (weights * depths.view(1, 1, 1, -1)).sum(dim=-1)
        expected_point = (weights.unsqueeze(-1) * points).sum(dim=3)
        ray_feat = ray_feat + camera_tokens[:, :, None, :]
        for block in self.view_blocks:
            ray_feat = block(ray_feat)
        rgb = torch.sigmoid(self.rgb_head(ray_feat)).reshape(b, v, sel.numel(), 3)
        sem = self.sem_head(ray_feat).reshape(b, v, sel.numel(), -1)
        point_delta = self.point_delta(ray_feat).reshape(b, v, sel.numel(), 3)
        pointmap = expected_point + 0.25 * torch.tanh(point_delta)
        uncertainty = F.softplus(self.point_uncertainty(ray_feat)).reshape(b, v, sel.numel())
        return {
            "rgb": rgb,
            "depth": expected_depth,
            "semantic": sem,
            "pointmap": pointmap,
            "point_uncertainty": uncertainty,
        }

    def forward(self, planes: dict[str, torch.Tensor], batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        h, w = self.decode_hw
        n_rays = h * w
        chunk = max(1, int(self.chunk_pixels))
        camera_tokens = self._camera_tokens(batch)
        rgb_chunks = []
        depth_chunks = []
        sem_chunks = []
        point_chunks = []
        unc_chunks = []
        for start in range(0, n_rays, chunk):
            stop = min(n_rays, start + chunk)
            if self.training and self.gradient_checkpoint_chunks:
                out_tuple = checkpoint(
                    self._decode_chunk_tuple,
                    planes["xy"],
                    planes["xz"],
                    planes["yz"],
                    batch["intrinsics"],
                    batch["cam_to_lidar_rot"],
                    batch["cam_to_lidar_trans"],
                    camera_tokens,
                    torch.tensor(start, device=camera_tokens.device),
                    torch.tensor(stop, device=camera_tokens.device),
                    use_reentrant=False,
                )
                out = {
                    "rgb": out_tuple[0],
                    "depth": out_tuple[1],
                    "semantic": out_tuple[2],
                    "pointmap": out_tuple[3],
                    "point_uncertainty": out_tuple[4],
                }
            else:
                out = self._decode_chunk(planes, batch, slice(start, stop), camera_tokens)
            rgb_chunks.append(out["rgb"])
            depth_chunks.append(out["depth"])
            sem_chunks.append(out["semantic"])
            point_chunks.append(out["pointmap"])
            unc_chunks.append(out["point_uncertainty"])
        rgb = torch.cat(rgb_chunks, dim=2).reshape(batch["intrinsics"].shape[0], batch["intrinsics"].shape[1], h, w, 3)
        depth = torch.cat(depth_chunks, dim=2).reshape(batch["intrinsics"].shape[0], batch["intrinsics"].shape[1], h, w)
        sem = torch.cat(sem_chunks, dim=2).reshape(batch["intrinsics"].shape[0], batch["intrinsics"].shape[1], h, w, -1)
        pointmap = torch.cat(point_chunks, dim=2).reshape(batch["intrinsics"].shape[0], batch["intrinsics"].shape[1], h, w, 3)
        uncertainty = torch.cat(unc_chunks, dim=2).reshape(batch["intrinsics"].shape[0], batch["intrinsics"].shape[1], h, w)
        rgb = rgb.permute(0, 1, 4, 2, 3)
        sem = sem.permute(0, 1, 4, 2, 3)
        return {
            "rgb": rgb,
            "depth": depth,
            "semantic": sem,
            "pointmap": pointmap,
            "point_uncertainty": uncertainty,
        }

    def _decode_chunk_tuple(
        self,
        xy: torch.Tensor,
        xz: torch.Tensor,
        yz: torch.Tensor,
        intrinsics: torch.Tensor,
        cam_to_lidar_rot: torch.Tensor,
        cam_to_lidar_trans: torch.Tensor,
        camera_tokens: torch.Tensor,
        start: torch.Tensor,
        stop: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        planes = {"xy": xy, "xz": xz, "yz": yz}
        batch = {
            "intrinsics": intrinsics,
            "cam_to_lidar_rot": cam_to_lidar_rot,
            "cam_to_lidar_trans": cam_to_lidar_trans,
        }
        out = self._decode_chunk(planes, batch, slice(int(start.item()), int(stop.item())), camera_tokens)
        return out["rgb"], out["depth"], out["semantic"], out["pointmap"], out["point_uncertainty"]


class OccupancyDecoder(nn.Module):
    def __init__(
        self,
        spec: TriplaneSpec,
        shape_zyx: tuple[int, int, int],
        hidden_dim: int,
        num_classes: int,
        chunk_points: int = 8192,
    ):
        super().__init__()
        self.spec = spec
        self.shape_zyx = shape_zyx
        self.chunk_points = chunk_points
        self.sampler = TriplaneSampler(spec)
        self.head = nn.Sequential(
            nn.Linear(spec.channels, hidden_dim),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, planes: dict[str, torch.Tensor]) -> torch.Tensor:
        b = planes["xy"].shape[0]
        centers = voxel_centers(
            self.shape_zyx,
            self.spec.x_range,
            self.spec.y_range,
            self.spec.z_range,
            planes["xy"].device,
            planes["xy"].dtype,
        )
        points = centers.reshape(1, -1, 3).expand(b, -1, -1)
        chunks = []
        for start in range(0, points.shape[1], self.chunk_points):
            stop = min(points.shape[1], start + self.chunk_points)
            feat = self.sampler(planes, points[:, start:stop])
            chunks.append(self.head(feat))
        logits = torch.cat(chunks, dim=1)
        z, y, x = self.shape_zyx
        return logits.reshape(b, z, y, x, -1).permute(0, 4, 1, 2, 3).contiguous()


class MultiTaskDecoder(nn.Module):
    def __init__(self, cfg: dict[str, Any], spec: TriplaneSpec):
        super().__init__()
        data_cfg = cfg["data"]
        dec_cfg = cfg["model"]["decoder"]
        occ_cfg = cfg["model"]["occupancy"]
        self.ray = RayMultiTaskDecoder(
            spec=spec,
            image_size=tuple(dec_cfg["image_size"]),
            decode_stride=int(dec_cfg["decode_stride"]),
            ray_samples=int(dec_cfg["ray_samples"]),
            near=float(dec_cfg["near"]),
            far=float(dec_cfg["far"]),
            hidden_dim=int(dec_cfg["hidden_dim"]),
            num_semantic_classes=int(data_cfg["num_semantic_classes"]),
            chunk_pixels=int(dec_cfg.get("chunk_pixels", 1536)),
            gradient_checkpoint_chunks=bool(dec_cfg.get("gradient_checkpoint_chunks", True)),
            sample_transformer_layers=int(dec_cfg.get("sample_transformer_layers", 2)),
            cross_view_layers=int(dec_cfg.get("cross_view_layers", 4)),
            attn_heads=int(dec_cfg.get("attn_heads", 8)),
        )
        self.occ = OccupancyDecoder(
            spec=spec,
            shape_zyx=tuple(occ_cfg["shape"]),
            hidden_dim=int(dec_cfg["hidden_dim"]),
            num_classes=int(data_cfg["num_occ_classes"]),
            chunk_points=int(occ_cfg.get("chunk_points", 8192)),
        )

    def forward(self, planes: dict[str, torch.Tensor], batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        out = self.ray(planes, batch)
        out["occ"] = self.occ(planes)
        return out
