"""Model components for GeoNWM Stage 1."""

