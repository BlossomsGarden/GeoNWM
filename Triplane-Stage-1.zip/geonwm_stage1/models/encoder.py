from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F


DINO_AUTO_CANDIDATES = (
    "vit_7b_patch16_dinov3",
    "vit_huge_plus_patch16_dinov3",
    "vit_large_patch16_dinov3",
    "vit_base_patch16_dinov3",
)


class DinoV3ImageEncoder(nn.Module):
    """DINOv3 patch features projected to the triplane channel width."""

    def __init__(
        self,
        model_name: str = "auto",
        pretrained: bool = True,
        pretrained_path: str | None = None,
        freeze: bool = False,
        out_channels: int = 256,
        normalize: bool = True,
        upsample_stride: int | None = None,
    ):
        super().__init__()
        try:
            import timm
        except ImportError as exc:
            raise ImportError("DinoV3ImageEncoder requires timm.") from exc

        resolved_name = self._resolve_model_name(timm, model_name, pretrained)
        checkpoint_path = self._resolve_checkpoint_path(pretrained_path)
        self.backbone = timm.create_model(
            resolved_name,
            pretrained=False,
            checkpoint_path=str(checkpoint_path),
            num_classes=0,
        )
        self.model_name = resolved_name
        self.pretrained_path = str(checkpoint_path)
        self.normalize = normalize
        self.upsample_stride = upsample_stride
        self.freeze = freeze

        in_channels = int(getattr(self.backbone, "num_features", getattr(self.backbone, "embed_dim", 0)))
        if in_channels <= 0:
            raise ValueError(f"Cannot infer feature dimension for DINOv3 model: {resolved_name}")

        patch_embed = getattr(self.backbone, "patch_embed", None)
        patch_size = getattr(patch_embed, "patch_size", (16, 16))
        if isinstance(patch_size, int):
            patch_size = (patch_size, patch_size)
        self.patch_size = tuple(int(x) for x in patch_size)
        self.num_prefix_tokens = int(getattr(self.backbone, "num_prefix_tokens", 0) or 0)
        if self.num_prefix_tokens <= 0:
            self.num_prefix_tokens = 1

        self.proj = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=min(32, out_channels), num_channels=out_channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=min(32, out_channels), num_channels=out_channels),
            nn.SiLU(inplace=True),
        )
        self.register_buffer(
            "image_mean",
            torch.tensor([0.485, 0.456, 0.406], dtype=torch.float32).view(1, 3, 1, 1),
            persistent=False,
        )
        self.register_buffer(
            "image_std",
            torch.tensor([0.229, 0.224, 0.225], dtype=torch.float32).view(1, 3, 1, 1),
            persistent=False,
        )
        if freeze:
            self.backbone.requires_grad_(False)
            self.backbone.eval()

    @staticmethod
    def _resolve_model_name(timm: Any, model_name: str, pretrained: bool) -> str:
        if model_name and model_name.lower() != "auto":
            return model_name
        available = set(timm.list_models("*dinov3*"))
        for candidate in DINO_AUTO_CANDIDATES:
            if candidate in available:
                return candidate
        if available:
            ranked = sorted(available, key=lambda x: ("large" not in x, "base" not in x, x))
            return ranked[0]
        # Let timm raise the real error in environments with older list_models behavior.
        return DINO_AUTO_CANDIDATES[0] if pretrained else DINO_AUTO_CANDIDATES[-1]

    @staticmethod
    def _resolve_checkpoint_path(pretrained_path: str | None) -> Path:
        if pretrained_path is None or not str(pretrained_path).strip():
            raise ValueError(
                "DINOv3 pretrained_path is required. Pass --dinov3-path or set "
                "model.image_encoder.pretrained_path to a local checkpoint path."
            )
        path = Path(pretrained_path).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"DINOv3 pretrained checkpoint path does not exist: {path}")
        if path.is_file():
            return path
        if not path.is_dir():
            raise FileNotFoundError(f"DINOv3 pretrained checkpoint path is neither a file nor a directory: {path}")

        preferred = [
            "model.safetensors",
            "pytorch_model.bin",
            "open_clip_pytorch_model.bin",
            "checkpoint.pth",
            "checkpoint.pt",
            "model.pth",
            "model.pt",
        ]
        for name in preferred:
            candidate = path / name
            if candidate.is_file():
                return candidate

        matches: list[Path] = []
        for pattern in ("*.safetensors", "*.bin", "*.pth", "*.pt"):
            matches.extend(sorted(path.glob(pattern)))
        if matches:
            return matches[0]
        raise FileNotFoundError(
            f"No DINOv3 checkpoint file found in {path}. Expected one of: {', '.join(preferred)}"
        )

    def train(self, mode: bool = True):
        super().train(mode)
        if self.freeze:
            self.backbone.eval()
        return self

    def _patch_grid(self, h: int, w: int) -> tuple[int, int]:
        ph, pw = self.patch_size
        if h % ph != 0 or w % pw != 0:
            raise ValueError(
                f"DINOv3 patch size {self.patch_size} requires image size divisible by the patch size; got {(h, w)}."
            )
        return h // ph, w // pw

    def _tokens_to_map(self, tokens: torch.Tensor, h: int, w: int) -> torch.Tensor:
        hp, wp = self._patch_grid(h, w)
        expected = hp * wp
        if tokens.ndim != 3:
            raise ValueError(f"Expected DINOv3 tokens [B,N,C], got {tuple(tokens.shape)}")
        if tokens.shape[1] == expected + self.num_prefix_tokens:
            tokens = tokens[:, self.num_prefix_tokens :]
        elif tokens.shape[1] > expected:
            tokens = tokens[:, -expected:]
        elif tokens.shape[1] != expected:
            raise ValueError(f"Cannot reshape {tokens.shape[1]} DINOv3 tokens to patch grid {(hp, wp)}")
        return tokens.reshape(tokens.shape[0], hp, wp, tokens.shape[2]).permute(0, 3, 1, 2).contiguous()

    def _forward_backbone(self, x: torch.Tensor) -> torch.Tensor:
        out = self.backbone.forward_features(x)
        if isinstance(out, dict):
            if "x_norm_patchtokens" in out:
                return out["x_norm_patchtokens"]
            for value in out.values():
                if torch.is_tensor(value) and value.ndim == 3:
                    return value
            raise ValueError(f"DINOv3 forward_features dict has no token tensor. Keys: {list(out.keys())}")
        if not torch.is_tensor(out):
            raise ValueError(f"Unsupported DINOv3 output type: {type(out)!r}")
        return out

    def forward(self, images: torch.Tensor) -> torch.Tensor:
        b, v, c, h, w = images.shape
        x = images.reshape(b * v, c, h, w)
        if self.normalize:
            x = (x - self.image_mean.to(dtype=x.dtype)) / self.image_std.to(dtype=x.dtype)
        with torch.set_grad_enabled(not self.freeze):
            tokens = self._forward_backbone(x)
        feat = self._tokens_to_map(tokens, h, w)
        feat = self.proj(feat)
        if self.upsample_stride is not None:
            feat = F.interpolate(
                feat,
                size=(h // int(self.upsample_stride), w // int(self.upsample_stride)),
                mode="bilinear",
                align_corners=False,
            )
        return feat.reshape(b, v, feat.shape[1], feat.shape[2], feat.shape[3])


def build_image_encoder(cfg: dict[str, Any]) -> nn.Module:
    enc_type = str(cfg.get("type", "dinov3")).lower()
    if enc_type not in {"dinov3", "dino_v3", "dino"}:
        raise ValueError(f"GeoNWM Phase1 only supports DINOv3 image_encoder.type, got: {enc_type}")
    return DinoV3ImageEncoder(
        model_name=str(cfg.get("model_name", "auto")),
        pretrained=bool(cfg.get("pretrained", True)),
        pretrained_path=cfg.get("pretrained_path", None),
        freeze=bool(cfg.get("freeze", False)),
        out_channels=int(cfg.get("out_channels", 256)),
        normalize=bool(cfg.get("normalize", True)),
        upsample_stride=cfg.get("upsample_stride", None),
    )
