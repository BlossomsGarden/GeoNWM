from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F

from geonwm_stage1.models.attention import EfficientSelfAttention


@dataclass(frozen=True)
class TriplaneSpec:
    channels: int
    xy_size: int
    z_size: int
    x_range: tuple[float, float]
    y_range: tuple[float, float]
    z_range: tuple[float, float]


def _range_mask(v: torch.Tensor, vrange: tuple[float, float]) -> torch.Tensor:
    return (v >= vrange[0]) & (v <= vrange[1])


def _coord_to_index(v: torch.Tensor, vrange: tuple[float, float], size: int) -> torch.Tensor:
    t = (v - vrange[0]) / max(vrange[1] - vrange[0], 1e-6)
    return (t * (size - 1)).round().long().clamp(0, size - 1)


class DepthGuidedTriplaneScatter(nn.Module):
    """Scatter dense image features into XY/XZ/YZ planes using dense point maps."""

    def __init__(self, spec: TriplaneSpec):
        super().__init__()
        self.spec = spec

    def _scatter_one(
        self,
        features: torch.Tensor,
        points: torch.Tensor,
        valid: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        c = features.shape[0]
        s = self.spec
        xy = features.new_zeros(c, s.xy_size * s.xy_size)
        xz = features.new_zeros(c, s.z_size * s.xy_size)
        yz = features.new_zeros(c, s.z_size * s.xy_size)
        xy_count = features.new_zeros(1, s.xy_size * s.xy_size)
        xz_count = features.new_zeros(1, s.z_size * s.xy_size)
        yz_count = features.new_zeros(1, s.z_size * s.xy_size)

        pts = points.reshape(-1, 3)
        feat = features.permute(1, 2, 0).reshape(-1, c)
        m = valid.reshape(-1)
        m = (
            m
            & _range_mask(pts[:, 0], s.x_range)
            & _range_mask(pts[:, 1], s.y_range)
            & _range_mask(pts[:, 2], s.z_range)
        )
        if not bool(m.any()):
            empty_xy = features.new_zeros(c, s.xy_size, s.xy_size)
            empty_xz = features.new_zeros(c, s.z_size, s.xy_size)
            empty_yz = features.new_zeros(c, s.z_size, s.xy_size)
            return empty_xy, empty_xz, empty_yz

        pts = pts[m]
        feat = feat[m]
        xi = _coord_to_index(pts[:, 0], s.x_range, s.xy_size)
        yi = _coord_to_index(pts[:, 1], s.y_range, s.xy_size)
        zi = _coord_to_index(pts[:, 2], s.z_range, s.z_size)

        xy_idx = yi * s.xy_size + xi
        xz_idx = zi * s.xy_size + xi
        yz_idx = zi * s.xy_size + yi
        xy.scatter_add_(1, xy_idx.unsqueeze(0).expand(c, -1), feat.T)
        xz.scatter_add_(1, xz_idx.unsqueeze(0).expand(c, -1), feat.T)
        yz.scatter_add_(1, yz_idx.unsqueeze(0).expand(c, -1), feat.T)
        ones = torch.ones(1, feat.shape[0], device=feat.device, dtype=feat.dtype)
        xy_count.scatter_add_(1, xy_idx.unsqueeze(0), ones)
        xz_count.scatter_add_(1, xz_idx.unsqueeze(0), ones)
        yz_count.scatter_add_(1, yz_idx.unsqueeze(0), ones)
        xy = xy / xy_count.clamp_min(1.0)
        xz = xz / xz_count.clamp_min(1.0)
        yz = yz / yz_count.clamp_min(1.0)
        return (
            xy.reshape(c, s.xy_size, s.xy_size),
            xz.reshape(c, s.z_size, s.xy_size),
            yz.reshape(c, s.z_size, s.xy_size),
        )

    def forward(
        self,
        features: torch.Tensor,
        pointmap: torch.Tensor,
        depth_mask: torch.Tensor,
        view_keep_mask: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        b, v, c, hf, wf = features.shape
        pm = F.interpolate(
            pointmap.flatten(0, 1).permute(0, 3, 1, 2),
            size=(hf, wf),
            mode="nearest",
        ).permute(0, 2, 3, 1).reshape(b, v, hf, wf, 3)
        dm = F.interpolate(
            depth_mask.float().flatten(0, 1).unsqueeze(1),
            size=(hf, wf),
            mode="nearest",
        ).reshape(b, v, hf, wf) > 0.5
        if view_keep_mask is None:
            view_keep_mask = torch.ones(b, v, device=features.device, dtype=torch.bool)

        xy_list, xz_list, yz_list = [], [], []
        for bi in range(b):
            feat_b = features[bi]
            pm_b = pm[bi]
            dm_b = dm[bi] & view_keep_mask[bi].view(v, 1, 1)
            feat_cat = feat_b.permute(1, 0, 2, 3).reshape(c, v * hf, wf)
            pm_cat = pm_b.reshape(v * hf, wf, 3)
            dm_cat = dm_b.reshape(v * hf, wf)
            xy, xz, yz = self._scatter_one(feat_cat, pm_cat, dm_cat)
            xy_list.append(xy)
            xz_list.append(xz)
            yz_list.append(yz)
        return {
            "xy": torch.stack(xy_list, dim=0),
            "xz": torch.stack(xz_list, dim=0),
            "yz": torch.stack(yz_list, dim=0),
        }


class PlaneBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(num_groups=min(32, channels), num_channels=channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(num_groups=min(32, channels), num_channels=channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.silu(x + self.net(x))


class TransformerBlock(nn.Module):
    def __init__(self, channels: int, heads: int = 8, mlp_ratio: float = 4.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(channels)
        self.attn = EfficientSelfAttention(channels, heads)
        self.norm2 = nn.LayerNorm(channels)
        hidden = int(channels * mlp_ratio)
        self.mlp = nn.Sequential(nn.Linear(channels, hidden), nn.GELU(), nn.Linear(hidden, channels))

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        x = self.norm1(tokens)
        tokens = tokens + self.attn(x)
        tokens = tokens + self.mlp(self.norm2(tokens))
        return tokens


class AxialPlaneTransformerBlock(nn.Module):
    def __init__(self, channels: int, heads: int = 8, mlp_ratio: float = 4.0):
        super().__init__()
        self.row = TransformerBlock(channels, heads, mlp_ratio)
        self.col = TransformerBlock(channels, heads, mlp_ratio)

    def forward(self, plane: torch.Tensor) -> torch.Tensor:
        b, c, h, w = plane.shape
        x = plane.permute(0, 2, 3, 1).reshape(b * h, w, c)
        x = self.row(x).reshape(b, h, w, c)
        x = x.permute(0, 2, 1, 3).reshape(b * w, h, c)
        x = self.col(x).reshape(b, w, h, c).permute(0, 3, 2, 1).contiguous()
        return x


class TriplaneRefiner(nn.Module):
    """Conv smoothing plus axial transformer refinement that remains feasible at R=200."""

    def __init__(self, spec: TriplaneSpec, layers: int = 4, heads: int = 8, mlp_ratio: float = 4.0):
        super().__init__()
        c = spec.channels
        self.pre_xy = PlaneBlock(c)
        self.pre_xz = PlaneBlock(c)
        self.pre_yz = PlaneBlock(c)
        self.blocks = nn.ModuleList([AxialPlaneTransformerBlock(c, heads, mlp_ratio) for _ in range(layers)])

    def forward(self, planes: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        xy = self.pre_xy(planes["xy"])
        xz = self.pre_xz(planes["xz"])
        yz = self.pre_yz(planes["yz"])
        for block in self.blocks:
            xy = block(xy)
            xz = block(xz)
            yz = block(yz)
        return {"xy": xy, "xz": xz, "yz": yz}
