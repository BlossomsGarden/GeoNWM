from __future__ import annotations

from typing import Any

import torch
from torch import nn
from torch.nn import functional as F


def masked_l1(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    mask_f = mask.float()
    return ((pred - target).abs() * mask_f).sum() / mask_f.sum().clamp_min(1.0)


def silog_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    pred = pred.clamp_min(1e-3)
    target = target.clamp_min(1e-3)
    diff = torch.log(pred) - torch.log(target)
    diff = diff[mask]
    if diff.numel() == 0:
        return pred.sum() * 0.0
    return torch.sqrt((diff**2).mean() - 0.85 * diff.mean() ** 2 + 1e-6)


def gradient_l1(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    dx_p = pred[..., :, 1:] - pred[..., :, :-1]
    dx_t = target[..., :, 1:] - target[..., :, :-1]
    mx = mask[..., :, 1:] & mask[..., :, :-1]
    dy_p = pred[..., 1:, :] - pred[..., :-1, :]
    dy_t = target[..., 1:, :] - target[..., :-1, :]
    my = mask[..., 1:, :] & mask[..., :-1, :]
    return masked_l1(dx_p, dx_t, mx) + masked_l1(dy_p, dy_t, my)


def point_gradient_l1(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    dx_p = pred[..., :, 1:, :] - pred[..., :, :-1, :]
    dx_t = target[..., :, 1:, :] - target[..., :, :-1, :]
    mx = mask[..., :, 1:] & mask[..., :, :-1]
    dy_p = pred[..., 1:, :, :] - pred[..., :-1, :, :]
    dy_t = target[..., 1:, :, :] - target[..., :-1, :, :]
    my = mask[..., 1:, :] & mask[..., :-1, :]
    return masked_l1(dx_p.norm(dim=-1), dx_t.norm(dim=-1), mx) + masked_l1(
        dy_p.norm(dim=-1), dy_t.norm(dim=-1), my
    )


def chamfer_loss(pred_points: torch.Tensor, lidar_points: list[torch.Tensor], max_points: int) -> torch.Tensor:
    losses = []
    b = pred_points.shape[0]
    pred_flat = pred_points.reshape(b, -1, 3)
    for i in range(b):
        p = pred_flat[i]
        q = lidar_points[i].to(p.device, dtype=p.dtype)
        if p.shape[0] > max_points:
            p = p[torch.linspace(0, p.shape[0] - 1, max_points, device=p.device).long()]
        if q.shape[0] > max_points:
            q = q[torch.linspace(0, q.shape[0] - 1, max_points, device=q.device).long()]
        if p.numel() == 0 or q.numel() == 0:
            losses.append(pred_flat[i].sum() * 0.0)
            continue
        d = torch.cdist(p.float(), q.float())
        losses.append(d.min(dim=1).values.mean() + d.min(dim=0).values.mean())
    return torch.stack(losses).mean()


def make_occ_dense(
    occ_sparse: list[torch.Tensor],
    source_shape_zyx: tuple[int, int, int],
    target_shape_zyx: tuple[int, int, int],
    device: torch.device,
    source_ranges_xyz: tuple[tuple[float, float], tuple[float, float], tuple[float, float]] | None = None,
    target_ranges_xyz: tuple[tuple[float, float], tuple[float, float], tuple[float, float]] | None = None,
) -> torch.Tensor:
    b = len(occ_sparse)
    sz, sy, sx = source_shape_zyx
    tz, ty, tx = target_shape_zyx
    dense = torch.zeros((b, tz, ty, tx), dtype=torch.long, device=device)
    for bi, arr in enumerate(occ_sparse):
        arr = arr.to(device=device, dtype=torch.long)
        if arr.numel() == 0:
            continue
        if source_ranges_xyz is None or target_ranges_xyz is None:
            x = (arr[:, 0].float() / max(sx - 1, 1) * (tx - 1)).round().long().clamp(0, tx - 1)
            y = (arr[:, 1].float() / max(sy - 1, 1) * (ty - 1)).round().long().clamp(0, ty - 1)
            z = (arr[:, 2].float() / max(sz - 1, 1) * (tz - 1)).round().long().clamp(0, tz - 1)
        else:
            src_x, src_y, src_z = source_ranges_xyz
            tgt_x, tgt_y, tgt_z = target_ranges_xyz
            x_coord = src_x[0] + arr[:, 0].float() / max(sx - 1, 1) * (src_x[1] - src_x[0])
            y_coord = src_y[0] + arr[:, 1].float() / max(sy - 1, 1) * (src_y[1] - src_y[0])
            z_coord = src_z[0] + arr[:, 2].float() / max(sz - 1, 1) * (src_z[1] - src_z[0])
            in_target = (
                (x_coord >= tgt_x[0])
                & (x_coord <= tgt_x[1])
                & (y_coord >= tgt_y[0])
                & (y_coord <= tgt_y[1])
                & (z_coord >= tgt_z[0])
                & (z_coord <= tgt_z[1])
            )
            if not bool(in_target.any()):
                continue
            arr = arr[in_target]
            x_coord = x_coord[in_target]
            y_coord = y_coord[in_target]
            z_coord = z_coord[in_target]
            x = ((x_coord - tgt_x[0]) / max(tgt_x[1] - tgt_x[0], 1e-6) * (tx - 1)).round().long().clamp(0, tx - 1)
            y = ((y_coord - tgt_y[0]) / max(tgt_y[1] - tgt_y[0], 1e-6) * (ty - 1)).round().long().clamp(0, ty - 1)
            z = ((z_coord - tgt_z[0]) / max(tgt_z[1] - tgt_z[0], 1e-6) * (tz - 1)).round().long().clamp(0, tz - 1)
        label = arr[:, 3].clamp_min(0)
        dense[bi, z, y, x] = label
    return dense


def occ_source_ranges_from_cfg(data_cfg: dict[str, Any]) -> tuple[tuple[float, float], tuple[float, float], tuple[float, float]]:
    ranges = data_cfg.get("occ_source_ranges") or data_cfg.get("occ_ranges") or data_cfg.get("occ_range")
    if isinstance(ranges, dict):
        return (
            tuple(float(x) for x in ranges.get("x", [-50.0, 50.0])),
            tuple(float(x) for x in ranges.get("y", [-50.0, 50.0])),
            tuple(float(x) for x in ranges.get("z", [-5.0, 3.0])),
        )
    if isinstance(ranges, (list, tuple)) and len(ranges) == 6:
        # Common pc_range order: [x_min, y_min, z_min, x_max, y_max, z_max].
        return ((float(ranges[0]), float(ranges[3])), (float(ranges[1]), float(ranges[4])), (float(ranges[2]), float(ranges[5])))
    return ((-50.0, 50.0), (-50.0, 50.0), (-5.0, 3.0))


def occ_target_ranges_from_cfg(cfg: dict[str, Any]) -> tuple[tuple[float, float], tuple[float, float], tuple[float, float]]:
    tp_cfg = cfg["model"]["triplane"]
    return (
        tuple(float(x) for x in tp_cfg["x_range"]),
        tuple(float(x) for x in tp_cfg["y_range"]),
        tuple(float(x) for x in tp_cfg["z_range"]),
    )


class UncertaintyWeighting(nn.Module):
    def __init__(self, names: list[str]):
        super().__init__()
        self.names = names
        self.log_vars = nn.ParameterDict({name: nn.Parameter(torch.zeros(())) for name in names})

    def forward(self, losses: dict[str, torch.Tensor]) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        total = None
        weighted = {}
        for name, loss in losses.items():
            if name in self.log_vars:
                lv = self.log_vars[name]
                value = torch.exp(-lv) * loss + lv
            else:
                value = loss
            weighted[name] = value
            total = value if total is None else total + value
        if total is None:
            raise ValueError("No losses supplied.")
        return total, weighted


class Stage1Loss(nn.Module):
    def __init__(self, cfg: dict[str, Any]):
        super().__init__()
        self.cfg = cfg
        data_cfg = cfg["data"]
        self.ignore_index = int(data_cfg.get("semantic_ignore_index", 255))
        self.source_occ_shape = tuple(data_cfg.get("occ_source_shape", [16, 200, 200]))
        self.source_occ_ranges = occ_source_ranges_from_cfg(data_cfg)
        self.target_occ_ranges = occ_target_ranges_from_cfg(cfg)
        self.loss_cfg = cfg["loss"]
        self.num_occ_classes = int(data_cfg.get("num_occ_classes", 17))
        names = ["rgb", "depth", "semantic", "point", "occ"]
        self.uncertainty = (
            UncertaintyWeighting(names) if bool(self.loss_cfg.get("uncertainty_weighting", True)) else None
        )

    @staticmethod
    def _resize_like(target: torch.Tensor, pred: torch.Tensor, mode: str = "bilinear") -> torch.Tensor:
        b, v = target.shape[:2]
        if target.dim() == 4:
            x = target.reshape(b * v, 1, target.shape[-2], target.shape[-1]).float()
            out = F.interpolate(x, size=pred.shape[-2:], mode=mode, align_corners=False if mode == "bilinear" else None)
            return out.reshape(b, v, pred.shape[-2], pred.shape[-1])
        if target.dim() == 5 and target.shape[-1] == 3:
            x = target.flatten(0, 1).permute(0, 3, 1, 2)
            out = F.interpolate(x, size=pred.shape[2:4], mode=mode, align_corners=False if mode == "bilinear" else None)
            return out.permute(0, 2, 3, 1).reshape(b, v, pred.shape[2], pred.shape[3], 3)
        raise ValueError(f"Unsupported resize target shape: {target.shape}")

    def forward(
        self,
        pred: dict[str, torch.Tensor],
        batch: dict[str, torch.Tensor],
        step: int,
        force_all: bool = False,
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        del step
        weights = self.loss_cfg
        losses: dict[str, torch.Tensor] = {}
        view_indices = pred.get("target_view_indices")
        if torch.is_tensor(view_indices):
            batch = dict(batch)
            for key in ["images", "depth", "depth_mask", "pointmap", "semantic"]:
                if key in batch and torch.is_tensor(batch[key]):
                    batch[key] = batch[key][:, view_indices]

        rgb_gt = batch["images"]
        losses["rgb"] = float(weights.get("rgb_l1", 1.0)) * F.l1_loss(pred["rgb"], rgb_gt)

        depth_gt = batch["depth"]
        depth_mask = batch["depth_mask"]
        l_depth = silog_loss(pred["depth"], depth_gt, depth_mask)
        l_depth = l_depth + float(weights.get("depth_grad", 0.1)) * gradient_l1(pred["depth"], depth_gt, depth_mask)
        losses["depth"] = float(weights.get("depth_silog", 0.5)) * l_depth

        sem_gt = batch["semantic"]
        losses["semantic"] = float(weights.get("semantic_ce", 1.0)) * F.cross_entropy(
            pred["semantic"].flatten(0, 1),
            sem_gt.flatten(0, 1),
            ignore_index=self.ignore_index,
        )

        pm_gt = batch["pointmap"]
        pm_mask = depth_mask
        point_error = (pred["pointmap"] - pm_gt).norm(dim=-1)
        point_l = masked_l1(point_error, torch.zeros_like(point_error), pm_mask)
        if "point_uncertainty" in pred:
            point_sigma = pred["point_uncertainty"].clamp_min(1e-6)
            point_l = point_l + float(weights.get("point_uncertainty_reg", 0.01)) * masked_l1(
                point_sigma,
                torch.ones_like(point_sigma),
                pm_mask,
            )
        point_l = point_l + float(weights.get("point_grad", 0.1)) * point_gradient_l1(
            pred["pointmap"], pm_gt, pm_mask
        )
        if force_all or float(weights.get("chamfer", 0.0)) > 0:
            point_l = point_l + float(weights.get("chamfer", 0.05)) * chamfer_loss(
                pred["pointmap"], batch["lidar_points"], int(weights.get("max_chamfer_points", 1024))
            )
        losses["point"] = float(weights.get("point_l2", 1.0)) * point_l

        occ_gt = make_occ_dense(
            batch["occ_sparse"],
            source_shape_zyx=self.source_occ_shape,
            target_shape_zyx=tuple(pred["occ"].shape[-3:]),
            device=pred["occ"].device,
            source_ranges_xyz=self.source_occ_ranges,
            target_ranges_xyz=self.target_occ_ranges,
        )
        occ_weight = None
        if "occ_empty_weight" in weights or "occ_occupied_weight" in weights or "occ_class_weights" in weights:
            occ_weight = pred["occ"].new_full((self.num_occ_classes,), float(weights.get("occ_occupied_weight", 1.0)))
            occ_weight[0] = float(weights.get("occ_empty_weight", 0.1))
            class_weights = weights.get("occ_class_weights")
            if isinstance(class_weights, dict):
                for key, value in class_weights.items():
                    idx = int(key)
                    if 0 <= idx < self.num_occ_classes:
                        occ_weight[idx] = float(value)
            elif isinstance(class_weights, (list, tuple)):
                for idx, value in enumerate(class_weights[: self.num_occ_classes]):
                    occ_weight[idx] = float(value)
        losses["occ"] = float(weights.get("occ_ce", 0.5)) * F.cross_entropy(pred["occ"], occ_gt, weight=occ_weight)

        if self.uncertainty is not None:
            total, weighted = self.uncertainty(losses)
            log_losses = {f"raw_{k}": v.detach() for k, v in losses.items()}
            log_losses.update({k: v.detach() for k, v in weighted.items()})
            log_losses["total"] = total.detach()
            return total, log_losses

        total = sum(losses.values())
        log_losses = {k: v.detach() for k, v in losses.items()}
        log_losses["total"] = total.detach()
        return total, log_losses
