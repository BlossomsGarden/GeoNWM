"""Losses for GeoNWM Stage 1."""

