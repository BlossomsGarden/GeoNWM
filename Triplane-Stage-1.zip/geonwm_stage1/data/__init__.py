"""Data loading utilities for GeoNWM Stage 1."""

