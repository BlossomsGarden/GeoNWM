from __future__ import annotations

import argparse
import json

import torch
from torch.utils.data import DataLoader

from geonwm_stage1.data.nuscenes_stage1 import NuScenesStage1Dataset, collate_stage1
from geonwm_stage1.losses.stage1_losses import Stage1Loss
from geonwm_stage1.models.stage1 import GeoNWMStage1
from geonwm_stage1.utils.config import load_config
from geonwm_stage1.utils.runtime import seed_everything, to_device


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Sanity-check real Stage1 data.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--num-samples", type=int, default=2)
    parser.add_argument("--split", choices=["train", "val"], default="train")
    parser.add_argument("--forward", action="store_true")
    return parser.parse_args()


def shape_of(x):
    if torch.is_tensor(x):
        return list(x.shape)
    if isinstance(x, list):
        return [shape_of(v) for v in x[:2]]
    return str(type(x))


def main() -> None:
    args = parse_args()
    cfg = load_config(args.config)
    seed_everything(int(cfg.get("seed", 2026)))
    ds = NuScenesStage1Dataset(cfg, split=args.split, limit_samples=args.num_samples)
    print(f"dataset split={args.split} len={len(ds)}")
    for i in range(min(args.num_samples, len(ds))):
        sample = ds[i]
        summary = {
            "idx": i,
            "token": sample["token"],
            "images": list(sample["images"].shape),
            "depth": list(sample["depth"].shape),
            "depth_valid_ratio": float(sample["depth_mask"].float().mean()),
            "pointmap": list(sample["pointmap"].shape),
            "semantic_valid_pixels": int((sample["semantic"] != cfg["data"]["semantic_ignore_index"]).sum()),
            "lidar_points": list(sample["lidar_points"].shape),
            "occ_sparse": list(sample["occ_sparse"].shape),
            "first_image": sample["image_paths"][0],
        }
        print(json.dumps(summary, ensure_ascii=False, indent=2))

    if args.forward:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        loader = DataLoader(ds, batch_size=1, collate_fn=collate_stage1, num_workers=0)
        batch = to_device(next(iter(loader)), device)
        model = GeoNWMStage1(cfg).to(device)
        criterion = Stage1Loss(cfg).to(device)
        model.train()
        with torch.no_grad():
            pred = model(batch)
            loss, logs = criterion(pred, batch, step=0, force_all=True)
        out = {
            "device": str(device),
            "pred_shapes": {k: shape_of(v) for k, v in pred.items() if k != "planes"},
            "plane_shapes": {k: list(v.shape) for k, v in pred["planes"].items()},
            "losses": {k: float(v.detach().cpu()) for k, v in logs.items()},
            "total": float(loss.detach().cpu()),
        }
        print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

