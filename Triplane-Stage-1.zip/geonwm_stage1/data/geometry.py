from __future__ import annotations

import math

import torch


def scale_intrinsics(
    k: torch.Tensor,
    src_hw: tuple[int, int],
    dst_hw: tuple[int, int],
) -> torch.Tensor:
    """Scale a 3x3 camera matrix from source H,W to target H,W."""
    src_h, src_w = src_hw
    dst_h, dst_w = dst_hw
    out = k.clone()
    out[0, :] *= float(dst_w) / float(src_w)
    out[1, :] *= float(dst_h) / float(src_h)
    return out


def resize_crop_intrinsics(
    k: torch.Tensor,
    src_hw: tuple[int, int],
    dst_hw: tuple[int, int],
) -> torch.Tensor:
    """Match the MoGe-2 preprocessing used for 256x704 nuScenes depth.

    The image is scaled isotropically to the target width, then a top crop is
    applied to reach the target height. For 1600x900 -> 704x256 this is:
    scale=0.44, resized=704x396, crop_top=140.
    """
    src_h, src_w = src_hw
    dst_h, dst_w = dst_hw
    scale = float(dst_w) / float(src_w)
    resized_h = int(round(float(src_h) * scale))
    crop_top = max(0, resized_h - dst_h)
    out = k.clone()
    out[0, :] *= scale
    out[1, :] *= scale
    out[1, 2] -= float(crop_top)
    return out


def invert_rigid(rot: torch.Tensor, trans: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Invert x_to_y transform: y = R x + t."""
    rinv = rot.transpose(-1, -2)
    tinv = -(rinv @ trans.unsqueeze(-1)).squeeze(-1)
    return rinv, tinv


def depth_to_points_camera(depth: torch.Tensor, intrinsics: torch.Tensor) -> torch.Tensor:
    """Convert depth to camera-frame points.

    Args:
        depth: [H, W]
        intrinsics: [3, 3]

    Returns:
        [H, W, 3] camera-frame xyz.
    """
    h, w = depth.shape
    device = depth.device
    dtype = depth.dtype
    ys, xs = torch.meshgrid(
        torch.arange(h, device=device, dtype=dtype),
        torch.arange(w, device=device, dtype=dtype),
        indexing="ij",
    )
    fx = intrinsics[0, 0].clamp_min(1e-6)
    fy = intrinsics[1, 1].clamp_min(1e-6)
    cx = intrinsics[0, 2]
    cy = intrinsics[1, 2]
    x = (xs - cx) / fx * depth
    y = (ys - cy) / fy * depth
    z = depth
    return torch.stack([x, y, z], dim=-1)


def transform_points(points: torch.Tensor, rot: torch.Tensor, trans: torch.Tensor) -> torch.Tensor:
    """Apply y = R x + t to points with trailing xyz dimension."""
    return torch.einsum("...j,ij->...i", points, rot) + trans


def project_lidar_to_image(
    points_lidar: torch.Tensor,
    labels: torch.Tensor | None,
    lidar_to_cam_rot: torch.Tensor,
    lidar_to_cam_trans: torch.Tensor,
    intrinsics: torch.Tensor,
    image_hw: tuple[int, int],
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Project LiDAR points into one image.

    Returns:
        pixels [N, 2] in x,y order, depth [N], labels_out [N] or empty.
    """
    pts_cam = transform_points(points_lidar, lidar_to_cam_rot, lidar_to_cam_trans)
    z = pts_cam[:, 2]
    valid = z > 1e-3
    pts_cam = pts_cam[valid]
    z = z[valid]
    if labels is not None:
        labels = labels[valid]

    uvw = pts_cam @ intrinsics.T
    uv = uvw[:, :2] / uvw[:, 2:3].clamp_min(1e-6)
    h, w = image_hw
    in_img = (uv[:, 0] >= 0) & (uv[:, 0] < w) & (uv[:, 1] >= 0) & (uv[:, 1] < h)
    uv = uv[in_img]
    z = z[in_img]
    if labels is None:
        labels_out = torch.empty((0,), dtype=torch.long, device=points_lidar.device)
    else:
        labels_out = labels[in_img].long()
    return uv, z, labels_out


def rasterize_sparse_labels(
    pixels_xy: torch.Tensor,
    depth: torch.Tensor,
    labels: torch.Tensor,
    image_hw: tuple[int, int],
    ignore_index: int = 255,
) -> torch.Tensor:
    """Rasterize projected sparse labels with a z-buffer."""
    h, w = image_hw
    target = torch.full((h, w), ignore_index, dtype=torch.long, device=pixels_xy.device)
    if pixels_xy.numel() == 0:
        return target
    x = pixels_xy[:, 0].round().long().clamp(0, w - 1)
    y = pixels_xy[:, 1].round().long().clamp(0, h - 1)
    flat = y * w + x
    order = torch.argsort(depth, descending=True)
    # Far points first, near points overwrite.
    target.view(-1)[flat[order]] = labels[order]
    return target


def voxel_centers(
    shape_zyx: tuple[int, int, int],
    x_range: tuple[float, float],
    y_range: tuple[float, float],
    z_range: tuple[float, float],
    device: torch.device,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    z, y, x = shape_zyx
    xs = torch.linspace(x_range[0], x_range[1], x, device=device, dtype=dtype)
    ys = torch.linspace(y_range[0], y_range[1], y, device=device, dtype=dtype)
    zs = torch.linspace(z_range[0], z_range[1], z, device=device, dtype=dtype)
    zz, yy, xx = torch.meshgrid(zs, ys, xs, indexing="ij")
    return torch.stack([xx, yy, zz], dim=-1)


def normalize_coords(
    points: torch.Tensor,
    x_range: tuple[float, float],
    y_range: tuple[float, float],
    z_range: tuple[float, float],
) -> torch.Tensor:
    x = (points[..., 0] - x_range[0]) / max(x_range[1] - x_range[0], 1e-6)
    y = (points[..., 1] - y_range[0]) / max(y_range[1] - y_range[0], 1e-6)
    z = (points[..., 2] - z_range[0]) / max(z_range[1] - z_range[0], 1e-6)
    return torch.stack([x, y, z], dim=-1)


def sinusoidal_encoding(x: torch.Tensor, num_freqs: int = 6) -> torch.Tensor:
    freqs = (2 ** torch.arange(num_freqs, device=x.device, dtype=x.dtype)) * math.pi
    xb = x.unsqueeze(-1) * freqs
    enc = torch.cat([torch.sin(xb), torch.cos(xb)], dim=-1)
    return enc.flatten(-2)
