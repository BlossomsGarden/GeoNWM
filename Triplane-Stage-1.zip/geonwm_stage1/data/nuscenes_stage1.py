from __future__ import annotations

import os
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF

from geonwm_stage1.data.geometry import (
    depth_to_points_camera,
    invert_rigid,
    project_lidar_to_image,
    rasterize_sparse_labels,
    resize_crop_intrinsics,
    scale_intrinsics,
    transform_points,
)


def resolve_nuscenes_path(path: str, nuscenes_root: str) -> str:
    if os.path.isabs(path):
        return path
    prefix = "./data/nuscenes/"
    if path.startswith(prefix):
        return os.path.join(nuscenes_root, path[len(prefix) :])
    return os.path.join(nuscenes_root, path)


def resolve_occ_path(path: str, surroundocc_root: str) -> str:
    if os.path.isabs(path):
        return path
    prefix = "./data/nuscenes_occ/"
    if path.startswith(prefix):
        return os.path.join(surroundocc_root, "nuscenes_occ", path[len(prefix) :])
    return os.path.join(surroundocc_root, path)


def resolve_lidarseg_path(path: str | None, nuscenes_root: str) -> str | None:
    if not path:
        return None
    if os.path.isabs(path):
        return path
    if "/" not in path:
        return os.path.join(nuscenes_root, "lidarseg", "v1.0-trainval", path)
    return os.path.join(nuscenes_root, path)


class NuScenesStage1Dataset(Dataset):
    """Stage-1 dataset indexed by SurroundOcc infos.

    Returned tensor shapes:
        images: [V, 3, H, W]
        depth: [V, H, W]
        pointmap: [V, H, W, 3], LiDAR/ego frame
        semantic: [V, H, W], sparse lidarseg labels with ignore index
        occ_sparse: [N, 4], x,y,z,label from SurroundOcc
        lidar_points: [N, 3], LiDAR frame
    """

    def __init__(self, cfg: dict[str, Any], split: str = "train", limit_samples: int | None = None):
        self.cfg = cfg
        self.split = split
        paths = cfg["paths"]
        data = cfg["data"]
        self.nuscenes_root = paths["nuscenes_root"]
        self.surroundocc_root = paths["surroundocc_root"]
        self.depth_root = paths["depth_root"]
        self.depth_kind = data.get("depth_kind", "align_depth")
        self.cameras = data["cameras"]
        self.image_hw = tuple(data["image_size"])
        self.image_transform = data.get("image_transform", "resize_crop")
        self.min_depth = float(data.get("min_depth", 0.1))
        self.max_depth = float(data.get("max_depth", 80.0))
        self.ignore_index = int(data.get("semantic_ignore_index", 255))
        self.load_lidarseg = bool(data.get("load_lidarseg", True))
        self.lidar_points_max = int(data.get("lidar_points_max", 20000))

        info_path = data["train_info"] if split == "train" else data["val_info"]
        with open(info_path, "rb") as f:
            obj = pickle.load(f)
        infos = obj["infos"] if isinstance(obj, dict) and "infos" in obj else obj
        if limit_samples is not None:
            infos = infos[: int(limit_samples)]
        self.infos = infos

    def __len__(self) -> int:
        return len(self.infos)

    def _preprocess_image(self, img: Image.Image) -> Image.Image:
        dst_h, dst_w = self.image_hw
        src_w, src_h = img.size
        if self.image_transform == "resize":
            return img.resize((dst_w, dst_h), Image.BILINEAR)
        if self.image_transform != "resize_crop":
            raise ValueError(f"Unsupported image_transform: {self.image_transform}")
        scale = float(dst_w) / float(src_w)
        resized_h = int(round(float(src_h) * scale))
        resized = img.resize((dst_w, resized_h), Image.BILINEAR)
        crop_top = max(0, resized_h - dst_h)
        cropped = resized.crop((0, crop_top, dst_w, min(crop_top + dst_h, resized_h)))
        if cropped.size != (dst_w, dst_h):
            canvas = Image.new("RGB", (dst_w, dst_h))
            canvas.paste(cropped, (0, 0))
            cropped = canvas
        return cropped

    def _transform_intrinsics(self, k: torch.Tensor, src_hw: tuple[int, int]) -> torch.Tensor:
        if self.image_transform == "resize":
            return scale_intrinsics(k, src_hw=src_hw, dst_hw=self.image_hw)
        if self.image_transform == "resize_crop":
            return resize_crop_intrinsics(k, src_hw=src_hw, dst_hw=self.image_hw)
        raise ValueError(f"Unsupported image_transform: {self.image_transform}")

    def _load_image(self, path: str) -> tuple[torch.Tensor, tuple[int, int]]:
        with Image.open(path) as img:
            img = img.convert("RGB")
            src_w, src_h = img.size
            img = self._preprocess_image(img)
        return TF.to_tensor(img), (src_h, src_w)

    def _load_depth(self, image_path: str, cam: str) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor | None]:
        stem = Path(image_path).stem + ".npz"
        path = os.path.join(self.depth_root, self.depth_kind, cam, stem)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Missing MoGe depth: {path}")
        z = np.load(path)
        depth = torch.from_numpy(z["depth"].astype(np.float32))
        mask = torch.from_numpy(z["mask"].astype(np.bool_))
        intrinsics = torch.from_numpy(z["intrinsics"].astype(np.float32)) if "intrinsics" in z.files else None
        depth = torch.nan_to_num(depth, nan=0.0, posinf=0.0, neginf=0.0)
        valid = mask & torch.isfinite(depth) & (depth >= self.min_depth) & (depth <= self.max_depth)
        depth = depth.clamp(0.0, self.max_depth)
        return depth, valid, intrinsics

    def _load_lidar(self, info: dict[str, Any]) -> torch.Tensor:
        path = resolve_nuscenes_path(info["lidar_path"], self.nuscenes_root)
        arr = np.fromfile(path, dtype=np.float32)
        if arr.size % 5 == 0:
            arr = arr.reshape(-1, 5)[:, :3]
        elif arr.size % 4 == 0:
            arr = arr.reshape(-1, 4)[:, :3]
        else:
            raise ValueError(f"Unexpected lidar file shape: {path}, floats={arr.size}")
        pts = torch.from_numpy(arr.astype(np.float32))
        if self.lidar_points_max > 0 and pts.shape[0] > self.lidar_points_max:
            idx = torch.linspace(0, pts.shape[0] - 1, self.lidar_points_max).long()
            pts = pts[idx]
        return pts

    def _load_lidarseg(self, info: dict[str, Any], n_points_full: int) -> torch.Tensor | None:
        if not self.load_lidarseg:
            return None
        path = resolve_lidarseg_path(info.get("lidarseg"), self.nuscenes_root)
        if path is None or not os.path.exists(path):
            return None
        labels = np.fromfile(path, dtype=np.uint8).astype(np.int64)
        if labels.shape[0] != n_points_full:
            return None
        labels_t = torch.from_numpy(labels)
        if self.lidar_points_max > 0 and labels_t.shape[0] > self.lidar_points_max:
            idx = torch.linspace(0, labels_t.shape[0] - 1, self.lidar_points_max).long()
            labels_t = labels_t[idx]
        return labels_t

    def _load_occ(self, info: dict[str, Any]) -> torch.Tensor:
        path = resolve_occ_path(info["occ_path"], self.surroundocc_root)
        arr = np.load(path)
        return torch.from_numpy(arr.astype(np.int64))

    def __getitem__(self, index: int) -> dict[str, Any]:
        info = self.infos[index]
        images: list[torch.Tensor] = []
        depths: list[torch.Tensor] = []
        depth_masks: list[torch.Tensor] = []
        pointmaps: list[torch.Tensor] = []
        semantics: list[torch.Tensor] = []
        intrinsics: list[torch.Tensor] = []
        cam_to_lidar_rots: list[torch.Tensor] = []
        cam_to_lidar_trans: list[torch.Tensor] = []
        lidar_to_cam_rots: list[torch.Tensor] = []
        lidar_to_cam_trans: list[torch.Tensor] = []
        image_paths: list[str] = []

        lidar_path = resolve_nuscenes_path(info["lidar_path"], self.nuscenes_root)
        raw = np.fromfile(lidar_path, dtype=np.float32)
        n_points_full = raw.size // (5 if raw.size % 5 == 0 else 4)
        lidar_points = self._load_lidar(info)
        lidar_labels = self._load_lidarseg(info, n_points_full)

        for cam in self.cameras:
            cam_info = info["cams"][cam]
            img_path = resolve_nuscenes_path(cam_info["data_path"], self.nuscenes_root)
            image, src_hw = self._load_image(img_path)
            depth, depth_valid, depth_k = self._load_depth(img_path, cam)
            k = torch.as_tensor(cam_info["cam_intrinsic"], dtype=torch.float32)
            k = depth_k if depth_k is not None else self._transform_intrinsics(k, src_hw)

            cam_to_lidar_r = torch.as_tensor(cam_info["sensor2lidar_rotation"], dtype=torch.float32)
            cam_to_lidar_t = torch.as_tensor(cam_info["sensor2lidar_translation"], dtype=torch.float32)
            lidar_to_cam_r, lidar_to_cam_t = invert_rigid(cam_to_lidar_r, cam_to_lidar_t)

            points_cam = depth_to_points_camera(depth, k)
            points_lidar = transform_points(points_cam, cam_to_lidar_r, cam_to_lidar_t)
            points_lidar = torch.where(depth_valid[..., None], points_lidar, torch.zeros_like(points_lidar))

            if lidar_labels is None:
                sem = torch.full(self.image_hw, self.ignore_index, dtype=torch.long)
            else:
                pix, z, lab = project_lidar_to_image(
                    lidar_points,
                    lidar_labels,
                    lidar_to_cam_r,
                    lidar_to_cam_t,
                    k,
                    self.image_hw,
                )
                sem = rasterize_sparse_labels(pix, z, lab, self.image_hw, self.ignore_index)

            images.append(image)
            depths.append(depth)
            depth_masks.append(depth_valid)
            pointmaps.append(points_lidar)
            semantics.append(sem)
            intrinsics.append(k)
            cam_to_lidar_rots.append(cam_to_lidar_r)
            cam_to_lidar_trans.append(cam_to_lidar_t)
            lidar_to_cam_rots.append(lidar_to_cam_r)
            lidar_to_cam_trans.append(lidar_to_cam_t)
            image_paths.append(img_path)

        return {
            "token": info["token"],
            "images": torch.stack(images, dim=0),
            "depth": torch.stack(depths, dim=0),
            "depth_mask": torch.stack(depth_masks, dim=0),
            "pointmap": torch.stack(pointmaps, dim=0),
            "semantic": torch.stack(semantics, dim=0),
            "intrinsics": torch.stack(intrinsics, dim=0),
            "cam_to_lidar_rot": torch.stack(cam_to_lidar_rots, dim=0),
            "cam_to_lidar_trans": torch.stack(cam_to_lidar_trans, dim=0),
            "lidar_to_cam_rot": torch.stack(lidar_to_cam_rots, dim=0),
            "lidar_to_cam_trans": torch.stack(lidar_to_cam_trans, dim=0),
            "lidar_points": lidar_points,
            "occ_sparse": self._load_occ(info),
            "image_paths": image_paths,
        }


def collate_stage1(batch: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    tensor_stack_keys = [
        "images",
        "depth",
        "depth_mask",
        "pointmap",
        "semantic",
        "intrinsics",
        "cam_to_lidar_rot",
        "cam_to_lidar_trans",
        "lidar_to_cam_rot",
        "lidar_to_cam_trans",
    ]
    for key in tensor_stack_keys:
        out[key] = torch.stack([b[key] for b in batch], dim=0)
    out["token"] = [b["token"] for b in batch]
    out["image_paths"] = [b["image_paths"] for b in batch]
    out["lidar_points"] = [b["lidar_points"] for b in batch]
    out["occ_sparse"] = [b["occ_sparse"] for b in batch]
    return out
