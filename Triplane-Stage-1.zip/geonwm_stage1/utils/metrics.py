from __future__ import annotations

import math
from typing import Any

import torch
from torch.nn import functional as F

from geonwm_stage1.losses.stage1_losses import (
    chamfer_loss,
    make_occ_dense,
    occ_source_ranges_from_cfg,
    occ_target_ranges_from_cfg,
)


def _resize_scalar(target: torch.Tensor, hw: tuple[int, int], mode: str) -> torch.Tensor:
    b, v = target.shape[:2]
    x = target.reshape(b * v, 1, target.shape[-2], target.shape[-1]).float()
    if mode == "nearest":
        out = F.interpolate(x, size=hw, mode=mode)
    else:
        out = F.interpolate(x, size=hw, mode=mode, align_corners=False)
    return out.reshape(b, v, hw[0], hw[1])


def _resize_rgb(target: torch.Tensor, hw: tuple[int, int]) -> torch.Tensor:
    b, v = target.shape[:2]
    out = F.interpolate(target.flatten(0, 1), size=hw, mode="bilinear", align_corners=False)
    return out.reshape(b, v, 3, hw[0], hw[1])


def _resize_pointmap(target: torch.Tensor, hw: tuple[int, int]) -> torch.Tensor:
    b, v = target.shape[:2]
    x = target.flatten(0, 1).permute(0, 3, 1, 2)
    out = F.interpolate(x, size=hw, mode="nearest")
    return out.permute(0, 2, 3, 1).reshape(b, v, hw[0], hw[1], 3)


def confusion_matrix(pred: torch.Tensor, target: torch.Tensor, num_classes: int, ignore_index: int) -> torch.Tensor:
    pred = pred.reshape(-1).long()
    target = target.reshape(-1).long()
    valid = (target != ignore_index) & (target >= 0) & (target < num_classes)
    pred = pred[valid].clamp(0, num_classes - 1)
    target = target[valid]
    idx = target * num_classes + pred
    cm = torch.bincount(idx, minlength=num_classes * num_classes)
    return cm.reshape(num_classes, num_classes).double()


def miou_from_confusion(cm: torch.Tensor, ignore_classes: tuple[int, ...] = ()) -> float:
    cm = cm.double()
    tp = torch.diag(cm)
    denom = cm.sum(dim=1) + cm.sum(dim=0) - tp
    valid = denom > 0
    if ignore_classes:
        ignore = torch.zeros_like(valid)
        for cls in ignore_classes:
            if 0 <= cls < valid.numel():
                ignore[cls] = True
        valid = valid & (~ignore)
    if not bool(valid.any()):
        return float("nan")
    return float((tp[valid] / denom[valid].clamp_min(1.0)).mean().item())


def histogram_from_confusion(cm: torch.Tensor, kind: str) -> dict[str, float]:
    if kind == "target":
        values = cm.sum(dim=1).double()
    elif kind == "pred":
        values = cm.sum(dim=0).double()
    else:
        raise ValueError(f"Unsupported histogram kind: {kind}")
    total = values.sum().clamp_min(1.0)
    return {str(i): float((values[i] / total).item()) for i in range(values.numel()) if values[i] > 0}


class Stage1MetricAccumulator:
    def __init__(self, cfg: dict[str, Any], compute_chamfer: bool = False):
        self.cfg = cfg
        data_cfg = cfg["data"]
        self.ignore_index = int(data_cfg.get("semantic_ignore_index", 255))
        self.num_semantic = int(data_cfg.get("num_semantic_classes", 32))
        self.num_occ = int(data_cfg.get("num_occ_classes", 17))
        self.occ_source_shape = tuple(data_cfg.get("occ_source_shape", [16, 200, 200]))
        self.occ_source_ranges = occ_source_ranges_from_cfg(data_cfg)
        self.occ_target_ranges = occ_target_ranges_from_cfg(cfg)
        self.compute_chamfer = compute_chamfer
        self.max_chamfer_points = int(cfg.get("loss", {}).get("max_chamfer_points", 1024))
        self.scalars: dict[str, float] = {}
        self.counts: dict[str, float] = {}
        self.sem_cm = torch.zeros(self.num_semantic, self.num_semantic, dtype=torch.double)
        self.occ_cm = torch.zeros(self.num_occ, self.num_occ, dtype=torch.double)

    def _add(self, name: str, value: torch.Tensor | float, count: torch.Tensor | float) -> None:
        val = float(value.detach().cpu().item()) if torch.is_tensor(value) else float(value)
        cnt = float(count.detach().cpu().item()) if torch.is_tensor(count) else float(count)
        if cnt <= 0:
            return
        self.scalars[name] = self.scalars.get(name, 0.0) + val
        self.counts[name] = self.counts.get(name, 0.0) + cnt

    def update(self, pred: dict[str, torch.Tensor], batch: dict[str, Any]) -> None:
        view_indices = pred.get("target_view_indices")
        if torch.is_tensor(view_indices):
            batch = dict(batch)
            for key in ["images", "depth", "depth_mask", "pointmap", "semantic"]:
                if key in batch and torch.is_tensor(batch[key]):
                    batch[key] = batch[key][:, view_indices]
        rgb_hw = tuple(pred["rgb"].shape[-2:])
        rgb_gt = _resize_rgb(batch["images"], rgb_hw)
        rgb_err = (pred["rgb"] - rgb_gt).float()
        self._add("rgb_sse", (rgb_err**2).sum(), rgb_err.numel())
        self._add("rgb_l1", rgb_err.abs().sum(), rgb_err.numel())

        depth_hw = tuple(pred["depth"].shape[-2:])
        depth_gt = _resize_scalar(batch["depth"], depth_hw, mode="bilinear").clamp_min(1e-3)
        depth_mask = _resize_scalar(batch["depth_mask"].float(), depth_hw, mode="nearest") > 0.5
        depth_pred = pred["depth"].float().clamp_min(1e-3)
        if bool(depth_mask.any()):
            diff = depth_pred - depth_gt
            ratio = torch.maximum(depth_pred / depth_gt, depth_gt / depth_pred)
            self._add("depth_absrel", (diff.abs() / depth_gt)[depth_mask].sum(), depth_mask.sum())
            self._add("depth_sqerr", (diff[depth_mask] ** 2).sum(), depth_mask.sum())
            self._add("depth_delta125", (ratio[depth_mask] < 1.25).float().sum(), depth_mask.sum())

        sem_gt = _resize_scalar(batch["semantic"].float(), depth_hw, mode="nearest").long()
        sem_pred = pred["semantic"].argmax(dim=2)
        self.sem_cm += confusion_matrix(
            sem_pred.detach().cpu(),
            sem_gt.detach().cpu(),
            self.num_semantic,
            self.ignore_index,
        )

        pm_gt = _resize_pointmap(batch["pointmap"], tuple(pred["pointmap"].shape[2:4]))
        pm_mask = _resize_scalar(batch["depth_mask"].float(), tuple(pred["pointmap"].shape[2:4]), mode="nearest") > 0.5
        pm_l2 = (pred["pointmap"].float() - pm_gt.float()).norm(dim=-1)
        self._add("point_l2", pm_l2[pm_mask].sum(), pm_mask.sum())
        if self.compute_chamfer:
            cd = chamfer_loss(pred["pointmap"], batch["lidar_points"], self.max_chamfer_points)
            self._add("point_chamfer", cd, 1.0)

        occ_gt = make_occ_dense(
            batch["occ_sparse"],
            source_shape_zyx=self.occ_source_shape,
            target_shape_zyx=tuple(pred["occ"].shape[-3:]),
            device=pred["occ"].device,
            source_ranges_xyz=self.occ_source_ranges,
            target_ranges_xyz=self.occ_target_ranges,
        )
        occ_pred = pred["occ"].argmax(dim=1)
        self.occ_cm += confusion_matrix(
            occ_pred.detach().cpu(),
            occ_gt.detach().cpu(),
            self.num_occ,
            ignore_index=-1,
        )

    def compute(self) -> dict[str, float]:
        out: dict[str, float] = {}
        if self.counts.get("rgb_sse", 0.0) > 0:
            mse = self.scalars["rgb_sse"] / self.counts["rgb_sse"]
            out["rgb_mse"] = mse
            out["rgb_psnr"] = -10.0 * math.log10(max(mse, 1e-12))
        if self.counts.get("rgb_l1", 0.0) > 0:
            out["rgb_l1"] = self.scalars["rgb_l1"] / self.counts["rgb_l1"]
        if self.counts.get("depth_absrel", 0.0) > 0:
            out["depth_absrel"] = self.scalars["depth_absrel"] / self.counts["depth_absrel"]
            out["depth_rmse"] = math.sqrt(self.scalars["depth_sqerr"] / self.counts["depth_sqerr"])
            out["depth_delta125"] = self.scalars["depth_delta125"] / self.counts["depth_delta125"]
        if self.counts.get("point_l2", 0.0) > 0:
            out["point_l2_m"] = self.scalars["point_l2"] / self.counts["point_l2"]
        if self.counts.get("point_chamfer", 0.0) > 0:
            out["point_chamfer_m"] = self.scalars["point_chamfer"] / self.counts["point_chamfer"]
        out["semantic_miou"] = miou_from_confusion(self.sem_cm)
        out["occ_miou_all"] = miou_from_confusion(self.occ_cm)
        out["occ_miou_occupied"] = miou_from_confusion(self.occ_cm, ignore_classes=(0,))
        out["semantic_gt_hist"] = histogram_from_confusion(self.sem_cm, kind="target")
        out["semantic_pred_hist"] = histogram_from_confusion(self.sem_cm, kind="pred")
        out["occ_gt_hist"] = histogram_from_confusion(self.occ_cm, kind="target")
        out["occ_pred_hist"] = histogram_from_confusion(self.occ_cm, kind="pred")
        out["semantic_valid_pixels"] = float(self.sem_cm.sum().item())
        out["occ_voxels"] = float(self.occ_cm.sum().item())
        return out
