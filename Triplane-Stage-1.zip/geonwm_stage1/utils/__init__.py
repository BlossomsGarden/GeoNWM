"""Small runtime utilities."""

