from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image, ImageDraw
from torch.nn import functional as F

from geonwm_stage1.losses.stage1_losses import make_occ_dense, occ_source_ranges_from_cfg, occ_target_ranges_from_cfg


PALETTE = np.array(
    [
        [0, 0, 0],
        [230, 25, 75],
        [60, 180, 75],
        [255, 225, 25],
        [0, 130, 200],
        [245, 130, 48],
        [145, 30, 180],
        [70, 240, 240],
        [240, 50, 230],
        [210, 245, 60],
        [250, 190, 190],
        [0, 128, 128],
        [230, 190, 255],
        [170, 110, 40],
        [255, 250, 200],
        [128, 0, 0],
        [170, 255, 195],
        [128, 128, 0],
        [255, 215, 180],
        [0, 0, 128],
        [128, 128, 128],
        [255, 255, 255],
        [30, 60, 90],
        [90, 30, 60],
        [60, 90, 30],
        [120, 60, 30],
        [30, 120, 60],
        [60, 30, 120],
        [190, 90, 90],
        [90, 190, 90],
        [90, 90, 190],
        [220, 220, 120],
    ],
    dtype=np.uint8,
)


def _resize_rgb(target: torch.Tensor, hw: tuple[int, int]) -> torch.Tensor:
    b, v = target.shape[:2]
    out = F.interpolate(target.flatten(0, 1), size=hw, mode="bilinear", align_corners=False)
    return out.reshape(b, v, 3, hw[0], hw[1])


def _resize_scalar(target: torch.Tensor, hw: tuple[int, int], mode: str) -> torch.Tensor:
    b, v = target.shape[:2]
    x = target.reshape(b * v, 1, target.shape[-2], target.shape[-1]).float()
    if mode == "nearest":
        out = F.interpolate(x, size=hw, mode=mode)
    else:
        out = F.interpolate(x, size=hw, mode=mode, align_corners=False)
    return out.reshape(b, v, hw[0], hw[1])


def _resize_pointmap(target: torch.Tensor, hw: tuple[int, int]) -> torch.Tensor:
    b, v = target.shape[:2]
    x = target.flatten(0, 1).permute(0, 3, 1, 2)
    out = F.interpolate(x, size=hw, mode="nearest")
    return out.permute(0, 2, 3, 1).reshape(b, v, hw[0], hw[1], 3)


def _rgb(t: torch.Tensor) -> np.ndarray:
    arr = t.detach().float().cpu().clamp(0, 1).permute(1, 2, 0).numpy()
    return (arr * 255.0).round().astype(np.uint8)


def _depth(t: torch.Tensor, mask: torch.Tensor | None = None, max_depth: float = 80.0) -> np.ndarray:
    arr = t.detach().float().cpu().numpy()
    if mask is not None:
        m = mask.detach().cpu().numpy().astype(bool)
    else:
        m = np.isfinite(arr) & (arr > 0)
    arr = np.nan_to_num(arr, nan=0.0, posinf=max_depth, neginf=0.0)
    norm = np.clip(arr / max_depth, 0, 1)
    r = (255 * norm).astype(np.uint8)
    g = (255 * np.sqrt(norm)).astype(np.uint8)
    b = (255 * (1.0 - norm)).astype(np.uint8)
    img = np.stack([r, g, b], axis=-1)
    img[~m] = 0
    return img


def _semantic(t: torch.Tensor, ignore_index: int = 255) -> np.ndarray:
    arr = t.detach().long().cpu().numpy()
    img = PALETTE[np.clip(arr, 0, len(PALETTE) - 1)]
    img[arr == ignore_index] = np.array([0, 0, 0], dtype=np.uint8)
    return img


def _heat(t: torch.Tensor, mask: torch.Tensor | None = None, vmax: float = 10.0) -> np.ndarray:
    arr = t.detach().float().cpu().numpy()
    if mask is not None:
        m = mask.detach().cpu().numpy().astype(bool)
    else:
        m = np.isfinite(arr)
    norm = np.clip(arr / max(vmax, 1e-6), 0, 1)
    img = np.stack(
        [
            (255 * norm).astype(np.uint8),
            (255 * (1.0 - np.abs(norm - 0.5) * 2.0)).astype(np.uint8),
            (255 * (1.0 - norm)).astype(np.uint8),
        ],
        axis=-1,
    )
    img[~m] = 0
    return img


def _labeled_tile(img: np.ndarray, label: str) -> Image.Image:
    pil = Image.fromarray(img)
    draw = ImageDraw.Draw(pil)
    draw.rectangle([0, 0, min(pil.width, 180), 14], fill=(0, 0, 0))
    draw.text((3, 1), label, fill=(255, 255, 255))
    return pil


def _grid(rows: list[list[Image.Image]]) -> Image.Image:
    cell_w = max(tile.width for row in rows for tile in row)
    cell_h = max(tile.height for row in rows for tile in row)
    out = Image.new("RGB", (cell_w * len(rows[0]), cell_h * len(rows)), (20, 20, 20))
    for y, row in enumerate(rows):
        for x, tile in enumerate(row):
            out.paste(tile, (x * cell_w, y * cell_h))
    return out


def _bev_from_occ(labels_zyx: torch.Tensor) -> np.ndarray:
    occupied = labels_zyx > 0
    z_indices = torch.arange(labels_zyx.shape[0], device=labels_zyx.device).view(-1, 1, 1)
    top_z = torch.where(occupied, z_indices, z_indices.new_full((), -1)).max(dim=0).values
    labels = torch.where(top_z >= 0, labels_zyx.gather(0, top_z.clamp_min(0).unsqueeze(0)).squeeze(0), labels_zyx.new_zeros(labels_zyx.shape[1:]))
    img = _semantic(labels, ignore_index=255)
    img[~occupied.any(dim=0).detach().cpu().numpy()] = np.array([15, 15, 15], dtype=np.uint8)
    return img


def save_stage1_visuals(
    pred: dict[str, torch.Tensor],
    batch: dict[str, Any],
    cfg: dict[str, Any],
    out_dir: str | Path,
    start_index: int = 0,
    max_items: int = 1,
) -> list[str]:
    view_indices = pred.get("target_view_indices")
    if torch.is_tensor(view_indices):
        batch = dict(batch)
        for key in ["images", "depth", "depth_mask", "pointmap", "semantic"]:
            if key in batch and torch.is_tensor(batch[key]):
                batch[key] = batch[key][:, view_indices]
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    saved: list[str] = []
    bsz = min(max_items, pred["rgb"].shape[0])
    rgb_hw = tuple(pred["rgb"].shape[-2:])
    depth_hw = tuple(pred["depth"].shape[-2:])
    rgb_gt = _resize_rgb(batch["images"], rgb_hw)
    depth_gt = _resize_scalar(batch["depth"], depth_hw, mode="bilinear")
    depth_mask = _resize_scalar(batch["depth_mask"].float(), depth_hw, mode="nearest") > 0.5
    sem_gt = _resize_scalar(batch["semantic"].float(), depth_hw, mode="nearest").long()
    pm_gt = _resize_pointmap(batch["pointmap"], tuple(pred["pointmap"].shape[2:4]))
    pm_err = (pred["pointmap"].float() - pm_gt.float()).norm(dim=-1)
    sem_pred = pred["semantic"].argmax(dim=2)
    max_depth = float(cfg["data"].get("max_depth", 80.0))
    ignore_index = int(cfg["data"].get("semantic_ignore_index", 255))

    for bi in range(bsz):
        token = batch["token"][bi]
        rows: list[list[Image.Image]] = []
        for row_name, tensor_kind in [
            ("rgb_gt", "rgb_gt"),
            ("rgb_pred", "rgb_pred"),
            ("depth_gt", "depth_gt"),
            ("depth_pred", "depth_pred"),
            ("sem_gt", "sem_gt"),
            ("sem_pred", "sem_pred"),
            ("point_err_m", "point_err"),
        ]:
            row: list[Image.Image] = []
            for vi in range(pred["rgb"].shape[1]):
                if tensor_kind == "rgb_gt":
                    img = _rgb(rgb_gt[bi, vi])
                elif tensor_kind == "rgb_pred":
                    img = _rgb(pred["rgb"][bi, vi])
                elif tensor_kind == "depth_gt":
                    img = _depth(depth_gt[bi, vi], depth_mask[bi, vi], max_depth=max_depth)
                elif tensor_kind == "depth_pred":
                    img = _depth(pred["depth"][bi, vi], None, max_depth=max_depth)
                elif tensor_kind == "sem_gt":
                    img = _semantic(sem_gt[bi, vi], ignore_index=ignore_index)
                elif tensor_kind == "sem_pred":
                    img = _semantic(sem_pred[bi, vi], ignore_index=ignore_index)
                else:
                    img = _heat(pm_err[bi, vi], depth_mask[bi, vi], vmax=10.0)
                row.append(_labeled_tile(img, f"{row_name} v{vi}"))
            rows.append(row)
        panel = _grid(rows)
        path = out / f"sample_{start_index + bi:04d}_{token}_views.png"
        panel.save(path)
        saved.append(str(path))

        occ_gt = make_occ_dense(
            [batch["occ_sparse"][bi]],
            source_shape_zyx=tuple(cfg["data"].get("occ_source_shape", [16, 200, 200])),
            target_shape_zyx=tuple(pred["occ"].shape[-3:]),
            device=pred["occ"].device,
            source_ranges_xyz=occ_source_ranges_from_cfg(cfg["data"]),
            target_ranges_xyz=occ_target_ranges_from_cfg(cfg),
        )[0]
        occ_pred = pred["occ"][bi].argmax(dim=0)
        occ_panel = _grid(
            [[
                _labeled_tile(_bev_from_occ(occ_gt), "occ_gt_bev"),
                _labeled_tile(_bev_from_occ(occ_pred), "occ_pred_bev"),
            ]]
        )
        occ_path = out / f"sample_{start_index + bi:04d}_{token}_occ_bev.png"
        occ_panel.save(occ_path)
        saved.append(str(occ_path))
    return saved
