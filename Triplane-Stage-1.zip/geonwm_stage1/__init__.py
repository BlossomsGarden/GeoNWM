"""GeoNWM Phase 1 training package."""

__version__ = "0.1.0"

