from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from geonwm_stage1.data.nuscenes_stage1 import NuScenesStage1Dataset, collate_stage1
from geonwm_stage1.models.stage1 import GeoNWMStage1
from geonwm_stage1.utils.config import load_config, save_json
from geonwm_stage1.utils.metrics import Stage1MetricAccumulator
from geonwm_stage1.utils.runtime import ensure_dir, seed_everything, to_device
from geonwm_stage1.utils.visualization import save_stage1_visuals


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate GeoNWM Stage1 checkpoint.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--checkpoint-kind", choices=["full", "weights"], required=True)
    parser.add_argument("--split", choices=["train", "val"], default="val")
    parser.add_argument("--limit-samples", type=int, default=None)
    parser.add_argument("--limit-batches", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--dinov3-path", default=None, help="Local DINOv3 checkpoint file or directory.")
    parser.add_argument("--save-visuals", action="store_true")
    parser.add_argument("--visual-count", type=int, default=2)
    parser.add_argument("--compute-chamfer", action="store_true")
    parser.add_argument("--amp", choices=["none", "fp16", "bf16"], default="bf16")
    return parser.parse_args()


def amp_context(mode: str, device: torch.device):
    if device.type != "cuda" or mode == "none":
        return torch.autocast(device_type="cpu", enabled=False)
    dtype = torch.bfloat16 if mode == "bf16" else torch.float16
    return torch.autocast(device_type="cuda", dtype=dtype)


def assert_current_stage1_config(cfg: dict[str, Any]) -> None:
    data_cfg = cfg["data"]
    model_cfg = cfg["model"]
    dec_cfg = model_cfg["decoder"]
    tp_cfg = model_cfg["triplane"]
    enc_cfg = model_cfg["image_encoder"]
    occ_cfg = model_cfg["occupancy"]

    assert data_cfg["image_transform"] == "resize_crop", data_cfg["image_transform"]
    assert list(data_cfg["image_size"]) == [256, 704], data_cfg["image_size"]
    assert len(data_cfg["cameras"]) == 6, data_cfg["cameras"]
    assert data_cfg["depth_kind"] == "align_depth", data_cfg["depth_kind"]
    assert int(data_cfg["num_semantic_classes"]) == 32, data_cfg["num_semantic_classes"]
    assert int(data_cfg["num_occ_classes"]) == 17, data_cfg["num_occ_classes"]
    assert list(data_cfg["occ_source_shape"]) == [16, 200, 200], data_cfg["occ_source_shape"]

    assert enc_cfg["type"] == "dinov3", enc_cfg["type"]
    assert enc_cfg["model_name"] == "vit_large_patch16_dinov3", enc_cfg["model_name"]
    assert bool(enc_cfg["pretrained"]), enc_cfg["pretrained"]
    assert enc_cfg.get("pretrained_path"), "model.image_encoder.pretrained_path"
    assert bool(enc_cfg["freeze"]), enc_cfg["freeze"]
    assert int(enc_cfg["out_channels"]) == 256, enc_cfg["out_channels"]
    assert int(enc_cfg["stride"]) == 16, enc_cfg["stride"]

    assert int(tp_cfg["channels"]) == 256, tp_cfg["channels"]
    assert int(tp_cfg["xy_size"]) == 200, tp_cfg["xy_size"]
    assert int(tp_cfg["z_size"]) == 32, tp_cfg["z_size"]
    assert int(tp_cfg["transformer_layers"]) == 4, tp_cfg["transformer_layers"]
    assert int(tp_cfg["transformer_heads"]) == 8, tp_cfg["transformer_heads"]
    assert float(tp_cfg["transformer_mlp_ratio"]) == 4.0, tp_cfg["transformer_mlp_ratio"]

    assert list(dec_cfg["image_size"]) == [256, 704], dec_cfg["image_size"]
    assert int(dec_cfg["decode_stride"]) == 1, dec_cfg["decode_stride"]
    assert int(dec_cfg["hidden_dim"]) == 256, dec_cfg["hidden_dim"]
    assert int(dec_cfg["ray_samples"]) == 8, dec_cfg["ray_samples"]
    assert int(dec_cfg["cross_view_layers"]) == 4, dec_cfg["cross_view_layers"]
    assert int(dec_cfg["attn_heads"]) == 8, dec_cfg["attn_heads"]
    assert int(dec_cfg["chunk_pixels"]) == 512, dec_cfg["chunk_pixels"]
    assert bool(dec_cfg["gradient_checkpoint_chunks"]), dec_cfg["gradient_checkpoint_chunks"]

    assert list(occ_cfg["shape"]) == [16, 200, 200], occ_cfg["shape"]
    assert int(occ_cfg["chunk_points"]) == 8192, occ_cfg["chunk_points"]


def assert_checkpoint_config_matches(run_cfg: dict[str, Any], checkpoint_cfg: dict[str, Any]) -> None:
    run_data = run_cfg.get("data", {})
    ckpt_data = checkpoint_cfg.get("data", {})
    for key in [
        "cameras",
        "image_size",
        "image_transform",
        "depth_kind",
        "semantic_ignore_index",
        "num_semantic_classes",
        "num_occ_classes",
        "occ_source_shape",
    ]:
        assert ckpt_data.get(key) == run_data.get(key), f"data.{key}"
    run_model = dict(run_cfg.get("model", {}))
    ckpt_model = dict(checkpoint_cfg.get("model", {}))
    if "image_encoder" in run_model and "image_encoder" in ckpt_model:
        run_enc = dict(run_model["image_encoder"])
        ckpt_enc = dict(ckpt_model["image_encoder"])
        run_enc.pop("pretrained_path", None)
        ckpt_enc.pop("pretrained_path", None)
        run_model["image_encoder"] = run_enc
        ckpt_model["image_encoder"] = ckpt_enc
    assert ckpt_model == run_model, "model"


def load_checkpoint_state(checkpoint: str, checkpoint_kind: str) -> dict[str, Any]:
    path = Path(checkpoint)
    assert path.exists(), f"Missing checkpoint: {path}"
    ckpt = torch.load(path, map_location="cpu")
    assert isinstance(ckpt, dict), type(ckpt)
    assert "model" in ckpt, ckpt.keys()
    if checkpoint_kind == "full":
        for key in ["criterion", "optimizer", "scaler", "config"]:
            assert key in ckpt, f"Full checkpoint missing key: {key}"
    elif checkpoint_kind == "weights":
        allowed = {"step", "model"}
        unexpected = set(ckpt.keys()) - allowed
        assert not unexpected, f"Weights checkpoint has unexpected full-state keys: {sorted(unexpected)}"
    else:
        raise ValueError(f"Unsupported checkpoint_kind: {checkpoint_kind}")
    return ckpt


def load_model(cfg: dict[str, Any], checkpoint: str, checkpoint_kind: str, device: torch.device) -> GeoNWMStage1:
    ckpt = load_checkpoint_state(checkpoint, checkpoint_kind)
    if checkpoint_kind == "full":
        assert_checkpoint_config_matches(cfg, ckpt["config"])
    model = GeoNWMStage1(cfg)
    model.load_state_dict(ckpt["model"], strict=True)
    model.to(device)
    model.eval()
    return model


def main() -> None:
    args = parse_args()
    cfg = load_config(args.config)
    if args.dinov3_path is not None:
        cfg["model"]["image_encoder"]["pretrained_path"] = args.dinov3_path
    assert_current_stage1_config(cfg)
    seed_everything(int(cfg.get("seed", 2026)))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = ensure_dir(args.output_dir or Path(cfg["paths"]["output_dir"]) / "eval")

    dataset = NuScenesStage1Dataset(cfg, split=args.split, limit_samples=args.limit_samples)
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        collate_fn=collate_stage1,
    )
    model = load_model(cfg, args.checkpoint, args.checkpoint_kind, device)
    metrics = Stage1MetricAccumulator(cfg, compute_chamfer=args.compute_chamfer)

    saved_visuals: list[str] = []
    seen = 0
    with torch.no_grad():
        for batch_idx, batch in enumerate(tqdm(loader, desc=f"eval-{args.split}")):
            if args.limit_batches is not None and batch_idx >= args.limit_batches:
                break
            batch = to_device(batch, device)
            with amp_context(args.amp, device):
                pred = model(batch)
            metrics.update(pred, batch)
            if args.save_visuals and len(saved_visuals) < args.visual_count * 2:
                remaining = max(args.visual_count - len(saved_visuals) // 2, 0)
                if remaining > 0:
                    saved_visuals.extend(
                        save_stage1_visuals(
                            pred,
                            batch,
                            cfg,
                            Path(out_dir) / "visuals",
                            start_index=seen,
                            max_items=remaining,
                        )
                    )
            seen += len(batch["token"])

    result = {
        "checkpoint": args.checkpoint,
        "checkpoint_kind": args.checkpoint_kind,
        "split": args.split,
        "samples_seen": seen,
        "metrics": metrics.compute(),
        "visuals": saved_visuals,
    }
    save_json(Path(out_dir) / "metrics.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
