# Triplane-Stage-1

GeoNWM Phase 1 training code for nuScenes + MoGe-2 depth + SurroundOcc supervision.

This branch targets the full Stage-1 geometry setup:

- DINOv3-backed image encoder loaded from an explicit local checkpoint path
- six nuScenes views at `256x704`
- `256`-channel triplane with `200x200` XY and `200x32` XZ/YZ grids
- full-resolution multi-view ray decoding with chunked execution
- occupancy decoding on `16x200x200`
- flash-attn-backed attention when `flash_attn` is available

## Quick Start

```bash
cd /data/wlh/Triplane/code/Triplane-Stage-1
bash scripts/run_single_gpu_verify.sh
bash scripts/run_ddp_train_4gpu.sh
```

## Inference And Visualization

Use the unified evaluation entry for both inference-only weights and full resumable checkpoints:

```bash
CHECKPOINT=/data/wlh/Triplane/model/stage1_fullscale/weights_latest.pt \
CHECKPOINT_KIND=weights \
bash scripts/run_eval_visualize.sh
```

```bash
CHECKPOINT=/data/wlh/Triplane/model/stage1_fullscale/checkpoint_latest.pt \
CHECKPOINT_KIND=full \
bash scripts/run_eval_visualize.sh
```

## Notes

- The encoder can stay frozen by default, but the config keeps a training switch for later comparison.
- DINOv3 weights are loaded from `DINOV3_PATH` or `/data/wlh/Triplane/model/vit_large_patch16_dinov3`; missing paths fail fast instead of downloading.
- RGB, depth, semantic, point map, and occupancy all keep full-resolution supervision paths.
- The decoder accepts 1, 3, or 6 active target views through the same interface.
- Chunked ray query and chunked occupancy decoding keep the full-scale model trainable on a single GPU.
- Full resumable checkpoints are saved every 6 hours; inference-only weights are saved every 3 hours.
- Verified remote launch: single-GPU `cuda:7` and 4-GPU DDP `cuda:4,5,6,7`.
- `geonwm_stage1.eval` is the single evaluation and visualization entrypoint.
