# DA3-Tok MAE-Style RGB Variant

This directory is a fork of `GenDA3/DA3-Tok` that replaces only the RGB decoding branch with a
fused-token MAE-style RGB head.  Frozen **DA3-BASE**, five-layer fusion, depth decoding, semantic
decoding, point supervision, metrics, checkpointing, and distributed training stay aligned with the
original DA3-Tok baseline.

## Current Experiment

- Remote host: the GenDA3 server from the repository-root `REMOTE_SERVER.md`.
- Remote work dir: `/data4/DATA/wlh/GenDA3/DA3-Tok-MAE-style`.
- Frozen DA3 checkpoint: `/data/wlh/DA3/model/DA3-BASE`.
- DA3 source: `/data/wlh/DA3/code/Depth-Anything-3-main/src`.
- Backbone feature contract: DINOv2 ViT-B/14, `embed_dim=768`, `cat_token=True`, feature dim `1536`.
- Fusion layers: `[3, 5, 7, 9, 11]`.
- DDP resources: `CUDA_VISIBLE_DEVICES=4,7`, `torchrun --nproc_per_node=2`.
- Frame contract: 9 consecutive `CAM_FRONT` frames, all RGB/depth/semantic targets aligned to `280x728`.
- Checkpoint metrics: a deterministic scene-stratified subset of at most 16 official-val clips.
- Confirmed semantic classes: read from `configs/semantic_label_mapping.json` (currently `10`, `ignore_index=-1`).
- Semantic class weights in train-ID order: `[0.39, 0.25, 0.36, 0.43, 1.90, 3.00, 0.25, 0.87, 0.56, 0.25]`.
- Confirmed MoGe2 transform: `configs/moge2_source_transform.json`.

The RAEv2-style fusion remains unchanged: per-layer LayerNorm, learnable scalar softmax weights,
elementwise token/channel sum, and final-layer mean-token context broadcast.

## MAE-Style RGB Head

The RGB branch is now private from the fused-token input onward:

```text
DA3FrozenEncoder
  -> FiveLayerRAEv2Fusion
  -> fused tokens [B,9,1040,1536]
      -> MAEStyleRGBHead -> rgb_norm, rgb
      -> SharedSpatialDecoder(predict_rgb=False) -> depth, semantic_logits
```

`MAEStyleRGBHead` follows the GLD MAE decoder shape after adapting the input projection to the
DA3-Tok fused token width:

- input: fused tokens `[B,T,1040,1536]`
- `decoder_embed`: `Linear(1536 -> 1152)`
- trainable CLS token, fixed 2D sin-cos positional embedding for the `20x52` patch grid
- `28` `ViTMAELayer` blocks, `16` heads, MLP width `4096`
- `decoder_pred`: `Linear(1152 -> 14*14*3)`
- `unpatchify`: normalized RGB patches to `[B,T,3,280,728]`
- ImageNet denormalization: `rgb = rgb_norm * std + mean`

This is intentionally not the exact GLD `6144 -> 1152` head.  GLD concatenates four raw DA3 layers.
This variant keeps DA3-Tok's existing five-layer scalar fusion and tests whether a MAE-style token
decoder improves RGB reconstruction from the fused `1536`-wide representation.

## Checkpoint Policy

DA3-BASE is frozen and is never saved inside training checkpoints. `best.pt` and `last.pt` save only:

- `fusion.state_dict()`
- `rgb_decoder.state_dict()` and depth/semantic `decoder.state_dict()`
- optimizer, scheduler, sampler position, best dev loss, and the arguments needed to reload the frozen DA3 checkpoint
- RGB/depth/semantic metrics measured for that checkpoint on the fixed val subset

Resume always reloads the backbone from the explicit `--da3-model-dir`, then restores the trainable fusion/decoder state.

## Training

```bash
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate da3
cd /data4/DATA/wlh/GenDA3/DA3-Tok-MAE-style
export PYTHONPATH="/data4/DATA/wlh/GenDA3/DA3-Tok-MAE-style:/data/wlh/DA3/code/Depth-Anything-3-main/src:${PYTHONPATH:-}"

CUDA_VISIBLE_DEVICES=4,7 torchrun --standalone --nproc_per_node=2 \
  -m da3_tok.train \
  --train-manifest /data4/DATA/wlh/GenDA3/DA3-Tok/artifacts/index/train.jsonl \
  --dev-manifest /data4/DATA/wlh/GenDA3/DA3-Tok/artifacts/index/dev.jsonl \
  --val-manifest /data4/DATA/wlh/GenDA3/DA3-Tok/artifacts/index/val.jsonl \
  --nuscenes-root /data2/DATA/AutoDrive/nuscenes/v1.0-trainval \
  --da3-model-dir /data/wlh/DA3/model/DA3-BASE \
  --semantic-classes 10 \
  --semantic-mapping configs/semantic_label_mapping.json \
  --moge-source-spec configs/moge2_source_transform.json \
  --semantic-ignore-index -1 \
  --semantic-class-weights 0.39 0.25 0.36 0.43 1.90 3.00 0.25 0.87 0.56 0.25 \
  --seed 42 \
  --steps 40000 \
  --warmup-steps 2000 \
  --loss-log-every 10 \
  --validate-every 1000 \
  --checkpoint-every 1000 \
  --max-dev-batches 32 \
  --max-val-clips 16 \
  --micro-batch-size 1 \
  --gradient-accumulation 12 \
  --frame-chunk-size 1 \
  --workers 6 \
  --feature-layers 3 5 7 9 11 \
  --feature-dim 1536 \
  --run-dir runs/da3_tok_mae_rgb_seed42_gpus47_b1_acc12
```

The original DA3-Tok smoke preflight on GPUs `4,7` passed with `micro_batch_size=1`, LPIPS enabled,
and peak allocated memory `20.70 GiB`.  This MAE-style RGB variant is expected to use more memory
because the RGB branch runs a 28-layer token decoder over `1041` tokens per frame; keep
`frame_chunk_size=1` unless a new smoke preflight shows a larger chunk is safe.

The joint objective uses weights `1.0` RGB L1 reconstruction, `1.0` LPIPS, `1.0` depth,
`0.02` PointCloud, and `0.5` semantic.  RGB reconstruction and LPIPS are computed after
ImageNet-denormalizing the MAE prediction to `[0,1]`, matching GLD's RGB loss convention while
leaving depth, point, and semantic losses unchanged.  GAN loss is not included in this variant.
Semantic cross-entropy applies the class weights above and normalizes by the sum of valid-pixel
weights.

Training logs report loss over the full effective global batch: all accumulation microbatches and both ranks are reduced before rank 0 prints. Dev loss is computed from all-reduced numerator/count statistics, not from an unweighted average of per-batch means.

Rank 0 appends training loss to `loss_history.jsonl` every `--loss-log-every 10` optimizer steps. Each record includes `total`, `rgb`, `perceptual`, `depth`, `point`, `semantic`, and `lr`. Whenever `best.pt` or `last.pt` is saved, training regenerates `loss_curves.png` in the run directory and overwrites the previous image. The plot shows Total, RGB, Depth, PointCloud, and Semantic loss curves.

Dev loss is evaluated every `--validate-every` steps and remains the only criterion used to select `best.pt`. Whenever a periodic `last.pt` or a new `best.pt` is saved, both ranks jointly evaluate one fixed scene-stratified subset from `--val-manifest`. The subset contains at most `--max-val-clips 16` clips, prioritizes one temporal-centre clip per scene, and is recorded in `val_subset.json`. If `best.pt` and `last.pt` are written at the same step, the val subset is forwarded only once.

Checkpoint validation reports:

- RGB: global-pixel `PSNR` and mean-frame Gaussian-window `SSIM`
- Depth: valid-pixel `AbsRel`, `RMSE`, and `delta1`
- Semantic: global-confusion-matrix pixel accuracy, `mIoU`, and per-class IoU

All sufficient statistics are summed across DDP ranks before metrics are computed. Rank 0 appends them to `val_metrics.jsonl`; each checkpoint regenerates and overwrites `metric_curves.png`. Val metrics are monitoring outputs and do not influence checkpoint selection.

## Historical DA3-LARGE Experiment

Earlier testing used `/data/wlh/DA3/model/DA3-LARGE-1.1`, four GPUs, feature layers `[5, 11, 15, 19, 23]`, and feature dim `2048`. That run is historical only. It is not the current formal training configuration and should not be mixed with the BASE run in commands, checkpoint names, or reports.

Frozen DualDPT and Video VAE diagnostics also belong to the historical/reporting workflow, not the clean training directory used for the current BASE formal run.
