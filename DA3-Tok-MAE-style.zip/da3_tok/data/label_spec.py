"""Validated source-label taxonomy mappings for externally generated semantics."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
import torch


@dataclass(frozen=True)
class MoGeSourceSpec:
    """Confirmed raw-camera-to-MoGe depth-pixel transform."""

    raw_width: int
    raw_height: int
    target_width: int
    target_height: int
    raw_to_pixels: torch.Tensor

    @classmethod
    def from_json(cls, path: str | Path) -> "MoGeSourceSpec":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if raw.get("status") != "CONFIRMED":
            raise ValueError(
                f"MoGe source specification {path} has status={raw.get('status')!r}; "
                "verify the actual MoGe preprocessing and set status to CONFIRMED first."
            )
        try:
            raw_width, raw_height = (int(value) for value in raw["source_resolution"])
            target_width, target_height = (int(value) for value in raw["target_resolution"])
            matrix = torch.as_tensor(raw["raw_to_pixels"], dtype=torch.float32)
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError(
                f"{path} must define source_resolution=[width,height], target_resolution=[width,height], "
                "and raw_to_pixels=3x3"
            ) from error
        if matrix.shape != (3, 3):
            raise ValueError(f"{path}: raw_to_pixels must have shape [3,3], got {tuple(matrix.shape)}")
        if target_width <= 0 or target_height <= 0:
            raise ValueError(f"{path}: target_resolution must contain positive [width,height] values")
        return cls(raw_width, raw_height, target_width, target_height, matrix)

    def validate_raw_resolution(self, raw_width: int, raw_height: int) -> None:
        if (raw_width, raw_height) != (self.raw_width, self.raw_height):
            raise RuntimeError(
                "MoGe source specification applies to "
                f"{self.raw_width}x{self.raw_height}, but received raw camera {raw_width}x{raw_height}."
            )


@dataclass(frozen=True)
class SemanticLabelSpec:
    """Maps source semantic IDs and, when needed, specifies their pixel frame."""

    source_to_train: dict[int, int]
    ignore_ids: frozenset[int]
    classes: int
    ignore_index: int = -1
    source_resolution: tuple[int, int] | None = None
    raw_to_pixels: torch.Tensor | None = None

    @classmethod
    def from_json(cls, path: str | Path) -> "SemanticLabelSpec":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if raw.get("status") != "CONFIRMED":
            raise ValueError(
                f"Semantic mapping {path} has status={raw.get('status')!r}; audit and set status to CONFIRMED first."
            )
        try:
            classes = int(raw["classes"])
            source_to_train = {int(source): int(target) for source, target in raw["source_to_train"].items()}
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError(
                f"{path} must contain classes and a source_to_train object with integer IDs"
            ) from error
        ignore_index = int(raw.get("ignore_index", -1))
        ignore_ids = frozenset(int(value) for value in raw.get("ignore_ids", []))
        invalid_targets = {target for target in source_to_train.values() if target < 0 or target >= classes}
        if classes <= 0 or invalid_targets:
            raise ValueError(
                f"Invalid semantic mapping in {path}: classes={classes}, invalid targets={sorted(invalid_targets)}"
            )
        source_resolution = raw.get("source_resolution")
        raw_to_pixels = raw.get("raw_to_pixels")
        if (source_resolution is None) != (raw_to_pixels is None):
            raise ValueError(
                f"{path} must provide both source_resolution and raw_to_pixels, or neither for raw-camera labels"
            )
        if source_resolution is not None:
            source_resolution = tuple(int(value) for value in source_resolution)
            raw_to_pixels = torch.as_tensor(raw_to_pixels, dtype=torch.float32)
            if len(source_resolution) != 2 or raw_to_pixels.shape != (3, 3):
                raise ValueError(f"Invalid semantic source frame declaration in {path}")
        return cls(source_to_train, ignore_ids, classes, ignore_index, source_resolution, raw_to_pixels)

    def validate_raw_resolution(self, raw_width: int, raw_height: int) -> None:
        if self.source_resolution is not None and self.source_resolution != (raw_width, raw_height):
            raise RuntimeError(
                f"Semantic mapping expects raw camera {self.source_resolution}, got {(raw_width, raw_height)}"
            )

    def map_tensor(self, source: torch.Tensor) -> torch.Tensor:
        output = torch.full_like(source, self.ignore_index)
        known = torch.zeros_like(source, dtype=torch.bool)
        for source_id, target_id in self.source_to_train.items():
            match = source.eq(source_id)
            output[match] = target_id
            known |= match
        for source_id in self.ignore_ids:
            known |= source.eq(source_id)
        unknown = ~known
        if unknown.any():
            unknown_ids = torch.unique(source[unknown]).tolist()
            raise RuntimeError(
                f"Semantic source contains IDs absent from the verified taxonomy: {unknown_ids[:16]}."
            )
        return output
