"""Deterministic multi-modal camera-frame transforms."""

from __future__ import annotations

from typing import Literal

import numpy as np
import torch
from PIL import Image

from da3_tok.geometry import (
    TARGET_HEIGHT,
    TARGET_WIDTH,
    PixelTransform,
    resize_width_center_crop,
    width_center_crop_transform,
)


def target_transform_from_raw(raw_width: int, raw_height: int) -> PixelTransform:
    return width_center_crop_transform(raw_width, raw_height, TARGET_HEIGHT, TARGET_WIDTH)


def pil_rgb_to_target(image: Image.Image, transform: PixelTransform) -> torch.Tensor:
    """Return target-frame RGB as ``[3,H,W]`` floats in ``[0,1]``."""
    rgb = image.convert("RGB")
    array = np.asarray(rgb, dtype=np.float32) / 255.0
    tensor = torch.from_numpy(array).permute(2, 0, 1)
    return resize_width_center_crop(tensor, transform, mode="bicubic").clamp_(0.0, 1.0)


def label_to_target(label: torch.Tensor, transform: PixelTransform) -> torch.Tensor:
    """Resize/crop a class-id label with nearest-neighbour interpolation."""
    if label.ndim != 2:
        raise ValueError(f"Expected a class-id [H,W] label, got {tuple(label.shape)}")
    return resize_width_center_crop(label[None].float(), transform, mode="nearest").squeeze(0).long()


def imagenet_normalize(rgb_01: torch.Tensor) -> torch.Tensor:
    """ImageNet-normalize ``[...,3,H,W]`` RGB for the frozen DA3 encoder."""
    if rgb_01.shape[-3] != 3:
        raise ValueError(f"Expected RGB channel at -3, got {tuple(rgb_01.shape)}")
    mean = torch.tensor((0.485, 0.456, 0.406), dtype=rgb_01.dtype, device=rgb_01.device)
    std = torch.tensor((0.229, 0.224, 0.225), dtype=rgb_01.dtype, device=rgb_01.device)
    shape = (1,) * (rgb_01.ndim - 3) + (3, 1, 1)
    return (rgb_01 - mean.view(shape)) / std.view(shape)


def vae_normalize(rgb_01: torch.Tensor) -> torch.Tensor:
    """Map common RGB targets to OmniNWM Hunyuan VAE's ``[-1,1]`` range."""
    return rgb_01.mul(2.0).sub(1.0)


def target_intrinsics(raw_intrinsics: torch.Tensor, transform: PixelTransform) -> torch.Tensor:
    if raw_intrinsics.shape[-2:] != (3, 3):
        raise ValueError(f"Expected [...,3,3] intrinsics, got {tuple(raw_intrinsics.shape)}")
    matrix = transform.matrix.to(raw_intrinsics.device, raw_intrinsics.dtype)
    return matrix @ raw_intrinsics
