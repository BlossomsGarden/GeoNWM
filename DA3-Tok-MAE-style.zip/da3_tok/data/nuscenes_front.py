"""Manifest-driven nine-frame CAM_FRONT clips with a shared calibrated pixel frame."""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np
import torch
from PIL import Image
from pyquaternion import Quaternion
from torch.utils.data import Dataset

from da3_tok.data.label_spec import MoGeSourceSpec, SemanticLabelSpec
from da3_tok.data.transforms import (
    imagenet_normalize,
    label_to_target,
    pil_rgb_to_target,
    target_intrinsics,
    target_transform_from_raw,
)
from da3_tok.geometry import (
    TARGET_HEIGHT,
    TARGET_WIDTH,
    target_from_source_matrix,
    warp_depth_and_mask,
    warp_preprocessed_frame,
)

CAMERA_CHANNEL = "CAM_FRONT"
CLIP_FRAMES = 9
def _resolve_nuscenes_dataroot(path: str | Path) -> Path:
    """Accept either the nuScenes root or its ``v1.0-trainval`` subdirectory."""
    root = Path(path).expanduser().resolve()
    version_dir = root / "v1.0-trainval"
    if version_dir.is_dir() and (version_dir / "scene.json").is_file():
        return root
    if root.name == "v1.0-trainval" and (root / "scene.json").is_file():
        return root.parent
    raise FileNotFoundError(
        f"Could not find v1.0-trainval metadata under {root}; expected "
        "<root>/v1.0-trainval/scene.json or <root>/scene.json."
    )


def _matrix_from_record(translation: list[float], rotation: list[float]) -> np.ndarray:
    matrix = np.eye(4, dtype=np.float32)
    matrix[:3, :3] = Quaternion(rotation).rotation_matrix.astype(np.float32)
    matrix[:3, 3] = np.asarray(translation, dtype=np.float32)
    return matrix


def camera_world_to_camera(nusc: Any, camera_sample_data: Mapping[str, Any]) -> np.ndarray:
    """Return timestamp-correct world-to-CAM_FRONT transform for a sample_data record."""
    calibrated = nusc.get("calibrated_sensor", camera_sample_data["calibrated_sensor_token"])
    ego_pose = nusc.get("ego_pose", camera_sample_data["ego_pose_token"])
    sensor_to_ego = _matrix_from_record(calibrated["translation"], calibrated["rotation"])
    ego_to_world = _matrix_from_record(ego_pose["translation"], ego_pose["rotation"])
    camera_to_world = ego_to_world @ sensor_to_ego
    return np.linalg.inv(camera_to_world).astype(np.float32)


def _load_csv_allowlist(csv_path: str | Path | None) -> set[str] | None:
    if csv_path is None:
        return None
    path = Path(csv_path)
    if not path.is_file():
        raise FileNotFoundError(f"Sample allowlist CSV not found: {path}")
    values: set[str] = set()
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        for row in csv.reader(handle):
            for value in row:
                value = value.strip()
                if value:
                    values.add(value)
                    values.add(Path(value).stem)
    return values


def _allowlisted(
    allowlist: set[str] | None,
    sample_token: str,
    camera_data_token: str,
    filename: str,
) -> bool:
    if allowlist is None:
        return True
    candidates = {sample_token, camera_data_token, filename, Path(filename).stem}
    return not candidates.isdisjoint(allowlist)


def _build_stem_index(root: str | Path, *, require_cam_front: bool) -> dict[str, str]:
    """Index labels by exact camera stem without cross-camera fallback.

    ``samples_seg`` mirrors all six nuScenes camera directories.  A missing
    CAM_FRONT label must remain missing; falling back to CAM_BACK (or any other
    view) would pair supervision with the wrong image rays.  Some MoGe exports
    are flat rather than camera-directory trees, so depth may use one globally
    unique file only when no camera-directory structure exists.
    """
    root_path = Path(root)
    if not root_path.is_dir():
        raise FileNotFoundError(f"External label root does not exist: {root_path}")
    grouped: dict[str, list[Path]] = defaultdict(list)
    for path in root_path.rglob("*"):
        if path.is_file():
            grouped[path.stem].append(path)
    resolved: dict[str, str] = {}
    ambiguous: dict[str, list[Path]] = {}
    known_camera_names = {
        "CAM_FRONT", "CAM_FRONT_LEFT", "CAM_FRONT_RIGHT",
        "CAM_BACK", "CAM_BACK_LEFT", "CAM_BACK_RIGHT",
    }
    root_has_camera_tree = any(any(part in known_camera_names for part in path.parts) for paths in grouped.values() for path in paths)
    for stem, paths in grouped.items():
        front_paths = [path for path in paths if CAMERA_CHANNEL in path.parts]
        if require_cam_front or root_has_camera_tree:
            candidates = front_paths
        else:
            candidates = paths
        if len(candidates) == 1:
            resolved[stem] = str(candidates[0])
        elif len(candidates) > 1:
            ambiguous[stem] = candidates
    if ambiguous:
        example = next(iter(ambiguous.items()))
        raise RuntimeError(
            f"Ambiguous external-label filename stem '{example[0]}' under {root_path}: "
            f"{[str(path) for path in example[1][:3]]}. Provide a deterministic mapping first."
        )
    return resolved


def _read_array(path: str | Path, key: str | None = None) -> np.ndarray:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".npy":
        return np.asarray(np.load(path))
    if suffix == ".npz":
        archive = np.load(path)
        if key is not None:
            if key not in archive.files:
                raise RuntimeError(f"Expected key {key!r} in {path}, got {archive.files}")
            return np.asarray(archive[key])
        if len(archive.files) != 1:
            raise RuntimeError(f"Expected one array in {path}, got {archive.files}")
        return np.asarray(archive[archive.files[0]])
    with Image.open(path) as image:
        return np.asarray(image)


def _read_moge_depth(path: str | Path) -> tuple[np.ndarray, np.ndarray | None]:
    path = Path(path)
    if path.suffix.lower() == ".npz":
        with np.load(path) as archive:
            if "depth" not in archive.files:
                raise RuntimeError(f"Expected MoGe2 npz key 'depth' in {path}, got {archive.files}")
            depth = np.asarray(archive["depth"]).astype(np.float32)
            mask = np.asarray(archive["mask"]).astype(bool) if "mask" in archive.files else None
        return depth, mask
    return _read_array(path).astype(np.float32), None


def _as_class_id_array(values: np.ndarray, path: str | Path) -> np.ndarray:
    """Accept 2D IDs or lossless grayscale RGB IDs; reject palette/logit tensors."""
    values = np.squeeze(values)
    if values.ndim == 2:
        return values
    if values.ndim == 3 and values.shape[-1] in {3, 4}:
        channels = values[..., :3]
        if np.array_equal(channels[..., 0], channels[..., 1]) and np.array_equal(channels[..., 0], channels[..., 2]):
            return channels[..., 0]
    raise RuntimeError(
        f"Semantic target at {path} is not a recoverable class-id image: shape={values.shape}. "
        "Convert palette/logit output to a verified single-channel ID map before training."
    )


def _json_record(record: dict[str, Any]) -> str:
    return json.dumps(record, ensure_ascii=False, separators=(",", ":"))


def _records_from_scene(nusc: Any, scene_token: str) -> list[dict[str, Any]]:
    scene = nusc.get("scene", scene_token)
    records: list[dict[str, Any]] = []
    sample_token = scene["first_sample_token"]
    while sample_token:
        sample = nusc.get("sample", sample_token)
        camera_token = sample["data"].get(CAMERA_CHANNEL)
        if camera_token is not None:
            camera = nusc.get("sample_data", camera_token)
            calibrated = nusc.get("calibrated_sensor", camera["calibrated_sensor_token"])
            records.append(
                {
                    "scene_name": scene["name"],
                    "scene_token": scene_token,
                    "sample_token": sample_token,
                    "camera_data_token": camera_token,
                    "camera_filename": camera["filename"],
                    "timestamp": camera["timestamp"],
                    "raw_intrinsics": calibrated["camera_intrinsic"],
                    "world_to_camera": camera_world_to_camera(nusc, camera).tolist(),
                }
            )
        sample_token = sample["next"]
    return records


def _scene_splits() -> tuple[set[str], set[str]]:
    try:
        from nuscenes.utils.splits import create_splits_scenes
    except ImportError as error:  # raised early with a direct remedy
        raise ImportError("nuscenes-devkit is required to build DA3-Tok manifests") from error
    splits = create_splits_scenes()
    return set(splits["train"]), set(splits["val"])


def build_clip_index(
    nuscenes_root: str | Path,
    output_dir: str | Path,
    moge_depth_root: str | Path,
    semantic_root: str | Path,
    samples_csv: str | Path | None = None,
    frames: int = CLIP_FRAMES,
    dev_scene_fraction: float = 0.1,
    val_stride: int = 1,
    min_label_coverage: float = 0.95,
) -> dict[str, int]:
    """Build scene-disjoint JSONL manifests using exact external-label stem matches.

    ``train`` uses the optional CSV as a centre-frame allowlist.  ``dev`` comes
    from held-out official train scenes; ``val`` uses official validation scenes.
    Every returned clip has RGB, MoGe2 and semantic paths for all nine frames.
    """
    if frames % 2 != 1:
        raise ValueError("frames must be odd so each clip has a unique centre frame")
    try:
        from nuscenes.nuscenes import NuScenes
    except ImportError as error:
        raise ImportError("nuscenes-devkit is required to build DA3-Tok manifests") from error

    dataroot = _resolve_nuscenes_dataroot(nuscenes_root)
    nusc = NuScenes(version="v1.0-trainval", dataroot=str(dataroot), verbose=False)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    depth_by_stem = _build_stem_index(moge_depth_root, require_cam_front=False)
    semantic_by_stem = _build_stem_index(semantic_root, require_cam_front=True)
    allowlist = _load_csv_allowlist(samples_csv)
    train_scene_names, val_scene_names = _scene_splits()
    present_scenes = {scene["name"]: scene for scene in nusc.scene}
    train_names = sorted(train_scene_names & set(present_scenes))
    dev_count = max(1, round(len(train_names) * dev_scene_fraction))
    dev_names = set(train_names[-dev_count:])
    train_names = set(train_names[:-dev_count])
    val_names = val_scene_names & set(present_scenes)
    records_by_scene = {
        scene["name"]: _records_from_scene(nusc, scene["token"])
        for scene in nusc.scene
        if scene["name"] in train_names | dev_names | val_names
    }

    split_records: dict[str, list[dict[str, Any]]] = {"train": [], "dev": [], "val": []}
    split_candidates: dict[str, int] = {"train": 0, "dev": 0, "val": 0}
    split_missing_depth: dict[str, int] = {"train": 0, "dev": 0, "val": 0}
    split_missing_semantic: dict[str, int] = {"train": 0, "dev": 0, "val": 0}
    split_missing_images: dict[str, int] = {"train": 0, "dev": 0, "val": 0}
    radius = frames // 2
    for split, scene_names in (("train", train_names), ("dev", dev_names), ("val", val_names)):
        for scene_name in sorted(scene_names):
            sequence = records_by_scene[scene_name]
            for centre in range(radius, len(sequence) - radius):
                if split == "val" and (centre - radius) % val_stride:
                    continue
                centre_record = sequence[centre]
                if split == "train" and not _allowlisted(
                    allowlist,
                    centre_record["sample_token"],
                    centre_record["camera_data_token"],
                    centre_record["camera_filename"],
                ):
                    continue
                clip = sequence[centre - radius : centre + radius + 1]
                split_candidates[split] += 1
                enriched: list[dict[str, Any]] = []
                complete = True
                for frame in clip:
                    stem = Path(frame["camera_filename"]).stem
                    depth_path = depth_by_stem.get(stem)
                    semantic_path = semantic_by_stem.get(stem)
                    image_exists = (dataroot / frame["camera_filename"]).is_file()
                    if depth_path is None:
                        split_missing_depth[split] += 1
                    if semantic_path is None:
                        split_missing_semantic[split] += 1
                    if not image_exists:
                        split_missing_images[split] += 1
                    if depth_path is None or semantic_path is None or not image_exists:
                        complete = False
                        break
                    enriched.append({**frame, "moge_depth_path": depth_path, "semantic_path": semantic_path})
                if complete:
                    split_records[split].append(
                        {
                            "frames": enriched,
                            "centre_sample_token": centre_record["sample_token"],
                            "scene_name": scene_name,
                            "frames_per_clip": frames,
                        }
                    )
    coverage = {
        split: len(records) / max(1, split_candidates[split])
        for split, records in split_records.items()
    }
    failed_coverage = {split: value for split, value in coverage.items() if value < min_label_coverage}
    if failed_coverage:
        raise RuntimeError(
            "External label/image clip coverage is below the required threshold "
            f"{min_label_coverage:.1%}: {failed_coverage}. Missing frame counts: "
            f"depth={split_missing_depth}, semantic={split_missing_semantic}, image={split_missing_images}. "
            "Fix token/path mappings rather than silently training on a biased subset."
        )
    for split, records in split_records.items():
        path = output / f"{split}.jsonl"
        with path.open("w", encoding="utf-8") as handle:
            for record in records:
                handle.write(_json_record(record) + "\n")
    manifest = {
        "dataroot": str(dataroot),
        "moge_depth_root": str(Path(moge_depth_root)),
        "semantic_root": str(Path(semantic_root)),
        "samples_csv": str(samples_csv) if samples_csv else None,
        "frames": frames,
        "target_size": [TARGET_HEIGHT, TARGET_WIDTH],
        "train_scenes": sorted(train_names),
        "dev_scenes": sorted(dev_names),
        "val_scenes": sorted(val_names),
        "counts": {split: len(records) for split, records in split_records.items()},
        "candidate_counts": split_candidates,
        "clip_coverage": coverage,
        "missing_depth_frames": split_missing_depth,
        "missing_semantic_frames": split_missing_semantic,
        "missing_image_frames": split_missing_images,
    }
    (output / "split_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest["counts"]


class NuScenesFrontClipDataset(Dataset[dict[str, Any]]):
    """Load indexed nine-frame clips into the DA3-Tok unified ``280×728`` frame."""

    def __init__(
        self,
        manifest_path: str | Path,
        nuscenes_root: str | Path,
        semantic_classes: int | None = None,
        semantic_ignore_index: int = -1,
        semantic_label_spec: SemanticLabelSpec | None = None,
        moge_invalid_values: Iterable[float] = (0.0,),
        moge_source_spec: MoGeSourceSpec | None = None,
    ) -> None:
        self.records = [
            json.loads(line)
            for line in Path(manifest_path).read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        self.dataroot = _resolve_nuscenes_dataroot(nuscenes_root)
        self.semantic_classes = semantic_classes
        self.semantic_ignore_index = semantic_ignore_index
        self.semantic_label_spec = semantic_label_spec
        if semantic_label_spec is not None:
            if semantic_classes is not None and semantic_classes != semantic_label_spec.classes:
                raise ValueError("semantic_classes must match the verified SemanticLabelSpec classes")
            if semantic_ignore_index != semantic_label_spec.ignore_index:
                raise ValueError("semantic_ignore_index must match the verified SemanticLabelSpec ignore_index")
            self.semantic_classes = semantic_label_spec.classes
        self.moge_invalid_values = tuple(float(value) for value in moge_invalid_values)
        if moge_source_spec is None:
            raise ValueError(
                "MoGeSourceSpec is required for formal training; audit the actual MoGe preprocessing and "
                "provide its confirmed raw-camera-to-depth affine matrix."
            )
        self.moge_source_spec = moge_source_spec

    def __len__(self) -> int:
        return len(self.records)

    def _depth_target(
        self,
        path: str,
        raw_width: int,
        raw_height: int,
        target_transform: Any,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        values, file_valid = _read_moge_depth(path)
        values = np.squeeze(values)
        if values.ndim != 2:
            raise RuntimeError(f"MoGe2 depth must be 2D after squeeze, got {values.shape} at {path}")
        if file_valid is not None:
            file_valid = np.squeeze(file_valid)
            if file_valid.shape != values.shape:
                raise RuntimeError(
                    f"MoGe2 mask shape {file_valid.shape} does not match depth {values.shape} at {path}"
                )
        expected_shape = (self.moge_source_spec.target_height, self.moge_source_spec.target_width)
        if values.shape != expected_shape:
            raise RuntimeError(
                f"Expected MoGe2 target-frame source {expected_shape}, got {values.shape} at {path}. "
                "Update the documented source transform instead of silently resizing."
            )
        valid = np.isfinite(values)
        if file_valid is not None:
            valid &= file_valid
        for invalid in self.moge_invalid_values:
            valid &= values != invalid
        self.moge_source_spec.validate_raw_resolution(raw_width, raw_height)
        source_to_target = target_from_source_matrix(
            self.moge_source_spec.raw_to_pixels,
            target_transform.matrix,
        )
        depth = torch.from_numpy(np.nan_to_num(values, nan=0.0))[None]
        mask = torch.from_numpy(valid)[None]
        return warp_depth_and_mask(depth, mask, source_to_target)

    def _semantic_target(self, path: str, raw_width: int, raw_height: int, transform: Any) -> tuple[torch.Tensor, torch.Tensor]:
        label = _as_class_id_array(_read_array(path), path)
        label_tensor = torch.from_numpy(label.astype(np.int64, copy=False))
        if self.semantic_label_spec is None:
            raise RuntimeError(
                "SemanticLabelSpec is required for formal training; audit samples_seg and provide "
                "an explicit source-ID to train-ID mapping instead of treating raw IDs as classes."
            )
        label_tensor = self.semantic_label_spec.map_tensor(label_tensor)
        if label_tensor.shape == (raw_height, raw_width):
            target = label_to_target(label_tensor, transform)
        elif self.semantic_label_spec.source_resolution is not None and label_tensor.shape == tuple(reversed(self.semantic_label_spec.source_resolution)):
            self.semantic_label_spec.validate_raw_resolution(raw_width, raw_height)
            source_to_target = target_from_source_matrix(self.semantic_label_spec.raw_to_pixels, transform.matrix)
            target = warp_preprocessed_frame(
                label_tensor[None].float(),
                source_to_target,
                TARGET_HEIGHT,
                TARGET_WIDTH,
                mode="nearest",
            ).squeeze(0).long()
            source_valid = torch.ones_like(label_tensor, dtype=torch.float32)[None]
            target_valid = warp_preprocessed_frame(
                source_valid,
                source_to_target,
                TARGET_HEIGHT,
                TARGET_WIDTH,
                mode="nearest",
            ).squeeze(0) > 0.5
            target = target.masked_fill(~target_valid, self.semantic_ignore_index)
        else:
            expected = None
            if self.semantic_label_spec.source_resolution is not None:
                expected = tuple(reversed(self.semantic_label_spec.source_resolution))
            raise RuntimeError(
                f"Semantic shape {tuple(label_tensor.shape)} at {path} matches neither raw camera "
                f"{raw_height}x{raw_width} nor configured source label frame {expected}."
            )
        valid = target.ne(self.semantic_ignore_index)
        if self.semantic_classes is not None:
            invalid_class = valid & ((target < 0) | (target >= self.semantic_classes))
            if invalid_class.any():
                bad_values = torch.unique(target[invalid_class]).tolist()
                raise RuntimeError(
                    f"Semantic label IDs {bad_values[:16]} at {path} are outside [0,{self.semantic_classes}) "
                    f"and are not ignore_index={self.semantic_ignore_index}. Supply a verified taxonomy mapping."
                )
        return target, valid

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        rgb_frames: list[torch.Tensor] = []
        depth_frames: list[torch.Tensor] = []
        depth_masks: list[torch.Tensor] = []
        semantic_frames: list[torch.Tensor] = []
        semantic_masks: list[torch.Tensor] = []
        intrinsics: list[torch.Tensor] = []
        world_to_camera: list[torch.Tensor] = []
        frame_tokens: list[str] = []
        for frame in record["frames"]:
            image_path = self.dataroot / frame["camera_filename"]
            with Image.open(image_path) as image:
                raw_width, raw_height = image.size
                transform = target_transform_from_raw(raw_width, raw_height)
                rgb_frames.append(pil_rgb_to_target(image, transform))
            raw_intrinsics = torch.tensor(frame["raw_intrinsics"], dtype=torch.float32)
            intrinsics.append(target_intrinsics(raw_intrinsics, transform))
            depth, depth_mask = self._depth_target(
                frame["moge_depth_path"], raw_width, raw_height, transform
            )
            semantic, semantic_mask = self._semantic_target(
                frame["semantic_path"], raw_width, raw_height, transform
            )
            depth_frames.append(depth)
            depth_masks.append(depth_mask)
            semantic_frames.append(semantic)
            semantic_masks.append(semantic_mask)
            world_to_camera.append(torch.tensor(frame["world_to_camera"], dtype=torch.float32))
            frame_tokens.append(frame["camera_data_token"])
        rgb_01 = torch.stack(rgb_frames)
        return {
            "rgb_01": rgb_01,
            "image_da3": imagenet_normalize(rgb_01),
            "depth": torch.stack(depth_frames),
            "depth_valid": torch.stack(depth_masks),
            "semantic": torch.stack(semantic_frames),
            "semantic_valid": torch.stack(semantic_masks),
            "intrinsics": torch.stack(intrinsics),
            "world_to_camera": torch.stack(world_to_camera),
            "camera_tokens": frame_tokens,
            "centre_sample_token": record["centre_sample_token"],
            "scene_name": record["scene_name"],
        }
