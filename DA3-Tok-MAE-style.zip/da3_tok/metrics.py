"""Deterministic validation sampling and globally reducible dense metrics."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
import math
from typing import Any

import torch
import torch.distributed as dist
import torch.nn.functional as F

from da3_tok.geometry import flatten_video_frames


def _evenly_spaced_positions(length: int, count: int) -> list[int]:
    if count <= 0 or count > length:
        raise ValueError(f"count must be in [1,{length}], got {count}")
    if count == 1:
        return [length // 2]
    return [round(index * (length - 1) / (count - 1)) for index in range(count)]


def select_scene_stratified_indices(
    records: Sequence[Mapping[str, Any]],
    max_clips: int,
) -> list[int]:
    """Select a deterministic, scene-balanced subset from a clip manifest."""
    if max_clips <= 0:
        raise ValueError("--max-val-clips must be positive")
    if not records:
        raise ValueError("Validation manifest contains no clips")

    by_scene: dict[str, list[int]] = defaultdict(list)
    for index, record in enumerate(records):
        scene_name = record.get("scene_name")
        if not isinstance(scene_name, str) or not scene_name:
            raise ValueError(f"Validation record {index} has no scene_name")
        by_scene[scene_name].append(index)

    scene_names = sorted(by_scene)
    target_count = min(max_clips, len(records))
    if target_count <= len(scene_names):
        scene_positions = _evenly_spaced_positions(len(scene_names), target_count)
        chosen_scenes = [scene_names[index] for index in scene_positions]
        return sorted(by_scene[name][len(by_scene[name]) // 2] for name in chosen_scenes)

    allocation = {name: 1 for name in scene_names}
    remaining = target_count - len(scene_names)
    while remaining:
        progressed = False
        for name in scene_names:
            if allocation[name] >= len(by_scene[name]):
                continue
            allocation[name] += 1
            remaining -= 1
            progressed = True
            if not remaining:
                break
        if not progressed:
            break

    selected: list[int] = []
    for name in scene_names:
        scene_indices = by_scene[name]
        positions = _evenly_spaced_positions(len(scene_indices), allocation[name])
        selected.extend(scene_indices[position] for position in positions)
    return sorted(selected)


def structural_similarity_per_frame(
    prediction: torch.Tensor,
    target: torch.Tensor,
    window_size: int = 11,
    sigma: float = 1.5,
) -> torch.Tensor:
    """Return standard Gaussian-window RGB SSIM for each ``[N,C,H,W]`` frame."""
    if prediction.shape != target.shape or prediction.ndim != 4:
        raise ValueError("SSIM prediction and target must have matching [N,C,H,W] shapes")
    if window_size % 2 != 1 or window_size < 3:
        raise ValueError("SSIM window_size must be an odd integer >= 3")
    if min(prediction.shape[-2:]) <= window_size // 2:
        raise ValueError("SSIM frames are too small for reflect padding")

    prediction = prediction.float().clamp(0.0, 1.0)
    target = target.float().clamp(0.0, 1.0)
    coordinates = torch.arange(window_size, device=prediction.device, dtype=prediction.dtype)
    coordinates = coordinates - (window_size - 1) / 2.0
    kernel_1d = torch.exp(-(coordinates.square()) / (2.0 * sigma**2))
    kernel_1d = kernel_1d / kernel_1d.sum()
    kernel_2d = kernel_1d[:, None] * kernel_1d[None, :]
    channels = prediction.shape[1]
    kernel = kernel_2d.expand(channels, 1, window_size, window_size)
    padding = window_size // 2

    def local_mean(values: torch.Tensor) -> torch.Tensor:
        values = F.pad(values, (padding, padding, padding, padding), mode="reflect")
        return F.conv2d(values, kernel, groups=channels)

    mean_prediction = local_mean(prediction)
    mean_target = local_mean(target)
    variance_prediction = local_mean(prediction.square()) - mean_prediction.square()
    variance_target = local_mean(target.square()) - mean_target.square()
    covariance = local_mean(prediction * target) - mean_prediction * mean_target
    c1 = 0.01**2
    c2 = 0.03**2
    numerator = (2.0 * mean_prediction * mean_target + c1) * (2.0 * covariance + c2)
    denominator = (
        (mean_prediction.square() + mean_target.square() + c1)
        * (variance_prediction + variance_target + c2)
    )
    return (numerator / denominator.clamp_min(1e-12)).mean(dim=(1, 2, 3))


class DenseMetricAccumulator:
    """Accumulate RGB, depth and semantic statistics without retaining predictions."""

    def __init__(self, semantic_classes: int, device: torch.device) -> None:
        if semantic_classes <= 0:
            raise ValueError("semantic_classes must be positive")
        self.semantic_classes = semantic_classes
        self.stats = torch.zeros(9, dtype=torch.float64, device=device)
        self.confusion = torch.zeros(
            (semantic_classes, semantic_classes), dtype=torch.int64, device=device
        )

    @torch.no_grad()
    def update(self, prediction: Mapping[str, torch.Tensor], batch: Mapping[str, torch.Tensor]) -> None:
        predicted_rgb = flatten_video_frames(prediction["rgb"]).float().clamp(0.0, 1.0)
        target_rgb = flatten_video_frames(batch["rgb_01"]).float().clamp(0.0, 1.0)
        if predicted_rgb.shape != target_rgb.shape:
            raise ValueError("RGB prediction and target shapes do not match")
        rgb_error = predicted_rgb - target_rgb
        self.stats[0] += rgb_error.square().sum(dtype=torch.float64)
        self.stats[1] += rgb_error.numel()
        ssim = structural_similarity_per_frame(predicted_rgb, target_rgb)
        self.stats[2] += ssim.sum(dtype=torch.float64)
        self.stats[3] += ssim.numel()
        self.stats[8] += prediction["rgb"].shape[0]

        predicted_depth = flatten_video_frames(prediction["depth"]).float()
        target_depth = flatten_video_frames(batch["depth"]).float()
        depth_valid = flatten_video_frames(batch["depth_valid"].float()).bool()
        depth_valid &= torch.isfinite(predicted_depth) & torch.isfinite(target_depth) & target_depth.gt(0.0)
        if depth_valid.any():
            predicted_values = predicted_depth[depth_valid].clamp_min(1e-6)
            target_values = target_depth[depth_valid].clamp_min(1e-6)
            depth_error = predicted_values - target_values
            self.stats[4] += (depth_error.abs() / target_values).sum(dtype=torch.float64)
            self.stats[5] += depth_error.square().sum(dtype=torch.float64)
            ratio = torch.maximum(predicted_values / target_values, target_values / predicted_values)
            self.stats[6] += ratio.lt(1.25).sum(dtype=torch.float64)
            self.stats[7] += target_values.numel()

        semantic_logits = prediction["semantic_logits"].flatten(0, 1)
        semantic_target = batch["semantic"].flatten(0, 1).long()
        semantic_valid = batch["semantic_valid"].flatten(0, 1).bool()
        semantic_valid &= semantic_target.ge(0) & semantic_target.lt(self.semantic_classes)
        if semantic_valid.any():
            predicted_class = semantic_logits.argmax(dim=1)
            target_values = semantic_target[semantic_valid]
            predicted_values = predicted_class[semantic_valid]
            encoded = target_values * self.semantic_classes + predicted_values
            counts = torch.bincount(encoded, minlength=self.semantic_classes**2)
            self.confusion += counts.reshape(self.semantic_classes, self.semantic_classes)

    def synchronize(self) -> None:
        if dist.is_available() and dist.is_initialized():
            dist.all_reduce(self.stats, op=dist.ReduceOp.SUM)
            dist.all_reduce(self.confusion, op=dist.ReduceOp.SUM)

    def compute(self) -> dict[str, Any]:
        rgb_count = self.stats[1].item()
        frame_count = self.stats[3].item()
        depth_count = self.stats[7].item()
        semantic_count = self.confusion.sum().item()
        if min(rgb_count, frame_count, depth_count, semantic_count) <= 0:
            raise RuntimeError("Validation subset produced an empty RGB, depth, or semantic metric domain")

        rgb_mse = self.stats[0].item() / rgb_count
        depth_mse = self.stats[5].item() / depth_count
        confusion = self.confusion.double()
        intersection = confusion.diag()
        union = confusion.sum(dim=0) + confusion.sum(dim=1) - intersection
        valid_classes = union.gt(0)
        per_class_iou = intersection / union.clamp_min(1.0)
        return {
            "rgb_psnr": -10.0 * math.log10(max(rgb_mse, 1e-12)),
            "rgb_ssim": self.stats[2].item() / frame_count,
            "depth_abs_rel": self.stats[4].item() / depth_count,
            "depth_rmse": depth_mse**0.5,
            "depth_delta1": self.stats[6].item() / depth_count,
            "semantic_pixel_accuracy": intersection.sum().item() / semantic_count,
            "semantic_miou": per_class_iou[valid_classes].mean().item(),
            "semantic_per_class_iou": [
                value.item() if valid else None
                for value, valid in zip(per_class_iou.cpu(), valid_classes.cpu())
            ],
            "evaluated_clips": int(self.stats[8].item()),
            "evaluated_frames": int(frame_count),
        }
