"""Single-node DDP training for DA3-Tok with a MAE-style RGB decoder."""

from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.distributed as dist
from PIL import Image, ImageDraw
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.optim import AdamW
from torch.optim.lr_scheduler import LambdaLR
from torch.utils.data import DataLoader, DistributedSampler, Subset

from da3_tok.data.label_spec import MoGeSourceSpec, SemanticLabelSpec
from da3_tok.data.nuscenes_front import NuScenesFrontClipDataset
from da3_tok.distributed import DistributedEvalSampler, cleanup_distributed, is_main_process, setup_distributed
from da3_tok.losses import DA3TokLoss, LossWeights
from da3_tok.metrics import DenseMetricAccumulator, select_scene_stratified_indices
from da3_tok.models.da3_tok import DA3Tok


LOSS_COMPONENTS = ("rgb", "perceptual", "depth", "point", "semantic")
LOSS_PLOT_SERIES = (
    ("total", "Total"),
    ("rgb", "RGB"),
    ("depth", "Depth"),
    ("point", "PointCloud"),
    ("semantic", "Semantic"),
)
METRIC_PLOT_SERIES = (
    ("rgb_psnr", "RGB PSNR"),
    ("rgb_ssim", "RGB SSIM"),
    ("depth_abs_rel", "Depth AbsRel"),
    ("depth_rmse", "Depth RMSE"),
    ("depth_delta1", "Depth delta1"),
    ("semantic_miou", "Semantic mIoU"),
    ("semantic_pixel_accuracy", "Semantic pixel accuracy"),
)
PLOT_COLORS = {
    "total": (31, 78, 121),
    "rgb": (70, 130, 80),
    "depth": (190, 110, 30),
    "point": (115, 73, 157),
    "semantic": (180, 60, 75),
    "rgb_psnr": (31, 120, 180),
    "rgb_ssim": (42, 145, 120),
    "depth_abs_rel": (210, 125, 35),
    "depth_rmse": (190, 75, 45),
    "depth_delta1": (120, 105, 175),
    "semantic_miou": (185, 65, 100),
    "semantic_pixel_accuracy": (90, 95, 105),
}
DEFAULT_SEMANTIC_CLASS_WEIGHTS = (
    0.39,
    0.25,
    0.36,
    0.43,
    1.90,
    3.00,
    0.25,
    0.87,
    0.56,
    0.25,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-manifest", required=True)
    parser.add_argument("--dev-manifest", required=True)
    parser.add_argument("--val-manifest", required=True)
    parser.add_argument("--nuscenes-root", required=True)
    parser.add_argument("--da3-model-dir", required=True)
    parser.add_argument("--semantic-classes", type=int, required=True)
    parser.add_argument("--semantic-mapping", type=Path, required=True)
    parser.add_argument("--moge-source-spec", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, default=Path("runs/da3_tok_seed42"))
    parser.add_argument("--feature-layers", type=int, nargs=5, default=[3, 5, 7, 9, 11])
    parser.add_argument("--feature-dim", type=int, default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--steps", type=int, default=40_000)
    parser.add_argument("--warmup-steps", type=int, default=2_000)
    parser.add_argument("--micro-batch-size", type=int, default=1)
    parser.add_argument("--gradient-accumulation", type=int, default=4)
    parser.add_argument("--frame-chunk-size", type=int, default=1)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=0.05)
    parser.add_argument("--validate-every", type=int, default=1_000)
    parser.add_argument("--checkpoint-every", type=int, default=1_000)
    parser.add_argument("--loss-log-every", type=int, default=10)
    parser.add_argument("--max-dev-batches", type=int, default=32)
    parser.add_argument("--max-val-clips", type=int, default=16)
    parser.add_argument("--resume", type=Path, default=None)
    parser.add_argument("--disable-lpips", action="store_true")
    parser.add_argument("--semantic-ignore-index", type=int, default=-1)
    parser.add_argument(
        "--semantic-class-weights",
        type=float,
        nargs="+",
        default=list(DEFAULT_SEMANTIC_CLASS_WEIGHTS),
        help="Positive cross-entropy weights in semantic train-ID order.",
    )
    return parser.parse_args()


def validated_semantic_class_weights(values: list[float], classes: int) -> torch.Tensor:
    weights = torch.as_tensor(values, dtype=torch.float32)
    if weights.ndim != 1 or weights.numel() != classes:
        raise ValueError(
            f"--semantic-class-weights must provide exactly {classes} values, got {weights.numel()}"
        )
    if not torch.isfinite(weights).all() or (weights <= 0).any():
        raise ValueError("--semantic-class-weights values must be finite and positive")
    return weights


def seed_everything(seed: int, rank: int) -> None:
    actual_seed = seed + rank
    random.seed(actual_seed)
    np.random.seed(actual_seed)
    torch.manual_seed(actual_seed)
    torch.cuda.manual_seed_all(actual_seed)


def move_batch(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def build_scheduler(optimizer: torch.optim.Optimizer, warmup_steps: int, total_steps: int) -> LambdaLR:
    def factor(step: int) -> float:
        if step < warmup_steps:
            return max(1, step + 1) / max(1, warmup_steps)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * min(1.0, progress)))

    return LambdaLR(optimizer, factor)


def _unwrap_model(model: DDP | DA3Tok) -> DA3Tok:
    return model.module if isinstance(model, DDP) else model


def trainable_state_dict(model: DDP | DA3Tok) -> dict[str, dict[str, torch.Tensor]]:
    """Checkpoint only trainable DA3-Tok modules; frozen DA3 is reloaded from args."""
    unwrapped = _unwrap_model(model)
    return {
        "fusion": unwrapped.fusion.state_dict(),
        "rgb_decoder": unwrapped.rgb_decoder.state_dict(),
        "decoder": unwrapped.decoder.state_dict(),
    }


def load_trainable_state_dict(model: DDP | DA3Tok, checkpoint: dict[str, Any]) -> None:
    unwrapped = _unwrap_model(model)
    if "trainable_model" in checkpoint:
        state = checkpoint["trainable_model"]
        unwrapped.fusion.load_state_dict(state["fusion"], strict=True)
        unwrapped.rgb_decoder.load_state_dict(state["rgb_decoder"], strict=True)
        unwrapped.decoder.load_state_dict(state["decoder"], strict=True)
        return
    if "model" in checkpoint:
        # Backward compatibility for pre-BASE-cleanup checkpoints that stored DA3.
        unwrapped.load_state_dict(checkpoint["model"], strict=True)
        return
    unwrapped.load_state_dict(checkpoint, strict=True)


def loss_stats_tensor(losses: dict[str, torch.Tensor]) -> torch.Tensor:
    values: list[torch.Tensor] = []
    for component in LOSS_COMPONENTS:
        values.append(losses[f"{component}_sum"].detach().double())
        values.append(losses[f"{component}_count"].detach().double())
    return torch.stack(values)


def summarize_loss_stats(stats: torch.Tensor, weights: LossWeights) -> dict[str, float]:
    means: dict[str, float] = {}
    for index, component in enumerate(LOSS_COMPONENTS):
        total = stats[index * 2]
        count = stats[index * 2 + 1].clamp_min(1.0)
        means[component] = (total / count).item()
    means["total"] = (
        weights.rgb * means["rgb"]
        + weights.perceptual * means["perceptual"]
        + weights.depth * means["depth"]
        + weights.point * means["point"]
        + weights.semantic * means["semantic"]
    )
    return means


def append_loss_history(
    run_dir: Path,
    step: int,
    loss_log: dict[str, float],
    optimizer: torch.optim.Optimizer,
) -> None:
    record = {"step": step, "lr": float(optimizer.param_groups[0]["lr"])}
    for key in ("total", *LOSS_COMPONENTS):
        if key in loss_log:
            record[key] = float(loss_log[key])
    with (run_dir / "loss_history.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, separators=(",", ":")) + "\n")


def append_val_metrics(run_dir: Path, step: int, metrics: dict[str, Any]) -> None:
    record = {"step": step, **metrics}
    with (run_dir / "val_metrics.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, separators=(",", ":"), allow_nan=False) + "\n")


def read_jsonl_history(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    records: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if "step" in record:
            records.append(record)
    return records


def _finite_points(records: list[dict[str, Any]], key: str) -> list[tuple[int, float]]:
    points: list[tuple[int, float]] = []
    for record in records:
        value = record.get(key)
        step = record.get("step")
        if isinstance(step, (int, float)) and isinstance(value, (int, float)) and math.isfinite(float(value)):
            points.append((int(step), float(value)))
    return points


def _render_history_curves(
    records: list[dict[str, Any]],
    image_path: Path,
    series: tuple[tuple[str, str], ...],
    title: str,
    subtitle: str,
) -> None:
    if not records:
        return
    width = 1200
    panel_height = 190
    header_height = 58
    footer_height = 18
    panel_gap = 18
    left = 92
    right = 28
    panel_inner_top = 30
    panel_inner_bottom = 34
    plot_width = width - left - right
    height = header_height + len(series) * panel_height + (len(series) - 1) * panel_gap + footer_height
    image = Image.new("RGB", (width, height), (255, 255, 255))
    draw = ImageDraw.Draw(image)
    last_step = max(int(record.get("step", 0)) for record in records)
    draw.text((20, 18), f"{title}, updated at step {last_step}", fill=(20, 20, 20))
    draw.text(
        (20, 36),
        subtitle,
        fill=(90, 90, 90),
    )
    for panel_index, (key, label) in enumerate(series):
        points = _finite_points(records, key)
        panel_top = header_height + panel_index * (panel_height + panel_gap)
        plot_top = panel_top + panel_inner_top
        plot_height = panel_height - panel_inner_top - panel_inner_bottom
        plot_bottom = plot_top + plot_height
        plot_right = left + plot_width
        draw.rectangle((left, plot_top, plot_right, plot_bottom), outline=(190, 190, 190))
        draw.text((20, panel_top + 6), label, fill=PLOT_COLORS[key])
        if not points:
            draw.text((left + 8, plot_top + 8), "No data", fill=(140, 140, 140))
            continue
        x_values = [step for step, _ in points]
        y_values = [value for _, value in points]
        x_min = min(x_values)
        x_max = max(x_values)
        if x_min == x_max:
            x_min -= 1
            x_max += 1
        y_min = min(y_values)
        y_max = max(y_values)
        pad = (y_max - y_min) * 0.08 if y_max > y_min else max(abs(y_max), 1.0) * 0.05
        y_min = max(0.0, y_min - pad)
        y_max = y_max + pad
        if y_max <= y_min:
            y_max = y_min + 1.0
        for grid_index in range(5):
            frac = grid_index / 4.0
            y = plot_top + int(round((1.0 - frac) * plot_height))
            value = y_min + frac * (y_max - y_min)
            draw.line((left, y, plot_right, y), fill=(235, 235, 235))
            draw.text((20, y - 7), f"{value:.4g}", fill=(100, 100, 100))
        scaled = [
            (
                left + int(round((step - x_min) / max(1, x_max - x_min) * plot_width)),
                plot_top + int(round((y_max - value) / (y_max - y_min) * plot_height)),
            )
            for step, value in points
        ]
        if len(scaled) == 1:
            x, y = scaled[0]
            draw.ellipse((x - 3, y - 3, x + 3, y + 3), fill=PLOT_COLORS[key])
        else:
            draw.line(scaled, fill=PLOT_COLORS[key], width=2)
        latest_step, latest_value = points[-1]
        draw.text((left, plot_bottom + 10), f"step {x_min}", fill=(100, 100, 100))
        draw.text((plot_right - 90, plot_bottom + 10), f"step {x_max}", fill=(100, 100, 100))
        draw.text((plot_right - 210, panel_top + 6), f"latest {latest_value:.6g} @ {latest_step}", fill=(60, 60, 60))
    image_path.parent.mkdir(parents=True, exist_ok=True)
    image.save(image_path)


def render_loss_curves(history_path: Path, image_path: Path) -> None:
    _render_history_curves(
        read_jsonl_history(history_path),
        image_path,
        LOSS_PLOT_SERIES,
        "DA3-Tok MAE-style RGB training loss curves",
        "History: loss_history.jsonl. Values are effective global-batch losses reduced across all ranks.",
    )


def render_metric_curves(history_path: Path, image_path: Path) -> None:
    _render_history_curves(
        read_jsonl_history(history_path),
        image_path,
        METRIC_PLOT_SERIES,
        "DA3-Tok MAE-style RGB validation metric curves",
        "History: val_metrics.jsonl. The fixed scene-stratified validation subset is reduced across all ranks.",
    )


def save_checkpoint(
    path: Path,
    model: DDP | DA3Tok,
    optimizer: torch.optim.Optimizer,
    scheduler: LambdaLR,
    step: int,
    microbatches_seen: int,
    args: argparse.Namespace,
    best_dev_loss: float,
    val_metrics: dict[str, Any],
) -> None:
    """Save trainable DA3-Tok state and an exact sampler stream position."""
    if not is_main_process():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "checkpoint_version": 4,
            "trainable_model": trainable_state_dict(model),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "step": step,
            "microbatches_seen": microbatches_seen,
            "best_dev_loss": best_dev_loss,
            "val_metrics": val_metrics,
            "args": vars(args),
            "frozen_encoder": {
                "da3_model_dir": str(args.da3_model_dir),
                "feature_layers": list(args.feature_layers),
                "feature_dim": args.feature_dim,
            },
        },
        path,
    )
    try:
        render_loss_curves(path.parent / "loss_history.jsonl", path.parent / "loss_curves.png")
    except Exception as error:
        print(f"warning: failed to render loss curves: {error}", flush=True)
    try:
        render_metric_curves(path.parent / "val_metrics.jsonl", path.parent / "metric_curves.png")
    except Exception as error:
        print(f"warning: failed to render metric curves: {error}", flush=True)



@torch.no_grad()
def validate(
    model: DDP | DA3Tok,
    criterion: DA3TokLoss,
    loader: DataLoader,
    device: torch.device,
    max_batches: int,
) -> dict[str, float]:
    model.eval()
    stats = torch.zeros(len(LOSS_COMPONENTS) * 2, dtype=torch.float64, device=device)
    for index, batch in enumerate(loader):
        if index >= max_batches:
            break
        batch = move_batch(batch, device)
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            output = model(batch["image_da3"], batch["intrinsics"], batch["world_to_camera"])
        values = criterion(output, batch)
        stats += loss_stats_tensor(values).to(device)
    if dist.is_initialized():
        dist.all_reduce(stats, op=dist.ReduceOp.SUM)
    model.train()
    return summarize_loss_stats(stats, criterion.weights)


@torch.no_grad()
def evaluate_val_metrics(
    model: DDP | DA3Tok,
    loader: DataLoader,
    device: torch.device,
    semantic_classes: int,
) -> dict[str, Any]:
    model.eval()
    accumulator = DenseMetricAccumulator(semantic_classes, device)
    for batch in loader:
        batch = move_batch(batch, device)
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            output = model(batch["image_da3"], batch["intrinsics"], batch["world_to_camera"])
        accumulator.update(output, batch)
    accumulator.synchronize()
    metrics = accumulator.compute()
    model.train()
    return metrics


def _iterator_at_microbatch(
    loader: DataLoader,
    sampler: DistributedSampler,
    microbatches_seen: int,
) -> tuple[int, Any]:
    """Recreate the deterministic rank-local stream at a saved microbatch count."""
    batches_per_epoch = len(loader)
    if batches_per_epoch == 0:
        raise RuntimeError("Train loader is empty after clip/label filtering")
    epoch, cursor = divmod(microbatches_seen, batches_per_epoch)
    sampler.set_epoch(epoch)
    iterator = iter(loader)
    for _ in range(cursor):
        next(iterator)
    return epoch, iterator


def main() -> None:
    args = parse_args()
    if args.loss_log_every <= 0:
        raise ValueError("--loss-log-every must be positive")
    if args.max_val_clips <= 0:
        raise ValueError("--max-val-clips must be positive")
    semantic_class_weights = validated_semantic_class_weights(
        args.semantic_class_weights, args.semantic_classes
    )
    rank, world_size, local_rank = setup_distributed()
    if world_size < 1:
        raise RuntimeError(f"DA3-Tok formal training requires at least one rank, got world_size={world_size}")
    device = torch.device("cuda", local_rank)
    seed_everything(args.seed, rank)
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    semantic_spec = SemanticLabelSpec.from_json(args.semantic_mapping)
    moge_spec = MoGeSourceSpec.from_json(args.moge_source_spec)
    if semantic_spec.classes != args.semantic_classes:
        raise ValueError("--semantic-classes must equal the verified semantic mapping classes")
    if semantic_spec.ignore_index != args.semantic_ignore_index:
        raise ValueError("--semantic-ignore-index must equal the verified semantic mapping ignore_index")
    dataset_kwargs = {
        "semantic_classes": args.semantic_classes,
        "semantic_ignore_index": args.semantic_ignore_index,
        "semantic_label_spec": semantic_spec,
        "moge_source_spec": moge_spec,
    }
    train_dataset = NuScenesFrontClipDataset(args.train_manifest, args.nuscenes_root, **dataset_kwargs)
    dev_dataset = NuScenesFrontClipDataset(args.dev_manifest, args.nuscenes_root, **dataset_kwargs)
    val_source_dataset = NuScenesFrontClipDataset(args.val_manifest, args.nuscenes_root, **dataset_kwargs)
    val_indices = select_scene_stratified_indices(val_source_dataset.records, args.max_val_clips)
    val_dataset = Subset(val_source_dataset, val_indices)
    train_sampler = DistributedSampler(train_dataset, num_replicas=world_size, rank=rank, shuffle=True, drop_last=True)
    dev_sampler = DistributedEvalSampler(dev_dataset)
    val_sampler = DistributedEvalSampler(val_dataset)
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.micro_batch_size,
        sampler=train_sampler,
        num_workers=args.workers,
        pin_memory=True,
        persistent_workers=args.workers > 0,
        drop_last=True,
    )
    dev_loader = DataLoader(
        dev_dataset,
        batch_size=args.micro_batch_size,
        sampler=dev_sampler,
        num_workers=args.workers,
        pin_memory=True,
        persistent_workers=args.workers > 0,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.micro_batch_size,
        sampler=val_sampler,
        num_workers=args.workers,
        pin_memory=True,
        persistent_workers=args.workers > 0,
    )
    if not len(train_loader):
        raise RuntimeError("Train loader is empty after clip/label filtering")

    model = DA3Tok(
        args.da3_model_dir,
        args.semantic_classes,
        frame_chunk_size=args.frame_chunk_size,
        feature_layers=args.feature_layers,
        feature_dim=args.feature_dim,
    ).to(device)
    model.train()
    ddp_model = DDP(model, device_ids=[local_rank], broadcast_buffers=False, find_unused_parameters=False)
    criterion = DA3TokLoss(
        semantic_ignore_index=args.semantic_ignore_index,
        semantic_class_weights=semantic_class_weights,
        use_lpips=not args.disable_lpips,
        weights=LossWeights(),
    ).to(device)
    trainable = [parameter for parameter in ddp_model.parameters() if parameter.requires_grad]
    optimizer = AdamW(trainable, lr=args.learning_rate, betas=(0.9, 0.95), weight_decay=args.weight_decay)
    scheduler = build_scheduler(optimizer, args.warmup_steps, args.steps)

    global_step = 0
    microbatches_seen = 0
    best_dev_loss = float("inf")
    latest_val_metrics: dict[str, Any] | None = None
    last_val_metric_step = -1
    last_checkpoint_step = -1
    if args.resume:
        checkpoint = torch.load(args.resume, map_location=device, weights_only=False)
        load_trainable_state_dict(ddp_model, checkpoint)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        global_step = int(checkpoint["step"])
        microbatches_seen = int(checkpoint.get("microbatches_seen", global_step * args.gradient_accumulation))
        best_dev_loss = float(checkpoint["best_dev_loss"])
        if checkpoint.get("val_metrics") is not None:
            latest_val_metrics = checkpoint["val_metrics"]
            last_val_metric_step = global_step

    if is_main_process():
        args.run_dir.mkdir(parents=True, exist_ok=True)
        (args.run_dir / "command.json").write_text(json.dumps(vars(args), indent=2, default=str), encoding="utf-8")
        val_selection = [
            {
                "manifest_index": index,
                "scene_name": val_source_dataset.records[index]["scene_name"],
                "centre_sample_token": val_source_dataset.records[index]["centre_sample_token"],
            }
            for index in val_indices
        ]
        (args.run_dir / "val_subset.json").write_text(
            json.dumps(val_selection, indent=2), encoding="utf-8"
        )
        print(
            f"trainable={sum(parameter.numel() for parameter in trainable):,}; "
            f"effective_global_clips={args.micro_batch_size * world_size * args.gradient_accumulation}; "
            f"val_clips={len(val_dataset)}"
        )

    epoch, iterator = _iterator_at_microbatch(train_loader, train_sampler, microbatches_seen)
    while global_step < args.steps:
        optimizer.zero_grad(set_to_none=True)
        accumulated_loss_stats = torch.zeros(len(LOSS_COMPONENTS) * 2, dtype=torch.float64, device=device)
        for accumulation_index in range(args.gradient_accumulation):
            try:
                batch = next(iterator)
            except StopIteration:
                epoch += 1
                train_sampler.set_epoch(epoch)
                iterator = iter(train_loader)
                batch = next(iterator)
            microbatches_seen += 1
            batch = move_batch(batch, device)
            sync_context = (
                ddp_model.no_sync()
                if accumulation_index < args.gradient_accumulation - 1
                else torch.enable_grad()
            )
            with sync_context:
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    output = ddp_model(batch["image_da3"], batch["intrinsics"], batch["world_to_camera"])
                losses = criterion(output, batch)
                loss = losses["total"] / args.gradient_accumulation
                loss.backward()
            accumulated_loss_stats += loss_stats_tensor(losses).to(device)
        torch.nn.utils.clip_grad_norm_(trainable, max_norm=1.0)
        optimizer.step()
        scheduler.step()
        global_step += 1

        if global_step % args.loss_log_every == 0:
            reduced_loss_stats = accumulated_loss_stats.detach().clone()
            if dist.is_initialized():
                dist.all_reduce(reduced_loss_stats, op=dist.ReduceOp.SUM)
            loss_log = summarize_loss_stats(reduced_loss_stats, criterion.weights)
            weights = ddp_model.module.fusion.weights.detach().float().cpu().tolist()
            if is_main_process():
                append_loss_history(args.run_dir, global_step, loss_log, optimizer)
                print(
                    f"step={global_step} loss={loss_log['total']:.4f} rgb={loss_log['rgb']:.4f} "
                    f"depth={loss_log['depth']:.4f} point={loss_log['point']:.4f} "
                    f"sem={loss_log['semantic']:.4f} weights={weights}"
                )
        new_best = False
        if global_step % args.validate_every == 0:
            dev = validate(ddp_model, criterion, dev_loader, device, args.max_dev_batches)
            new_best = dev["total"] < best_dev_loss
            if new_best:
                best_dev_loss = dev["total"]
            if is_main_process():
                print(f"dev step={global_step} {json.dumps(dev)}")
                with (args.run_dir / "dev_metrics.jsonl").open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps({"step": global_step, **dev}) + "\n")
        checkpoint_due = global_step % args.checkpoint_every == 0
        if new_best or checkpoint_due:
            latest_val_metrics = evaluate_val_metrics(
                ddp_model, val_loader, device, args.semantic_classes
            )
            last_val_metric_step = global_step
            if is_main_process():
                append_val_metrics(args.run_dir, global_step, latest_val_metrics)
                print(f"val step={global_step} {json.dumps(latest_val_metrics)}")
            if new_best:
                save_checkpoint(
                    args.run_dir / "best.pt", ddp_model, optimizer, scheduler,
                    global_step, microbatches_seen, args, best_dev_loss, latest_val_metrics,
                )
            if checkpoint_due:
                save_checkpoint(
                    args.run_dir / "last.pt", ddp_model, optimizer, scheduler,
                    global_step, microbatches_seen, args, best_dev_loss, latest_val_metrics,
                )
                last_checkpoint_step = global_step
    if last_val_metric_step != global_step:
        latest_val_metrics = evaluate_val_metrics(
            ddp_model, val_loader, device, args.semantic_classes
        )
        if is_main_process():
            append_val_metrics(args.run_dir, global_step, latest_val_metrics)
            print(f"val step={global_step} {json.dumps(latest_val_metrics)}")
    if latest_val_metrics is None:
        raise RuntimeError("Final checkpoint has no validation metrics")
    if last_checkpoint_step != global_step:
        save_checkpoint(
            args.run_dir / "last.pt", ddp_model, optimizer, scheduler,
            global_step, microbatches_seen, args, best_dev_loss, latest_val_metrics,
        )
    cleanup_distributed()


if __name__ == "__main__":
    main()
