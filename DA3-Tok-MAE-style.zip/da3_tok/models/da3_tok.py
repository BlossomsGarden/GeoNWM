"""End-to-end frozen-DA3 five-layer fusion model."""

from __future__ import annotations

from pathlib import Path
from collections.abc import Sequence

import torch
from torch import nn

from .da3_frozen import DA3FrozenEncoder
from .fusion import FiveLayerRAEv2Fusion
from .mae_rgb_head import MAERGBHeadConfig, MAEStyleRGBHead
from .spatial_decoder import SharedSpatialDecoder


class DA3Tok(nn.Module):
    """Frozen DA3 encoder with fused-token MAE RGB and dense geometry/semantic decoders."""

    def __init__(
        self,
        da3_model_dir: str | Path,
        semantic_classes: int,
        frame_chunk_size: int = 1,
        feature_layers: Sequence[int] = (3, 5, 7, 9, 11),
        feature_dim: int | None = None,
    ) -> None:
        super().__init__()
        self.encoder = DA3FrozenEncoder(da3_model_dir, layers=feature_layers, feature_dim=feature_dim)
        self.fusion = FiveLayerRAEv2Fusion(dim=self.encoder.feature_dim, layers=feature_layers)
        self.rgb_decoder = MAEStyleRGBHead(
            MAERGBHeadConfig(input_dim=self.encoder.feature_dim),
            frame_chunk_size=frame_chunk_size,
        )
        self.decoder = SharedSpatialDecoder(
            semantic_classes=semantic_classes,
            frame_chunk_size=frame_chunk_size,
            input_dim=self.encoder.feature_dim,
            predict_rgb=False,
        )

    def forward(
        self,
        image_da3: torch.Tensor,
        intrinsics: torch.Tensor,
        world_to_camera: torch.Tensor,
        frame_chunk_size: int | None = None,
    ) -> dict[str, torch.Tensor]:
        levels = self.encoder(image_da3, intrinsics, world_to_camera)
        fused_tokens, fusion_weights = self.fusion(levels)
        output = self.decoder(fused_tokens, frame_chunk_size=frame_chunk_size)
        output.update(self.rgb_decoder(fused_tokens, frame_chunk_size=frame_chunk_size))
        output["fusion_weights"] = fusion_weights
        return output

    def train(self, mode: bool = True) -> "DA3Tok":
        """Keep frozen DA3 submodules in eval mode even during decoder training."""
        super().train(mode)
        self.encoder.da3.eval()
        return self
