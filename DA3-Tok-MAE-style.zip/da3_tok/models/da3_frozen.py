"""Frozen DA3-BASE encoder exposing five DPT-compatible feature levels."""

from __future__ import annotations

from contextlib import nullcontext
from collections.abc import Sequence
from pathlib import Path

import torch
from torch import nn

DEFAULT_LAYERS = (3, 5, 7, 9, 11)


class DA3FrozenEncoder(nn.Module):
    """Load local DA3 and return five aligned `[B,T,N,C]` patch tensors.

    The official DA3 wrapper only requests its configured DPT layers. This
    adapter retains the frozen backbone/camera encoder, but asks the underlying
    ViT for the current BASE run's five layers directly. Returned tokens
    preserve DA3's dual feature layout: local channels concatenated with
    normalized global channels.
    """

    def __init__(
        self,
        model_dir: str | Path,
        layers: Sequence[int] = DEFAULT_LAYERS,
        feature_dim: int | None = None,
    ) -> None:
        super().__init__()
        if len(tuple(layers)) != 5:
            raise ValueError(f"DA3-Tok requires five feature layers, got {tuple(layers)}")
        model_dir = Path(model_dir)
        if not model_dir.is_dir():
            raise FileNotFoundError(f"DA3 model directory not found: {model_dir}")
        try:
            from depth_anything_3.api import DepthAnything3
        except ImportError as error:
            raise ImportError(
                "Could not import depth_anything_3. Add "
                "the DA3 source src directory, e.g. /data/wlh/DA3/code/Depth-Anything-3-main/src, "
                "to PYTHONPATH."
            ) from error
        self.layers = tuple(layers)
        # PyTorchModelHubMixin accepts a local snapshot directory containing the
        # official config.json and model.safetensors files; it does not download.
        self.da3 = DepthAnything3.from_pretrained(str(model_dir))
        self.backbone = self.da3.model.backbone
        self.camera_encoder = self.da3.model.cam_enc
        pretrained = self.backbone.pretrained
        embed_dim = int(getattr(pretrained, "embed_dim"))
        cat_token = bool(getattr(pretrained, "cat_token", False))
        self.feature_dim = int(feature_dim or (embed_dim * (2 if cat_token else 1)))
        self.patch_size = int(getattr(pretrained, "patch_size", 14))
        self._freeze()

    def _freeze(self) -> None:
        self.da3.eval()
        for parameter in self.da3.parameters():
            parameter.requires_grad_(False)

    @staticmethod
    def normalize_extrinsics(
        extrinsics: torch.Tensor,
        return_scales: bool = False,
    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        """Mirror DA3's first-view-relative normalization independently per clip.

        ``extrinsics`` is `[B,T,4,4]`; each clip gets its own median trajectory
        scale so camera tokens never depend on unrelated clips in the minibatch.
        """
        if extrinsics.ndim != 4 or extrinsics.shape[-2:] != (4, 4):
            raise ValueError(f"Expected [B,T,4,4] extrinsics, got {tuple(extrinsics.shape)}")
        if extrinsics.device.type in {"cuda", "cpu"}:
            autocast_disabled = torch.autocast(device_type=extrinsics.device.type, enabled=False)
        else:
            autocast_disabled = nullcontext()
        with autocast_disabled:
            extrinsics = extrinsics.float()
            reference_inverse = torch.linalg.inv(extrinsics[:, :1])
            normalized = extrinsics @ reference_inverse
            camera_to_world = torch.linalg.inv(normalized)
            distances = torch.linalg.vector_norm(camera_to_world[..., :3, 3], dim=-1)
            median_distance = torch.median(distances, dim=1, keepdim=True).values.clamp_min(1e-1)
            normalized = normalized.clone()
            normalized[..., :3, 3] = normalized[..., :3, 3] / median_distance[..., None]
        if return_scales:
            return normalized, median_distance.squeeze(1)
        return normalized

    def assert_frozen(self) -> None:
        trainable = [name for name, parameter in self.da3.named_parameters() if parameter.requires_grad]
        if trainable:
            raise RuntimeError(f"Frozen DA3 unexpectedly has trainable parameters: {trainable[:5]}")

    def forward(
        self,
        images: torch.Tensor,
        intrinsics: torch.Tensor,
        world_to_camera: torch.Tensor,
    ) -> tuple[torch.Tensor, ...]:
        """Encode all clip frames jointly without backbone autograd state."""
        if images.ndim != 5 or images.shape[2] != 3:
            raise ValueError(f"Expected images [B,T,3,H,W], got {tuple(images.shape)}")
        if images.shape[-2] % self.patch_size or images.shape[-1] % self.patch_size:
            raise ValueError(f"DA3 inputs must be divisible by patch size {self.patch_size}")
        if intrinsics.shape != (*images.shape[:2], 3, 3):
            raise ValueError(f"Expected intrinsics [B,T,3,3], got {tuple(intrinsics.shape)}")
        if world_to_camera.shape != (*images.shape[:2], 4, 4):
            raise ValueError(f"Expected world_to_camera [B,T,4,4], got {tuple(world_to_camera.shape)}")
        self.assert_frozen()
        normalized_extrinsics = self.normalize_extrinsics(world_to_camera)
        autocast_kwargs = {
            "device_type": images.device.type,
            "enabled": images.device.type == "cuda",
        }
        if images.device.type == "cuda":
            autocast_kwargs["dtype"] = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        # The vendored ViT names its final two input dimensions `w, h`, but
        # passes them to positional interpolation in that same order.  Supplying
        # ordinary `[B,T,3,H,W]` therefore correctly produces the 20×52 patch
        # grid for the non-square 280×728 DA3-Tok frame; do not transpose pixels.
        with torch.inference_mode(), torch.autocast(**autocast_kwargs):
            camera_token = self.camera_encoder(
                normalized_extrinsics.float(), intrinsics.float(), images.shape[-2:]
            )
            features, _ = self.backbone.pretrained.get_intermediate_layers(
                images,
                n=list(self.layers),
                cam_token=camera_token,
                ref_view_strategy="first",
            )
        patches = tuple(feature[0] for feature in features)
        expected_tokens = (images.shape[-2] // self.patch_size) * (images.shape[-1] // self.patch_size)
        expected_shape = (*images.shape[:2], expected_tokens, self.feature_dim)
        for layer, patch in zip(self.layers, patches):
            if tuple(patch.shape) != expected_shape:
                raise RuntimeError(
                    f"DA3 layer {layer} has shape {tuple(patch.shape)}, expected {expected_shape}; "
                    "verify the checkpoint, feature layers and feature_dim."
                )
        # Clone outside inference_mode. These tensors feed trainable decoder layers,
        # so they must be normal tensors that autograd can save for decoder backward.
        return tuple(patch.clone() for patch in patches)
