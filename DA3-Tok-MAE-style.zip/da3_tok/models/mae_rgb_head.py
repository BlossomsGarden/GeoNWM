"""MAE-style RGB decoder for fused DA3-Tok patch features."""

from __future__ import annotations

from dataclasses import dataclass
import os

import torch
from torch import nn

from da3_tok.geometry import TARGET_HEIGHT, TARGET_WIDTH

os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
os.environ.setdefault("TRANSFORMERS_NO_FLAX", "1")
os.environ.setdefault("USE_TF", "0")
os.environ.setdefault("USE_FLAX", "0")

try:
    from transformers import ViTMAEConfig
    from transformers.models.vit_mae.modeling_vit_mae import ViTMAELayer
except ImportError as error:  # pragma: no cover - exercised only in missing optional dependency envs.
    raise ImportError("Install transformers to use the MAE-style RGB head") from error


@dataclass(frozen=True)
class MAERGBHeadConfig:
    input_dim: int = 1536
    decoder_dim: int = 1152
    patch_size: int = 14
    decoder_layers: int = 28
    decoder_heads: int = 16
    decoder_mlp_dim: int = 4096
    target_height: int = TARGET_HEIGHT
    target_width: int = TARGET_WIDTH


def _sincos_1d(embed_dim: int, positions: torch.Tensor) -> torch.Tensor:
    if embed_dim % 2:
        raise ValueError(f"1D sin-cos embedding dimension must be even, got {embed_dim}")
    half = embed_dim // 2
    omega = torch.arange(half, dtype=torch.float32)
    omega = 1.0 / (10000 ** (omega / half))
    angles = positions.float().reshape(-1, 1) * omega.reshape(1, -1)
    return torch.cat([angles.sin(), angles.cos()], dim=1)


def build_2d_sincos_position_embedding(embed_dim: int, grid_height: int, grid_width: int) -> torch.Tensor:
    """Return fixed `[1, 1 + H*W, D]` CLS+patch positional embedding."""
    if embed_dim % 4:
        raise ValueError(f"2D sin-cos embedding dimension must be divisible by 4, got {embed_dim}")
    y, x = torch.meshgrid(
        torch.arange(grid_height, dtype=torch.float32),
        torch.arange(grid_width, dtype=torch.float32),
        indexing="ij",
    )
    patch_pos = torch.cat(
        [
            _sincos_1d(embed_dim // 2, y.reshape(-1)),
            _sincos_1d(embed_dim // 2, x.reshape(-1)),
        ],
        dim=1,
    )
    cls_pos = torch.zeros(1, embed_dim, dtype=torch.float32)
    return torch.cat([cls_pos, patch_pos], dim=0).unsqueeze(0)


class MAEStyleRGBHead(nn.Module):
    """Decode fused `[B,T,N,1536]` tokens to ImageNet-normalized RGB patches."""

    def __init__(self, config: MAERGBHeadConfig = MAERGBHeadConfig(), frame_chunk_size: int = 1) -> None:
        super().__init__()
        if config.target_height % config.patch_size or config.target_width % config.patch_size:
            raise ValueError(
                f"target size {(config.target_height, config.target_width)} must be divisible by "
                f"patch_size={config.patch_size}"
            )
        self.config = config
        self.frame_chunk_size = frame_chunk_size
        self.token_height = config.target_height // config.patch_size
        self.token_width = config.target_width // config.patch_size
        self.expected_tokens = self.token_height * self.token_width

        self.decoder_embed = nn.Linear(config.input_dim, config.decoder_dim, bias=True)
        self.trainable_cls_token = nn.Parameter(torch.zeros(1, 1, config.decoder_dim))
        self.register_buffer(
            "decoder_pos_embed",
            build_2d_sincos_position_embedding(config.decoder_dim, self.token_height, self.token_width),
            persistent=False,
        )

        decoder_config = ViTMAEConfig(
            hidden_size=config.decoder_dim,
            num_hidden_layers=config.decoder_layers,
            num_attention_heads=config.decoder_heads,
            intermediate_size=config.decoder_mlp_dim,
            hidden_act="gelu",
            hidden_dropout_prob=0.0,
            attention_probs_dropout_prob=0.0,
            layer_norm_eps=1e-12,
            qkv_bias=True,
        )
        self.decoder_layers = nn.ModuleList(ViTMAELayer(decoder_config) for _ in range(config.decoder_layers))
        self.decoder_norm = nn.LayerNorm(config.decoder_dim, eps=1e-12)
        self.decoder_pred = nn.Linear(config.decoder_dim, config.patch_size * config.patch_size * 3, bias=True)

        self.register_buffer("imagenet_mean", torch.tensor((0.485, 0.456, 0.406)).view(1, 3, 1, 1), persistent=False)
        self.register_buffer("imagenet_std", torch.tensor((0.229, 0.224, 0.225)).view(1, 3, 1, 1), persistent=False)
        self.initialize_weights()

    def initialize_weights(self) -> None:
        nn.init.normal_(self.trainable_cls_token, std=0.02)
        nn.init.xavier_uniform_(self.decoder_embed.weight)
        nn.init.zeros_(self.decoder_embed.bias)
        nn.init.xavier_uniform_(self.decoder_pred.weight)
        nn.init.zeros_(self.decoder_pred.bias)

    def _decode_flat_tokens(self, tokens: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        hidden_states = self.decoder_embed(tokens)
        cls_token = self.trainable_cls_token.expand(hidden_states.shape[0], -1, -1)
        hidden_states = torch.cat([cls_token, hidden_states], dim=1)
        hidden_states = hidden_states + self.decoder_pos_embed.to(device=hidden_states.device, dtype=hidden_states.dtype)

        for layer in self.decoder_layers:
            hidden_states = layer(hidden_states, head_mask=None, output_attentions=False)[0]

        hidden_states = self.decoder_norm(hidden_states)
        patch_logits = self.decoder_pred(hidden_states)[:, 1:, :]
        rgb_norm = self.unpatchify(patch_logits)
        rgb = rgb_norm * self.imagenet_std.to(dtype=rgb_norm.dtype) + self.imagenet_mean.to(dtype=rgb_norm.dtype)
        return rgb_norm, rgb

    def unpatchify(self, patchified_pixel_values: torch.Tensor) -> torch.Tensor:
        patch_size = self.config.patch_size
        expected_channels = patch_size * patch_size * 3
        if patchified_pixel_values.shape[1:] != (self.expected_tokens, expected_channels):
            raise ValueError(
                "Expected patchified RGB with shape "
                f"[N,{self.expected_tokens},{expected_channels}], got {tuple(patchified_pixel_values.shape)}"
            )
        batch = patchified_pixel_values.shape[0]
        values = patchified_pixel_values.reshape(
            batch,
            self.token_height,
            self.token_width,
            patch_size,
            patch_size,
            3,
        )
        values = torch.einsum("nhwpqc->nchpwq", values)
        return values.reshape(batch, 3, self.config.target_height, self.config.target_width)

    def forward(self, fused_tokens: torch.Tensor, frame_chunk_size: int | None = None) -> dict[str, torch.Tensor]:
        if fused_tokens.ndim != 4:
            raise ValueError(f"Expected [B,T,N,C] fused tokens, got {tuple(fused_tokens.shape)}")
        batch, frames, tokens, channels = fused_tokens.shape
        if tokens != self.expected_tokens or channels != self.config.input_dim:
            raise ValueError(
                f"Expected {self.expected_tokens} tokens with {self.config.input_dim} channels, got {tokens}x{channels}"
            )

        flat = fused_tokens.reshape(batch * frames, tokens, channels)
        chunk = frame_chunk_size or self.frame_chunk_size
        if chunk <= 0:
            raise ValueError("frame_chunk_size must be positive")
        rgb_norm_chunks: list[torch.Tensor] = []
        rgb_chunks: list[torch.Tensor] = []
        for start in range(0, flat.shape[0], chunk):
            rgb_norm, rgb = self._decode_flat_tokens(flat[start : start + chunk])
            rgb_norm_chunks.append(rgb_norm)
            rgb_chunks.append(rgb)

        rgb_norm_out = torch.cat(rgb_norm_chunks, dim=0).reshape(batch, frames, 3, self.config.target_height, self.config.target_width)
        rgb_out = torch.cat(rgb_chunks, dim=0).reshape(batch, frames, 3, self.config.target_height, self.config.target_width)
        return {"rgb_norm": rgb_norm_out, "rgb": rgb_out}
