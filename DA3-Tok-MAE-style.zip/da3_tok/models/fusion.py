"""RAEv2-style five-layer elementwise DA3 feature fusion."""

from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import nn


class FiveLayerRAEv2Fusion(nn.Module):
    """Fuse five aligned DA3 layers into one aligned token tensor.

    Each selected layer has an independent LayerNorm.  Learned scalar softmax
    weights retain the RAEv2 elementwise-addition constraint: no feature concat,
    no hidden channel expansion, and no token pooling.  The final layer's mean
    token is broadcast back as the DINOv3 RAEv2 global-context term.
    """

    def __init__(self, dim: int = 1536, layers: Sequence[int] = (3, 5, 7, 9, 11)) -> None:
        super().__init__()
        if len(layers) != 5:
            raise ValueError(f"DA3-Tok requires five layers, got {tuple(layers)}")
        self.layers = tuple(layers)
        self.norms = nn.ModuleList(nn.LayerNorm(dim) for _ in self.layers)
        self.layer_logits = nn.Parameter(torch.zeros(len(self.layers)))

    @property
    def weights(self) -> torch.Tensor:
        return self.layer_logits.softmax(dim=0)

    def forward(self, features: Sequence[torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        if len(features) != len(self.layers):
            raise ValueError(f"Expected {len(self.layers)} feature levels, got {len(features)}")
        shape = features[0].shape
        if len(shape) != 4:
            raise ValueError(f"Expected [B,T,N,C] features, got {tuple(shape)}")
        normalized = []
        for layer, norm, feature in zip(self.layers, self.norms, features):
            if feature.shape != shape:
                raise ValueError(
                    f"Layer {layer} has {tuple(feature.shape)}, expected all levels to align with {tuple(shape)}"
                )
            normalized.append(norm(feature))
        weights = self.weights.to(device=normalized[0].device, dtype=normalized[0].dtype)
        fused = torch.zeros_like(normalized[0])
        for weight, feature in zip(weights, normalized):
            fused = fused + weight * feature
        fused = fused + normalized[-1].mean(dim=2, keepdim=True)
        return fused, weights
