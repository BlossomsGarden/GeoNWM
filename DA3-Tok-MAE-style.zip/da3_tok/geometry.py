"""Shared image geometry, camera transforms, and depth-derived point geometry.

All DA3-Tok modalities live in the same target camera frame.  The target frame is
constructed by scaling the *raw camera width* to TARGET_WIDTH and centre-cropping
vertically.  Keeping the affine matrix explicit prevents the common error of
resizing depth/labels to the right shape while leaving intrinsics inconsistent.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterable, Sequence

import torch
import torch.nn.functional as F

TARGET_HEIGHT = 280
TARGET_WIDTH = 728


@dataclass(frozen=True)
class PixelTransform:
    """An affine mapping from source pixel homogeneous coordinates to target ones."""

    source_width: int
    source_height: int
    target_width: int
    target_height: int
    matrix: torch.Tensor
    resize_width: int
    resize_height: int
    crop_x: int
    crop_y: int

    def to(self, device: torch.device | str, dtype: torch.dtype = torch.float32) -> "PixelTransform":
        return PixelTransform(
            self.source_width,
            self.source_height,
            self.target_width,
            self.target_height,
            self.matrix.to(device=device, dtype=dtype),
            self.resize_width,
            self.resize_height,
            self.crop_x,
            self.crop_y,
        )

    def transform_intrinsics(self, intrinsics: torch.Tensor) -> torch.Tensor:
        """Apply this pixel-space affine matrix to ``[..., 3, 3]`` intrinsics."""
        matrix = self.matrix.to(device=intrinsics.device, dtype=intrinsics.dtype)
        return matrix @ intrinsics


def load_affine_matrix(path: str | Path, key: str = "raw_to_pixels") -> torch.Tensor:
    """Load a confirmed 3×3 raw-camera-to-preprocessed-pixels matrix from JSON."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    matrix = torch.as_tensor(payload[key], dtype=torch.float32)
    if matrix.shape != (3, 3):
        raise ValueError(f"{path}:{key} must be a 3×3 matrix, got {tuple(matrix.shape)}")
    return matrix


def width_center_crop_transform(
    source_width: int,
    source_height: int,
    target_height: int = TARGET_HEIGHT,
    target_width: int = TARGET_WIDTH,
) -> PixelTransform:
    """Return the requested width-proportional resize plus centred vertical crop.

    This intentionally uses one uniform scale (``target_width / source_width``)
    for x and y.  It must not use independent height/width scales: that would make
    camera intrinsics incompatible with the RGB/depth/semantic image transform.
    """
    if source_width <= 0 or source_height <= 0:
        raise ValueError(f"Invalid source size {(source_width, source_height)}")
    scale = target_width / float(source_width)
    resize_height = int(round(source_height * scale))
    if resize_height < target_height:
        raise ValueError(
            "Width-proportional resize is too short for the target crop: "
            f"source={(source_width, source_height)}, target={(target_width, target_height)}, "
            f"resized height={resize_height}. Use a documented source transform instead."
        )
    crop_y = int(round((resize_height - target_height) / 2.0))
    crop_x = 0
    matrix = torch.tensor(
        [[scale, 0.0, -float(crop_x)], [0.0, scale, -float(crop_y)], [0.0, 0.0, 1.0]],
        dtype=torch.float32,
    )
    return PixelTransform(
        source_width=source_width,
        source_height=source_height,
        target_width=target_width,
        target_height=target_height,
        matrix=matrix,
        resize_width=target_width,
        resize_height=resize_height,
        crop_x=crop_x,
        crop_y=crop_y,
    )


def compose_transforms(first: PixelTransform, second: PixelTransform) -> torch.Tensor:
    """Return the affine matrix applying ``first`` then ``second``."""
    return second.matrix @ first.matrix


def target_from_source_matrix(source_raw_to_pixels: torch.Tensor, target_raw_to_pixels: torch.Tensor) -> torch.Tensor:
    """Map a source preprocessed frame into the target preprocessed frame.

    ``source_raw_to_pixels`` and ``target_raw_to_pixels`` both map the raw camera
    frame into their own pixel frames.  The returned matrix maps source pixels to
    target pixels, i.e. ``A_target @ inverse(A_source)``.
    """
    return target_raw_to_pixels @ torch.linalg.inv(source_raw_to_pixels)


def _as_bchw(image: torch.Tensor) -> tuple[torch.Tensor, int]:
    if image.ndim == 2:
        return image[None, None], 2
    if image.ndim == 3:
        return image[None], 3
    if image.ndim == 4:
        return image, 4
    raise ValueError(f"Expected [H,W], [C,H,W], or [B,C,H,W], got {tuple(image.shape)}")


def _restore_input_rank(image: torch.Tensor, original_rank: int) -> torch.Tensor:
    if original_rank == 2:
        return image.squeeze(0).squeeze(0)
    if original_rank == 3:
        return image.squeeze(0)
    return image


def resize_width_center_crop(
    image: torch.Tensor,
    transform: PixelTransform,
    mode: str,
) -> torch.Tensor:
    """Apply a width resize and vertical crop to an image/mask tensor."""
    image_bchw, original_rank = _as_bchw(image)
    kwargs: dict[str, object] = {"size": (transform.resize_height, transform.resize_width), "mode": mode}
    if mode in {"bilinear", "bicubic"}:
        kwargs["align_corners"] = False
    resized = F.interpolate(image_bchw, **kwargs)
    cropped = resized[
        ...,
        transform.crop_y : transform.crop_y + transform.target_height,
        transform.crop_x : transform.crop_x + transform.target_width,
    ]
    return _restore_input_rank(cropped, original_rank)


def warp_preprocessed_frame(
    image: torch.Tensor,
    source_to_target: torch.Tensor,
    target_height: int = TARGET_HEIGHT,
    target_width: int = TARGET_WIDTH,
    mode: str = "bilinear",
) -> torch.Tensor:
    """Warp a source-frame tensor into target-frame pixels with an affine map.

    ``source_to_target`` maps source pixels to target pixels.  ``grid_sample``
    needs target-to-source coordinates, so inversion is deliberately local and
    explicit. With ``align_corners=True``, integer pixel coordinates map exactly.
    """
    image_bchw, original_rank = _as_bchw(image)
    batch, _, source_height, source_width = image_bchw.shape
    inverse = torch.linalg.inv(source_to_target.to(image_bchw.device, image_bchw.dtype))
    yy, xx = torch.meshgrid(
        torch.arange(target_height, device=image_bchw.device, dtype=image_bchw.dtype),
        torch.arange(target_width, device=image_bchw.device, dtype=image_bchw.dtype),
        indexing="ij",
    )
    target = torch.stack((xx, yy, torch.ones_like(xx)), dim=-1)
    source = target @ inverse.T
    source_xy = source[..., :2] / source[..., 2:].clamp_min(torch.finfo(image_bchw.dtype).eps)
    if source_width == 1:
        x_norm = torch.zeros_like(source_xy[..., 0])
    else:
        x_norm = 2.0 * source_xy[..., 0] / float(source_width - 1) - 1.0
    if source_height == 1:
        y_norm = torch.zeros_like(source_xy[..., 1])
    else:
        y_norm = 2.0 * source_xy[..., 1] / float(source_height - 1) - 1.0
    grid = torch.stack((x_norm, y_norm), dim=-1).unsqueeze(0).expand(batch, -1, -1, -1)
    sample_mode = "nearest" if mode == "nearest" else "bilinear"
    warped = F.grid_sample(
        image_bchw,
        grid,
        mode=sample_mode,
        padding_mode="zeros",
        align_corners=True,
    )
    return _restore_input_rank(warped, original_rank)


def warp_depth_and_mask(
    depth: torch.Tensor,
    valid_mask: torch.Tensor,
    source_to_target: torch.Tensor,
    target_height: int = TARGET_HEIGHT,
    target_width: int = TARGET_WIDTH,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Warp dense depth bilinearly and validity nearest-neighbour into target frame."""
    if depth.shape[-2:] != valid_mask.shape[-2:]:
        raise ValueError("Depth and valid mask must share spatial size")
    warped_depth = warp_preprocessed_frame(
        depth, source_to_target, target_height, target_width, mode="bilinear"
    )
    warped_mask = warp_preprocessed_frame(
        valid_mask.to(dtype=warped_depth.dtype),
        source_to_target,
        target_height,
        target_width,
        mode="nearest",
    ) > 0.5
    warped_depth = torch.where(warped_mask, warped_depth, torch.zeros_like(warped_depth))
    return warped_depth, warped_mask


def backproject_depth(depth: torch.Tensor, intrinsics: torch.Tensor) -> torch.Tensor:
    """Backproject ``[B,1,H,W]`` metric depth to camera-frame ``[B,3,H,W]`` points.

    Geometry is intentionally evaluated in FP32: ``torch.linalg.solve`` is not
    supported consistently for BF16 and should not inherit decoder AMP dtype.
    """
    if depth.ndim != 4 or depth.shape[1] != 1:
        raise ValueError(f"Expected depth [B,1,H,W], got {tuple(depth.shape)}")
    if intrinsics.shape != (depth.shape[0], 3, 3):
        raise ValueError(f"Expected intrinsics [B,3,3], got {tuple(intrinsics.shape)}")
    depth = depth.float()
    intrinsics = intrinsics.float()
    batch, _, height, width = depth.shape
    yy, xx = torch.meshgrid(
        torch.arange(height, device=depth.device, dtype=depth.dtype),
        torch.arange(width, device=depth.device, dtype=depth.dtype),
        indexing="ij",
    )
    pixels = torch.stack((xx, yy, torch.ones_like(xx)), dim=0).reshape(1, 3, -1)
    rays = torch.linalg.solve(intrinsics, pixels.expand(batch, -1, -1))
    return rays.reshape(batch, 3, height, width) * depth


def camera_point_errors(
    prediction: torch.Tensor,
    target: torch.Tensor,
    valid_mask: torch.Tensor,
) -> dict[str, torch.Tensor]:
    """Return masked 3D, axial-z, and lateral-xy errors per camera frame."""
    if prediction.shape != target.shape or prediction.ndim != 4 or prediction.shape[1] != 3:
        raise ValueError("Prediction and target must both be [B,3,H,W]")
    valid = valid_mask.squeeze(1).bool()
    values = {"l2": [], "z": [], "xy": []}
    for pred, truth, mask in zip(prediction, target, valid):
        if not mask.any():
            zero = pred.new_zeros(())
            for key in values:
                values[key].append(zero)
            continue
        diff = pred[:, mask] - truth[:, mask]
        values["l2"].append(torch.linalg.vector_norm(diff, dim=0).mean())
        values["z"].append(diff[2].abs().mean())
        values["xy"].append(torch.linalg.vector_norm(diff[:2], dim=0).mean())
    return {key: torch.stack(value) for key, value in values.items()}


def flatten_video_frames(video: torch.Tensor) -> torch.Tensor:
    """Convert ``[B,T,C,H,W]`` to metric-friendly ``[B*T,C,H,W]``."""
    if video.ndim != 5:
        raise ValueError(f"Expected [B,T,C,H,W], got {tuple(video.shape)}")
    return video.flatten(0, 1)
