"""DA3-Tok MAE-style RGB variant with frozen DA3-BASE feature fusion."""

from .geometry import TARGET_HEIGHT, TARGET_WIDTH

__all__ = ["TARGET_HEIGHT", "TARGET_WIDTH"]
