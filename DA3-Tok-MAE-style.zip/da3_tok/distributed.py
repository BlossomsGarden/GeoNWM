"""Minimal single-node DDP helpers for DA3-Tok training."""

from __future__ import annotations

import os
from collections.abc import Iterator
from typing import Protocol

import torch
import torch.distributed as dist
from torch.utils.data import Sampler


def setup_distributed() -> tuple[int, int, int]:
    """Initialize NCCL from torchrun environment and return rank/world/local rank."""
    if "RANK" not in os.environ:
        raise RuntimeError("DA3-Tok DDP entry points must be launched with torchrun.")
    local_rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(local_rank)
    dist.init_process_group(backend="nccl")
    return dist.get_rank(), dist.get_world_size(), local_rank


def is_distributed() -> bool:
    return dist.is_available() and dist.is_initialized()


def rank() -> int:
    return dist.get_rank() if is_distributed() else 0


def world_size() -> int:
    return dist.get_world_size() if is_distributed() else 1


def is_main_process() -> bool:
    return rank() == 0


def barrier() -> None:
    if is_distributed():
        dist.barrier()


def reduce_sum(tensor: torch.Tensor) -> torch.Tensor:
    output = tensor.detach().clone()
    if is_distributed():
        dist.all_reduce(output, op=dist.ReduceOp.SUM)
    return output


def cleanup_distributed() -> None:
    if is_distributed():
        dist.destroy_process_group()


class DistributedEvalSampler(Sampler[int]):
    """Partition validation indices without DistributedSampler's padding repeats."""

    def __init__(self, dataset: Sized) -> None:  # type: ignore[name-defined]
        self.dataset = dataset
        self._rank = rank()
        self._world_size = world_size()

    def __iter__(self) -> Iterator[int]:
        return iter(range(self._rank, len(self.dataset), self._world_size))

    def __len__(self) -> int:
        return (len(self.dataset) + self._world_size - self._rank - 1) // self._world_size


class Sized(Protocol):
    def __len__(self) -> int: ...
