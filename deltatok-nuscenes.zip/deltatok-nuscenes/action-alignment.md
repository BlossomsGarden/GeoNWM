# Action-Aligned Transition Bottleneck

本文档定义 DeltaTok 在 nuScenes 上的动作对齐方案。这里不主张严格的因果分解，也不把 Fano 不等式作为主证明线；主训练目标仍然是连续回归 + Huber loss。动作对齐模块的定位是：让残差 token 显式承载 `t-1 -> t` 的 ego-motion 信息，并让 decoder 只能通过残差 token 去利用这部分信息。

## 1. 动作定义

令 `a_{t-1}` 表示从 `t-1` 到 `t` 的相对运动，定义为三维连续量：

```math
a_{t-1} = [\Delta x_{t-1\to t}, \Delta y_{t-1\to t}, \Delta \psi_{t-1\to t}]
```

其中：

- `\Delta x`：在上一帧 ego 坐标系下的前向位移，单位 meter
- `\Delta y`：在上一帧 ego 坐标系下的侧向位移，单位 meter；遵循 nuScenes ego 坐标系，左向（`+y`）为正
- `\Delta \psi`：绕 `z` 轴的相对偏航角，单位 degree

nuScenes 侧的实现应基于相邻两帧 `ego_pose` 计算，并在进入 tokenizer 前做归一化或标准化。

## 2. 参考 Epona 的动作编码方式

动作 token 的构造尽量沿用 [Epona.txt](0606-lightworldpred/Epona.txt) 和 [epona-main](sources/epona-main/) 的写法，但不照搬其离散化训练目标。对每个分量分别做 Fourier embedding，再经独立 projector 映射到 Transformer hidden size。

推荐流程如下：

```text
Δx    -> normalize/clip -> Fourier embedding -> MLP_x   -> A_x
Δy    -> normalize/clip -> Fourier embedding -> MLP_y   -> A_y
Δyaw  -> normalize/clip -> Fourier embedding -> MLP_yaw -> A_yaw
```

实现约束：

- `A_x, A_y, A_yaw` 各自都是一个 token，形状均为 `[B, 1, C]`
- 每个分量使用独立 projector，不共享参数
- Fourier embedding 后接两层 MLP，再接 `LayerNorm`
- token 进入 encoder 前应附加 type embedding，避免三者在表示上完全同构
- yaw 使用周期性编码，避免 `-pi` / `pi` 附近不连续

关于 Epona 的单位约定，代码里 `yaws_to_indices()` 用的是 degree 量纲；文档和实现都应显式写成 `degree`，不要混用弧度。

## 3. Action-conditioned tokenizer

这里采用 action-conditioned tokenizer，而不是只在训练时喂动作。

也就是说，推理阶段同样提供 `a_{t-1}`。这样做的原因很直接：我们不是想让模型“猜”当前动作，而是想让模型在给定动作条件下，把视觉变化压缩到 residual token 中。

### 推荐嵌入实现

动作输入先做标准化，再分别做 Fourier embedding：

```math
\tilde a_j = \operatorname{clip}((a_j - \mu_j)/\sigma_j, [-c, c])
```

```math
\phi_j(a_j) = [\sin(\omega_k \tilde a_j), \cos(\omega_k \tilde a_j)]_{k=1}^{m}
```

实现沿用 Epona 的频率尺度 `\omega_k = 100^{k/m}`，不额外乘 `2\pi`；否则标准化值相差整数时会产生完全相同的编码。对 yaw 先按 degree wrap 到 `[-180, 180)`，再进行标准化与 Fourier embedding。

```math
A_j = \operatorname{LN}(\operatorname{MLP}_j(\phi_j(a_j)))
```

这里的 `\mu_j, \sigma_j, c` 由训练集统计得到；若后续发现动作分布偏态明显，可以保留 clip 但放宽统计窗口。

## 4. DeltaTok 的动作对齐结构

设 DINO-Tok AE fused latent 为：

```math
U_{t-1}, U_t \in \mathbb{R}^{N \times 832}
```

其中：

- `256` 分辨率时 `N = 16 \times 16 = 256`
- `512` 分辨率时 `N = 32 \times 32 = 1024`

令 `K` 为 learnable delta token 数量，通过命令行传入，默认 `1`。

### Encoder 输入顺序

建议拼接顺序为：

```text
[delta queries, action tokens, previous latent, current latent]
```

即：

```math
H_{enc} = [Q_1, \ldots, Q_K, A_x, A_y, A_{yaw}, U_{t-1}, U_t]
```

约束：

- `Q_k` 是可学习 query slot
- `A_x, A_y, A_yaw` 只作为 encoder 条件，不进入 decoder
- 2D RoPE 只作用于图像 latent token
- action token 和 delta query token 不使用图像空间位置编码

### Residual token 输出

残差 token 从前 `K` 个 query 位置读出：

```math
Z_t = \operatorname{LN}(H_{enc}[:, :K]) \in \mathbb{R}^{B \times K \times 832}
```

注意这里应当是 `:K`，不是从第 1 个位置开始切片。否则会把第一个 delta query 丢掉。

### Decoder 输入

decoder 只接收：

```text
[Z_t, U_{t-1} + E_prev]
```

不再把 action tokens 喂回 decoder。这样做是为了避免 decoder 直接绕开 residual token 使用动作信息。

decoder 输出仍然复用冻结的 DINO-Tok RGB decoder 做可视化：

```math
\hat I_t = D_{RGB}(\hat U_t)
```

这部分只用于验证阶段的旁路定性可视化，不参与训练 loss，也不作为第三个主验证目标。

## 5. Action alignment loss

这里不把离散 Fano bound 作为主证明。主训练信号使用连续 Huber 回归：

```math
\hat a_{t-1\to t} = g_\phi(\operatorname{pool}(Z_t))
```

```math
\mathcal L_{motion} = \operatorname{Huber}(\hat a_{t-1\to t}, \tilde a_{t-1\to t})
```

其中 `pool(Z_t)` 可以先用 mean pooling；如果后续 `K > 1` 的消融发现 mean pooling 太弱，再替换成轻量 attention pooling，但先不引入额外复杂度。

### 为什么不做逐维硬对齐

不建议直接写成 `\|Z_t - E(a_t)\|_2` 作为主目标。原因是 latent space 有旋转、缩放、重参数化自由度，逐维对齐没有稳定理论基础，也会把任务变成一个过于僵硬的表征匹配问题。

### 论文表述建议

更稳妥的表述是：

> residual tokens are explicitly aligned with, and predictive of, ego-motion-conditioned visual transitions.

也就是说，强调“可预测、对齐、承载动作信息”，而不是宣称“严格因果分解”。

## 6. 可选分析实验

Fano 相关分析可以保留，但只作为辅助分析，不做主证明线。可做的实验包括：

- motion bin accuracy
- continuous motion MAE / RMSE / `R^2`
- 不同 `K` 下的下游重建质量
- residual token 线性 probe / small MLP probe 的动作回归性能
- action token 去除、action-conditioned tokenizer 去除、decoder 重新注入 action 的 ablation

如果后续确实要写信息论分析，建议将其定位为“表征容量上界的辅助讨论”，不要把整篇方法建立在它上面。

## 7. 需要避免的说法

- 不要写成 residual token 严格等于动作造成的变化量
- 不要写成 decoder 也必须接收 action token 才能工作
- 不要把离散化后的 Fano 证明写成方法主干
- 不要把 `K=1` 视为固定设定，`K` 必须可配置

## 8. 一句话总结

这个模块更适合被定义为：

```text
3D local ego-motion
    -> Epona-style action-conditioned tokenizer
    -> DeltaTok encoder
    -> K learnable residual tokens
    -> motion Huber alignment on pooled residuals
    -> decoder only sees previous fused latent + residual tokens
    -> frozen DINO-Tok RGB decoder for visualization
```
