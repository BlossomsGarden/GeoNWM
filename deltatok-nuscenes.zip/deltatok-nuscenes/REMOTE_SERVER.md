# Remote Server

ip: 10.0.20.33

port: 22

user_name: wlh

password: wlh@2025

connect-tool: paramiko or scp

project_dir: /data/wlh/DeltaWorld

model_dir: /data/wlh/DeltaWorld/model/

nuscenes_dir: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval

samples_train_csv_dir: /data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv

samples_val_csv_dir: /data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv

conda_dir: /data/wlh/miniconda3

conda_env_name: deltaworld

## Runtime contract

- CSV rows provide the image file field, so image loading uses the CSV path directly. Relative paths are resolved under `nuscenes_dir`.
- The server layout is intentionally nested: images are under `nuscenes_dir/samples`, and metadata JSON files are under `nuscenes_dir/v1.0-trainval`.
- The dataset filters `cam=FRONT` or `cam=CAM_FRONT`, sorts by `scene_id/frame_id`, and creates consecutive keyframe pairs.
- `ego_pose.json` is read only to compute `[Delta x, Delta y, Delta yaw]` online.
- `Delta y` follows the nuScenes ego convention, so leftward motion (`+y`) is positive.
- Large metadata JSON files are parsed incrementally with `ijson`; only required poses and `CAM_FRONT` calibration entries are retained.
- `CAM_FRONT` pair preprocessing is principal-point aligned and works for both 256 and 512 square inputs.

## DINO-Tok weights

The local checkout does not contain model weights. On the server, download the DINO-Tok AE checkpoint through the domestic mirror into:

```text
/data/wlh/DeltaWorld/model/dinotok/aetok.pt
```

Example:

```bash
mkdir -p /data/wlh/DeltaWorld/model/dinotok
HF_ENDPOINT=https://hf-mirror.com \
  /data/wlh/miniconda3/envs/deltaworld/bin/huggingface-cli download \
  mkjia/DINO-Tok aetok.pt \
  --local-dir /data/wlh/DeltaWorld/model/dinotok
```

The existing DINOv3 checkpoint is expected at:

```text
/data/wlh/DeltaWorld/model/dinov3-vitb16-pretrain-lvd1689m
```

Install the incremental JSON parser in the existing environment without changing the Torch stack:

```bash
/data/wlh/miniconda3/envs/deltaworld/bin/python -m pip install ijson
```

## Two-GPU smoke run

Before the long run, exercise one real DDP train batch and one validation batch:

```bash
cd /data/wlh/DeltaWorld
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate deltaworld
export CUDA_VISIBLE_DEVICES=2,3

WANDB_MODE=disabled python main.py fit \
  -c configs/deltatok_nuscenes_256.yaml \
  --trainer.devices=2 \
  --trainer.strategy=ddp \
  --trainer.fast_dev_run=1
```

## Two-GPU DDP launch

The current server inspection found GPUs 2 and 3 idle. Use them explicitly:

```bash
cd /data/wlh/DeltaWorld
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate deltaworld
export CUDA_VISIBLE_DEVICES=2,3

WANDB_MODE=offline python main.py fit \
  -c configs/deltatok_nuscenes_256.yaml \
  --trainer.devices=2 \
  --trainer.strategy=ddp \
  --trainer.max_steps=1000000
```

After the 256 run, start the 512 fine-tune with the stage-1 model weights:

```bash
export CUDA_VISIBLE_DEVICES=2,3
WANDB_MODE=offline python main.py fit \
  -c configs/deltatok_nuscenes_512.yaml \
  --model.ckpt_path=/path/to/stage1/last.ckpt \
  --trainer.devices=2 \
  --trainer.strategy=ddp \
  --trainer.max_steps=500000
```

The nuScenes validation path is one-step pairwise. It reports latent loss and motion loss; RGB decoding, latent PCA, and optional last-768-channel semantic/depth heads are qualitative visualizations only.
