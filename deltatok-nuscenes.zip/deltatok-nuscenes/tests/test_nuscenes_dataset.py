from __future__ import annotations

import csv
import json

import numpy as np
import torch
from PIL import Image

import datasets.nuscenes as nuscenes_module
from datasets.nuscenes import NuScenesTrain


class FakeGMFlow:
    def __call__(self, image0: torch.Tensor, image1: torch.Tensor) -> torch.Tensor:
        if image0.ndim == 3:
            image0 = image0.unsqueeze(0)
        if image1.ndim == 3:
            image1 = image1.unsqueeze(0)
        _, _, height, width = image0.shape
        flow = torch.zeros(1, 2, height, width)
        flow[:, 0] = 2.0
        return flow


def write_json(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")


def test_nuscenes_item_returns_residual_flow_target(tmp_path, monkeypatch):
    nuscenes_root = tmp_path / "nuscenes"
    image_dir = nuscenes_root / "samples" / "CAM_FRONT"
    metadata_dir = nuscenes_root / "v1.0-trainval"
    depth_dir = tmp_path / "depth" / "CAM_FRONT"
    image_dir.mkdir(parents=True)
    metadata_dir.mkdir(parents=True)
    depth_dir.mkdir(parents=True)

    intrinsic = [[4.0, 0.0, 3.5], [0.0, 4.0, 3.5], [0.0, 0.0, 1.0]]
    calibration = {
        "token": "calibration",
        "translation": [0.0, 0.0, 0.0],
        "rotation": [1.0, 0.0, 0.0, 0.0],
        "camera_intrinsic": intrinsic,
    }
    sample_data = []
    ego_poses = []
    rows = []
    for frame_id in (0, 1):
        stem = f"frame{frame_id}"
        filename = f"samples/CAM_FRONT/{stem}.jpg"
        Image.fromarray(np.full((8, 8, 3), 80 + frame_id, dtype=np.uint8)).save(
            image_dir / f"{stem}.jpg"
        )
        np.savez(
            depth_dir / f"{stem}.npz",
            depth=np.full((8, 8), 10.0, dtype=np.float32),
            mask=np.ones((8, 8), dtype=np.uint8),
            intrinsics=np.asarray(intrinsic, dtype=np.float32),
        )
        pose_token = f"pose{frame_id}"
        sample_data.append(
            {
                "token": f"sample{frame_id}",
                "filename": filename,
                "calibrated_sensor_token": "calibration",
                "ego_pose_token": pose_token,
                "width": 8,
                "height": 8,
            }
        )
        ego_poses.append(
            {
                "token": pose_token,
                "translation": [0.0, 0.0, 0.0],
                "rotation": [1.0, 0.0, 0.0, 0.0],
            }
        )
        rows.append(
            {
                "id": str(frame_id),
                "frame_id": str(frame_id),
                "scene_id": "scene",
                "cam": "FRONT",
                "file": f"{stem}.jpg",
                "ego_pose_token": pose_token,
            }
        )

    write_json(metadata_dir / "sample_data.json", sample_data)
    write_json(metadata_dir / "calibrated_sensor.json", [calibration])
    write_json(metadata_dir / "ego_pose.json", ego_poses)
    csv_path = tmp_path / "samples.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    monkeypatch.setattr(
        nuscenes_module, "get_gmflow_estimator", lambda *args, **kwargs: FakeGMFlow()
    )
    dataset = NuScenesTrain(
        csv_path=str(csv_path),
        nuscenes_root=str(nuscenes_root),
        depth_root=str(tmp_path / "depth"),
        gmflow_checkpoint_path="unused-for-fake",
        gmflow_device="cpu",
        frame_size=8,
        optical_flow_size=4,
        optical_flow_quantile=0.8,
    )
    frames, action, flow, mask = dataset[0]

    assert frames.shape == (2, 3, 8, 8)
    assert action.shape == (3,)
    assert flow.shape == (2, 4, 4)
    assert mask.shape == (4, 4)
    assert mask.any()
    assert torch.allclose(flow[0][mask], torch.full_like(flow[0][mask], 2.0))
