from __future__ import annotations

import torch

from datasets.optical_flow import (
    build_crop_geometry,
    build_residual_flow,
    compute_ego_flow,
    downsample_flow_and_mask,
)


def identity_pose():
    return {"rotation": [1.0, 0.0, 0.0, 0.0], "translation": [0.0, 0.0, 0.0]}


def identity_camera():
    return {"rotation": [1.0, 0.0, 0.0, 0.0], "translation": [0.0, 0.0, 0.0]}


def test_static_identity_pose_has_zero_ego_flow():
    intrinsic = torch.tensor(
        [[4.0, 0.0, 3.5], [0.0, 4.0, 3.5], [0.0, 0.0, 1.0]]
    )
    geometry = build_crop_geometry((8, 8), intrinsic, 8)
    flow, valid = compute_ego_flow(
        depth=torch.full((8, 8), 10.0),
        depth_mask=torch.ones((8, 8), dtype=torch.bool),
        prev_depth_intrinsic=intrinsic,
        curr_depth_intrinsic=intrinsic,
        prev_pose=identity_pose(),
        curr_pose=identity_pose(),
        camera_calibration=identity_camera(),
        geometry=geometry,
    )
    assert valid.all()
    assert torch.allclose(flow, torch.zeros_like(flow), atol=1.0e-5)


def test_forward_ego_translation_moves_static_points_left_in_image():
    intrinsic = torch.tensor(
        [[4.0, 0.0, 3.5], [0.0, 4.0, 3.5], [0.0, 0.0, 1.0]]
    )
    geometry = build_crop_geometry((8, 8), intrinsic, 8)
    curr_pose = {"rotation": [1.0, 0.0, 0.0, 0.0], "translation": [1.0, 0.0, 0.0]}
    flow, valid = compute_ego_flow(
        depth=torch.full((8, 8), 10.0),
        depth_mask=torch.ones((8, 8), dtype=torch.bool),
        prev_depth_intrinsic=intrinsic,
        curr_depth_intrinsic=intrinsic,
        prev_pose=identity_pose(),
        curr_pose=curr_pose,
        camera_calibration=identity_camera(),
        geometry=geometry,
    )
    assert valid[4, 4]
    assert torch.isclose(flow[0, 4, 4], torch.tensor(-0.4), atol=1.0e-4)
    assert torch.isclose(flow[1, 4, 4], torch.tensor(0.0), atol=1.0e-5)


def test_residual_mask_uses_residual_magnitude_and_downsample_keeps_pixel_units():
    raw = torch.zeros(2, 4, 4)
    ego = torch.zeros_like(raw)
    raw[0, 0, 0] = 100.0
    ego[0, 0, 0] = 100.0
    raw[0, 3, 3] = 2.0
    ego[0, 3, 3] = -13.0
    valid = torch.ones(4, 4, dtype=torch.bool)

    residual, mask, residual_valid = build_residual_flow(
        raw, ego, valid, quantile=0.8
    )
    assert residual_valid.all()
    assert mask[3, 3]
    assert not mask[0, 0]

    target, target_mask = downsample_flow_and_mask(
        residual, mask, target_size=2
    )
    assert target.shape == (2, 2, 2)
    assert target_mask.any()
    assert torch.isclose(target[0, 1, 1], torch.tensor(15.0), atol=1.0e-5)
