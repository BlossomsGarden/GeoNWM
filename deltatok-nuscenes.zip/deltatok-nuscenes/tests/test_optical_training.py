from __future__ import annotations

import torch

from models.optical_probe import ResidualFlowProbe
from training.deltatok import masked_flow_loss


def test_residual_flow_probe_outputs_configured_grid_from_k8_tokens():
    probe = ResidualFlowProbe(
        hidden_size=832,
        query_size=32,
        output_size=128,
        num_heads=13,
        depth=0,
    )
    residual = torch.randn(1, 8, 832)
    prediction = probe(residual)
    assert prediction.shape == (1, 2, 128, 128)
    assert torch.isfinite(prediction).all()


def test_masked_flow_loss_ignores_invalid_pixels_and_empty_masks_are_finite():
    prediction = torch.zeros(1, 2, 2, 2)
    target = torch.zeros_like(prediction)
    target[:, 0, 0, 0] = 10.0
    valid = torch.tensor([[[True, False], [False, False]]])
    loss = masked_flow_loss(prediction, target, valid)
    assert torch.isclose(loss, torch.tensor(4.75), atol=1.0e-5)

    empty_loss = masked_flow_loss(prediction, target, torch.zeros_like(valid))
    assert torch.isfinite(empty_loss)
    assert empty_loss.item() == 0.0
