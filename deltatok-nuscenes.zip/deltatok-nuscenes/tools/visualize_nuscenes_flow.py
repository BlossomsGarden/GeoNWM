from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw


PROJECT_ROOT = Path(__file__).resolve().parents[1]
GMFLOW_SOURCE_ROOT = PROJECT_ROOT / "third_party" / "gmflow-main"
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(GMFLOW_SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(GMFLOW_SOURCE_ROOT))

from third_party.gmflow import GMFlowOnlineEstimator
from utils.flow_viz import flow_to_image


CAM_FRONT_NAMES = {"FRONT", "CAM_FRONT"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Visualize GMFlow, nuScenes ego flow, and residual flow."
    )
    parser.add_argument(
        "--csv-path",
        default="/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv",
    )
    parser.add_argument(
        "--nuscenes-root",
        default="/data2/DATA/AutoDrive/nuscenes/v1.0-trainval",
    )
    parser.add_argument(
        "--depth-root",
        default="/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth",
    )
    parser.add_argument(
        "--checkpoint",
        default="/data/wlh/DeltaWorld/model/pretrained/gmflow_sintel-0c07dcb3.pth",
    )
    parser.add_argument(
        "--output-dir",
        default="/data/wlh/DeltaWorld/outputs/nuscenes_flow_visualization",
    )
    parser.add_argument("--scene-id", default=None)
    parser.add_argument("--frame-id", type=int, default=None)
    parser.add_argument("--image-size", type=int, default=512)
    parser.add_argument("--quantile", type=float, default=0.8)
    parser.add_argument("--device", default="cuda:0")
    return parser.parse_args()


def quat_to_rotation(quaternion: list[float]) -> np.ndarray:
    w, x, y, z = map(float, quaternion)
    return np.asarray(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def make_transform(rotation: np.ndarray, translation: list[float]) -> np.ndarray:
    transform = np.eye(4, dtype=np.float64)
    transform[:3, :3] = rotation
    transform[:3, 3] = np.asarray(translation, dtype=np.float64)
    return transform


def choose_pair(rows: list[dict[str, str]], scene_id: str | None, frame_id: int | None):
    grouped: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        if row.get("cam") in CAM_FRONT_NAMES:
            grouped.setdefault(row["scene_id"], []).append(row)
    for scene_rows in grouped.values():
        scene_rows.sort(key=lambda row: int(row["frame_id"]))

    for current_scene, scene_rows in grouped.items():
        if scene_id is not None and current_scene != scene_id:
            continue
        for prev, curr in zip(scene_rows, scene_rows[1:]):
            if int(curr["frame_id"]) != int(prev["frame_id"]) + 1:
                continue
            if frame_id is not None and int(prev["frame_id"]) != frame_id:
                continue
            return prev, curr
    raise ValueError("Could not find the requested consecutive CAM_FRONT pair")


def load_metadata(
    metadata_root: Path,
    filenames: set[str],
    pose_tokens: set[str],
) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    with (metadata_root / "sample_data.json").open("r", encoding="utf-8") as handle:
        sample_data = {
            item["filename"]: item
            for item in json.load(handle)
            if item.get("filename") in filenames
        }
    with (metadata_root / "calibrated_sensor.json").open(
        "r", encoding="utf-8"
    ) as handle:
        calibrated = {item["token"]: item for item in json.load(handle)}
    with (metadata_root / "ego_pose.json").open("r", encoding="utf-8") as handle:
        poses = {
            item["token"]: item
            for item in json.load(handle)
            if item.get("token") in pose_tokens
        }
    return sample_data, calibrated, poses


def resolve_image_path(nuscenes_root: Path, filename: str) -> Path:
    raw = Path(filename)
    if raw.is_absolute() and raw.exists():
        return raw
    candidates = (nuscenes_root / raw, nuscenes_root / "samples" / "CAM_FRONT" / raw.name)
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"Could not resolve image {filename!r}: {candidates}")


def resize_then_principal_crop(
    image: np.ndarray,
    intrinsic: np.ndarray,
    output_size: int,
) -> tuple[np.ndarray, dict[str, float | int]]:
    height, width = image.shape[:2]
    scale = output_size / min(height, width)
    resized_height = max(output_size, int(round(height * scale)))
    resized_width = max(output_size, int(round(width * scale)))
    resized = cv2.resize(
        image, (resized_width, resized_height), interpolation=cv2.INTER_AREA
    )

    principal_x = float(intrinsic[0, 2]) * scale
    principal_y = float(intrinsic[1, 2]) * scale
    crop_left = int(round(principal_x - output_size / 2.0))
    crop_top = int(round(principal_y - output_size / 2.0))
    right = crop_left + output_size
    bottom = crop_top + output_size
    pad_left = max(0, -crop_left)
    pad_top = max(0, -crop_top)
    pad_right = max(0, right - resized_width)
    pad_bottom = max(0, bottom - resized_height)
    if pad_left or pad_top or pad_right or pad_bottom:
        resized = np.pad(
            resized,
            ((pad_top, pad_bottom), (pad_left, pad_right), (0, 0)),
            mode="edge",
        )
        crop_left += pad_left
        crop_top += pad_top

    cropped = resized[crop_top : crop_top + output_size, crop_left : crop_left + output_size]
    geometry = {
        "scale": scale,
        "resized_width": resized_width,
        "resized_height": resized_height,
        "original_crop_left": crop_left - pad_left,
        "original_crop_top": crop_top - pad_top,
        "pad_left": pad_left,
        "pad_top": pad_top,
        "original_width": width,
        "original_height": height,
    }
    return cropped, geometry


def sample_depth_to_model_grid(
    depth: np.ndarray,
    depth_mask: np.ndarray,
    model_size: int,
    geometry: dict[str, float | int],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    depth_height, depth_width = depth.shape
    original_width = float(geometry["original_width"])
    original_height = float(geometry["original_height"])
    scale = float(geometry["scale"])
    crop_left = float(geometry["original_crop_left"])
    crop_top = float(geometry["original_crop_top"])
    resized_width = int(geometry["resized_width"])
    resized_height = int(geometry["resized_height"])

    yy, xx = np.mgrid[0:model_size, 0:model_size].astype(np.float32)
    resized_x = xx + crop_left
    resized_y = yy + crop_top
    source_valid = (
        (resized_x >= 0)
        & (resized_x <= resized_width - 1)
        & (resized_y >= 0)
        & (resized_y <= resized_height - 1)
    )
    original_x = resized_x / scale
    original_y = resized_y / scale
    depth_x = original_x * (depth_width / original_width)
    depth_y = original_y * (depth_height / original_height)

    sampled_depth = cv2.remap(
        depth.astype(np.float32),
        depth_x,
        depth_y,
        interpolation=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )
    sampled_mask = cv2.remap(
        depth_mask.astype(np.uint8),
        depth_x,
        depth_y,
        interpolation=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    ).astype(bool)
    sampled_mask &= source_valid
    return sampled_depth, sampled_mask, depth_x, depth_y


def compute_ego_flow(
    depth: np.ndarray,
    depth_mask: np.ndarray,
    depth_intrinsic: np.ndarray,
    prev_pose: dict[str, Any],
    curr_pose: dict[str, Any],
    camera: dict[str, Any],
    model_size: int,
    geometry: dict[str, float | int],
) -> tuple[np.ndarray, np.ndarray]:
    sampled_depth, sampled_mask, depth_x, depth_y = sample_depth_to_model_grid(
        depth, depth_mask, model_size, geometry
    )
    yy, xx = np.mgrid[0:model_size, 0:model_size].astype(np.float64)
    pixels = np.stack(
        (depth_x.astype(np.float64), depth_y.astype(np.float64), np.ones_like(depth_x)),
        axis=0,
    ).reshape(3, -1)
    points_prev = (
        np.linalg.inv(depth_intrinsic) @ pixels * sampled_depth.reshape(1, -1)
    )

    camera_to_ego = make_transform(
        quat_to_rotation(camera["rotation"]), camera["translation"]
    )
    prev_ego_to_world = make_transform(
        quat_to_rotation(prev_pose["rotation"]), prev_pose["translation"]
    )
    curr_ego_to_world = make_transform(
        quat_to_rotation(curr_pose["rotation"]), curr_pose["translation"]
    )
    prev_camera_to_world = prev_ego_to_world @ camera_to_ego
    curr_world_to_camera = np.linalg.inv(curr_ego_to_world @ camera_to_ego)
    prev_to_curr = curr_world_to_camera @ prev_camera_to_world

    points_prev_h = np.concatenate(
        (points_prev, np.ones((1, points_prev.shape[1]), dtype=np.float64)), axis=0
    )
    points_curr = (prev_to_curr @ points_prev_h)[:3]
    z_curr = points_curr[2]
    projected = depth_intrinsic @ points_curr
    projected_x = projected[0] / np.maximum(z_curr, 1.0e-8)
    projected_y = projected[1] / np.maximum(z_curr, 1.0e-8)

    scale = float(geometry["scale"])
    crop_left = float(geometry["original_crop_left"])
    crop_top = float(geometry["original_crop_top"])
    original_width = float(geometry["original_width"])
    original_height = float(geometry["original_height"])
    depth_height, depth_width = depth.shape
    current_resized_x = projected_x * (original_width / depth_width) * scale
    current_resized_y = projected_y * (original_height / depth_height) * scale
    current_x = current_resized_x - crop_left
    current_y = current_resized_y - crop_top

    flow = np.stack(
        (current_x - xx.reshape(-1), current_y - yy.reshape(-1)), axis=1
    ).reshape(model_size, model_size, 2)
    valid = sampled_mask.reshape(-1)
    valid &= np.isfinite(sampled_depth.reshape(-1))
    valid &= sampled_depth.reshape(-1) > 0
    valid &= np.isfinite(z_curr)
    valid &= z_curr > 0
    valid &= np.isfinite(current_x) & np.isfinite(current_y)
    valid &= current_x >= 0
    valid &= current_x < model_size
    valid &= current_y >= 0
    valid &= current_y < model_size
    valid = valid.reshape(model_size, model_size)
    flow[~valid] = 0
    return flow.astype(np.float32), valid


def flow_stats(flow: np.ndarray, valid: np.ndarray) -> dict[str, float | int]:
    magnitude = np.linalg.norm(flow, axis=-1)
    values = magnitude[valid & np.isfinite(magnitude)]
    if values.size == 0:
        return {"valid_pixels": 0}
    return {
        "valid_pixels": int(values.size),
        "valid_fraction": float(values.size / magnitude.size),
        "mean_magnitude": float(values.mean()),
        "p50_magnitude": float(np.percentile(values, 50)),
        "p90_magnitude": float(np.percentile(values, 90)),
        "max_magnitude": float(values.max()),
        "mean_u": float(flow[..., 0][valid].mean()),
        "mean_v": float(flow[..., 1][valid].mean()),
    }


def magnitude_image(flow: np.ndarray, vmax: float) -> np.ndarray:
    magnitude = np.linalg.norm(flow, axis=-1)
    scaled = np.clip(magnitude / max(vmax, 1.0e-6), 0, 1)
    return cv2.applyColorMap(np.uint8(scaled * 255), cv2.COLORMAP_TURBO)[:, :, ::-1]


def mask_overlay(image: np.ndarray, mask: np.ndarray) -> np.ndarray:
    overlay = image.astype(np.float32).copy()
    red = np.zeros_like(overlay)
    red[..., 0] = 255
    overlay[mask] = 0.35 * overlay[mask] + 0.65 * red[mask]
    return np.uint8(np.clip(overlay, 0, 255))


def add_label(image: np.ndarray, label: str) -> Image.Image:
    result = Image.fromarray(image)
    draw = ImageDraw.Draw(result)
    draw.rectangle((0, 0, 240, 24), fill=(0, 0, 0))
    draw.text((8, 5), label, fill=(255, 255, 255))
    return result


def make_overview(images: list[tuple[str, np.ndarray]]) -> Image.Image:
    labeled = [add_label(image, label) for label, image in images]
    width, height = labeled[0].size
    columns = 3
    rows = math.ceil(len(labeled) / columns)
    canvas = Image.new("RGB", (columns * width, rows * height), (32, 32, 32))
    for index, image in enumerate(labeled):
        canvas.paste(image, ((index % columns) * width, (index // columns) * height))
    return canvas


def save_image(path: Path, image: np.ndarray | Image.Image) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(image, Image.Image):
        image.save(path)
    else:
        Image.fromarray(image).save(path)


def main() -> None:
    args = parse_args()
    if not 0 < args.quantile < 1:
        raise ValueError("--quantile must be between 0 and 1")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    csv_path = Path(args.csv_path)
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        prev_row, curr_row = choose_pair(
            list(csv.DictReader(handle)), args.scene_id, args.frame_id
        )

    nuscenes_root = Path(args.nuscenes_root)
    metadata_root = nuscenes_root / "v1.0-trainval"
    filenames = {
        f"samples/CAM_FRONT/{Path(prev_row['file']).name}",
        f"samples/CAM_FRONT/{Path(curr_row['file']).name}",
    }
    sample_data, calibrated, poses = load_metadata(
        metadata_root,
        filenames,
        {prev_row["ego_pose_token"], curr_row["ego_pose_token"]},
    )

    prev_key = f"samples/CAM_FRONT/{Path(prev_row['file']).name}"
    curr_key = f"samples/CAM_FRONT/{Path(curr_row['file']).name}"
    prev_record = sample_data[prev_key]
    curr_record = sample_data[curr_key]
    if prev_record["calibrated_sensor_token"] != curr_record["calibrated_sensor_token"]:
        raise ValueError("The pair uses different calibrated sensors")
    camera = calibrated[prev_record["calibrated_sensor_token"]]
    intrinsic = np.asarray(camera["camera_intrinsic"], dtype=np.float64)

    frame_images = []
    geometries = []
    for row in (prev_row, curr_row):
        image_path = resolve_image_path(nuscenes_root, row["file"])
        with Image.open(image_path) as image:
            raw_image = np.asarray(image.convert("RGB"))
        processed, geometry = resize_then_principal_crop(
            raw_image, intrinsic, args.image_size
        )
        frame_images.append(processed)
        geometries.append(geometry)
    if geometries[0] != geometries[1]:
        raise ValueError("The two frames do not share the same image geometry")
    geometry = geometries[0]

    depth_root = Path(args.depth_root) / "CAM_FRONT"
    depth_data = []
    for row in (prev_row, curr_row):
        depth_path = depth_root / f"{Path(row['file']).stem}.npz"
        with np.load(depth_path) as data:
            depth_data.append(
                (
                    data["depth"].astype(np.float32),
                    data["mask"].astype(bool),
                    data["intrinsics"].astype(np.float64),
                )
            )
    if not np.allclose(depth_data[0][2], depth_data[1][2], atol=1.0e-4):
        raise ValueError("The pair uses different depth-grid intrinsics")
    depth_intrinsic = depth_data[0][2]

    estimator = GMFlowOnlineEstimator(
        checkpoint_path=args.checkpoint,
        device=args.device,
    )
    frame_tensor = torch.from_numpy(np.stack(frame_images)).permute(0, 3, 1, 2)
    with torch.inference_mode():
        raw_flow = estimator(frame_tensor[0], frame_tensor[1])[0]
    raw_flow = raw_flow.detach().float().cpu().permute(1, 2, 0).numpy()
    if raw_flow.shape[:2] != (args.image_size, args.image_size):
        raise ValueError(f"Unexpected GMFlow shape: {raw_flow.shape}")

    ego_flow, ego_valid = compute_ego_flow(
        depth=depth_data[0][0],
        depth_mask=depth_data[0][1],
        depth_intrinsic=depth_intrinsic,
        prev_pose=poses[prev_row["ego_pose_token"]],
        curr_pose=poses[curr_row["ego_pose_token"]],
        camera=camera,
        model_size=args.image_size,
        geometry=geometry,
    )
    raw_valid = np.isfinite(raw_flow).all(axis=-1)
    raw_flow[~raw_valid] = 0
    residual_flow = raw_flow - ego_flow
    residual_valid = raw_valid & ego_valid

    raw_magnitude = np.linalg.norm(raw_flow, axis=-1)
    finite_raw = raw_magnitude[raw_valid]
    motion_threshold = float(np.quantile(finite_raw, args.quantile))
    motion_mask = raw_valid & (raw_magnitude >= motion_threshold)

    shared_vmax = max(
        float(np.percentile(np.linalg.norm(raw_flow, axis=-1)[raw_valid], 99)),
        float(np.percentile(np.linalg.norm(ego_flow, axis=-1)[ego_valid], 99))
        if ego_valid.any()
        else 0.0,
        float(np.percentile(np.linalg.norm(residual_flow, axis=-1)[residual_valid], 99))
        if residual_valid.any()
        else 0.0,
        1.0,
    )
    raw_color = flow_to_image(raw_flow.copy())
    ego_color = flow_to_image(ego_flow.copy())
    residual_color = flow_to_image(residual_flow.copy())
    images = [
        ("prev frame", frame_images[0]),
        ("curr frame", frame_images[1]),
        ("depth valid", np.repeat(ego_valid[..., None] * 255, 3, axis=-1).astype(np.uint8)),
        ("raw GMFlow", raw_color),
        ("ego-only flow", ego_color),
        ("residual flow", residual_color),
        ("raw magnitude", magnitude_image(raw_flow, shared_vmax)),
        ("ego magnitude", magnitude_image(ego_flow, shared_vmax)),
        ("residual magnitude", magnitude_image(residual_flow, shared_vmax)),
        (f"raw >= p{args.quantile:.2f}", mask_overlay(frame_images[0], motion_mask)),
        ("residual on raw mask", mask_overlay(residual_color, motion_mask & residual_valid)),
        ("residual valid", np.repeat(residual_valid[..., None] * 255, 3, axis=-1).astype(np.uint8)),
    ]
    save_image(output_dir / "overview.png", make_overview(images))
    save_image(output_dir / "prev_frame.png", frame_images[0])
    save_image(output_dir / "curr_frame.png", frame_images[1])
    save_image(output_dir / "raw_flow_color.png", raw_color)
    save_image(output_dir / "ego_flow_color.png", ego_color)
    save_image(output_dir / "residual_flow_color.png", residual_color)
    save_image(output_dir / "raw_magnitude.png", magnitude_image(raw_flow, shared_vmax))
    save_image(output_dir / "ego_magnitude.png", magnitude_image(ego_flow, shared_vmax))
    save_image(output_dir / "residual_magnitude.png", magnitude_image(residual_flow, shared_vmax))
    save_image(output_dir / "raw_motion_mask_overlay.png", mask_overlay(frame_images[0], motion_mask))
    save_image(output_dir / "depth_valid.png", np.repeat(ego_valid[..., None] * 255, 3, axis=-1).astype(np.uint8))
    np.savez_compressed(
        output_dir / "flows.npz",
        raw_flow=raw_flow,
        ego_flow=ego_flow,
        residual_flow=residual_flow,
        ego_valid=ego_valid,
        raw_valid=raw_valid,
        residual_valid=residual_valid,
        motion_mask=motion_mask,
    )

    stats = {
        "prev": prev_row,
        "curr": curr_row,
        "image_geometry": geometry,
        "depth_shape": list(depth_data[0][0].shape),
        "depth_intrinsic": depth_intrinsic.tolist(),
        "motion_threshold_raw_pixels": motion_threshold,
        "shared_magnitude_vmax": shared_vmax,
        "raw": flow_stats(raw_flow, raw_valid),
        "ego": flow_stats(ego_flow, ego_valid),
        "residual": flow_stats(residual_flow, residual_valid),
        "residual_on_raw_motion_mask": flow_stats(
            residual_flow, motion_mask & residual_valid
        ),
    }
    with (output_dir / "stats.json").open("w", encoding="utf-8") as handle:
        json.dump(stats, handle, indent=2, ensure_ascii=True)
    print(json.dumps(stats, indent=2, ensure_ascii=True))
    print(f"overview={output_dir / 'overview.png'}")


if __name__ == "__main__":
    main()
