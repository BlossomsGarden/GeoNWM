from __future__ import annotations

import csv
import json
import logging
import math
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import ijson
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

from datasets.base import as_hw, resize_then_principal_crop
from datasets.optical_flow import (
    build_crop_geometry,
    prepare_optical_flow_target,
)
from third_party.gmflow import get_gmflow_estimator


CAM_FRONT_NAMES = {"FRONT", "CAM_FRONT"}


@dataclass(frozen=True)
class SampleRow:
    scene_id: str
    frame_id: int
    file: str
    ego_pose_token: str


def _load_token_map(path: Path) -> dict[str, dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return {item["token"]: item for item in json.load(handle)}


def _load_selected_token_map(
    path: Path, tokens: set[str]
) -> dict[str, dict[str, Any]]:
    remaining = set(tokens)
    selected: dict[str, dict[str, Any]] = {}
    with path.open("rb") as handle:
        for item in ijson.items(handle, "item"):
            token = item.get("token")
            if token not in remaining:
                continue
            selected[token] = item
            remaining.remove(token)
            if not remaining:
                break
    if remaining:
        examples = sorted(remaining)[:5]
        raise KeyError(
            f"{path} is missing {len(remaining)} requested tokens; examples: {examples}"
        )
    return selected


@lru_cache(maxsize=4)
def _load_cam_front_calibrations(
    sample_data_path_str: str, calibrated_sensor_path_str: str
) -> dict[str, dict[str, Any]]:
    sample_data_path = Path(sample_data_path_str)
    calibrated_sensor_path = Path(calibrated_sensor_path_str)
    if not sample_data_path.exists() or not calibrated_sensor_path.exists():
        return {}

    calibrated = _load_token_map(calibrated_sensor_path)
    calibrations: dict[str, dict[str, Any]] = {}
    with sample_data_path.open("rb") as handle:
        for item in ijson.items(handle, "item"):
            filename = str(item.get("filename", ""))
            if "CAM_FRONT" not in Path(filename).parts:
                continue
            sensor = calibrated.get(item.get("calibrated_sensor_token"))
            matrix = sensor.get("camera_intrinsic") if sensor else None
            if not matrix or sensor is None:
                continue
            value = np.asarray(matrix, dtype=np.float32)
            calibration = {
                "camera_intrinsic": value,
                "translation": list(sensor["translation"]),
                "rotation": list(sensor["rotation"]),
                "width": int(item["width"]),
                "height": int(item["height"]),
            }
            calibrations[filename] = calibration
            calibrations[Path(filename).name] = calibration
    return calibrations


@lru_cache(maxsize=4)
def _load_cam_front_intrinsics(
    sample_data_path_str: str, calibrated_sensor_path_str: str
) -> dict[str, np.ndarray]:
    calibrations = _load_cam_front_calibrations(
        sample_data_path_str, calibrated_sensor_path_str
    )
    return {
        filename: calibration["camera_intrinsic"]
        for filename, calibration in calibrations.items()
    }


def _quat_to_rotation(quaternion: list[float]) -> np.ndarray:
    w, x, y, z = map(float, quaternion)
    return np.asarray(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def compute_action(prev_pose: dict[str, Any], curr_pose: dict[str, Any]) -> torch.Tensor:
    """Return [forward meters, lateral meters, relative yaw degrees]."""
    prev_rotation = _quat_to_rotation(prev_pose["rotation"])
    curr_rotation = _quat_to_rotation(curr_pose["rotation"])
    delta_global = np.asarray(curr_pose["translation"], dtype=np.float64) - np.asarray(
        prev_pose["translation"], dtype=np.float64
    )
    delta_prev = prev_rotation.T @ delta_global
    relative_rotation = prev_rotation.T @ curr_rotation
    delta_yaw = math.degrees(
        math.atan2(relative_rotation[1, 0], relative_rotation[0, 0])
    )
    return torch.tensor(
        [delta_prev[0], delta_prev[1], delta_yaw], dtype=torch.float32
    )


class _NuScenesPairDataset(Dataset):
    def __init__(
        self,
        csv_path: str,
        nuscenes_root: str,
        frame_size: int | tuple[int, int] = 256,
        gmflow_checkpoint_path: str | None = None,
        gmflow_device: str = "cpu",
        depth_root: str | None = None,
        optical_frame_size: int | tuple[int, int] = 512,
        optical_flow_size: int | tuple[int, int] | None = None,
        optical_flow_quantile: float = 0.8,
        ego_pose_path: str | None = None,
        sample_data_path: str | None = None,
        calibrated_sensor_path: str | None = None,
    ) -> None:
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.frame_size = as_hw(frame_size)
        self.optical_frame_size = as_hw(optical_frame_size)
        metadata_root = self.nuscenes_root / "v1.0-trainval"
        self.ego_pose_path = Path(ego_pose_path or metadata_root / "ego_pose.json")
        self.sample_data_path = Path(
            sample_data_path or metadata_root / "sample_data.json"
        )
        self.calibrated_sensor_path = Path(
            calibrated_sensor_path or metadata_root / "calibrated_sensor.json"
        )
        if depth_root is None:
            raise ValueError("depth_root is required for MoGe ego-flow compensation")
        self.depth_root = Path(depth_root)
        if not self.depth_root.exists():
            raise FileNotFoundError(f"MoGe depth root does not exist: {self.depth_root}")
        if gmflow_checkpoint_path is None:
            raise ValueError("gmflow_checkpoint_path is required for online GMFlow")
        self.flow_target_size = as_hw(
            optical_flow_size
            if optical_flow_size is not None
            else self.frame_size[0] // 4
        )
        self.flow_quantile = float(optical_flow_quantile)
        rows_by_scene = self._build_rows()
        pose_tokens = {
            row.ego_pose_token
            for rows in rows_by_scene.values()
            for row in rows
        }
        self.ego_poses = _load_selected_token_map(self.ego_pose_path, pose_tokens)
        self.camera_calibrations = _load_cam_front_calibrations(
            str(self.sample_data_path.resolve()),
            str(self.calibrated_sensor_path.resolve()),
        )
        if not self.camera_calibrations:
            raise FileNotFoundError(
                f"No CAM_FRONT calibration records found in {self.sample_data_path}"
            )
        self.intrinsics_by_file = self._load_intrinsics()
        self.flow_estimator = get_gmflow_estimator(
            gmflow_checkpoint_path,
            device=gmflow_device,
        )
        self.pairs = self._build_pairs(rows_by_scene)

    def _load_intrinsics(self) -> dict[str, np.ndarray]:
        intrinsics = _load_cam_front_intrinsics(
            str(self.sample_data_path.resolve()),
            str(self.calibrated_sensor_path.resolve()),
        )
        if not intrinsics:
            raise FileNotFoundError(
                f"No CAM_FRONT intrinsics loaded from {self.sample_data_path}"
            )
        return intrinsics

    def _camera_calibration(self, row: SampleRow) -> dict[str, Any]:
        calibration = self.camera_calibrations.get(row.file)
        if calibration is None:
            calibration = self.camera_calibrations.get(Path(row.file).name)
        if calibration is None:
            raise KeyError(f"No CAM_FRONT calibration found for {row.file}")
        return calibration

    def _load_depth_record(
        self, row: SampleRow
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        depth_path = self.depth_root / "CAM_FRONT" / f"{Path(row.file).stem}.npz"
        if not depth_path.exists():
            raise FileNotFoundError(f"MoGe depth file does not exist: {depth_path}")
        with np.load(depth_path) as data:
            for key in ("depth", "mask", "intrinsics"):
                if key not in data:
                    raise KeyError(f"Missing {key!r} in MoGe depth file {depth_path}")
            depth = np.asarray(data["depth"], dtype=np.float32)
            mask = np.asarray(data["mask"], dtype=np.uint8).astype(bool)
            intrinsic = np.asarray(data["intrinsics"], dtype=np.float32)
        if depth.ndim != 2 or mask.shape != depth.shape:
            raise ValueError(
                f"Invalid MoGe depth/mask shapes in {depth_path}: "
                f"{depth.shape} and {mask.shape}"
            )
        if intrinsic.shape != (3, 3):
            raise ValueError(
                f"Invalid MoGe intrinsics shape in {depth_path}: {intrinsic.shape}"
            )
        return (
            torch.from_numpy(depth.copy()),
            torch.from_numpy(mask.copy()),
            torch.from_numpy(intrinsic.copy()),
        )

    def _resolve_image_path(self, filename: str) -> Path:
        path = Path(filename)
        if path.is_absolute():
            return path
        candidates = (
            self.nuscenes_root / path,
            self.nuscenes_root / "samples" / "CAM_FRONT" / path.name,
        )
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(
            f"Could not resolve CSV image path {filename!r}; tried {candidates}"
        )

    def _build_rows(self) -> dict[str, list[SampleRow]]:
        grouped: dict[str, list[SampleRow]] = {}
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            for raw in csv.DictReader(handle):
                if raw.get("cam") not in CAM_FRONT_NAMES:
                    continue
                filename = raw["file"]
                row = SampleRow(
                    scene_id=raw["scene_id"],
                    frame_id=int(raw["frame_id"]),
                    file=filename,
                    ego_pose_token=raw["ego_pose_token"],
                )
                grouped.setdefault(row.scene_id, []).append(row)
        for rows in grouped.values():
            rows.sort(key=lambda row: row.frame_id)
        return grouped

    def _build_pairs(
        self, rows_by_scene: dict[str, list[SampleRow]]
    ) -> list[tuple[SampleRow, SampleRow]]:
        pairs: list[tuple[SampleRow, SampleRow]] = []
        for rows in rows_by_scene.values():
            for prev, curr in zip(rows, rows[1:]):
                if curr.frame_id != prev.frame_id + 1:
                    continue
                pairs.append((prev, curr))
        if not pairs:
            raise ValueError(f"No consecutive CAM_FRONT pairs found in {self.csv_path}")
        return pairs

    def __len__(self) -> int:
        return len(self.pairs)

    def _load_frame(
        self, row: SampleRow, frame_size: int | tuple[int, int] | None = None
    ) -> torch.Tensor:
        image_path = self._resolve_image_path(row.file)
        with Image.open(image_path) as image:
            image = np.asarray(image.convert("RGB"))
        intrinsic = self.intrinsics_by_file.get(row.file)
        if intrinsic is None:
            intrinsic = self.intrinsics_by_file.get(Path(row.file).name)
        image = resize_then_principal_crop(image, intrinsic, frame_size or self.frame_size)
        return torch.from_numpy(image.copy()).permute(2, 0, 1)

    def __getitem__(self, idx: int):
        prev, curr = self.pairs[idx]
        prev_frame = self._load_frame(prev)
        curr_frame = self._load_frame(curr)
        frames = torch.stack((prev_frame, curr_frame))
        if self.optical_frame_size == self.frame_size:
            prev_flow_frame, curr_flow_frame = prev_frame, curr_frame
        else:
            prev_flow_frame = self._load_frame(prev, self.optical_frame_size)
            curr_flow_frame = self._load_frame(curr, self.optical_frame_size)
        prev_calibration = self._camera_calibration(prev)
        curr_calibration = self._camera_calibration(curr)
        if prev_calibration["camera_intrinsic"].shape != curr_calibration["camera_intrinsic"].shape:
            raise ValueError("Consecutive CAM_FRONT frames have incompatible intrinsics")
        geometry = build_crop_geometry(
            (prev_calibration["height"], prev_calibration["width"]),
            torch.from_numpy(prev_calibration["camera_intrinsic"]),
            self.optical_frame_size,
        )
        action = compute_action(
            self.ego_poses[prev.ego_pose_token],
            self.ego_poses[curr.ego_pose_token],
        )
        prev_depth, prev_depth_mask, prev_depth_intrinsic = self._load_depth_record(prev)
        _, _, curr_depth_intrinsic = self._load_depth_record(curr)
        optical_flow, optical_mask = prepare_optical_flow_target(
            prev_flow_frame,
            curr_flow_frame,
            self.flow_estimator,
            prev_depth=prev_depth,
            prev_depth_mask=prev_depth_mask,
            prev_depth_intrinsic=prev_depth_intrinsic,
            curr_depth_intrinsic=curr_depth_intrinsic,
            prev_pose=self.ego_poses[prev.ego_pose_token],
            curr_pose=self.ego_poses[curr.ego_pose_token],
            camera_calibration=prev_calibration,
            curr_camera_calibration=curr_calibration,
            geometry=geometry,
            target_size=self.flow_target_size,
            quantile=self.flow_quantile,
        )
        return frames, action, optical_flow, optical_mask


class NuScenesTrain(_NuScenesPairDataset):
    pass


class NuScenesVal(_NuScenesPairDataset):
    def __getitem__(self, idx: int):
        frames, action, optical_flow, optical_mask = super().__getitem__(idx)
        return frames, action, optical_flow, optical_mask, idx
