from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
import torch.nn.functional as F

from third_party.gmflow import GMFlowOnlineEstimator, estimate_flow_pair


def as_hw(size: int | tuple[int, int]) -> tuple[int, int]:
    if isinstance(size, int):
        return size, size
    h, w = size
    return int(h), int(w)


@dataclass(frozen=True)
class CropGeometry:
    original_height: int
    original_width: int
    output_height: int
    output_width: int
    scale: float
    resized_height: int
    resized_width: int
    crop_left: int
    crop_top: int


def build_crop_geometry(
    original_size: tuple[int, int],
    intrinsic: torch.Tensor,
    output_size: int | tuple[int, int],
) -> CropGeometry:
    original_height, original_width = map(int, original_size)
    output_height, output_width = as_hw(output_size)
    if output_height != output_width:
        raise ValueError("nuScenes preprocessing requires a square output")
    scale = output_height / min(original_height, original_width)
    resized_height = max(output_height, int(round(original_height * scale)))
    resized_width = max(output_width, int(round(original_width * scale)))
    principal_x = float(intrinsic[0, 2]) * scale
    principal_y = float(intrinsic[1, 2]) * scale
    crop_left = int(round(principal_x - output_width / 2.0))
    crop_top = int(round(principal_y - output_height / 2.0))
    return CropGeometry(
        original_height=original_height,
        original_width=original_width,
        output_height=output_height,
        output_width=output_width,
        scale=scale,
        resized_height=resized_height,
        resized_width=resized_width,
        crop_left=crop_left,
        crop_top=crop_top,
    )


def _quat_to_rotation(quaternion: Any, dtype: torch.dtype = torch.float32) -> torch.Tensor:
    w, x, y, z = torch.as_tensor(quaternion, dtype=dtype).unbind()
    return torch.stack(
        (
            torch.stack((1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y))),
            torch.stack((2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x))),
            torch.stack((2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y))),
        )
    )


def _make_transform(rotation: torch.Tensor, translation: Any) -> torch.Tensor:
    transform = torch.eye(4, dtype=rotation.dtype, device=rotation.device)
    transform[:3, :3] = rotation
    transform[:3, 3] = torch.as_tensor(
        translation, dtype=rotation.dtype, device=rotation.device
    )
    return transform


def _sample_depth_to_model_grid(
    depth: torch.Tensor,
    depth_mask: torch.Tensor,
    geometry: CropGeometry,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    if depth.ndim != 2 or depth_mask.ndim != 2 or depth.shape != depth_mask.shape:
        raise ValueError(
            f"Expected depth/mask [H,W] with equal shapes, got {tuple(depth.shape)} "
            f"and {tuple(depth_mask.shape)}"
        )
    depth = depth.float()
    depth_mask = depth_mask.bool()
    output_h, output_w = geometry.output_height, geometry.output_width
    depth_h, depth_w = depth.shape
    yy, xx = torch.meshgrid(
        torch.arange(output_h, dtype=torch.float32, device=depth.device),
        torch.arange(output_w, dtype=torch.float32, device=depth.device),
        indexing="ij",
    )
    resized_x = xx + geometry.crop_left
    resized_y = yy + geometry.crop_top
    original_x = resized_x / geometry.scale
    original_y = resized_y / geometry.scale
    depth_x = original_x * (depth_w / geometry.original_width)
    depth_y = original_y * (depth_h / geometry.original_height)
    source_valid = (
        (depth_x >= 0)
        & (depth_x <= depth_w - 1)
        & (depth_y >= 0)
        & (depth_y <= depth_h - 1)
    )

    def sample_map(value: torch.Tensor, mode: str) -> torch.Tensor:
        if depth_w > 1:
            grid_x = depth_x / (depth_w - 1) * 2 - 1
        else:
            grid_x = torch.zeros_like(depth_x)
        if depth_h > 1:
            grid_y = depth_y / (depth_h - 1) * 2 - 1
        else:
            grid_y = torch.zeros_like(depth_y)
        grid = torch.stack((grid_x, grid_y), dim=-1).unsqueeze(0)
        return F.grid_sample(
            value.unsqueeze(0).unsqueeze(0),
            grid,
            mode=mode,
            padding_mode="zeros",
            align_corners=True,
        )[0, 0]

    sampled_depth = sample_map(depth, "bilinear")
    sampled_mask = sample_map(depth_mask.float(), "nearest").bool()
    sampled_mask &= source_valid
    sampled_mask &= torch.isfinite(sampled_depth) & (sampled_depth > 0)
    return sampled_depth, sampled_mask, depth_x, depth_y


def compute_ego_flow(
    depth: torch.Tensor,
    depth_mask: torch.Tensor,
    prev_depth_intrinsic: torch.Tensor,
    curr_depth_intrinsic: torch.Tensor,
    prev_pose: dict[str, Any],
    curr_pose: dict[str, Any],
    camera_calibration: dict[str, Any],
    geometry: CropGeometry,
    curr_camera_calibration: dict[str, Any] | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Project static-scene points from the previous camera image to the current one."""
    sampled_depth, valid, depth_x, depth_y = _sample_depth_to_model_grid(
        depth, depth_mask, geometry
    )
    dtype = torch.float32
    device = sampled_depth.device
    prev_k = torch.as_tensor(prev_depth_intrinsic, dtype=dtype, device=device)
    curr_k = torch.as_tensor(curr_depth_intrinsic, dtype=dtype, device=device)
    pixels_prev = torch.stack(
        (depth_x, depth_y, torch.ones_like(depth_x)), dim=0
    ).reshape(3, -1)
    points_prev = torch.linalg.solve(
        prev_k, pixels_prev * sampled_depth.reshape(1, -1)
    )

    curr_camera_calibration = curr_camera_calibration or camera_calibration
    prev_camera_to_ego = _make_transform(
        _quat_to_rotation(camera_calibration["rotation"], dtype=dtype).to(device),
        camera_calibration["translation"],
    )
    curr_camera_to_ego = _make_transform(
        _quat_to_rotation(curr_camera_calibration["rotation"], dtype=dtype).to(device),
        curr_camera_calibration["translation"],
    )
    prev_ego_to_world = _make_transform(
        _quat_to_rotation(prev_pose["rotation"], dtype=dtype).to(device),
        prev_pose["translation"],
    )
    curr_ego_to_world = _make_transform(
        _quat_to_rotation(curr_pose["rotation"], dtype=dtype).to(device),
        curr_pose["translation"],
    )
    prev_camera_to_world = prev_ego_to_world @ prev_camera_to_ego
    curr_world_to_camera = torch.linalg.inv(curr_ego_to_world @ curr_camera_to_ego)
    prev_to_curr = curr_world_to_camera @ prev_camera_to_world

    points_prev_h = torch.cat(
        (points_prev, torch.ones((1, points_prev.shape[1]), dtype=dtype, device=device)),
        dim=0,
    )
    points_curr = (prev_to_curr @ points_prev_h)[:3]
    z_curr = points_curr[2]
    projected = curr_k @ points_curr
    projected_x = projected[0] / z_curr.clamp_min(1.0e-8)
    projected_y = projected[1] / z_curr.clamp_min(1.0e-8)

    depth_h, depth_w = depth.shape
    current_original_x = projected_x * (geometry.original_width / depth_w)
    current_original_y = projected_y * (geometry.original_height / depth_h)
    current_x = current_original_x * geometry.scale - geometry.crop_left
    current_y = current_original_y * geometry.scale - geometry.crop_top
    yy, xx = torch.meshgrid(
        torch.arange(geometry.output_height, dtype=dtype, device=device),
        torch.arange(geometry.output_width, dtype=dtype, device=device),
        indexing="ij",
    )
    flow = torch.stack(
        (current_x.reshape_as(xx) - xx, current_y.reshape_as(yy) - yy), dim=0
    )
    valid = valid.reshape(-1)
    valid &= torch.isfinite(z_curr) & (z_curr > 0)
    valid &= torch.isfinite(projected_x) & torch.isfinite(projected_y)
    valid &= projected_x >= 0
    valid &= projected_x < depth_w
    valid &= projected_y >= 0
    valid &= projected_y < depth_h
    valid &= current_x >= 0
    valid &= current_x < geometry.output_width
    valid &= current_y >= 0
    valid &= current_y < geometry.output_height
    valid = valid.reshape(geometry.output_height, geometry.output_width)
    flow = torch.where(valid.unsqueeze(0), flow, torch.zeros_like(flow))
    return flow, valid


def build_motion_mask(
    flow: torch.Tensor,
    quantile: float = 0.8,
    valid_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    if flow.ndim != 3 or flow.shape[0] != 2:
        raise ValueError(f"Expected flow [2,H,W], got {tuple(flow.shape)}")
    if not 0 <= quantile <= 1:
        raise ValueError(f"Expected quantile in [0,1], got {quantile}")
    magnitude = torch.linalg.vector_norm(flow.float(), dim=0)
    valid = torch.isfinite(magnitude)
    if valid_mask is not None:
        if valid_mask.shape != magnitude.shape:
            raise ValueError(
                f"Flow/mask shape mismatch: {tuple(magnitude.shape)} vs {tuple(valid_mask.shape)}"
            )
        valid &= valid_mask.bool()
    if not valid.any():
        return torch.zeros_like(valid)
    threshold = torch.quantile(magnitude[valid], quantile)
    if threshold <= 0:
        return (magnitude > 0) & valid
    return (magnitude >= threshold) & valid


def build_residual_flow(
    raw_flow: torch.Tensor,
    ego_flow: torch.Tensor,
    ego_valid: torch.Tensor,
    quantile: float = 0.8,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if raw_flow.shape != ego_flow.shape:
        raise ValueError(
            f"Raw/ego flow shape mismatch: {tuple(raw_flow.shape)} vs {tuple(ego_flow.shape)}"
        )
    residual = raw_flow.float() - ego_flow.float()
    valid = ego_valid.bool() & torch.isfinite(residual).all(dim=0)
    motion_mask = build_motion_mask(residual, quantile=quantile, valid_mask=valid)
    residual = torch.where(valid.unsqueeze(0), residual, torch.zeros_like(residual))
    return residual, motion_mask, valid


def downsample_flow_and_mask(
    flow: torch.Tensor,
    mask: torch.Tensor,
    target_size: int | tuple[int, int],
) -> tuple[torch.Tensor, torch.Tensor]:
    target_h, target_w = as_hw(target_size)
    if flow.ndim != 3 or flow.shape[0] != 2:
        raise ValueError(f"Expected flow [2,H,W], got {tuple(flow.shape)}")
    if mask.ndim != 2 or mask.shape != flow.shape[-2:]:
        raise ValueError(
            f"Expected mask [H,W] matching flow, got {tuple(mask.shape)} and {tuple(flow.shape)}"
        )
    weights = mask.float().unsqueeze(0).unsqueeze(0)
    weighted_flow = F.adaptive_avg_pool2d(
        flow.float().unsqueeze(0) * weights, (target_h, target_w)
    )
    pooled_weights = F.adaptive_avg_pool2d(weights, (target_h, target_w))
    flow_down = weighted_flow / pooled_weights.clamp_min(1.0e-6)
    flow_down = torch.where(
        pooled_weights > 0, flow_down, torch.zeros_like(flow_down)
    )[0]
    mask_down = (
        F.adaptive_max_pool2d(weights, (target_h, target_w))[0, 0] > 0
    )
    return flow_down, mask_down


def prepare_optical_flow_target(
    prev_frame: torch.Tensor,
    curr_frame: torch.Tensor,
    estimator: GMFlowOnlineEstimator,
    prev_depth: torch.Tensor,
    prev_depth_mask: torch.Tensor,
    prev_depth_intrinsic: torch.Tensor,
    curr_depth_intrinsic: torch.Tensor,
    prev_pose: dict[str, Any],
    curr_pose: dict[str, Any],
    camera_calibration: dict[str, Any],
    geometry: CropGeometry,
    curr_camera_calibration: dict[str, Any] | None = None,
    target_size: int | tuple[int, int] = 128,
    quantile: float = 0.8,
) -> tuple[torch.Tensor, torch.Tensor]:
    raw_flow = estimate_flow_pair(prev_frame, curr_frame, estimator)[0].detach().cpu().float()
    ego_flow, ego_valid = compute_ego_flow(
        depth=prev_depth,
        depth_mask=prev_depth_mask,
        prev_depth_intrinsic=prev_depth_intrinsic,
        curr_depth_intrinsic=curr_depth_intrinsic,
        prev_pose=prev_pose,
        curr_pose=curr_pose,
        camera_calibration=camera_calibration,
        geometry=geometry,
        curr_camera_calibration=curr_camera_calibration,
    )
    residual, motion_mask, _ = build_residual_flow(
        raw_flow, ego_flow.cpu(), ego_valid.cpu(), quantile=quantile
    )
    return downsample_flow_and_mask(residual, motion_mask, target_size)
