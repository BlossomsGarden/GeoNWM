# DeltaTok / DeltaWorld-Flow / Refiner 数据流总览

> 代码位置:
> - [DeltaTok core](models/deltatok.py)
> - [DINOtok wrapper](models/dinotok_wrapper.py)
> - [Action tokenizer](models/action_tokenizer.py)
> - [DeltaWorld-Flow](deltaworld-flow/)
> - [Refiner](deltaworld-flow/refiner/)
>
> 默认 shape 约定:
> - `C = 832`
> - `K = num_delta_tokens = 1`（代码默认）
> - `N = (img_size / 16)^2`
>   - `img_size = 256 -> N = 16 x 16 = 256`
>   - `img_size = 512 -> N = 32 x 32 = 1024`
> - `H` / `W` 表示图像高宽
> - DeltaWorld-Flow 默认: `residual_dim = action_dim = model_dim = 832`, `num_heads = 13`, `head_dim = 64`
> - Refiner 默认: `dim = 832`, `num_heads = 13`

## 0. 先看三条输入契约

```text
DeltaTok
  frames [B, 2, 3, H, W]
  action  [B, 3]
  -> pairwise latent transition

DeltaWorld-Flow
  frames  [B, 5, 3, H, W]
  actions [B, 4, 3]
  -> 4-step residual chunk forecasting

Refiner
  frames  [B, 13, 3, H, W]
  actions [B, 12, 3]
  -> 3 x 4-step DeltaWorld chunks + per-frame refinement
```

```text
shared nuScenes preprocessing
  CSV row
    -> filter cam in {FRONT, CAM_FRONT}
    -> group by scene_id
    -> sort by frame_id
    -> build consecutive windows
    -> load image
    -> resize_then_principal_crop
    -> compute_action(prev_pose, curr_pose)
```

```text
compute_action(prev_pose, curr_pose)
  delta_global = curr.translation - prev.translation
  delta_prev   = prev_rotation^T @ delta_global
  relative_rot = prev_rotation^T @ curr_rotation
  delta_yaw    = atan2(relative_rot[1,0], relative_rot[0,0]) in degrees
  -> [dx, dy, dyaw] in the previous ego frame
```

## 1. DeltaTok

DeltaTok 的主文件是 [models/deltatok.py](models/deltatok.py)，它依赖
[models/dinotok_wrapper.py](models/dinotok_wrapper.py) 把 DINOv3 + DINO-Tok AE
封装成 `DINOtok`，再在这个 832 维 fused latent 上做 pairwise transition。

### 1.1 DINOtok wrapper

```text
frames [B, T, 3, H, W]
  |
  v
flatten(0, 1)
  |
  v
images [B*T, 3, H, W]
  |
  v
_prepare_input
  - float
  - if max > 1.5: /255
  - resize to img_size x img_size
  - normalize with img_mean / img_std
  |
  v
AutoModel(DINOv3, output_hidden_states=True)
  |
  +--> hidden_states[dino_shallow_layer] -> shallow [B*T, 768, h, w]
  |
  +--> hidden_states[-1]                -> deep    [B*T, 768, h, w]
  |
  v
strip prefix tokens
  |
  v
shallow/deep maps -> DINO-Tok encoder
  |
  v
fused latent map [B*T, 832, h, w]
  |
  v
rearrange to tokens
  |
  v
fused tokens [B*T, N, 832]
  |
  v
reshape back to frame axis
  |
  v
U [B, T, N, 832]
```

```text
decode(latent)
  latent [B, N, 832] or [B, T, N, 832]
    |
    v
  flatten T if needed
    |
    v
  reshape tokens -> latent map [B, 832, h, w]
    |
    v
  DINO-Tok decoder
    |
    v
  RGB image [B, 3, H, W] or [B, T, 3, H, W]
```

```text
feature_slice(latent)
  latent [..., 832]
    |
    v
  latent[..., -768:]
    |
    v
  compatibility slice for frozen task heads / visualization only
```

### 1.2 DeltaTok encode

```text
previous latent U_{t-1} [B, N, 832]
current  latent U_t     [B, N, 832]
action   a_{t-1}        [B, 3]

a_{t-1}
  -> ActionTokenizer
  -> A_x, A_y, A_yaw [B, 3, 832]

Q_1..Q_K               [B, K, 832]
A_x, A_y, A_yaw        [B, 3, 832]
U_{t-1}                [B, N, 832]
U_t                    [B, N, 832]
  |
  v
concat along sequence dimension
  |
  v
H_enc [B, K + 3 + N + N, 832]
  |
  v
12 x DINOv3ViTLayer
  |
  v
encoder_norm
  |
  v
residual tokens Z_t = hidden[:, :K] [B, K, 832]
```

```text
segment embedding usage
  Q tokens   -> segment_embedding[0]
  action toks -> segment_embedding[1]
  U_{t-1}    -> segment_embedding[2]
  U_t        -> segment_embedding[3]

position embedding
  2D RoPE on the token grid
  previous and current latent grids share the same RoPE shape
```

### 1.3 DeltaTok decode

```text
residual Z_t     [B, K, 832]
previous U_{t-1} [B, N, 832]

Z_t + residual_embedding
U_{t-1} + segment_embedding[2]
  |
  v
concat
  |
  v
H_dec [B, K + N, 832]
  |
  v
12 x DINOv3ViTLayer
  |
  v
decoder output tokens
  |
  +--> hidden[:, :K]   -> ignored
  |
  +--> hidden[:, K:]   -> U_hat_t [B, N, 832]
```

```text
forward(frames, action)
  frames [B, 2, 3, H, W]
    |
    v
  backbone.encode(frames) -> latents [B, 2, N, 832]
    |
    +--> previous = latents[:, 0] [B, N, 832]
    |
    +--> target   = latents[:, 1] [B, N, 832]
    |
    v
  residual = encode(previous, target, action)
    |
    v
  pred_latent = decode(residual, previous)
    |
    +--> motion_pred   = motion_head(mean(residual, dim=1)) [B, 3]
    |
    +--> motion_target = normalized action [B, 3]
```

```text
training side losses
  latent_loss = criterion(pred_latent, target_latent).mean()
  motion_loss = smooth_l1(motion_pred, motion_target)
  total_loss  = latent_loss + lambda_motion * motion_loss
```

```text
compatibility heads
  Base._apply_head(feats, head, frame_shape)
    -> selected = feats[..., -768:]
    -> reshape to [B, T, 768, h, w]
    -> frozen SegHead / DepthHead
  This path is for logging / visualization only.
```

## 2. DeltaWorld-Flow

主入口是 [deltaworld-flow/deltaflow/model.py](deltaworld-flow/deltaflow/model.py) 和
[deltaworld-flow/deltaflow/modules.py](deltaworld-flow/deltaflow/modules.py)。
它把 DeltaTok 的 residual space 当成 flow space，在 4-step future chunk 上做 rectified flow。

### 2.1 总体链路

```text
frames  [B, 5, 3, H, W]
actions [B, 4, 3]
  |
  +--> frozen delta_tok.backbone.encode(frames)
  |      -> U_seq [B, 5, N, 832]
  |
  +--> target extraction
         z_0 = delta_tok.encode(U_0, U_1, a_0) [B, K, 832]
         z_1 = delta_tok.encode(U_1, U_2, a_1) [B, K, 832]
         z_2 = delta_tok.encode(U_2, U_3, a_2) [B, K, 832]
         z_3 = delta_tok.encode(U_3, U_4, a_3) [B, K, 832]
         -> target_z [B, 4, K, 832]
```

```text
actions [B, 4, 3]
  |
  v
delta_tok.action_tokenizer(actions.reshape(B*4, 3))
  |
  v
action_tokens [B, 4, 3, 832]
  |
  +--> StepActionPooler
  |      -> step_action_emb [B, 4, 832]
  |      -> plan_emb       [B, 832]
  |
  +--> SceneActionResampler
         scene_tokens  = U_0 [B, N, 832]
         action_tokens  = [B, 12, 832]
         step_action_emb
         plan_emb
         -> C_i [B, 64, 832]
```

```text
noise [B, active_h, K, 832]
target_z [B, active_h, K, 832]
tau [B]
  |
  v
x_tau = (1 - tau) * noise + tau * target_z
target_v = target_z - noise
  |
  v
FlowDiT(x_tau, tau, C_i, step_action_emb, plan_emb)
  |
  v
pred_v [B, active_h, K, 832]
```

### 2.2 StepActionPooler

```text
+-----------------------------------------------------------------------+
| Input: action_tokens                                                  |
|   [B, 4, 3, 832]                                                      |
|   4 future steps x 3 typed tokens per step                            |
|   typed tokens = [A_dx, A_dy, A_dyaw]                                 |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| Per-step pooling                                                      |
|                                                                       |
| for each future step h = 0,1,2,3:                                    |
|   step_query [1, 832]                                                 |
|   A_h = action_tokens[:, h] [B, 3, 832]                               |
|   concat(step_query, A_h) -> step_seq [B, 4, 832]                     |
|   step_seq -> GatedSelfAttentionBlock x 2                             |
|   take token 0 -> step_emb_h [B, 832]                                 |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| Stack four step embeddings                                             |
|   step_emb_0, step_emb_1, step_emb_2, step_emb_3                      |
|   -> step_action_emb [B, 4, 832]                                      |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| Global plan pooling                                                    |
|                                                                       |
|   step_action_emb + horizon_embedding[:4]                             |
|   -> step_with_time [B, 4, 832]                                       |
|                                                                       |
|   plan_query [1, 832]                                                 |
|   concat(plan_query, step_with_time) -> plan_seq [B, 5, 832]          |
|   plan_seq -> GatedSelfAttentionBlock x 2                             |
|   take token 0 -> plan_emb [B, 832]                                   |
+-----------------------------------------------------------------------+
```

```text
StepActionPooler block count
  per-step branch = 2 x GatedSelfAttentionBlock
  plan branch     = 2 x GatedSelfAttentionBlock
  total           = 4 x GatedSelfAttentionBlock
```

### 2.3 SceneActionResampler

#### 2.3.1 Query initialization

`4 horizon groups x 16 queries per group` 的意思是：
每个未来时间步分配 16 个 learnable query，一共 4 个未来时间步，
所以总 query 数是 `4 x 16 = 64`。

```text
learnable query bank
  q[m] [832], m = 0,...,15

for each horizon h = 0,1,2,3:
  Q[h,m] =
      q[m]                           [832]
    + horizon_embedding[h]           [832]
    + step_proj(step_action_emb[:,h]) [B,832]
    + plan_proj(plan_emb)             [B,832]

  m = 0,...,15
  -> Q_h [B,16,832]

stack h = 0,1,2,3
  -> Q_grouped [B,4,16,832]
  -> reshape
  -> Q_0 [B,64,832]
  -> + segment_embedding[2]
```

```text
Q_0 [B,64,832] 的排布

  horizon 0: Q[0,0] ... Q[0,15]   -> 16 tokens
  horizon 1: Q[1,0] ... Q[1,15]   -> 16 tokens
  horizon 2: Q[2,0] ... Q[2,15]   -> 16 tokens
  horizon 3: Q[3,0] ... Q[3,15]   -> 16 tokens
                                   ----------------
                                   total = 64 tokens
```

#### 2.3.2 Resampler inputs

```text
+-----------------------------------------------------------------------+
| Scene input                                                            |
|   U_i [B, N, 832]                                                     |
|   -> LayerNorm                                                        |
|   -> + segment_embedding[0]                                           |
|   -> scene_tokens S [B, N, 832]                                       |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| Action input                                                           |
|   action_tokens A [B, 12, 832]                                        |
|   = 4 future steps x 3 typed action tokens                            |
|   -> LayerNorm                                                        |
|   -> + segment_embedding[1]                                           |
|   -> action_tokens A [B, 12, 832]                                     |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| Query input                                                            |
|   Q_0 [B, 64, 832]                                                    |
|   = 4 horizon groups x 16 learnable queries                           |
|   -> + horizon / step-action / global-plan embeddings                 |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| Global condition                                                       |
|   plan_emb P [B, 832]                                                  |
|   is used by every AdaLayerNorm in every ResamplerBlock               |
+-----------------------------------------------------------------------+
```

#### 2.3.3 One ResamplerBlock

`query self-attn` 这一步是 **64 个 query token 之间的自注意力**。
也就是说，`Q = K = V` 都来自当前 query 序列 `Q_0`，它不看 scene token，
也不看 action token。

```text
Input query sequence
  X_0 [B,64,832]
       |
       v
+-----------------------------------------------------------------------+
| (1) Query AdaLN                                                       |
|   hidden = AdaLayerNorm(X_0, P)                                       |
|   hidden [B,64,832]                                                   |
|   P = plan_emb [B,832]                                                |
+-----------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------+
| (2) Query Self-Attention                                              |
|   Q = hidden [B,64,832]                                               |
|   K = hidden [B,64,832]                                               |
|   V = hidden [B,64,832]                                               |
|   MultiHeadAttention(832, 13 heads)                                   |
|   self_attn_out [B,64,832]                                            |
|   X_1 = X_0 + self_attn_out                                           |
+-----------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------+
| (3) Action Cross-Attention                                            |
|   hidden = AdaLayerNorm(X_1, P)                                       |
|   Q = hidden [B,64,832]                                               |
|   K = A [B,12,832]                                                    |
|   V = A [B,12,832]                                                    |
|   action_attn_out [B,64,832]                                          |
|   X_2 = X_1 + tanh(action_gate) * action_attn_out                     |
|   action_gate is a single trainable scalar, init 0.0                  |
+-----------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------+
| (4) Scene Cross-Attention                                             |
|   hidden = AdaLayerNorm(X_2, P)                                       |
|   Q = hidden [B,64,832]                                               |
|   K = S [B,N,832]                                                     |
|   V = S [B,N,832]                                                     |
|   scene_attn_out [B,64,832]                                           |
|   X_3 = X_2 + scene_attn_out                                          |
+-----------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------+
| (5) Query MLP                                                         |
|   hidden = AdaLayerNorm(X_3, P)                                       |
|   MLP: 832 -> 3328 -> 832                                             |
|   mlp_out [B,64,832]                                                  |
|   X_out = X_3 + mlp_out                                               |
+-----------------------------------------------------------------------+
       |
       v
Output query sequence
  X_out [B,64,832]
```

```text
ResamplerBlock information flow
  X_0 [B,64,832]
    -> AdaLN(X_0, P)
    -> Self-Attn(Q=X, K=X, V=X)
    -> residual add
    -> AdaLN(X, P)
    -> Action Cross-Attn(Q=X, K=A, V=A)
    -> gated residual add
    -> AdaLN(X, P)
    -> Scene Cross-Attn(Q=X, K=S, V=S)
    -> residual add
    -> AdaLN(X, P)
    -> MLP(832 -> 3328 -> 832)
    -> residual add
    -> X_out [B,64,832]
```

#### 2.3.4 Resampler stack

```text
Q_0 [B,64,832]
  |
  v
+-----------------------------+
| ResamplerBlock #1           |
| self-attn                   |
| action cross-attn           |
| scene cross-attn            |
| MLP                         |
+-----------------------------+
  | X_1 [B,64,832]
  v
+-----------------------------+
| ResamplerBlock #2           |
| self-attn                   |
| action cross-attn           |
| scene cross-attn            |
| MLP                         |
+-----------------------------+
  | X_2 [B,64,832]
  v
+-----------------------------+
| ResamplerBlock #3           |
| self-attn                   |
| action cross-attn           |
| scene cross-attn            |
| MLP                         |
+-----------------------------+
  | X_3 [B,64,832]
  v
+-----------------------------+
| ResamplerBlock #4           |
| self-attn                   |
| action cross-attn           |
| scene cross-attn            |
| MLP                         |
+-----------------------------+
  | X_4 [B,64,832]
  v
+-----------------------------------------------------------------------+
| output_norm                                                           |
| -> condition_tokens C_i [B,64,832]                                    |
+-----------------------------------------------------------------------+
```

```text
SceneActionResampler 总 block 数
  resampler_depth = 4
  => ResamplerBlock #1, #2, #3, #4

每个 ResamplerBlock 内部:
  1 x query self-attention
  1 x action cross-attention
  1 x scene cross-attention
  1 x MLP

整个 Resampler 共有:
  4 x self-attention
  4 x action cross-attention
  4 x scene cross-attention
  4 x MLP
```

### 2.4 FlowDiT

#### 2.4.1 FlowDiT 输入和 token 化

```text
+-----------------------------------------------------------------------+
| Noisy future residual                                                 |
|   noisy_delta [B,H,K,832]                                             |
|                                                                       |
|   H = active prediction horizon                                      |
|   K = num_delta_tokens                                               |
|   default: H in {1,2,4}, K = 1                                        |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| Input normalization and projection                                    |
|   noisy_delta                                                         |
|     -> z_norm = LayerNorm(noisy_delta)                                |
|     -> input_proj                                                     |
|     -> z_tokens [B,H,K,832]                                           |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| Local token conditioning                                               |
|   horizon_embedding[:H] [H,832]                                       |
|   slot_embedding[:K]    [K,832]                                       |
|   step_action_emb[:, :H] [B,H,832]                                    |
|     -> step_action_proj [B,H,832]                                     |
|                                                                       |
|   broadcast and sum                                                   |
|   -> local [B,H,K,832]                                                |
|                                                                       |
|   z_tokens + local                                                    |
|   -> [B,H,K,832]                                                      |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| Flatten horizon and slot dimensions                                   |
|                                                                       |
|   (h=0,k=0),...,(h=0,k=K-1),                                         |
|   (h=1,k=0),...,(h=1,k=K-1),                                         |
|   ...                                                                 |
|   (h=H-1,k=0),...,(h=H-1,k=K-1)                                      |
|                                                                       |
|   -> flow_tokens [B,H*K,832]                                         |
+-----------------------------------------------------------------------+
```

```text
Default K = 1, H = 4

  noisy_delta [B,4,1,832]
    -> delta_0 [B,1,832]
    -> delta_1 [B,1,832]
    -> delta_2 [B,1,832]
    -> delta_3 [B,1,832]
    -> flow_tokens [B,4,832]

If K = 2, H = 4:
  flow_tokens [B,8,832]
  token order:
    (h=0,k=0), (h=0,k=1),
    (h=1,k=0), (h=1,k=1),
    (h=2,k=0), (h=2,k=1),
    (h=3,k=0), (h=3,k=1)
```

#### 2.4.2 FlowDiT 条件分支和 mask

```text
+-----------------------------------------------------------------------+
| Global flow condition                                                 |
|   tau [B]                                                             |
|     -> timestep_embedding                                             |
|     -> TimestepEmbedder MLP                                           |
|     -> time_emb [B,832]                                               |
|                                                                       |
|   plan_emb [B,832]                                                    |
|                                                                       |
|   global_cond = time_emb + plan_emb                                  |
|   global_cond [B,832]                                                 |
+-----------------------------------------------------------------------+
```

```text
local [B,H,K,832]
  -> reshape
  -> local_flat [B,H*K,832]

global_cond [B,832]
  -> unsqueeze(1)
  -> [B,1,832]
  -> broadcast over H*K tokens

token_cond = local_flat + global_cond.unsqueeze(1)
  -> token_cond [B,H*K,832]
```

```text
build_horizon_causal_mask(H, K)
  -> mask [H*K, H*K]

token(h, k) can attend token(h2, k2) iff h2 <= h

Therefore:
  horizon h sees all slots from horizons 0...h
  same-horizon slots see each other
  future horizons are masked

This mask is applied only in delta self-attention.
The cross-attention to C_i has no horizon causal mask.
```

#### 2.4.3 One FlowDiTBlock

```text
Input flow tokens
  X_0 [B,H*K,832]
       |
       v
+-----------------------------------------------------------------------+
| (1) Delta AdaLN                                                       |
|   hidden = AdaLayerNorm(X_0, token_cond)                              |
|   hidden [B,H*K,832]                                                  |
|   token_cond contains:                                                |
|     horizon embedding                                                 |
|     DeltaTok slot embedding                                           |
|     step-local action embedding                                       |
|     global time embedding                                             |
|     global action-plan embedding                                      |
+-----------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------+
| (2) Causal Delta Self-Attention                                       |
|   Q = hidden [B,H*K,832]                                              |
|   K = hidden [B,H*K,832]                                              |
|   V = hidden [B,H*K,832]                                              |
|   attn_mask = horizon causal mask [H*K,H*K]                           |
|   self_attn_out [B,H*K,832]                                           |
|   X_1 = X_0 + self_attn_out                                           |
+-----------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------+
| (3) Condition Cross-Attention                                         |
|   hidden = AdaLayerNorm(X_1, token_cond)                              |
|   Q = hidden              [B,H*K,832]                                 |
|   K = condition_tokens C_i [B,64,832]                                 |
|   V = condition_tokens C_i [B,64,832]                                 |
|   condition_attn_out [B,H*K,832]                                     |
|   X_2 = X_1 + condition_attn_out                                      |
+-----------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------+
| (4) Flow MLP                                                          |
|   hidden = AdaLayerNorm(X_2, token_cond)                              |
|   MLP: Linear(832,3328) -> GELU -> Linear(3328,832)                  |
|   mlp_out [B,H*K,832]                                                 |
|   X_out = X_2 + mlp_out                                               |
+-----------------------------------------------------------------------+
       |
       v
Output flow tokens
  X_out [B,H*K,832]
```

```text
FlowDiTBlock information flow
  X_0 [B,H*K,832]
    -> AdaLN(X_0, token_cond)
    -> Causal Self-Attn(Q=X, K=X, V=X, mask=causal)
    -> residual add
    -> AdaLN(X, token_cond)
    -> Condition Cross-Attn(Q=X, K=C_i, V=C_i)
    -> residual add
    -> AdaLN(X, token_cond)
    -> MLP(832 -> 3328 -> 832)
    -> residual add
    -> X_out [B,H*K,832]
```

#### 2.4.4 FlowDiT stack

```text
flow_tokens [B,H*K,832]
  |
  v
+-----------------------------+
| FlowDiTBlock #1             |
| causal self-attn            |
| condition cross-attn        |
| MLP                         |
+-----------------------------+
  | [B,H*K,832]
  v
+-----------------------------+
| FlowDiTBlock #2             |
| causal self-attn            |
| condition cross-attn        |
| MLP                         |
+-----------------------------+
  | [B,H*K,832]
  v
              ...
              |
              v
+-----------------------------+
| FlowDiTBlock #11            |
| causal self-attn            |
| condition cross-attn        |
| MLP                         |
+-----------------------------+
  | [B,H*K,832]
  v
+-----------------------------+
| FlowDiTBlock #12            |
| causal self-attn            |
| condition cross-attn        |
| MLP                         |
+-----------------------------+
  | [B,H*K,832]
  v
+-----------------------------------------------------------------------+
| Output head                                                            |
|   output_norm: LayerNorm(832)                                         |
|   output_proj: Linear(832,832), zero-initialized                      |
|   -> velocity_flat [B,H*K,832]                                       |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| Restore horizon and slot dimensions                                   |
|   reshape [B,H*K,832] -> [B,H,K,832]                                 |
|   -> pred_v [B,H,K,832]                                               |
+-----------------------------------------------------------------------+
```

```text
FlowDiT 总 block 数
  flow_depth = 12
  => FlowDiTBlock #1 ... #12

每个 FlowDiTBlock 内部:
  1 x causal delta self-attention
  1 x condition cross-attention
  1 x MLP

整个 FlowDiT 共有:
  12 x causal delta self-attention
  12 x condition cross-attention
  12 x MLP
```

```text
rectified flow objective
  x0 = noise
  x1 = target_z
  x_tau = (1 - tau) * x0 + tau * x1
  v_target = x1 - x0

  loss = weighted MSE over active horizons
```

### 2.5 训练 / 采样 / 验证

```text
training_step
  frames, actions
    -> outputs = network(frames, actions, active_horizon=schedule.active_horizon)
    -> pred_v vs target_v
    -> weighted horizon MSE

loss weights schedule
  step < 100000  -> active_horizon = 1, weights [1.0]
  step < 200000  -> active_horizon = 2, weights [1.0, 0.7]
  else           -> active_horizon = 4, weights [1.0, 0.7, 0.5, 0.3]
```

```text
sample(initial_latent, actions, num_steps=20)
  z ~ N(0, I)
  for step in 0..19:
    tau = step / 20
    v = predict_velocity(z, tau, initial_latent, actions)
    z = z + dt * v
  return z [B, 4, K, 832]
```

```text
rollout_latents(initial_latent, sampled_z)
  previous = initial_latent [B, N, 832]
  for step in 0..3:
    previous = delta_tok.decode(sampled_z[:, step], previous)
    collect previous
  -> sampled_latents [B, 4, N, 832]
```

```text
validation
  teacher-forced:
    pred_v vs target_v
    -> losses/val_teacher_forced_velocity_mse_*

  sampled:
    sampled_z = sample(...)
    -> metrics/*_sampled_z_mse_*

  visualization:
    sampled_latents -> delta_tok.backbone.decode -> RGB rollout
```

```text
important detail
  target_z_full is only "full" when active_horizon = 4.
  For shorter curriculum stages, it is the active prefix.
```

## 3. Refiner

主目录是 [deltaworld-flow/refiner/](deltaworld-flow/refiner/)。
它接在 DeltaWorld-Flow 之后，把每个 coarse latent 再修一遍。
这个目录里有两个独立版本:

```text
A: deterministic residual regression
B: stochastic residual rectified flow
```

```text
rollout steps
  train_flow_steps = 8
  eval_flow_steps  = 20
  stochastic refiner internal correction steps = 4
```

### 3.1 总体 rollout 链路

```text
frames  [B, 13, 3, H, W]
actions [B, 12, 3]
  |
  v
frozen delta_tok.backbone.encode(frames)
  |
  v
targets [B, 13, N, 832]
  |
  v
previous = targets[:, 0]

for chunk in 0..2:
  flow.sample(previous, actions[:, chunk*4 : chunk*4+4])
    -> z_chunk [B, 4, K, 832]

  for local in 0..3:
    coarse = delta_tok.decode(z_chunk[:, local], previous)
    -> [B, N, 832]

    refiner(previous, coarse)
    -> refined

    next_previous = where(path_mask, refined.detach(), coarse.detach())
```

```text
feedback schedule
  progress < 0.10 -> p = 0
  0.10 <= progress < 0.50 -> p linearly ramps to 0.75
  progress >= 0.50 -> p = 0.75

path_mask
  sample once per sequence
  shared by all 12 future frames
```

### 3.2 RefinerDDT

`RefinerDDT` 是两个 refiner 版本共用的骨架，定义在
[deltaworld-flow/refiner/modules.py](deltaworld-flow/refiner/modules.py)。

```text
state   [B, N, C]
previous [B, N, C]
coarse   [B, N, C]
tau      [B]

state
  -> input projection
  -> x [B, N, C]

previous
  -> previous_proj
coarse
  -> coarse_proj

tau
  -> timestep_embedding
  -> time MLP
  -> cond [B, C]

for each DDTBlock:
  1) self-attn on x, conditioned by cond
  2) cross-attn: x attends previous
  3) cross-attn: x attends coarse
  4) gated MLP

output head
  zero-initialized linear
  -> correction [B, N, C]
```

```text
spatial RoPE
  Dynamic2DRoPE(head_dim)
  requires head_dim % 4 == 0
  requires N to be a square number
  supports:
    16 x 16 latent grid
    32 x 32 latent grid
```

### 3.3 DeterministicRefiner

```text
previous [B, N, 832]
coarse   [B, N, 832]
  |
  v
backbone = RefinerDDT(coarse, previous, coarse)
  |
  v
correction [B, N, 832]
  |
  v
refined = coarse + correction
```

```text
loss(refined, target, channel_std)
  scale = channel_std.reshape(1, 1, 832)
  normalized_error = (refined - target) / scale
  SmoothL1(normalized_error, 0)
```

### 3.4 StochasticRefiner

```text
make_residual_flow_state(coarse, target, channel_std, sigma, tau)
  scale = channel_std.reshape(1, 1, 832)
  d = (target - coarse) / scale
  noise -> r0 = sigma * noise
  r_tau = (1 - tau) * r0 + tau * d
  target_velocity = d - r0
  return:
    r0
    r_tau
    target_velocity
    tau
```

```text
velocity(previous, coarse, r_tau, tau)
  -> RefinerDDT(r_tau, previous, coarse, tau)
  -> predicted residual velocity
```

```text
sample(previous, coarse, channel_std, num_steps=4)
  r = sigma * N(0, I)
  for step in 0..3:
    tau = step / 4
    v = velocity(previous, coarse, r, tau)
    r = r + dt * v
  refined = coarse + r * channel_std
```

```text
loss(pred_velocity, target_velocity)
  MSE(pred_velocity, target_velocity)
```

### 3.5 RefinerModule 训练壳

```text
training_step(batch)
  frames, actions
    -> rollout_engine.rollout(...)
    -> 12 FrameRecord objects

  per-frame weights
    frames 1-4  -> warmup_weight = 0.8
    frames 5-12 -> 1.0

  total_weight = 4 * 0.8 + 8 * 1.0

  for each frame:
    - deterministic: frame_loss = SmoothL1(refined, target)
    - stochastic:    frame_loss = MSE(pred_velocity, target_velocity)

  manual_backward(frame_loss * weight / total_weight)
  optimizer.step()
```

```text
validation_step(batch)
  frames, actions
    -> rollout_engine.rollout(..., training=False)
    -> mean((refined - target)^2)
    -> log val/mse
```

```text
channel statistics
  scan_gt_latent_stats(dataloader, frozen_dinotok, device)
    -> raw_std [832]
    -> clamp to [0.1 * median, 10 * median]
    -> LatentStats.clamped_std

this vector is used by both A and B as channel_std
```

## 4. 三个模块串起来看

```text
nuScenes CAM_FRONT images
  |
  v
DINOtok.encode
  -> U_t [B, N, 832]
  |
  v
DeltaTok.encode / decode
  -> residual tokens Z_t [B, K, 832]
  -> predicted current latent U_hat_t [B, N, 832]
  -> motion_pred [B, 3]
  |
  v
DeltaWorld-Flow
  -> future residual chunk z_hat [B, 4, K, 832]
  -> recursive latent rollout [B, 4, N, 832]
  |
  v
Refiner
  -> coarse latent [B, N, 832]
  -> refined latent [B, N, 832]
  |
  v
DINOtok.decode
  -> RGB rollout / visualization only
```

```text
一句话总结
  DINOtok 负责把图像压成 832 维 fused latent
  DeltaTok 负责在 latent space 里做相邻帧 transition
  DeltaWorld-Flow 负责在 residual space 里预测未来 4 步 chunk
  Refiner 负责在 coarse latent 上做最后一层 correction
```

## 5. 看代码时最容易混的点

```text
1) DeltaTok 的 motion head 不是主重建头，只是从 residual token 上回归 [dx, dy, dyaw]
2) DeltaWorld-Flow 的 target_z 来自在线 DeltaTok.encode，不是离线缓存
3) FlowDiT 的 causal mask 只约束 noisy future delta slots，不约束 condition tokens
4) Refiner 的 coarse 输入来自 DeltaTok.decode / DeltaWorld rollout，不直接吃 RGB
5) 256 / 512 的核心差别只是 latent grid N 变了，832 宽度不变
```
