# Decoder-Aware Latent Refiner and RAE-Style Decoder Design

本文档讨论 DeltaWorld-flow 当前最重要的视觉质量问题：预测结果在经过 DeltaTok decoder 和 DINO-Tok RGB decoder 后出现模糊、局部纹理缺失或 checkerboard-like artifacts。本文档的目标不是把所有问题归因于自回归误差，而是区分以下四类因素，并给出首版可验证的解决路径：

1. DeltaTok residual slot 的承载能力不足；
2. Flow DiT 预测的 latent 偏离 DINO-Tok decoder 熟悉的有效分布；
3. decoder 本身对高频纹理的重建能力不足；
4. 多段 rollout 中的 exposure bias 和误差累积。

其中 chain-of-forward 主要针对第 4 类问题，不能解决 residual 没有携带的细节信息。因此，本文档把 decoder-aware latent refiner 作为首版主线，把 RAE-style decoder 作为 decoder 能力增强路线，并把 stochastic texture completion 作为后续独立分支。

## 1. 当前数据流

当前模型的相关数据流为：

```text
I_t, I_{t+1}
    |
    v
U_t = E(I_t), U_{t+1}^* = E(I_{t+1})
    |
    v
z_t^* = DeltaTok.encode(U_t, U_{t+1}^*, action_t)
    |
    v
z_hat_t = DeltaWorld-flow.sample(U_t, action_{t:t+3})
    |
    v
U_coarse_{t+1} = DeltaTok.decode(z_hat_t, U_t)
    |
    v
I_coarse_{t+1} = G(U_coarse_{t+1})
```

当前代码中的接口与形状约定如下：

```text
U_t, U_{t+1}^*       [B, N, 832]
z_t, z_hat_t         [B, K, 832]
U_coarse             [B, N, 832]
N                    (image_size / 16)^2
K                    num_delta_tokens，当前默认值为 1
```

`DeltaTok.decode()` 接收 residual tokens 和 previous latent，将它们拼接后经过 decoder blocks，再取出 latent 部分。因此，residual token 不是一个完整的下一帧 latent，也不是一个显式的空间 residual map。特别是在 `K=1` 时，一个全局 residual slot 需要通过 attention 间接影响整张 latent grid。

当前 DINO-Tok wrapper 使用确定性的 encoder 和冻结的 RGB decoder：

- encoder 路径没有 `mu/logvar` 和 reparameterization；
- `enable_vq=False` 时不使用 codebook；
- `quant_conv` 是卷积投影和 GroupNorm，不是 VAE posterior；
- RGB decoder 输入的是 `832` 通道 latent map；
- decoder 的上采样路径主要使用 `InterpolateConv`，不能简单地把所有 checkerboard 归因于 `ConvTranspose2d`。

对应代码位置：

- [models/deltatok.py](models/deltatok.py)
- [models/dinotok_wrapper.py](models/dinotok_wrapper.py)
- [third_party/DINO-Tok/tokenizer/dinotok/models/tokenizer/dinotok.py](third_party/DINO-Tok/tokenizer/dinotok/models/tokenizer/dinotok.py)

## 2. 问题拆分

### 2.1 Residual capacity bottleneck

若 `K` 较小，DeltaTok residual 主要表达全局运动和结构变化，可能无法独立表示：

- disocclusion 区域中新出现的内容；
- 车辆、行人、路牌等小目标的局部形变；
- 物体边缘和遮挡边界；
- 运动导致的局部高频纹理变化；
- 需要重新生成而不是简单 warp 的区域。

这里的瓶颈首先是 residual slot 的空间自由度，而不只是每个 token 的 channel width。把 `832` 维 token 改成 `1024` 维，未必能解决一个 token 需要表达多个局部区域的问题；增加 `K` 或增加局部 residual 分支通常更直接。

### 2.2 Latent manifold drift

如果真实 target latent 能被 DINO-Tok RGB decoder 正常解码，而 Flow 预测的 latent 出现 checkerboard，那么更可能的路径是：

```text
Flow endpoint error
    -> U_coarse 偏离 E(I) 的有效 latent 分布
    -> frozen RGB decoder 对异常 latent 响应不稳定
    -> blur, periodic texture, checkerboard-like artifacts
```

这类问题不是简单的 image-space sharpening 问题。若直接在 RGB 输出后做锐化，可能只会放大错误纹理；更合理的做法是在进入 RGB decoder 前，把 coarse latent 拉回 decoder-compatible latent region。

### 2.3 Decoder texture limitation

即使 residual 使用真实 target pair 得到的 oracle residual，DeltaTok decoder 也可能无法完整重建 target latent。如果 oracle decode 仍然缺少纹理，说明问题不只是 Flow 误差，而是：

- residual representation 没有足够的局部自由度；
- DeltaTok decoder 没有学会从 previous latent 和 residual 恢复局部细节；
- DINO-Tok latent 本身偏语义，天然舍弃了一部分像素级高频；
- RGB decoder 的训练目标偏向平均重建，细节重建不足。

### 2.4 Autoregressive error accumulation

多段 rollout 时，上一段的预测 latent 会成为下一段的 previous。错误会改变下一次 DeltaTok decode 的输入分布，造成 exposure bias 和误差累积。

chain-of-forward、closed-loop training 和 refined feedback 主要处理这一类问题。它们不能补回 coarse latent 从未携带的纹理信息，因此应该和 refiner、decoder 训练分开评估。

## 3. 首版核心决策

本文提出的下一版实验主线采用以下组合。它不是对当前 A/B refiner checkpoint 的无标记替换，而是一个需要单独训练和评估的 decoder-aware 变体：

```text
DeltaWorld-flow
    负责 action-conditioned motion residual prediction

DeltaTok decoder
    负责 previous latent + residual -> coarse next latent

Decoder-aware latent refiner
    负责 coarse latent correction 和 decoder-compatible manifold repair

RAE-style RGB decoder training
    负责增强 latent -> RGB 的可重建细节能力

Chain-of-forward
    独立负责 closed-loop rollout stability
```

第一版不直接把 DeltaTok 改造成普通 VAE，原因见第 7 节。第一版也不把 stochastic texture generation 和 motion residual 混在一个 latent 中，避免 action-aligned residual 的语义变得不稳定。

与现有 `deltaworld-flow/refiner/` 的关系如下：

```text
A: deterministic latent correction baseline
B: stochastic residual-flow correction baseline
C: decoder-aware refiner + decoder-aware supervision
```

A/B 用于回答“latent correction 是否有效”以及“correction flow 的随机性是否有帮助”；C 进一步回答“修复是否真正改善了 RGB decoder 的细节重建”。三者应使用独立 checkpoint 和明确的 ablation 表格，不能把 C 的 RGB/high-frequency loss 混入 A/B 后再声称提升来自 refiner architecture。

## 4. Decoder-aware latent refiner (方案 C)

### 4.1 基本接口

对每一个 DeltaTok decode 后的 coarse latent 进行修复：

```text
U_coarse_{t+1} = DeltaTok.decode(z_hat_t, U_t)

d_hat_{t+1} = R(U_t, U_coarse_{t+1})

U_refined_{t+1} = U_coarse_{t+1} + d_hat_{t+1}

I_refined_{t+1} = G(U_refined_{t+1})
```

其中：

- `R` 是 trainable latent refiner；
- `G` 是 DINO-Tok RGB decoder；
- `U_t` 提供上一帧结构参考；
- `U_coarse` 提供当前 coarse prediction；
- `U_refined` 才进入 RGB decoder，也作为下一次 rollout 的 previous latent。

首版 refiner 不显式接收 action 和 horizon。action 已经参与 DeltaWorld-flow 并决定 coarse latent；refiner 的第一职责是修复 coarse latent，而不是重新推断 dynamics。action-conditioned refiner 作为后续 ablation 保留，避免第一版把 motion error、manifold error 和 texture error 混在一起。

### 4.2 推荐的 DDT 结构

首版可复用当前 `refiner` 目录中规划的 DDT 风格结构：

```text
coarse latent tokens -> input projection / norm
previous latent      -> independent cross-attention memory
coarse latent        -> independent cross-attention memory

每个 block:
    self-attention on refiner tokens
    cross-attention to previous latent
    cross-attention to coarse latent
    MLP
    residual gates / AdaLN

output:
    zero-initialized correction head
    refined = coarse + correction
```

空间位置编码复用动态 2D RoPE，使 `16x16` 和 `32x32` latent grid 使用同一模型接口。previous 和 coarse 使用独立的 norm、projection 和 gate，而不是简单拼接成一个 memory bank，原因是两者语义不同：

- previous 是历史结构锚点；
- coarse 是当前需要修复的预测结果。

输出 head 零初始化，使模型初始时满足：

```text
correction = 0
U_refined = U_coarse
```

这样可以先保留 DeltaWorld-flow 的原始行为，再逐步学习修复，不会在训练初期破坏已经存在的 coarse dynamics。

### 4.3 Refiner 训练目标

每个 training sample 使用：

```text
U_target = E(I_{t+1})
U_coarse = DeltaTok.decode(z_hat_t, U_t)
U_refined = U_coarse + R(U_t, U_coarse)
```

如果 RGB decoder 仍然冻结，首版的 decoder-aware RGB target 应优先使用：

```text
I_target_ae = G(U_target)
```

而不是直接把原始 `I_{t+1}` 当作唯一 RGB target。原因是 frozen DINO-Tok decoder 有自己的重建误差，通常不能完全复原 raw image。若直接用 raw image 监督 refiner，refiner 可能为了追逐 decoder 根本无法表达的细节而把 latent 推离 `U_target`，形成 decoder compensation。完成 RAE-style decoder 重训、并确认 clean-latent reconstruction gap 已经足够小后，才适合加入较小权重的 raw RGB loss。

推荐将视觉损失统一命名为 `L_visual`。`L_hf` 可以归入 `L_visual`，但仍然必须保留独立权重和日志项：

```text
L_lat = SmoothL1((U_refined - U_target) / channel_std)

I_refined = G(U_refined)

L_pix = L1(I_refined, I_target_ae)

L_hf = L1(Grad(I_refined), Grad(I_target_ae))

L_visual = lambda_pix * L_pix
         + lambda_hf * L_hf
         + lambda_perc * L_LPIPS

L_task = lambda_depth * L_depth
        + lambda_sem * L_semantic

L_refiner = lambda_lat * L_lat
           + lambda_visual * L_visual
           + lambda_task * L_task
```

其中：

- `channel_std` 使用训练集 GT DINO-Tok latent 的固定 channel statistics；
- `L_lat` 保证输出不要离开目标 latent manifold；
- `L_pix` 让 correction 对 decoder 的整体 RGB 重建有意义；
- `L_hf` 直接约束边缘和局部纹理，避免所有低频区域都通过平均色获得较低的 pixel loss；
- `L_LPIPS` 只在需要感知相似性时启用，不能替代 `L_pix` 或 `L_hf`；
- `L_task` 用深度和语义任务约束 latent 中的几何和语义结构，不负责恢复任意像素纹理。

因此，“把 `L_hf` 归入 `L_rgb`”在损失分组意义上是合理的，推荐使用上面的 `L_visual` 命名；但不能删除 `lambda_hf`，否则普通 RGB L1 对局部高频的梯度约束会变得过弱。

首版不加入 GAN loss。GAN 可能增强视觉锐度，但也可能制造与场景不一致的纹理，使实验无法判断提升来自 latent repair 还是来自 hallucination。LPIPS 可以先作为 validation metric；当 L1、latent loss 和高频指标证明方向有效后，再将 LPIPS 或轻量 perceptual loss 作为独立 ablation。

### 4.3.1 Depth 和 semantic auxiliary losses

depth/semantic loss 是否加入，取决于监督来源：

```text
真实 nuScenes depth/semantic labels:
    可以作为 task supervision

只有 frozen compatibility heads:
    只能构造 teacher/pseudo-label consistency

没有 labels，也没有可信 teacher:
    不加入 task loss，只做 validation metric
```

当前项目的 `kitti` depth head 和 `cityscapes`/`vspw` segmentation heads 是冻结的 compatibility heads，主要用于可视化和跨数据集兼容性检查，并不是针对当前 nuScenes RGB 帧训练的 ground-truth supervision。它们还使用 latent 的兼容 feature slice，而不是完整 832 维 token。因此，直接把它们的输出当作“真实深度/语义 loss”会把 teacher bias 当成事实，也可能把 head 的域偏差传给 refiner。

若拥有与 `I_{t+1}` 对齐的真实标签，建议使用：

```text
depth:
    masked log-depth loss + multiscale depth-gradient loss

semantic:
    cross-entropy + optional Lovasz / boundary loss
```

若没有真实标签但希望利用现有 frozen heads，可以使用 target latent 产生 teacher：

```text
y_depth^T = H_depth(U_target)
y_sem^T   = H_semantic(U_target)

L_depth    = distance(H_depth(U_refined), stopgrad(y_depth^T))
L_semantic = CE(H_semantic(U_refined), argmax(stopgrad(y_sem^T)))
```

这种形式应该称为 `task-consistency loss`，而不是 depth/semantic ground-truth loss，并且必须使用较小权重。它的作用是避免 refiner 为了视觉锐度破坏几何和类别结构，而不是增加纹理信息。

首版建议的优先级为：

```text
L_lat                     主损失
L_pix + L_hf              首先加入的 decoder-aware visual loss
L_depth + L_semantic      有可靠 labels 或 teacher 时低权重加入
L_LPIPS                   先做 validation，再做独立 ablation
GAN                       暂不加入
```

### 4.3.2 `L_hf` 与 LPIPS 的区别

`L_hf` 和 LPIPS 都可以帮助视觉重建，但它们约束的对象不同：

| 项目 | `L_hf` | LPIPS |
|---|---|---|
| 主要输入 | 像素梯度、Laplacian 或 wavelet 高频分量 | 预训练 CNN 的多层 feature |
| 约束性质 | 局部、显式、位置敏感 | 感知级、较能容忍小位移 |
| 对 checkerboard | 通常更直接，能惩罚不应存在的周期梯度 | 可能被 pooling/downsampling 弱化 |
| 对语义和整体观感 | 基本不理解 | 通常更强 |
| 计算与显存 | 低 | 较高 |
| 主要风险 | 可能过度强调边缘或放大噪声 | 可能接受几何错位或“看起来合理”的 hallucination |

因此不存在脱离任务的“哪个绝对更好”：

- 如果目标是减少当前的 blur 和 checkerboard，首版优先 `L_pix + L_hf`；
- 如果目标是提升整体感知质量和纹理自然度，再以较小权重加入 LPIPS；
- LPIPS 不应替代 `L_lat`，否则 refiner 可能为了感知相似性牺牲 DINO-Tok latent contract；
- `L_hf` 应使用 target 与 prediction 的梯度或 Laplacian 差，而不是单独最大化 prediction 的梯度能量，否则会鼓励噪声和 ringing。

推荐的第一组消融为：

```text
A: L_lat
B: L_lat + L_pix
C: L_lat + L_pix + L_hf
D: L_lat + L_pix + L_hf + LPIPS
```

四组都保持同一 coarse latent、refiner 初始化、训练步数和 rollout seed。若 C 已经降低 checkerboard 且 D 只提高主观锐度但降低 latent/geometry 指标，则保留 C；若 D 在 LPIPS 和人眼质量上有稳定增益且没有破坏 task metrics，再将 LPIPS 作为小权重辅助项。

### 4.4 Refiner 的输入分布

如果 refiner 只在 GT pair 上训练，推理时会遇到明显的分布偏移。训练输入应包含以下 coarse source：

1. `z_gt` 经过 DeltaTok decode 得到的 oracle coarse；
2. Flow DiT 采样得到的实际 coarse；
3. closed-loop rollout 中上一帧 refined latent 继续解码得到的 coarse。

推荐先使用实际推理配置产生主要 coarse 分布，例如训练使用 Euler 8 steps，验证使用 Euler 20 steps；再以较小比例加入更低 ODE steps 或受控 latent corruption，增强对低质量输入的鲁棒性。

训练 refiner 时冻结：

- DINOv3 encoder；
- DINO-Tok latent encoder；
- DeltaTok encoder/decoder；
- DeltaWorld-flow。

冻结模型仍需允许 RGB loss 的梯度穿过 DINO-Tok RGB decoder 回到 refiner，但不更新 frozen 参数。每个 rollout frame 的 refined latent 在传入下一步前 detach，以免同时保留整个长序列的计算图。

## 5. RAE-style decoder 路线

### 5.1 RAE-style 的核心思想

RAE-style 的关键并不是给 latent 加随机噪声，而是：

```text
使用已有的高质量表示 encoder
保持 latent 接口和语义结构
重新训练一个更强、更适合重建的 decoder
```

这与当前系统非常匹配：DINO-Tok encoder 已经提供了语义和空间表示，DeltaWorld-flow 也围绕 `832` 维 fused latent 定义了 dynamics 接口。可以先不改变 latent 的定义，只重新训练或微调 RGB decoder，使它：

- 更好地重建 clean DINO-Tok latent；
- 对轻微 latent perturbation 更稳定；
- 在高频边缘和小目标处减少平均化；
- 对 refiner 输出的 latent 分布更加兼容。

当前 DINO-Tok 的 RGB decoder 是确定性的 decoder，不是 VAE decoder。将其按 RAE 思路重训不会破坏 `DeltaTok` 的 action-aligned residual 定义，只改变最后的 latent-to-RGB 映射。

### 5.2 推荐的 decoder 训练阶段

#### Stage D0: clean-latent decoder baseline

冻结 DINOv3 和 DINO-Tok encoder，只训练 RGB decoder：

```text
U = E(I)
I_hat = G_theta(U)
```

使用原始 RGB、L1/MSE、SSIM 或高频梯度损失，建立 clean latent 的重建上限。这个阶段回答：

> 在没有 Flow 和 DeltaTok 误差时，新的 decoder 能否比原 decoder 恢复更多细节？

#### Stage D1: decoder-aware corruption training

在 clean latent reconstruction 的基础上加入与部署接近的 corruption：

```text
U_clean = E(I)
U_corrupt = corruption(U_clean)
I_hat = G_theta(U_corrupt)
```

corruption 的优先级如下：

1. 实际 `DeltaTok.decode(z_flow, U_previous)` 输出；
2. closed-loop rollout 中的 coarse/refined latent；
3. 小幅 channel noise；
4. spatial block masking 或局部 feature dropout；
5. 轻微的 low-pass / high-frequency attenuation。

其中第 1、2 类最重要，因为它们来自真实系统，而不是人工构造的随机噪声。Gaussian noise 只能作为鲁棒性 augmentation，不能被解释为真实 texture uncertainty。

#### Stage D2: joint decoder-refiner training

当 D0/D1 单独验证有效后，再让 refiner 和 decoder 联合微调：

```text
U_refined = U_coarse + R(U_previous, U_coarse)
I_hat = G_theta(U_refined)
```

联合训练必须保留 latent loss，否则 decoder 可能学会补偿一个偏离 DINO-Tok latent manifold 的表示。推荐让 decoder 学习率低于 refiner，并比较：

- frozen decoder + trainable refiner；
- D1 decoder + trainable refiner；
- joint fine-tuning。

只有最后一种在 latent metrics、RGB sharpness 和 rollout consistency 上都改善时，才把 joint fine-tuning 作为主方案。

### 5.3 Decoder 的损失设计

首版 decoder 训练可以采用：

```text
L_decoder = lambda_l1 * L1(I_hat, I)
           + lambda_mse * MSE(I_hat, I)
           + lambda_ssim * (1 - SSIM(I_hat, I))
           + lambda_hf * L1(Grad(I_hat), Grad(I))
```

如果后续加入 LPIPS，应把它作为清晰的独立实验变量。若加入 PatchGAN 或其他 adversarial objective，需要同时报告：

- RGB sharpness；
- target consistency；
- latent cycle distance；
- 多 seed 下的 temporal consistency。

单纯视觉上更锐不等于更准确。尤其在驾驶场景中，GAN 可能生成看似合理但与真实车道、车辆纹理不一致的内容。

### 5.4 RAE-style decoder 的边界

RAE-style decoder 可以提升从已有 latent 恢复图像的能力，但它不能创造 latent 中完全不存在、且无法由上下文确定的真实细节。它解决的是：

- decoder 没有充分利用已有 latent 信息；
- decoder 对轻微 off-manifold 输入不稳定；
- decoder 的重建目标导致高频平均化。

它不能保证：

- 从一个只包含运动信息的 residual 中恢复所有新出现纹理；
- 在多个同样合理的纹理之间选择真实那一个；
- 代替一个显式的 appearance/texture latent。

## 6. Oracle gap 诊断实验

在训练更复杂模块前，先用同一组 previous、target 和 action 分解误差来源。

### 6.1 四个 latent

```text
U_t       = E(I_t)
U_target  = E(I_{t+1})
z_gt      = DeltaTok.encode(U_t, U_target, action_t)
U_oracle  = DeltaTok.decode(z_gt, U_t)
z_flow    = DeltaWorld-flow.sample(U_t, future_actions)
U_flow    = DeltaTok.decode(z_flow, U_t)
```

分别解码：

```text
I_target = G(U_target)
I_oracle = G(U_oracle)
I_flow   = G(U_flow)
```

### 6.2 判别逻辑

| 实验现象 | 主要结论 |
|---|---|
| `I_target` 清晰，`I_oracle` 清晰，`I_flow` 棋盘化 | Flow endpoint error 或 latent manifold drift 是主因 |
| `I_target` 清晰，`I_oracle` 已模糊 | DeltaTok residual capacity 或 DeltaTok decoder 是主因 |
| 增大 `K` 后 `I_oracle` 明显改善 | residual slot bottleneck 是重要因素 |
| clean decoder 改善明显，coarse decoder 仍差 | decoder 对 off-manifold 输入不鲁棒 |
| refiner 改善 latent cycle distance 和 RGB | manifold repair 路线有效 |
| refiner 只改善 RGB、不改善 latent | 可能存在 decoder compensation，应谨慎解释 |

### 6.3 建议指标

每个设置至少记录：

```text
latent SmoothL1 / MSE / cosine distance
latent cycle distance: ||E(G(U)) - U||
RGB L1 / MSE / PSNR / SSIM
LPIPS
gradient or Laplacian high-frequency error
checkerboard energy or periodic artifact score
per-frame and multi-chunk rollout metrics
```

其中 checkerboard score 不应只依赖主观观察。可增加频域分析，统计输出图像在上采样相关周期频率上的能量，并与 target 和 clean reconstruction 对比。

## 7. 为什么首版不直接改成 VAE

### 7.1 VAE 的噪声不是正确纹理信息

VAE 通常学习：

```text
q_phi(z | x) = Normal(mu(x), sigma(x)^2)
z = mu(x) + sigma(x) * epsilon
```

其中 `epsilon` 表示编码不确定性，不表示当前场景真实缺失的纹理。推理时随机采样只能产生 plausible detail，不能知道 target 中实际是哪一种细节。

### 7.2 普通 VAE 可能进一步造成 blur

当一个条件对应多个可能纹理时，像素级 MSE 或高斯似然倾向于输出条件均值。结果可能是：

```text
多种纹理模式
    -> 平均化
    -> 低频图像
    -> patch 内部颜色趋同
```

因此，“加入 VAE noise”与“恢复细节”之间没有直接的因果关系。

### 7.3 VAE 需要一个可用的条件 prior

如果把 target frame 改造成 VAE，需要同时定义：

```text
训练 posterior:
q(T_{t+1} | I_t, I_{t+1}, action)

推理 prior:
p(T_{t+1} | U_t, action)
```

还需要让 prior 和 posterior 对齐：

```text
L = reconstruction/perceptual loss + beta * KL(q || p)
```

否则训练时 encoder 可以从 target 读取纹理，推理时却没有机制生成对应的 texture latent。直接给 DeltaTok residual 加噪声并不能解决这个问题。

### 7.4 Dynamics residual 与 texture latent 不应首版混合

当前 residual 的职责是 action-aligned transition。若让它同时承担：

- ego-motion；
- geometry change；
- appearance uncertainty；
- stochastic texture completion；

那么 flow target 会变成随机变量，action alignment 的解释性和训练稳定性都会下降。更干净的设计是：

```text
motion branch:
    action-conditioned DeltaTok residual

appearance branch:
    optional stochastic texture latent

decoder:
    combine motion-aware latent and texture latent
```

## 8. 后续 texture completion 分支

只有当 Oracle gap 证明 residual/decoder 即使在最优条件下仍不能表达新纹理时，才引入独立 texture branch。

### 8.1 Conditional texture latent

推荐的抽象接口为：

```text
T_target = Q(I_{t+1}, U_t, action_t)
T_hat    = P(U_t, z_motion, action_t)

U_final = Fusion(U_coarse, T_hat)
I_hat   = G_texture(U_final)
```

若目标确实存在多模态不可见区域，可以进一步使用 conditional VAE 或 latent flow：

```text
posterior q(T | I_t, I_{t+1}, action)
prior     p(T | U_t, z_motion, action)
```

训练时使用 KL、latent reconstruction、RGB perceptual 和 high-frequency objectives。此时 stochasticity 的位置和职责是清楚的：它用于 appearance uncertainty，而不是 motion residual。

### 8.2 Alternative: high-resolution texture feature

不一定需要 VAE。也可以增加一个高分辨率但较小通道数的 texture feature：

```text
T_t = TextureEncoder(I_t)
T_{t+1} = TexturePredictor(T_t, U_coarse, action)
I_hat = TextureDecoder(U_coarse, T_{t+1})
```

这个方案更容易保持确定性，也更适合先验证“是否真的是高频信息缺失”。代价是需要重新设计 texture encoder、predictor 和 decoder 的接口。

## 9. 可借鉴架构对比

| 架构 | 是否适合直接替换当前 DeltaTok | 可借鉴内容 | 当前建议 |
|---|---:|---|---|
| Vanilla VAE | 否 | reparameterization、posterior/prior 分离 | 不作为首版方案 |
| VQ-VAE | 否 | 局部离散 texture code、codebook | 作为 texture branch 候选 |
| VQGAN | 否 | perceptual loss、PatchGAN、高频纹理重建 | 后续做高保真 texture tokenizer |
| KL-VAE / LDM VAE | 否 | KL latent、感知重建、稳定 decoder 训练 | 可参考 decoder loss，不直接替换 |
| RAE-style decoder | 是，接口兼容性最好 | 冻结语义 encoder、重训表达力更强的 decoder | 首版 decoder 路线 |
| Conditional VAE | 仅适用于独立 appearance latent | 条件 prior、不可见区域多模态建模 | Oracle gap 证明需要后再做 |
| Latent diffusion / flow decoder | 不直接替换 | 对 coarse latent 做随机或确定性细化 | 作为高成本后续方案 |

## 10. 与 chain-of-forward 的关系

两个模块解决不同问题：

```text
chain-of-forward:
    处理 previous latent 逐步偏离真实分布造成的 AR error accumulation

latent refiner:
    处理单次 DeltaTok/Flow 输出的 latent drift 和 decoder 不兼容

RAE-style decoder:
    处理 decoder 本身的细节利用能力和 off-manifold robustness

texture branch:
    处理 coarse latent 没有表达、且需要生成的外观信息
```

因此不能用 chain-of-forward 的改善来证明纹理问题已经解决。实验时至少报告四种设置：

1. Flow baseline；
2. Flow + chain-of-forward；
3. Flow + refiner/RAE decoder；
4. Flow + chain-of-forward + refiner/RAE decoder。

这样可以分别测量 dynamics stability 和 visual detail recovery 的增益。

## 11. 推荐实验顺序

### Phase A: diagnosis

1. 完成 `U_target`、`U_oracle`、`U_flow` 的 oracle gap 测试；
2. 记录 latent cycle distance 和高频指标；
3. 扫描 `K = 1, 2, 4, 8`，只比较 oracle DeltaTok decode；
4. 判断主因更接近 Flow drift、residual capacity 还是 decoder capacity。

### Phase B: deterministic refiner

1. 实现 zero-init DDT correction head；
2. 先使用 frozen DINO-Tok RGB decoder；
3. 训练 latent + RGB + high-frequency loss；
4. 使用实际 Flow coarse 和 closed-loop coarse 作为训练输入；
5. 评估单帧、4-frame chunk 和 3-chunk rollout。

### Phase C: RAE-style decoder

1. 在 clean DINO-Tok latent 上重训或微调 RGB decoder；
2. 加入 Flow/rollout coarse corruption；
3. 对比原 decoder、clean decoder、corruption-trained decoder；
4. 再测试 refiner 与新 decoder 的组合；
5. 只有在独立实验有效后才做 joint fine-tuning。

### Phase D: stochastic texture branch

仅当以下现象成立时进入：

- oracle residual 也无法恢复目标细节；
- 增大 `K` 和 deterministic refiner 仍存在稳定的 hidden-region detail gap；
- clean/robust decoder 已经不是主要瓶颈。

此时再比较 high-resolution texture feature、VQ/VQGAN texture code、conditional VAE 和 latent flow decoder。

## 12. 论文中的表述

首版可以把方法拆成以下清晰的科学问题：

```text
Action-conditioned dynamics:
    DeltaWorld-flow predicts action-aligned motion residuals.

Latent manifold repair:
    decoder-aware latent refiner maps coarse predicted latents toward
    the target-compatible DINO-Tok latent region.

Detail-aware reconstruction:
    RAE-style decoder training improves the use of semantic latent
    information and robustness to realistic prediction perturbations.

Autoregressive stability:
    chain-of-forward training reduces closed-loop error accumulation.
```

不建议在没有实验支持时写成：

- “VAE noise recovers missing real textures”；
- “refiner guarantees the true hidden content”；
- “checkerboard is caused solely by transposed convolution”；
- “stochastic decoder always improves visual fidelity”。

更准确的表述是：

> The decoder-aware refiner reduces prediction-induced latent drift and improves compatibility with the pretrained visual decoder, while the RAE-style decoder objective enhances detail reconstruction from the available representation. Neither component can recover information that is absent from the motion residual; such uncertainty requires a separate appearance modeling branch.

## 13. 最终建议

当前项目的首版破局顺序应为：

```text
先做 oracle gap 分解
    -> 再确认 K 是否造成 residual bottleneck
    -> 加 deterministic decoder-aware latent refiner
    -> 用 RAE-style 思路重训/增强 RGB decoder
    -> 保留 chain-of-forward 解决 AR accumulation
    -> 最后再考虑独立 stochastic texture latent
```

核心判断是：**VAE 不是 checkerboard 的直接解药，decoder-aware latent repair 才是当前最应该先验证的机制；RAE-style decoder 是增强这一机制的兼容路线，而不是把 DeltaTok 整体重写成 VAE。**

## 14. 参考方向

- Kingma and Welling, *Auto-Encoding Variational Bayes*：VAE posterior、reparameterization 和 KL regularization。
- van den Oord et al., *Neural Discrete Representation Learning*：VQ-VAE 和离散 latent code。
- Esser et al., *Taming Transformers for High-Resolution Image Synthesis*：VQGAN 的 perceptual/adversarial decoder 思路。
- Rombach et al., *High-Resolution Image Synthesis with Latent Diffusion Models*：KL-regularized latent autoencoder 与 latent generative modeling。
- 本项目中的 [RAE-NWM.txt](../../0606-lightworldpred/RAE-NWM.txt)：冻结表示 encoder、使用 RAE-style representation 进行导航 world modeling 的直接参考。
- 本项目中的 [deltaworld-flow/refiner/0828-refiner-design.md](deltaworld-flow/refiner/0828-refiner-design.md)：当前 deterministic refiner、stochastic correction flow 和 closed-loop rollout 的实现设计。
