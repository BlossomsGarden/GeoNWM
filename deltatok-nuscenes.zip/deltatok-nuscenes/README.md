<!-- 现在我已经在另一台训练服务器上训练完毕了 [deltatok-nuscenes](sources/deltatok-nuscenes/) ，即相当于已经将 DINO-Tok 的action-aligned变化量空间提取出来了。现在需要考量的是下一个问题：如何基于这个变化量空间设计自回归式DiT实现future action conditioned变化量空间的rollout。我的计划是这样的——condition encoder: 历史参考末帧的DINO-Tok-AE特征U_i, past  4 delta token chunk, future 4 action chunk（经过DeltaTok的Action Tokenizer模块获取输入） -> Scene-Action Resampler
 -> compact condition tokens C_i。具体架构可以做成Perceiver/Resampler 风格：learnable scene queries cross-attend 到完整 U_i，action chunk tokens 和 past delta tokens 参与 self-attn 或 AdaLN 调制，最后输出 64 个 compact condition tokens。（原因很直接：U_i 必须作为场景锚点存在，否则同一个 action 在不同车道、物体、遮挡、运动状态下对应的变化量是歧义的；但完整 U_i 不应该在每个 flow step 里反复作为 1024 个 token 被 dense attention 消耗。resampler 把它压成“动作相关的场景摘要”，既保留语义/几何锚点，又减少模型追逐静态纹理和 checkerboard 高频误差的机会。）

flow stage: noisy future delta tokens z_tau -> Flow/DiT blocks, cross-attend C_i（noisy future delta tokens  + flow time embedding  + horizon or slot embedding  + action AdaLN gating +  cross-attend / attend to C） -> predict velocity。这里就使用rectified flow 就行。

然后再 sample 获得 deltatoken z，最终输入DeltaTok decoder(U_i, z) 解码出DINO-Tok-AE的特征 U_{i+1}，喂给解码器生成下游模态输出

训练方式上，我会希望是分成几步走，第一步以future 4 action 输入但只输出第1 个delta token（这里采用这种机制而非future 1 action 输入只输出第1 个delta token，核心原因是：condition 可以看远一点，prediction 先走稳一点。单步 action 往往不够表达“意图”，尤其在驾驶场景里，a_i 本身可能只是局部位移/速度/yaw 的一个切片，而未来 3-4 个 action 更像一个短程 intent：直行、刹车、左转、右转、并线、加速。相当于给模型一个短程计划，而不是只给一个局部微分量，可以更好判断下一步变化属于哪条运动模式），到后面才扩张到future 4 action 输入输出4个delta token，并且causal mask over future delta tokens，  each delta_k can see U_i, action chunk, and earlier target/pred delta positions，loss on all 4 deltas, heavier weight on first 1-2 deltas。具体代码实现你可以让模型的代码本身就模型从第一天就支持：past_delta_len = 4，future_action_len = 4，max_pred_horizon = 4，但训练 schedule 根据steps控制当前激活几个阶段的预测目标：第一阶段  active_pred_horizon = 1，  loss_weights = [1.0, 0.0, 0.0, 0.0]，只监督 deltatoken，相当于只训第 1 个 delta；第二阶段逐渐打开第 2/3/4 个 delta 的 loss；最后一个阶段是完整 chunk loss，比如说  active_pred_horizon = 4，  loss_weights = [1.0, 0.7, 0.5, 0.3]

针对condition encoder的past delta token输入，需要在训练时做特殊处理，随机 drop 一部分 history，让模型别过度依赖 oracle history（训练时 past delta 往往来自 GT DeltaTok encoder，推理时 past delta 会逐渐变成模型自己预测的 delta。强依赖 GT history 会让 rollout 更脆），而且需要落一个命令行参数控制是否在训练时使用past  4 delta token chunk，因为其实有种导航情况是仅1初始帧，这种情况下你无处获得 history delta，所以我认为应该优先保证它的接受 历史参考末帧的DINO-Tok-AE特征U_i,  future 4 action chunk（经过DeltaTok的Action Tokenizer模块获取输入） 的能力，如果传入这个控制参数表明训练时不希望使用 past  4 delta token chunk 作为输入的话，那么整个训练流程都不应该出现past_delta_token作为输入。
 
训练数据集你暂时还是用nuscenes吧。————
你暂时先不要急着赶紧去落代码，而是带着详细去实现落地的前提，去分析我的说法是否还存在前后冲突、或者我的规划存在问题可能达不到预期目标、或者我没考虑到某种情况、或者我的说法还不够精确，这些你都不要自己猜测决定，而是以提问的形式向我询问或汇报，由我来做决定。现在开始分析整理信息、询问或汇报吧


针对你提到的冲突点：1、我声明一下，你这里说的“第 1 个 delta token / 输出 4 个 delta token” 确实应该严格理解为 “第 1 个未来时间步 / 未来 4 个时间步的 DeltaTok residual”，也就是目标张量形状为 z_future: [B, H=4, K, 832]，其中 K 沿用 DeltaTok 的 num_delta_tokens，而不是把 DeltaTok 的 K 个 residual slot 当成 horizon。2、我目前暂时先不额外训练它的AR自回归能力，目前就先专注于 “一次 flow 预测 future 4个时间步的 delta Token chunk”，把预测能力学好；3、这个其实是AR稳定性能力吧，就像上一点说到的，我们暂时先不额外训练它的AR，目前先专注于把一次flow的预测能力学好，之后我再制订AR的方案；4、那就删除past delta token吧，干脆直接确认这一版改动不用past delta token输入，以后如果有必要再加；5、future 4 action 也都按照当前action的来，每一个都是相对于上一帧ego坐标系下的[dx, dy, dyaw]，yaw 是 degree。从我理解上来说因为存在 casual mask也就是第一个时间步的delta token在生成时是只能看到未来的action但看不到未来的时间步的delta token的，所以也是可以沿用这种相对于上一帧ego坐标系的变化量的方式执行的；6、你这个判断是对的。我会修正为 curriculum 不能只靠 loss_weights=[1,0,0,0]，而应该调度 active prediction horizon。
我就以第一阶段为例，更正确的第一阶段应该是：
Condition encoder:
  U_i
  future actions a_i:i+3

Flow target branch:
  noisy delta_i only

Loss:
  velocity loss on delta_i only
注意：4 个 future actions 继续保留。因为第一阶段的目的不是“只看一个 action”，而是“看 4 个 action 的短期意图，但只预测下一步变化量”。被 mask 掉的是 inactive future delta target slots，不是 future action tokens。
这里可以用 causal mask：
delta_i       sees delta_i
delta_{i+1}   sees delta_i, delta_{i+1}
delta_{i+2}   sees delta_i, delta_{i+1}, delta_{i+2}
delta_{i+3}   sees delta_i, delta_{i+1}, delta_{i+2}, delta_{i+3}
这样 final stage 才是真的 “4 actions conditioned, generate 4 deltas”，而不是四个 unordered noisy slots 混在一起做 dense joint denoising。
最终的schedule可以这样设置：
Stage 1:
  active_pred_horizon = 1
  flow tokens = [delta_i]
  loss weights = [1.0]

Stage 2:
  active_pred_horizon = 2
  flow tokens = [delta_i, delta_{i+1}]
  loss weights = [1.0, 0.5~0.7]

Stage 3:
  active_pred_horizon = 4
  flow tokens = [delta_i, delta_{i+1}, delta_{i+2}, delta_{i+3}]
  loss weights = [1.0, 0.7, 0.5, 0.3]
 
如果为了静态 shape 或编译必须保留 4 个 tensor slots，那也要用 hard attention mask 让 inactive slots 对 active slots 完全不可见，并且 inactive slots 最好填 null token，不填随机 noise。但从研究定义上，直接 slice 掉最清楚。（例如active_h = schedule(global_step)

target_delta = target_delta[:, :active_h]
noise = noise[:, :active_h]
noisy_delta = noisy_delta[:, :active_h]

pred_v = model(
    condition_actions=actions[:, :4],
    noisy_delta=noisy_delta,
    active_horizon=active_h,
)

loss = weighted_loss(pred_v, target_v[:, :active_h])）（补充：如果想更干净，也当然也可以直接 1 -> 4，但我更喜欢中间加 2，因为它让模型先学会“预测第二个 delta 必须依赖第一个 delta 的动态”，再扩到 4 步。） -->

<!-- 我会选 两路注入，但不是无约束地把 action 到处塞。我建议是首先使用现在的 DeltaTok ActionTokenizer（它已经是连续 action 的 typed-token 编码）针对每个时间步的 (Δx, Δy, Δθ) 输出 3 个高维 token，这便是 12 个 action condition tokens

Route A: Scene-Action Resampler
  U_i + 12 action tokens -> compact condition tokens C_i

Route B: Direct Action Injection in Flow DiT
  12 action tokens -> action plan vector / per-step action embedding
  用于 DiT 的 AdaLN/gating，以及每个 delta slot 的 step-local bias

原因是 C_i 的职责应该是 action-aware scene summary：告诉生成器“在当前场景里，这段动作计划会影响哪些语义/几何区域”。但 action 本身的 (Δx, Δy, Δθ) 数值、时间顺序、轴向结构，不应该完全依赖 64 个 compact scene tokens 保留下来。否则 resampler 很容易被 U_i 的大视觉信息主导，把细小 yaw / lateral motion 压弱。 -->
 
<!-- 我建议首版用 每个时间步内 3 个 action tokens 做一个小 self-attn/MLP pooling，得到 [B,4,C] 的 step action embedding，再从 [B,4,C] pooled/attn 得到全局 action plan vector。这样既保留 x/y/yaw 的 typed 结构，又不会让 DiT 每层直接 attend 12 个 action tokens。
你希望 Route B 采用这个“per-step pooling + global plan pooling”的形式吗？
你的方案我觉得是对的，而且比“12 个 action tokens 直接喂进每层 DiT cross-attn”更合适。12 个 token 真正的问题是条件语义太散，DiT 可能学到“什么时候看哪个 action token”这件事，而不是专注建模 delta manifold 的 flow。该方案把 action 分成两个层级：当前 horizon step 的局部动作控制、未来 4 步的整体驾驶意图，这非常适合你的任务。我更喜欢 tiny self-attn，因为它自然建模 forward motion + yaw、lateral shift + yaw 这种耦合关系。每步只有 4 个 token，计算量几乎可以忽略。 -->

<!-- 
DiT 的模型宽度沿用832/13 heads吧，没有强的升维理由，也没必要降低来引入信息瓶颈。我会这样设计：
external_dim = 832
model_dim = 832
num_heads = 13
head_dim = 64

ActionTokenizer: 832, 可从 DeltaTok 初始化
Action tiny self-attn: 832 / 13 heads
Scene-Action Resampler: 832 / 13 heads
Flow DiT: 832 / 13 heads
Output velocity: 832
但模块接口写成：
residual_dim = 832
action_dim = 832
model_dim = 832 by default

if model_dim ！= residual_dim:
  input_proj = Linear(832, model_dim)
  output_proj = zero-init Linear(model_dim, 832)
另外，“无投影”不等于直接粗暴拼接。仍然要有 modality-specific LayerNorm/RMSNorm、segment embedding、horizon embedding、zero-init output head。U_i、past delta、action token 虽然同宽，但分布完全不同。 -->

<!-- 我不建议把 K/V = [U_i tokens + action tokens] 直接拼在一起。主设计我会选：分段 cross-attn，并且 action 先、scene 后。
A12 = ActionTokenizer(a_i:i+3)        # [B,4,3,C] -> [B,12,C]
S4  = StepActionPooler(A12)           # [B,4,C]
p   = PlanPooler(S4)                  # [B,C]

Q0:
  64 queries = 4 horizon groups x 16 queries
  Q[h,m] = learnable_query[m] + horizon_emb[h] + step_proj(S4[h]) + plan_proj(p)

Resampler block:
  1. query self-attn
  2. query -> action cross-attn, K/V = A12, gated / lightweight
  3. query -> scene cross-attn, K/V = U_i spatial tokens
  4. MLP, AdaLN/gated by p

最后：
C_i = flatten(Q)  # [B,64,832]
为什么不拼接 [scene + action]
拼接的表面好处是简单，但归纳偏置不太对。U_i 有上千个 spatial tokens，action 只有 12 个 tokens；放进同一个 attention softmax 里，action token 要么被大量 scene token 稀释，要么模型被迫学出很强的 action-token norm/scale 来抢注意力。这样 action 的角色会变得不稳定。
更重要的是，scene token 和 action token 的语义角色不同：
scene tokens: 被查询的视觉/几何内容
action tokens: 指导应该查询哪些 scene 内容
把它们放到同一个 KV 池里，会让 action 同时扮演“内容”和“控制信号”，边界比较脏。分段 cross-attn 可以明确告诉模型：先用 action 改写 query 的意图，再用这些 action-aware queries 去场景里取信息。
为什么 action 先、scene 后
如果先 attend scene，再 attend action，第一步得到的是 generic scene summary。64 个 query 可能已经被静态道路、背景、纹理占掉容量，后面 action 再来只是修饰这些 summary。
而目标是：
给定未来动作，压缩当前场景中与这段动作相关的部分
所以 query 应该先被 action 变成“左转/直行/加速/刹车相关的查询器”，再去 U_i 里读取 lane boundary、前车、可行驶区域、遮挡和远近结构。
这样 C_i 不是普通压缩后的场景 token，而是 future-action-indexed scene condition tokens。这和你的主线非常贴：用 action-aligned delta space 做 rollout，同时让当前场景压缩过程本身也被未来动作计划结构化。 -->

<!-- 下一个关键问题是 Flow DiT 里 cross-attend C_i 的范围。
因为 C_i 本身已经分成 4 个 horizon groups，每组 16 个 query。对于预测 delta_h 的 flow token，你希望它：
attend 所有 64 个 C_i，因为第 1 步也允许看完整 4-action intent；
只 attend 自己对应 horizon 的 16 个 C_i[h]，更强 step-local；
attend C_i[:h+1]，和 delta causal mask 一致，但会削弱“第 1 步看完整意图”的初衷。
选 1：Flow delta tokens 对 C_i 全量 cross-attn，causal mask 只约束 noisy delta target tokens 之间的可见性。这样 delta_i 不能偷看未来 noisy deltas，但仍然能用完整 future action-aware scene summary。
更精确地说：
causal mask 只作用在 noisy future delta target tokens 之间
cross-attn to C_i 不做 horizon-causal mask
理由是：C_i 是由 U_i + future actions a_i:i+3 得到的条件，不是未来 GT delta。future actions 在你的任务定义里本来就是可用条件，所以 delta_i 看完整 4-action intent 没有信息泄漏。我会把可见性定义成：
delta self-attn:
  delta_h 只能看 delta_0:h

delta -> condition cross-attn:
  delta_h 可以看 C_i[0:4, all 16 queries]

DiT modulation:
  所有 delta_h 共享 plan_emb
  每个 delta_h 加自己的 step_action_emb[h]
这样区分很干净：
不能看：未来 noisy/target delta slots
可以看：完整 future action-conditioned scene summary -->

<!-- 现在 z_future 是 [B,H,K,832]。当 K>1 时，DiT 的 token 序列组织方式为：
把每个 (h,k) 都作为一个 token，序列长度 active_h * K，causal mask 按 horizon 分组：h 可以看所有 <=h 的 K slots，同一 horizon 内的 K slots 彼此可见。

不做 dataset-level per-dim mean/std normalization，直接在 raw DeltaTok residual space 上做 flow。当前 DeltaTok encoder 输出的 residual_tokens 已经过 LayerNorm，形状是 [B,K,832]，理论上可以直接在 raw residual space 上做 flow，最后采样出的 z 也能直接喂给 DeltaTok decoder。 -->



# DeltaTok nuScenes

This branch trains DeltaTok on nuScenes `CAM_FRONT` keyframe pairs using the 832-channel DINO-Tok AE fused latent.

## Training contract

- Input: consecutive `(x_{t-1}, x_t)` `CAM_FRONT` keyframes.
- Action: online `[Delta x, Delta y, Delta yaw]` from consecutive ego poses, with yaw in degrees and the previous ego frame as reference. `Delta y` follows the nuScenes ego convention (`+y` points left).
- Encoder: learnable `K` residual queries plus three Fourier action tokens, previous fused latent, and current fused latent.
- Decoder: previous fused latent plus residual tokens produces `x_t_hat`.
- Main objectives: fused-latent reconstruction loss and motion Huber loss over pooled residual tokens.
- RGB: frozen DINO-Tok decode for qualitative visualization only; no RGB reconstruction loss.
- Optional compatibility views: existing semantic/depth heads consume the last 768 latent channels for display only, as requested. DINO-Tok actually concatenates `[deep 768, shallow 64]`, so this slice is not identical to the original deep feature and its visual quality is not a primary model metric.

## Remote data and weights

See [`REMOTE_SERVER.md`](REMOTE_SERVER.md) for the server paths, CSV contract, DINO-Tok checkpoint download, and 2-GPU DDP launch command.

The CSVs are:

```text
/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv
/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv
```

The image paths in the CSV are resolved directly against the nuScenes root when they are relative. On the current server, images are under `nuscenes_root/samples`, while pose and calibration metadata are under `nuscenes_root/v1.0-trainval`; this nested layout is intentional. Large metadata tables are streamed and filtered to `CAM_FRONT` entries during dataset setup.

## Two-stage recipe

### Stage 1: 256 pretrain

```bash
export CUDA_VISIBLE_DEVICES=2,3
python main.py fit \
  -c configs/deltatok_nuscenes_256.yaml \
  --trainer.devices=2 \
  --trainer.strategy=ddp
```

### Stage 2: 512 fine-tune

```bash
export CUDA_VISIBLE_DEVICES=2,3
python main.py fit \
  -c configs/deltatok_nuscenes_512.yaml \
  --model.ckpt_path=/path/to/stage1/last.ckpt \
  --trainer.devices=2 \
  --trainer.strategy=ddp
```

The 512 stage keeps the same dataset and model family while changing the latent grid from `16x16` to `32x32`.
Use `WANDB_MODE=offline` on the server when no W&B login is configured; validation RGB and latent visualizations remain in the local W&B run directory.

## Smoke checks

Before a long run, execute the 2-GPU `fast_dev_run=1` command in `REMOTE_SERVER.md`, then verify:

1. Load one train and one validation batch and verify `frames.shape == [B, 2, 3, H, W]` and `action.shape == [B, 3]`.
2. Run DINO-Tok encode/decode and verify latent width `832` plus a nonblank RGB output.
3. Run one forward/backward step and verify finite `latent_loss`, `motion_loss`, and total loss.
4. Run one validation batch and inspect RGB decode and latent PCA images.
