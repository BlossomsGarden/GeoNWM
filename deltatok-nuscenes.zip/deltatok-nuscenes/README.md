# DeltaTok nuScenes

This branch trains DeltaTok on nuScenes `CAM_FRONT` keyframe pairs using the 832-channel DINO-Tok AE fused latent.

## Training contract

- Input: consecutive `(x_{t-1}, x_t)` `CAM_FRONT` keyframes.
- Action: online `[Delta x, Delta y, Delta yaw]` from consecutive ego poses, with yaw in degrees and the previous ego frame as reference. `Delta y` follows the nuScenes ego convention (`+y` points left).
- Encoder: learnable `K` residual queries plus three Fourier action tokens, previous fused latent, and current fused latent.
- Decoder: previous fused latent plus residual tokens produces `x_t_hat`.
- Main objectives: fused-latent reconstruction loss and motion Huber loss over pooled residual tokens.
- RGB: frozen DINO-Tok decode for qualitative visualization only; no RGB reconstruction loss.
- Optional compatibility views: existing semantic/depth heads consume the last 768 latent channels for display only, as requested. DINO-Tok actually concatenates `[deep 768, shallow 64]`, so this slice is not identical to the original deep feature and its visual quality is not a primary model metric.

## Remote data and weights

See [`REMOTE_SERVER.md`](REMOTE_SERVER.md) for the server paths, CSV contract, DINO-Tok checkpoint download, and 2-GPU DDP launch command.

The CSVs are:

```text
/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv
/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv
```

The image paths in the CSV are resolved directly against the nuScenes root when they are relative. On the current server, images are under `nuscenes_root/samples`, while pose and calibration metadata are under `nuscenes_root/v1.0-trainval`; this nested layout is intentional. Large metadata tables are streamed and filtered to `CAM_FRONT` entries during dataset setup.

## Two-stage recipe

### Stage 1: 256 pretrain

```bash
export CUDA_VISIBLE_DEVICES=2,3
python main.py fit \
  -c configs/deltatok_nuscenes_256.yaml \
  --trainer.devices=2 \
  --trainer.strategy=ddp
```

### Stage 2: 512 fine-tune

```bash
export CUDA_VISIBLE_DEVICES=2,3
python main.py fit \
  -c configs/deltatok_nuscenes_512.yaml \
  --model.ckpt_path=/path/to/stage1/last.ckpt \
  --trainer.devices=2 \
  --trainer.strategy=ddp
```

The 512 stage keeps the same dataset and model family while changing the latent grid from `16x16` to `32x32`.
Use `WANDB_MODE=offline` on the server when no W&B login is configured; validation RGB and latent visualizations remain in the local W&B run directory.

## Smoke checks

Before a long run, execute the 2-GPU `fast_dev_run=1` command in `REMOTE_SERVER.md`, then verify:

1. Load one train and one validation batch and verify `frames.shape == [B, 2, 3, H, W]` and `action.shape == [B, 3]`.
2. Run DINO-Tok encode/decode and verify latent width `832` plus a nonblank RGB output.
3. Run one forward/backward step and verify finite `latent_loss`, `motion_loss`, and total loss.
4. Run one validation batch and inspect RGB decode and latent PCA images.
