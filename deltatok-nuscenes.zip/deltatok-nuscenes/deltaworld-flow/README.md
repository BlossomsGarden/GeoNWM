# DeltaWorld Flow

Future-action-conditioned rectified flow over the frozen DeltaTok residual
space. The model predicts a four-step residual chunk in one flow sample, then
uses the frozen DeltaTok decoder recursively for rollout visualization.

## Contract

- Dataset: consecutive five-keyframe `CAM_FRONT` nuScenes windows.
- Input frames: `[B, 5, 3, H, W]` for keyframes `i ... i+4`.
- Input actions: `[B, 4, 3]` for local ego-motion `i->i+1 ... i+3->i+4`.
- Frozen tokenizer: DINO-Tok encode/decode, DeltaTok encoder/decoder, and
  DeltaTok ActionTokenizer.
- Trainable modules: action poolers, Scene-Action Resampler, Flow DiT, and the
  zero-initialized velocity head.
- Flow space: raw DeltaTok residual tokens, no extra residual normalization.
- Training loss: horizon-weighted velocity MSE over the active curriculum
  horizon.

## DeltaTok Checkpoint

The config files set `model.init_args.network.init_args.delta_tok.init_args.ckpt_path`
to `null` because the trained DeltaTok checkpoint path is server-specific. Set it
before any real run:

```bash
--model.network.delta_tok.ckpt_path=/path/to/trained/deltatok.ckpt
```

or edit the YAML value directly.

The checkpoint should match the configured `num_delta_tokens`, image resolution,
DINO-Tok AE checkpoint, and action normalization statistics.

## Smoke Run

```bash
cd /data/wlh/DeltaWorld/deltaworld-flow
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate deltaworld
export CUDA_VISIBLE_DEVICES=2,3

WANDB_MODE=disabled python main.py fit \
  -c configs/deltaflow_nuscenes_256.yaml \
  --model.network.delta_tok.ckpt_path=/path/to/trained/deltatok.ckpt \
  --trainer.fast_dev_run=1
```

## Two-GPU Launch

```bash
cd /data/wlh/DeltaWorld/deltaworld-flow
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate deltaworld
export CUDA_VISIBLE_DEVICES=2,3

WANDB_MODE=offline python main.py fit \
  -c configs/deltaflow_nuscenes_256.yaml \
  --model.network.delta_tok.ckpt_path=/path/to/trained/deltatok.ckpt \
  --trainer.devices=2 \
  --trainer.strategy=ddp
```

For 512-resolution training, use `configs/deltaflow_nuscenes_512.yaml` and a
DeltaTok checkpoint trained with matching 512 latent geometry.

## Metrics

Validation logs teacher-forced flow metrics:

```text
teacher_forced_velocity_mse_total
teacher_forced_velocity_mse_h1 ... h4
```

It also samples a four-step residual chunk with a 20-step Euler ODE sampler and
logs residual diagnostics:

```text
sampled_z_mse_total
sampled_z_mse_h1 ... h4
```

For the first validation examples, W&B receives rollout images with the input
RGB, ground-truth future RGB frames, sampled rollout RGB frames, and latent PCA
diagnostics.

## Local Checks

From the repository workspace:

```powershell
python -m compileall sources/deltatok-nuscenes/deltaworld-flow
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/tests -q
```

The pytest suite requires the training environment dependencies, especially
PyTorch and Lightning.
