from __future__ import annotations

import logging
import sys
import warnings
from datetime import datetime
from importlib.metadata import distributions
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parent
PARENT_ROOT = PROJECT_ROOT.parent
for path in (str(PARENT_ROOT), str(PROJECT_ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

import torch
from dotenv import load_dotenv
from lightning import Trainer
from lightning.pytorch import cli
from lightning.pytorch.callbacks import (
    Callback,
    LearningRateMonitor,
    ModelCheckpoint,
    ModelSummary,
)

from deltaflow.training import DeltaWorldFlowModule


class LogRun(Callback):
    """Capture code and package versions needed to reproduce a run."""

    def setup(
        self, trainer: Trainer, pl_module: DeltaWorldFlowModule, stage: str
    ) -> None:
        if trainer.logger is not None:
            trainer.logger.experiment.log_code(
                ".",
                include_fn=lambda filename: filename.endswith(
                    (".py", ".yaml", ".md", ".env")
                ),
            )

    def on_train_start(
        self, trainer: Trainer, pl_module: DeltaWorldFlowModule
    ) -> None:
        if not trainer.is_global_zero or trainer.logger is None:
            return
        experiment = trainer.logger.experiment

        experiment_dir = experiment.dir
        if callable(experiment_dir):
            experiment_dir = experiment_dir()
        if experiment_dir and Path(experiment_dir).exists():
            pkg_path = Path(experiment_dir) / f"pip-freeze-step{trainer.global_step}.txt"
            pkgs = sorted(f"{d.name}=={d.version}" for d in distributions())
            pkg_path.write_text("\n".join(pkgs))
            experiment.save(str(pkg_path), policy="now")

        entry = f"[step {trainer.global_step}] {datetime.now().isoformat()}\n$ {' '.join(sys.argv)}"
        experiment.notes = f"{experiment.notes or ''}\n{entry}".strip()


class LightningCLI(cli.LightningCLI):
    def __init__(self, *args: Any, **kw: Any) -> None:
        load_dotenv()
        torch.set_float32_matmul_precision("high")
        torch.backends.cudnn.benchmark = True
        logging.getLogger().setLevel(logging.INFO)
        warnings.filterwarnings(
            "ignore", message=r".*Found .* module\(s\) in eval mode.*"
        )
        warnings.filterwarnings(
            "ignore", message=r".*Precision bf16-mixed is not supported.*"
        )
        super().__init__(*args, **kw)


def cli_main() -> None:
    LightningCLI(
        DeltaWorldFlowModule,
        subclass_mode_model=True,
        subclass_mode_data=True,
        save_config_callback=None,
        seed_everything_default=0,
        trainer_defaults={
            "max_epochs": -1,
            "accelerator": "gpu",
            "devices": 2,
            "strategy": "ddp",
            "precision": "bf16-mixed",
            "enable_model_summary": False,
            "log_every_n_steps": 1,
            "check_val_every_n_epoch": None,
            "val_check_interval": 5000,
            "callbacks": [
                ModelSummary(max_depth=3),
                LearningRateMonitor(logging_interval="step"),
                LogRun(),
                ModelCheckpoint(every_n_train_steps=50000, save_top_k=-1),
                ModelCheckpoint(monitor="losses/val", mode="min", save_top_k=1),
                ModelCheckpoint(
                    every_n_train_steps=500,
                    save_last=True,
                    save_top_k=0,
                    enable_version_counter=False,
                ),
            ],
            "logger": {
                "class_path": "lightning.pytorch.loggers.wandb.WandbLogger",
                "init_args": {
                    "project": "deltaworld-flow",
                    "save_dir": str(PROJECT_ROOT / "runs"),
                },
            },
        },
    )


if __name__ == "__main__":
    cli_main()
