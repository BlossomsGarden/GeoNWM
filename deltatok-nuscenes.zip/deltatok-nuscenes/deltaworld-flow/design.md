DeltaTok 432M
DeltaWorld-Flow 291M

# DeltaWorld Flow Design

## 1. Scope

`deltaworld-flow` trains a future-action-conditioned rectified-flow model on top
of a frozen DeltaTok tokenizer. The pairwise DeltaTok model is treated as the
provider of the action-aligned residual space and as the decoder used for
rollout visualization. This project does not continue training DeltaTok itself.

The first version focuses on one-shot chunk prediction for four future residual
steps. It does not train a strict autoregressive sampler. Sampling produces a
four-step residual chunk at once, and DeltaTok decoding is then applied
recursively for visualization and downstream latent rollout.

Excluded from this version:

- no past delta token input;
- no additional AR stability objective;
- no offline latent or residual cache;
- no dataset-level residual mean/std normalization;
- no RGB, semantic, depth, or latent rollout loss;
- no future ground-truth delta tokens in the condition branch.

## 2. Data Contract

The nuScenes dataset returns consecutive `CAM_FRONT` keyframe windows. Each
sample contains five frames and four local ego-motion actions:

```text
frames:  [B, 5, 3, H, W]   # keyframes i ... i+4
actions: [B, 4, 3]         # i->i+1 ... i+3->i+4
```

Each action keeps the existing DeltaTok convention:

```text
[Delta x, Delta y, Delta yaw]
```

The displacement is measured in the previous frame ego coordinate system.
`Delta y` follows the nuScenes ego convention where positive is left. Yaw is in
degrees. Sequence construction requires `frame_id + 1` continuity for every
neighboring pair in the five-frame window; there is no stride or variable-time
sampling in the first version.

## 3. Frozen Online Target Extraction

Training computes targets online so that the flow model always sees residuals
from the currently loaded DeltaTok checkpoint.

```text
U_seq = DINO-Tok.encode(frames)  # [B, 5, N, 832]

z_0 = DeltaTok.encode(U_0, U_1, action_0)
z_1 = DeltaTok.encode(U_1, U_2, action_1)
z_2 = DeltaTok.encode(U_2, U_3, action_2)
z_3 = DeltaTok.encode(U_3, U_4, action_3)

z_future = stack(z_0, z_1, z_2, z_3)  # [B, 4, K, 832]
```

The full DeltaTok checkpoint is loaded, then these components are frozen and
kept in eval mode:

- DINO-Tok encoder and decoder;
- DeltaTok encoder;
- DeltaTok decoder;
- DeltaTok ActionTokenizer.

Only the new flow-side modules are trainable: the action poolers, the
Scene-Action Resampler, the Flow DiT blocks, and the velocity head.

## 4. Dimensions And Modality Boundaries

The default model keeps the DeltaTok residual width throughout the network:

```text
residual_dim = 832
action_dim = 832
model_dim = 832
num_heads = 13
head_dim = 64
```

Module interfaces still expose `residual_dim`, `action_dim`, and `model_dim`.
If a future experiment changes `model_dim`, input and output projections connect
the model width to the residual/action widths. The default path uses no such
projection.

Equal width does not mean equal distribution. Scene tokens, residual tokens,
action tokens, and query tokens use modality-specific normalization and segment
or slot embeddings. The velocity output head is zero-initialized.

## 5. Action Encoding

The frozen DeltaTok ActionTokenizer encodes the four future actions. For each
time step, it emits three typed high-dimensional tokens for `Delta x`, `Delta y`,
and `Delta yaw`:

```text
actions [B, 4, 3]
  -> action_tokens [B, 4, 3, 832]
  -> A12 [B, 12, 832]
```

These action tokens feed two routes.

### Route A: Scene-Action Resampler

Route A uses the full action token set to turn scene queries into
future-action-indexed scene queries, then reads from the current scene latent
`U_i`.

### Route B: Direct Action Injection

Route B summarizes action tokens into both step-local and global action
conditioning:

```text
per step:
  [learnable step query, A_dx, A_dy, A_yaw]
  -> tiny self-attention
  -> step_action_emb [B, 4, 832]

global:
  step_action_emb
  -> plan pooler
  -> plan_emb [B, 832]
```

The tiny self-attention preserves coupling between forward motion, lateral
motion, and yaw without forcing every Flow DiT block to route over twelve raw
action tokens.

## 6. Scene-Action Resampler

The resampler produces compact condition tokens from the current latent scene
anchor and the future action plan.

The initial query layout is four horizon groups with sixteen queries per group:

```text
64 queries = 4 horizon groups x 16 queries

Q[h, m] = learnable_query[m]
        + horizon_emb[h]
        + step_proj(step_action_emb[h])
        + plan_proj(plan_emb)
```

Each resampler block applies the following sequence:

```text
1. query self-attention
2. query -> action cross-attention, K/V = A12, gated and lightweight
3. query -> scene cross-attention, K/V = U_i spatial tokens
4. MLP, AdaLN or gating conditioned by plan_emb
```

Action and scene tokens are not concatenated into a single key/value pool. The
action cross-attention first updates query intent; the scene cross-attention then
uses those action-aware queries to retrieve relevant visual and geometric content
from `U_i`.

The output is:

```text
C_i [B, 64, 832]
```

`C_i` is a compact future-action-indexed scene condition, not a generic scene
compression.

## 7. Flow DiT Tokenization

The flow branch predicts DeltaTok residual slots for the active prediction
horizon:

```text
z_future:    [B, active_h, K, 832]
flow_tokens: [B, active_h * K, 832]
```

Each `(h, k)` pair is one Flow DiT token. Horizon embeddings distinguish the
future time step; slot embeddings distinguish the DeltaTok residual slot. This
keeps support for `K > 1` even when the current DeltaTok checkpoint uses `K = 1`.

The causal self-attention mask is grouped by horizon:

```text
token(h, k) can attend token(h2, k2) iff h2 <= h
```

All slots inside the same horizon can see each other.

## 8. Flow DiT Blocks

Each Flow DiT block uses explicit delta self-attention and condition
cross-attention:

```text
1. causal delta self-attention
2. delta -> C_i cross-attention
3. MLP
```

The cross-attention to `C_i` is not horizon-causally masked:

```text
delta_h can attend all C_i[0:4, all 16 queries]
```

This is allowed because `C_i` is built from the current scene latent and the
future action plan, both of which are valid conditions. The only prohibited
information path is from future noisy or target delta slots into earlier delta
slots.

Conditioning is separated into global and token-local signals:

```text
global AdaLN/gating:
  flow_time_emb + plan_emb

local token signal:
  step_action_emb[h] + horizon_emb[h] + slot_emb[k]
```

The model predicts velocity with shape `[B, active_h, K, 832]`.

## 9. Rectified Flow Objective

The flow direction uses the common noise-to-data convention:

```text
x0 = noise
x1 = target_z
tau ~ Uniform(0, 1)

x_tau = (1 - tau) * x0 + tau * x1
v_target = x1 - x0
```

`tau` is sampled once per sample and shared by the active chunk. Noise is still
independent per residual token and channel.

The training loss is horizon-weighted MSE over active horizons only:

```text
loss = weighted_mean(||v_pred - v_target||^2)
```

Residuals are trained in the raw DeltaTok residual space. The sampled residuals
are fed directly into the frozen DeltaTok decoder.

## 10. Horizon Curriculum

The model supports `past_delta_len = 0`, `future_action_len = 4`, and
`max_pred_horizon = 4` from the start. Curriculum changes only the active target
horizon. Future action tokens remain available in every stage.

Default schedule:

```yaml
horizon_schedule:
  - until_step: 100000
    active_horizon: 1
    loss_weights: [1.0]
  - until_step: 200000
    active_horizon: 2
    loss_weights: [1.0, 0.7]
  - until_step: null
    active_horizon: 4
    loss_weights: [1.0, 0.7, 0.5, 0.3]
```

Inactive future delta target slots are sliced out before noise sampling and Flow
DiT execution. They are not merely given zero loss. If static shapes are ever
needed for compilation, inactive slots must be hidden from active tokens by a
hard attention mask and should use null tokens instead of random noise.

## 11. Sampling And Rollout

Sampling starts from Gaussian noise and integrates the rectified-flow ODE from
`tau = 0` to `tau = 1`. The default validation sampler uses 20 steps.

The flow model samples a residual chunk in one pass:

```text
z_hat [B, 4, K, 832]
```

DeltaTok decoding then performs recursive latent rollout:

```text
U_hat_{i+1} = DeltaTok.decode(z_hat_0, U_i)
U_hat_{i+2} = DeltaTok.decode(z_hat_1, U_hat_{i+1})
U_hat_{i+3} = DeltaTok.decode(z_hat_2, U_hat_{i+2})
U_hat_{i+4} = DeltaTok.decode(z_hat_3, U_hat_{i+3})
```

This recursive decoding is for rollout evaluation and visualization. It does not
make the Flow DiT sampler itself autoregressive.

## 12. Validation

Validation reports teacher-forced flow metrics and sampled diagnostics.

Main metrics:

```text
teacher_forced_velocity_mse_total
teacher_forced_velocity_mse_h1
teacher_forced_velocity_mse_h2
teacher_forced_velocity_mse_h3
teacher_forced_velocity_mse_h4
```

Sampled residual diagnostics:

```text
sampled_z_mse_total
sampled_z_mse_h1
sampled_z_mse_h2
sampled_z_mse_h3
sampled_z_mse_h4
```

For a small fixed number of validation examples, the model also logs RGB rollout
visualizations:

```text
input RGB i
ground-truth future RGB i+1 ... i+4
sampled rollout RGB i+1 ... i+4
optional latent PCA views
```

The visualization path decodes sampled latent rollout with the frozen DINO-Tok
decoder and never contributes to training loss.

## 13. Project Layout

All new files for this project live under:

```text
sources/deltatok-nuscenes/deltaworld-flow/
```

The implementation can reuse the parent DeltaTok project as a local dependency,
including:

```text
../models/deltatok.py
../models/action_tokenizer.py
../models/dinotok_wrapper.py
../training/base.py patterns
../datasets/nuscenes.py utilities
```

The flow project should keep separate names for its modules and configs so that
pairwise DeltaTok tokenizer training remains distinct from future delta-flow
training.
