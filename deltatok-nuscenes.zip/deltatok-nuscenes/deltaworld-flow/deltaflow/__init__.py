from __future__ import annotations

__all__ = ["DeltaWorldFlow", "DeltaWorldFlowModule"]


def __getattr__(name: str):
    if name == "DeltaWorldFlow":
        from deltaflow.model import DeltaWorldFlow

        return DeltaWorldFlow
    if name == "DeltaWorldFlowModule":
        from deltaflow.training import DeltaWorldFlowModule

        return DeltaWorldFlowModule
    raise AttributeError(name)
