from __future__ import annotations

from collections.abc import Iterable
from typing import TypeVar


T = TypeVar("T")


def build_consecutive_windows(
    rows: list[T], frame_ids: Iterable[int], length: int = 5
) -> list[tuple[T, ...]]:
    """Return windows whose frame ids increase by one at every step."""
    ids = list(frame_ids)
    if len(rows) != len(ids):
        raise ValueError("rows and frame_ids must have the same length")
    if length < 2:
        raise ValueError("length must be at least 2")

    windows: list[tuple[T, ...]] = []
    for start in range(0, len(rows) - length + 1):
        base = ids[start]
        if all(ids[start + offset] == base + offset for offset in range(length)):
            windows.append(tuple(rows[start : start + length]))
    return windows
