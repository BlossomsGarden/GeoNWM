from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from deltaflow.modules import FlowDiT, SceneActionResampler, StepActionPooler


class DeltaWorldFlow(nn.Module):
    """Rectified flow model over frozen DeltaTok residual tokens."""

    def __init__(
        self,
        delta_tok: nn.Module | None = None,
        residual_dim: int = 832,
        action_dim: int = 832,
        model_dim: int = 832,
        num_heads: int = 13,
        future_action_len: int = 4,
        max_pred_horizon: int = 4,
        max_delta_tokens: int | None = None,
        action_pool_depth: int = 2,
        resampler_depth: int = 4,
        queries_per_horizon: int = 16,
        flow_depth: int = 12,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        if delta_tok is None:
            raise ValueError("delta_tok must be provided as a frozen DeltaTok module")
        if future_action_len != 4:
            raise ValueError("DeltaWorld Flow currently requires future_action_len=4")
        if max_pred_horizon != 4:
            raise ValueError("DeltaWorld Flow currently requires max_pred_horizon=4")

        self.delta_tok = delta_tok
        self.residual_dim = residual_dim
        self.action_dim = action_dim
        self.model_dim = model_dim
        self.future_action_len = future_action_len
        self.max_pred_horizon = max_pred_horizon
        self.num_delta_tokens = int(
            max_delta_tokens
            if max_delta_tokens is not None
            else getattr(delta_tok, "num_delta_tokens", 1)
        )
        self._freeze_delta_tok()

        self.scene_proj = (
            nn.Identity()
            if residual_dim == model_dim
            else nn.Linear(residual_dim, model_dim)
        )
        self.action_proj = (
            nn.Identity() if action_dim == model_dim else nn.Linear(action_dim, model_dim)
        )
        self.action_pooler = StepActionPooler(
            model_dim=model_dim,
            num_heads=num_heads,
            depth=action_pool_depth,
            max_horizon=future_action_len,
            mlp_ratio=2.0,
        )
        self.resampler = SceneActionResampler(
            model_dim=model_dim,
            num_heads=num_heads,
            depth=resampler_depth,
            max_horizon=future_action_len,
            queries_per_horizon=queries_per_horizon,
            mlp_ratio=mlp_ratio,
            dropout=dropout,
        )
        self.flow = FlowDiT(
            residual_dim=residual_dim,
            model_dim=model_dim,
            num_heads=num_heads,
            depth=flow_depth,
            max_horizon=max_pred_horizon,
            max_slots=self.num_delta_tokens,
            mlp_ratio=mlp_ratio,
            dropout=dropout,
        )

    def _freeze_delta_tok(self) -> None:
        self.delta_tok.requires_grad_(False)
        self.delta_tok.eval()

    def train(self, mode: bool = True) -> DeltaWorldFlow:
        super().train(mode)
        self._freeze_delta_tok()
        return self

    def _validate_batch(self, frames: torch.Tensor, actions: torch.Tensor) -> None:
        if frames.ndim != 5 or frames.shape[1] != self.max_pred_horizon + 1:
            raise ValueError(
                f"Expected frames [B,5,C,H,W], got {tuple(frames.shape)}"
            )
        if actions.shape != (frames.shape[0], self.future_action_len, 3):
            raise ValueError(
                f"Expected actions [B,4,3], got {tuple(actions.shape)}"
            )

    @torch.no_grad()
    def encode_latents(self, frames: torch.Tensor) -> torch.Tensor:
        return self.delta_tok.backbone.encode(frames).detach()

    @torch.no_grad()
    def encode_action_tokens(self, actions: torch.Tensor) -> torch.Tensor:
        batch_size, horizon, _ = actions.shape
        tokens = self.delta_tok.action_tokenizer(actions.reshape(batch_size * horizon, 3))
        return tokens.reshape(batch_size, horizon, 3, tokens.shape[-1]).detach()

    @torch.no_grad()
    def extract_target_z(
        self, latents: torch.Tensor, actions: torch.Tensor, horizon: int | None = None
    ) -> torch.Tensor:
        horizon = horizon or self.max_pred_horizon
        if horizon < 1 or horizon > self.max_pred_horizon:
            raise ValueError(
                f"horizon must be in [1,{self.max_pred_horizon}], got {horizon}"
            )
        targets = []
        for step in range(horizon):
            z = self.delta_tok.encode(
                latents[:, step], latents[:, step + 1], actions[:, step]
            )
            targets.append(z.detach())
        target_z = torch.stack(targets, dim=1)
        if target_z.shape[-2] != self.num_delta_tokens:
            raise ValueError(
                f"Expected {self.num_delta_tokens} DeltaTok slots, got {target_z.shape[-2]}"
            )
        if target_z.shape[-1] != self.residual_dim:
            raise ValueError(
                f"Expected residual dim {self.residual_dim}, got {target_z.shape[-1]}"
            )
        return target_z

    def build_condition(
        self, initial_latent: torch.Tensor, actions: torch.Tensor
    ) -> dict[str, torch.Tensor]:
        action_tokens = self.action_proj(self.encode_action_tokens(actions))
        step_action_emb, plan_emb = self.action_pooler(action_tokens)
        scene_tokens = self.scene_proj(initial_latent)
        condition_tokens = self.resampler(
            scene_tokens,
            action_tokens.reshape(action_tokens.shape[0], -1, self.model_dim),
            step_action_emb,
            plan_emb,
        )
        return {
            "action_tokens": action_tokens,
            "step_action_emb": step_action_emb,
            "plan_emb": plan_emb,
            "condition_tokens": condition_tokens,
        }

    def predict_velocity(
        self,
        noisy_delta: torch.Tensor,
        tau: torch.Tensor,
        initial_latent: torch.Tensor,
        actions: torch.Tensor,
        active_horizon: int | None = None,
        condition: dict[str, torch.Tensor] | None = None,
    ) -> torch.Tensor:
        active_horizon = active_horizon or noisy_delta.shape[1]
        condition = condition or self.build_condition(initial_latent, actions)
        return self.flow(
            noisy_delta,
            tau,
            condition["condition_tokens"],
            condition["step_action_emb"],
            condition["plan_emb"],
            active_horizon=active_horizon,
        )

    def forward(
        self,
        frames: torch.Tensor,
        actions: torch.Tensor,
        active_horizon: int = 4,
        noise: torch.Tensor | None = None,
        tau: torch.Tensor | None = None,
    ) -> dict[str, Any]:
        self._validate_batch(frames, actions)
        if active_horizon < 1 or active_horizon > self.max_pred_horizon:
            raise ValueError(
                f"active_horizon must be in [1,{self.max_pred_horizon}], got {active_horizon}"
            )

        latents = self.encode_latents(frames)
        target_z_full = self.extract_target_z(latents, actions, active_horizon)
        target_z = target_z_full
        if noise is None:
            noise = torch.randn(
                target_z.shape,
                device=target_z.device,
                dtype=target_z.dtype,
            )
        if tau is None:
            tau = torch.rand(
                target_z.shape[0], device=target_z.device, dtype=target_z.dtype
            )
        view_shape = (target_z.shape[0],) + (1,) * (target_z.ndim - 1)
        tau_view = tau.reshape(view_shape)
        x_tau = (1.0 - tau_view) * noise + tau_view * target_z
        target_v = target_z - noise

        initial_latent = latents[:, 0]
        condition = self.build_condition(initial_latent, actions)
        pred_v = self.predict_velocity(
            x_tau,
            tau,
            initial_latent,
            actions,
            active_horizon=active_horizon,
            condition=condition,
        )
        return {
            "pred_v": pred_v,
            "target_v": target_v,
            "target_z": target_z,
            "target_z_full": target_z_full,
            "noise": noise,
            "x_tau": x_tau,
            "tau": tau,
            "active_horizon": active_horizon,
            "latents": latents,
            "initial_latent": initial_latent,
            **condition,
        }

    @torch.no_grad()
    def sample(
        self,
        initial_latent: torch.Tensor,
        actions: torch.Tensor,
        num_steps: int = 20,
        generator: torch.Generator | None = None,
    ) -> torch.Tensor:
        if num_steps < 1:
            raise ValueError("num_steps must be at least 1")
        batch_size = initial_latent.shape[0]
        z = torch.randn(
            (
                batch_size,
                self.max_pred_horizon,
                self.num_delta_tokens,
                self.residual_dim,
            ),
            device=initial_latent.device,
            dtype=initial_latent.dtype,
            generator=generator,
        )
        condition = self.build_condition(initial_latent, actions)
        dt = 1.0 / float(num_steps)
        for step in range(num_steps):
            tau = torch.full(
                (batch_size,),
                step * dt,
                device=initial_latent.device,
                dtype=initial_latent.dtype,
            )
            velocity = self.predict_velocity(
                z,
                tau,
                initial_latent,
                actions,
                active_horizon=self.max_pred_horizon,
                condition=condition,
            )
            z = z + dt * velocity
        return z

    @torch.no_grad()
    def rollout_latents(
        self, initial_latent: torch.Tensor, sampled_z: torch.Tensor
    ) -> torch.Tensor:
        latents = []
        previous = initial_latent
        for step in range(sampled_z.shape[1]):
            previous = self.delta_tok.decode(sampled_z[:, step], previous)
            latents.append(previous)
        return torch.stack(latents, dim=1)
