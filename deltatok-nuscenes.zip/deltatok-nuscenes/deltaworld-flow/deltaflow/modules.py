from __future__ import annotations

import math

import torch
import torch.nn as nn


def zero_init(module: nn.Module) -> nn.Module:
    if isinstance(module, nn.Linear):
        nn.init.zeros_(module.weight)
        if module.bias is not None:
            nn.init.zeros_(module.bias)
    return module


def timestep_embedding(
    timesteps: torch.Tensor, dim: int, max_period: int = 10000
) -> torch.Tensor:
    half = dim // 2
    freqs = torch.exp(
        -math.log(max_period)
        * torch.arange(half, dtype=torch.float32, device=timesteps.device)
        / max(half, 1)
    )
    args = timesteps.float().unsqueeze(1) * freqs.unsqueeze(0)
    emb = torch.cat((args.cos(), args.sin()), dim=1)
    if dim % 2:
        emb = torch.cat((emb, torch.zeros_like(emb[:, :1])), dim=1)
    return emb.to(dtype=timesteps.dtype if timesteps.is_floating_point() else torch.float32)


def build_horizon_causal_mask(
    active_horizon: int, num_slots: int, device: torch.device
) -> torch.Tensor:
    if active_horizon < 1:
        raise ValueError("active_horizon must be at least 1")
    if num_slots < 1:
        raise ValueError("num_slots must be at least 1")
    horizons = torch.arange(active_horizon, device=device).repeat_interleave(num_slots)
    query_h = horizons[:, None]
    key_h = horizons[None, :]
    return key_h > query_h


class TimestepEmbedder(nn.Module):
    def __init__(self, model_dim: int, hidden_dim: int | None = None) -> None:
        super().__init__()
        hidden_dim = hidden_dim or model_dim * 4
        self.model_dim = model_dim
        self.mlp = nn.Sequential(
            nn.Linear(model_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, model_dim),
        )

    def forward(self, tau: torch.Tensor) -> torch.Tensor:
        emb = timestep_embedding(tau, self.model_dim).to(
            device=self.mlp[0].weight.device, dtype=self.mlp[0].weight.dtype
        )
        return self.mlp(emb)


class AdaLayerNorm(nn.Module):
    def __init__(self, model_dim: int, cond_dim: int | None = None) -> None:
        super().__init__()
        cond_dim = cond_dim or model_dim
        self.norm = nn.LayerNorm(model_dim, elementwise_affine=False)
        self.modulation = nn.Sequential(
            nn.SiLU(),
            zero_init(nn.Linear(cond_dim, 2 * model_dim)),
        )

    def forward(self, tokens: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        scale, shift = self.modulation(cond).chunk(2, dim=-1)
        if scale.ndim == 2:
            scale = scale.unsqueeze(1)
            shift = shift.unsqueeze(1)
        return self.norm(tokens) * (1.0 + scale) + shift


class MLP(nn.Module):
    def __init__(self, model_dim: int, mlp_ratio: float = 4.0) -> None:
        super().__init__()
        hidden_dim = int(model_dim * mlp_ratio)
        self.net = nn.Sequential(
            nn.Linear(model_dim, hidden_dim),
            nn.GELU(approximate="tanh"),
            nn.Linear(hidden_dim, model_dim),
        )

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        return self.net(tokens)


class GatedSelfAttentionBlock(nn.Module):
    def __init__(
        self,
        model_dim: int,
        num_heads: int,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.norm1 = nn.LayerNorm(model_dim)
        self.attn = nn.MultiheadAttention(
            model_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.norm2 = nn.LayerNorm(model_dim)
        self.mlp = MLP(model_dim, mlp_ratio)

    def forward(
        self, tokens: torch.Tensor, attn_mask: torch.Tensor | None = None
    ) -> torch.Tensor:
        hidden = self.norm1(tokens)
        attn_out = self.attn(
            hidden, hidden, hidden, attn_mask=attn_mask, need_weights=False
        )[0]
        tokens = tokens + attn_out
        return tokens + self.mlp(self.norm2(tokens))


class StepActionPooler(nn.Module):
    """Pool `[dx, dy, dyaw]` action tokens into step and plan embeddings."""

    def __init__(
        self,
        model_dim: int = 832,
        num_heads: int = 13,
        depth: int = 2,
        max_horizon: int = 4,
        mlp_ratio: float = 2.0,
    ) -> None:
        super().__init__()
        self.max_horizon = max_horizon
        self.step_query = nn.Parameter(torch.zeros(1, model_dim))
        self.plan_query = nn.Parameter(torch.zeros(1, model_dim))
        self.horizon_embedding = nn.Parameter(torch.zeros(max_horizon, model_dim))
        nn.init.trunc_normal_(self.step_query, std=0.02)
        nn.init.trunc_normal_(self.plan_query, std=0.02)
        nn.init.trunc_normal_(self.horizon_embedding, std=0.02)
        self.action_norm = nn.LayerNorm(model_dim)
        self.step_blocks = nn.ModuleList(
            [
                GatedSelfAttentionBlock(model_dim, num_heads, mlp_ratio)
                for _ in range(depth)
            ]
        )
        self.plan_blocks = nn.ModuleList(
            [
                GatedSelfAttentionBlock(model_dim, num_heads, mlp_ratio)
                for _ in range(depth)
            ]
        )
        self.step_norm = nn.LayerNorm(model_dim)
        self.plan_norm = nn.LayerNorm(model_dim)

    def forward(self, action_tokens: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if action_tokens.ndim != 4 or action_tokens.shape[2] != 3:
            raise ValueError(
                f"Expected action_tokens [B,H,3,C], got {tuple(action_tokens.shape)}"
            )
        batch_size, horizon, _, channels = action_tokens.shape
        if horizon > self.max_horizon:
            raise ValueError(f"horizon {horizon} exceeds max_horizon {self.max_horizon}")

        step_query = self.step_query.expand(batch_size * horizon, -1).unsqueeze(1)
        per_step = self.action_norm(action_tokens).reshape(batch_size * horizon, 3, channels)
        step_seq = torch.cat((step_query, per_step), dim=1)
        for block in self.step_blocks:
            step_seq = block(step_seq)
        step_emb = self.step_norm(step_seq[:, 0]).reshape(batch_size, horizon, channels)

        plan_query = self.plan_query.expand(batch_size, -1).unsqueeze(1)
        step_with_time = step_emb + self.horizon_embedding[:horizon].unsqueeze(0)
        plan_seq = torch.cat((plan_query, step_with_time), dim=1)
        for block in self.plan_blocks:
            plan_seq = block(plan_seq)
        return step_emb, self.plan_norm(plan_seq[:, 0])


class ResamplerBlock(nn.Module):
    def __init__(
        self,
        model_dim: int,
        num_heads: int,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.self_norm = AdaLayerNorm(model_dim)
        self.self_attn = nn.MultiheadAttention(
            model_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.action_norm = AdaLayerNorm(model_dim)
        self.action_attn = nn.MultiheadAttention(
            model_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.scene_norm = AdaLayerNorm(model_dim)
        self.scene_attn = nn.MultiheadAttention(
            model_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.mlp_norm = AdaLayerNorm(model_dim)
        self.mlp = MLP(model_dim, mlp_ratio)
        self.action_gate = nn.Parameter(torch.tensor(0.0))

    def forward(
        self,
        queries: torch.Tensor,
        action_tokens: torch.Tensor,
        scene_tokens: torch.Tensor,
        plan_emb: torch.Tensor,
    ) -> torch.Tensor:
        hidden = self.self_norm(queries, plan_emb)
        queries = queries + self.self_attn(hidden, hidden, hidden, need_weights=False)[0]

        hidden = self.action_norm(queries, plan_emb)
        action_out = self.action_attn(
            hidden, action_tokens, action_tokens, need_weights=False
        )[0]
        queries = queries + self.action_gate.tanh() * action_out

        hidden = self.scene_norm(queries, plan_emb)
        queries = queries + self.scene_attn(
            hidden, scene_tokens, scene_tokens, need_weights=False
        )[0]
        return queries + self.mlp(self.mlp_norm(queries, plan_emb))


class SceneActionResampler(nn.Module):
    def __init__(
        self,
        model_dim: int = 832,
        num_heads: int = 13,
        depth: int = 4,
        max_horizon: int = 4,
        queries_per_horizon: int = 16,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.max_horizon = max_horizon
        self.queries_per_horizon = queries_per_horizon
        self.query = nn.Parameter(torch.zeros(queries_per_horizon, model_dim))
        self.horizon_embedding = nn.Parameter(torch.zeros(max_horizon, model_dim))
        self.segment_embedding = nn.Parameter(torch.zeros(3, model_dim))
        nn.init.trunc_normal_(self.query, std=0.02)
        nn.init.trunc_normal_(self.horizon_embedding, std=0.02)
        nn.init.trunc_normal_(self.segment_embedding, std=0.02)
        self.scene_norm = nn.LayerNorm(model_dim)
        self.action_norm = nn.LayerNorm(model_dim)
        self.step_proj = nn.Linear(model_dim, model_dim)
        self.plan_proj = nn.Linear(model_dim, model_dim)
        self.blocks = nn.ModuleList(
            [
                ResamplerBlock(model_dim, num_heads, mlp_ratio, dropout)
                for _ in range(depth)
            ]
        )
        self.output_norm = nn.LayerNorm(model_dim)

    @property
    def num_queries(self) -> int:
        return self.max_horizon * self.queries_per_horizon

    def forward(
        self,
        scene_tokens: torch.Tensor,
        action_tokens: torch.Tensor,
        step_action_emb: torch.Tensor,
        plan_emb: torch.Tensor,
    ) -> torch.Tensor:
        batch_size, horizon, channels = step_action_emb.shape
        if horizon != self.max_horizon:
            raise ValueError(
                f"Expected {self.max_horizon} step action embeddings, got {horizon}"
            )
        scene_tokens = self.scene_norm(scene_tokens) + self.segment_embedding[0]
        action_tokens = self.action_norm(action_tokens) + self.segment_embedding[1]

        query = self.query.unsqueeze(0).unsqueeze(0).expand(
            batch_size, self.max_horizon, -1, -1
        )
        query = query + self.horizon_embedding.unsqueeze(0).unsqueeze(2)
        query = query + self.step_proj(step_action_emb).unsqueeze(2)
        query = query + self.plan_proj(plan_emb).unsqueeze(1).unsqueeze(2)
        query = query.reshape(batch_size, self.num_queries, channels)
        query = query + self.segment_embedding[2]

        for block in self.blocks:
            query = block(query, action_tokens, scene_tokens, plan_emb)
        return self.output_norm(query)


class FlowDiTBlock(nn.Module):
    def __init__(
        self,
        model_dim: int,
        num_heads: int,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.self_norm = AdaLayerNorm(model_dim)
        self.self_attn = nn.MultiheadAttention(
            model_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.cross_norm = AdaLayerNorm(model_dim)
        self.cross_attn = nn.MultiheadAttention(
            model_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.mlp_norm = AdaLayerNorm(model_dim)
        self.mlp = MLP(model_dim, mlp_ratio)

    def forward(
        self,
        tokens: torch.Tensor,
        condition_tokens: torch.Tensor,
        token_cond: torch.Tensor,
        attn_mask: torch.Tensor,
    ) -> torch.Tensor:
        hidden = self.self_norm(tokens, token_cond)
        tokens = tokens + self.self_attn(
            hidden, hidden, hidden, attn_mask=attn_mask, need_weights=False
        )[0]
        hidden = self.cross_norm(tokens, token_cond)
        tokens = tokens + self.cross_attn(
            hidden, condition_tokens, condition_tokens, need_weights=False
        )[0]
        return tokens + self.mlp(self.mlp_norm(tokens, token_cond))


class FlowDiT(nn.Module):
    def __init__(
        self,
        residual_dim: int = 832,
        model_dim: int = 832,
        num_heads: int = 13,
        depth: int = 12,
        max_horizon: int = 4,
        max_slots: int = 1,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.residual_dim = residual_dim
        self.model_dim = model_dim
        self.max_horizon = max_horizon
        self.max_slots = max_slots
        self.input_proj = (
            nn.Identity()
            if residual_dim == model_dim
            else nn.Linear(residual_dim, model_dim)
        )
        self.z_norm = nn.LayerNorm(residual_dim)
        self.condition_norm = nn.LayerNorm(model_dim)
        self.horizon_embedding = nn.Parameter(torch.zeros(max_horizon, model_dim))
        self.slot_embedding = nn.Parameter(torch.zeros(max_slots, model_dim))
        self.step_action_proj = nn.Linear(model_dim, model_dim)
        self.time_embed = TimestepEmbedder(model_dim)
        self.blocks = nn.ModuleList(
            [
                FlowDiTBlock(model_dim, num_heads, mlp_ratio, dropout)
                for _ in range(depth)
            ]
        )
        self.output_norm = nn.LayerNorm(model_dim)
        self.output_proj = zero_init(nn.Linear(model_dim, residual_dim))
        nn.init.trunc_normal_(self.horizon_embedding, std=0.02)
        nn.init.trunc_normal_(self.slot_embedding, std=0.02)

    def forward(
        self,
        noisy_delta: torch.Tensor,
        tau: torch.Tensor,
        condition_tokens: torch.Tensor,
        step_action_emb: torch.Tensor,
        plan_emb: torch.Tensor,
        active_horizon: int | None = None,
    ) -> torch.Tensor:
        if noisy_delta.ndim != 4:
            raise ValueError(
                f"Expected noisy_delta [B,H,K,C], got {tuple(noisy_delta.shape)}"
            )
        batch_size, horizon, num_slots, channels = noisy_delta.shape
        active_horizon = active_horizon or horizon
        if horizon != active_horizon:
            raise ValueError(
                f"noisy_delta horizon {horizon} must match active_horizon {active_horizon}"
            )
        if horizon > self.max_horizon:
            raise ValueError(f"horizon {horizon} exceeds max_horizon {self.max_horizon}")
        if num_slots > self.max_slots:
            raise ValueError(f"num_slots {num_slots} exceeds max_slots {self.max_slots}")
        if channels != self.residual_dim:
            raise ValueError(f"Expected residual dim {self.residual_dim}, got {channels}")

        tokens = self.input_proj(self.z_norm(noisy_delta))
        local = self.horizon_embedding[:horizon].view(1, horizon, 1, self.model_dim)
        local = local + self.slot_embedding[:num_slots].view(1, 1, num_slots, self.model_dim)
        local = local + self.step_action_proj(step_action_emb[:, :horizon]).unsqueeze(2)
        tokens = tokens + local
        tokens = tokens.reshape(batch_size, horizon * num_slots, self.model_dim)

        time_emb = self.time_embed(tau).to(tokens)
        global_cond = time_emb + plan_emb
        token_cond = local.reshape(batch_size, horizon * num_slots, self.model_dim)
        token_cond = token_cond + global_cond.unsqueeze(1)
        condition_tokens = self.condition_norm(condition_tokens)
        attn_mask = build_horizon_causal_mask(
            horizon, num_slots, tokens.device
        )
        for block in self.blocks:
            tokens = block(tokens, condition_tokens, token_cond, attn_mask)
        tokens = self.output_proj(self.output_norm(tokens))
        return tokens.reshape(batch_size, horizon, num_slots, self.residual_dim)
