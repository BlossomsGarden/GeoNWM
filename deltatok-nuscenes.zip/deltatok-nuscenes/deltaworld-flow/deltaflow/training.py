from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any

import lightning
import torch
import torch.distributed as dist
import torch.nn as nn
from lightning.pytorch.utilities import grad_norm
from torch.optim import AdamW
from torch.optim.lr_scheduler import LambdaLR

import wandb
from training.base import create_plot_from_rows, feats_to_pca, to_numpy_img


@dataclass(frozen=True)
class HorizonSchedule:
    until_step: int | None
    active_horizon: int
    loss_weights: list[float]

    def __post_init__(self) -> None:
        if self.until_step is not None and self.until_step < 0:
            raise ValueError("until_step must be non-negative or None")
        if self.active_horizon < 1:
            raise ValueError("active_horizon must be at least 1")
        if len(self.loss_weights) != self.active_horizon:
            raise ValueError("loss_weights length must match active_horizon")


def _coerce_schedule_item(item: HorizonSchedule | dict[str, Any]) -> HorizonSchedule:
    if isinstance(item, HorizonSchedule):
        return item
    return HorizonSchedule(
        until_step=item.get("until_step"),
        active_horizon=int(item["active_horizon"]),
        loss_weights=[float(v) for v in item["loss_weights"]],
    )


def resolve_horizon_schedule(
    schedule: list[HorizonSchedule | dict[str, Any]], global_step: int
) -> HorizonSchedule:
    if not schedule:
        raise ValueError("horizon_schedule must not be empty")
    coerced = [_coerce_schedule_item(item) for item in schedule]
    for item in coerced:
        if item.until_step is None or global_step < item.until_step:
            return item
    return coerced[-1]


def mse_per_horizon(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch: pred={tuple(pred.shape)} target={tuple(target.shape)}")
    return (pred.float() - target.float()).pow(2).mean(dim=(0, 2, 3))


class DeltaWorldFlowModule(lightning.LightningModule):
    def __init__(
        self,
        network: nn.Module,
        lr: float = 1.0e-4,
        weight_decay: float = 1.0e-2,
        lr_warmup_steps: int = 5000,
        horizon_schedule: list[HorizonSchedule | dict[str, Any]] | None = None,
        num_sampling_steps: int = 20,
        num_plots: int = 4,
        use_compile: bool = False,
    ) -> None:
        super().__init__()
        self.network = network
        self.lr = lr
        self.weight_decay = weight_decay
        self.lr_warmup_steps = lr_warmup_steps
        self.horizon_schedule = horizon_schedule or [
            HorizonSchedule(100000, 1, [1.0]),
            HorizonSchedule(200000, 2, [1.0, 0.7]),
            HorizonSchedule(None, 4, [1.0, 0.7, 0.5, 0.3]),
        ]
        self.num_sampling_steps = num_sampling_steps
        self.num_plots = num_plots
        self.use_compile = use_compile
        self.val_loss_sum, self.val_loss_count = defaultdict(float), defaultdict(int)
        self._plot_imgs: list[tuple[str, Any]] = []
        self.save_hyperparameters(ignore=["network"])

    @property
    def unwrapped_network(self) -> nn.Module:
        return getattr(self.network, "_orig_mod", self.network)

    def setup(self, stage: str) -> None:
        if stage == "fit" and self.use_compile:
            self.network = torch.compile(self.network)

    def configure_optimizers(self) -> dict[str, Any]:
        params = [p for p in self.network.parameters() if p.requires_grad]
        optimizer = AdamW(params, lr=self.lr, weight_decay=self.weight_decay)

        def lr_lambda(step: int) -> float:
            if self.lr_warmup_steps <= 0:
                return 1.0
            return min(1.0, float(step + 1) / float(self.lr_warmup_steps))

        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": LambdaLR(optimizer, lr_lambda),
                "interval": "step",
            },
        }

    def _current_schedule(self) -> HorizonSchedule:
        return resolve_horizon_schedule(self.horizon_schedule, int(self.global_step))

    def _weighted_mse(self, pred: torch.Tensor, target: torch.Tensor, weights: list[float]) -> torch.Tensor:
        per_h = mse_per_horizon(pred, target)
        weight = torch.tensor(weights, device=pred.device, dtype=per_h.dtype)
        return (per_h * weight).sum() / weight.sum().clamp_min(1.0e-8)

    def training_step(self, batch: tuple[torch.Tensor, ...], batch_idx: int) -> torch.Tensor:
        frames, actions = batch[:2]
        schedule = self._current_schedule()
        outputs = self.network(frames, actions, active_horizon=schedule.active_horizon)
        loss = self._weighted_mse(outputs["pred_v"], outputs["target_v"], schedule.loss_weights)
        self.log("train_losses/velocity_mse", loss, sync_dist=True, prog_bar=True)
        self.log(
            "train/active_horizon",
            float(schedule.active_horizon),
            sync_dist=True,
            prog_bar=True,
        )
        per_h = mse_per_horizon(outputs["pred_v"], outputs["target_v"])
        for idx, value in enumerate(per_h, start=1):
            self.log(f"train_losses/velocity_mse_h{idx}", value, sync_dist=True)
        return loss

    def validation_step(
        self, batch: tuple[torch.Tensor, ...], batch_idx: int, dataloader_idx: int = 0
    ) -> torch.Tensor:
        frames, actions, sample_idx = batch
        network = self.unwrapped_network
        outputs = self.network(frames, actions, active_horizon=network.max_pred_horizon)
        per_h = mse_per_horizon(outputs["pred_v"], outputs["target_v"])
        total = per_h.mean()
        prefix = self._val_prefix(dataloader_idx)
        self.log(f"losses/{prefix}_teacher_forced_velocity_mse_total", total, sync_dist=True)
        for idx, value in enumerate(per_h, start=1):
            self.log(
                f"losses/{prefix}_teacher_forced_velocity_mse_h{idx}",
                value,
                sync_dist=True,
            )
        self.val_loss_sum[prefix] += float(total.detach().cpu())
        self.val_loss_count[prefix] += 1

        sampled_z = network.sample(
            outputs["initial_latent"], actions, num_steps=self.num_sampling_steps
        )
        sampled_per_h = mse_per_horizon(sampled_z, outputs["target_z_full"])
        sampled_total = sampled_per_h.mean()
        self.log(f"metrics/{prefix}_sampled_z_mse_total", sampled_total, sync_dist=True)
        for idx, value in enumerate(sampled_per_h, start=1):
            self.log(f"metrics/{prefix}_sampled_z_mse_h{idx}", value, sync_dist=True)

        self._plot_selected_samples(
            frames=frames,
            outputs=outputs,
            sampled_z=sampled_z,
            sample_idx=sample_idx,
            prefix=prefix,
        )
        return total

    def _val_prefix(self, dataloader_idx: int) -> str:
        dataloaders = getattr(self.trainer, "val_dataloaders", None)
        if isinstance(dataloaders, list) and dataloader_idx < len(dataloaders):
            return getattr(dataloaders[dataloader_idx], "dataset_name", f"val{dataloader_idx}")
        return "val"

    def _plot_selected_samples(
        self,
        frames: torch.Tensor,
        outputs: dict[str, torch.Tensor],
        sampled_z: torch.Tensor,
        sample_idx: torch.Tensor,
        prefix: str,
    ) -> None:
        seen: set[int] = set()
        for row, idx in enumerate(sample_idx.tolist()):
            if idx >= self.num_plots or idx in seen:
                continue
            seen.add(idx)
            sample_outputs = {key: value[row : row + 1] for key, value in outputs.items() if torch.is_tensor(value)}
            self._plot_sample(
                frames[row], sample_outputs, sampled_z[row : row + 1], f"{prefix}_s{idx}"
            )

    def _plot_sample(
        self,
        frames: torch.Tensor,
        outputs: dict[str, torch.Tensor],
        sampled_z: torch.Tensor,
        prefix: str,
    ) -> None:
        network = self.unwrapped_network
        with torch.no_grad():
            sampled_latents = network.rollout_latents(outputs["initial_latent"], sampled_z)
            sampled_rgb = network.delta_tok.backbone.decode(sampled_latents)[0]

        input_img = to_numpy_img(frames[0])
        gt_imgs = [to_numpy_img(frame) for frame in frames[1:]]
        sampled_imgs = [to_numpy_img(frame) for frame in sampled_rgb]
        self._log_plot_img(
            f"{prefix}_rgb_rollout",
            create_plot_from_rows(
                [[input_img, *gt_imgs], [None, *sampled_imgs]],
                5,
            ),
        )

        target_latents = outputs["latents"][:, 1:]
        tokens = target_latents.shape[-2]
        grid = int(tokens**0.5)
        if grid * grid == tokens:
            target_pca, sampled_pca = feats_to_pca(
                target_latents[0], sampled_latents[0], grid, grid
            )
            self._log_plot_img(
                f"{prefix}_latent_pca_rollout",
                create_plot_from_rows([[None, *target_pca], [None, *sampled_pca]], 5),
            )

    def on_validation_epoch_end(self) -> None:
        if self.val_loss_sum:
            means = [
                self.val_loss_sum[name] / self.val_loss_count[name]
                for name in self.val_loss_sum
            ]
            self.log("losses/val", sum(means) / len(means), sync_dist=True, prog_bar=True)
            self.val_loss_sum.clear()
            self.val_loss_count.clear()

        if self.trainer.logger is None:
            self._plot_imgs = []
            return
        imgs = self._plot_imgs
        if dist.is_available() and dist.is_initialized():
            gathered = [None] * dist.get_world_size()
            dist.all_gather_object(gathered, imgs)
            imgs = sum(gathered, []) if dist.get_rank() == 0 else []
        if imgs and self.trainer.is_global_zero:
            self.trainer.logger.experiment.log(
                {key: [wandb.Image(img, file_type="jpg")] for key, img in imgs}
            )
        self._plot_imgs = []

    def on_before_optimizer_step(self, optimizer: AdamW) -> None:
        norms = grad_norm(self.network, norm_type=2)
        total = norms.get("grad_2.0_norm_total")
        if total is not None:
            self.log("grad_norm/total", total.to(self.device), sync_dist=True)

    def on_save_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        state = checkpoint.get("state_dict")
        if not state:
            return
        checkpoint["state_dict"] = {
            key: value
            for key, value in state.items()
            if not key.startswith("network.delta_tok.")
            and not key.startswith("network._orig_mod.delta_tok.")
        }

    def load_state_dict(
        self, state_dict: dict[str, torch.Tensor], strict: bool = False
    ) -> torch._C._IncompatibleKeys:
        return super().load_state_dict(state_dict, strict=False)

    def _log_plot_img(self, key: str, img: Any) -> None:
        self._plot_imgs.append((key, img))
