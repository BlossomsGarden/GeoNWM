from __future__ import annotations

import csv
import logging
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

from datasets.base import as_hw, resize_then_principal_crop
from datasets.nuscenes import (
    CAM_FRONT_NAMES,
    SampleRow,
    _load_cam_front_intrinsics,
    _load_selected_token_map,
    compute_action,
)
from deltaflow.windowing import build_consecutive_windows

__all__ = ["NuScenesSequenceTrain", "NuScenesSequenceVal", "build_consecutive_windows"]


class _NuScenesSequenceDataset(Dataset):
    """Consecutive five-keyframe CAM_FRONT windows for DeltaWorld Flow."""

    def __init__(
        self,
        csv_path: str,
        nuscenes_root: str,
        frame_size: int | tuple[int, int] = 256,
        sequence_length: int = 5,
        ego_pose_path: str | None = None,
        sample_data_path: str | None = None,
        calibrated_sensor_path: str | None = None,
    ) -> None:
        if sequence_length != 5:
            raise ValueError("DeltaWorld Flow currently requires sequence_length=5")
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.frame_size = as_hw(frame_size)
        self.sequence_length = sequence_length

        metadata_root = self.nuscenes_root / "v1.0-trainval"
        self.ego_pose_path = Path(ego_pose_path or metadata_root / "ego_pose.json")
        self.sample_data_path = Path(
            sample_data_path or metadata_root / "sample_data.json"
        )
        self.calibrated_sensor_path = Path(
            calibrated_sensor_path or metadata_root / "calibrated_sensor.json"
        )

        rows_by_scene = self._build_rows()
        self.sequences = self._build_sequences(rows_by_scene)
        pose_tokens = {
            row.ego_pose_token for sequence in self.sequences for row in sequence
        }
        self.ego_poses = _load_selected_token_map(self.ego_pose_path, pose_tokens)
        self.intrinsics_by_file = self._load_intrinsics()

    def _load_intrinsics(self) -> dict[str, np.ndarray]:
        intrinsics = _load_cam_front_intrinsics(
            str(self.sample_data_path.resolve()),
            str(self.calibrated_sensor_path.resolve()),
        )
        if not intrinsics:
            logging.warning(
                "No CAM_FRONT intrinsics loaded from %s; falling back to centered crops",
                self.sample_data_path,
            )
        return intrinsics

    def _build_rows(self) -> dict[str, list[SampleRow]]:
        grouped: dict[str, list[SampleRow]] = {}
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            for raw in csv.DictReader(handle):
                if raw.get("cam") not in CAM_FRONT_NAMES:
                    continue
                row = SampleRow(
                    scene_id=raw["scene_id"],
                    frame_id=int(raw["frame_id"]),
                    file=raw["file"],
                    ego_pose_token=raw["ego_pose_token"],
                )
                grouped.setdefault(row.scene_id, []).append(row)
        for rows in grouped.values():
            rows.sort(key=lambda row: row.frame_id)
        return grouped

    def _build_sequences(
        self, rows_by_scene: dict[str, list[SampleRow]]
    ) -> list[tuple[SampleRow, ...]]:
        sequences: list[tuple[SampleRow, ...]] = []
        for rows in rows_by_scene.values():
            frame_ids = [row.frame_id for row in rows]
            sequences.extend(
                build_consecutive_windows(rows, frame_ids, self.sequence_length)
            )
        if not sequences:
            raise ValueError(
                f"No consecutive {self.sequence_length}-frame CAM_FRONT windows found in {self.csv_path}"
            )
        return sequences

    def _resolve_image_path(self, filename: str) -> Path:
        path = Path(filename)
        if path.is_absolute():
            return path
        candidates = (
            self.nuscenes_root / path,
            self.nuscenes_root / "samples" / "CAM_FRONT" / path.name,
        )
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(
            f"Could not resolve CSV image path {filename!r}; tried {candidates}"
        )

    def _load_frame(self, row: SampleRow) -> torch.Tensor:
        image_path = self._resolve_image_path(row.file)
        with Image.open(image_path) as image:
            image_np = np.asarray(image.convert("RGB"))
        intrinsic = self.intrinsics_by_file.get(row.file)
        if intrinsic is None:
            intrinsic = self.intrinsics_by_file.get(Path(row.file).name)
        image_np = resize_then_principal_crop(image_np, intrinsic, self.frame_size)
        return torch.from_numpy(image_np.copy()).permute(2, 0, 1)

    def __len__(self) -> int:
        return len(self.sequences)

    def _get_sequence(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        rows = self.sequences[idx]
        frames = torch.stack([self._load_frame(row) for row in rows])
        actions = torch.stack(
            [
                compute_action(
                    self.ego_poses[prev.ego_pose_token],
                    self.ego_poses[curr.ego_pose_token],
                )
                for prev, curr in zip(rows, rows[1:])
            ]
        )
        return frames, actions

    def __getitem__(self, idx: int):
        return self._get_sequence(idx)


class NuScenesSequenceTrain(_NuScenesSequenceDataset):
    pass


class NuScenesSequenceVal(_NuScenesSequenceDataset):
    def __getitem__(self, idx: int):
        frames, actions = self._get_sequence(idx)
        return frames, actions, idx
