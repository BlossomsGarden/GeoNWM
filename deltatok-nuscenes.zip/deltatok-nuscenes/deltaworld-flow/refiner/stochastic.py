from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F

from .modules import RefinerDDT


@dataclass
class ResidualFlowState:
    r0: torch.Tensor
    r_tau: torch.Tensor
    target_velocity: torch.Tensor
    tau: torch.Tensor


def make_residual_flow_state(
    coarse: torch.Tensor,
    target: torch.Tensor,
    channel_std: torch.Tensor,
    sigma: float,
    tau: torch.Tensor,
    generator: torch.Generator | None = None,
) -> ResidualFlowState:
    scale = channel_std.to(device=coarse.device, dtype=coarse.dtype).reshape(1, 1, -1)
    d = (target - coarse) / scale
    noise = torch.randn(coarse.shape, device=coarse.device, dtype=coarse.dtype, generator=generator)
    r0 = float(sigma) * noise
    tau_view = tau.reshape((tau.shape[0],) + (1,) * (coarse.ndim - 1))
    return ResidualFlowState(r0, (1 - tau_view) * r0 + tau_view * d, d - r0, tau)


class StochasticRefiner(nn.Module):
    def __init__(self, dim: int = 832, depth: int = 8, num_heads: int = 13, mlp_ratio: float = 4.0, sigma: float = 0.1) -> None:
        super().__init__()
        if sigma <= 0:
            raise ValueError("sigma must be positive")
        self.sigma = float(sigma)
        self.num_steps = 4
        self.backbone = RefinerDDT(dim, depth, num_heads, mlp_ratio)

    def velocity(self, previous: torch.Tensor, coarse: torch.Tensor, r_tau: torch.Tensor, tau: torch.Tensor) -> torch.Tensor:
        return self.backbone(r_tau, previous, coarse, tau=tau)

    @staticmethod
    def loss(pred_velocity: torch.Tensor, target_velocity: torch.Tensor) -> torch.Tensor:
        return F.mse_loss(pred_velocity, target_velocity, reduction="mean")

    @torch.no_grad()
    def sample(
        self,
        previous: torch.Tensor,
        coarse: torch.Tensor,
        channel_std: torch.Tensor,
        num_steps: int = 4,
        generator: torch.Generator | None = None,
    ) -> torch.Tensor:
        if num_steps < 1:
            raise ValueError("num_steps must be positive")
        r = self.sigma * torch.randn(coarse.shape, device=coarse.device, dtype=coarse.dtype, generator=generator)
        dt = 1.0 / float(num_steps)
        for index in range(num_steps):
            tau = torch.full((coarse.shape[0],), index * dt, device=coarse.device, dtype=coarse.dtype)
            r = r + dt * self.velocity(previous, coarse, r, tau)
        scale = channel_std.to(device=coarse.device, dtype=coarse.dtype).reshape(1, 1, -1)
        return coarse + r * scale
