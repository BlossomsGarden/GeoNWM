from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F


@dataclass
class OffsetSummary:
    warmup_mean: torch.Tensor
    primary_mean: torch.Tensor
    per_offset: torch.Tensor


def aggregate_offsets(values: torch.Tensor, primary_start: int = 4) -> OffsetSummary:
    values = values.float()
    return OffsetSummary(values[:primary_start].mean(), values[primary_start:].mean(), values)


def latent_metrics(pred: torch.Tensor, target: torch.Tensor, channel_std: torch.Tensor) -> dict[str, torch.Tensor]:
    scale = channel_std.to(pred).reshape(1, 1, -1)
    normalized = (pred - target) / scale
    cosine = 1.0 - F.cosine_similarity(pred, target, dim=-1).mean(dim=-1)
    return {
        "smooth_l1": F.smooth_l1_loss(normalized, torch.zeros_like(normalized), reduction="none").mean(dim=(-1, -2)),
        "mse": (pred - target).pow(2).mean(dim=(-1, -2)),
        "cosine": cosine,
    }


def rgb_l1(pred_rgb: torch.Tensor, target_rgb: torch.Tensor) -> torch.Tensor:
    return (pred_rgb.float() - target_rgb.float()).abs().flatten(1).mean(dim=1)
