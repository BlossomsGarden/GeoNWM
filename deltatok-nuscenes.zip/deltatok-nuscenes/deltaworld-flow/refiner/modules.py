from __future__ import annotations

import math

import torch
import torch.nn as nn

from .rope import Dynamic2DRoPE


def timestep_embedding(t: torch.Tensor, dim: int) -> torch.Tensor:
    half = dim // 2
    freq = torch.exp(-math.log(10000.0) * torch.arange(half, device=t.device) / max(half, 1))
    args = t.float().unsqueeze(-1) * freq.unsqueeze(0)
    emb = torch.cat((args.cos(), args.sin()), dim=-1)
    return torch.cat((emb, torch.zeros_like(emb[:, :1])), dim=-1) if dim % 2 else emb


class AdaLN(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(dim, elementwise_affine=False)
        self.mod = nn.Sequential(nn.SiLU(), nn.Linear(dim, 2 * dim))
        nn.init.zeros_(self.mod[-1].weight)
        nn.init.zeros_(self.mod[-1].bias)

    def forward(self, x: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        shift, scale = self.mod(cond).chunk(2, dim=-1)
        return self.norm(x) * (1 + scale.unsqueeze(1)) + shift.unsqueeze(1)


class DDTBlock(nn.Module):
    def __init__(self, dim: int, heads: int, mlp_ratio: float = 4.0) -> None:
        super().__init__()
        self.heads = heads
        self.head_dim = dim // heads
        self.self_norm = AdaLN(dim)
        self.self_qkv = nn.Linear(dim, 3 * dim)
        self.self_out = nn.Linear(dim, dim)
        self.prev_norm = nn.LayerNorm(dim)
        self.prev_q = nn.Linear(dim, dim)
        self.prev_kv = nn.Linear(dim, 2 * dim)
        self.prev_out = nn.Linear(dim, dim)
        self.coarse_norm = nn.LayerNorm(dim)
        self.coarse_q = nn.Linear(dim, dim)
        self.coarse_kv = nn.Linear(dim, 2 * dim)
        self.coarse_out = nn.Linear(dim, dim)
        self.mlp_norm = AdaLN(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(nn.Linear(dim, hidden), nn.GELU(), nn.Linear(hidden, dim))
        self.gates = nn.Parameter(torch.zeros(4))
        self.rope = Dynamic2DRoPE(self.head_dim)

    def _attn(self, q, k, v, grid: int):
        b, n, d = q.shape
        q = q.view(b, n, self.heads, self.head_dim).transpose(1, 2)
        k = k.view(b, -1, self.heads, self.head_dim).transpose(1, 2)
        v = v.view(b, -1, self.heads, self.head_dim).transpose(1, 2)
        q = self.rope.apply(q, grid)
        if k.shape[-2] == n:
            k = self.rope.apply(k, grid)
        out = torch.nn.functional.scaled_dot_product_attention(q, k, v)
        return out.transpose(1, 2).reshape(b, n, d)

    def forward(self, x, previous, coarse, time_cond, grid: int):
        qkv = self.self_qkv(self.self_norm(x, time_cond)).chunk(3, dim=-1)
        x = x + self.gates[0].tanh() * self.self_out(self._attn(*qkv, grid))
        q = self.prev_q(self.prev_norm(x))
        k, v = self.prev_kv(previous).chunk(2, dim=-1)
        x = x + self.gates[1].tanh() * self.prev_out(self._attn(q, k, v, grid))
        q = self.coarse_q(self.coarse_norm(x))
        k, v = self.coarse_kv(coarse).chunk(2, dim=-1)
        x = x + self.gates[2].tanh() * self.coarse_out(self._attn(q, k, v, grid))
        x = x + self.gates[3].tanh() * self.mlp(self.mlp_norm(x, time_cond))
        return x


class RefinerDDT(nn.Module):
    def __init__(self, dim: int = 832, depth: int = 8, num_heads: int = 13, mlp_ratio: float = 4.0) -> None:
        super().__init__()
        self.dim = dim
        self.input = nn.Linear(dim, dim)
        self.previous_proj = nn.Linear(dim, dim)
        self.coarse_proj = nn.Linear(dim, dim)
        self.blocks = nn.ModuleList([DDTBlock(dim, num_heads, mlp_ratio) for _ in range(depth)])
        self.output_norm = nn.LayerNorm(dim)
        self.output = nn.Linear(dim, dim)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)
        self.time = nn.Sequential(nn.Linear(dim, 4 * dim), nn.SiLU(), nn.Linear(4 * dim, dim))

    def forward(self, state, previous, coarse, tau: torch.Tensor | None = None):
        b, n, c = state.shape
        grid = int(math.isqrt(n))
        if grid * grid != n:
            raise ValueError("latent token count must be square")
        tau = torch.zeros(b, device=state.device, dtype=state.dtype) if tau is None else tau
        cond = self.time(timestep_embedding(tau, self.dim).to(state))
        x = self.input(state)
        previous = self.previous_proj(previous)
        coarse = self.coarse_proj(coarse)
        for block in self.blocks:
            x = block(x, previous, coarse, cond, grid)
        return self.output(self.output_norm(x))
