# DeltaTok Latent Refiner

This directory contains two independent refiners applied after every frozen DeltaTok decode:

- **A**: deterministic residual regression with channel-normalized SmoothL1.
- **B**: stochastic residual rectified flow in normalized correction space.

Both variants consume a 13-frame CAM_FRONT sequence (`frames [B,13,3,H,W]`, `actions [B,12,3]`) and run three consecutive four-frame DeltaWorld-flow chunks. A sequence samples coarse replay versus refined feedback once; the choice is shared by all 12 frames. Frozen DINO-Tok, DeltaTok, and DeltaWorld-flow calls run under `no_grad`, and each refined frame is detached before the next decode.

## Fixed protocol

Training flow sampler: Euler 8 steps. Validation/final sampler: Euler 20 steps. A uses one deterministic DDT forward. B uses normalized correction flow with `sigma=0.1` and Euler 4 correction steps; train separate checkpoints for sigma `0.05`, `0.1`, and `0.2`.

Frame loss weights are `0.8` for frames 1-4 and `1.0` for frames 5-12. Each frame is backpropagated immediately with division by `11.2`; one optimizer step occurs after all 12 frames through Lightning manual optimization.

## Channel statistics

Scan training GT latents once and save a stats file:

```powershell
python -m refiner.stats_scan \
  --dataset-class refiner.data.NuScenesRefinerTrain \
  --dataset-kwargs csv_path=/path/to/nuscenes_train_samples.csv,nuscenes_root=/path/to/nuscenes,frame_size=256 \
  --dinotok-class models.dinotok_wrapper.DINOtok \
  --dinotok-kwargs decoder_ckpt=/path/to/aetok.pt,backbone_name=/path/to/dinov3,img_size=256 \
  --output /path/to/fixed_gt_channel_stats.pt
```

The scan computes per-channel GT latent std, then clamps each value to `[0.1*median, 10*median]`. The saved file is shared by A/B and must match tokenizer checkpoint, image size, and preprocessing.

## Training

After replacing checkpoint and dataset paths in a config:

```powershell
python main.py fit -c configs/refiner_a_256.yaml --trainer.fast_dev_run=1
python main.py fit -c configs/refiner_b_256.yaml --trainer.fast_dev_run=1
```

Use the 512 configs for the 32x32 latent grid. A/B checkpoints and output directories should remain separate.

## Evaluation

Use identical initial observation, actions, coarse flow seeds, and time offsets for GT, coarse, and refined rollouts. Report latent normalized SmoothL1/MSE/cosine, decoded RGB L1, optional LPIPS, per-offset metrics, and chunk-2/chunk-3 groups. Primary conclusions use frames 5-12; frames 1-4 are warm-up diagnostics. For B, additionally report multi-seed endpoint variance, pairwise distance, and temporal consistency.

## Local checks

```powershell
python -m compileall sources/deltatok-nuscenes/deltaworld-flow/refiner
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/refiner/tests -q
```

The local environment must provide PyTorch and Lightning for runtime tests. Fake-module tests do not require nuScenes data or remote checkpoints.
