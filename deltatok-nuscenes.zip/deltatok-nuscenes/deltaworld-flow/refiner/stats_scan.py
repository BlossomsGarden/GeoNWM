from __future__ import annotations

import argparse
import importlib
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from .stats import scan_gt_latent_stats


def _load(path: str):
    module, name = path.rsplit(".", 1)
    return getattr(importlib.import_module(module), name)


def main() -> None:
    parser = argparse.ArgumentParser(description="Scan GT DINO-Tok channel statistics.")
    parser.add_argument("--dataset-class", required=True, help="Dotted dataset class path")
    parser.add_argument("--dataset-kwargs", default="", help="Comma-separated key=value pairs")
    parser.add_argument("--dinotok-class", required=True, help="Dotted frozen DINO-Tok class path")
    parser.add_argument("--dinotok-kwargs", default="", help="Comma-separated key=value pairs")
    parser.add_argument("--output", required=True)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    def parse_kwargs(value: str) -> dict[str, str]:
        return {item.split("=", 1)[0]: item.split("=", 1)[1] for item in value.split(",") if "=" in item}

    dataset = _load(args.dataset_class)(**parse_kwargs(args.dataset_kwargs))
    dinotok = _load(args.dinotok_class)(**parse_kwargs(args.dinotok_kwargs)).to(args.device).eval()
    stats = scan_gt_latent_stats(DataLoader(dataset, batch_size=args.batch_size), dinotok, torch.device(args.device))
    stats.save(Path(args.output))
    print(f"saved channel statistics to {args.output}")


if __name__ == "__main__":
    main()
