from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch


def clamp_channel_std(raw_std: torch.Tensor) -> torch.Tensor:
    raw_std = raw_std.float()
    median = torch.median(raw_std)
    if not torch.isfinite(median) or median <= 0:
        raise ValueError("latent channel std median must be positive and finite")
    return raw_std.clamp(0.1 * median, 10.0 * median)


@dataclass
class LatentStats:
    raw_std: torch.Tensor
    median_std: torch.Tensor
    clamped_std: torch.Tensor
    sample_count: int
    tokenizer_id: str
    metadata: dict[str, Any]

    @classmethod
    def from_raw_std(cls, raw_std: torch.Tensor, sample_count: int, tokenizer_id: str, **metadata: Any) -> "LatentStats":
        raw_std = raw_std.detach().cpu().float()
        median = torch.median(raw_std)
        return cls(raw_std, median, clamp_channel_std(raw_std), int(sample_count), tokenizer_id, metadata)

    def save(self, path: str | Path) -> None:
        payload = {
            "schema_version": 1,
            "raw_std": self.raw_std,
            "median_std": self.median_std,
            "clamped_std": self.clamped_std,
            "sample_count": self.sample_count,
            "tokenizer_id": self.tokenizer_id,
            "metadata": self.metadata,
        }
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        torch.save(payload, path)

    @classmethod
    def load(cls, path: str | Path) -> "LatentStats":
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("schema_version") != 1:
            raise ValueError("unsupported latent stats schema")
        return cls(payload["raw_std"], payload["median_std"], payload["clamped_std"], payload["sample_count"], payload["tokenizer_id"], payload.get("metadata", {}))

    def validate(self, width: int, **metadata: Any) -> None:
        if self.clamped_std.numel() != width:
            raise ValueError(f"channel stats width {self.clamped_std.numel()} != latent width {width}")
        for key, expected in metadata.items():
            actual = self.metadata.get(key)
            if actual is not None and actual != expected:
                raise ValueError(f"latent stats metadata mismatch for {key}: {actual!r} != {expected!r}")


@torch.no_grad()
def scan_gt_latent_stats(dataloader, frozen_dinotok, device: torch.device, tokenizer_id: str = "unknown", **metadata: Any) -> LatentStats:
    count = 0
    mean = None
    m2 = None
    for batch in dataloader:
        frames = batch[0].to(device)
        latent = frozen_dinotok.encode(frames).float()
        values = latent.reshape(-1, latent.shape[-1]).double()
        n = values.shape[0]
        batch_mean = values.mean(0)
        batch_m2 = ((values - batch_mean) ** 2).sum(0)
        if mean is None:
            count, mean, m2 = n, batch_mean, batch_m2
        else:
            delta = batch_mean - mean
            total = count + n
            m2 = m2 + batch_m2 + delta.square() * count * n / total
            mean = mean + delta * n / total
            count = total
    if count < 2 or mean is None or m2 is None:
        raise ValueError("at least two latent observations are required")
    raw_std = (m2 / (count - 1)).sqrt().float()
    return LatentStats.from_raw_std(raw_std, count, tokenizer_id, **metadata)
