from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn

from .stochastic import StochasticRefiner, make_residual_flow_state


@dataclass
class FrameRecord:
    previous: torch.Tensor
    coarse: torch.Tensor
    target: torch.Tensor
    refined: torch.Tensor
    path_mask: torch.Tensor
    payload: object | None = None


def feedback_probability(progress: float, start: float = 0.10, ramp_end: float = 0.50, maximum: float = 0.75) -> float:
    if progress < start:
        return 0.0
    if progress < ramp_end:
        return maximum * (progress - start) / (ramp_end - start)
    return maximum


class OnlineRefinerRollout(nn.Module):
    def __init__(self, flow: nn.Module, delta_tok: nn.Module | None = None, train_flow_steps: int = 8, eval_flow_steps: int = 20) -> None:
        super().__init__()
        if delta_tok is None:
            delta_tok = getattr(flow, "delta_tok", None)
        if delta_tok is None:
            raise ValueError("flow must expose a frozen delta_tok or delta_tok must be provided")
        self.delta_tok = delta_tok.eval().requires_grad_(False)
        self.flow = flow.eval().requires_grad_(False)
        self.train_flow_steps = int(train_flow_steps)
        self.eval_flow_steps = int(eval_flow_steps)

    def encode_targets(self, frames: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            return self.delta_tok.backbone.encode(frames).detach()

    def rollout(
        self,
        frames: torch.Tensor,
        actions: torch.Tensor,
        refiner: nn.Module,
        channel_std: torch.Tensor,
        progress: float,
        training: bool,
        feedback_max: float = 0.75,
        generator: torch.Generator | None = None,
        refiner_generator: torch.Generator | None = None,
    ) -> list[FrameRecord]:
        if frames.ndim != 5 or frames.shape[1] != 13:
            raise ValueError(f"expected frames [B,13,C,H,W], got {tuple(frames.shape)}")
        if actions.shape[:2] != (frames.shape[0], 12):
            raise ValueError(f"expected actions [B,12,3], got {tuple(actions.shape)}")
        targets = self.encode_targets(frames)
        probability = feedback_probability(progress, maximum=feedback_max)
        path_mask = torch.rand(frames.shape[0], device=frames.device, generator=generator) < probability
        previous = targets[:, 0].detach()
        records: list[FrameRecord] = []
        flow_steps = self.train_flow_steps if training else self.eval_flow_steps
        for chunk in range(3):
            with torch.no_grad():
                z_chunk = self.flow.sample(previous, actions[:, chunk * 4 : chunk * 4 + 4], num_steps=flow_steps, generator=generator)
            for local in range(4):
                target = targets[:, chunk * 4 + local + 1].detach()
                with torch.no_grad():
                    coarse = self.delta_tok.decode(z_chunk[:, local], previous).detach()
                previous_input = previous.detach()
                if isinstance(refiner, StochasticRefiner) and training:
                    tau = torch.rand(frames.shape[0], device=coarse.device, dtype=coarse.dtype, generator=refiner_generator)
                    state = make_residual_flow_state(coarse, target, channel_std, refiner.sigma, tau, refiner_generator)
                    pred_v = refiner.velocity(previous_input, coarse, state.r_tau, tau)
                    payload = state, pred_v
                    # The loss graph is the current velocity evaluation; the feedback
                    # state is sampled without grad so later frames do not backpropagate.
                    refined = refiner.sample(
                        previous_input,
                        coarse,
                        channel_std,
                        num_steps=refiner.num_steps,
                        generator=refiner_generator,
                    )
                elif isinstance(refiner, StochasticRefiner):
                    refined = refiner.sample(previous_input, coarse, channel_std, refiner.num_steps if hasattr(refiner, "num_steps") else 4, refiner_generator)
                    payload = None
                else:
                    refined, correction = refiner(previous_input, coarse)
                    payload = correction
                next_previous = torch.where(path_mask.view(-1, 1, 1), refined.detach(), coarse.detach())
                records.append(FrameRecord(previous_input, coarse, target, refined, path_mask, payload))
                previous = next_previous
        return records
