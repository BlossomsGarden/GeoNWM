from __future__ import annotations

from typing import Any

import lightning
import torch
import torch.nn as nn
from torch.optim import AdamW

from .deterministic import DeterministicRefiner
from .rollout import OnlineRefinerRollout
from .stochastic import StochasticRefiner


class RefinerModule(lightning.LightningModule):
    automatic_optimization = False

    def __init__(self, refiner: nn.Module, rollout: OnlineRefinerRollout, channel_stats_path: str, lr: float = 1e-4, weight_decay: float = 1e-2, warmup_weight: float = 0.8, feedback_max: float = 0.75, gradient_clip_val: float = 1.0) -> None:
        super().__init__()
        self.refiner = refiner
        self.rollout_engine = rollout
        self.channel_std = torch.load(channel_stats_path, map_location="cpu", weights_only=False)["clamped_std"] if channel_stats_path else torch.ones(832)
        self.register_buffer("channel_std_buffer", torch.as_tensor(self.channel_std).float(), persistent=False)
        self.lr, self.weight_decay = lr, weight_decay
        self.warmup_weight, self.feedback_max, self.gradient_clip_val = warmup_weight, feedback_max, gradient_clip_val
        self.save_hyperparameters(ignore=["refiner", "rollout"])

    def configure_optimizers(self):
        return AdamW([p for p in self.refiner.parameters() if p.requires_grad], lr=self.lr, weight_decay=self.weight_decay)

    def _frame_loss(self, record):
        if isinstance(self.refiner, StochasticRefiner):
            state, pred_v = record.payload
            return StochasticRefiner.loss(pred_v, state.target_velocity)
        return DeterministicRefiner.loss(record.refined, record.target, self.channel_std_buffer)

    def training_step(self, batch: tuple[torch.Tensor, ...], batch_idx: int):
        frames, actions = batch[:2]
        optimizer = self.optimizers()
        optimizer.zero_grad()
        progress = float(self.global_step) / max(float(self.trainer.max_steps), 1.0)
        records = self.rollout_engine.rollout(frames, actions, self.refiner, self.channel_std_buffer, progress, True, feedback_max=self.feedback_max)
        total_weight = 4 * self.warmup_weight + 8.0
        losses = []
        for idx, record in enumerate(records):
            weight = self.warmup_weight if idx < 4 else 1.0
            loss = self._frame_loss(record)
            self.manual_backward(loss * (weight / total_weight))
            losses.append(loss.detach())
        torch.nn.utils.clip_grad_norm_(self.refiner.parameters(), self.gradient_clip_val)
        optimizer.step()
        self.log("train/loss", torch.stack(losses).mean(), prog_bar=True, sync_dist=True)
        return torch.stack(losses).mean().detach()

    def validation_step(self, batch: tuple[torch.Tensor, ...], batch_idx: int):
        frames, actions = batch[:2]
        with torch.no_grad():
            records = self.rollout_engine.rollout(frames, actions, self.refiner, self.channel_std_buffer, 1.0, False, feedback_max=self.feedback_max)
        values = torch.stack([((r.refined - r.target).float().pow(2).mean()) for r in records])
        self.log("val/mse", values.mean(), sync_dist=True)
        return values.mean()

    def on_before_optimizer_step(self, optimizer):
        pass

    def train(self, mode: bool = True):
        super().train(mode)
        self.rollout_engine.eval()
        self.refiner.train(mode)
        return self


class DeterministicRefinerModule(RefinerModule):
    pass


class StochasticRefinerModule(RefinerModule):
    pass
