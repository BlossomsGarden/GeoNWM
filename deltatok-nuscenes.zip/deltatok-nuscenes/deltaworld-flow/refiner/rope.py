from __future__ import annotations

import math

import torch


class Dynamic2DRoPE:
    def __init__(self, head_dim: int, theta: float = 10000.0) -> None:
        if head_dim < 4 or head_dim % 4:
            raise ValueError("head_dim must be divisible by four")
        self.head_dim = head_dim
        self.theta = theta

    def _angles(self, grid_size: int, device: torch.device, dtype: torch.dtype):
        axis_dim = self.head_dim // 2
        inv = 1.0 / (self.theta ** (torch.arange(0, axis_dim, 2, device=device, dtype=torch.float32) / max(axis_dim, 1)))
        coords = torch.arange(grid_size, device=device, dtype=torch.float32)
        row, col = torch.meshgrid(coords, coords, indexing="ij")
        row = row.reshape(-1, 1)
        col = col.reshape(-1, 1)
        row_ang = row * inv[None]
        col_ang = col * inv[None]
        angles = torch.cat((row_ang, col_ang), dim=-1)
        cos = torch.repeat_interleave(angles.cos(), 2, dim=-1).to(dtype)
        sin = torch.repeat_interleave(angles.sin(), 2, dim=-1).to(dtype)
        return cos, sin

    @staticmethod
    def _rotate(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
        half = x.shape[-1] // 2
        x1, x2 = x[..., :half], x[..., half:]
        rotated = torch.cat((-x2, x1), dim=-1)
        return x * cos + rotated * sin

    def apply(self, x: torch.Tensor, grid_size: int) -> torch.Tensor:
        if x.ndim != 4 or x.shape[-1] != self.head_dim:
            raise ValueError(f"expected [B,H,N,{self.head_dim}], got {tuple(x.shape)}")
        if grid_size * grid_size != x.shape[-2]:
            raise ValueError("token count must match square grid")
        cos, sin = self._angles(grid_size, x.device, x.dtype)
        return self._rotate(x, cos.view(1, 1, -1, self.head_dim), sin.view(1, 1, -1, self.head_dim))
