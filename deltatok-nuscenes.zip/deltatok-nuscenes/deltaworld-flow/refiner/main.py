from __future__ import annotations

import sys
from pathlib import Path

import torch
from lightning.pytorch.cli import LightningCLI

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent.parent
for path in (ROOT.parent, PARENT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from refiner.training import DeterministicRefinerModule, StochasticRefinerModule


def main() -> None:
    torch.set_float32_matmul_precision("high")
    LightningCLI(subclass_mode_model=True, subclass_mode_data=True)


if __name__ == "__main__":
    main()
