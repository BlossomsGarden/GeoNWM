# Latent Refiner Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or `superpowers:executing-plans`. Steps use checkbox (`- [ ]`) syntax.

**Goal:** Build two independently trainable latent refiners after every frozen DeltaTok decode: deterministic residual regression (A) and stochastic residual rectified flow (B), evaluated on closed-loop 12-frame nuScenes rollouts.

**Architecture:** A shared online rollout engine loads frozen DeltaTok and DeltaWorld-flow checkpoints, encodes `[B,13]` sequences, samples three consecutive four-frame flow chunks, and applies a refiner after every DeltaTok decode. Each sequence chooses coarse replay or refined feedback once for all 12 frames; every refined latent is detached immediately. A and B share rollout, statistics, data, and evaluation contracts but have separate models, objectives, configs, and checkpoints.

**Tech Stack:** PyTorch, Lightning manual optimization, existing `models.DeltaTok`/DINO-Tok wrappers, existing `deltaflow.DeltaWorldFlow`, nuScenes CSV/pose/crop utilities, optional LPIPS for read-only evaluation, and PyTest.

---

## Fixed Protocol

- Dataset samples are `frames [B,13,3,H,W]` and `actions [B,12,3]`.
- DINO-Tok, DeltaWorld-flow, DeltaTok encode/decode, and RGB decode are frozen and run under `torch.no_grad()`.
- The refiner runs after every `DeltaTok.decode`; its output becomes the next `previous` latent.
- Every refined frame is immediately detached. No gradient crosses a frame, chunk, frozen model, or flow/decode call.
- One Bernoulli path is sampled per sequence, not per chunk/frame. `False` means all-coarse replay; `True` means all-refined feedback.
- Feedback schedule by progress `p`: `p<0.10 -> 0.00`; `0.10<=p<0.50 -> 0.75*(p-0.10)/0.40`; `p>=0.50 -> 0.75`. Final mixture is 25% coarse and 75% refined.
- Train coarse chunks use Euler flow sampling with 8 steps; validation/final evaluation use 20 steps.
- Frame weights are `0.8` for offsets 1-4 and `1.0` for offsets 5-12. Each frame calls backward with `loss * weight / 11.2`; one optimizer step occurs after all 12 frames.
- `channel_std` is scanned once from training GT DINO-Tok latents, clamped to `[0.1*median_std,10*median_std]`, frozen, and shared by A/B. Stats include raw/clamped vectors and checkpoint/preprocessing metadata.
- B uses normalized correction flow, `sigma=0.1`, and Euler 4-step sampling. Planned independent sigma checkpoints are `0.05`, `0.1`, and `0.2`.
- DDT uses dynamic two-dimensional RoPE and independent previous/coarse cross-attention in the order `self -> previous -> coarse -> MLP`.
- Primary metrics use frames 5-12; frames 1-4 are warm-up diagnostics.

## File Structure

- `refiner/data.py`: 13-frame dataset and datamodule.
- `refiner/stats.py`: GT latent channel-stat scan, clamping, metadata, serialization.
- `refiner/rope.py`: dynamic 2D RoPE for square latent grids.
- `refiner/modules.py`: shared DDT blocks and zero-initialized output head.
- `refiner/deterministic.py`: scheme A and normalized SmoothL1.
- `refiner/stochastic.py`: scheme B residual flow and Euler sampler.
- `refiner/rollout.py`: frozen checkpoint adapters and three-chunk online rollout.
- `refiner/training.py`: Lightning manual optimization for A/B.
- `refiner/evaluation.py`: latent/RGB/LPIPS/diversity/temporal metrics and aligned visualization.
- `refiner/main.py`, `configs/refiner_{a,b}_{256,512}.yaml`, `README.md`.
- `refiner/tests/`: shape, stats, rollout, gradient, and metric tests.

### Task 1: Define the 13-frame dataset

**Files:** `refiner/data.py`; `refiner/tests/test_refiner_rollout.py`

- [ ] **Step 1: Write the failing continuity test**

```python
def test_thirteen_frame_windows_require_consecutive_ids():
    rows = list(range(14))
    ids = list(range(12)) + [14, 15]
    assert build_consecutive_windows(rows, ids, length=13) == []
```

- [ ] **Step 2: Implement datasets**

Reuse parent `SampleRow`, pose/calibration loaders, `compute_action`, `as_hw`, and `resize_then_principal_crop`. Enforce CAM_FRONT keyframes, `sequence_length=13`, consecutive IDs, train return `(frames, actions)`, and validation return `(frames, actions, index)`.

- [ ] **Step 3: Run and commit**

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_rollout.py::test_thirteen_frame_windows_require_consecutive_ids -q
```

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/refiner/data.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_rollout.py
git commit -m "feat: add refiner thirteen-frame dataset"
```

### Task 2: Scan and freeze GT latent channel statistics

**Files:** `refiner/stats.py`; `refiner/tests/test_refiner_stats.py`

- [ ] **Step 1: Write clamping and serialization tests**

```python
def test_channel_std_relative_clamp():
    raw = torch.tensor([0.001, 1.0, 100.0, 2.0])
    clamped = clamp_channel_std(raw)
    median = torch.median(raw)
    assert torch.all(clamped >= 0.1 * median)
    assert torch.all(clamped <= 10.0 * median)
```

- [ ] **Step 2: Implement stable float64 scanning**

`scan_gt_latent_stats(dataloader, frozen_dinotok, device)` encodes only training frames under `no_grad`, flattens batch/time/token dimensions, and updates count/mean/second moment without retaining batches. Compute per-channel std, median, and the relative clamp.

- [ ] **Step 3: Serialize and validate metadata**

Save schema version, sample/token counts, width/grid, tokenizer checkpoint identity, preprocessing fingerprint, raw std, median, and clamped std on CPU. Refuse mismatched width, image size, checkpoint identity, or preprocessing at startup.

- [ ] **Step 4: Test and commit**

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_stats.py -q
```

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/refiner/stats.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_stats.py
git commit -m "feat: add fixed GT latent statistics"
```

### Task 3: Implement dynamic 2D RoPE and common DDT

**Files:** `refiner/rope.py`; `refiner/modules.py`; `refiner/tests/test_refiner_shapes.py`

- [ ] **Step 1: Write shape and zero-init tests**

```python
def test_rope_supports_16_and_32():
    rope = Dynamic2DRoPE(head_dim=64)
    assert rope.apply(torch.randn(2, 13, 256, 64), 16).shape == (2, 13, 256, 64)
    assert rope.apply(torch.randn(2, 13, 1024, 64), 32).shape == (2, 13, 1024, 64)
```

- [ ] **Step 2: Implement runtime RoPE and DDT blocks**

Generate row/column frequencies for the supplied square grid and rotate Q/K only. Each block executes `self-attention -> previous cross-attention -> coarse cross-attention -> MLP`, with AdaLN time conditioning, independent previous/coarse norms/projections/gates, and a zero-initialized output projection. Use 8 blocks by default.

- [ ] **Step 3: Test and commit**

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_shapes.py -q
```

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/refiner/rope.py sources/deltatok-nuscenes/deltaworld-flow/refiner/modules.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_shapes.py
git commit -m "feat: add refiner DDT with dynamic RoPE"
```

### Task 4: Implement deterministic refiner A

**Files:** `refiner/deterministic.py`; `refiner/tests/test_refiner_shapes.py`

- [ ] **Step 1: Test identity at zero head init**

```python
def test_a_is_identity_at_zero_head_init():
    model = DeterministicRefiner(dim=832, depth=1, num_heads=13)
    previous = torch.randn(2, 256, 832)
    coarse = torch.randn_like(previous)
    refined, correction = model(previous, coarse)
    assert torch.allclose(refined, coarse)
    assert correction.shape == coarse.shape
```

- [ ] **Step 2: Implement forward and normalized loss**

Call common DDT with zero time conditioning, return raw correction and `refined=coarse+correction`. Use normalized SmoothL1 on `target=(gt-coarse)/channel_std` and `pred=correction/channel_std`. Do not add RGB/perceptual/action losses or ODE state.

- [ ] **Step 3: Test and commit**

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/refiner/deterministic.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_shapes.py
git commit -m "feat: add deterministic latent refiner"
```

### Task 5: Implement stochastic refiner B

**Files:** `refiner/stochastic.py`; `refiner/tests/test_refiner_shapes.py`

- [ ] **Step 1: Test normalized state**

```python
def test_b_state_starts_from_sigma_noise():
    coarse = torch.zeros(2, 16, 832)
    gt = torch.ones_like(coarse)
    state = make_residual_flow_state(coarse, gt, torch.full((832,), 2.0), 0.1, torch.zeros(2))
    assert state.r_tau.shape == coarse.shape
    assert torch.allclose(state.r_tau, state.r0)
```

- [ ] **Step 2: Implement training state**

Set `d=(gt-coarse)/channel_std`, `r0=sigma*epsilon`, `r_tau=(1-tau)*r0+tau*d`, and `v_target=d-r0`. Noise is never added directly to coarse.

- [ ] **Step 3: Implement velocity loss and Euler sampler**

Predict normalized velocity with `(previous, coarse, r_tau, tau)`. Train only velocity MSE. At inference start from `sigma*epsilon`, use `tau=step/num_steps`, update `r += v/num_steps`, and return `coarse+r*channel_std`. Default four steps; accept a seeded `torch.Generator`.

- [ ] **Step 4: Test and commit**

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/refiner/stochastic.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_shapes.py
git commit -m "feat: add stochastic residual-flow refiner"
```

### Task 6: Add frozen chunk adapter and 12-frame rollout

**Files:** modify `deltaflow/model.py`; create `refiner/rollout.py`; test `refiner/tests/test_refiner_rollout.py`

- [ ] **Step 1: Add fake-module rollout test**

Fake frozen flow/DeltaTok modules must produce three chunks, 12 coarse/refined latents, and no gradients on frozen parameters.

- [ ] **Step 2: Implement `FrozenDeltaWorldFlow.sample_chunk`**

Load the existing DeltaWorld-flow checkpoint plus nested DeltaTok checkpoint, call `.eval()` and `requires_grad_(False)`, validate `[B,N,832]` initial latent and `[B,4,3]` actions, and preserve residual slot order/sampler convention.

- [ ] **Step 3: Implement online GT encoding and path schedule**

Encode all 13 frames under `no_grad`. Implement the fixed piecewise probability, draw one boolean per sequence at rollout start, and store it in diagnostics.

- [ ] **Step 4: Implement three chunks and detach**

For each chunk, sample four residuals and decode sequentially. On refined path feed `refined.detach()` into the next decode/chunk. On coarse path run the refiner for its current-frame loss but feed `coarse.detach()` onward. Never use GT as `previous`.

- [ ] **Step 5: Test and commit**

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_rollout.py -q
```

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/deltaflow/model.py sources/deltatok-nuscenes/deltaworld-flow/refiner/rollout.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_rollout.py
git commit -m "feat: add online twelve-frame refiner rollout"
```

### Task 7: Add manual-optimization training

**Files:** `refiner/training.py`; `refiner/tests/test_refiner_rollout.py`

- [ ] **Step 1: Write gradient-equivalence test**

Verify twelve immediate backward calls scaled by `weights/11.2` equal one backward on the weighted sum, and verify one optimizer step occurs.

- [ ] **Step 2: Implement Lightning manual optimization**

Set `automatic_optimization=False`; call `zero_grad`, choose the path once, iterate 12 records, call `manual_backward(loss*weight/11.2)`, then clip and call one `optimizer.step()` after frame 12.

- [ ] **Step 3: Implement A/B modules and logs**

Use identical rollout/path schedule. A logs normalized endpoint loss; B logs normalized velocity loss and sigma. Both log per-offset losses, warm-up/primary aggregates, selected path fraction, and gradient norm. Refiner receives no action or horizon.

- [ ] **Step 4: Expose configuration**

Expose `feedback_start=0.10`, `feedback_ramp_end=0.50`, `feedback_max=0.75`, `warmup_weight=0.8`, `train_flow_steps=8`, `eval_flow_steps=20`, `refiner_steps=4`, `sigma=0.1`, and gradient clipping. Reject invalid stats at startup.

- [ ] **Step 5: Test and commit**

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/refiner/training.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_rollout.py
git commit -m "feat: add manual optimization for refiner"
```

### Task 8: Add evaluation metrics

**Files:** `refiner/evaluation.py`; `refiner/tests/test_refiner_metrics.py`

- [ ] **Step 1: Write offset aggregation test**

```python
def test_primary_offsets_are_frames_five_to_twelve():
    result = aggregate_offsets(torch.arange(12.0), primary_start=4)
    assert result.primary_mean == torch.tensor(7.5)
    assert result.warmup_mean == torch.tensor(1.5)
```

- [ ] **Step 2: Implement latent/RGB/LPIPS metrics**

Report normalized SmoothL1, raw MSE, cosine distance, and decoded RGB L1 for coarse/refined against GT, aggregated for warm-up, primary frames 5-12, each offset, and each four-frame chunk. LPIPS is optional, read-only, and never enters training.

- [ ] **Step 3: Implement B diversity and temporal metrics**

With fixed initial observation/actions/coarse seed, run multiple refiner seeds and report endpoint variance, pairwise latent/RGB distance, and adjacent-frame temporal consistency. Nonzero variance alone is not evidence of improvement.

- [ ] **Step 4: Implement aligned visualization and commit**

Produce columns `GT`, `coarse`, `refined` for frames 5-12. B's primary video uses one fixed refiner seed; other seeds are separate diagnostics.

```bash
git add sources/deltatok-nuscenes/deltaworld-flow/refiner/evaluation.py sources/deltatok-nuscenes/deltaworld-flow/refiner/tests/test_refiner_metrics.py
git commit -m "feat: add refiner rollout metrics"
```

### Task 9: Add configs, CLI, README, and end-to-end checks

**Files:** `refiner/main.py`; `refiner/configs/refiner_{a,b}_{256,512}.yaml`; `refiner/README.md`

- [ ] **Step 1: Write explicit configs**

Specify variant, frozen checkpoints, stats path, dataset paths, image size, width 832, heads 13, depth 8, `train_flow_steps: 8`, `eval_flow_steps: 20`, `refiner_steps: 4`, `warmup_weight: 0.8`, `feedback_max: 0.75`, and B's `sigma: 0.1`. Missing checkpoints/stats fail fast.

- [ ] **Step 2: Implement CLI**

Mirror the parent LightningCLI, select exactly one variant per run, use separate A/B checkpoint directories, and provide a stats-scan command before training.

- [ ] **Step 3: Document launch/evaluation**

Document the 13-frame contract, stats scan, independent A/B commands, fixed seed policy, 8/20 flow steps, Euler-4 B sampler, sigma ablation, primary frames 5-12, and evaluation-only RGB/LPIPS.

- [ ] **Step 4: Run local checks**

```powershell
python -m compileall sources/deltatok-nuscenes/deltaworld-flow/refiner
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/refiner/tests -q
```

Expected: compile succeeds and fake-module tests pass without remote assets.

- [ ] **Step 5: Run real smoke checks**

With assets available, run one A and one B train batch, verify finite losses, frozen upstream gradients, exactly one optimizer step after 12 backward calls, nonblank RGB decode, and validation with 20 flow steps/fixed seeds.

## Acceptance Criteria

- A/B train independently with separate objectives/checkpoints.
- A is deterministic conditional on `(previous, coarse)` and has no noise/ODE.
- B uses normalized correction flow with matching train/inference sigma, default `0.1`, Euler-4 sampling, and velocity-only loss.
- Both use the same online 13-frame data, whole-sequence path schedule, 8/20 flow steps, fixed GT channel stats, and evaluation protocol.
- Frozen calls are no-grad; every refined latent is detached immediately; only the current refiner call builds autograd.
- Frame losses use weights `0.8`/`1.0`, divide by `11.2`, backward immediately, then exactly one optimizer step.
- DDT has dynamic 2D RoPE and independent previous/coarse cross-attention.
- Primary conclusions use frames 5-12 and aligned identical-seed GT/coarse/refined comparisons.

## Self-Review

- **Coverage:** Includes selected C protocol, online generation, whole-rollout path sampling, `w_warmup=0.8`, 8/20 flow steps, normalized correction, GT-only clamped stats, `sigma=0.1`, Euler-4 B, RoPE, separate cross-attention, no-grad/detach, manual optimization, metrics, and A/B separation.
- **Placeholder scan:** No TBD/TODO or undefined implementation stage remains.
- **Type consistency:** Frames/actions, latent `[B,N,832]`, chunk `[B,4,3]`, normalized correction, and 12-frame offsets are consistent across tasks.
