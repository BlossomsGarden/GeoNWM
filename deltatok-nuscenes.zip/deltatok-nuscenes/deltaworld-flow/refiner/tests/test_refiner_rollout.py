import pytest

torch = pytest.importorskip("torch")

from refiner.rollout import feedback_probability


def test_feedback_schedule():
    assert feedback_probability(0.0) == 0.0
    assert feedback_probability(0.3) == pytest.approx(0.375)
    assert feedback_probability(0.8) == 0.75


def test_thirteen_frame_windows_require_consecutive_ids():
    from deltaflow.windowing import build_consecutive_windows

    rows = list(range(14))
    ids = list(range(12)) + [14, 15]
    assert build_consecutive_windows(rows, ids, length=13) == []
