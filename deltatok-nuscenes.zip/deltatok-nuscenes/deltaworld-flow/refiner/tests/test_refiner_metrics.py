import pytest

torch = pytest.importorskip("torch")

from refiner.evaluation import aggregate_offsets


def test_primary_offsets_are_frames_five_to_twelve():
    result = aggregate_offsets(torch.arange(12.0), primary_start=4)
    assert torch.equal(result.primary_mean, torch.tensor(7.5))
    assert torch.equal(result.warmup_mean, torch.tensor(1.5))
