import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from refiner.deterministic import DeterministicRefiner
from refiner.modules import RefinerDDT
from refiner.rope import Dynamic2DRoPE
from refiner.stochastic import StochasticRefiner, make_residual_flow_state


def test_rope_supports_16_and_32():
    rope = Dynamic2DRoPE(head_dim=64)
    assert rope.apply(torch.randn(2, 13, 256, 64), 16).shape == (2, 13, 256, 64)
    assert rope.apply(torch.randn(2, 13, 1024, 64), 32).shape == (2, 13, 1024, 64)


def test_output_head_is_zero_initialized():
    model = RefinerDDT(dim=832, depth=1, num_heads=13)
    assert torch.count_nonzero(model.output.weight) == 0
    assert torch.count_nonzero(model.output.bias) == 0


def test_a_is_identity_at_zero_head_init():
    model = DeterministicRefiner(dim=832, depth=1, num_heads=13)
    previous = torch.randn(2, 256, 832)
    coarse = torch.randn_like(previous)
    refined, correction = model(previous, coarse)
    assert torch.allclose(refined, coarse)
    assert correction.shape == coarse.shape


def test_b_state_starts_from_sigma_noise():
    coarse = torch.zeros(2, 16, 832)
    target = torch.ones_like(coarse)
    state = make_residual_flow_state(coarse, target, torch.full((832,), 2.0), 0.1, torch.zeros(2))
    assert state.r_tau.shape == coarse.shape
    assert torch.allclose(state.r_tau, state.r0)


def test_b_sampler_preserves_shape():
    model = StochasticRefiner(dim=832, depth=1, num_heads=13)
    x = torch.randn(2, 16, 832)
    assert model.sample(x, x, torch.ones(832), num_steps=1).shape == x.shape
