import pytest

torch = pytest.importorskip("torch")

from refiner.stats import LatentStats, clamp_channel_std


def test_channel_std_relative_clamp():
    raw = torch.tensor([0.001, 1.0, 100.0, 2.0])
    clamped = clamp_channel_std(raw)
    median = torch.median(raw)
    assert torch.all(clamped >= 0.1 * median)
    assert torch.all(clamped <= 10.0 * median)


def test_stats_round_trip(tmp_path):
    stats = LatentStats.from_raw_std(torch.ones(832), 13, "tok-a")
    path = tmp_path / "stats.pt"
    stats.save(path)
    assert LatentStats.load(path).tokenizer_id == "tok-a"
