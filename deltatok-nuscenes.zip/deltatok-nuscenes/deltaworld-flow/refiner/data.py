from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

from datasets.base import as_hw, resize_then_principal_crop
from datasets.nuscenes import (
    CAM_FRONT_NAMES,
    SampleRow,
    _load_cam_front_intrinsics,
    _load_selected_token_map,
    compute_action,
)
from deltaflow.windowing import build_consecutive_windows


class NuScenesRefinerDataset(Dataset):
    def __init__(
        self,
        csv_path: str,
        nuscenes_root: str,
        frame_size: int | tuple[int, int] = 256,
        sequence_length: int = 13,
        ego_pose_path: str | None = None,
        sample_data_path: str | None = None,
        calibrated_sensor_path: str | None = None,
    ) -> None:
        if sequence_length != 13:
            raise ValueError("Refiner requires sequence_length=13")
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.frame_size = as_hw(frame_size)
        metadata_root = self.nuscenes_root / "v1.0-trainval"
        self.ego_pose_path = Path(ego_pose_path or metadata_root / "ego_pose.json")
        self.sample_data_path = Path(sample_data_path or metadata_root / "sample_data.json")
        self.calibrated_sensor_path = Path(calibrated_sensor_path or metadata_root / "calibrated_sensor.json")
        grouped: dict[str, list[SampleRow]] = {}
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            for raw in csv.DictReader(handle):
                if raw.get("cam") not in CAM_FRONT_NAMES:
                    continue
                row = SampleRow(raw["scene_id"], int(raw["frame_id"]), raw["file"], raw["ego_pose_token"])
                grouped.setdefault(row.scene_id, []).append(row)
        self.sequences: list[tuple[SampleRow, ...]] = []
        for rows in grouped.values():
            rows.sort(key=lambda row: row.frame_id)
            self.sequences.extend(build_consecutive_windows(rows, [r.frame_id for r in rows], 13))
        if not self.sequences:
            raise ValueError(f"No consecutive 13-frame CAM_FRONT windows found in {self.csv_path}")
        tokens = {r.ego_pose_token for seq in self.sequences for r in seq}
        self.ego_poses = _load_selected_token_map(self.ego_pose_path, tokens)
        self.intrinsics_by_file = _load_cam_front_intrinsics(str(self.sample_data_path.resolve()), str(self.calibrated_sensor_path.resolve()))

    def _resolve(self, filename: str) -> Path:
        path = Path(filename)
        candidates = [path if path.is_absolute() else self.nuscenes_root / path,
                      self.nuscenes_root / "samples" / "CAM_FRONT" / path.name]
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(f"Could not resolve image path {filename!r}")

    def _frame(self, row: SampleRow) -> torch.Tensor:
        with Image.open(self._resolve(row.file)) as image:
            image_np = np.asarray(image.convert("RGB"))
        intrinsic = self.intrinsics_by_file.get(row.file)
        if intrinsic is None:
            intrinsic = self.intrinsics_by_file.get(Path(row.file).name)
        image_np = resize_then_principal_crop(image_np, intrinsic, self.frame_size)
        return torch.from_numpy(image_np.copy()).permute(2, 0, 1)

    def __len__(self) -> int:
        return len(self.sequences)

    def __getitem__(self, idx: int):
        rows = self.sequences[idx]
        frames = torch.stack([self._frame(row) for row in rows])
        actions = torch.stack([compute_action(self.ego_poses[a.ego_pose_token], self.ego_poses[b.ego_pose_token]) for a, b in zip(rows, rows[1:])])
        return frames, actions


class NuScenesRefinerTrain(NuScenesRefinerDataset):
    pass


class NuScenesRefinerVal(NuScenesRefinerDataset):
    def __getitem__(self, idx: int):
        frames, actions = super().__getitem__(idx)
        return frames, actions, idx
