# DINO-Tok Latent Refiner Design

本文档整理 refiner 第一版的目标、训练数据构造和两个并行模型版本。refiner 的任务是接在每一次 DeltaTok decode 后，将 DeltaWorld-flow 产生的低质量 latent 修复到 DINO-Tok-AE 的有效 latent 分布附近。本文档只描述设计，不包含实现细节和启动命令。

## 总体决策

项目层面的选择仍然是 C，但 A 和 B 不再被当作先后两个阶段，而是两个可以独立训练、独立评估的模型版本：

- **方案 A：deterministic latent refiner**。直接预测 residual correction，以 latent loss 监督最终 latent。它是最干净的 baseline，用来回答 DDT 是否能够修复 DeltaWorld-flow 带来的 blur、checkerboard 和 latent drift。
- **方案 B：stochastic residual flow refiner**。在 residual correction 空间中训练 conditional rectified flow，从小尺度随机初始 correction 出发，通过 velocity field 生成修复结果。它用于检验 refiner 是否能在修复质量之外保留或增加合理的细节生成能力。

两个版本共享输入形式、冻结的上游模型、训练样本构造方式和评估协议，但使用不同的训练目标。最终根据 latent accuracy、解码后的 RGB 质量、rollout 稳定性和生成多样性选择实际使用的版本。A 的上游 DeltaWorld-flow 本身仍然可以通过其采样噪声产生不同 coarse rollout；A 只是 refiner 本身不额外引入随机性。B 则额外对 refiner 的修复结果进行随机采样。

## 1. 实际目标：采用 C，并行比较 A/B

目标 A 的含义是允许 refiner 修正 `U_coarse` 与真实下一帧 latent 之间的全部差异，包括少量运动误差、时间误差和空间重建误差。当前最需要先验证的是：给定已经生成的 `U_coarse`，一个 latent-space DDT 是否能够把它拉回到真实 DINO-Tok-AE latent，而不是先限制它只能修改局部高频区域。

因此第一版不加入强 preservation 或 action-consistency correction 约束。过早加入这类约束可能把上游已有的 blur 和运动偏差保留下来。方案 B 也不额外加入 endpoint latent loss，避免把每一个随机样本都强行拉到同一个 GT，从而抑制其生成能力。若未来需要严格保持动作和时间结果，再单独设计方案 B 的结构保持约束，而不是混入这两个 baseline 的定义中。

## 2. 输入、输出和调用位置

设冻结的 DINO-Tok-AE encoder 和 decoder 分别为 (E) 和 (G)：

```text
U_t          = E(I_t)
U*_t+1       = E(I_t+1)
U_coarse_t+1 = DeltaTok.decode(z_hat_t, U_t)
```

refiner 的基本接口不接收 action，也不接收 DeltaWorld-flow 的 horizon：

```text
refiner(previous_latent, coarse_latent) -> correction 或 refined_latent
```

其中 `previous_latent` 和 `coarse_latent` 的形状为 `[B, N, C]`，当前 `C=832`。对于方案 B，DDT velocity head 还需要接收 residual flow 内部的状态 `r_tau` 和 flow time `tau`，但这两个量是 refiner 自己的采样变量，不是上游 action 或 dynamics horizon。

第一版位置编码选 **A**：复用现有 DINO-Tok / DeltaTok 的二维 RoPE，按 latent grid 动态生成，而不是额外引入固定 sin-cos 或可学习绝对位置表。这样同一套 refiner 可以直接兼容 16x16 和 32x32 的 latent grid，也不会因为 256 / 512 两种分辨率去维护两份位置参数。这里的 segment embedding 只负责区分 `previous`、`coarse`、`r_tau` 等角色，真正的空间对齐信息仍然由 2D RoPE 提供。

DDT 对 `previous` 和 `coarse` 的条件融合也选 **A**：两个独立 cross-attention，顺序为 `r -> previous` 再 `r -> coarse`，并分别使用独立的 norm、投影和 gate。这样 `previous` 作为历史结构参考先提供全局锚点，`coarse` 再提供当前待修复结果，语义边界是显式的，不需要让模型仅靠 segment embedding 去自己猜哪一半是 prior、哪一半是 observation。相比之下，拼接成 `[B,2N,C]` 再做一次 cross-attention 虽然更省参数，但会把两种语义不同的条件混在同一个 memory bank 里，第一版不够干净。

refiner 放在每一次 DeltaTok decode 之后，并且下一次 decode 使用 refined previous：

```text
previous = U_0
for h in range(4):
    coarse = DeltaTok.decode(z_hat[:, h], previous)
    refined = coarse + refiner(previous, coarse)
    previous = refined
```

因此它不是对四个 future latent 一次性做 post-processing，也不是只修复最后一帧。每次调用只输出当前的 (U_{t+1})，但这个结果会影响后续递归 decode。时间一致性第一版主要通过 refined previous 传递，不给 refiner 加显式 temporal attention 或四帧 joint prediction。

## 3. 方案 A：确定性 latent correction

方案 A 直接学习 coarse latent 到 GT latent 的 correction：

```text
d*              = U* - U_coarse
correction      = R_A(previous, coarse)
refined         = U_coarse + correction
```

它没有需要积分的 `r0`。若为了复用 flow 的代码路径而写成从 `r0=0` 开始的 deterministic flow，其目标 velocity 会退化为 (d^*)，但这比直接 residual regression 多引入了不必要的 flow time 和 ODE 误差。因此 A 的正式定义是直接 latent residual regression，推理时一次 DDT forward 得到 correction。

方案 A 的训练目标为最终 refined latent 与目标 latent 之间的归一化 SmoothL1：

```text
L_A = weighted_mean_h SmoothL1((refined_h - U*_h) / channel_std)
```

For the first version, `channel_std` follows option C: compute it once from the training-set GT DINO-Tok latent `U*`, then clamp it to `[0.1 * median(channel_std), 10 * median(channel_std)]` and freeze it for both A and B. We do not re-estimate it from coarse corrections, because the normalization basis should reflect the target latent manifold, not the current coarse sampler quality.

`channel_std` 只用训练集 GT latent 的 channel 标准差作为固定归一化基准，再按 median 做上下裁剪，避免少数低方差 channel 把 loss 放大，也避免少数高方差 channel 过度变小权重。A/B 共用同一套统计，比较才公平，也不会随着 coarse 质量变化而漂移。对应的统计文件还应保存 tokenizer checkpoint 标识、样本数、每个 channel 的原始 std 和裁剪后 std。SmoothL1 在小误差区域提供平滑的二次梯度，在 coarse 严重失真时又比 MSE 更不容易被异常误差主导。

方案 A 是 deterministic refiner，但整个系统不一定是 deterministic，因为上游 DeltaWorld-flow 的 `sample()` 仍从噪声生成 `z_hat`。这里的 deterministic 只表示：在给定 `previous` 和 `coarse` 后，A 不再根据新的随机变量生成不同修复结果。

## 4. 方案 B：stochastic residual flow

方案 B 不是对 `U_coarse` 直接加噪再去噪，而是在 correction 空间中定义随机 flow。令：

```text
d*    = U* - U_coarse
d_bar = norm(d*)
r0    = sigma * epsilon,    epsilon ~ Normal(0, I)
r_tau = (1 - tau) * r0 + tau * d_bar
v_bar = d_bar - r0
```

In the first version, `d*` in this block is shorthand for the normalized residual `d_bar = norm(U* - U_coarse)`, and `r1_bar` denotes the normalized endpoint before denormalization.

训练时 DDT 接收 `(previous, coarse, r_tau, tau)`，预测 correction velocity `v_theta`，使用标准 rectified-flow velocity MSE：

```text
L_B = weighted_mean_h E[ ||v_theta(r_tau, tau, previous, coarse) - (d_bar - r0)||^2 ]
```

这里的 MSE 是速度场 MSE，不是简单把人工噪声与某个 latent 做 MSE。`r0` 是 correction 的初始状态，不是直接把噪声加到 `U_coarse` 上。推理时从同样尺度的 `r0=sigma*epsilon` 出发，执行少步 ODE，得到 `r1_bar`，然后：

```text
refined = U_coarse + denorm(r1_bar)
```

`sigma` 应在 channel-normalized latent/correction 空间中定义，并作为可配置参数。第一版建议默认 `sigma=0.1`，并正式比较 `[0.05, 0.1, 0.2]`。它应当足够小，使 flow 主要负责修复和细节生成，而不是从完全无关的随机 latent 重建整幅画面；但也不能小到把 B 退化成几乎确定性的 residual regression。方案 B 的第一版只使用 `L_B`，不再叠加最终 latent endpoint loss；否则不同 noise seed 的输出都会被同一个观测 GT 拉近，容易发生 mode averaging 和随机性塌缩。

B 的 few-step ODE 第一版选择 **Euler 4 步**，并在 `[2, 4, 8]` 上做正式比较。Euler 4 步是默认速度和质量的折中点，也和上游 flow sampler 的简单 Euler 路线更一致；2 步用于验证极低开销是否仍能修复 checkerboard/blur，8 步用于判断 B 是否主要受 ODE 离散误差限制。Heun 4 步约等于 8 次网络计算，第一版先作为后续 ablation，不作为默认协议。

需要注意，B 的随机性不能凭空恢复不可见区域真实发生过的内容。它学习的是条件分布中合理的修复结果。如果给定 `(previous, coarse)` 后目标事实上几乎确定，flow 可能自然退化为低方差映射；如果不可见区域存在多个合理结果，B 才有机会利用 noise 生成不同细节。是否真正得到多样性必须通过多 seed rollout 评估，不能仅根据 velocity loss 判断。

## 5. 七个问题的具体回应

### 5.1 Loss 中各项的符号

所有 loss 项如果表示距离，都应使用加号。此前写成减去 L1 或 perceptual loss 只是符号错误；只有在该项明确表示 similarity 并且优化目标是最大化 similarity 时，才可能出现减号。

本设计两个版本都不使用 RGB reconstruction loss 和 RGB perceptual loss：

- A 使用 latent endpoint SmoothL1；
- B 使用 latent correction velocity MSE；
- RGB L1、LPIPS 等只作为 validation/evaluation 指标，不参与第一版反向传播。

这样可以先隔离 refiner 对 DINO-Tok latent manifold 的修复能力。RGB loss 当然可能提供 decoder-aware 的梯度，但它也可能让 latent 偏离 (E(I))，尤其是原始图像 (I) 与冻结 AE reconstruction (G(E(I))) 不完全一致时。第一版同时加入 RGB 或 LPIPS 会让实验无法判断改善来自 latent repair 还是 decoder compensation，因此暂不采用。

### 5.2 确定性版本的 `r0=0` 与带噪声 flow

A 不采用带高斯噪声的 flow 训练，而是直接做 residual regression。概念上可以把 A 看成从 `r0=0` 出发的确定性修复，但实现上不需要构造 `r_tau`、`tau` 或 ODE。

B 使用 `r0=sigma*epsilon` 并采用 velocity MSE。A 和 B 是两个独立 checkpoint、独立 loss 的模型版本，而不是通过一个命令行开关在同一训练过程中混合两种目标。后续可以让启动脚本选择版本，但训练统计和模型权重必须保持可区分。

### 5.3 Refiner 是后处理还是递归 rollout 的一部分

它是递归 rollout 的一部分，具体位置是每次 DeltaTok decoder 之后。当前 DeltaWorld-flow 的 `sample()` 一次产生四个 residual slots，但这不改变 refiner 的逐帧调用方式。对于第 (h) 步，refiner 只处理当前 decode 得到的 coarse frame；处理后的 frame 立即作为下一步 DeltaTok decode 的 `previous`。

### 5.4 训练 rollout 中的 `U_t` 来源

训练包含两种数据路径，不使用 GT teacher forcing：

1. **coarse replay path**：完全冻结 DeltaWorld-flow 和 DeltaTok，按推理流程生成低质量 rollout。第 0 步使用观测到的初始 (U_0)，之后每一步使用上一个 coarse latent。refiner 输入和推理 baseline 一致，目标始终是对应的 GT DINO-Tok latent。
2. **refined feedback path**：当前帧经过 refiner 后，立即把 refined latent 送入后续的 DeltaTok decode，模拟实际部署时 refiner 在闭环中的误差分布。若进一步要求 refined latent 也重新进入 DeltaWorld-flow 的条件分支，则需要单独的 autoregressive data-generation wrapper，在每一步用当前 refined latent 重新调用冻结 flow。现有 `DeltaWorldFlow.sample()` 是以初始 latent 为条件一次生成四步 chunk，不能把预先生成的四个 residual chunk 直接称为完整的 flow-and-decoder feedback。

训练时可以混合这两条路径。建议使用可配置的 `feedback_probability`，而不是把 `step % 10 == 0` 写死在训练逻辑中；`0.1` 的概率可以表达“约每十次使用一次 feedback”，并且更容易调度和复现实验。训练初期可使用较低概率，随后逐渐提高到目标比例，但 A/B 两个版本都应使用同样的数据路径和调度，保证比较公平。无论是否使用 feedback，都不应把未来 GT latent 作为 rollout 的 previous。

path 的采样粒度也在这里一并确定：第一版采用 **A**，也就是对一个 `[B,13]` 的完整 12-frame rollout 样本只抽样一次 path，整条序列在三次 flow forward 中共享同一种 path。这样每条序列内部不会出现 coarse/refined previous 来回切换，训练分布更干净，也更接近真实闭环部署。

A/B 两个版本都使用这个 sample-level path 粒度；区别只保留在 refiner 目标和采样方式上，不把 path 切换粒度本身做成额外变量。chunk-level 或 frame-level 抽样都放到后续 ablation，不作为第一版默认协议。
### 5.5 是否需要时间相关噪声

第一版不让 refiner 显式处理整段时间序列，也不设计跨帧 correlated noise。refiner 是空间 latent frame 的修复器，每次调用只采样当前 frame 的 correction noise；时间信息通过上一帧 refined latent 递归传递。

这意味着 B 在连续帧上独立采样时可能出现细节 flicker，这是当前设计接受的可观测风险，而不是通过隐藏的时间噪声机制掩盖。评估时应记录多 seed 的单帧多样性和连续帧 temporal consistency。只有确认 B 的空间生成有效但跨帧闪烁明显，才在后续版本加入 temporal attention、noise reuse 或显式 temporal consistency objective。

### 5.6 Coarse 样本是否严格复现推理

必须严格复现推理使用的：

- DeltaWorld-flow checkpoint；
- 冻结 DeltaTok checkpoint；
- latent 的 dtype、normalization 和 token 排列；
- action window 和 residual slot 的组织方式；
- recursive DeltaTok decode 顺序；
- sampling seed policy；
- ODE solver 和默认 sampling steps。

这样 coarse replay path 才真正代表 refiner 部署时看到的输入。训练可以使用多个可复现 seed，避免 refiner 记住一个固定 coarse artifact；验证和 A/B 对比则应使用固定 seed 集合。

ODE 步数可以比正式推理少一些，用来产生更差的 coarse 输入并提高 refiner 的鲁棒性，但这应标记为 controlled error augmentation，而不是声称与推理分布完全一致。建议 exact inference configuration 作为主训练分布，低 ODE steps 作为可配置的小比例混合分布。否则如果一开始只用低步数样本，refiner 的提升可能只反映它适应了人为制造的失真，而不能说明它修复了真实部署输入。

### 5.7 Horizon 和 action 是否进入 refiner

不进入。action 和 horizon 已经参与上游 DeltaWorld-flow 的 residual 生成；`U_coarse` 是这些条件作用后的结果。refiner 只根据 `previous` 和当前 `coarse` 判断需要怎样修复。训练时可以按照 rollout step 使用 `w_h` 做 loss weighting，但这里的 (h) 只存在于数据和统计逻辑中，不作为 refiner 的条件输入。


12 帧训练的 loss 权重采用 **B**：12 个 frame offset 都参与反向传播，但前 4 帧使用较低权重，后 8 帧使用主权重。第一版使用权重向量 `[0.8, 0.8, 0.8, 0.8, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]`，权重和为 `11.2`。每帧立即 backward 时，当前帧 loss 先乘以 `w_h / sum(w)`，也就是累计梯度满足 `g <- g + (w_h / 11.2) * grad(L_h)`。这样前 4 帧仍然负责学习基础修复并构造稳定的 feedback 状态，但训练重心与最终只统计第 5 到第 12 帧的评估协议保持一致。

第一版暂不采用随 offset 逐帧递增的 D。后 8 帧本身已经处于更困难、误差更大的闭环分布；再次单调放大尾部帧，可能使训练过度关注极端 rollout 误差，并造成训练目标与后 8 帧的无权平均评估不一致。D 保留为后续 ablation：只有当后 8 帧仍然随 offset 明显恶化时，再测试更激进的 tail weighting。

这里的“参与反向传播”不意味着跨 12 帧保留一张完整计算图。按照 truncated rollout 设定，每个 frame 的 refined latent 在送入后续 rollout 前都会 detach；因此更合适的实现是每帧立即 backward、12 帧累积梯度后再统一 optimizer step，而不是把 12 个 loss 全部留到最后一次性 backward。12 帧 backward 完成后，先执行一次统一的梯度裁剪，再执行一次 optimizer step 和 zero grad。这样既保留 12 帧加权监督，又不会同时挂住 12 份 DDT 激活。A/B 两个版本使用完全相同的 frame weights，只有各自的 latent endpoint loss 与 velocity MSE 不同。
## 6. 训练和评估协议

A 和 B 使用相同的冻结模型、action 序列、coarse sampler 配置和 rollout 评估协议。评估不是只运行一次四帧的 DeltaWorld-flow，而是连续 forward 三次：每次生成四帧，三次得到未来 12 帧。每一次 forward 的起始 latent 都是上一段 rollout 的最后一个 latent；无 refiner 分支使用上一段的 coarse latent，refiner 分支使用上一段的 refined latent。这样才能测到 refiner 是否减缓递归误差累积，而不只是改善第一段容易的短期结果。

训练数据也应尽量覆盖这条 12-frame rollout。理想的数据样本包含初始观测帧、未来 12 帧和对应的 12 个 action transitions，即 `frames [B,13,C,H,W]` 与 `actions [B,12,3]`，或者由三个相邻且边界对齐的四步窗口构造出同样的序列。每个时刻的监督目标仍然是该时刻对应的 `U*=E(I)`，不使用未来 GT latent 作为 rollout 的 `previous`。如果第一版先使用现有 `[B,5]` 数据做局部训练，也必须额外使用三次 forward 的长 rollout 做验证；最终模型选择不能只依据局部四帧 loss。

主评估指标只统计未来 12 帧中的后 8 帧，也就是第 5 到第 12 帧。前 4 帧作为 warm-up，只用于记录辅助诊断结果，不作为最终性能结论。这样做是因为第一段输出既受到真实初始观测的帮助，又尚未充分暴露递归误差；如果只计算第一次 forward 的四帧，可能看不出 refiner 在连续 rollout 中是否真正有效。主指标应同时报告后 8 帧的整体平均值、每个绝对 frame offset 的曲线，以及第二次和第三次 DeltaWorld-flow forward 的分组结果。

最终可视化采用固定的三列视频横向拼接，并保持每一列的时间帧严格对齐：

```text
左列：GT future video，frames 5...12
中列：不经过 refiner 的 DeltaWorld-flow + DeltaTok rollout，frames 5...12
右列：经过 refiner 的 rollout，frames 5...12
```

三列必须使用相同的初始观测、action、coarse flow seed 和时间范围。方案 A 直接展示其唯一的 refined rollout；方案 B 的主视频使用固定的 refiner noise seed，保证与 A 的视频比较可复现，其他 noise seeds 则作为单独的多样性可视化或统计。前 4 帧可以作为同一视频的可选 warm-up 行或附加诊断视频，但不应取代后 8 帧的主对比图。

第一版至少需要记录以下结果：

- 第 5 到第 12 帧的 refined latent 与 GT latent 的 normalized SmoothL1、MSE 和 cosine distance；
- coarse、refined、GT latent 分别解码后的 RGB L1；
- LPIPS 作为只读评估指标；
- 后 8 帧整体平均值、每帧指标，以及按第二次/第三次 flow forward 分组的指标；
- coarse baseline 与 refined rollout 在完全相同 coarse seed 下的对比；
- B 在多个 refiner noise seeds 下的 endpoint variance、pairwise distance 和 temporal consistency；
- 第 1 到第 4 帧的 warm-up 指标，作为误差传播诊断而不是最终主指标。

选择模型时，A 主要看后 8 帧的 latent accuracy、RGB sharpness 和递归稳定性；B 除了这些指标，还必须证明多 seed 结果具有有意义的多样性。如果 B 只增加随机性，却没有改善第 5 到第 12 帧的 hidden-region 视觉质量或整体 rollout，不能因为它使用了 flow 就认为它优于 A。

## 7. 后续目录和实现边界

两个版本都放在本目录下，并分别保存 checkpoint、配置和训练入口。后续 README 应提供两套独立的启动命令，明确说明：A 使用 deterministic latent loss，B 使用 stochastic residual flow velocity loss。公共部分负责加载冻结的 DeltaTok/DeltaWorld-flow、生成 coarse rollout、执行逐帧 refiner rollout 和记录统一指标；A/B 只替换 refiner 状态、采样过程和 loss。

第一版明确不包含：RGB-perceptual training loss、endpoint latent loss 与 stochastic flow 的混合目标、强 action/time preservation penalty、跨帧 temporal refiner、GT teacher forcing，以及未经定义的“把一次性四步 flow chunk 当成 refined-flow feedback”的实现。
