from __future__ import annotations

import torch
import torch.nn.functional as F
import torch.nn as nn

from .modules import RefinerDDT


class DeterministicRefiner(nn.Module):
    def __init__(self, dim: int = 832, depth: int = 8, num_heads: int = 13, mlp_ratio: float = 4.0) -> None:
        super().__init__()
        self.backbone = RefinerDDT(dim, depth, num_heads, mlp_ratio)

    def forward(self, previous: torch.Tensor, coarse: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        correction = self.backbone(coarse, previous, coarse)
        return coarse + correction, correction

    @staticmethod
    def loss(refined: torch.Tensor, target: torch.Tensor, channel_std: torch.Tensor) -> torch.Tensor:
        scale = channel_std.to(device=refined.device, dtype=refined.dtype).reshape(1, 1, -1)
        return F.smooth_l1_loss((refined - target) / scale, torch.zeros_like(refined), reduction="mean")
