# DeltaWorld Flow Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the first `deltaworld-flow` training project for online future-action-conditioned rectified flow in frozen DeltaTok residual space.

**Architecture:** Add a self-contained `deltaflow` Python package under `deltaworld-flow/` while reusing the parent DeltaTok project as a local dependency. The package includes a five-frame nuScenes sequence dataset, action pooling, Scene-Action Resampler, causal Flow DiT, a Lightning module that freezes DeltaTok and computes online residual targets, configs, and smoke tests.

**Tech Stack:** PyTorch, Lightning, jsonargparse/LightningCLI, einops, ijson/PIL/OpenCV via parent nuScenes utilities, W&B logging patterns from the parent project.

---

## File Structure

- Create: `sources/deltatok-nuscenes/deltaworld-flow/main.py`
  - Training entry point. Adds `deltaworld-flow/` and parent `deltatok-nuscenes/` to `sys.path`, then launches LightningCLI.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/__init__.py`
  - Package marker and public exports.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/datasets.py`
  - Five-frame consecutive `CAM_FRONT` nuScenes sequence datasets returning `frames`, `actions`, and validation index.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/modules.py`
  - Reusable neural building blocks: timestep embedding, AdaLN modulation, MLP, attention wrappers, action poolers, resampler, Flow DiT.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/model.py`
  - `DeltaWorldFlow` network that loads and freezes DeltaTok, extracts online targets, computes flow predictions, and samples residual chunks.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/training.py`
  - Lightning module with horizon schedule, MSE losses, validation metrics, sampled residual diagnostics, and RGB rollout logging.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/configs/deltaflow_nuscenes_256.yaml`
  - 256-resolution training config.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/configs/deltaflow_nuscenes_512.yaml`
  - 512-resolution training config.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/README.md`
  - Launch commands and checkpoint contract.
- Create: `sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py`
  - Shape and mask tests for schedule, dataset windowing, action pooling, resampler, Flow DiT, and sampling helpers.

---

### Task 1: Add Package And Training Entry

**Files:**
- Create: `sources/deltatok-nuscenes/deltaworld-flow/main.py`
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/__init__.py`

- [ ] **Step 1: Create the package marker**

Create `deltaflow/__init__.py` with public names:

```python
from deltaflow.model import DeltaWorldFlow
from deltaflow.training import DeltaWorldFlowModule

__all__ = ["DeltaWorldFlow", "DeltaWorldFlowModule"]
```

- [ ] **Step 2: Create the LightningCLI entry point**

Create `main.py` with this behavior:

```python
from __future__ import annotations

import logging
import sys
import warnings
from datetime import datetime
from importlib.metadata import distributions
from pathlib import Path
from typing import Any

import torch
from dotenv import load_dotenv
from lightning import Trainer
from lightning.pytorch import cli
from lightning.pytorch.callbacks import Callback, LearningRateMonitor, ModelCheckpoint, ModelSummary

PROJECT_ROOT = Path(__file__).resolve().parent
PARENT_ROOT = PROJECT_ROOT.parent
for path in (str(PROJECT_ROOT), str(PARENT_ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

from deltaflow.training import DeltaWorldFlowModule

class LogRun(Callback):
    def setup(self, trainer: Trainer, pl_module: DeltaWorldFlowModule, stage: str) -> None:
        if trainer.logger is not None:
            trainer.logger.experiment.log_code(
                ".", include_fn=lambda filename: filename.endswith((".py", ".yaml", ".md", ".env"))
            )

    def on_train_start(self, trainer: Trainer, pl_module: DeltaWorldFlowModule) -> None:
        if not trainer.is_global_zero or trainer.logger is None:
            return
        experiment = trainer.logger.experiment
        experiment_dir = experiment.dir() if callable(experiment.dir) else experiment.dir
        if experiment_dir and Path(experiment_dir).exists():
            pkg_path = Path(experiment_dir) / f"pip-freeze-step{trainer.global_step}.txt"
            pkg_path.write_text("\n".join(sorted(f"{d.name}=={d.version}" for d in distributions())))
            experiment.save(str(pkg_path), policy="now")
        entry = f"[step {trainer.global_step}] {datetime.now().isoformat()}\n$ {' '.join(sys.argv)}"
        experiment.notes = f"{experiment.notes or ''}\n{entry}".strip()

class LightningCLI(cli.LightningCLI):
    def __init__(self, *args: Any, **kw: Any) -> None:
        load_dotenv()
        torch.set_float32_matmul_precision("high")
        torch.backends.cudnn.benchmark = True
        logging.getLogger().setLevel(logging.INFO)
        warnings.filterwarnings("ignore", message=r".*Found .* module\(s\) in eval mode.*")
        super().__init__(*args, **kw)

def cli_main() -> None:
    LightningCLI(
        DeltaWorldFlowModule,
        subclass_mode_model=True,
        subclass_mode_data=True,
        save_config_callback=None,
        seed_everything_default=0,
        trainer_defaults={
            "max_epochs": -1,
            "accelerator": "gpu",
            "devices": 2,
            "strategy": "ddp",
            "precision": "bf16-mixed",
            "enable_model_summary": False,
            "log_every_n_steps": 1,
            "check_val_every_n_epoch": None,
            "val_check_interval": 5000,
            "callbacks": [
                ModelSummary(max_depth=3),
                LearningRateMonitor(logging_interval="step"),
                LogRun(),
                ModelCheckpoint(every_n_train_steps=50000, save_top_k=-1),
                ModelCheckpoint(monitor="losses/val", mode="min", save_top_k=1),
                ModelCheckpoint(every_n_train_steps=500, save_last=True, save_top_k=0, enable_version_counter=False),
            ],
            "logger": {
                "class_path": "lightning.pytorch.loggers.wandb.WandbLogger",
                "init_args": {"project": "deltaworld-flow", "save_dir": str(PROJECT_ROOT / "runs")},
            },
        },
    )

if __name__ == "__main__":
    cli_main()
```

- [ ] **Step 3: Verify import wiring**

Run:

```powershell
python -m py_compile sources/deltatok-nuscenes/deltaworld-flow/main.py
```

Expected: command exits with code `0`.

### Task 2: Add Five-Frame nuScenes Sequence Dataset

**Files:**
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/datasets.py`
- Test: `sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py`

- [ ] **Step 1: Write sequence dataset tests**

Add tests that construct fake rows and assert five-frame windows are consecutive:

```python
from deltaflow.datasets import build_consecutive_windows

def test_build_consecutive_windows_requires_five_consecutive_frames():
    rows = [object() for _ in range(6)]
    frame_ids = [10, 11, 12, 13, 14, 16]
    windows = build_consecutive_windows(rows, frame_ids, length=5)
    assert windows == [(rows[0], rows[1], rows[2], rows[3], rows[4])]
```

- [ ] **Step 2: Implement dataset module**

Implement `build_consecutive_windows`, `_NuScenesSequenceDataset`, `NuScenesSequenceTrain`, and `NuScenesSequenceVal`. Reuse parent utilities:

```python
from datasets.base import as_hw, resize_then_principal_crop
from datasets.nuscenes import CAM_FRONT_NAMES, SampleRow, _load_selected_token_map, _load_cam_front_intrinsics, compute_action
```

The training item returns `(frames, actions)`. The validation item returns `(frames, actions, idx)`.

- [ ] **Step 3: Run dataset tests**

Run:

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py::test_build_consecutive_windows_requires_five_consecutive_frames -q
```

Expected: `1 passed`.

### Task 3: Add Neural Building Blocks

**Files:**
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/modules.py`
- Test: `sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py`

- [ ] **Step 1: Write shape tests**

Add tests for the mask and module shapes:

```python
import torch
from deltaflow.modules import build_horizon_causal_mask, StepActionPooler, SceneActionResampler, FlowDiT

def test_horizon_causal_mask_groups_slots_by_horizon():
    mask = build_horizon_causal_mask(active_horizon=3, num_slots=2, device=torch.device("cpu"))
    assert mask.shape == (6, 6)
    assert bool(mask[0, 4]) is True
    assert bool(mask[4, 0]) is False
    assert bool(mask[2, 3]) is False

def test_flow_modules_preserve_delta_shapes():
    batch, horizon, slots, dim = 2, 4, 1, 832
    actions = torch.randn(batch, horizon, 3, dim)
    scene = torch.randn(batch, 16, dim)
    noisy = torch.randn(batch, 2, slots, dim)
    tau = torch.rand(batch)
    pooler = StepActionPooler(dim, 13, depth=1)
    step, plan = pooler(actions)
    resampler = SceneActionResampler(model_dim=dim, num_heads=13, depth=1, queries_per_horizon=4)
    cond = resampler(scene, actions.reshape(batch, 12, dim), step, plan)
    model = FlowDiT(residual_dim=dim, model_dim=dim, num_heads=13, depth=1, max_horizon=horizon, max_slots=slots)
    out = model(noisy, tau, cond, step, plan, active_horizon=2)
    assert cond.shape == (batch, 16, dim)
    assert out.shape == noisy.shape
```

- [ ] **Step 2: Implement modules**

Implement:

```text
TimestepEmbedder
AdaLayerNorm
GatedSelfAttentionBlock
StepActionPooler
SceneActionResampler
FlowDiTBlock
FlowDiT
build_horizon_causal_mask
```

Use `nn.MultiheadAttention(batch_first=True)` for self-attention and cross-attention. Use `True` values in `attn_mask` for disallowed attention positions. Zero-initialize the final velocity projection.

- [ ] **Step 3: Run module tests**

Run:

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py::test_horizon_causal_mask_groups_slots_by_horizon sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py::test_flow_modules_preserve_delta_shapes -q
```

Expected: `2 passed`.

### Task 4: Add DeltaWorldFlow Network

**Files:**
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/model.py`
- Test: `sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py`

- [ ] **Step 1: Write lightweight network tests with fake DeltaTok**

Add a fake frozen DeltaTok test double and assert flow target shapes:

```python
import torch
import torch.nn as nn
from deltaflow.model import DeltaWorldFlow

class FakeBackbone(nn.Module):
    patch_size = 16
    def encode(self, frames):
        b, t = frames.shape[:2]
        return torch.randn(b, t, 4, 832, device=frames.device)
    def decode(self, latent):
        b = latent.shape[0]
        return torch.zeros(b, 3, 32, 32, device=latent.device)

class FakeActionTokenizer(nn.Module):
    def forward(self, action):
        b = action.shape[0]
        return torch.randn(b, 3, 832, device=action.device)

class FakeDeltaTok(nn.Module):
    num_delta_tokens = 1
    hidden_size = 832
    def __init__(self):
        super().__init__()
        self.backbone = FakeBackbone()
        self.action_tokenizer = FakeActionTokenizer()
    def encode(self, previous, current, action):
        return current[:, :1] - previous[:, :1]
    def decode(self, residual, previous):
        return previous + residual.mean(dim=1, keepdim=True)

def test_deltaworld_flow_with_fake_tokenizer_shapes():
    model = DeltaWorldFlow(delta_tok=FakeDeltaTok(), flow_depth=1, resampler_depth=1, queries_per_horizon=4)
    frames = torch.randn(2, 5, 3, 32, 32)
    actions = torch.randn(2, 4, 3)
    out = model(frames, actions, active_horizon=2)
    assert out["target_z"].shape == (2, 2, 1, 832)
    assert out["pred_v"].shape == (2, 2, 1, 832)
```

- [ ] **Step 2: Implement network**

Implement `DeltaWorldFlow` with optional constructor injection `delta_tok`. If `delta_tok` is `None`, instantiate it from a jsonargparse config object. Freeze it with `requires_grad_(False).eval()`. Forward returns `pred_v`, `target_v`, `target_z`, `noise`, `x_tau`, `tau`, `active_horizon`, and conditioning tensors.

- [ ] **Step 3: Add sampler and rollout helpers**

Implement:

```python
@torch.no_grad()
def sample(self, initial_latent, actions, num_steps=20, generator=None): ...

@torch.no_grad()
def rollout_latents(self, initial_latent, sampled_z): ...
```

The sampler integrates from `tau=0` to `tau=1` and returns `[B,4,K,832]`.

- [ ] **Step 4: Run network tests**

Run:

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py::test_deltaworld_flow_with_fake_tokenizer_shapes -q
```

Expected: `1 passed`.

### Task 5: Add Lightning Training Module

**Files:**
- Create: `sources/deltatok-nuscenes/deltaworld-flow/deltaflow/training.py`
- Test: `sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py`

- [ ] **Step 1: Write schedule test**

Add:

```python
from deltaflow.training import HorizonSchedule, resolve_horizon_schedule

def test_horizon_schedule_resolves_by_global_step():
    schedule = [
        HorizonSchedule(until_step=10, active_horizon=1, loss_weights=[1.0]),
        HorizonSchedule(until_step=20, active_horizon=2, loss_weights=[1.0, 0.7]),
        HorizonSchedule(until_step=None, active_horizon=4, loss_weights=[1.0, 0.7, 0.5, 0.3]),
    ]
    assert resolve_horizon_schedule(schedule, 0).active_horizon == 1
    assert resolve_horizon_schedule(schedule, 10).active_horizon == 2
    assert resolve_horizon_schedule(schedule, 30).active_horizon == 4
```

- [ ] **Step 2: Implement Lightning module**

Implement `DeltaWorldFlowModule` with AdamW, warmup LambdaLR, horizon-weighted MSE, teacher-forced validation metrics, sampled z MSE diagnostics, RGB rollout logging, and trainable-only checkpoint saving.

- [ ] **Step 3: Run training helper tests**

Run:

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/tests/test_deltaflow_shapes.py::test_horizon_schedule_resolves_by_global_step -q
```

Expected: `1 passed`.

### Task 6: Add Configs And README

**Files:**
- Create: `sources/deltatok-nuscenes/deltaworld-flow/configs/deltaflow_nuscenes_256.yaml`
- Create: `sources/deltatok-nuscenes/deltaworld-flow/configs/deltaflow_nuscenes_512.yaml`
- Create: `sources/deltatok-nuscenes/deltaworld-flow/README.md`

- [ ] **Step 1: Create 256 config**

Config points to `deltaflow.training.DeltaWorldFlowModule`, `deltaflow.model.DeltaWorldFlow`, `datasets.module.DataModule`, and `deltaflow.datasets.NuScenesSequenceTrain/Val`. It sets `future_action_len=4`, `max_pred_horizon=4`, `num_sampling_steps=20`, and the default horizon schedule.

- [ ] **Step 2: Create 512 config**

Copy the same structure with `img_size: 512`, `frame_size: 512`, and a smaller batch size.

- [ ] **Step 3: Create README launch commands**

Document:

```bash
cd /data/wlh/DeltaWorld/deltaworld-flow
WANDB_MODE=disabled python main.py fit -c configs/deltaflow_nuscenes_256.yaml --trainer.fast_dev_run=1
WANDB_MODE=offline python main.py fit -c configs/deltaflow_nuscenes_256.yaml --trainer.devices=2 --trainer.strategy=ddp
```

Also document that `--model.network.delta_tok.ckpt_path=/path/to/deltatok.ckpt` or the YAML value must point to the trained DeltaTok checkpoint.

### Task 7: Verify And Commit

**Files:**
- Verify all files under `sources/deltatok-nuscenes/deltaworld-flow/`

- [ ] **Step 1: Run compile check**

Run:

```powershell
python -m compileall sources/deltatok-nuscenes/deltaworld-flow
```

Expected: no syntax errors.

- [ ] **Step 2: Run shape tests**

Run:

```powershell
python -m pytest sources/deltatok-nuscenes/deltaworld-flow/tests -q
```

Expected: all tests pass or the environment reports a missing optional test dependency that is documented in the final response.

- [ ] **Step 3: Inspect changed files**

Run:

```powershell
git -C C:\Users\86187 status --short -- Desktop/2/sources/deltatok-nuscenes/deltaworld-flow
```

Expected: only intended `deltaworld-flow` files are modified or untracked.

- [ ] **Step 4: Commit implementation**

Run:

```powershell
git -C C:\Users\86187 add -- Desktop/2/sources/deltatok-nuscenes/deltaworld-flow
git -C C:\Users\86187 commit -m "feat: add deltaworld flow training"
```

Expected: one commit containing the flow project implementation.

---

## Self-Review

- Spec coverage: data contract, online target extraction, frozen DeltaTok, raw residual flow, action two-route conditioning, action-first scene-after resampler, horizon grouped causal mask, common rectified-flow direction, curriculum slicing, validation metrics, sampled z diagnostics, recursive decoder rollout, configs, and local project layout are covered by Tasks 2-6.
- Placeholder scan: no placeholder markers or undefined future work remains in this plan.
- Type consistency: model tensors use `frames [B,5,3,H,W]`, `actions [B,4,3]`, `target_z [B,active_h,K,832]`, `C_i [B,64,832]`, and velocity `[B,active_h,K,832]` throughout.
