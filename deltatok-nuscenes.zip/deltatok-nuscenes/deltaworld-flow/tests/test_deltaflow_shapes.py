from __future__ import annotations

import sys
from pathlib import Path

import pytest


FLOW_ROOT = Path(__file__).resolve().parents[1]
PARENT_ROOT = FLOW_ROOT.parent
for path in (str(PARENT_ROOT), str(FLOW_ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

from deltaflow.windowing import build_consecutive_windows


def test_build_consecutive_windows_requires_five_consecutive_frames():
    rows = [object() for _ in range(6)]
    frame_ids = [10, 11, 12, 13, 14, 16]
    windows = build_consecutive_windows(rows, frame_ids, length=5)
    assert windows == [(rows[0], rows[1], rows[2], rows[3], rows[4])]


def test_horizon_causal_mask_groups_slots_by_horizon():
    torch = pytest.importorskip("torch")
    from deltaflow.modules import build_horizon_causal_mask

    mask = build_horizon_causal_mask(
        active_horizon=3, num_slots=2, device=torch.device("cpu")
    )
    assert mask.shape == (6, 6)
    assert bool(mask[0, 4]) is True
    assert bool(mask[4, 0]) is False
    assert bool(mask[2, 3]) is False


def test_flow_modules_preserve_delta_shapes():
    torch = pytest.importorskip("torch")
    from deltaflow.modules import FlowDiT, SceneActionResampler, StepActionPooler

    batch, horizon, slots, dim = 2, 4, 1, 832
    actions = torch.randn(batch, horizon, 3, dim)
    scene = torch.randn(batch, 16, dim)
    noisy = torch.randn(batch, 2, slots, dim)
    tau = torch.rand(batch)
    pooler = StepActionPooler(dim, 13, depth=1)
    step, plan = pooler(actions)
    resampler = SceneActionResampler(
        model_dim=dim, num_heads=13, depth=1, queries_per_horizon=4
    )
    cond = resampler(scene, actions.reshape(batch, 12, dim), step, plan)
    model = FlowDiT(
        residual_dim=dim,
        model_dim=dim,
        num_heads=13,
        depth=1,
        max_horizon=horizon,
        max_slots=slots,
    )
    out = model(noisy, tau, cond, step, plan, active_horizon=2)
    assert cond.shape == (batch, 16, dim)
    assert out.shape == noisy.shape


def test_deltaworld_flow_with_fake_tokenizer_shapes():
    torch = pytest.importorskip("torch")
    nn = torch.nn
    from deltaflow.model import DeltaWorldFlow

    class FakeBackbone(nn.Module):
        patch_size = 16

        def encode(self, frames):
            batch_size, num_frames = frames.shape[:2]
            values = torch.randn(batch_size, num_frames, 4, 832, device=frames.device)
            return values.to(frames.dtype)

        def decode(self, latent):
            batch_size = latent.shape[0]
            return torch.zeros(
                batch_size, 3, 32, 32, device=latent.device, dtype=latent.dtype
            )

    class FakeActionTokenizer(nn.Module):
        def forward(self, action):
            batch_size = action.shape[0]
            return torch.randn(
                batch_size, 3, 832, device=action.device, dtype=action.dtype
            )

    class FakeDeltaTok(nn.Module):
        num_delta_tokens = 1
        hidden_size = 832

        def __init__(self):
            super().__init__()
            self.backbone = FakeBackbone()
            self.action_tokenizer = FakeActionTokenizer()

        def encode(self, previous, current, action):
            return current[:, :1] - previous[:, :1]

        def decode(self, residual, previous):
            return previous + residual.mean(dim=1, keepdim=True)

    model = DeltaWorldFlow(
        delta_tok=FakeDeltaTok(),
        flow_depth=1,
        resampler_depth=1,
        action_pool_depth=1,
        queries_per_horizon=4,
    )
    frames = torch.randn(2, 5, 3, 32, 32)
    actions = torch.randn(2, 4, 3)
    out = model(frames, actions, active_horizon=2)
    assert out["target_z"].shape == (2, 2, 1, 832)
    assert out["pred_v"].shape == (2, 2, 1, 832)


def test_horizon_schedule_resolves_by_global_step():
    pytest.importorskip("torch")
    pytest.importorskip("lightning")
    from deltaflow.training import HorizonSchedule, resolve_horizon_schedule

    schedule = [
        HorizonSchedule(until_step=10, active_horizon=1, loss_weights=[1.0]),
        HorizonSchedule(until_step=20, active_horizon=2, loss_weights=[1.0, 0.7]),
        HorizonSchedule(
            until_step=None,
            active_horizon=4,
            loss_weights=[1.0, 0.7, 0.5, 0.3],
        ),
    ]
    assert resolve_horizon_schedule(schedule, 0).active_horizon == 1
    assert resolve_horizon_schedule(schedule, 10).active_horizon == 2
    assert resolve_horizon_schedule(schedule, 30).active_horizon == 4
