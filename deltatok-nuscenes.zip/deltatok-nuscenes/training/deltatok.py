from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F

from training.base import (
    Base,
    create_plot_from_rows,
    feats_to_pca,
    to_numpy_img,
)


def masked_flow_loss(
    pred_flow: torch.Tensor,
    target_flow: torch.Tensor,
    mask: torch.Tensor,
    beta: float = 1.0,
) -> torch.Tensor:
    loss_map = F.smooth_l1_loss(
        pred_flow.float(), target_flow.float(), reduction="none", beta=beta
    ).mean(dim=1)
    mask = mask.bool()
    if mask.ndim != 3:
        raise ValueError(f"Expected flow mask [B,H,W], got {tuple(mask.shape)}")
    valid = mask.float()
    denom = valid.sum().clamp_min(1.0)
    return (loss_map * valid).sum() / denom


class DeltaTok(Base):
    def __init__(
        self,
        network: torch.nn.Module,
        lr: float = 1e-3,
        weight_decay: float = 1e-2,
        loss_fn: str = "smooth_l1",
        loss_beta: float = 1e-1,
        lambda_motion: float = 1.0,
        lambda_optical: float = 1.0,
        compatibility_head_paths: dict[str, str] | None = None,
        lr_warmup_steps: int = 5000,
        num_plots: int = 4,
        ckpt_path: str | None = None,
        use_compile: bool | None = None,
    ) -> None:
        super().__init__(
            **{
                k: v
                for k, v in locals().items()
                if k not in ("self", "__class__")
            }
        )

    def training_step(
        self, batch: tuple[torch.Tensor, ...], batch_idx: int
    ) -> torch.Tensor:
        frames, action, optical_flow, optical_mask = batch
        outputs = self.network(frames, action)
        latent_loss = self.criterion(
            outputs["pred_latent"].float(), outputs["target_latent"].float()
        ).mean()
        motion_loss = F.smooth_l1_loss(
            outputs["motion_pred"].float(), outputs["motion_target"].float()
        )
        optical_loss = masked_flow_loss(
            outputs["optical_pred"], optical_flow, optical_mask
        )
        total_loss = (
            latent_loss
            + self.lambda_motion * motion_loss
            + self.lambda_optical * optical_loss
        )
        self._log_scalar("latent", latent_loss, "train_losses", prog_bar=True)
        self._log_scalar("motion", motion_loss, "train_losses", prog_bar=True)
        self._log_scalar("optical", optical_loss, "train_losses", prog_bar=True)
        self._log_scalar("total", total_loss, "train_losses")
        return total_loss

    def validation_step(
        self, batch: tuple[torch.Tensor, ...], batch_idx: int, dataloader_idx: int = 0
    ) -> torch.Tensor:
        frames, action, optical_flow, optical_mask, sample_idx = batch
        outputs = self.network(frames, action)
        latent_loss = self.criterion(
            outputs["pred_latent"].float(), outputs["target_latent"].float()
        ).mean()
        motion_loss = F.smooth_l1_loss(
            outputs["motion_pred"].float(), outputs["motion_target"].float()
        )
        optical_loss = masked_flow_loss(
            outputs["optical_pred"], optical_flow, optical_mask
        )
        total_loss = (
            latent_loss
            + self.lambda_motion * motion_loss
            + self.lambda_optical * optical_loss
        )
        dataset_name = self.trainer.val_dataloaders[dataloader_idx].dataset_name
        prefix = f"val_{dataset_name}"
        self._log_scalar(f"{prefix}_latent", latent_loss, "losses")
        self._log_scalar(f"{prefix}_motion", motion_loss, "losses")
        self._log_scalar(f"{prefix}_optical", optical_loss, "losses")
        self._log_scalar(f"{prefix}_total", total_loss, "losses", prog_bar=True)
        self.val_loss_sum[dataset_name] += total_loss.item()
        self.val_loss_count[dataset_name] += 1

        self._plot_selected_samples(
            frames=frames,
            outputs=outputs,
            sample_idx=sample_idx,
            prefix=prefix,
        )
        return total_loss

    def _plot_selected_samples(
        self,
        frames: torch.Tensor,
        outputs: dict[str, torch.Tensor],
        sample_idx: torch.Tensor,
        prefix: str,
    ) -> None:
        selected = set()
        for row, idx in enumerate(sample_idx.tolist()):
            if idx >= self.num_plots or idx in selected:
                continue
            selected.add(idx)
            sample_outputs = {
                key: value[row : row + 1] for key, value in outputs.items()
            }
            self._plot_sample(frames[row], sample_outputs, f"{prefix}_s{idx}")

    def _plot_sample(
        self,
        frames: torch.Tensor,
        outputs: dict[str, torch.Tensor],
        prefix: str,
    ) -> None:
        previous = to_numpy_img(frames[0])
        current = to_numpy_img(frames[1])
        pred_latent = outputs["pred_latent"][:1]
        target_latent = outputs["target_latent"][:1]
        with torch.no_grad():
            pred_rgb = self.network.backbone.decode(pred_latent)[0]
            target_rgb = self.network.backbone.decode(target_latent)[0]
        self._log_plot_img(
            f"{prefix}_rgb",
            create_plot_from_rows(
                [
                    [previous],
                    [current],
                    [to_numpy_img(target_rgb)],
                    [to_numpy_img(pred_rgb)],
                ],
                1,
            ),
        )

        patch_size = self.network.backbone.patch_size
        grid = frames.shape[-1] // patch_size
        target_pca, pred_pca = feats_to_pca(
            target_latent[0:1], pred_latent[0:1], grid, grid
        )
        self._log_plot_img(
            f"{prefix}_latent_pca",
            create_plot_from_rows(
                [[previous], target_pca, pred_pca],
                1,
            ),
        )

        self._plot_compatibility_heads(
            prefix, target_latent, pred_latent, frames.shape[-2:]
        )

    def _plot_compatibility_heads(
        self,
        prefix: str,
        target_latent: torch.Tensor,
        pred_latent: torch.Tensor,
        frame_size: tuple[int, int],
    ) -> None:
        for name in ("vspw", "cityscapes", "kitti"):
            if name not in self.task_heads:
                continue
            head = self.task_heads[name]
            target = self._apply_head(target_latent.unsqueeze(1), head, (1, 1, 3, *frame_size))[0, 0]
            pred = self._apply_head(pred_latent.unsqueeze(1), head, (1, 1, 3, *frame_size))[0, 0]
            if name in ("vspw", "cityscapes"):
                palette = np.random.default_rng(0).integers(
                    0, 256, (256, 3), dtype=np.uint8
                ) / 255.0
                target_img = palette[target.argmax(0).cpu().numpy()]
                pred_img = palette[pred.argmax(0).cpu().numpy()]
            else:
                target_np = target.squeeze(0).detach().cpu().numpy()
                pred_np = pred.squeeze(0).detach().cpu().numpy()
                vmax = max(float(target_np.max()), float(pred_np.max()), 1e-6)
                cmap = __import__("matplotlib").colormaps["viridis"]
                target_img = cmap(target_np / vmax)[..., :3]
                pred_img = cmap(pred_np / vmax)[..., :3]
            self._log_plot_img(
                f"{prefix}_{name}",
                create_plot_from_rows([[target_img], [pred_img]], 1),
            )

    def _plot_feats(self, sample: dict) -> None:
        raise NotImplementedError("Pairwise DeltaTok uses _plot_sample directly")

    def _plot_task(self, sample: dict, task_head: torch.nn.Module) -> None:
        raise NotImplementedError("Pairwise DeltaTok uses _plot_sample directly")

    def _plot_rgb(self, sample: dict) -> None:
        raise NotImplementedError("Pairwise DeltaTok uses _plot_sample directly")
