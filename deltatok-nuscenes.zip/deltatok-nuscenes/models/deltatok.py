from __future__ import annotations

from itertools import chain
from math import isqrt

import torch
import torch.nn as nn
from transformers import AutoConfig
from transformers.models.dinov3_vit.modeling_dinov3_vit import (
    DINOv3ViTLayer,
    DINOv3ViTRopePositionEmbedding,
)

from models.action_tokenizer import ActionTokenizer
from models.gated_attn import enable_gated_attn
from models.qk_norm import enable_dinov3_qk_norm
from training.base import load_sd


class DeltaTok(nn.Module):
    """Pairwise DeltaTok transition model over frozen DINO-Tok latents."""

    def __init__(
        self,
        backbone: nn.Module,
        num_hidden_layers: int = 12,
        num_delta_tokens: int = 1,
        layer_scale_init: float = 1e-5,
        use_qk_norm: bool = True,
        use_gated_attn: bool = True,
        use_swiglu: bool = True,
        use_rope_aug: bool = True,
        action_mean: tuple[float, float, float] = (2.5142802, -0.0177921, -0.04997),
        action_std: tuple[float, float, float] = (1.8113501, 0.0518354, 2.4821163),
        action_clip: float = 3.0,
        motion_hidden_size: int = 256,
        template_path: str = "facebook/dinov3-vitb16-pretrain-lvd1689m",
        ckpt_path: str | None = None,
    ) -> None:
        super().__init__()
        if num_delta_tokens < 1:
            raise ValueError("num_delta_tokens must be at least 1")
        self.backbone = backbone.requires_grad_(False).eval()
        self.hidden_size = 832
        self.num_heads = 13
        self.head_dim = 64
        self.num_delta_tokens = num_delta_tokens

        cfg = AutoConfig.from_pretrained(template_path)
        cfg._attn_implementation = "sdpa"
        cfg.hidden_size = self.hidden_size
        cfg.num_attention_heads = self.num_heads
        cfg.patch_size = self.backbone.patch_size
        cfg.num_register_tokens = 0
        if use_swiglu:
            cfg.use_gated_mlp = True
            cfg.intermediate_size = max(1, (2 * int(cfg.intermediate_size)) // 3)
            cfg.hidden_act = "silu"

        self.rope_embeddings = DINOv3ViTRopePositionEmbedding(cfg)
        if not use_rope_aug:
            self.rope_embeddings.eval()

        self.delta_queries = nn.Parameter(
            torch.zeros(num_delta_tokens, self.hidden_size)
        )
        self.segment_embedding = nn.Parameter(torch.zeros(4, self.hidden_size))
        self.residual_embedding = nn.Parameter(torch.zeros(self.hidden_size))
        nn.init.trunc_normal_(self.delta_queries, std=cfg.initializer_range)
        nn.init.trunc_normal_(self.segment_embedding, std=cfg.initializer_range)
        nn.init.trunc_normal_(self.residual_embedding, std=cfg.initializer_range)

        self.action_tokenizer = ActionTokenizer(
            hidden_size=self.hidden_size,
            action_mean=action_mean,
            action_std=action_std,
            clip_value=action_clip,
        )
        self.encoder_blocks = nn.ModuleList(
            [DINOv3ViTLayer(cfg) for _ in range(num_hidden_layers)]
        )
        self.decoder_blocks = nn.ModuleList(
            [DINOv3ViTLayer(cfg) for _ in range(num_hidden_layers)]
        )
        for block in chain(self.encoder_blocks, self.decoder_blocks):
            for module in block.modules():
                if isinstance(module, nn.Linear):
                    nn.init.trunc_normal_(module.weight, std=cfg.initializer_range)
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)
            block.layer_scale1.lambda1.data.fill_(layer_scale_init)
            block.layer_scale2.lambda1.data.fill_(layer_scale_init)
            if use_qk_norm:
                enable_dinov3_qk_norm(block)
            if use_gated_attn:
                enable_gated_attn(block)

        self.encoder_norm = nn.LayerNorm(self.hidden_size, cfg.layer_norm_eps)
        self.motion_head = nn.Sequential(
            nn.LayerNorm(self.hidden_size),
            nn.Linear(self.hidden_size, motion_hidden_size),
            nn.SiLU(),
            nn.Linear(motion_hidden_size, 3),
        )

        if ckpt_path:
            load_sd(self, torch.load(ckpt_path, map_location="cpu"))

    def _rope(self, token_count: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
        grid = isqrt(token_count)
        if grid * grid != token_count:
            raise ValueError(f"Expected square latent grid, got {token_count} tokens")
        dummy = torch.zeros(
            1,
            3,
            grid * self.backbone.patch_size,
            grid * self.backbone.patch_size,
            device=device,
        )
        return self.rope_embeddings(dummy)

    def encode(
        self,
        previous: torch.Tensor,
        current: torch.Tensor,
        action: torch.Tensor,
    ) -> torch.Tensor:
        batch_size, token_count, _ = previous.shape
        rope = self._rope(token_count, previous.device)
        queries = self.delta_queries.unsqueeze(0).expand(batch_size, -1, -1)
        queries = queries + self.segment_embedding[0]
        actions = self.action_tokenizer(action) + self.segment_embedding[1]
        hidden = torch.cat(
            (
                queries,
                actions,
                previous + self.segment_embedding[2],
                current + self.segment_embedding[3],
            ),
            dim=1,
        )
        position_embeddings = (
            torch.cat((rope[0], rope[0]), dim=0),
            torch.cat((rope[1], rope[1]), dim=0),
        )
        for block in self.encoder_blocks:
            hidden = block(hidden, position_embeddings=position_embeddings)
        return self.encoder_norm(hidden[:, : self.num_delta_tokens])

    def decode(self, residual: torch.Tensor, previous: torch.Tensor) -> torch.Tensor:
        token_count = previous.shape[1]
        rope = self._rope(token_count, previous.device)
        hidden = torch.cat(
            (
                residual + self.residual_embedding,
                previous + self.segment_embedding[2],
            ),
            dim=1,
        )
        for block in self.decoder_blocks:
            hidden = block(hidden, position_embeddings=rope)
        return hidden[:, self.num_delta_tokens :]

    def forward(self, frames: torch.Tensor, action: torch.Tensor) -> dict[str, torch.Tensor]:
        if frames.ndim != 5 or frames.shape[1] != 2:
            raise ValueError(f"Expected frames [B,2,C,H,W], got {tuple(frames.shape)}")
        if action.shape != (frames.shape[0], 3):
            raise ValueError(f"Expected action [B,3], got {tuple(action.shape)}")
        with torch.no_grad():
            latents = self.backbone.encode(frames)
        previous, target = latents[:, 0], latents[:, 1]
        residual = self.encode(previous, target, action)
        prediction = self.decode(residual, previous)
        motion_prediction = self.motion_head(residual.mean(dim=1))
        return {
            "pred_latent": prediction,
            "target_latent": target.detach(),
            "previous_latent": previous.detach(),
            "residual_tokens": residual,
            "motion_pred": motion_prediction,
            "motion_target": self.action_tokenizer.normalize(action).detach(),
        }
