from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class _ProbeBlock(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        mlp_ratio: float = 4.0,
    ) -> None:
        super().__init__()
        self.query_norm = nn.LayerNorm(hidden_size)
        self.context_norm = nn.LayerNorm(hidden_size)
        self.cross_attn = nn.MultiheadAttention(
            hidden_size, num_heads, batch_first=True
        )
        self.mlp_norm = nn.LayerNorm(hidden_size)
        hidden = max(1, int(hidden_size * mlp_ratio))
        self.mlp = nn.Sequential(
            nn.Linear(hidden_size, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden_size),
        )

    def forward(self, query: torch.Tensor, context: torch.Tensor) -> torch.Tensor:
        attn, _ = self.cross_attn(
            self.query_norm(query),
            self.context_norm(context),
            self.context_norm(context),
            need_weights=False,
        )
        query = query + attn
        query = query + self.mlp(self.mlp_norm(query))
        return query


class ResidualFlowProbe(nn.Module):
    """Spatial optical-flow probe driven by DeltaTok residual tokens."""

    def __init__(
        self,
        hidden_size: int = 832,
        query_size: int = 32,
        output_size: int | tuple[int, int] = 128,
        num_heads: int = 13,
        depth: int = 2,
        decoder_hidden_size: int = 256,
        mlp_ratio: float = 4.0,
    ) -> None:
        super().__init__()
        if decoder_hidden_size < 4 or decoder_hidden_size % 4 != 0:
            raise ValueError("decoder_hidden_size must be divisible by 4")
        self.hidden_size = hidden_size
        self.query_size = query_size
        self.output_size = (output_size, output_size) if isinstance(output_size, int) else tuple(output_size)
        self.num_queries = query_size * query_size
        self.query_tokens = nn.Parameter(torch.zeros(1, self.num_queries, hidden_size))
        nn.init.trunc_normal_(self.query_tokens, std=0.02)

        self.blocks = nn.ModuleList(
            [_ProbeBlock(hidden_size, num_heads, mlp_ratio=mlp_ratio) for _ in range(depth)]
        )
        self.pre_decoder = nn.Sequential(
            nn.LayerNorm(hidden_size),
            nn.Linear(hidden_size, decoder_hidden_size),
            nn.SiLU(),
        )
        self.decoder = nn.Sequential(
            nn.Conv2d(decoder_hidden_size, decoder_hidden_size, kernel_size=3, padding=1),
            nn.SiLU(),
            nn.ConvTranspose2d(
                decoder_hidden_size, decoder_hidden_size // 2, kernel_size=4, stride=2, padding=1
            ),
            nn.SiLU(),
            nn.ConvTranspose2d(
                decoder_hidden_size // 2,
                decoder_hidden_size // 4,
                kernel_size=4,
                stride=2,
                padding=1,
            ),
            nn.SiLU(),
            nn.Conv2d(decoder_hidden_size // 4, 2, kernel_size=3, padding=1),
        )

    def forward(self, residual_tokens: torch.Tensor) -> torch.Tensor:
        if residual_tokens.ndim != 3:
            raise ValueError(
                f"Expected residual tokens [B,K,C], got {tuple(residual_tokens.shape)}"
            )
        batch_size = residual_tokens.shape[0]
        query = self.query_tokens.expand(batch_size, -1, -1)
        for block in self.blocks:
            query = block(query, residual_tokens)
        query = self.pre_decoder(query)
        query = query.transpose(1, 2).reshape(
            batch_size, -1, self.query_size, self.query_size
        )
        flow = self.decoder(query)
        if flow.shape[-2:] != self.output_size:
            flow = F.interpolate(
                flow, size=self.output_size, mode="bilinear", align_corners=False
            )
        return flow
