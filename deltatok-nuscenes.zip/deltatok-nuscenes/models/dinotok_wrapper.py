from __future__ import annotations

import sys
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from transformers import AutoConfig, AutoModel


_VENDOR_ROOT = Path(__file__).resolve().parents[1] / "third_party" / "DINO-Tok"
if str(_VENDOR_ROOT) not in sys.path:
    sys.path.insert(0, str(_VENDOR_ROOT))

from tokenizer.dinotok.models.tokenizer.dinotok import DINOTOK, dinov3_f16c768


class DINOtok(nn.Module):
    """Frozen DINOv3 encoder plus the DINO-Tok AE decoder."""

    def __init__(
        self,
        backbone_name: str = "facebook/dinov3-vitb16-pretrain-lvd1689m",
        decoder_ckpt: str | None = None,
        img_size: int = 256,
        dino_shallow_layer: int = 5,
    ) -> None:
        super().__init__()
        if decoder_ckpt is None:
            raise ValueError("decoder_ckpt is required for the DINO-Tok AE")
        self.img_size = img_size
        self.patch_size = 16
        self.dino_hidden_size = 768
        self.hidden_size = 832
        self.num_heads = 13
        self.initializer_range = 0.02
        self.backbone = AutoModel.from_pretrained(backbone_name)
        self.backbone.eval().requires_grad_(False)
        config = AutoConfig.from_pretrained(backbone_name)
        self.num_prefix_tokens = int(config.num_register_tokens) + 1
        self.dino_shallow_layer = dino_shallow_layer

        decoder_cfg = dinov3_f16c768(
            "dinov3-f16c768-in-1.0",
            None,
            0,
            img_size,
            img_size,
            False,
            None,
        )
        self.decoder = DINOTOK(decoder_cfg)
        self._load_decoder(decoder_ckpt)
        self.decoder.eval().requires_grad_(False)

        self.register_buffer(
            "img_mean",
            torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1),
            persistent=False,
        )
        self.register_buffer(
            "img_std",
            torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1),
            persistent=False,
        )

    def _load_decoder(self, checkpoint_path: str) -> None:
        state = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        if isinstance(state, dict) and "model" in state:
            state = state["model"]
        if not isinstance(state, dict):
            raise TypeError(f"Unsupported DINO-Tok checkpoint format: {checkpoint_path}")
        cleaned = {}
        for key, value in state.items():
            for prefix in ("module.", "model."):
                if key.startswith(prefix):
                    key = key[len(prefix) :]
            cleaned[key] = value
        missing, unexpected = self.decoder.load_state_dict(cleaned, strict=False)
        if missing:
            raise RuntimeError(
                f"DINO-Tok decoder checkpoint is missing {len(missing)} keys; first keys: {missing[:5]}"
            )
        if unexpected:
            raise RuntimeError(
                f"DINO-Tok decoder checkpoint has {len(unexpected)} unexpected keys; first keys: {unexpected[:5]}"
            )

    def _prepare_input(self, frames: torch.Tensor) -> torch.Tensor:
        frames = frames.float()
        if frames.numel() and frames.detach().amax() > 1.5:
            frames = frames / 255.0
        if frames.shape[-2:] != (self.img_size, self.img_size):
            frames = F.interpolate(
                frames,
                size=(self.img_size, self.img_size),
                mode="bicubic",
                align_corners=False,
            )
        return (frames.clamp(0.0, 1.0) - self.img_mean.to(frames)) / self.img_std.to(
            frames
        )

    @torch.no_grad()
    def encode(self, frames: torch.Tensor) -> torch.Tensor:
        batch_size, num_frames = frames.shape[:2]
        images = self._prepare_input(frames.flatten(0, 1))
        outputs = self.backbone(images, output_hidden_states=True)
        hidden_states = outputs.hidden_states
        if hidden_states is None:
            raise RuntimeError("DINOv3 backbone did not return hidden states")
        shallow = hidden_states[self.dino_shallow_layer]
        deep = hidden_states[-1]
        shallow = self.backbone.norm(shallow)
        deep = self.backbone.norm(deep)
        shallow = shallow[:, self.num_prefix_tokens :]
        deep = deep[:, self.num_prefix_tokens :]
        grid = self.img_size // self.patch_size
        shallow = rearrange(shallow, "b (h w) c -> b c h w", h=grid, w=grid)
        deep = rearrange(deep, "b (h w) c -> b c h w", h=grid, w=grid)
        fused = self.decoder.encode((shallow, deep))[0]
        fused = rearrange(fused, "b c h w -> b (h w) c")
        return fused.reshape(batch_size, num_frames, fused.shape[1], fused.shape[2])

    @torch.no_grad()
    def decode(self, latent: torch.Tensor) -> torch.Tensor:
        original_shape = latent.shape
        if latent.ndim == 4:
            latent = latent.flatten(0, 1)
        elif latent.ndim == 3:
            pass
        else:
            raise ValueError(f"Expected latent [B,N,C] or [B,T,N,C], got {original_shape}")
        tokens = latent.shape[-2]
        grid = int(tokens**0.5)
        if grid * grid != tokens:
            raise ValueError(f"Latent token count must be a square, got {tokens}")
        latent_map = rearrange(latent, "b (h w) c -> b c h w", h=grid, w=grid)
        images, _ = self.decoder.decode(latent_map)
        images = images * self.img_std.to(images) + self.img_mean.to(images)
        images = images.clamp(0.0, 1.0)
        if len(original_shape) == 4:
            images = images.reshape(original_shape[0], original_shape[1], *images.shape[1:])
        return images

    def feature_slice(self, latent: torch.Tensor) -> torch.Tensor:
        return latent[..., -self.dino_hidden_size :]

    def train(self, mode: bool = True) -> DINOtok:
        super().train(False)
        return self
