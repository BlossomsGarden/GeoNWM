from __future__ import annotations

from functools import lru_cache
import sys
from pathlib import Path
from typing import Any

import torch


GMFLOW_SOURCE_ROOT = Path(__file__).resolve().parents[1] / "gmflow-main"
GMFLOW_DEFAULT_CKPT_URL = (
    "https://huggingface.co/Anonymous-sub/Rerender/resolve/main/models/"
    "gmflow_sintel-0c07dcb3.pth"
)
GMFLOW_DEFAULT_KWARGS = {
    "feature_channels": 128,
    "num_scales": 1,
    "upsample_factor": 8,
    "num_head": 1,
    "attention_type": "swin",
    "ffn_dim_expansion": 4,
    "num_transformer_layers": 6,
}


def _ensure_gmflow_source_path() -> None:
    source = str(GMFLOW_SOURCE_ROOT)
    if source not in sys.path:
        sys.path.insert(0, source)


def _load_gmflow_cls():
    _ensure_gmflow_source_path()
    from gmflow.gmflow import GMFlow

    return GMFlow


def _load_checkpoint(
    checkpoint_path: str | Path | None,
    checkpoint_url: str,
) -> dict[str, torch.Tensor]:
    if checkpoint_path is None:
        checkpoint = torch.utils.model_zoo.load_url(
            checkpoint_url, map_location="cpu"
        )
    else:
        checkpoint = torch.load(Path(checkpoint_path), map_location="cpu")
    weights = checkpoint.get("model", checkpoint) if isinstance(checkpoint, dict) else checkpoint
    if not isinstance(weights, dict):
        raise TypeError(f"Expected GMFlow checkpoint dict, got {type(weights)!r}")
    return weights


class GMFlowOnlineEstimator:
    def __init__(
        self,
        checkpoint_path: str | Path | None = None,
        checkpoint_url: str = GMFLOW_DEFAULT_CKPT_URL,
        model_kwargs: dict[str, Any] | None = None,
        device: str | torch.device = "cpu",
    ) -> None:
        gmflow_cls = _load_gmflow_cls()
        kwargs = dict(GMFLOW_DEFAULT_KWARGS)
        if model_kwargs:
            kwargs.update(model_kwargs)
        self.device = torch.device(device)
        self.model = gmflow_cls(**kwargs).to(self.device)
        self.model.eval()
        self.model.requires_grad_(False)
        weights = _load_checkpoint(checkpoint_path, checkpoint_url)
        incompatible = self.model.load_state_dict(weights, strict=False)
        if incompatible.missing_keys or incompatible.unexpected_keys:
            raise RuntimeError(
                "GMFlow checkpoint mismatch: "
                f"missing={incompatible.missing_keys}, "
                f"unexpected={incompatible.unexpected_keys}"
            )

    @torch.inference_mode()
    def __call__(self, image0: torch.Tensor, image1: torch.Tensor) -> torch.Tensor:
        if image0.ndim == 3:
            image0 = image0.unsqueeze(0)
        if image1.ndim == 3:
            image1 = image1.unsqueeze(0)
        if image0.ndim != 4 or image1.ndim != 4:
            raise ValueError(
                "Expected images shaped [B,3,H,W] or [3,H,W], "
                f"got {tuple(image0.shape)} and {tuple(image1.shape)}"
            )
        image0 = image0.to(self.device, dtype=torch.float32)
        image1 = image1.to(self.device, dtype=torch.float32)
        outputs = self.model(
            image0,
            image1,
            attn_splits_list=[2],
            corr_radius_list=[-1],
            prop_radius_list=[-1],
        )
        return outputs["flow_preds"][-1]


def estimate_flow_pair(
    image0: torch.Tensor,
    image1: torch.Tensor,
    estimator: GMFlowOnlineEstimator,
) -> torch.Tensor:
    if image0.ndim == 3:
        image0 = image0.unsqueeze(0)
    if image1.ndim == 3:
        image1 = image1.unsqueeze(0)
    flow = estimator(image0, image1)
    if flow.ndim != 4 or flow.shape[1] != 2:
        raise ValueError(f"Expected GMFlow output [B,2,H,W], got {tuple(flow.shape)}")
    return flow


@lru_cache(maxsize=8)
def get_gmflow_estimator(
    checkpoint_path: str | None = None,
    checkpoint_url: str = GMFLOW_DEFAULT_CKPT_URL,
    device: str = "cpu",
) -> GMFlowOnlineEstimator:
    return GMFlowOnlineEstimator(
        checkpoint_path=checkpoint_path,
        checkpoint_url=checkpoint_url,
        device=device,
    )
