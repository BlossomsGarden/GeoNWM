"""Vendored third-party helpers."""
