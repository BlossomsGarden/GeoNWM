# nuScenes Multimodal Decoder Training

This tokenizer folder includes helper scripts for training extra decoders on top of the frozen DINO-Tok-AE latent representation.

## What is trained

- Stage A: train new depth and semantic decoders jointly from frozen DINO-Tok-AE latents.
- Stage B: fine-tune the released DINO-Tok RGB decoder with a small learning rate.
- The DINO-Tok-AE encoder and 832-channel latent interface are kept unchanged.
- Image geometry is 480x832, with a 30x52 token grid for 16x16 patches.
- RGB and semantic labels are directly resized to 480x832. Semantic resize uses nearest-neighbor interpolation.
- Depth supervision loads `npz["depth"]` at 480x832 and does not use the MoGe valid mask.

## Remote paths

The current remote setup uses:

```bash
PROJECT=/data/wlh/DeltaWorld
DINOTOK=$PROJECT/third_party/DINO-Tok
PY=/data/wlh/miniconda3/envs/deltaworld/bin/python

NUSC_ROOT=/data2/DATA/AutoDrive/nuscenes/v1.0-trainval
TRAIN_CSV=/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv
VAL_CSV=/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv
DEPTH_ROOT=/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth
SEM_ROOT=/data4/DATA/wlh/GenDA3/samples_seg
AE_CKPT=/data/wlh/DeltaWorld/model/dinotok/aetok.pt
DINOV3=/data/wlh/DeltaWorld/model/dinov3-vitb16-pretrain-lvd1689m
OUT_ROOT=/data/wlh/DeltaWorld/outputs/dinotok_multimodal
```

Run commands from:

```bash
cd /data/wlh/DeltaWorld/third_party/DINO-Tok
```

## Preview alignment

Before long runs, generate RGB/depth/semantic preview strips and visually check alignment:

```bash
$PY tokenizer/preview_nuscenes_multimodal.py \
  --out-dir $OUT_ROOT/previews_alignment_check \
  --num-samples 16
```

## Stage A: depth and semantic decoders

The latest smoke tests used GPUs 2 and 3. Per-GPU batch sizes 20 and 24 both stayed below 24000 MiB for the DINO-Tok process, so the recommended Stage A batch size is 24:

```bash
export CUDA_VISIBLE_DEVICES=2,3
export OMP_NUM_THREADS=4
OUT=$OUT_ROOT/stage_a_480x832_dptlite_b24_$(date +%Y%m%d_%H%M%S)
mkdir -p $OUT

nohup $PY -m torch.distributed.run --nproc_per_node=2 --master_port=29701 \
  tokenizer/train_stage_a_multimodal.py \
  --out-dir $OUT \
  --batch-size 24 \
  --num-workers 8 \
  --max-steps 100000 \
  --log-every 50 \
  --eval-every 1000 \
  --save-every 2000 \
  --val-samples 256 \
  --semantic-weight 0.7 \
  --precision bf16 \
  > $OUT/stdout.log 2> $OUT/stderr.log &
echo $! > $OUT/launcher.pid
```

Losses:

- Depth: log-Charbonnier + 0.5 multi-scale log-gradient matching + 0.1 metric relative Charbonnier.
- Valid depth range defaults to `0.1 < depth < 120.0` and finite values only.
- Semantic: cross entropy + 0.5 Lovasz, with 10 output classes.
- The default joint objective is depth-focused: `depth_weight=1.0`, `semantic_weight=0.7`.
- Validation reports depth AbsRel/RMSE/log-RMSE, depth delta accuracies, semantic mIoU, pixel accuracy, and per-class IoU.
- Smoke memory on GPUs 2 and 3: batch 20 peaked at 16598 MiB; batch 24 peaked at 19540 MiB.

## Stage B: RGB decoder fine-tuning

The RGB decoder is memory heavier than Stage A. On the shared 48GB GPUs 2 and 3, per-GPU batch size 2 was stable. Batch size 3 can OOM if other jobs are already using memory.

```bash
export CUDA_VISIBLE_DEVICES=2,3
export OMP_NUM_THREADS=4
OUT=$OUT_ROOT/stage_b_rgb_480x832_b2_$(date +%Y%m%d_%H%M%S)
mkdir -p $OUT

nohup $PY -m torch.distributed.run --nproc_per_node=2 --master_port=29703 \
  tokenizer/train_stage_b_rgb_decoder.py \
  --out-dir $OUT \
  --batch-size 2 \
  --num-workers 6 \
  --max-steps 20000 \
  --lr 1.0e-5 \
  --log-every 50 \
  --eval-every 500 \
  --save-every 1000 \
  --val-samples 256 \
  --early-stop-patience 8 \
  --precision bf16 \
  > $OUT/stdout.log 2> $OUT/stderr.log &
echo $! > $OUT/launcher.pid
```

Stage B evaluates PSNR, SSIM, MSE, and L1 on a fixed 256-image validation subset. The best checkpoint is selected from PSNR/SSIM improvement.

## Monitoring

```bash
tail -f $OUT/stdout.log
tail -f $OUT/stderr.log
nvidia-smi
```

Each run writes:

- `args.json`
- `train_log.jsonl`
- `val_log.jsonl`
- `val_subset_<N>.jsonl`
- `previews/`
- `checkpoints/last.pt`
- periodic `checkpoints/step_*.pt`
- Stage B also writes `checkpoints/best.pt`

## Stopping runs

Prefer matching the exact output directory to avoid killing unrelated jobs:

```bash
pkill -TERM -f '/path/to/exact/output_dir_name'
sleep 10
pgrep -af '/path/to/exact/output_dir_name' || true
```

If processes remain after a graceful stop:

```bash
pkill -KILL -f '/path/to/exact/output_dir_name'
```
