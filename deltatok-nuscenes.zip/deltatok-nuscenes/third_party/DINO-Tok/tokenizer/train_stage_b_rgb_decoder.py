from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler


THIS_FILE = Path(__file__).resolve()
DINO_TOK_ROOT = THIS_FILE.parents[1]
if str(DINO_TOK_ROOT) not in sys.path:
    sys.path.insert(0, str(DINO_TOK_ROOT))

from tokenizer.multimodal_decoders.data import (  # noqa: E402
    NuScenesMultimodalDataset,
    sample_fixed_indices,
    write_subset_manifest,
)
from tokenizer.multimodal_decoders.metrics import psnr_from_mse, rgb_mse_sum, ssim_index  # noqa: E402
from tokenizer.multimodal_decoders.rect_dinotok import RectDinoTokAutoEncoder  # noqa: E402
from tokenizer.multimodal_decoders.train_utils import (  # noqa: E402
    all_reduce_tensor,
    append_jsonl,
    barrier,
    cleanup_distributed,
    cosine_scheduler,
    current_gpu_memory,
    init_distributed,
    make_grad_scaler,
    make_labeled_row,
    move_to_device,
    precision_context,
    save_checkpoint,
    seed_everything,
    tensor_to_pil,
)


class RGBDecoderModule(nn.Module):
    def __init__(self, decoder: nn.Module, img_mean: torch.Tensor, img_std: torch.Tensor) -> None:
        super().__init__()
        self.decoder = decoder
        self.register_buffer("img_mean", img_mean.detach().clone(), persistent=False)
        self.register_buffer("img_std", img_std.detach().clone(), persistent=False)

    def forward(self, latent_map: torch.Tensor) -> torch.Tensor:
        image_norm, _ = self.decoder(latent_map)
        return image_norm * self.img_std.to(image_norm) + self.img_mean.to(image_norm)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Stage B: fine-tune DINO-Tok RGB decoder on nuScenes.")
    parser.add_argument("--train-csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv")
    parser.add_argument("--val-csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv")
    parser.add_argument("--nuscenes-root", default="/data2/DATA/AutoDrive/nuscenes/v1.0-trainval")
    parser.add_argument("--backbone-name", default="/data/wlh/DeltaWorld/model/dinov3-vitb16-pretrain-lvd1689m")
    parser.add_argument("--decoder-ckpt", default="/data/wlh/DeltaWorld/model/dinotok/aetok.pt")
    parser.add_argument("--out-dir", default="/data/wlh/DeltaWorld/outputs/dinotok_multimodal/stage_b_rgb")
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--width", type=int, default=832)
    parser.add_argument("--batch-size", type=int, default=2, help="Per-GPU batch size.")
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--max-steps", type=int, default=20000)
    parser.add_argument("--lr", type=float, default=1.0e-5)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--warmup-steps", type=int, default=500)
    parser.add_argument("--min-lr-ratio", type=float, default=0.1)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--l1-weight", type=float, default=1.0)
    parser.add_argument("--mse-weight", type=float, default=0.1)
    parser.add_argument("--ssim-weight", type=float, default=0.1)
    parser.add_argument("--precision", choices=["bf16", "fp16", "fp32"], default="bf16")
    parser.add_argument("--seed", type=int, default=20260826)
    parser.add_argument("--log-every", type=int, default=50)
    parser.add_argument("--eval-every", type=int, default=500)
    parser.add_argument("--save-every", type=int, default=1000)
    parser.add_argument("--val-samples", type=int, default=256)
    parser.add_argument("--early-stop-patience", type=int, default=8)
    parser.add_argument("--min-psnr-delta", type=float, default=0.02)
    parser.add_argument("--min-ssim-delta", type=float, default=1.0e-4)
    parser.add_argument("--resume", default=None)
    return parser.parse_args()


def unwrap_model(model: torch.nn.Module) -> RGBDecoderModule:
    return model.module if isinstance(model, DDP) else model  # type: ignore[return-value]


def make_loaders(args: argparse.Namespace, rank: int, world_size: int, distributed: bool):
    train_dataset = NuScenesMultimodalDataset(
        args.train_csv,
        args.nuscenes_root,
        depth_root=None,
        semantic_root=None,
        split="train",
        image_size=(args.height, args.width),
        load_rgb=True,
        load_depth=False,
        load_semantic=False,
    )
    val_full = NuScenesMultimodalDataset(
        args.val_csv,
        args.nuscenes_root,
        depth_root=None,
        semantic_root=None,
        split="val",
        image_size=(args.height, args.width),
        load_rgb=True,
        load_depth=False,
        load_semantic=False,
    )
    val_indices = sample_fixed_indices(len(val_full), args.val_samples, args.seed)
    val_dataset = NuScenesMultimodalDataset(
        args.val_csv,
        args.nuscenes_root,
        depth_root=None,
        semantic_root=None,
        split="val",
        image_size=(args.height, args.width),
        load_rgb=True,
        load_depth=False,
        load_semantic=False,
        indices=val_indices,
    )
    train_sampler = DistributedSampler(
        train_dataset,
        num_replicas=world_size,
        rank=rank,
        shuffle=True,
        drop_last=True,
    ) if distributed else None
    val_sampler = DistributedSampler(
        val_dataset,
        num_replicas=world_size,
        rank=rank,
        shuffle=False,
        drop_last=False,
    ) if distributed else None
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=(train_sampler is None),
        sampler=train_sampler,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True,
        persistent_workers=args.num_workers > 0,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=max(1, min(args.batch_size, 4)),
        shuffle=False,
        sampler=val_sampler,
        num_workers=max(1, min(args.num_workers, 4)),
        pin_memory=True,
        drop_last=False,
        persistent_workers=args.num_workers > 0,
    )
    return train_loader, val_loader, train_sampler, val_full, val_indices


def rgb_loss(pred: torch.Tensor, target: torch.Tensor, args: argparse.Namespace) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    pred_float = pred.float()
    target_float = target.float()
    l1 = F.l1_loss(pred_float, target_float)
    mse = F.mse_loss(pred_float, target_float)
    ssim = ssim_index(pred_float, target_float).mean()
    total = args.l1_weight * l1 + args.mse_weight * mse + args.ssim_weight * (1.0 - ssim)
    return total, {
        "rgb_l1": l1.detach(),
        "rgb_mse": mse.detach(),
        "rgb_ssim_train": ssim.detach(),
    }


def save_rgb_preview(out_dir: Path, step: int, batch: dict[str, Any], pred: torch.Tensor, max_items: int = 4) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    target = batch["rgb"].detach().cpu()
    pred = pred.detach().cpu().clamp(0.0, 1.0)
    for idx in range(min(max_items, target.shape[0])):
        err = (pred[idx] - target[idx]).abs().mean(dim=0, keepdim=True).repeat(3, 1, 1).clamp(0.0, 1.0)
        row = make_labeled_row(
            [tensor_to_pil(target[idx]), tensor_to_pil(pred[idx]), tensor_to_pil(err)],
            ["rgb target", "rgb reconstruction", "abs error"],
        )
        row.save(out_dir / f"step_{step:08d}_sample_{idx:02d}.jpg", quality=95)


@torch.no_grad()
def evaluate(
    ae: RectDinoTokAutoEncoder,
    model: torch.nn.Module,
    loader: DataLoader,
    args: argparse.Namespace,
    device: torch.device,
    step: int,
    preview_dir: Path | None,
    is_main: bool,
) -> dict[str, float]:
    unwrapped = unwrap_model(model)
    unwrapped.eval()
    mse_sum = torch.zeros((), device=device)
    pixel_sum = torch.zeros((), device=device)
    ssim_sum = torch.zeros((), device=device)
    image_sum = torch.zeros((), device=device)
    l1_sum = torch.zeros((), device=device)
    preview_saved = False
    for batch in loader:
        batch = move_to_device(batch, device)
        with precision_context(device, args.precision):
            latent = ae.encode_to_map(batch["rgb"])
            pred = unwrapped(latent)
        mse, pixels = rgb_mse_sum(pred, batch["rgb"])
        mse_sum += mse
        pixel_sum += pixels
        ssim_values = ssim_index(pred, batch["rgb"])
        ssim_sum += ssim_values.sum()
        image_sum += torch.tensor(float(ssim_values.numel()), device=device)
        l1_sum += F.l1_loss(pred.float(), batch["rgb"].float(), reduction="sum")
        if is_main and preview_dir is not None and not preview_saved:
            save_rgb_preview(preview_dir, step, batch, pred)
            preview_saved = True
    mse_sum = all_reduce_tensor(mse_sum)
    pixel_sum = all_reduce_tensor(pixel_sum)
    ssim_sum = all_reduce_tensor(ssim_sum)
    image_sum = all_reduce_tensor(image_sum)
    l1_sum = all_reduce_tensor(l1_sum)
    mse = float((mse_sum / pixel_sum.clamp_min(1.0)).detach().cpu().item())
    ssim = float((ssim_sum / image_sum.clamp_min(1.0)).detach().cpu().item())
    l1 = float((l1_sum / pixel_sum.clamp_min(1.0)).detach().cpu().item())
    unwrapped.train()
    return {"val_rgb_mse": mse, "val_rgb_psnr": psnr_from_mse(mse), "val_rgb_ssim": ssim, "val_rgb_l1": l1}


def broadcast_stop(stop: bool, device: torch.device) -> bool:
    value = torch.tensor(1 if stop else 0, device=device, dtype=torch.int64)
    if dist.is_available() and dist.is_initialized():
        dist.broadcast(value, src=0)
    return bool(value.item())


def main() -> None:
    args = parse_args()
    dist_info = init_distributed()
    seed_everything(args.seed, dist_info.rank)
    torch.backends.cudnn.benchmark = True
    out_dir = Path(args.out_dir)
    ckpt_dir = out_dir / "checkpoints"
    preview_dir = out_dir / "previews"
    if dist_info.is_main:
        out_dir.mkdir(parents=True, exist_ok=True)
        with (out_dir / "args.json").open("w", encoding="utf-8") as handle:
            json.dump(vars(args), handle, indent=2, ensure_ascii=True)
    train_loader, val_loader, train_sampler, val_full, val_indices = make_loaders(
        args,
        dist_info.rank,
        dist_info.world_size,
        dist_info.distributed,
    )
    if dist_info.is_main:
        write_subset_manifest(out_dir / f"val_subset_{args.val_samples}.jsonl", val_full, val_indices)

    ae = RectDinoTokAutoEncoder(
        backbone_name=args.backbone_name,
        decoder_ckpt=args.decoder_ckpt,
        image_height=args.height,
        image_width=args.width,
    ).to(dist_info.device)
    ae.enable_rgb_decoder_training()
    model: torch.nn.Module = RGBDecoderModule(ae.ae.decoder, ae.img_mean, ae.img_std).to(dist_info.device)
    if dist_info.distributed:
        model = DDP(model, device_ids=[dist_info.local_rank], output_device=dist_info.local_rank)
    optimizer = torch.optim.AdamW(
        [p for p in unwrap_model(model).parameters() if p.requires_grad],
        lr=args.lr,
        betas=(0.9, 0.95),
        weight_decay=args.weight_decay,
    )
    scheduler = cosine_scheduler(optimizer, args.warmup_steps, args.max_steps, args.min_lr_ratio)
    scaler = make_grad_scaler(args.precision)
    start_step = 0
    best_psnr = -1.0
    best_ssim = -1.0
    no_improve = 0
    if args.resume:
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
        unwrap_model(model).decoder.load_state_dict(checkpoint["rgb_decoder"], strict=True)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_step = int(checkpoint["step"])
        best_psnr = float(checkpoint.get("best_psnr", best_psnr))
        best_ssim = float(checkpoint.get("best_ssim", best_ssim))
        no_improve = int(checkpoint.get("no_improve", 0))

    if dist_info.is_main:
        print(
            f"Stage B start: world_size={dist_info.world_size} batch_per_gpu={args.batch_size} "
            f"train_batches={len(train_loader)} val_items={args.val_samples} out={out_dir}",
            flush=True,
        )
    barrier()

    epoch = 0
    train_iter = iter(train_loader)
    unwrap_model(model).train()
    for step in range(start_step + 1, args.max_steps + 1):
        try:
            batch = next(train_iter)
        except StopIteration:
            epoch += 1
            if train_sampler is not None:
                train_sampler.set_epoch(epoch)
            train_iter = iter(train_loader)
            batch = next(train_iter)
        batch = move_to_device(batch, dist_info.device)
        optimizer.zero_grad(set_to_none=True)
        with torch.no_grad(), precision_context(dist_info.device, args.precision):
            latent = ae.encode_to_map(batch["rgb"])
        with precision_context(dist_info.device, args.precision):
            pred = model(latent)
            loss, stats = rgb_loss(pred, batch["rgb"], args)
        scaler.scale(loss).backward()
        if args.grad_clip > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(unwrap_model(model).parameters(), args.grad_clip)
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()

        if step % args.log_every == 0 or step == 1:
            reduced_loss = all_reduce_tensor(loss.detach().float()) / float(dist_info.world_size)
            row: dict[str, Any] = {
                "step": step,
                "epoch": epoch,
                "lr": optimizer.param_groups[0]["lr"],
                "loss": float(reduced_loss.cpu().item()),
            }
            for key, value in stats.items():
                reduced = all_reduce_tensor(value.detach().float()) / float(dist_info.world_size)
                row[key] = float(reduced.cpu().item())
            row.update(current_gpu_memory())
            if dist_info.is_main:
                append_jsonl(out_dir / "train_log.jsonl", row)
                print(json.dumps(row, ensure_ascii=True), flush=True)

        stop_now = False
        if step % args.eval_every == 0 or step == 1:
            metrics = evaluate(
                ae,
                model,
                val_loader,
                args,
                dist_info.device,
                step,
                preview_dir if dist_info.is_main else None,
                dist_info.is_main,
            )
            if dist_info.is_main:
                improved = (
                    metrics["val_rgb_psnr"] > best_psnr + args.min_psnr_delta
                    or metrics["val_rgb_ssim"] > best_ssim + args.min_ssim_delta
                )
                if improved:
                    best_psnr = max(best_psnr, metrics["val_rgb_psnr"])
                    best_ssim = max(best_ssim, metrics["val_rgb_ssim"])
                    no_improve = 0
                else:
                    no_improve += 1
                row = {
                    "step": step,
                    **metrics,
                    "best_psnr": best_psnr,
                    "best_ssim": best_ssim,
                    "no_improve": no_improve,
                    **current_gpu_memory(),
                }
                append_jsonl(out_dir / "val_log.jsonl", row)
                print("VAL " + json.dumps(row, ensure_ascii=True), flush=True)
                payload = {
                    "step": step,
                    "rgb_decoder": unwrap_model(model).decoder.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "scheduler": scheduler.state_dict(),
                    "args": vars(args),
                    "best_psnr": best_psnr,
                    "best_ssim": best_ssim,
                    "no_improve": no_improve,
                    "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                }
                save_checkpoint(ckpt_dir / "last.pt", payload)
                if improved:
                    save_checkpoint(ckpt_dir / "best.pt", payload)
                stop_now = no_improve >= args.early_stop_patience
            stop_now = broadcast_stop(stop_now, dist_info.device)
            if stop_now:
                if dist_info.is_main:
                    print(f"Early stop at step {step}: PSNR/SSIM converged", flush=True)
                break

        if dist_info.is_main and (step % args.save_every == 0 or step == args.max_steps):
            payload = {
                "step": step,
                "rgb_decoder": unwrap_model(model).decoder.state_dict(),
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
                "args": vars(args),
                "best_psnr": best_psnr,
                "best_ssim": best_ssim,
                "no_improve": no_improve,
                "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            }
            save_checkpoint(ckpt_dir / "last.pt", payload)
            save_checkpoint(ckpt_dir / f"step_{step:08d}.pt", payload)
    cleanup_distributed()


if __name__ == "__main__":
    main()
