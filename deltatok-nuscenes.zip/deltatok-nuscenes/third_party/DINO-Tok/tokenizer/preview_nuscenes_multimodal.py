from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np


THIS_FILE = Path(__file__).resolve()
DINO_TOK_ROOT = THIS_FILE.parents[1]
if str(DINO_TOK_ROOT) not in sys.path:
    sys.path.insert(0, str(DINO_TOK_ROOT))

from tokenizer.multimodal_decoders.data import NuScenesMultimodalDataset, sample_fixed_indices
from tokenizer.multimodal_decoders.train_utils import (
    colorize_depth,
    colorize_semantic,
    make_labeled_row,
    tensor_to_pil,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Preview aligned nuScenes RGB/depth/semantic samples.")
    parser.add_argument("--csv-path", default="/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv")
    parser.add_argument("--nuscenes-root", default="/data2/DATA/AutoDrive/nuscenes/v1.0-trainval")
    parser.add_argument(
        "--depth-root",
        default="/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth",
    )
    parser.add_argument("--semantic-root", default="/data4/DATA/wlh/GenDA3/samples_seg")
    parser.add_argument("--output-dir", default="/data/wlh/DeltaWorld/outputs/dinotok_multimodal/previews")
    parser.add_argument("--split", default="train")
    parser.add_argument("--num-samples", type=int, default=12)
    parser.add_argument("--seed", type=int, default=20260826)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--width", type=int, default=832)
    parser.add_argument("--num-classes", type=int, default=10)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    dataset = NuScenesMultimodalDataset(
        csv_path=args.csv_path,
        nuscenes_root=args.nuscenes_root,
        depth_root=args.depth_root,
        semantic_root=args.semantic_root,
        split=args.split,
        image_size=(args.height, args.width),
        num_classes=args.num_classes,
        load_rgb=True,
        load_depth=True,
        load_semantic=True,
    )
    indices = sample_fixed_indices(len(dataset), args.num_samples, args.seed)
    rng = random.Random(args.seed)
    rng.shuffle(indices)
    indices = indices[: args.num_samples]
    manifest = []
    for preview_idx, dataset_idx in enumerate(indices):
        item = dataset[dataset_idx]
        row = make_labeled_row(
            [
                tensor_to_pil(item["rgb"]),
                colorize_depth(item["depth"]),
                colorize_semantic(item["semantic"]),
            ],
            ["rgb resize 832x480", "moge aligned depth", "semantic nearest resize"],
        )
        out_path = out_dir / f"{args.split}_{preview_idx:03d}_{item['cam_dir']}_{Path(item['file']).stem}.jpg"
        row.save(out_path, quality=95)
        semantic = item["semantic"].numpy()
        depth = item["depth"].numpy()
        manifest.append(
            {
                "preview_index": preview_idx,
                "dataset_index": int(dataset_idx),
                "file": item["file"],
                "cam": item["cam"],
                "cam_dir": item["cam_dir"],
                "scene_id": item["scene_id"],
                "frame_id": int(item["frame_id"]),
                "preview_path": str(out_path),
                "depth_shape": list(depth.shape),
                "semantic_shape": list(semantic.shape),
                "semantic_values": [int(x) for x in np.unique(semantic).tolist()],
                "depth_min_positive": float(depth[depth > 0].min()) if np.any(depth > 0) else 0.0,
                "depth_max": float(np.nanmax(depth)),
            }
        )
        print(f"wrote {out_path}")
    with (out_dir / f"{args.split}_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=True)
    print(f"manifest={out_dir / f'{args.split}_manifest.json'}")


if __name__ == "__main__":
    main()
