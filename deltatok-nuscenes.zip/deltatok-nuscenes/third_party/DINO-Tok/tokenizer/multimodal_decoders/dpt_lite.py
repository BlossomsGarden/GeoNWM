from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


def _group_norm(channels: int) -> nn.GroupNorm:
    groups = min(32, channels)
    while channels % groups != 0 and groups > 1:
        groups -= 1
    return nn.GroupNorm(groups, channels)


class ResidualConvUnit(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.GELU(),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            _group_norm(channels),
            nn.GELU(),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            _group_norm(channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.block(x)


class FeatureFusionBlock(nn.Module):
    def __init__(self, channels: int, has_residual: bool = True) -> None:
        super().__init__()
        self.has_residual = bool(has_residual)
        self.residual_unit = ResidualConvUnit(channels) if has_residual else None
        self.output_unit = ResidualConvUnit(channels)
        self.out_conv = nn.Conv2d(channels, channels, kernel_size=1)

    def forward(
        self,
        x: torch.Tensor,
        residual: torch.Tensor | None = None,
        size: tuple[int, int] | None = None,
    ) -> torch.Tensor:
        if self.has_residual:
            if residual is None:
                raise ValueError("residual feature is required for this fusion block")
            x = x + self.residual_unit(residual)
        x = self.output_unit(x)
        if size is not None and x.shape[-2:] != size:
            x = F.interpolate(x, size=size, mode="bilinear", align_corners=False)
        return self.out_conv(x)


class LatentProjectLevel(nn.Module):
    def __init__(self, out_channels: int, texture_fraction: float = 0.25) -> None:
        super().__init__()
        tex_channels = max(8, int(round(out_channels * texture_fraction)))
        deep_channels = out_channels - tex_channels
        self.deep_norm = nn.LayerNorm(768)
        self.tex_norm = nn.LayerNorm(64)
        self.deep_proj = nn.Conv2d(768, deep_channels, kernel_size=1)
        self.tex_proj = nn.Conv2d(64, tex_channels, kernel_size=1)
        self.fuse = nn.Sequential(
            _group_norm(out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
        )

    def forward(self, latent_map: torch.Tensor) -> torch.Tensor:
        deep = latent_map[:, :768]
        tex = latent_map[:, 768:]
        deep_tokens = rearrange(deep, "b c h w -> b h w c")
        tex_tokens = rearrange(tex, "b c h w -> b h w c")
        deep = rearrange(self.deep_norm(deep_tokens), "b h w c -> b c h w")
        tex = rearrange(self.tex_norm(tex_tokens), "b h w c -> b c h w")
        return self.fuse(torch.cat([self.deep_proj(deep), self.tex_proj(tex)], dim=1))


class DPTLiteBase(nn.Module):
    """Single-latent DPT-style dense head for DINO-Tok 832-channel grids."""

    def __init__(
        self,
        out_channels: int,
        grid_size: tuple[int, int] = (30, 52),
        output_size: tuple[int, int] = (480, 832),
        pyramid_channels: tuple[int, int, int, int] = (128, 192, 384, 384),
        fusion_channels: int = 192,
        texture_fraction: float = 0.25,
        final_bias: float | None = None,
    ) -> None:
        super().__init__()
        self.grid_h, self.grid_w = int(grid_size[0]), int(grid_size[1])
        self.output_h, self.output_w = int(output_size[0]), int(output_size[1])
        if self.output_h != self.grid_h * 16 or self.output_w != self.grid_w * 16:
            raise ValueError(
                "DPTLiteBase expects output_size to be 16x the latent grid; "
                f"got grid={grid_size} output={output_size}"
            )
        self.out_channels = int(out_channels)

        self.projects = nn.ModuleList(
            [LatentProjectLevel(ch, texture_fraction=texture_fraction) for ch in pyramid_channels]
        )
        self.resize_layers = nn.ModuleList(
            [
                nn.ConvTranspose2d(pyramid_channels[0], pyramid_channels[0], kernel_size=4, stride=4),
                nn.ConvTranspose2d(pyramid_channels[1], pyramid_channels[1], kernel_size=2, stride=2),
                nn.Identity(),
                nn.Conv2d(pyramid_channels[3], pyramid_channels[3], kernel_size=3, stride=2, padding=1),
            ]
        )
        self.scratch = nn.ModuleList(
            [
                nn.Conv2d(ch, fusion_channels, kernel_size=3, padding=1)
                for ch in pyramid_channels
            ]
        )
        self.refinenet4 = FeatureFusionBlock(fusion_channels, has_residual=False)
        self.refinenet3 = FeatureFusionBlock(fusion_channels, has_residual=True)
        self.refinenet2 = FeatureFusionBlock(fusion_channels, has_residual=True)
        self.refinenet1 = FeatureFusionBlock(fusion_channels, has_residual=True)
        head_channels = fusion_channels // 2
        self.output_conv = nn.Sequential(
            nn.Conv2d(fusion_channels, head_channels, kernel_size=3, padding=1),
            _group_norm(head_channels),
            nn.GELU(),
            nn.Conv2d(head_channels, self.out_channels * 16, kernel_size=1),
            nn.PixelShuffle(4),
        )
        if final_bias is not None:
            last_conv = self.output_conv[3]
            if isinstance(last_conv, nn.Conv2d):
                nn.init.constant_(last_conv.bias, float(final_bias))

    def _coerce_latent_map(self, latent: torch.Tensor) -> torch.Tensor:
        if latent.ndim == 4:
            latent_map = latent
        elif latent.ndim == 3:
            latent_map = rearrange(
                latent,
                "b (h w) c -> b c h w",
                h=self.grid_h,
                w=self.grid_w,
            )
        else:
            raise ValueError(f"Expected latent [B,C,H,W] or [B,N,C], got {tuple(latent.shape)}")
        if latent_map.shape[1] != 832:
            raise ValueError(f"Expected 832 latent channels, got {latent_map.shape[1]}")
        if latent_map.shape[-2:] != (self.grid_h, self.grid_w):
            raise ValueError(
                f"Expected latent grid {(self.grid_h, self.grid_w)}, got {tuple(latent_map.shape[-2:])}"
            )
        return latent_map

    def forward_features(self, latent: torch.Tensor) -> torch.Tensor:
        latent_map = self._coerce_latent_map(latent)
        pyramid = []
        for project, resize, scratch in zip(self.projects, self.resize_layers, self.scratch):
            pyramid.append(scratch(resize(project(latent_map))))

        layer1, layer2, layer3, layer4 = pyramid
        path4 = self.refinenet4(layer4, size=layer3.shape[-2:])
        path3 = self.refinenet3(path4, layer3, size=layer2.shape[-2:])
        path2 = self.refinenet2(path3, layer2, size=layer1.shape[-2:])
        return self.refinenet1(path2, layer1)

    def forward_logits(self, latent: torch.Tensor) -> torch.Tensor:
        logits = self.output_conv(self.forward_features(latent))
        if logits.shape[-2:] != (self.output_h, self.output_w):
            raise RuntimeError(
                f"Decoder produced {tuple(logits.shape[-2:])}, expected {(self.output_h, self.output_w)}"
            )
        return logits


class DPTLiteDepthDecoder(DPTLiteBase):
    def __init__(
        self,
        grid_size: tuple[int, int] = (30, 52),
        output_size: tuple[int, int] = (480, 832),
        min_depth: float = 0.1,
        max_depth: float = 120.0,
        init_depth: float = 20.0,
        **kwargs,
    ) -> None:
        self.min_depth = float(min_depth)
        self.max_depth = float(max_depth)
        final_bias = math.log(float(init_depth))
        super().__init__(
            out_channels=1,
            grid_size=grid_size,
            output_size=output_size,
            final_bias=final_bias,
            **kwargs,
        )

    def forward(self, latent: torch.Tensor) -> torch.Tensor:
        log_depth = self.forward_logits(latent)
        log_depth = log_depth.clamp(math.log(self.min_depth), math.log(self.max_depth))
        return torch.exp(log_depth)


class DPTLiteSemanticDecoder(DPTLiteBase):
    def __init__(
        self,
        num_classes: int = 10,
        grid_size: tuple[int, int] = (30, 52),
        output_size: tuple[int, int] = (480, 832),
        **kwargs,
    ) -> None:
        self.num_classes = int(num_classes)
        super().__init__(
            out_channels=self.num_classes,
            grid_size=grid_size,
            output_size=output_size,
            final_bias=0.0,
            **kwargs,
        )

    def forward(self, latent: torch.Tensor) -> torch.Tensor:
        return self.forward_logits(latent)
