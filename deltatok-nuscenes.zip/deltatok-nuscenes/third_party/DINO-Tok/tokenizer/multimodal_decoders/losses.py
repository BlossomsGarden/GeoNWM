from __future__ import annotations

import torch
import torch.nn.functional as F


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    mask = mask.to(dtype=value.dtype, device=value.device)
    return (value * mask).sum() / mask.sum().clamp_min(1.0)


def charbonnier(value: torch.Tensor, eps: float = 1.0e-3) -> torch.Tensor:
    return torch.sqrt(value.float().pow(2) + float(eps) ** 2)


def depth_valid_mask(
    depth: torch.Tensor,
    min_depth: float = 0.1,
    max_depth: float = 120.0,
) -> torch.Tensor:
    return torch.isfinite(depth) & (depth > float(min_depth)) & (depth < float(max_depth))


def _masked_avg_pool(value: torch.Tensor, mask: torch.Tensor, scale: int) -> tuple[torch.Tensor, torch.Tensor]:
    if scale == 1:
        return value, mask
    mask_f = mask.float()
    count = F.avg_pool2d(mask_f, kernel_size=scale, stride=scale) * float(scale * scale)
    summed = F.avg_pool2d(value * mask_f, kernel_size=scale, stride=scale) * float(scale * scale)
    pooled = summed / count.clamp_min(1.0)
    pooled_mask = count >= float(scale * scale)
    return pooled, pooled_mask


def multiscale_log_gradient_loss(
    pred_depth: torch.Tensor,
    target_depth: torch.Tensor,
    mask: torch.Tensor,
    scales: tuple[int, ...] = (1, 2, 4),
    eps: float = 1.0e-3,
) -> torch.Tensor:
    pred_log = torch.log(pred_depth.clamp_min(1.0e-6))
    target_log = torch.log(target_depth.clamp_min(1.0e-6))
    total = pred_log.new_zeros(())
    count = 0
    for scale in scales:
        pred_s, mask_s = _masked_avg_pool(pred_log, mask, int(scale))
        target_s, _ = _masked_avg_pool(target_log, mask, int(scale))
        mask_x = mask_s[..., :, 1:] & mask_s[..., :, :-1]
        mask_y = mask_s[..., 1:, :] & mask_s[..., :-1, :]
        grad_pred_x = pred_s[..., :, 1:] - pred_s[..., :, :-1]
        grad_tgt_x = target_s[..., :, 1:] - target_s[..., :, :-1]
        grad_pred_y = pred_s[..., 1:, :] - pred_s[..., :-1, :]
        grad_tgt_y = target_s[..., 1:, :] - target_s[..., :-1, :]
        total = total + masked_mean(charbonnier(grad_pred_x - grad_tgt_x, eps), mask_x)
        total = total + masked_mean(charbonnier(grad_pred_y - grad_tgt_y, eps), mask_y)
        count += 2
    return total / max(count, 1)


def depth_loss(
    pred_depth: torch.Tensor,
    target_depth: torch.Tensor,
    min_depth: float = 0.1,
    max_depth: float = 120.0,
    log_weight: float = 1.0,
    grad_weight: float = 0.5,
    metric_weight: float = 0.1,
    eps: float = 1.0e-3,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    if pred_depth.shape != target_depth.shape:
        raise ValueError(f"Depth shape mismatch: pred={pred_depth.shape} target={target_depth.shape}")
    valid = depth_valid_mask(target_depth, min_depth=min_depth, max_depth=max_depth)
    valid = valid & torch.isfinite(pred_depth)
    pred = pred_depth.clamp_min(1.0e-6)
    target = target_depth.clamp_min(1.0e-6)
    log_term = masked_mean(charbonnier(torch.log(pred) - torch.log(target), eps), valid)
    grad_term = multiscale_log_gradient_loss(pred, target, valid, eps=eps)
    rel = (pred - target) / target.clamp_min(1.0)
    metric_term = masked_mean(charbonnier(rel, eps), valid)
    total = float(log_weight) * log_term + float(grad_weight) * grad_term + float(metric_weight) * metric_term
    stats = {
        "depth_loss": total.detach(),
        "depth_log_charb": log_term.detach(),
        "depth_grad": grad_term.detach(),
        "depth_metric_rel": metric_term.detach(),
        "depth_valid_frac": valid.float().mean().detach(),
    }
    return total, stats


def lovasz_grad(gt_sorted: torch.Tensor) -> torch.Tensor:
    p = len(gt_sorted)
    gts = gt_sorted.sum()
    intersection = gts - gt_sorted.float().cumsum(0)
    union = gts + (1.0 - gt_sorted).float().cumsum(0)
    jaccard = 1.0 - intersection / union.clamp_min(1.0e-6)
    if p > 1:
        jaccard[1:p] = jaccard[1:p] - jaccard[0 : p - 1]
    return jaccard


def lovasz_softmax_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    ignore_index: int = 255,
    downsample: int = 1,
) -> torch.Tensor:
    if downsample > 1:
        logits = F.interpolate(
            logits,
            scale_factor=1.0 / float(downsample),
            mode="bilinear",
            align_corners=False,
            recompute_scale_factor=False,
        )
        labels = F.interpolate(labels[:, None].float(), size=logits.shape[-2:], mode="nearest")[:, 0].long()
    probs = F.softmax(logits.float(), dim=1)
    num_classes = probs.shape[1]
    probs = probs.permute(0, 2, 3, 1).reshape(-1, num_classes)
    labels_flat = labels.reshape(-1)
    valid = labels_flat != int(ignore_index)
    probs = probs[valid]
    labels_flat = labels_flat[valid]
    if labels_flat.numel() == 0:
        return logits.new_zeros(())
    losses = []
    for cls in range(num_classes):
        fg = (labels_flat == cls).float()
        if fg.sum() == 0:
            continue
        errors = (fg - probs[:, cls]).abs()
        errors_sorted, perm = torch.sort(errors, descending=True)
        fg_sorted = fg[perm]
        losses.append(torch.dot(errors_sorted, lovasz_grad(fg_sorted)))
    if not losses:
        return logits.new_zeros(())
    return torch.stack(losses).mean()


def semantic_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    ce_weight: float = 1.0,
    lovasz_weight: float = 0.5,
    ignore_index: int = 255,
    lovasz_downsample: int = 4,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    ce = F.cross_entropy(logits.float(), labels.long(), ignore_index=int(ignore_index))
    lovasz = lovasz_softmax_loss(
        logits,
        labels,
        ignore_index=ignore_index,
        downsample=int(lovasz_downsample),
    )
    total = float(ce_weight) * ce + float(lovasz_weight) * lovasz
    stats = {
        "semantic_loss": total.detach(),
        "semantic_ce": ce.detach(),
        "semantic_lovasz": lovasz.detach(),
    }
    return total, stats
