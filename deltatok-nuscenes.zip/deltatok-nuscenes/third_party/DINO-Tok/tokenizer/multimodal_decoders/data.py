from __future__ import annotations

import csv
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset


CAM_TO_DIR = {
    "FRONT_LEFT": "CAM_FRONT_LEFT",
    "FRONT": "CAM_FRONT",
    "FRONT_RIGHT": "CAM_FRONT_RIGHT",
    "BACK_LEFT": "CAM_BACK_LEFT",
    "BACK": "CAM_BACK",
    "BACK_RIGHT": "CAM_BACK_RIGHT",
    "CAM_FRONT_LEFT": "CAM_FRONT_LEFT",
    "CAM_FRONT": "CAM_FRONT",
    "CAM_FRONT_RIGHT": "CAM_FRONT_RIGHT",
    "CAM_BACK_LEFT": "CAM_BACK_LEFT",
    "CAM_BACK": "CAM_BACK",
    "CAM_BACK_RIGHT": "CAM_BACK_RIGHT",
}


@dataclass(frozen=True)
class NuScenesSample:
    index: int
    split: str
    scene_id: str
    frame_id: int
    cam: str
    cam_dir: str
    file: str
    ego_pose_token: str

    @property
    def stem(self) -> str:
        return Path(self.file).stem


def load_csv_samples(csv_path: str | Path, split: str) -> list[NuScenesSample]:
    samples: list[NuScenesSample] = []
    with Path(csv_path).open("r", encoding="utf-8-sig", newline="") as handle:
        for idx, row in enumerate(csv.DictReader(handle)):
            cam = str(row["cam"])
            if cam not in CAM_TO_DIR:
                raise ValueError(f"Unsupported camera name {cam!r} in {csv_path}")
            samples.append(
                NuScenesSample(
                    index=idx,
                    split=split,
                    scene_id=str(row["scene_id"]),
                    frame_id=int(row["frame_id"]),
                    cam=cam,
                    cam_dir=CAM_TO_DIR[cam],
                    file=str(row["file"]),
                    ego_pose_token=str(row.get("ego_pose_token", "")),
                )
            )
    if not samples:
        raise ValueError(f"No samples found in {csv_path}")
    return samples


def sample_fixed_indices(num_items: int, num_samples: int, seed: int) -> list[int]:
    if num_samples <= 0 or num_samples >= num_items:
        return list(range(num_items))
    rng = random.Random(int(seed))
    return sorted(rng.sample(range(num_items), int(num_samples)))


def write_subset_manifest(
    path: str | Path,
    dataset: "NuScenesMultimodalDataset",
    indices: list[int],
) -> None:
    manifest_path = Path(path)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open("w", encoding="utf-8") as handle:
        for subset_pos, idx in enumerate(indices):
            sample = dataset.samples[idx]
            row = {
                "subset_pos": subset_pos,
                "dataset_index": idx,
                "split": sample.split,
                "scene_id": sample.scene_id,
                "frame_id": sample.frame_id,
                "cam": sample.cam,
                "cam_dir": sample.cam_dir,
                "file": sample.file,
                "rgb_path": str(dataset.rgb_path(sample)),
            }
            if dataset.depth_root is not None:
                row["depth_path"] = str(dataset.depth_path(sample))
            if dataset.semantic_root is not None:
                row["semantic_path"] = str(dataset.semantic_path(sample))
            handle.write(json.dumps(row, ensure_ascii=True) + "\n")


class NuScenesMultimodalDataset(Dataset):
    """nuScenes camera samples aligned to the MoGe-2 480x832 resize geometry."""

    def __init__(
        self,
        csv_path: str | Path,
        nuscenes_root: str | Path,
        depth_root: str | Path | None = None,
        semantic_root: str | Path | None = None,
        split: str = "train",
        image_size: tuple[int, int] = (480, 832),
        num_classes: int = 10,
        load_rgb: bool = True,
        load_depth: bool = True,
        load_semantic: bool = True,
        indices: list[int] | None = None,
    ) -> None:
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.depth_root = Path(depth_root) if depth_root is not None else None
        self.semantic_root = Path(semantic_root) if semantic_root is not None else None
        self.split = split
        self.image_height = int(image_size[0])
        self.image_width = int(image_size[1])
        self.num_classes = int(num_classes)
        self.load_rgb = bool(load_rgb)
        self.load_depth = bool(load_depth)
        self.load_semantic = bool(load_semantic)

        if self.load_depth and self.depth_root is None:
            raise ValueError("depth_root is required when load_depth=True")
        if self.load_semantic and self.semantic_root is None:
            raise ValueError("semantic_root is required when load_semantic=True")

        samples = load_csv_samples(self.csv_path, split)
        if indices is not None:
            samples = [samples[int(i)] for i in indices]
        self.samples = samples

    def __len__(self) -> int:
        return len(self.samples)

    def rgb_path(self, sample: NuScenesSample) -> Path:
        raw = Path(sample.file)
        if raw.is_absolute():
            return raw
        return self.nuscenes_root / "samples" / sample.cam_dir / sample.file

    def depth_path(self, sample: NuScenesSample) -> Path:
        if self.depth_root is None:
            raise ValueError("depth_root is not configured")
        return self.depth_root / sample.cam_dir / f"{sample.stem}.npz"

    def semantic_path(self, sample: NuScenesSample) -> Path:
        if self.semantic_root is None:
            raise ValueError("semantic_root is not configured")
        return self.semantic_root / sample.cam_dir / f"{sample.stem}.png"

    def _resize_rgb(self, image_rgb: np.ndarray) -> np.ndarray:
        return cv2.resize(
            image_rgb,
            (self.image_width, self.image_height),
            interpolation=cv2.INTER_AREA,
        )

    def _load_rgb(self, sample: NuScenesSample) -> torch.Tensor:
        path = self.rgb_path(sample)
        with Image.open(path) as image:
            image_rgb = np.asarray(image.convert("RGB"))
        image_rgb = self._resize_rgb(image_rgb)
        return torch.from_numpy(image_rgb.copy()).permute(2, 0, 1).float() / 255.0

    def _load_depth(self, sample: NuScenesSample) -> torch.Tensor:
        path = self.depth_path(sample)
        data = np.load(path)
        depth = data["depth"].astype(np.float32, copy=False)
        if depth.shape != (self.image_height, self.image_width):
            raise ValueError(
                f"Depth shape {depth.shape} for {path} does not match "
                f"{(self.image_height, self.image_width)}"
            )
        return torch.from_numpy(depth.copy()).unsqueeze(0)

    def _load_semantic(self, sample: NuScenesSample) -> torch.Tensor:
        path = self.semantic_path(sample)
        with Image.open(path) as image:
            label = np.asarray(image.convert("L"))
        if label.shape != (self.image_height, self.image_width):
            label = cv2.resize(
                label,
                (self.image_width, self.image_height),
                interpolation=cv2.INTER_NEAREST,
            )
        label = label.astype(np.int64, copy=False)
        invalid = (label < 0) | (label >= self.num_classes)
        if np.any(invalid):
            label = label.copy()
            label[invalid] = 255
        return torch.from_numpy(label.copy()).long()

    def __getitem__(self, idx: int) -> dict[str, Any]:
        sample = self.samples[int(idx)]
        item: dict[str, Any] = {
            "index": sample.index,
            "split": sample.split,
            "scene_id": sample.scene_id,
            "frame_id": sample.frame_id,
            "cam": sample.cam,
            "cam_dir": sample.cam_dir,
            "file": sample.file,
        }
        if self.load_rgb:
            item["rgb"] = self._load_rgb(sample)
        if self.load_depth:
            item["depth"] = self._load_depth(sample)
        if self.load_semantic:
            item["semantic"] = self._load_semantic(sample)
        return item
