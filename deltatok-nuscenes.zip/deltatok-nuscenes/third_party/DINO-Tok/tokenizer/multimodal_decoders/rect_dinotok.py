from __future__ import annotations

from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from transformers import AutoConfig, AutoModel

from tokenizer.dinotok.models.tokenizer.dinotok import DINOTOK, dinov3_f16c768


class RectDinoTokAutoEncoder(nn.Module):
    """Frozen DINOv3 encoder plus DINO-Tok AE decoder for rectangular inputs."""

    def __init__(
        self,
        backbone_name: str,
        decoder_ckpt: str,
        image_height: int = 480,
        image_width: int = 832,
        patch_size: int = 16,
        dino_shallow_layer: int = 5,
    ) -> None:
        super().__init__()
        if image_height % patch_size != 0 or image_width % patch_size != 0:
            raise ValueError(
                f"Image size {(image_height, image_width)} must be divisible by {patch_size}"
            )
        self.image_height = int(image_height)
        self.image_width = int(image_width)
        self.patch_size = int(patch_size)
        self.grid_h = self.image_height // self.patch_size
        self.grid_w = self.image_width // self.patch_size
        self.hidden_size = 832
        self.deep_size = 768
        self.texture_size = 64
        self.dino_shallow_layer = int(dino_shallow_layer)

        self.backbone = AutoModel.from_pretrained(backbone_name)
        self.backbone.eval().requires_grad_(False)
        config = AutoConfig.from_pretrained(backbone_name)
        self.num_prefix_tokens = int(config.num_register_tokens) + 1

        decoder_cfg = dinov3_f16c768(
            "dinov3-f16c768-in-1.0",
            None,
            0,
            self.image_width,
            self.image_height,
            False,
            None,
        )
        self.ae = DINOTOK(decoder_cfg)
        self._load_decoder_checkpoint(decoder_ckpt)
        self.ae.eval().requires_grad_(False)

        self.register_buffer(
            "img_mean",
            torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1),
            persistent=False,
        )
        self.register_buffer(
            "img_std",
            torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1),
            persistent=False,
        )

    def _load_decoder_checkpoint(self, checkpoint_path: str) -> None:
        state = torch.load(str(checkpoint_path), map_location="cpu", weights_only=False)
        if isinstance(state, dict) and "model" in state:
            state = state["model"]
        if not isinstance(state, dict):
            raise TypeError(f"Unsupported checkpoint format: {checkpoint_path}")
        cleaned = {}
        for key, value in state.items():
            for prefix in ("module.", "model."):
                if key.startswith(prefix):
                    key = key[len(prefix) :]
            cleaned[key] = value
        missing, unexpected = self.ae.load_state_dict(cleaned, strict=False)
        if missing:
            raise RuntimeError(
                f"DINO-Tok checkpoint missing {len(missing)} keys; first keys: {missing[:5]}"
            )
        if unexpected:
            raise RuntimeError(
                f"DINO-Tok checkpoint has {len(unexpected)} unexpected keys; first keys: {unexpected[:5]}"
            )

    def prepare_images(self, images: torch.Tensor) -> torch.Tensor:
        images = images.float()
        if images.numel() and images.detach().amax() > 1.5:
            images = images / 255.0
        if images.shape[-2:] != (self.image_height, self.image_width):
            images = F.interpolate(
                images,
                size=(self.image_height, self.image_width),
                mode="bicubic",
                align_corners=False,
            )
        images = images.clamp(0.0, 1.0)
        return (images - self.img_mean.to(images)) / self.img_std.to(images)

    @torch.no_grad()
    def encode_to_map(self, images: torch.Tensor) -> torch.Tensor:
        images = self.prepare_images(images)
        outputs = self.backbone(images, output_hidden_states=True)
        hidden_states = outputs.hidden_states
        if hidden_states is None:
            raise RuntimeError("DINOv3 backbone did not return hidden states")
        shallow = self.backbone.norm(hidden_states[self.dino_shallow_layer])
        deep = self.backbone.norm(hidden_states[-1])
        shallow = shallow[:, self.num_prefix_tokens :]
        deep = deep[:, self.num_prefix_tokens :]
        expected_tokens = self.grid_h * self.grid_w
        if shallow.shape[1] != expected_tokens or deep.shape[1] != expected_tokens:
            raise ValueError(
                f"Expected {expected_tokens} patch tokens for "
                f"{self.grid_h}x{self.grid_w}, got shallow={shallow.shape[1]} deep={deep.shape[1]}"
            )
        shallow_map = rearrange(
            shallow,
            "b (h w) c -> b c h w",
            h=self.grid_h,
            w=self.grid_w,
        )
        deep_map = rearrange(
            deep,
            "b (h w) c -> b c h w",
            h=self.grid_h,
            w=self.grid_w,
        )
        latent_map = self.ae.encode((shallow_map, deep_map))[0]
        return latent_map.detach()

    @torch.no_grad()
    def encode_to_tokens(self, images: torch.Tensor) -> torch.Tensor:
        latent_map = self.encode_to_map(images)
        return rearrange(latent_map, "b c h w -> b (h w) c")

    def decode_from_map(self, latent_map: torch.Tensor, clamp: bool = True) -> torch.Tensor:
        if latent_map.ndim != 4:
            raise ValueError(f"Expected latent_map [B,C,H,W], got {tuple(latent_map.shape)}")
        if latent_map.shape[-2:] != (self.grid_h, self.grid_w):
            raise ValueError(
                f"Expected latent grid {(self.grid_h, self.grid_w)}, got {tuple(latent_map.shape[-2:])}"
            )
        images, _ = self.ae.decode(latent_map)
        images = images * self.img_std.to(images) + self.img_mean.to(images)
        if clamp:
            images = images.clamp(0.0, 1.0)
        return images

    def decode_from_tokens(self, latents: torch.Tensor, clamp: bool = True) -> torch.Tensor:
        if latents.ndim != 3:
            raise ValueError(f"Expected latents [B,N,C], got {tuple(latents.shape)}")
        latent_map = rearrange(
            latents,
            "b (h w) c -> b c h w",
            h=self.grid_h,
            w=self.grid_w,
        )
        return self.decode_from_map(latent_map, clamp=clamp)

    def enable_rgb_decoder_training(self) -> None:
        self.backbone.eval().requires_grad_(False)
        self.ae.quant_conv.eval().requires_grad_(False)
        self.ae.decoder.train().requires_grad_(True)

    def train(self, mode: bool = True) -> "RectDinoTokAutoEncoder":
        super().train(mode)
        self.backbone.eval().requires_grad_(False)
        self.ae.quant_conv.eval().requires_grad_(False)
        return self

    def rgb_decoder_state_dict(self) -> dict[str, torch.Tensor]:
        return self.ae.decoder.state_dict()

    def load_rgb_decoder_state_dict(self, state_dict: dict[str, torch.Tensor]) -> None:
        self.ae.decoder.load_state_dict(state_dict, strict=True)

    @property
    def decoder_checkpoint_name(self) -> str:
        return Path("rgb_decoder_480x832.pt").name
