from __future__ import annotations

import json
import math
import os
import random
import time
from contextlib import nullcontext
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

import numpy as np
import torch
import torch.distributed as dist
from PIL import Image, ImageDraw
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LambdaLR


SEMANTIC_PALETTE = np.asarray(
    [
        [0, 0, 0],
        [70, 130, 180],
        [220, 20, 60],
        [255, 140, 0],
        [255, 215, 0],
        [148, 0, 211],
        [34, 139, 34],
        [0, 191, 255],
        [255, 105, 180],
        [169, 169, 169],
    ],
    dtype=np.uint8,
)


@dataclass(frozen=True)
class DistInfo:
    distributed: bool
    rank: int
    local_rank: int
    world_size: int
    device: torch.device

    @property
    def is_main(self) -> bool:
        return self.rank == 0


def init_distributed() -> DistInfo:
    distributed = "RANK" in os.environ and "WORLD_SIZE" in os.environ
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    if torch.cuda.is_available():
        torch.cuda.set_device(local_rank)
        device = torch.device("cuda", local_rank)
    else:
        device = torch.device("cpu")
    if distributed:
        backend = "nccl" if device.type == "cuda" else "gloo"
        dist.init_process_group(backend=backend)
        rank = dist.get_rank()
        world_size = dist.get_world_size()
    else:
        rank = 0
        world_size = 1
    return DistInfo(distributed, rank, local_rank, world_size, device)


def cleanup_distributed() -> None:
    if dist.is_available() and dist.is_initialized():
        dist.destroy_process_group()


def barrier() -> None:
    if dist.is_available() and dist.is_initialized():
        dist.barrier()


def seed_everything(seed: int, rank: int = 0) -> None:
    seed = int(seed) + int(rank)
    random.seed(seed)
    np.random.seed(seed % (2**32 - 1))
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def precision_context(device: torch.device, precision: str):
    if device.type != "cuda" or precision == "fp32":
        return nullcontext()
    if precision == "bf16":
        return torch.autocast(device_type="cuda", dtype=torch.bfloat16)
    if precision == "fp16":
        return torch.autocast(device_type="cuda", dtype=torch.float16)
    raise ValueError(f"Unsupported precision {precision!r}")


def make_grad_scaler(precision: str) -> torch.cuda.amp.GradScaler:
    return torch.cuda.amp.GradScaler(enabled=(precision == "fp16" and torch.cuda.is_available()))


def cosine_scheduler(
    optimizer: Optimizer,
    warmup_steps: int,
    max_steps: int,
    min_lr_ratio: float = 0.05,
) -> LambdaLR:
    warmup_steps = int(warmup_steps)
    max_steps = max(int(max_steps), 1)
    min_lr_ratio = float(min_lr_ratio)

    def lr_lambda(step: int) -> float:
        step = int(step)
        if warmup_steps > 0 and step < warmup_steps:
            return float(step + 1) / float(warmup_steps)
        progress = (step - warmup_steps) / float(max(1, max_steps - warmup_steps))
        progress = min(max(progress, 0.0), 1.0)
        cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
        return min_lr_ratio + (1.0 - min_lr_ratio) * cosine

    return LambdaLR(optimizer, lr_lambda)


def cycle(loader) -> Iterator[Any]:
    while True:
        for batch in loader:
            yield batch


def move_to_device(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in batch.items():
        out[key] = value.to(device, non_blocking=True) if torch.is_tensor(value) else value
    return out


def all_reduce_tensor(value: torch.Tensor) -> torch.Tensor:
    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(value, op=dist.ReduceOp.SUM)
    return value


def all_reduce_mapping(values: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {key: all_reduce_tensor(value.clone()) for key, value in values.items()}


def append_jsonl(path: str | Path, row: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(row)
    payload.setdefault("time", time.strftime("%Y-%m-%dT%H:%M:%S"))
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=True) + "\n")


def save_checkpoint(path: str | Path, payload: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, tmp)
    tmp.replace(path)


def tensor_to_pil(image: torch.Tensor) -> Image.Image:
    image_np = image.detach().float().cpu().clamp(0.0, 1.0)
    image_np = (image_np.permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)
    return Image.fromarray(image_np, mode="RGB")


def colorize_depth(depth: torch.Tensor | np.ndarray) -> Image.Image:
    if torch.is_tensor(depth):
        arr = depth.detach().float().cpu().squeeze().numpy()
    else:
        arr = np.asarray(depth).squeeze().astype(np.float32)
    valid = np.isfinite(arr) & (arr > 0)
    norm = np.zeros_like(arr, dtype=np.float32)
    if np.any(valid):
        near, far = np.percentile(arr[valid], [2, 98])
        if far <= near:
            far = near + 1.0
        norm = np.clip((arr - near) / (far - near), 0.0, 1.0)
    r = (255.0 * norm).astype(np.uint8)
    g = (255.0 * (1.0 - np.abs(norm - 0.5) * 2.0)).astype(np.uint8)
    b = (255.0 * (1.0 - norm)).astype(np.uint8)
    rgb = np.stack([r, g, b], axis=-1)
    rgb[~valid] = 0
    return Image.fromarray(rgb, mode="RGB")


def colorize_semantic(label: torch.Tensor | np.ndarray, palette: np.ndarray = SEMANTIC_PALETTE) -> Image.Image:
    if torch.is_tensor(label):
        arr = label.detach().cpu().long().squeeze().numpy()
    else:
        arr = np.asarray(label).squeeze().astype(np.int64)
    out = np.zeros((*arr.shape, 3), dtype=np.uint8)
    valid = (arr >= 0) & (arr < len(palette))
    out[valid] = palette[arr[valid]]
    return Image.fromarray(out, mode="RGB")


def make_labeled_row(images: list[Image.Image], labels: list[str]) -> Image.Image:
    if len(images) != len(labels):
        raise ValueError("images and labels must have the same length")
    widths = [img.width for img in images]
    height = max(img.height for img in images)
    header = 24
    canvas = Image.new("RGB", (sum(widths), height + header), "white")
    draw = ImageDraw.Draw(canvas)
    x = 0
    for image, label in zip(images, labels):
        canvas.paste(image, (x, header))
        draw.text((x + 8, 6), label, fill=(0, 0, 0))
        x += image.width
    return canvas


def current_gpu_memory() -> dict[str, float]:
    if not torch.cuda.is_available():
        return {"gpu_allocated_gb": 0.0, "gpu_reserved_gb": 0.0, "gpu_max_allocated_gb": 0.0}
    return {
        "gpu_allocated_gb": round(torch.cuda.memory_allocated() / 1024**3, 3),
        "gpu_reserved_gb": round(torch.cuda.memory_reserved() / 1024**3, 3),
        "gpu_max_allocated_gb": round(torch.cuda.max_memory_allocated() / 1024**3, 3),
    }
