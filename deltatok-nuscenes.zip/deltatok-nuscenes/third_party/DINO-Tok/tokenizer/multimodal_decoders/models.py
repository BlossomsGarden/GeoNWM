from __future__ import annotations

import torch
import torch.nn as nn

from .dpt_lite import DPTLiteDepthDecoder, DPTLiteSemanticDecoder


class StageAMultimodalDecoders(nn.Module):
    def __init__(
        self,
        grid_size: tuple[int, int] = (30, 52),
        output_size: tuple[int, int] = (480, 832),
        num_classes: int = 10,
        min_depth: float = 0.1,
        max_depth: float = 120.0,
        fusion_channels: int = 192,
    ) -> None:
        super().__init__()
        common = {
            "grid_size": grid_size,
            "output_size": output_size,
            "fusion_channels": int(fusion_channels),
        }
        self.depth_decoder = DPTLiteDepthDecoder(
            min_depth=min_depth,
            max_depth=max_depth,
            **common,
        )
        self.semantic_decoder = DPTLiteSemanticDecoder(
            num_classes=num_classes,
            **common,
        )

    def forward(self, latent_map: torch.Tensor) -> dict[str, torch.Tensor]:
        return {
            "depth": self.depth_decoder(latent_map),
            "semantic_logits": self.semantic_decoder(latent_map),
        }

    def decoder_state_dict(self) -> dict[str, dict[str, torch.Tensor]]:
        return {
            "depth_decoder": self.depth_decoder.state_dict(),
            "semantic_decoder": self.semantic_decoder.state_dict(),
        }
