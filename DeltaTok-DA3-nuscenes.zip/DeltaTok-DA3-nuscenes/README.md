# DeltaTok-DA3 nuScenes

This project trains a DA3-space DeltaTok tokenizer for adjacent nuScenes frame pairs.
It uses frozen Depth Anything 3 nested giant-large features and learns only the
DeltaTok encoder/decoder.

## Modules

- `src/deltatok_da3/data.py`: full nuScenes adjacent-keyframe pair indexing and
  DVGT-style principal-point resize/crop. The formal run uses only `CAM_FRONT`
  and `CAM_BACK` at `700x252`, which is divisible by the DA3 patch size 14.
- `src/deltatok_da3/da3_features.py`: frozen DA3 feature extraction. It loads
  `/data/wlh/DA3/model/DA3NESTED-GIANT-LARGE-1.1`, uses only the anyview branch,
  and returns the four real DPT-projected feature levels `[256,512,1024,1024]`.
- `src/deltatok_da3/model.py`: one joint four-level DeltaTok checkpoint. Each
  level has 8 delta tokens with its native channel width; no padding to 1024 is
  used. The decoder residual head is zero-initialized, so the model starts from
  the copy-last prior and learns changes from there.
- `src/deltatok_da3/train.py`: 2-GPU DDP training, batch-size probing, MSE loss,
  copy-last baseline logging, checkpointing, resume, and validation.
- `configs/deltatok_da3_nuscenes_front_back_700x252.yaml`: the formal training
  configuration.

## Feature Target

The model does not reconstruct DA3 raw backbone tokens. DA3 nested giant-large
has raw anyview features with 3072 channels, but the DA3 DualDPT head immediately
projects the four selected layers to:

```text
[256, 512, 1024, 1024]
```

DeltaTok is trained directly in this decoder-facing projected space. The decoder
outputs those same four real feature tensors; there are no fake padding channels
and no padding mask.

## Training Objective

For each adjacent pair `(x_{t-1}, x_t)` from the same camera:

1. DA3 extracts frozen projected features for both frames.
2. The per-level DeltaTok encoder reads previous/current features and emits
   8 delta tokens for that level.
3. The per-level decoder reconstructs current features from previous features
   and the 8 delta tokens.
4. The loss is the equal-weight mean of four MSE losses, one per DA3 projected
   feature level.

The run also logs copy-last MSE and relative improvement, so the tokenizer must
learn a useful change representation rather than merely preserve the previous
state.

## Formal Remote Training

From the remote project directory:

```bash
cd /data/wlh/DA3/code/DeltaTok-DA3-nuscenes
CONDA_ENV_NAME=da3 GPUS=2,3 bash scripts/start_remote_training.sh
```

The launcher sets:

```bash
CUDA_VISIBLE_DEVICES=2,3
torchrun --standalone --nproc_per_node=2
```

Recommended formal launch sequence:

```bash
cd /data/wlh/DA3/code/DeltaTok-DA3-nuscenes
CONDA_ENV_NAME=da3 GPUS=2,3 bash scripts/start_remote_training.sh
INTERVAL_SECONDS=300 bash scripts/watch_validation_analysis.sh
INTERVAL_SECONDS=300 bash scripts/monitor_formal_training.sh
DEVICE=cuda:6 INTERVAL_SECONDS=300 bash scripts/watch_checkpoint_visualization.sh
DEVICE=cuda:7 INTERVAL_SECONDS=300 bash scripts/watch_checkpoint_full_eval.sh
```

The config trains for 50K optimizer steps with AdamW, MSE, LR warmup to `1e-3`
over 5K steps, weight decay `1e-4`, gradient clip `1e-2`, bf16, and DDP. It
probes per-GPU batch size from 64 downward and then chooses gradient
accumulation to keep the effective batch near 1024 without changing feature
dimensions.

Validation uses a separate `val_batch_size` and `decoder_chunk_size`. This does
not change the training batch, model dimensions, or reconstruction objective; it
keeps the DA3 depth/ray decoder evaluation within memory because validation runs
the frozen DA3 DPT tail while training supervises projected features directly.

## Current Interrupted Run

The first formal run was intentionally stopped on `2026-06-10 09:17 CST`
because the server has runtime-occupancy limits. Only this project's training
and diagnostic processes were stopped.

Run directory:

```text
runs/deltatok_da3_front_back_700x252_8tok
```

Stop snapshot:

```text
runs/deltatok_da3_front_back_700x252_8tok/stop_snapshot_20260610_091712
```

State at stop:

- latest logged train step: `530`
- latest train MSE: `0.1873707175`
- latest train copy-last MSE: `0.2742286325`
- latest train relative improvement over copy-last: `31.67%`
- pre-stop strict anomaly count: `0`
- no checkpoint was available yet because the first scheduled checkpoint is
  step `1000`

After the stop command, the full formal log contains one `Traceback` from
`torchrun` receiving `SIGTERM` at `2026-06-10 09:17:13 CST`. This is the
intentional shutdown path, not a training-time numerical or OOM failure. The
pre-stop strict anomaly report is saved as:

```text
runs/deltatok_da3_front_back_700x252_8tok/stop_snapshot_20260610_091712/strict_before_stop.txt
```

The completed step-500 limited validation is the current scientific evidence:

```text
val_mse                 0.1775074851
val_copy_mse            0.2566185060
relative improvement    30.83%
depth relative improve  16.95%
ray relative improve    37.97%
non-finite values       0
```

Per-level validation improvement over copy-last:

```text
level1  20.83%
level2  23.14%
level3  35.18%
level4  56.74%
```

Step-500 evidence files:

- `val_metrics.csv`
- `analysis_step_500.txt`
- `analysis_step_500.json`
- `strict_anomalies_step_500.txt`
- `run_manifest_latest.json`
- `process_snapshot_latest.json`
- `EXPERIMENT_LOG.md`

Not yet completed in this interrupted run:

- step-1000 checkpoint
- fixed-sample checkpoint visualization
- independent checkpoint full-val evaluation
- training-process internal full-val evaluation at step `5000`

Because no checkpoint was produced before the intentional stop, this particular
run cannot be resumed from step `530`. To keep the current evidence intact, do
not relaunch into the same output directory unless you intentionally want CSVs
from multiple launches to share one directory. Prefer either archiving this run
directory or changing `train.output_dir` in the config before the next formal
launch.

To intentionally stop only this project later, first record the current state:

```bash
bash scripts/analyze_run.sh
python scripts/check_strict_anomalies.py --log logs/formal_train_20260610_024230.log
bash scripts/write_run_manifest.sh
bash scripts/write_process_snapshot.sh
```

Then stop only commands matching this project:

```bash
ps -eo pid,cmd \
  | grep -E 'watch_validation_analysis.sh|watch_checkpoint_full_eval.sh|watch_checkpoint_visualization.sh|monitor_formal_training.sh|torchrun --standalone --nproc_per_node=2 src/deltatok_da3/train.py|src/deltatok_da3/train.py --config configs/deltatok_da3_nuscenes_front_back_700x252.yaml|scripts/start_remote_training.sh' \
  | grep -v grep
```

Kill only those listed PIDs. Do not kill unrelated GPU jobs.

## Verification

Before training:

```bash
CONDA_ENV_NAME=da3 bash scripts/remote_smoke_check.sh
```

This check compiles the local modules, verifies full train/val pair indexing,
camera filtering, `3x252x700` image tensors, DA3 frozen projected feature shapes,
8-token DeltaTok output shapes, native `[256,512,1024,1024]` channels with no
padding, and DA3 decoder output keys. By default it auto-selects an idle GPU and
excludes the formal training GPUs `2,3`.

During training, inspect:

- `runs/deltatok_da3_front_back_700x252_8tok/metrics.csv`
- `runs/deltatok_da3_front_back_700x252_8tok/val_metrics.csv`
- `runs/deltatok_da3_front_back_700x252_8tok/full_val_metrics.csv`
- `runs/deltatok_da3_front_back_700x252_8tok/checkpoint_evals/*.json`
- `runs/deltatok_da3_front_back_700x252_8tok/checkpoints/last.pt`
- `logs/train_deltatok_da3.log`
- `EXPERIMENT_LOG.md` for the running evidence trail and pending milestones.

For a read-only metric summary:

```bash
bash scripts/analyze_run.sh
```

This reports the latest train/validation MSE, relative improvement over
copy-last, per-level relative improvement, non-finite value counts, checkpoint
presence, independent checkpoint evaluation status, visualization status, and
pending milestones. It uses only CSV/JSON/file reads and does not initialize
CUDA.

Training metrics are logged from the final micro-batch of each accumulated
optimizer step, so they are useful as an early health signal. Validation metrics
are the primary evidence for scientific conclusions.

For a strict read-only anomaly scan of the formal training log:

```bash
python scripts/check_strict_anomalies.py --log logs/formal_train_20260610_024230.log
```

This avoids broad `inf`/`nan` false positives such as matching the word `INFO`.
It reports only OOM, traceback/runtime/child-failure lines, and standalone
NaN/Inf tokens.

For a reproducibility manifest of the active code/config/scripts and run files:

```bash
bash scripts/write_run_manifest.sh
```

This writes `run_manifest_*.json` and `run_manifest_latest.json` under the run
directory, including SHA256 hashes of the project files used to interpret the
run. It does not initialize CUDA.

For a read-only snapshot of the active training processes:

```bash
bash scripts/write_process_snapshot.sh
```

This writes `process_snapshot_*.json` and `process_snapshot_latest.json` under
the run directory, including the active torchrun/worker PIDs, command lines,
selected environment variables, GPU process summary, and current artifact
presence. It does not initialize CUDA.

To leave the first validation analysis waiting in the background:

```bash
INTERVAL_SECONDS=300 bash scripts/watch_validation_analysis.sh
```

It waits for `val_metrics.csv` to reach step `500`, then writes
`analysis_step_500.txt` and `analysis_step_500.json` under the run directory,
adds a strict anomaly scan, refreshes the run manifest and process snapshot,
and appends the report to `EXPERIMENT_LOG.md`.

For long runs, a read-only monitor can be left running in the background:

```bash
INTERVAL_SECONDS=300 bash scripts/monitor_formal_training.sh
```

It records process, GPU, metric, validation, checkpoint, and anomaly snapshots
under `logs/monitor_formal_training_*.log` without touching the training job.

After a checkpoint is available, generate fixed-sample validation diagnostics:

```bash
bash scripts/run_checkpoint_visualization.sh
```

By default this auto-selects an idle GPU and excludes the formal training GPUs
`2,3`. Override with `DEVICE=cuda:x` when a specific GPU is known to be safe.
This writes `visualizations/*.png` and `visualizations/summary_step_*.csv` under
the run directory. Each image compares previous RGB, current RGB, copy-last DA3
decoder output, DeltaTok prediction, oracle DA3 output, and absolute errors for
DA3 depth and ray outputs.

To leave the fixed-sample diagnostic waiting for the first scheduled checkpoint:

```bash
INTERVAL_SECONDS=300 bash scripts/watch_checkpoint_visualization.sh
```

After visualization completes, the watcher also writes a fresh analyzer report
and appends it to `EXPERIMENT_LOG.md`. It waits for the checkpoint file size to
stabilize before loading, so it does not race a checkpoint that is still being
written.

The run is considered scientifically meaningful only if validation MSE improves
over copy-last and the per-level losses decrease coherently.

For a complete val-set evaluation of a saved checkpoint without waiting for the
training process to reach the next internal full-validation milestone:

```bash
CHECKPOINT=runs/deltatok_da3_front_back_700x252_8tok/checkpoints/step_0001000.pt \
  bash scripts/run_checkpoint_full_eval.sh
```

This loads the checkpoint in a separate process, auto-selects a non-training GPU
when possible, evaluates all `val` pairs by default, and writes:

- `checkpoint_evals/full_val_step_0001000_val.json`
- `checkpoint_evals/full_val_step_0001000_val.csv`
- `checkpoint_evals/full_val_step_0001000_val_progress.json`

It uses the same DA3 projected-feature MSE, copy-last baseline, and DA3
depth/ray decoder metrics as the training validation path. It does not modify
the active DDP training process.

To leave this complete checkpoint evaluation waiting for the first scheduled
checkpoint:

```bash
INTERVAL_SECONDS=300 bash scripts/watch_checkpoint_full_eval.sh
```

The watcher appends the resulting full-val report, a fresh manifest, and a
process snapshot to `EXPERIMENT_LOG.md`.

When running the visualization watcher and the checkpoint full-val watcher at
the same time, pin them to different non-training GPUs so they do not compete for
memory:

```bash
DEVICE=cuda:6 INTERVAL_SECONDS=300 bash scripts/watch_checkpoint_visualization.sh
DEVICE=cuda:7 INTERVAL_SECONDS=300 bash scripts/watch_checkpoint_full_eval.sh
```

The interrupted run used this convention after the step-500 validation finished.

## Recovery Policy

Do not change the feature channel dimensions `[256,512,1024,1024]`, camera set,
image size, or full train/val data scope to handle failures.

If validation OOM occurs, first reduce only `train.val_batch_size` and/or
`train.decoder_chunk_size`. The configured formal validation path has already
been preflighted with `val_batch_size=4` and `decoder_chunk_size=1`, so this
should be a last-mile memory adjustment rather than a model change.

If training OOM occurs, lower per-GPU batch size and increase gradient
accumulation to preserve the intended effective batch size. Do not reduce token
dimensions or drop DA3 levels.

Future launches save `checkpoints/pre_validation_latest.pt` immediately before
scheduled validation, so a validation-time failure can be resumed from the last
completed optimizer step. The active run that was already launched before this
safety checkpoint patch may not have this file until restarted with the updated
code.

If a run must be resumed:

```bash
CONDA_ENV_NAME=da3 GPUS=2,3 bash scripts/start_remote_training.sh \
  --resume runs/deltatok_da3_front_back_700x252_8tok/checkpoints/pre_validation_latest.pt
```

Use `last.pt` or a numbered `step_*.pt` checkpoint when those are the latest
valid artifacts. Always run `bash scripts/analyze_run.sh` after resume and keep
`EXPERIMENT_LOG.md` updated with the reason for the restart.
