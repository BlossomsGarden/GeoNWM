<!-- 我现在创建了一个 [DeltaTok-DA3-nuscenes](DeltaTok-DA3-nuscenes/) 文件夹，里面有远程服务器的连接方式、DA3的模型，并且已经创建好了名为da3的conda环境，本地文件夹下也已经帮你拉取好了DA3的仓库demo源码与文档、DeltaTok的Github仓库源码，现在需要你做的是：在文件夹下落代码，仿照 [DeltaWorld.txt](0606-lightworldpred/DeltaWorld.txt) 里 Figure3 所示的 DeltaTok Encoder/Decoder训练模式、以及warmup/weightdecay/learningrate/MSE/gradient clip等等训练设置，使用nuscenes全量数据集进行训练（数据集加载与图片resize_crop逻辑可以照搬 [DVGT-Multi-Decoders](DVGT-Multi-Decoders/) 文件夹底下的加载逻辑，同时要尽可能用到所有数据以提高训练数据的数量），执行2卡DDP训练（现在cuda:2,3这两张48G显存的显卡上测试），训练一个针对 DA3的四层特征空间的DeltaTok编码器、解码器，并启动正式训练。记住，如果你需要拉取代码或者下载模型到服务器上，记得使用代理网站，因为这台服务器无法访问中国大陆外的网络。最后代码落完后首先写Readme介绍文件夹底下的模块、代码逻辑、具体验证思路等信息，然后上传到远程服务器开始训练，我需要特地指明的是：你这不是轻量化验证，你作为一名计算机领域的多年深耕多年的熟练、专业工作者，你是这个假说验证的主体。不能只抽几个pair简单测试代码能不能跑通，而是直接进行严谨地科学研究探索确认，要确保每一步都是正式训练它理论上是确实能训练到东西的，而不是只轻量化数据验证代码能跑，这是在无形中推卸严谨、专业、复杂的科学验证责任与义务，而是要将这个阶段的工作切实落出代码并正确编写专业训练代码运行，分析训练结果，如果不正确甚至还需要自行分析是不是哪里出错了然后做记录并修改重新启动。如果服务器显存有空余你可以增加batch_size来获得更快的训练速度。注意使用superpowers框架执行，并且自动使用必要的相关skill来实现高质量分析与实现 -->

注意为了加速训练，第一阶段暂时先只使用MSE loss吧

ip: 219.223.207.223

port: 22

user_name: wlh

password: wlh@2025

connect-tool: paramiko (already installed) or scp

# 请注意，不要创建什么文件软链接，直接让代码文件里的路径指向这些地方就行了

# 如果需要修改文件，直接在本地改改文件（如果没有就把必要文件拉下来），改完再scp推上去就完事了

# 除了可视化结果图片或视频可以拉一两个代表性的下来到本地，其他计算尽量都在云端完成，避免网络流量消耗

project_dir: /data/wlh/DA3/code

model_dir: /data/wlh/DA3/model/DA3NESTED-GIANT-LARGE-1.1

nuscenes_dir: /data2/DATA/AutoDrive/nuscenes/v1.0-trainval

conda_dir:/data/wlh/miniconda3

conda_env_name: da3

