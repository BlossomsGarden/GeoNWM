from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class DataConfig:
    nuscenes_root: str
    image_size: tuple[int, int]
    cameras: tuple[str, ...]
    max_frame_gap_factor: float
    train_split: str
    val_split: str


@dataclass(frozen=True)
class ModelConfig:
    da3_src: str
    da3_model_dir: str
    feature_channels: tuple[int, int, int, int]
    num_delta_tokens: int
    encoder_depth: int
    decoder_depth: int
    num_heads: tuple[int, int, int, int]
    mlp_ratio: float
    dropout: float
    use_checkpointing: bool


@dataclass(frozen=True)
class TrainConfig:
    output_dir: str
    seed: int
    max_steps: int
    batch_size: int
    batch_size_probe: tuple[int, ...]
    grad_accum_steps: int
    target_effective_batch_size: int
    num_workers: int
    lr: float
    warmup_steps: int
    weight_decay: float
    grad_clip_norm: float
    precision: str
    log_every_steps: int
    val_every_steps: int
    full_val_every_steps: int
    save_every_steps: int
    max_val_batches: int
    val_batch_size: int
    decoder_chunk_size: int
    resume: str | None


@dataclass(frozen=True)
class Config:
    data: DataConfig
    model: ModelConfig
    train: TrainConfig


def _as_tuple(value: Any, item_type: type = int) -> tuple:
    return tuple(item_type(x) for x in value)


def load_config(path: str | Path) -> Config:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    data = raw["data"]
    model = raw["model"]
    train = raw["train"]
    return Config(
        data=DataConfig(
            nuscenes_root=str(data["nuscenes_root"]),
            image_size=(int(data["image_size"][0]), int(data["image_size"][1])),
            cameras=_as_tuple(data["cameras"], str),
            max_frame_gap_factor=float(data.get("max_frame_gap_factor", 1.5)),
            train_split=str(data.get("train_split", "train")),
            val_split=str(data.get("val_split", "val")),
        ),
        model=ModelConfig(
            da3_src=str(model["da3_src"]),
            da3_model_dir=str(model["da3_model_dir"]),
            feature_channels=_as_tuple(model["feature_channels"], int),
            num_delta_tokens=int(model["num_delta_tokens"]),
            encoder_depth=int(model["encoder_depth"]),
            decoder_depth=int(model["decoder_depth"]),
            num_heads=_as_tuple(model["num_heads"], int),
            mlp_ratio=float(model.get("mlp_ratio", 4.0)),
            dropout=float(model.get("dropout", 0.0)),
            use_checkpointing=bool(model.get("use_checkpointing", True)),
        ),
        train=TrainConfig(
            output_dir=str(train["output_dir"]),
            seed=int(train.get("seed", 0)),
            max_steps=int(train["max_steps"]),
            batch_size=int(train["batch_size"]),
            batch_size_probe=_as_tuple(train.get("batch_size_probe", [train["batch_size"]]), int),
            grad_accum_steps=int(train.get("grad_accum_steps", 1)),
            target_effective_batch_size=int(train.get("target_effective_batch_size", 1024)),
            num_workers=int(train.get("num_workers", 8)),
            lr=float(train["lr"]),
            warmup_steps=int(train["warmup_steps"]),
            weight_decay=float(train["weight_decay"]),
            grad_clip_norm=float(train["grad_clip_norm"]),
            precision=str(train.get("precision", "bf16")),
            log_every_steps=int(train.get("log_every_steps", 10)),
            val_every_steps=int(train.get("val_every_steps", 500)),
            full_val_every_steps=int(train.get("full_val_every_steps", 5000)),
            save_every_steps=int(train.get("save_every_steps", 1000)),
            max_val_batches=int(train.get("max_val_batches", 64)),
            val_batch_size=int(train.get("val_batch_size", min(int(train.get("batch_size", 1)), 8))),
            decoder_chunk_size=int(train.get("decoder_chunk_size", 4)),
            resume=None if train.get("resume") in (None, "", "none", "null") else str(train["resume"]),
        ),
    )


def to_plain_dict(config: Config) -> dict[str, Any]:
    def plain(value: Any) -> Any:
        if isinstance(value, tuple):
            return [plain(x) for x in value]
        if isinstance(value, list):
            return [plain(x) for x in value]
        if isinstance(value, dict):
            return {str(k): plain(v) for k, v in value.items()}
        return value

    return {
        "data": plain(config.data.__dict__),
        "model": plain(config.model.__dict__),
        "train": plain(config.train.__dict__),
    }
