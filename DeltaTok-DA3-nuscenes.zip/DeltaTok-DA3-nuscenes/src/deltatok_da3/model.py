from __future__ import annotations

from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


class CrossAttentionBlock(nn.Module):
    def __init__(self, dim: int, num_heads: int, mlp_ratio: float, dropout: float) -> None:
        super().__init__()
        self.norm_q1 = nn.LayerNorm(dim)
        self.self_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout, batch_first=True)
        self.norm_q2 = nn.LayerNorm(dim)
        self.norm_mem = nn.LayerNorm(dim)
        self.cross_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout, batch_first=True)
        self.norm_q3 = nn.LayerNorm(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.Dropout(dropout),
        )

    def forward(self, q: torch.Tensor, memory: torch.Tensor) -> torch.Tensor:
        q = q + self.self_attn(self.norm_q1(q), self.norm_q1(q), self.norm_q1(q), need_weights=False)[0]
        q = q + self.cross_attn(
            self.norm_q2(q),
            self.norm_mem(memory),
            self.norm_mem(memory),
            need_weights=False,
        )[0]
        q = q + self.mlp(self.norm_q3(q))
        return q


class DecoderBlock(nn.Module):
    def __init__(self, dim: int, num_heads: int, mlp_ratio: float, dropout: float) -> None:
        super().__init__()
        self.norm_x1 = nn.LayerNorm(dim)
        self.norm_z = nn.LayerNorm(dim)
        self.cross_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout, batch_first=True)
        self.norm_x2 = nn.LayerNorm(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        x = x + self.cross_attn(self.norm_x1(x), self.norm_z(z), self.norm_z(z), need_weights=False)[0]
        x = x + self.mlp(self.norm_x2(x))
        return x


class LevelDeltaTok(nn.Module):
    def __init__(
        self,
        dim: int,
        num_delta_tokens: int,
        encoder_depth: int,
        decoder_depth: int,
        num_heads: int,
        mlp_ratio: float,
        dropout: float,
        max_patches: int,
        use_checkpointing: bool,
    ) -> None:
        super().__init__()
        self.dim = int(dim)
        self.num_delta_tokens = int(num_delta_tokens)
        self.use_checkpointing = bool(use_checkpointing)
        self.delta_queries = nn.Parameter(torch.empty(1, self.num_delta_tokens, self.dim))
        self.time_embed = nn.Parameter(torch.empty(2, self.dim))
        self.pos_embed = nn.Parameter(torch.empty(1, int(max_patches), self.dim))
        self.encoder_blocks = nn.ModuleList(
            [CrossAttentionBlock(self.dim, num_heads, mlp_ratio, dropout) for _ in range(encoder_depth)]
        )
        self.decoder_blocks = nn.ModuleList(
            [DecoderBlock(self.dim, num_heads, mlp_ratio, dropout) for _ in range(decoder_depth)]
        )
        self.out_norm = nn.LayerNorm(self.dim)
        self.residual_head = nn.Linear(self.dim, self.dim)
        self._init_weights()

    def _init_weights(self) -> None:
        nn.init.trunc_normal_(self.delta_queries, std=0.02)
        nn.init.trunc_normal_(self.time_embed, std=0.02)
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.trunc_normal_(module.weight, std=0.02)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
        nn.init.zeros_(self.residual_head.weight)
        nn.init.zeros_(self.residual_head.bias)

    def _pos(self, n: int, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
        if n > self.pos_embed.shape[1]:
            raise ValueError(f"Feature has {n} patches but max_patches={self.pos_embed.shape[1]}")
        return self.pos_embed[:, :n].to(device=device, dtype=dtype)

    def _run_encoder_block(
        self,
        block: CrossAttentionBlock,
        z: torch.Tensor,
        memory: torch.Tensor,
    ) -> torch.Tensor:
        if self.use_checkpointing and self.training:
            return checkpoint(block, z, memory, use_reentrant=False)
        return block(z, memory)

    def _run_decoder_block(
        self,
        block: DecoderBlock,
        x: torch.Tensor,
        z: torch.Tensor,
    ) -> torch.Tensor:
        if self.use_checkpointing and self.training:
            return checkpoint(block, x, z, use_reentrant=False)
        return block(x, z)

    def encode(self, prev_feat: torch.Tensor, curr_feat: torch.Tensor) -> torch.Tensor:
        if prev_feat.shape != curr_feat.shape:
            raise ValueError(f"Feature shapes differ: {tuple(prev_feat.shape)} vs {tuple(curr_feat.shape)}")
        b, n, c = prev_feat.shape
        if c != self.dim:
            raise ValueError(f"Expected dim={self.dim}, got {c}")
        pos = self._pos(n, prev_feat.dtype, prev_feat.device)
        prev = prev_feat + pos + self.time_embed[0].to(prev_feat.dtype).view(1, 1, c)
        curr = curr_feat + pos + self.time_embed[1].to(prev_feat.dtype).view(1, 1, c)
        memory = torch.cat([prev, curr], dim=1)
        z = self.delta_queries.to(dtype=prev_feat.dtype, device=prev_feat.device).expand(b, -1, -1)
        for block in self.encoder_blocks:
            z = self._run_encoder_block(block, z, memory)
        return z

    def decode(self, prev_feat: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        b, n, c = prev_feat.shape
        if c != self.dim:
            raise ValueError(f"Expected dim={self.dim}, got {c}")
        if z.shape != (b, self.num_delta_tokens, c):
            raise ValueError(f"Expected z {(b, self.num_delta_tokens, c)}, got {tuple(z.shape)}")
        x = prev_feat + self._pos(n, prev_feat.dtype, prev_feat.device)
        for block in self.decoder_blocks:
            x = self._run_decoder_block(block, x, z)
        residual = self.residual_head(self.out_norm(x))
        return prev_feat + residual

    def forward(self, prev_feat: torch.Tensor, curr_feat: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        z = self.encode(prev_feat, curr_feat)
        return self.decode(prev_feat, z), z


class MultiLevelDeltaTok(nn.Module):
    def __init__(
        self,
        feature_channels: Sequence[int],
        num_delta_tokens: int,
        encoder_depth: int,
        decoder_depth: int,
        num_heads: Sequence[int],
        mlp_ratio: float,
        dropout: float,
        max_patches: int,
        use_checkpointing: bool,
    ) -> None:
        super().__init__()
        self.feature_channels = tuple(int(x) for x in feature_channels)
        self.num_delta_tokens = int(num_delta_tokens)
        if len(self.feature_channels) != 4:
            raise ValueError("DeltaTok-DA3 expects exactly four DA3 feature levels")
        if len(num_heads) != 4:
            raise ValueError("num_heads must contain one entry per feature level")
        self.levels = nn.ModuleList(
            [
                LevelDeltaTok(
                    dim=dim,
                    num_delta_tokens=self.num_delta_tokens,
                    encoder_depth=encoder_depth,
                    decoder_depth=decoder_depth,
                    num_heads=int(heads),
                    mlp_ratio=mlp_ratio,
                    dropout=dropout,
                    max_patches=max_patches,
                    use_checkpointing=use_checkpointing,
                )
                for dim, heads in zip(self.feature_channels, num_heads)
            ]
        )

    def encode(
        self,
        prev_feats: Sequence[torch.Tensor],
        curr_feats: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        self._check_features(prev_feats)
        self._check_features(curr_feats)
        return [level.encode(prev, curr) for level, prev, curr in zip(self.levels, prev_feats, curr_feats)]

    def decode(
        self,
        prev_feats: Sequence[torch.Tensor],
        delta_tokens: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        self._check_features(prev_feats)
        if len(delta_tokens) != 4:
            raise ValueError(f"Expected four delta token groups, got {len(delta_tokens)}")
        return [level.decode(prev, z) for level, prev, z in zip(self.levels, prev_feats, delta_tokens)]

    def forward(
        self,
        prev_feats: Sequence[torch.Tensor],
        curr_feats: Sequence[torch.Tensor],
    ) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
        delta_tokens = self.encode(prev_feats, curr_feats)
        recon = self.decode(prev_feats, delta_tokens)
        return recon, delta_tokens

    def _check_features(self, features: Sequence[torch.Tensor]) -> None:
        if len(features) != 4:
            raise ValueError(f"Expected four feature levels, got {len(features)}")
        for idx, (feat, dim) in enumerate(zip(features, self.feature_channels)):
            if feat.ndim != 3:
                raise ValueError(f"Level {idx} must be [B,N,C], got {tuple(feat.shape)}")
            if feat.shape[-1] != dim:
                raise ValueError(f"Level {idx} has dim {feat.shape[-1]}, expected {dim}")


def multilevel_mse(
    pred: Sequence[torch.Tensor],
    target: Sequence[torch.Tensor],
) -> tuple[torch.Tensor, list[torch.Tensor]]:
    losses = [F.mse_loss(p.float(), t.detach().float()) for p, t in zip(pred, target)]
    return sum(losses) / len(losses), losses


def copy_last_mse(
    prev_feats: Sequence[torch.Tensor],
    curr_feats: Sequence[torch.Tensor],
) -> tuple[torch.Tensor, list[torch.Tensor]]:
    losses = [F.mse_loss(p.float(), c.detach().float()) for p, c in zip(prev_feats, curr_feats)]
    return sum(losses) / len(losses), losses
