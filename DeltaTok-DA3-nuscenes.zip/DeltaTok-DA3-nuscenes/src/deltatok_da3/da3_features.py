from __future__ import annotations

import sys
from pathlib import Path
from typing import Sequence

import torch
import torch.nn as nn
from addict import Dict


IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
IMAGENET_STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


def add_da3_to_path(da3_src: str) -> None:
    src = Path(da3_src).resolve()
    if str(src) not in sys.path:
        sys.path.insert(0, str(src))


class DA3ProjectedFeatureExtractor(nn.Module):
    """Frozen DA3 anyview branch feature extractor before DPT fusion."""

    def __init__(self, da3_src: str, model_dir: str, expected_channels: Sequence[int]) -> None:
        super().__init__()
        add_da3_to_path(da3_src)
        from depth_anything_3.api import DepthAnything3

        wrapper = DepthAnything3.from_pretrained(model_dir)
        self.da3 = wrapper.model.da3.eval()
        self.da3.requires_grad_(False)
        self.expected_channels = tuple(int(x) for x in expected_channels)
        self.patch_size = int(self.da3.head.patch_size)

    def train(self, mode: bool = True) -> "DA3ProjectedFeatureExtractor":
        super().train(False)
        self.da3.eval()
        return self

    @torch.no_grad()
    def forward(self, images: torch.Tensor) -> list[torch.Tensor]:
        """Return four projected DA3 feature maps as [B, N, C]."""
        if images.ndim != 4:
            raise ValueError(f"Expected images [B,3,H,W], got {tuple(images.shape)}")
        h, w = int(images.shape[-2]), int(images.shape[-1])
        if h % self.patch_size != 0 or w % self.patch_size != 0:
            raise ValueError(f"Input {(h, w)} must be divisible by patch size {self.patch_size}")
        mean = IMAGENET_MEAN.to(device=images.device, dtype=images.dtype)
        std = IMAGENET_STD.to(device=images.device, dtype=images.dtype)
        x = ((images - mean) / std).unsqueeze(1)
        feats, _ = self.da3.backbone(x, cam_token=None, export_feat_layers=[])
        return self.project_from_backbone_feats(feats, h, w)

    def project_from_backbone_feats(
        self,
        feats: list[torch.Tensor],
        h: int,
        w: int,
    ) -> list[torch.Tensor]:
        head = self.da3.head
        b, s, n, c = feats[0][0].shape
        if s != 1:
            raise ValueError(f"Single-view extractor expects S=1, got S={s}")
        ph, pw = h // self.patch_size, w // self.patch_size
        out = []
        for stage_idx, take_idx in enumerate(head.intermediate_layer_idx):
            x = feats[take_idx][0].reshape(b * s, n, c)
            x = head.norm(x)
            x = x.permute(0, 2, 1).reshape(b * s, c, ph, pw)
            x = head.projects[stage_idx](x)
            if x.shape[1] != self.expected_channels[stage_idx]:
                raise RuntimeError(
                    f"DA3 level {stage_idx} has {x.shape[1]} channels, "
                    f"expected {self.expected_channels[stage_idx]}"
                )
            out.append(x.flatten(2).transpose(1, 2).contiguous())
        return out

    @torch.no_grad()
    def decode_projected_features(
        self,
        features: Sequence[torch.Tensor],
        h: int,
        w: int,
    ) -> Dict:
        """Run the frozen DA3 DPT tail from projected pre-fusion features."""
        head = self.da3.head
        ph, pw = h // self.patch_size, w // self.patch_size
        resized_feats = []
        for stage_idx, feat in enumerate(features):
            b, n, c = feat.shape
            if n != ph * pw:
                raise ValueError(f"Level {stage_idx} has {n} patches, expected {ph * pw}")
            x = feat.transpose(1, 2).reshape(b, c, ph, pw)
            if head.pos_embed:
                x = head._add_pos_embed(x, w, h)
            x = head.resize_layers[stage_idx](x)
            resized_feats.append(x)

        fused_main, fused_aux_pyr = head._fuse(resized_feats)
        h_out = int(ph * self.patch_size / head.down_ratio)
        w_out = int(pw * self.patch_size / head.down_ratio)

        from depth_anything_3.model.utils.head_utils import custom_interpolate

        fused_main = custom_interpolate(
            fused_main, (h_out, w_out), mode="bilinear", align_corners=True
        )
        if head.pos_embed:
            fused_main = head._add_pos_embed(fused_main, w, h)
        main_logits = head.scratch.output_conv2(fused_main)
        fmap = main_logits.permute(0, 2, 3, 1)
        main_pred = head._apply_activation_single(fmap[..., :-1], head.activation)
        main_conf = head._apply_activation_single(fmap[..., -1], head.conf_activation)

        last_aux = fused_aux_pyr[-1]
        if head.pos_embed:
            last_aux = head._add_pos_embed(last_aux, w, h)
        last_aux_logits = head.scratch.output_conv2_aux[-1](last_aux)
        fmap_last = last_aux_logits.permute(0, 2, 3, 1)
        aux_pred = head._apply_activation_single(fmap_last[..., :-1], "linear")
        aux_conf = head._apply_activation_single(fmap_last[..., -1], head.conf_activation)
        return Dict(
            {
                head.head_main: main_pred.squeeze(-1),
                f"{head.head_main}_conf": main_conf,
                head.head_aux: aux_pred,
                f"{head.head_aux}_conf": aux_conf,
            }
        )


def feature_maps_to_grids(features: list[torch.Tensor], h: int, w: int, patch_size: int) -> list[torch.Tensor]:
    ph, pw = h // patch_size, w // patch_size
    grids = []
    for feat in features:
        grids.append(feat.transpose(1, 2).reshape(feat.shape[0], feat.shape[-1], ph, pw))
    return grids
