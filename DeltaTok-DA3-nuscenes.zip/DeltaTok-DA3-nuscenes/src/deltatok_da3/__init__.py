"""DeltaTok training in DA3 projected feature space."""

