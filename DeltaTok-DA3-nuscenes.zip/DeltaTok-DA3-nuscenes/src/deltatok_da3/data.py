from __future__ import annotations

import math
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF


@dataclass(frozen=True)
class ImageGeometry:
    original_hw: tuple[int, int]
    pre_crop_yx: tuple[int, int]
    pre_crop_hw: tuple[int, int]
    resized_hw: tuple[int, int]
    final_crop_yx: tuple[int, int]
    target_hw: tuple[int, int]


def resolve_nuscenes_path(root: Path, path_value: str) -> Path:
    rel = path_value.replace("./data/nuscenes/", "")
    return root / rel


def principal_point_crop(
    width: int,
    height: int,
    intrinsics: np.ndarray,
    target_width: int,
    target_height: int,
    *,
    strict: bool,
) -> tuple[int, int, int, int, np.ndarray]:
    intr = intrinsics.copy()
    cx = float(intr[0, 2])
    cy = float(intr[1, 2])
    if strict:
        crop_w = int(target_width)
        crop_h = int(target_height)
        start_x = int(math.floor(cx - crop_w / 2.0))
        start_y = int(math.floor(cy - crop_h / 2.0))
        start_x = max(0, min(start_x, width - crop_w))
        start_y = max(0, min(start_y, height - crop_h))
    else:
        half_x = min(target_width / 2.0, cx, width - cx)
        half_y = min(target_height / 2.0, cy, height - cy)
        crop_w = max(1, min(width, 2 * int(math.floor(half_x))))
        crop_h = max(1, min(height, 2 * int(math.floor(half_y))))
        start_x = int(math.floor(cx) - crop_w // 2)
        start_y = int(math.floor(cy) - crop_h // 2)
        start_x = max(0, min(start_x, width - crop_w))
        start_y = max(0, min(start_y, height - crop_h))
    intr[0, 2] -= float(start_x)
    intr[1, 2] -= float(start_y)
    return start_x, start_y, crop_w, crop_h, intr


def resize_crop_image_and_intrinsics(
    image: Image.Image,
    intrinsics: np.ndarray,
    target_width: int,
    target_height: int,
    *,
    safe_bound: int = 4,
) -> tuple[torch.Tensor, np.ndarray, ImageGeometry]:
    """DVGT-style aspect-preserving resize followed by principal-point crop."""
    original_width, original_height = image.size
    intr = intrinsics.astype(np.float32, copy=True)

    pre_x, pre_y, pre_w, pre_h, intr = principal_point_crop(
        original_width,
        original_height,
        intr,
        original_width,
        original_height,
        strict=False,
    )
    if pre_x or pre_y or pre_w != original_width or pre_h != original_height:
        image = image.crop((pre_x, pre_y, pre_x + pre_w, pre_y + pre_h))

    scale = max(
        (float(target_width) + float(safe_bound)) / float(pre_w),
        (float(target_height) + float(safe_bound)) / float(pre_h),
    )
    resized_width = max(target_width, int(math.floor(pre_w * scale)))
    resized_height = max(target_height, int(math.floor(pre_h * scale)))
    resample = Image.Resampling.LANCZOS if scale < 1.0 else Image.Resampling.BICUBIC
    image = image.resize((resized_width, resized_height), resample=resample)

    scale_x = resized_width / float(pre_w)
    scale_y = resized_height / float(pre_h)
    intr[0, 2] += 0.5
    intr[1, 2] += 0.5
    intr[0, 0] *= scale_x
    intr[1, 1] *= scale_y
    intr[0, 2] *= scale_x
    intr[1, 2] *= scale_y
    intr[0, 2] -= 0.5
    intr[1, 2] -= 0.5

    final_x, final_y, crop_w, crop_h, intr = principal_point_crop(
        resized_width,
        resized_height,
        intr,
        target_width,
        target_height,
        strict=True,
    )
    if crop_w != target_width or crop_h != target_height:
        raise RuntimeError(f"Invalid final crop {(crop_w, crop_h)} for target {(target_width, target_height)}")
    image = image.crop((final_x, final_y, final_x + target_width, final_y + target_height))
    geometry = ImageGeometry(
        original_hw=(original_height, original_width),
        pre_crop_yx=(pre_y, pre_x),
        pre_crop_hw=(pre_h, pre_w),
        resized_hw=(resized_height, resized_width),
        final_crop_yx=(final_y, final_x),
        target_hw=(target_height, target_width),
    )
    return TF.to_tensor(image), intr.astype(np.float32, copy=False), geometry


class NuScenesPairDataset(Dataset):
    """Adjacent keyframe pair dataset for CAM_FRONT/CAM_BACK DeltaTok training."""

    def __init__(
        self,
        root: str,
        split: str,
        image_size: tuple[int, int],
        cameras: tuple[str, ...],
        max_frame_gap_factor: float = 1.5,
    ) -> None:
        self.root = Path(root)
        self.split = split
        self.width, self.height = int(image_size[0]), int(image_size[1])
        self.cameras = tuple(cameras)
        if self.width % 14 != 0 or self.height % 14 != 0:
            raise ValueError(f"DA3 image_size must be divisible by 14, got {(self.width, self.height)}")
        info_path = self.root / f"nuscenes_infos_{'train' if split == 'train' else 'val'}.pkl"
        with info_path.open("rb") as f:
            infos = pickle.load(f)["infos"]
        self.pairs = self._build_pairs(infos, max_frame_gap_factor)
        if not self.pairs:
            raise RuntimeError(f"No adjacent nuScenes pairs found for split={split}")

    def _scene_key(self, info: dict[str, Any]) -> str:
        if info.get("scene_token"):
            return str(info["scene_token"])
        lidar_name = Path(str(info["lidar_path"])).name
        if "__" in lidar_name:
            return lidar_name.split("__", 1)[0]
        raise KeyError(f"Cannot infer scene token from {lidar_name}")

    def _timestamp(self, info: dict[str, Any]) -> int:
        if info.get("timestamp") is not None:
            return int(info["timestamp"])
        lidar_name = Path(str(info["lidar_path"])).name
        parts = lidar_name.split("__")
        if len(parts) >= 3:
            return int(parts[2].split(".", 1)[0])
        raise KeyError(f"Cannot infer timestamp from {lidar_name}")

    def _has_camera_images(self, info: dict[str, Any]) -> bool:
        for cam in self.cameras:
            if cam not in info.get("cams", {}):
                return False
            path = resolve_nuscenes_path(self.root, info["cams"][cam]["data_path"])
            if not path.exists():
                return False
        return True

    def _build_pairs(
        self,
        infos: list[dict[str, Any]],
        max_frame_gap_factor: float,
    ) -> list[tuple[dict[str, Any], dict[str, Any], str]]:
        groups: dict[str, list[dict[str, Any]]] = {}
        for info in infos:
            if self._has_camera_images(info):
                groups.setdefault(self._scene_key(info), []).append(info)
        max_gap_us = (1_000_000.0 / 2.0) * float(max_frame_gap_factor)
        pairs = []
        for group in groups.values():
            ordered = sorted(group, key=self._timestamp)
            for prev, curr in zip(ordered, ordered[1:]):
                if self._timestamp(curr) <= self._timestamp(prev):
                    continue
                if (self._timestamp(curr) - self._timestamp(prev)) > max_gap_us:
                    continue
                for cam in self.cameras:
                    pairs.append((prev, curr, cam))
        pairs.sort(key=lambda item: (self._scene_key(item[0]), self._timestamp(item[0]), item[2]))
        return pairs

    def __len__(self) -> int:
        return len(self.pairs)

    def _load_view(self, info: dict[str, Any], cam: str) -> tuple[torch.Tensor, str]:
        cam_info = info["cams"][cam]
        path = resolve_nuscenes_path(self.root, cam_info["data_path"])
        image = Image.open(path).convert("RGB")
        intr = np.asarray(cam_info["camera_intrinsics"], dtype=np.float32)
        tensor, _, _ = resize_crop_image_and_intrinsics(image, intr, self.width, self.height)
        return tensor, str(path.relative_to(self.root))

    def __getitem__(self, idx: int) -> dict[str, Any]:
        prev, curr, cam = self.pairs[idx]
        prev_img, prev_rel = self._load_view(prev, cam)
        curr_img, curr_rel = self._load_view(curr, cam)
        return {
            "prev_image": prev_img,
            "curr_image": curr_img,
            "camera": cam,
            "prev_path": prev_rel,
            "curr_path": curr_rel,
            "prev_token": str(prev["token"]),
            "curr_token": str(curr["token"]),
            "prev_timestamp": self._timestamp(prev),
            "curr_timestamp": self._timestamp(curr),
        }


def collate_pairs(samples: list[dict[str, Any]]) -> dict[str, Any]:
    tensor_keys = {"prev_image", "curr_image"}
    out: dict[str, Any] = {}
    for key in samples[0].keys():
        if key in tensor_keys:
            out[key] = torch.stack([s[key] for s in samples], dim=0)
        elif key.endswith("timestamp"):
            out[key] = torch.tensor([s[key] for s in samples], dtype=torch.long)
        else:
            out[key] = [s[key] for s in samples]
    return out

