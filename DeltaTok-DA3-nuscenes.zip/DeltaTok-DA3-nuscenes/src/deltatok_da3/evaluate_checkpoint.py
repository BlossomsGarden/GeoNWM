from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from pathlib import Path
from typing import Any

import torch
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deltatok_da3.config import load_config
from deltatok_da3.da3_features import DA3ProjectedFeatureExtractor
from deltatok_da3.data import NuScenesPairDataset, collate_pairs
from deltatok_da3.model import MultiLevelDeltaTok, copy_last_mse, multilevel_mse
from deltatok_da3.train import (
    decoder_mse_chunked,
    extract_pair_features,
    move_batch,
    precision_context,
)


METRIC_NAMES = [
    "val_mse",
    "val_copy_mse",
    "val_level1_mse",
    "val_level2_mse",
    "val_level3_mse",
    "val_level4_mse",
    "val_copy_level1_mse",
    "val_copy_level2_mse",
    "val_copy_level3_mse",
    "val_copy_level4_mse",
    "val_depth_mse",
    "val_copy_depth_mse",
    "val_ray_mse",
    "val_copy_ray_mse",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate a DeltaTok-DA3 checkpoint on nuScenes pairs.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--split", default="val", choices=("train", "val"))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--precision", default=None, choices=(None, "bf16", "fp16", "fp32"))
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--decoder-chunk-size", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--max-batches", type=int, default=None)
    parser.add_argument("--tag", default="full_val")
    parser.add_argument("--log-every-batches", type=int, default=50)
    parser.add_argument("--write-progress-every", type=int, default=50)
    return parser.parse_args()


def build_model_from_config(config: Any, max_patches: int) -> MultiLevelDeltaTok:
    return MultiLevelDeltaTok(
        feature_channels=config.model.feature_channels,
        num_delta_tokens=config.model.num_delta_tokens,
        encoder_depth=config.model.encoder_depth,
        decoder_depth=config.model.decoder_depth,
        num_heads=config.model.num_heads,
        mlp_ratio=config.model.mlp_ratio,
        dropout=config.model.dropout,
        max_patches=max_patches,
        use_checkpointing=False,
    )


def build_eval_loader(
    dataset: NuScenesPairDataset,
    batch_size: int,
    num_workers: int,
) -> DataLoader:
    sampler = DistributedSampler(
        dataset,
        num_replicas=1,
        rank=0,
        shuffle=False,
        drop_last=False,
    )
    return DataLoader(
        dataset,
        batch_size=batch_size,
        sampler=sampler,
        shuffle=False,
        drop_last=False,
        num_workers=num_workers,
        pin_memory=True,
        persistent_workers=num_workers > 0,
        collate_fn=collate_pairs,
    )


def rel_improvement(value: float | None, copy_value: float | None) -> float | None:
    if value is None or copy_value is None or abs(copy_value) < 1e-12:
        return None
    return 1.0 - value / copy_value


def metrics_from_total(total: torch.Tensor) -> dict[str, float]:
    denom = float(total[-1].item())
    if denom <= 0:
        raise RuntimeError("Evaluation produced no samples.")
    return {name: float(total[idx].item() / denom) for idx, name in enumerate(METRIC_NAMES)}


def finite_audit(metrics: dict[str, float]) -> list[dict[str, Any]]:
    bad = []
    for key, value in metrics.items():
        if not math.isfinite(float(value)):
            bad.append({"field": key, "value": value})
    return bad


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
    tmp.replace(path)


def write_csv(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)


def make_report(
    *,
    args: argparse.Namespace,
    checkpoint_step: int,
    dataset_size: int,
    num_batches: int,
    total: torch.Tensor,
    elapsed_sec: float,
    final: bool,
) -> dict[str, Any]:
    metrics = metrics_from_total(total)
    return {
        "status": "complete" if final else "running",
        "checkpoint": str(Path(args.checkpoint)),
        "checkpoint_step": int(checkpoint_step),
        "split": args.split,
        "dataset_size": int(dataset_size),
        "max_batches": args.max_batches,
        "num_batches": int(num_batches),
        "num_samples": int(total[-1].item()),
        "elapsed_sec": float(elapsed_sec),
        "samples_per_sec": float(total[-1].item() / max(elapsed_sec, 1e-6)),
        "relative_improvement": rel_improvement(metrics["val_mse"], metrics["val_copy_mse"]),
        "depth_relative_improvement": rel_improvement(metrics["val_depth_mse"], metrics["val_copy_depth_mse"]),
        "ray_relative_improvement": rel_improvement(metrics["val_ray_mse"], metrics["val_copy_ray_mse"]),
        "level_relative_improvement": {
            f"level{idx}": rel_improvement(
                metrics[f"val_level{idx}_mse"],
                metrics[f"val_copy_level{idx}_mse"],
            )
            for idx in range(1, 5)
        },
        "non_finite_values": finite_audit(metrics),
        "metrics": metrics,
    }


@torch.no_grad()
def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    precision = args.precision or config.train.precision
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(device)
        torch.set_float32_matmul_precision("high")

    batch_size = int(args.batch_size or config.train.val_batch_size)
    decoder_chunk_size = int(args.decoder_chunk_size or config.train.decoder_chunk_size)
    num_workers = int(config.train.num_workers if args.num_workers is None else args.num_workers)
    output_dir = Path(args.output_dir) if args.output_dir else Path(config.train.output_dir) / "checkpoint_evals"
    output_dir.mkdir(parents=True, exist_ok=True)

    split_name = config.data.val_split if args.split == "val" else config.data.train_split
    dataset = NuScenesPairDataset(
        root=config.data.nuscenes_root,
        split=split_name,
        image_size=config.data.image_size,
        cameras=config.data.cameras,
        max_frame_gap_factor=config.data.max_frame_gap_factor,
    )
    loader = build_eval_loader(dataset, batch_size=batch_size, num_workers=num_workers)
    max_patches = (config.data.image_size[0] // 14) * (config.data.image_size[1] // 14)

    extractor = DA3ProjectedFeatureExtractor(
        config.model.da3_src,
        config.model.da3_model_dir,
        config.model.feature_channels,
    ).to(device)
    model = build_model_from_config(config, max_patches=max_patches).to(device).eval()
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model.load_state_dict(checkpoint["model"], strict=True)
    checkpoint_step = int(checkpoint.get("step", -1))

    progress_path = output_dir / f"{args.tag}_step_{checkpoint_step:07d}_{args.split}_progress.json"
    json_path = output_dir / f"{args.tag}_step_{checkpoint_step:07d}_{args.split}.json"
    csv_path = output_dir / f"{args.tag}_step_{checkpoint_step:07d}_{args.split}.csv"

    total = torch.zeros(len(METRIC_NAMES) + 1, device=device, dtype=torch.float64)
    num_batches = 0
    t0 = time.time()
    print(
        "eval_start "
        f"checkpoint_step={checkpoint_step} split={args.split} dataset_size={len(dataset)} "
        f"batch_size={batch_size} decoder_chunk_size={decoder_chunk_size} "
        f"max_batches={args.max_batches} device={device}",
        flush=True,
    )

    for batch in loader:
        prev, curr = move_batch(batch, device)
        prev_feats, curr_feats = extract_pair_features(extractor, prev, curr, precision, device)
        with precision_context(device, precision):
            pred, _ = model(prev_feats, curr_feats)
        loss, level_losses = multilevel_mse(pred, curr_feats)
        copy_loss, copy_levels = copy_last_mse(prev_feats, curr_feats)
        depth_mse, copy_depth_mse, ray_mse, copy_ray_mse = decoder_mse_chunked(
            extractor,
            pred,
            prev_feats,
            curr_feats,
            prev.shape[-2],
            prev.shape[-1],
            precision,
            device,
            decoder_chunk_size,
        )
        bs = float(prev.shape[0])
        values = [
            loss * bs,
            copy_loss * bs,
            *[level_loss * bs for level_loss in level_losses],
            *[copy_level * bs for copy_level in copy_levels],
            depth_mse * bs,
            copy_depth_mse * bs,
            ray_mse * bs,
            copy_ray_mse * bs,
            torch.tensor(bs, device=device),
        ]
        total += torch.tensor([float(v.detach().cpu()) for v in values], device=device, dtype=torch.float64)
        num_batches += 1

        if args.max_batches is not None and num_batches >= args.max_batches:
            break

        should_log = args.log_every_batches > 0 and num_batches % args.log_every_batches == 0
        should_write = args.write_progress_every > 0 and num_batches % args.write_progress_every == 0
        if should_log or should_write:
            report = make_report(
                args=args,
                checkpoint_step=checkpoint_step,
                dataset_size=len(dataset),
                num_batches=num_batches,
                total=total,
                elapsed_sec=time.time() - t0,
                final=False,
            )
            if should_write:
                write_json_atomic(progress_path, report)
            if should_log:
                metrics = report["metrics"]
                print(
                    "eval_progress "
                    f"batches={num_batches} samples={report['num_samples']} "
                    f"val_mse={metrics['val_mse']:.8g} copy={metrics['val_copy_mse']:.8g} "
                    f"rel={report['relative_improvement']:.6g}",
                    flush=True,
                )
            if device.type == "cuda":
                torch.cuda.empty_cache()

    elapsed = time.time() - t0
    report = make_report(
        args=args,
        checkpoint_step=checkpoint_step,
        dataset_size=len(dataset),
        num_batches=num_batches,
        total=total,
        elapsed_sec=elapsed,
        final=True,
    )
    write_json_atomic(json_path, report)
    write_json_atomic(progress_path, report)
    row = {
        "checkpoint_step": checkpoint_step,
        "split": args.split,
        "dataset_size": len(dataset),
        "max_batches": args.max_batches,
        "num_batches": num_batches,
        "num_samples": report["num_samples"],
        "elapsed_sec": elapsed,
        "samples_per_sec": report["samples_per_sec"],
        "relative_improvement": report["relative_improvement"],
        "depth_relative_improvement": report["depth_relative_improvement"],
        "ray_relative_improvement": report["ray_relative_improvement"],
        **report["level_relative_improvement"],
        **report["metrics"],
    }
    write_csv(csv_path, row)
    print(f"eval_complete json={json_path} csv={csv_path}", flush=True)
    print(
        "eval_result "
        f"val_mse={report['metrics']['val_mse']:.8g} "
        f"copy={report['metrics']['val_copy_mse']:.8g} "
        f"rel={report['relative_improvement']:.6g} "
        f"depth_rel={report['depth_relative_improvement']:.6g} "
        f"ray_rel={report['ray_relative_improvement']:.6g}",
        flush=True,
    )


if __name__ == "__main__":
    main()
