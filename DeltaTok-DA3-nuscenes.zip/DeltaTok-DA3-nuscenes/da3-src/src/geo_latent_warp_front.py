#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from contextlib import contextmanager
from glob import glob
from pathlib import Path
from typing import Iterable

import cv2
import imageio.v2 as imageio
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

from depth_anything_3.api import DepthAnything3
from depth_anything_3.utils.visualize import visualize_depth


DEFAULT_SCENE_DIR = (
    "/data/wlh/FreeDrive/data/waymo/processed-test/"
    "segment-10061305430875486848_1080_000_1100_000_with_camera_labels"
)
DEFAULT_MODEL_DIR = "/data/wlh/DA3/model/DA3NESTED-GIANT-LARGE-1.1"
DEFAULT_OUTPUT_DIR = "outputs/geo_latent_warp_front_000_to_006"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Test DA3 decoder geo-latent feature warp from FRONT frame 000 to 006."
    )
    parser.add_argument("--scene-dir", default=DEFAULT_SCENE_DIR)
    parser.add_argument("--model-dir", default=DEFAULT_MODEL_DIR)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--camera-id", type=int, default=0, help="Waymo FRONT camera id.")
    parser.add_argument("--num-frames", type=int, default=7)
    parser.add_argument("--source-frame", type=int, default=0)
    parser.add_argument("--target-frame", type=int, default=6)
    parser.add_argument("--process-res", type=int, default=672)
    parser.add_argument("--process-res-method", default="upper_bound_resize")
    parser.add_argument("--raw-width", type=int, default=1920)
    parser.add_argument("--raw-height", type=int, default=1280)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--no-strict-size", action="store_true")
    parser.add_argument("--save-all-frame-depths", action="store_true")
    return parser.parse_args()


def load_intrinsic_for_image(
    intrinsics_dir: Path,
    cam_id: int,
    raw_size: tuple[int, int],
    image_size: tuple[int, int],
) -> np.ndarray:
    vals = np.loadtxt(intrinsics_dir / f"{cam_id}.txt").reshape(-1)
    fx, fy, cx, cy = vals[:4]
    raw_w, raw_h = raw_size
    image_w, image_h = image_size
    sx = image_w / float(raw_w)
    sy = image_h / float(raw_h)
    return np.array(
        [[fx * sx, 0.0, cx * sx], [0.0, fy * sy, cy * sy], [0.0, 0.0, 1.0]],
        dtype=np.float32,
    )


def load_camera_to_ego(extrinsics_dir: Path, cam_id: int) -> np.ndarray:
    return np.loadtxt(extrinsics_dir / f"{cam_id}.txt").reshape(4, 4).astype(np.float32)


def load_ego_poses(ego_pose_dir: Path, frame_ids: Iterable[int]) -> dict[int, np.ndarray]:
    pose_files = {
        int(Path(p).stem): Path(p)
        for p in glob(str(ego_pose_dir / "*.txt"))
        if Path(p).stem.isdigit()
    }
    out: dict[int, np.ndarray] = {}
    for frame_id in frame_ids:
        if frame_id not in pose_files:
            raise FileNotFoundError(f"Missing ego pose for frame {frame_id:03d} in {ego_pose_dir}")
        out[frame_id] = np.loadtxt(pose_files[frame_id]).reshape(4, 4).astype(np.float32)
    return out


def waymo_to_cv_coordinate_transform() -> np.ndarray:
    return np.array(
        [
            [0.0, -1.0, 0.0, 0.0],
            [0.0, 0.0, -1.0, 0.0],
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ],
        dtype=np.float32,
    )


def compute_world_to_camera(cam_to_ego: np.ndarray, ego_to_world: np.ndarray) -> np.ndarray:
    waymo_to_cv = waymo_to_cv_coordinate_transform()
    cv_to_waymo = np.linalg.inv(waymo_to_cv)
    cam_to_ego_cv = waymo_to_cv @ cam_to_ego @ cv_to_waymo
    ego_to_world_cv = waymo_to_cv @ ego_to_world @ cv_to_waymo
    world_to_ego_cv = np.linalg.inv(ego_to_world_cv)
    ego_to_cam_cv = np.linalg.inv(cam_to_ego_cv)
    return (ego_to_cam_cv @ world_to_ego_cv).astype(np.float32)


def make_homogeneous_w2c(extrinsics: np.ndarray) -> np.ndarray:
    if extrinsics.shape[-2:] == (4, 4):
        return extrinsics.astype(np.float32)
    if extrinsics.shape[-2:] != (3, 4):
        raise ValueError(f"Expected extrinsics [...,3,4] or [...,4,4], got {extrinsics.shape}")
    bottom = np.zeros((*extrinsics.shape[:-2], 1, 4), dtype=np.float32)
    bottom[..., 0, 3] = 1.0
    return np.concatenate([extrinsics.astype(np.float32), bottom], axis=-2)


def resolve_head(model: DepthAnything3) -> torch.nn.Module:
    net = model.model
    if hasattr(net, "da3"):
        return net.da3.head
    if hasattr(net, "head"):
        return net.head
    raise AttributeError("Could not find DA3 DPT head on model.model")


@contextmanager
def capture_decoder_feats(model: DepthAnything3):
    captured: dict[str, list[torch.Tensor]] = {}
    head = resolve_head(model)
    original_fuse = head._fuse

    def head_pre_hook(module, args, kwargs):
        feats = kwargs.get("feats", args[0] if args else None)
        if feats is None:
            raise RuntimeError("DPT head pre-hook did not receive feats.")
        captured["token_feats"] = [item[0].detach().float().cpu() for item in feats]

    def wrapped_fuse(pyramid_feats):
        captured["pyramid_feats"] = [item.detach().float().cpu() for item in pyramid_feats]
        return original_fuse(pyramid_feats)

    head_handle = head.register_forward_pre_hook(head_pre_hook, with_kwargs=True)
    head._fuse = wrapped_fuse
    try:
        yield captured
    finally:
        head._fuse = original_fuse
        head_handle.remove()


def prepare_inputs(args: argparse.Namespace) -> tuple[list[str], np.ndarray, np.ndarray]:
    scene = Path(args.scene_dir)
    images_dir = scene / "images"
    intrinsics_dir = scene / "intrinsics"
    extrinsics_dir = scene / "extrinsics"
    ego_pose_dir = scene / "ego_pose"
    frame_ids = list(range(args.num_frames))

    image_paths = [images_dir / f"{frame_id:03d}_{args.camera_id}.jpg" for frame_id in frame_ids]
    missing = [str(p) for p in image_paths if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing input images:\n" + "\n".join(missing))

    with Image.open(image_paths[0]) as im:
        image_size = im.size
    K = load_intrinsic_for_image(
        intrinsics_dir,
        args.camera_id,
        raw_size=(args.raw_width, args.raw_height),
        image_size=image_size,
    )
    cam_to_ego = load_camera_to_ego(extrinsics_dir, args.camera_id)
    ego_poses = load_ego_poses(ego_pose_dir, frame_ids)

    intrinsics = np.stack([K.copy() for _ in frame_ids], axis=0).astype(np.float32)
    extrinsics = np.stack(
        [compute_world_to_camera(cam_to_ego, ego_poses[frame_id]) for frame_id in frame_ids],
        axis=0,
    ).astype(np.float32)
    return [str(p) for p in image_paths], extrinsics, intrinsics


def decoder_feats_to_chw(
    captured_feats: list[torch.Tensor],
    view_indices: list[int],
    image_hw: tuple[int, int],
    patch_size: int = 14,
) -> dict[str, torch.Tensor]:
    h, w = image_hw
    ph, pw = h // patch_size, w // patch_size
    out: dict[str, torch.Tensor] = {}
    for layer_idx, feat in enumerate(captured_feats):
        if feat.ndim != 4:
            raise ValueError(f"Expected captured feat [B,S,N,C], got {tuple(feat.shape)}")
        b, s, n, c = feat.shape
        if b != 1:
            raise ValueError(f"This script expects batch size 1, got {b}")
        if n != ph * pw:
            raise ValueError(
                f"Feature layer {layer_idx} token count {n} does not match {ph}*{pw}."
            )
        selected = feat[0, view_indices].reshape(len(view_indices), ph, pw, c)
        out[f"layer_{layer_idx}"] = selected.permute(0, 3, 1, 2).contiguous()
    return out


def decoder_pyramid_to_chw(
    captured_pyramid_feats: list[torch.Tensor],
    view_indices: list[int],
) -> dict[str, torch.Tensor]:
    out: dict[str, torch.Tensor] = {}
    for layer_idx, feat in enumerate(captured_pyramid_feats):
        if feat.ndim != 4:
            raise ValueError(f"Expected pyramid feat [B*S,C,H,W], got {tuple(feat.shape)}")
        bad = [idx for idx in view_indices if idx < 0 or idx >= feat.shape[0]]
        if bad:
            raise IndexError(f"View indices {bad} out of range for feature shape {tuple(feat.shape)}")
        out[f"layer_{layer_idx}"] = feat[view_indices].contiguous()
    return out


def resize_depth_to_feature(depth_hw: torch.Tensor, feature_hw: tuple[int, int]) -> torch.Tensor:
    return F.interpolate(
        depth_hw[None, None].float(),
        size=feature_hw,
        mode="bilinear",
        align_corners=False,
    )[0, 0]


def warp_feature_forward(
    src_feature_chw: torch.Tensor,
    src_depth_hw: torch.Tensor,
    src_intr: torch.Tensor,
    tgt_intr: torch.Tensor,
    src_w2c: torch.Tensor,
    tgt_w2c: torch.Tensor,
    image_hw: tuple[int, int],
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if src_feature_chw.ndim != 3:
        raise ValueError(f"Expected source feature [C,Hf,Wf], got {tuple(src_feature_chw.shape)}")
    device = src_feature_chw.device
    dtype = torch.float32
    feat = src_feature_chw.float()
    c, hf, wf = feat.shape
    img_h, img_w = image_hw
    depth_f = resize_depth_to_feature(src_depth_hw.to(device), (hf, wf)).to(device, dtype)

    y, x = torch.meshgrid(
        torch.arange(hf, device=device, dtype=dtype),
        torch.arange(wf, device=device, dtype=dtype),
        indexing="ij",
    )
    u_src = (x + 0.5) * (img_w / wf) - 0.5
    v_src = (y + 0.5) * (img_h / hf) - 0.5
    ones = torch.ones_like(u_src)
    pix = torch.stack([u_src, v_src, ones], dim=0).reshape(3, -1)
    z = depth_f.reshape(-1)

    inv_src_intr = torch.linalg.inv(src_intr.to(device=device, dtype=dtype))
    src_xyz = inv_src_intr @ pix
    src_xyz = src_xyz * z.unsqueeze(0)
    src_xyz_h = torch.cat([src_xyz, ones.reshape(1, -1)], dim=0)

    src_c2w = torch.linalg.inv(src_w2c.to(device=device, dtype=dtype))
    world = src_c2w @ src_xyz_h
    tgt = tgt_w2c.to(device=device, dtype=dtype) @ world
    tgt_z = tgt[2]
    proj = tgt_intr.to(device=device, dtype=dtype) @ tgt[:3]
    u_t = proj[0] / tgt_z.clamp_min(1e-6)
    v_t = proj[1] / tgt_z.clamp_min(1e-6)

    x_t = torch.round((u_t + 0.5) * (wf / img_w) - 0.5).long()
    y_t = torch.round((v_t + 0.5) * (hf / img_h) - 0.5).long()
    valid = (
        torch.isfinite(z)
        & torch.isfinite(tgt_z)
        & (z > 1e-5)
        & (tgt_z > 1e-5)
        & (u_t >= 0)
        & (u_t < img_w)
        & (v_t >= 0)
        & (v_t < img_h)
        & (x_t >= 0)
        & (x_t < wf)
        & (y_t >= 0)
        & (y_t < hf)
    )

    warped = torch.zeros((c, hf, wf), device=device, dtype=feat.dtype)
    valid_mask = torch.zeros((1, hf, wf), device=device, dtype=feat.dtype)
    z_buffer = torch.full((hf, wf), float("inf"), device=device, dtype=dtype)
    if valid.any():
        idx = torch.nonzero(valid, as_tuple=False).flatten()
        order = torch.argsort(tgt_z[idx], descending=True)
        flat_feat = feat.reshape(c, -1)
        for point_idx in idx[order].tolist():
            yy = int(y_t[point_idx].item())
            xx = int(x_t[point_idx].item())
            zz = tgt_z[point_idx]
            if zz <= z_buffer[yy, xx]:
                warped[:, yy, xx] = flat_feat[:, point_idx]
                valid_mask[:, yy, xx] = 1.0
                z_buffer[yy, xx] = zz
    occlusion_mask = 1.0 - valid_mask
    return warped, valid_mask, occlusion_mask


def fit_pca_rgb(features: list[torch.Tensor], masks: list[torch.Tensor | None]) -> tuple[torch.Tensor, torch.Tensor]:
    rows = []
    for feat, mask in zip(features, masks):
        flat = feat.float().permute(1, 2, 0).reshape(-1, feat.shape[0])
        if mask is not None:
            keep = mask.reshape(-1).float() > 0.5
            if keep.any():
                flat = flat[keep]
        flat = flat[torch.isfinite(flat).all(dim=1)]
        rows.append(flat)
    data = torch.cat(rows, dim=0)
    if data.shape[0] < 3:
        raise ValueError("Need at least 3 finite feature vectors for PCA.")
    mean = data.mean(dim=0)
    centered = data - mean
    _, _, vh = torch.linalg.svd(centered, full_matrices=False)
    basis = vh[:3].T.contiguous()
    return mean, basis


def project_pca_rgb(
    features: list[torch.Tensor],
    mean: torch.Tensor,
    basis: torch.Tensor,
    masks: list[torch.Tensor | None],
) -> list[np.ndarray]:
    projected = []
    for feat in features:
        c, h, w = feat.shape
        flat = feat.float().permute(1, 2, 0).reshape(-1, c)
        rgb = ((flat - mean) @ basis).reshape(h, w, 3)
        projected.append(rgb)

    rows = []
    for rgb, mask in zip(projected, masks):
        flat = rgb.reshape(-1, 3)
        if mask is not None:
            keep = mask.reshape(-1).float() > 0.5
            if keep.any():
                flat = flat[keep]
        rows.append(flat)
    stacked = torch.cat(rows, dim=0)
    lo = torch.quantile(stacked, 0.01, dim=0)
    hi = torch.quantile(stacked, 0.99, dim=0)
    denom = (hi - lo).clamp_min(1e-6)
    out = []
    for rgb, mask in zip(projected, masks):
        arr = ((rgb - lo) / denom).clamp(0.0, 1.0)
        if mask is not None:
            arr = apply_mask_gray(arr, mask)
        out.append((arr.numpy() * 255.0).round().astype(np.uint8))
    return out


def apply_mask_gray(rgb: torch.Tensor, mask: torch.Tensor, gray: float = 0.12) -> torch.Tensor:
    mask_hw = mask.float().squeeze(0).clamp(0.0, 1.0)
    return rgb * mask_hw[..., None] + gray * (1.0 - mask_hw[..., None])


def first3_rgb(features: list[torch.Tensor], masks: list[torch.Tensor | None]) -> list[np.ndarray]:
    chans = []
    for feat in features:
        if feat.shape[0] < 3:
            pad = torch.zeros((3 - feat.shape[0], *feat.shape[1:]), dtype=feat.dtype)
            feat = torch.cat([feat, pad], dim=0)
        chans.append(feat[:3].float().permute(1, 2, 0))

    rows = []
    for arr, mask in zip(chans, masks):
        flat = arr.reshape(-1, 3)
        if mask is not None:
            keep = mask.reshape(-1).float() > 0.5
            if keep.any():
                flat = flat[keep]
        rows.append(flat[torch.isfinite(flat).all(dim=1)])
    stacked = torch.cat(rows, dim=0)
    lo = torch.quantile(stacked, 0.01, dim=0)
    hi = torch.quantile(stacked, 0.99, dim=0)
    denom = (hi - lo).clamp_min(1e-6)

    out = []
    for arr, mask in zip(chans, masks):
        rgb = ((arr - lo) / denom).clamp(0.0, 1.0)
        if mask is not None:
            rgb = apply_mask_gray(rgb, mask)
        out.append((rgb.numpy() * 255.0).round().astype(np.uint8))
    return out


def resize_nearest(img: np.ndarray, image_hw: tuple[int, int]) -> np.ndarray:
    h, w = image_hw
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_NEAREST)


def hcat_with_titles(items: list[tuple[str, np.ndarray]]) -> np.ndarray:
    font = cv2.FONT_HERSHEY_SIMPLEX
    pad = 36
    panels = []
    for title, img in items:
        if img.ndim == 2:
            img = np.repeat(img[..., None], 3, axis=2)
        if img.dtype != np.uint8:
            img = (np.clip(img, 0.0, 1.0) * 255).round().astype(np.uint8)
        canvas = np.full((img.shape[0] + pad, img.shape[1], 3), 255, dtype=np.uint8)
        canvas[pad:] = img
        cv2.putText(canvas, title, (8, 24), font, 0.65, (20, 20, 20), 2, cv2.LINE_AA)
        panels.append(canvas)
    return np.concatenate(panels, axis=1)


def save_visualizations(
    out_dir: Path,
    processed_images: np.ndarray,
    depth_pair: torch.Tensor,
    target_feat: torch.Tensor,
    warped_feat: torch.Tensor,
    valid_mask: torch.Tensor,
    occlusion_mask: torch.Tensor,
    image_hw: tuple[int, int],
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    source_img = processed_images[0]
    target_img = processed_images[1]

    mask_vis = resize_nearest(occlusion_mask.squeeze(0).numpy(), image_hw)
    mask_u8 = (mask_vis * 255.0).round().astype(np.uint8)
    imageio.imwrite(out_dir / "occlusion_mask_000_to_006.png", mask_u8)

    depth_vis_src = visualize_depth(depth_pair[0].numpy())
    depth_vis_tgt = visualize_depth(depth_pair[1].numpy())
    imageio.imwrite(
        out_dir / "input_depths.png",
        hcat_with_titles(
            [
                ("000_0 processed image", source_img),
                ("000_0 DA3 depth", depth_vis_src),
                ("006_0 processed image", target_img),
                ("006_0 DA3 depth", depth_vis_tgt),
            ]
        ),
    )

    mean, basis = fit_pca_rgb([warped_feat, target_feat], [valid_mask, None])
    warp_pca, target_pca = project_pca_rgb(
        [warped_feat, target_feat], mean, basis, [valid_mask, None]
    )
    warp_pca = resize_nearest(warp_pca, image_hw)
    target_pca = resize_nearest(target_pca, image_hw)
    imageio.imwrite(
        out_dir / "layer0_pca_warp_vs_target.png",
        hcat_with_titles(
            [
                ("000_0 -> 006_0 warped layer0 PCA", warp_pca),
                ("006_0 target layer0 PCA", target_pca),
            ]
        ),
    )

    warp_first3, target_first3 = first3_rgb([warped_feat, target_feat], [valid_mask, None])
    warp_first3 = resize_nearest(warp_first3, image_hw)
    target_first3 = resize_nearest(target_first3, image_hw)
    imageio.imwrite(
        out_dir / "layer0_first3_warp_vs_target.png",
        hcat_with_titles(
            [
                ("000_0 -> 006_0 warped layer0 dims 0-2", warp_first3),
                ("006_0 target layer0 dims 0-2", target_first3),
            ]
        ),
    )

    imageio.imwrite(
        out_dir / "warp_overview.png",
        hcat_with_titles(
            [
                ("000_0 processed image", source_img),
                ("006_0 processed image", target_img),
                ("occlusion mask white=missing", mask_u8),
                ("warped PCA", warp_pca),
                ("target PCA", target_pca),
            ]
        ),
    )


def write_manifest(out_dir: Path, manifest: dict) -> None:
    with (out_dir / "manifest.json").open("w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)


def main() -> None:
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but torch.cuda.is_available() is false.")
    device = torch.device(args.device if args.device != "cuda" else "cuda")

    image_paths, input_extrinsics, input_intrinsics = prepare_inputs(args)
    src_view = args.source_frame
    tgt_view = args.target_frame
    if src_view < 0 or src_view >= len(image_paths) or tgt_view < 0 or tgt_view >= len(image_paths):
        raise IndexError("source-frame/target-frame must be within the selected 7 FRONT frames.")

    print("[geo-warp] loading DA3 model:", args.model_dir, flush=True)
    model = DepthAnything3.from_pretrained(args.model_dir).to(device=device)
    model.eval()

    print("[geo-warp] running DA3 inference on FRONT frames 000..006", flush=True)
    with capture_decoder_feats(model) as captured:
        prediction = model.inference(
            image_paths,
            extrinsics=input_extrinsics,
            intrinsics=input_intrinsics,
            align_to_input_ext_scale=True,
            infer_gs=False,
            process_res=args.process_res,
            process_res_method=args.process_res_method,
            export_dir=None,
            export_feat_layers=[],
        )

    if "token_feats" not in captured or "pyramid_feats" not in captured:
        raise RuntimeError(
            "DPT decoder features were not captured. "
            f"Captured keys: {sorted(captured.keys())}"
        )
    if prediction.processed_images is None:
        raise RuntimeError("prediction.processed_images is missing.")
    image_h, image_w = prediction.processed_images.shape[1:3]
    image_hw = (int(image_h), int(image_w))
    if not args.no_strict_size and image_hw != (448, 672):
        raise RuntimeError(
            f"Expected processed image size (448,672), got {image_hw}. "
            "Pass --no-strict-size to continue."
        )
    if prediction.depth.shape[1:] != image_hw:
        raise RuntimeError(
            f"Depth shape {prediction.depth.shape[1:]} does not match processed image {image_hw}."
        )

    selected_views = [src_view, tgt_view]
    token_features = decoder_feats_to_chw(captured["token_feats"], selected_views, image_hw)
    decoder_features = decoder_pyramid_to_chw(captured["pyramid_feats"], selected_views)
    depth_pair = torch.from_numpy(prediction.depth[selected_views]).float().cpu()
    intr_pair = torch.from_numpy(prediction.intrinsics[selected_views]).float().cpu()
    extr_pair = torch.from_numpy(
        make_homogeneous_w2c(np.asarray(prediction.extrinsics)[selected_views])
    ).float().cpu()
    processed_pair = prediction.processed_images[selected_views]

    layer0 = decoder_features["layer_0"]
    src_feat = layer0[0]
    tgt_feat = layer0[1]
    print(
        "[geo-warp] layer_0 feature shape:",
        tuple(src_feat.shape),
        "image_hw:",
        image_hw,
        flush=True,
    )
    warped, valid_mask, occlusion_mask = warp_feature_forward(
        src_feat,
        depth_pair[0],
        intr_pair[0],
        intr_pair[1],
        extr_pair[0],
        extr_pair[1],
        image_hw=image_hw,
    )
    coverage = float(valid_mask.mean().item())
    print(f"[geo-warp] target feature coverage={coverage:.4f}", flush=True)

    payload = {
        "frame_ids": torch.tensor(selected_views, dtype=torch.long),
        "image_paths": [image_paths[i] for i in selected_views],
        "decoder_pyramid_features": decoder_features,
        "decoder_token_features": token_features,
        "depth": depth_pair,
        "intrinsics": intr_pair,
        "extrinsics_w2c": extr_pair,
        "processed_images": torch.from_numpy(processed_pair.copy()),
        "warped_layer0": warped.cpu(),
        "valid_mask": valid_mask.cpu(),
        "occlusion_mask": occlusion_mask.cpu(),
    }
    if args.save_all_frame_depths:
        payload["all_depth"] = torch.from_numpy(prediction.depth).float().cpu()
    torch.save(payload, out_dir / "features_depth_warp.pt")

    np.savez_compressed(
        out_dir / "features_depth_warp_summary.npz",
        depth=depth_pair.numpy(),
        intrinsics=intr_pair.numpy(),
        extrinsics_w2c=extr_pair.numpy(),
        valid_mask=valid_mask.numpy(),
        occlusion_mask=occlusion_mask.numpy(),
        processed_images=processed_pair,
    )

    save_visualizations(
        out_dir / "visualizations",
        processed_pair,
        depth_pair,
        tgt_feat,
        warped.cpu(),
        valid_mask.cpu(),
        occlusion_mask.cpu(),
        image_hw,
    )

    manifest = {
        "scene_dir": args.scene_dir,
        "model_dir": args.model_dir,
        "camera_id": args.camera_id,
        "source_image": image_paths[src_view],
        "target_image": image_paths[tgt_view],
        "processed_image_hw": image_hw,
        "decoder_pyramid_feature_shapes": {k: list(v.shape) for k, v in decoder_features.items()},
        "decoder_token_feature_shapes": {k: list(v.shape) for k, v in token_features.items()},
        "depth_pair_shape": list(depth_pair.shape),
        "warped_layer0_shape": list(warped.shape),
        "valid_coverage": coverage,
        "outputs": {
            "torch_payload": str(out_dir / "features_depth_warp.pt"),
            "summary_npz": str(out_dir / "features_depth_warp_summary.npz"),
            "visualizations": str(out_dir / "visualizations"),
        },
    }
    write_manifest(out_dir, manifest)
    print("[geo-warp] wrote outputs to", out_dir.resolve(), flush=True)
    print(json.dumps(manifest, indent=2), flush=True)


if __name__ == "__main__":
    main()
