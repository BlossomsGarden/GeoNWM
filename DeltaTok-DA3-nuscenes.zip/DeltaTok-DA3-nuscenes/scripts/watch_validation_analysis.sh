#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONDA_SH="${CONDA_SH:-/data/wlh/miniconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-da3}"
RUN_DIR="${RUN_DIR:-${ROOT}/runs/deltatok_da3_front_back_700x252_8tok}"
MIN_STEP="${MIN_STEP:-500}"
FORMAL_LOG="${FORMAL_LOG:-${ROOT}/logs/formal_train_20260610_024230.log}"
INTERVAL_SECONDS="${INTERVAL_SECONDS:-300}"
MAX_ITERATIONS="${MAX_ITERATIONS:-0}"
LOG_DIR="${LOG_DIR:-${ROOT}/logs}"
WATCH_LOG="${WATCH_LOG:-${LOG_DIR}/watch_validation_analysis_$(date +%Y%m%d_%H%M%S).log}"

mkdir -p "${LOG_DIR}" "${RUN_DIR}"

last_val_step() {
  local path="${RUN_DIR}/val_metrics.csv"
  if [ ! -f "${path}" ]; then
    printf '0\n'
    return
  fi
  awk -F',' 'NR > 1 && $1 ~ /^[0-9]+$/ { step=$1 } END { print step+0 }' "${path}"
}

{
  printf 'watcher_pid=%s\n' "$$"
  printf 'root=%s\nrun_dir=%s\nmin_step=%s\ninterval_seconds=%s\nmax_iterations=%s\n' \
    "${ROOT}" "${RUN_DIR}" "${MIN_STEP}" "${INTERVAL_SECONDS}" "${MAX_ITERATIONS}"

  iteration=0
  while true; do
    iteration=$((iteration + 1))
    step="$(last_val_step)"
    printf '\n[%s] watcher iteration %s val_step=%s\n' \
      "$(date '+%F %T %Z')" "${iteration}" "${step}"

    if [ "${step}" -ge "${MIN_STEP}" ]; then
      cd "${ROOT}"
      set +u
      source "${CONDA_SH}"
      conda activate "${CONDA_ENV_NAME}"
      set -u

      text_out="${RUN_DIR}/analysis_step_${step}.txt"
      json_out="${RUN_DIR}/analysis_step_${step}.json"
      anomaly_out="${RUN_DIR}/strict_anomalies_step_${step}.txt"
      python scripts/analyze_run.py --run-dir "${RUN_DIR}" > "${text_out}"
      python scripts/analyze_run.py --run-dir "${RUN_DIR}" --json > "${json_out}"
      python scripts/check_strict_anomalies.py --log "${FORMAL_LOG}" --tail 40 > "${anomaly_out}" || true
      manifest_output="$(bash scripts/write_run_manifest.sh)"
      snapshot_output="$(bash scripts/write_process_snapshot.sh)"
      printf 'analysis written: %s\n' "${text_out}"
      printf 'analysis json written: %s\n' "${json_out}"
      printf 'strict anomalies written: %s\n' "${anomaly_out}"
      printf '%s\n' "${manifest_output}"
      printf '%s\n' "${snapshot_output}"
      cat "${text_out}"
      cat "${anomaly_out}"
      {
        printf '\n## %s\n\n' "$(date '+%F %T %Z')"
        printf 'First validation analysis reached step `%s`.\n\n' "${step}"
        printf -- '- Text report: `%s`\n' "${text_out#${ROOT}/}"
        printf -- '- JSON report: `%s`\n\n' "${json_out#${ROOT}/}"
        printf -- '- Strict anomaly report: `%s`\n' "${anomaly_out#${ROOT}/}"
        printf '\nManifest output:\n\n'
        printf '```text\n%s\n```\n\n' "${manifest_output}"
        printf 'Process snapshot output:\n\n'
        printf '```text\n%s\n```\n\n' "${snapshot_output}"
        printf '```text\n'
        cat "${text_out}"
        printf '```\n'
        printf '\nStrict anomaly scan:\n\n'
        printf '```text\n'
        cat "${anomaly_out}"
        printf '```\n'
      } >> "${ROOT}/EXPERIMENT_LOG.md"
      printf 'experiment log appended: %s\n' "${ROOT}/EXPERIMENT_LOG.md"
      break
    fi

    printf 'validation not ready yet\n'
    if [ "${MAX_ITERATIONS}" -gt 0 ] && [ "${iteration}" -ge "${MAX_ITERATIONS}" ]; then
      printf '[%s] watcher reached max iterations without validation\n' "$(date '+%F %T %Z')"
      break
    fi
    sleep "${INTERVAL_SECONDS}"
  done
} >> "${WATCH_LOG}" 2>&1
