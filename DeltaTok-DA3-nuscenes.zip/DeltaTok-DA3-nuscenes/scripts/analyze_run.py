#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any


DEFAULT_RUN_DIR = "runs/deltatok_da3_front_back_700x252_8tok"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize DeltaTok-DA3 run metrics without touching CUDA.")
    parser.add_argument("--run-dir", default=DEFAULT_RUN_DIR)
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON only.")
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return [dict(row) for row in csv.DictReader(f)]


def to_float(row: dict[str, str], key: str) -> float | None:
    value = row.get(key)
    if value in (None, ""):
        return None
    try:
        return float(value)
    except ValueError:
        return None


def to_int(row: dict[str, str], key: str) -> int | None:
    value = to_float(row, key)
    return None if value is None else int(value)


def rel_improvement(value: float | None, copy_value: float | None) -> float | None:
    if value is None or copy_value is None or abs(copy_value) < 1e-12:
        return None
    return 1.0 - value / copy_value


def finite_audit(rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    bad: list[dict[str, Any]] = []
    for idx, row in enumerate(rows):
        step = row.get("step", str(idx))
        for key, value in row.items():
            if key == "step" or value in (None, ""):
                continue
            try:
                numeric = float(value)
            except ValueError:
                continue
            if not math.isfinite(numeric):
                bad.append({"row": idx, "step": step, "field": key, "value": value})
    return bad


def summarize_train(rows: list[dict[str, str]]) -> dict[str, Any]:
    if not rows:
        return {"status": "missing"}
    latest = rows[-1]
    rel = to_float(latest, "relative_improvement")
    if rel is None:
        rel = rel_improvement(to_float(latest, "train_mse"), to_float(latest, "copy_mse"))

    def train_rel(row: dict[str, str]) -> float:
        value = rel_improvement(to_float(row, "train_mse"), to_float(row, "copy_mse"))
        return value if value is not None else float("-inf")

    best_row = max(
        rows,
        key=train_rel,
    )
    return {
        "status": "present",
        "num_logged_rows": len(rows),
        "latest": {
            "step": to_int(latest, "step"),
            "lr": to_float(latest, "lr"),
            "train_mse": to_float(latest, "train_mse"),
            "copy_mse": to_float(latest, "copy_mse"),
            "relative_improvement": rel,
            "grad_norm": to_float(latest, "grad_norm"),
            "batch_size_per_gpu": to_int(latest, "batch_size_per_gpu"),
            "grad_accum_steps": to_int(latest, "grad_accum_steps"),
            "effective_batch_size": to_int(latest, "effective_batch_size"),
            "gpu_mem_gb": to_float(latest, "gpu_mem_gb"),
            "steps_per_sec": to_float(latest, "steps_per_sec"),
        },
        "latest_level_relative_improvement": {
            f"level{idx}": rel_improvement(
                to_float(latest, f"level{idx}_mse"),
                to_float(latest, f"copy_level{idx}_mse"),
            )
            for idx in range(1, 5)
        },
        "best_logged_relative_improvement": {
            "step": to_int(best_row, "step"),
            "relative_improvement": rel_improvement(
                to_float(best_row, "train_mse"), to_float(best_row, "copy_mse")
            ),
        },
        "non_finite_values": finite_audit(rows),
    }


def summarize_val(rows: list[dict[str, str]]) -> dict[str, Any]:
    if not rows:
        return {"status": "missing"}
    latest = rows[-1]

    def val_mse(row: dict[str, str]) -> float:
        value = to_float(row, "val_mse")
        return value if value is not None else float("inf")

    best_row = min(rows, key=val_mse)
    return {
        "status": "present",
        "num_logged_rows": len(rows),
        "latest": {
            "step": to_int(latest, "step"),
            "val_mse": to_float(latest, "val_mse"),
            "val_copy_mse": to_float(latest, "val_copy_mse"),
            "relative_improvement": rel_improvement(
                to_float(latest, "val_mse"), to_float(latest, "val_copy_mse")
            ),
            "depth_relative_improvement": rel_improvement(
                to_float(latest, "val_depth_mse"), to_float(latest, "val_copy_depth_mse")
            ),
            "ray_relative_improvement": rel_improvement(
                to_float(latest, "val_ray_mse"), to_float(latest, "val_copy_ray_mse")
            ),
        },
        "latest_level_relative_improvement": {
            f"level{idx}": rel_improvement(
                to_float(latest, f"val_level{idx}_mse"),
                to_float(latest, f"val_copy_level{idx}_mse"),
            )
            for idx in range(1, 5)
        },
        "best_val_mse": {
            "step": to_int(best_row, "step"),
            "val_mse": to_float(best_row, "val_mse"),
            "relative_improvement": rel_improvement(
                to_float(best_row, "val_mse"), to_float(best_row, "val_copy_mse")
            ),
        },
        "non_finite_values": finite_audit(rows),
    }


def summarize_checkpoints(run_dir: Path) -> dict[str, Any]:
    ckpt_dir = run_dir / "checkpoints"
    if not ckpt_dir.exists():
        return {"status": "missing", "files": []}
    files = []
    for path in sorted(ckpt_dir.glob("*.pt")):
        files.append({"name": path.name, "size_bytes": path.stat().st_size})
    return {
        "status": "present" if files else "empty",
        "files": files,
        "has_last": any(item["name"] == "last.pt" for item in files),
        "has_step_1000": any(item["name"] == "step_0001000.pt" for item in files),
    }


def summarize_visualizations(run_dir: Path) -> dict[str, Any]:
    vis_dir = run_dir / "visualizations"
    summary_files = sorted(vis_dir.glob("summary_step_*.csv")) if vis_dir.exists() else []
    summary_path = summary_files[-1] if summary_files else Path("__missing__")
    summaries = read_csv(summary_path)
    png_count = len(list(vis_dir.glob("*.png"))) if vis_dir.exists() else 0
    if not vis_dir.exists():
        return {"status": "missing", "png_count": 0, "summary": None}
    if not summaries:
        return {"status": "present_without_summary", "png_count": png_count, "summary": None}
    rel_values = [
        rel_improvement(to_float(row, "feature_mse"), to_float(row, "copy_feature_mse"))
        for row in summaries
    ]
    rel_values = [value for value in rel_values if value is not None]
    return {
        "status": "present",
        "png_count": png_count,
        "summary_file": summary_path.name,
        "summary_rows": len(summaries),
        "mean_feature_relative_improvement": sum(rel_values) / len(rel_values) if rel_values else None,
        "non_finite_values": finite_audit(summaries),
    }


def read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def summarize_checkpoint_evals(run_dir: Path) -> dict[str, Any]:
    eval_dir = run_dir / "checkpoint_evals"
    if not eval_dir.exists():
        return {"status": "missing", "files": []}
    files = sorted(eval_dir.glob("*_step_*_val.json"))
    completed = []
    for path in files:
        payload = read_json(path)
        if not payload:
            continue
        completed.append(
            {
                "name": path.name,
                "status": payload.get("status"),
                "checkpoint_step": payload.get("checkpoint_step"),
                "num_samples": payload.get("num_samples"),
                "relative_improvement": payload.get("relative_improvement"),
                "depth_relative_improvement": payload.get("depth_relative_improvement"),
                "ray_relative_improvement": payload.get("ray_relative_improvement"),
                "non_finite_values": payload.get("non_finite_values", []),
                "metrics": payload.get("metrics", {}),
            }
        )
    if not completed:
        return {"status": "empty", "files": [path.name for path in files]}
    latest = completed[-1]
    return {
        "status": "present",
        "files": [item["name"] for item in completed],
        "latest": latest,
    }


def format_percent(value: float | None) -> str:
    if value is None:
        return "n/a"
    return f"{100.0 * value:.2f}%"


def print_text(report: dict[str, Any]) -> None:
    print(f"run_dir: {report['run_dir']}")
    train = report["train"]
    if train["status"] == "present":
        latest = train["latest"]
        print(
            "train_latest: "
            f"step={latest['step']} mse={latest['train_mse']} copy={latest['copy_mse']} "
            f"rel={format_percent(latest['relative_improvement'])} lr={latest['lr']}"
        )
        print(f"train_best_rel: {train['best_logged_relative_improvement']}")
        print(f"train_level_rel: {train['latest_level_relative_improvement']}")
        print(f"train_non_finite_count: {len(train['non_finite_values'])}")
    else:
        print("train_latest: missing")

    val = report["validation"]
    if val["status"] == "present":
        latest = val["latest"]
        print(
            "val_latest: "
            f"step={latest['step']} mse={latest['val_mse']} copy={latest['val_copy_mse']} "
            f"rel={format_percent(latest['relative_improvement'])} "
            f"depth_rel={format_percent(latest['depth_relative_improvement'])} "
            f"ray_rel={format_percent(latest['ray_relative_improvement'])}"
        )
        print(f"val_level_rel: {val['latest_level_relative_improvement']}")
        print(f"val_non_finite_count: {len(val['non_finite_values'])}")
    else:
        print("val_latest: missing")

    full_val = report["full_validation"]
    if full_val["status"] == "present":
        latest = full_val["latest"]
        print(
            "full_val_latest: "
            f"step={latest['step']} mse={latest['val_mse']} copy={latest['val_copy_mse']} "
            f"rel={format_percent(latest['relative_improvement'])} "
            f"depth_rel={format_percent(latest['depth_relative_improvement'])} "
            f"ray_rel={format_percent(latest['ray_relative_improvement'])}"
        )
        print(f"full_val_non_finite_count: {len(full_val['non_finite_values'])}")
    else:
        print("full_val_latest: missing")

    checkpoint_eval = report["checkpoint_eval"]
    if checkpoint_eval["status"] == "present":
        latest = checkpoint_eval["latest"]
        metrics = latest.get("metrics", {})
        print(
            "checkpoint_eval_latest: "
            f"step={latest.get('checkpoint_step')} samples={latest.get('num_samples')} "
            f"mse={metrics.get('val_mse')} copy={metrics.get('val_copy_mse')} "
            f"rel={format_percent(latest.get('relative_improvement'))} "
            f"depth_rel={format_percent(latest.get('depth_relative_improvement'))} "
            f"ray_rel={format_percent(latest.get('ray_relative_improvement'))}"
        )
        print(f"checkpoint_eval_non_finite_count: {len(latest.get('non_finite_values', []))}")
    else:
        print("checkpoint_eval_latest: missing")

    checkpoints = report["checkpoints"]
    print(
        "checkpoints: "
        f"status={checkpoints['status']} has_last={checkpoints.get('has_last', False)} "
        f"has_step_1000={checkpoints.get('has_step_1000', False)} files={len(checkpoints['files'])}"
    )

    visualizations = report["visualizations"]
    print(
        "visualizations: "
        f"status={visualizations['status']} png_count={visualizations['png_count']} "
        f"mean_rel={format_percent(visualizations.get('mean_feature_relative_improvement'))}"
    )

    pending = report["pending_milestones"]
    if pending:
        print("pending_milestones:")
        for item in pending:
            print(f"- {item}")
    else:
        print("pending_milestones: none")
    print("notes:")
    for note in report["notes"]:
        print(f"- {note}")


def main() -> None:
    args = parse_args()
    run_dir = Path(args.run_dir)
    train_rows = read_csv(run_dir / "metrics.csv")
    val_rows = read_csv(run_dir / "val_metrics.csv")
    full_val_rows = read_csv(run_dir / "full_val_metrics.csv")
    report = {
        "run_dir": str(run_dir),
        "train": summarize_train(train_rows),
        "validation": summarize_val(val_rows),
        "full_validation": summarize_val(full_val_rows),
        "checkpoint_eval": summarize_checkpoint_evals(run_dir),
        "checkpoints": summarize_checkpoints(run_dir),
        "visualizations": summarize_visualizations(run_dir),
        "notes": [
            (
                "Training metrics are logged from the final micro-batch of each "
                "accumulated optimizer step; validation metrics are the primary "
                "scientific evidence."
            ),
            "Relative improvement is computed against the copy-last baseline.",
        ],
    }
    pending = []
    if report["validation"]["status"] != "present":
        pending.append("first limited validation at step 500")
    if report["checkpoint_eval"]["status"] != "present":
        pending.append("checkpoint full validation after first checkpoint")
    if not report["checkpoints"].get("has_step_1000", False):
        pending.append("first scheduled checkpoint at step 1000")
    if report["visualizations"]["status"] != "present":
        pending.append("fixed-sample visualization after checkpoint")
    report["pending_milestones"] = pending

    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print_text(report)


if __name__ == "__main__":
    main()
