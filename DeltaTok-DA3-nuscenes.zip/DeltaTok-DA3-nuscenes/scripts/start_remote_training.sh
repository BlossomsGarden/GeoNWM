#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONDA_SH="${CONDA_SH:-/data/wlh/miniconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-da3}"
CONFIG="${CONFIG:-configs/deltatok_da3_nuscenes_front_back_700x252.yaml}"
GPUS="${GPUS:-2,3}"

set +u
source "${CONDA_SH}"
conda activate "${CONDA_ENV_NAME}"
set -u
cd "${ROOT}"

export PYTHONPATH="${ROOT}/src:${ROOT}/da3-src/src:${PYTHONPATH:-}"
export CUDA_VISIBLE_DEVICES="${GPUS}"
export TOKENIZERS_PARALLELISM=false

mkdir -p logs
torchrun --standalone --nproc_per_node=2 \
  src/deltatok_da3/train.py \
  --config "${CONFIG}" \
  "$@" 2>&1 | tee logs/train_deltatok_da3.log
