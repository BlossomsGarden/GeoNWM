#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONDA_SH="${CONDA_SH:-/data/wlh/miniconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-da3}"

set +u
source "${CONDA_SH}"
conda activate "${CONDA_ENV_NAME}"
set -u
cd "${ROOT}"

python scripts/analyze_run.py "$@"
