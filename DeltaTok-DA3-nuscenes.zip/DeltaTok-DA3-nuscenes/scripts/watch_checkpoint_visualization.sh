#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_DIR="${RUN_DIR:-${ROOT}/runs/deltatok_da3_front_back_700x252_8tok}"
CHECKPOINT="${CHECKPOINT:-${RUN_DIR}/checkpoints/step_0001000.pt}"
OUTPUT_DIR="${OUTPUT_DIR:-${RUN_DIR}/visualizations}"
SUMMARY_STEP="${SUMMARY_STEP:-1000}"
INTERVAL_SECONDS="${INTERVAL_SECONDS:-300}"
MAX_ITERATIONS="${MAX_ITERATIONS:-0}"
LOG_DIR="${LOG_DIR:-${ROOT}/logs}"
WATCH_LOG="${WATCH_LOG:-${LOG_DIR}/watch_checkpoint_visualization_$(date +%Y%m%d_%H%M%S).log}"
SUMMARY_PATH="${OUTPUT_DIR}/summary_step_$(printf '%07d' "${SUMMARY_STEP}").csv"

mkdir -p "${LOG_DIR}"

file_size_bytes() {
  local path="$1"
  if [ ! -f "${path}" ]; then
    printf -- '-1\n'
    return
  fi
  stat -c '%s' "${path}"
}

wait_for_stable_file() {
  local path="$1"
  local checks="${STABLE_CHECKS:-2}"
  local sleep_seconds="${STABLE_SLEEP_SECONDS:-30}"
  local previous_size="-1"
  local stable_count=0

  while true; do
    current_size="$(file_size_bytes "${path}")"
    printf 'checkpoint size check: path=%s size=%s stable_count=%s/%s\n' \
      "${path}" "${current_size}" "${stable_count}" "${checks}"
    if [ "${current_size}" -gt 0 ] && [ "${current_size}" = "${previous_size}" ]; then
      stable_count=$((stable_count + 1))
    else
      stable_count=0
    fi
    if [ "${stable_count}" -ge "${checks}" ]; then
      break
    fi
    previous_size="${current_size}"
    sleep "${sleep_seconds}"
  done
}

{
  printf 'watcher_pid=%s\n' "$$"
  printf 'root=%s\nrun_dir=%s\ncheckpoint=%s\noutput_dir=%s\nsummary_path=%s\ninterval_seconds=%s\nmax_iterations=%s\n' \
    "${ROOT}" "${RUN_DIR}" "${CHECKPOINT}" "${OUTPUT_DIR}" "${SUMMARY_PATH}" "${INTERVAL_SECONDS}" "${MAX_ITERATIONS}"

  iteration=0
  while true; do
    iteration=$((iteration + 1))
    printf '\n[%s] watcher iteration %s\n' "$(date '+%F %T %Z')" "${iteration}"

    if [ -f "${CHECKPOINT}" ]; then
      printf 'checkpoint found: %s\n' "${CHECKPOINT}"
      wait_for_stable_file "${CHECKPOINT}"
      if [ -f "${SUMMARY_PATH}" ]; then
        printf 'visualization summary already exists: %s; exiting.\n' "${SUMMARY_PATH}"
        break
      fi

      cd "${ROOT}"
      CHECKPOINT="${CHECKPOINT}" OUTPUT_DIR="${OUTPUT_DIR}" bash scripts/run_checkpoint_visualization.sh
      printf '[%s] visualization complete\n' "$(date '+%F %T %Z')"
      analysis_text="${RUN_DIR}/analysis_after_visualization.txt"
      analysis_json="${RUN_DIR}/analysis_after_visualization.json"
      bash scripts/analyze_run.sh --run-dir "${RUN_DIR}" > "${analysis_text}"
      bash scripts/analyze_run.sh --run-dir "${RUN_DIR}" --json > "${analysis_json}"
      {
        printf '\n## %s\n\n' "$(date '+%F %T %Z')"
        printf 'Checkpoint visualization completed for `%s`.\n\n' "${CHECKPOINT#${ROOT}/}"
        printf -- '- Visualization directory: `%s`\n' "${OUTPUT_DIR#${ROOT}/}"
        printf -- '- Text report: `%s`\n' "${analysis_text#${ROOT}/}"
        printf -- '- JSON report: `%s`\n\n' "${analysis_json#${ROOT}/}"
        printf '```text\n'
        cat "${analysis_text}"
        printf '```\n'
      } >> "${ROOT}/EXPERIMENT_LOG.md"
      printf 'analysis written: %s\n' "${analysis_text}"
      printf 'analysis json written: %s\n' "${analysis_json}"
      printf 'experiment log appended: %s\n' "${ROOT}/EXPERIMENT_LOG.md"
      break
    fi

    printf 'checkpoint not ready yet\n'
    if [ "${MAX_ITERATIONS}" -gt 0 ] && [ "${iteration}" -ge "${MAX_ITERATIONS}" ]; then
      printf '[%s] watcher reached max iterations without checkpoint\n' "$(date '+%F %T %Z')"
      break
    fi
    sleep "${INTERVAL_SECONDS}"
  done
} >> "${WATCH_LOG}" 2>&1
