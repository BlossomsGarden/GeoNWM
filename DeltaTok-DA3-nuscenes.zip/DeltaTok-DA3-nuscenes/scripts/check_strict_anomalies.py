#!/usr/bin/env python
from __future__ import annotations

import argparse
import re
from pathlib import Path


DEFAULT_LOG = "logs/formal_train_20260610_024230.log"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read-only strict anomaly scan for the formal DeltaTok-DA3 training log."
    )
    parser.add_argument("--log", default=DEFAULT_LOG)
    parser.add_argument("--tail", type=int, default=30)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    path = Path(args.log)
    patterns = [
        re.compile(r"out of memory", re.IGNORECASE),
        re.compile(r"traceback", re.IGNORECASE),
        re.compile(r"runtimeerror", re.IGNORECASE),
        re.compile(r"childfailed", re.IGNORECASE),
        re.compile(r"(?<![A-Za-z])nan(?![A-Za-z])", re.IGNORECASE),
        re.compile(r"(?<![A-Za-z])inf(?![A-Za-z])", re.IGNORECASE),
    ]
    if not path.exists():
        print(f"strict_anomaly_log_missing {path}")
        return

    lines = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if any(pattern.search(line) for pattern in patterns):
            lines.append(line)

    print(f"strict_anomaly_count {len(lines)}")
    for line in lines[-max(0, int(args.tail)) :]:
        print(line)


if __name__ == "__main__":
    main()
