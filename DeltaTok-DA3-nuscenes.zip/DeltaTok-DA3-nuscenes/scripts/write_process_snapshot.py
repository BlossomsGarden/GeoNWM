#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import os
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any


DEFAULT_RUN_DIR = "runs/deltatok_da3_front_back_700x252_8tok"
TRAIN_PATTERN = "src/deltatok_da3/train.py --config configs/deltatok_da3_nuscenes_front_back_700x252.yaml"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Write a read-only active process snapshot.")
    parser.add_argument("--run-dir", default=DEFAULT_RUN_DIR)
    parser.add_argument("--output", default=None)
    return parser.parse_args()


def run_command(command: list[str]) -> dict[str, Any]:
    try:
        result = subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=20,
        )
        return {
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except Exception as exc:  # pragma: no cover - defensive utility
        return {"error": repr(exc)}


def read_text(path: Path, max_chars: int = 20000) -> str | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    if len(text) > max_chars:
        return text[:max_chars] + "\n...[truncated]..."
    return text


def proc_record(pid: int) -> dict[str, Any]:
    proc = Path("/proc") / str(pid)
    environ = read_text(proc / "environ")
    env_dict = {}
    if environ is not None:
        for item in environ.split("\x00"):
            if "=" in item:
                key, value = item.split("=", 1)
                if key in {
                    "CUDA_VISIBLE_DEVICES",
                    "CONDA_DEFAULT_ENV",
                    "PYTHONPATH",
                    "RANK",
                    "LOCAL_RANK",
                    "WORLD_SIZE",
                    "MASTER_ADDR",
                    "MASTER_PORT",
                    "OMP_NUM_THREADS",
                }:
                    env_dict[key] = value
    cwd = None
    exe = None
    try:
        cwd = os.readlink(proc / "cwd")
    except OSError:
        pass
    try:
        exe = os.readlink(proc / "exe")
    except OSError:
        pass
    return {
        "pid": pid,
        "cmdline": read_text(proc / "cmdline"),
        "status": read_text(proc / "status", max_chars=8000),
        "cwd": cwd,
        "exe": exe,
        "selected_environment": env_dict,
    }


def parse_pids(ps_output: str) -> list[int]:
    pids: list[int] = []
    for line in ps_output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        first = stripped.split(maxsplit=1)[0]
        if first.isdigit():
            pids.append(int(first))
    return pids


def path_summary(path: Path) -> dict[str, Any]:
    out: dict[str, Any] = {"path": str(path), "exists": path.exists()}
    if path.exists():
        stat = path.stat()
        out.update({"size_bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns})
    return out


def main() -> None:
    args = parse_args()
    root = Path(__file__).resolve().parents[1]
    run_dir = (root / args.run_dir).resolve()
    run_dir.mkdir(parents=True, exist_ok=True)

    ps_result = run_command(
        [
            "bash",
            "-lc",
            (
                "ps -eo pid,ppid,stat,etime,pcpu,pmem,cmd "
                f"| grep -F '{TRAIN_PATTERN}' | grep -v grep || true"
            ),
        ]
    )
    pids = parse_pids(ps_result.get("stdout", ""))
    snapshot = {
        "timestamp": datetime.now().astimezone().strftime("%Y-%m-%dT%H:%M:%S%z"),
        "root": str(root),
        "run_dir": str(run_dir),
        "train_pattern": TRAIN_PATTERN,
        "process_table": ps_result,
        "processes": [proc_record(pid) for pid in pids],
        "gpu_processes": run_command(
            [
                "nvidia-smi",
                "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
                "--format=csv,noheader,nounits",
            ]
        ),
        "gpu_summary": run_command(
            [
                "nvidia-smi",
                "--query-gpu=index,memory.used,memory.free,utilization.gpu,temperature.gpu",
                "--format=csv,noheader,nounits",
            ]
        ),
        "artifacts": {
            "metrics_csv": path_summary(run_dir / "metrics.csv"),
            "val_metrics_csv": path_summary(run_dir / "val_metrics.csv"),
            "full_val_metrics_csv": path_summary(run_dir / "full_val_metrics.csv"),
            "checkpoints_dir": path_summary(run_dir / "checkpoints"),
            "visualizations_dir": path_summary(run_dir / "visualizations"),
            "manifest_latest": path_summary(run_dir / "run_manifest_latest.json"),
        },
    }

    output = Path(args.output) if args.output else run_dir / f"process_snapshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    output.write_text(json.dumps(snapshot, indent=2, sort_keys=True), encoding="utf-8")
    latest = run_dir / "process_snapshot_latest.json"
    latest.write_text(json.dumps(snapshot, indent=2, sort_keys=True), encoding="utf-8")
    print(f"process_snapshot_written={output}")
    print(f"process_snapshot_latest={latest}")
    print(f"process_count={len(snapshot['processes'])}")


if __name__ == "__main__":
    main()
