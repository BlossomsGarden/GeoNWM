#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONDA_SH="${CONDA_SH:-/data/wlh/miniconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-da3}"
CONFIG="${CONFIG:-configs/deltatok_da3_nuscenes_front_back_700x252.yaml}"
CHECKPOINT="${CHECKPOINT:-runs/deltatok_da3_front_back_700x252_8tok_release_aligned/checkpoints/last.pt}"
OUTPUT_DIR="${OUTPUT_DIR:-runs/deltatok_da3_front_back_700x252_8tok_release_aligned/visualizations}"
DEVICE="${DEVICE:-auto}"
NUM_SAMPLES="${NUM_SAMPLES:-8}"
VIS_EXCLUDE_GPUS="${VIS_EXCLUDE_GPUS:-2,3}"
VIS_MIN_FREE_MB="${VIS_MIN_FREE_MB:-12000}"

set +u
source "${CONDA_SH}"
conda activate "${CONDA_ENV_NAME}"
set -u
cd "${ROOT}"

export PYTHONPATH="${ROOT}/src:${ROOT}/da3-src/src:${PYTHONPATH:-}"
if [ "${DEVICE}" = "auto" ]; then
  DEVICE="$(
    VIS_EXCLUDE_GPUS="${VIS_EXCLUDE_GPUS}" VIS_MIN_FREE_MB="${VIS_MIN_FREE_MB}" python - <<'PY'
import os
import subprocess

exclude = {
    int(item)
    for item in os.environ.get("VIS_EXCLUDE_GPUS", "").replace(" ", "").split(",")
    if item
}
min_free_mb = int(os.environ.get("VIS_MIN_FREE_MB", "12000"))
query = [
    "nvidia-smi",
    "--query-gpu=index,memory.free,utilization.gpu",
    "--format=csv,noheader,nounits",
]
rows = []
for line in subprocess.check_output(query, text=True).strip().splitlines():
    idx_s, free_s, util_s = [part.strip() for part in line.split(",")]
    idx, free, util = int(idx_s), int(free_s), int(util_s)
    rows.append((idx, free, util))
eligible = [row for row in rows if row[0] not in exclude and row[1] >= min_free_mb]
fallback = [row for row in rows if row[0] not in exclude]
pool = eligible or fallback or rows
if not pool:
    raise SystemExit("No CUDA devices reported by nvidia-smi")
idx, _, _ = max(pool, key=lambda row: (row[1], -row[2]))
print(f"cuda:{idx}")
PY
  )"
fi
echo "visualization_device=${DEVICE}"
python src/deltatok_da3/visualize_checkpoint.py \
  --config "${CONFIG}" \
  --checkpoint "${CHECKPOINT}" \
  --output-dir "${OUTPUT_DIR}" \
  --device "${DEVICE}" \
  --num-samples "${NUM_SAMPLES}" \
  "$@"
