#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONDA_SH="${CONDA_SH:-/data/wlh/miniconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-da3}"
CONFIG="${CONFIG:-configs/deltatok_da3_nuscenes_front_back_700x252.yaml}"
DEVICE="${DEVICE:-auto}"
SMOKE_EXCLUDE_GPUS="${SMOKE_EXCLUDE_GPUS:-2,3}"
SMOKE_MIN_FREE_MB="${SMOKE_MIN_FREE_MB:-12000}"

set +u
source "${CONDA_SH}"
conda activate "${CONDA_ENV_NAME}"
set -u
cd "${ROOT}"

export PYTHONPATH="${ROOT}/src:${ROOT}/da3-src/src:${PYTHONPATH:-}"
python -m compileall -q src
if [ "${DEVICE}" = "auto" ]; then
  DEVICE="$(
    SMOKE_EXCLUDE_GPUS="${SMOKE_EXCLUDE_GPUS}" SMOKE_MIN_FREE_MB="${SMOKE_MIN_FREE_MB}" python - <<'PY'
import os
import subprocess

exclude = {
    int(item)
    for item in os.environ.get("SMOKE_EXCLUDE_GPUS", "").replace(" ", "").split(",")
    if item
}
min_free_mb = int(os.environ.get("SMOKE_MIN_FREE_MB", "12000"))
query = [
    "nvidia-smi",
    "--query-gpu=index,memory.free,utilization.gpu",
    "--format=csv,noheader,nounits",
]
rows = []
for line in subprocess.check_output(query, text=True).strip().splitlines():
    idx_s, free_s, util_s = [part.strip() for part in line.split(",")]
    rows.append((int(idx_s), int(free_s), int(util_s)))
eligible = [row for row in rows if row[0] not in exclude and row[1] >= min_free_mb]
fallback = [row for row in rows if row[0] not in exclude]
pool = eligible or fallback or rows
if not pool:
    raise SystemExit("No CUDA devices reported by nvidia-smi")
idx, _, _ = max(pool, key=lambda row: (row[1], -row[2]))
print(f"cuda:{idx}")
PY
  )"
fi
echo "smoke_device=${DEVICE}"
export CONFIG DEVICE
python - <<'PY'
import os

import torch

from pathlib import Path
from deltatok_da3.config import load_config
from deltatok_da3.da3_features import DA3ProjectedFeatureExtractor
from deltatok_da3.data import NuScenesPairDataset, collate_pairs
from deltatok_da3.model import MultiLevelDeltaTok

cfg = load_config(os.environ.get("CONFIG", "configs/deltatok_da3_nuscenes_front_back_700x252.yaml"))
expected_cameras = set(cfg.data.cameras)
assert expected_cameras == {"CAM_FRONT", "CAM_BACK"}, expected_cameras

datasets = {}
for split in (cfg.data.train_split, cfg.data.val_split):
    ds = NuScenesPairDataset(
        root=cfg.data.nuscenes_root,
        split=split,
        image_size=cfg.data.image_size,
        cameras=cfg.data.cameras,
        max_frame_gap_factor=cfg.data.max_frame_gap_factor,
    )
    datasets[split] = ds
    camera_counts = {cam: 0 for cam in cfg.data.cameras}
    max_gap_us = 0
    for prev, curr, cam in ds.pairs:
        assert cam in expected_cameras
        prev_ts = ds._timestamp(prev)
        curr_ts = ds._timestamp(curr)
        assert curr_ts > prev_ts
        max_gap_us = max(max_gap_us, curr_ts - prev_ts)
        camera_counts[cam] += 1
    sample = ds[0]
    assert tuple(sample["prev_image"].shape) == (3, cfg.data.image_size[1], cfg.data.image_size[0])
    assert tuple(sample["curr_image"].shape) == (3, cfg.data.image_size[1], cfg.data.image_size[0])
    print(f"{split}_pairs", len(ds))
    print(f"{split}_camera_counts", camera_counts)
    print(f"{split}_max_gap_us", max_gap_us)
    print(f"{split}_first_camera", sample["camera"])
    print(f"{split}_first_prev", sample["prev_path"])
    print(f"{split}_first_curr", sample["curr_path"])

device_arg = os.environ.get("DEVICE", "cuda:0")
device = torch.device(device_arg if torch.cuda.is_available() else "cpu")
if device.type == "cuda":
    torch.cuda.set_device(device)
    torch.set_float32_matmul_precision("high")
precision = cfg.train.precision


def precision_context():
    if device.type == "cuda" and precision == "bf16":
        return torch.autocast(device_type=device.type, dtype=torch.bfloat16)
    if device.type == "cuda" and precision == "fp16":
        return torch.autocast(device_type=device.type, dtype=torch.float16)
    return torch.no_grad()

extractor = DA3ProjectedFeatureExtractor(
    cfg.model.da3_src,
    cfg.model.da3_model_dir,
    cfg.model.feature_channels,
).to(device)
assert not any(param.requires_grad for param in extractor.parameters())

sample_batch = collate_pairs([datasets[cfg.data.train_split][0]])
prev = sample_batch["prev_image"].to(device)
curr = sample_batch["curr_image"].to(device)
with torch.no_grad(), precision_context():
    feats = extractor(torch.cat([prev, curr], dim=0))
expected_shapes = [
    (2, 900, cfg.model.feature_channels[0]),
    (2, 900, cfg.model.feature_channels[1]),
    (2, 900, cfg.model.feature_channels[2]),
    (2, 900, cfg.model.feature_channels[3]),
]
actual_shapes = [tuple(feat.shape) for feat in feats]
assert actual_shapes == expected_shapes, actual_shapes
print("da3_feature_shapes", actual_shapes)
print("da3_frozen", True)

prev_feats = [feat[:1].detach() for feat in feats]
curr_feats = [feat[1:].detach() for feat in feats]
model = MultiLevelDeltaTok(
    feature_channels=cfg.model.feature_channels,
    num_delta_tokens=cfg.model.num_delta_tokens,
    encoder_depth=cfg.model.encoder_depth,
    decoder_depth=cfg.model.decoder_depth,
    num_heads=cfg.model.num_heads,
    mlp_ratio=cfg.model.mlp_ratio,
    dropout=cfg.model.dropout,
    max_patches=900,
    use_checkpointing=False,
    patch_grid=(cfg.data.image_size[1] // 14, cfg.data.image_size[0] // 14),
    layer_scale_init=cfg.model.layer_scale_init,
    use_qk_norm=cfg.model.use_qk_norm,
    use_gated_attn=cfg.model.use_gated_attn,
    use_swiglu=cfg.model.use_swiglu,
).to(device).eval()
with torch.no_grad(), precision_context():
    pred, tokens = model(prev_feats, curr_feats)
pred_shapes = [tuple(feat.shape) for feat in pred]
token_shapes = [tuple(token.shape) for token in tokens]
assert pred_shapes == [(1, 900, dim) for dim in cfg.model.feature_channels], pred_shapes
assert token_shapes == [(1, cfg.model.num_delta_tokens, dim) for dim in cfg.model.feature_channels], token_shapes
assert cfg.model.num_delta_tokens == 8
print("deltatok_pred_shapes", pred_shapes)
print("deltatok_token_shapes", token_shapes)
print("no_padding_channels", list(cfg.model.feature_channels))

with torch.no_grad(), precision_context():
    decoded = extractor.decode_projected_features(pred, cfg.data.image_size[1], cfg.data.image_size[0])
depth_key = extractor.da3.head.head_main
ray_key = extractor.da3.head.head_aux
assert depth_key in decoded and ray_key in decoded
print("da3_decoder_keys", [depth_key, ray_key])
print("smoke_check_ok", True)
PY
