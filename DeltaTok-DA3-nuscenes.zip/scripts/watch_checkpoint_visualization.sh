#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_DIR="${RUN_DIR:-${ROOT}/runs/deltatok_da3_front_back_700x252_8tok_release_aligned}"
CHECKPOINT="${CHECKPOINT:-}"
CHECKPOINT_PATTERN="${CHECKPOINT_PATTERN:-${RUN_DIR}/checkpoints/step_*.pt}"
OUTPUT_DIR="${OUTPUT_DIR:-${RUN_DIR}/visualizations}"
INTERVAL_SECONDS="${INTERVAL_SECONDS:-300}"
MAX_ITERATIONS="${MAX_ITERATIONS:-0}"
WATCH_ALL_CHECKPOINTS="${WATCH_ALL_CHECKPOINTS:-1}"
LOG_DIR="${LOG_DIR:-${ROOT}/logs}"
WATCH_LOG="${WATCH_LOG:-${LOG_DIR}/watch_checkpoint_visualization_$(date +%Y%m%d_%H%M%S).log}"

mkdir -p "${LOG_DIR}" "${OUTPUT_DIR}"

file_size_bytes() {
  local path="$1"
  if [ ! -f "${path}" ]; then
    printf -- '-1\n'
    return
  fi
  stat -c '%s' "${path}"
}

checkpoint_step() {
  local name
  name="$(basename "$1")"
  name="${name#step_}"
  name="${name%.pt}"
  printf '%d\n' "$((10#${name}))"
}

summary_path_for_checkpoint() {
  local step
  step="$(checkpoint_step "$1")"
  printf '%s/summary_step_%07d.csv\n' "${OUTPUT_DIR}" "${step}"
}

wait_for_stable_file() {
  local path="$1"
  local checks="${STABLE_CHECKS:-2}"
  local sleep_seconds="${STABLE_SLEEP_SECONDS:-30}"
  local previous_size="-1"
  local stable_count=0
  local current_size

  while true; do
    current_size="$(file_size_bytes "${path}")"
    printf 'checkpoint size check: path=%s size=%s stable_count=%s/%s\n' \
      "${path}" "${current_size}" "${stable_count}" "${checks}"
    if [ "${current_size}" -gt 0 ] && [ "${current_size}" = "${previous_size}" ]; then
      stable_count=$((stable_count + 1))
    else
      stable_count=0
    fi
    if [ "${stable_count}" -ge "${checks}" ]; then
      break
    fi
    previous_size="${current_size}"
    sleep "${sleep_seconds}"
  done
}

next_checkpoint_to_visualize() {
  local path
  if [ -n "${CHECKPOINT}" ]; then
    if [ ! -f "${CHECKPOINT}" ]; then
      return 1
    fi
    if [ -f "$(summary_path_for_checkpoint "${CHECKPOINT}")" ]; then
      return 1
    fi
    printf '%s\n' "${CHECKPOINT}"
    return 0
  fi

  while IFS= read -r path; do
    if [ -z "${path}" ]; then
      continue
    fi
    if [ ! -f "$(summary_path_for_checkpoint "${path}")" ]; then
      printf '%s\n' "${path}"
      return 0
    fi
  done < <(compgen -G "${CHECKPOINT_PATTERN}" | sort)
  return 1
}

run_visualization_for_checkpoint() {
  local checkpoint_path="$1"
  local step
  local summary_path
  local analysis_text
  local analysis_json

  step="$(checkpoint_step "${checkpoint_path}")"
  summary_path="$(summary_path_for_checkpoint "${checkpoint_path}")"
  printf 'checkpoint selected: %s step=%s summary=%s\n' "${checkpoint_path}" "${step}" "${summary_path}"
  wait_for_stable_file "${checkpoint_path}"

  if [ -f "${summary_path}" ]; then
    printf 'visualization summary already exists after stability wait: %s\n' "${summary_path}"
    return 0
  fi

  cd "${ROOT}"
  CHECKPOINT="${checkpoint_path}" OUTPUT_DIR="${OUTPUT_DIR}" bash scripts/run_checkpoint_visualization.sh
  printf '[%s] visualization complete for step %s\n' "$(date '+%F %T %Z')" "${step}"

  analysis_text="${RUN_DIR}/analysis_after_visualization_step_${step}.txt"
  analysis_json="${RUN_DIR}/analysis_after_visualization_step_${step}.json"
  bash scripts/analyze_run.sh --run-dir "${RUN_DIR}" > "${analysis_text}"
  bash scripts/analyze_run.sh --run-dir "${RUN_DIR}" --json > "${analysis_json}"
  {
    printf '\n## %s\n\n' "$(date '+%F %T %Z')"
    printf 'Checkpoint visualization completed for `%s`.\n\n' "${checkpoint_path#${ROOT}/}"
    printf -- '- Visualization summary: `%s`\n' "${summary_path#${ROOT}/}"
    printf -- '- Feature PCA images: `%s/*_feature_pca.png`\n' "${OUTPUT_DIR#${ROOT}/}"
    printf -- '- DPT depth/ray images: `%s/step_%07d_*.png`\n' "${OUTPUT_DIR#${ROOT}/}" "${step}"
    printf -- '- Text report: `%s`\n' "${analysis_text#${ROOT}/}"
    printf -- '- JSON report: `%s`\n\n' "${analysis_json#${ROOT}/}"
    printf '```text\n'
    cat "${analysis_text}"
    printf '```\n'
  } >> "${ROOT}/EXPERIMENT_LOG.md"
  printf 'analysis written: %s\n' "${analysis_text}"
  printf 'analysis json written: %s\n' "${analysis_json}"
  printf 'experiment log appended: %s\n' "${ROOT}/EXPERIMENT_LOG.md"
}

{
  printf 'watcher_pid=%s\n' "$$"
  printf 'root=%s\nrun_dir=%s\ncheckpoint=%s\ncheckpoint_pattern=%s\noutput_dir=%s\ninterval_seconds=%s\nmax_iterations=%s\nwatch_all_checkpoints=%s\n' \
    "${ROOT}" "${RUN_DIR}" "${CHECKPOINT:-auto}" "${CHECKPOINT_PATTERN}" "${OUTPUT_DIR}" \
    "${INTERVAL_SECONDS}" "${MAX_ITERATIONS}" "${WATCH_ALL_CHECKPOINTS}"

  iteration=0
  while true; do
    iteration=$((iteration + 1))
    printf '\n[%s] watcher iteration %s\n' "$(date '+%F %T %Z')" "${iteration}"

    if checkpoint_path="$(next_checkpoint_to_visualize)"; then
      run_visualization_for_checkpoint "${checkpoint_path}"
      if [ -n "${CHECKPOINT}" ] || [ "${WATCH_ALL_CHECKPOINTS}" != "1" ]; then
        break
      fi
      continue
    fi

    printf 'no unvisualized checkpoint ready yet\n'
    if [ "${MAX_ITERATIONS}" -gt 0 ] && [ "${iteration}" -ge "${MAX_ITERATIONS}" ]; then
      printf '[%s] watcher reached max iterations without new checkpoint\n' "$(date '+%F %T %Z')"
      break
    fi
    sleep "${INTERVAL_SECONDS}"
  done
} >> "${WATCH_LOG}" 2>&1
