#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_DIR="${RUN_DIR:-${ROOT}/runs/deltatok_da3_front_back_700x252_8tok_release_aligned}"
FORMAL_LOG="${FORMAL_LOG:-${ROOT}/logs/formal_train_20260610_024230.log}"
PYTHON_BIN="${PYTHON_BIN:-/data/wlh/miniconda3/envs/da3/bin/python}"
INTERVAL_SECONDS="${INTERVAL_SECONDS:-300}"
MAX_ITERATIONS="${MAX_ITERATIONS:-0}"
LOG_DIR="${LOG_DIR:-${ROOT}/logs}"
MONITOR_LOG="${MONITOR_LOG:-${LOG_DIR}/monitor_formal_training_$(date +%Y%m%d_%H%M%S).log}"

mkdir -p "${LOG_DIR}"

emit_section() {
  printf '\n[%s] %s\n' "$(date '+%F %T %Z')" "$1"
}

tail_file() {
  local path="$1"
  local lines="${2:-5}"
  if [ -f "${path}" ]; then
    tail -n "${lines}" "${path}"
  else
    printf '%s missing\n' "${path}"
  fi
}

snapshot() {
  emit_section "processes"
  ps -eo pid,ppid,stat,etime,pcpu,pmem,cmd \
    | grep -E 'scripts/start_remote_training.sh|src/deltatok_da3/train.py --config configs/deltatok_da3_nuscenes_front_back_700x252.yaml|torchrun --standalone --nproc_per_node=2 src/deltatok_da3/train.py' \
    | grep -v grep || true

  emit_section "metrics tail"
  tail_file "${RUN_DIR}/metrics.csv" 6

  emit_section "validation tail"
  tail_file "${RUN_DIR}/val_metrics.csv" 6

  emit_section "full validation tail"
  tail_file "${RUN_DIR}/full_val_metrics.csv" 4

  emit_section "checkpoints"
  if [ -d "${RUN_DIR}/checkpoints" ]; then
    find "${RUN_DIR}/checkpoints" -maxdepth 1 -type f \
      -printf '%f %s %TY-%Tm-%Td %TH:%TM:%TS\n' | sort || true
  else
    printf '%s/checkpoints missing\n' "${RUN_DIR}"
  fi

  emit_section "gpu 2,3"
  nvidia-smi --query-gpu=index,memory.used,memory.free,utilization.gpu,temperature.gpu \
    --format=csv,noheader,nounits | sed -n '3,4p' || true

  emit_section "recent anomalies"
  if [ -f "${FORMAL_LOG}" ]; then
    if [ -f "${ROOT}/scripts/check_strict_anomalies.py" ]; then
      "${PYTHON_BIN}" "${ROOT}/scripts/check_strict_anomalies.py" --log "${FORMAL_LOG}" --tail 20 || true
    else
      grep -Ein 'oom|out of memory|(^|[^[:alpha:]])nan([^[:alpha:]]|$)|(^|[^[:alpha:]])inf([^[:alpha:]]|$)|traceback|runtimeerror|childfailed|exception' "${FORMAL_LOG}" \
        | tail -n 20 || true
    fi
  else
    printf '%s missing\n' "${FORMAL_LOG}"
  fi
}

{
  printf 'monitor_pid=%s\n' "$$"
  printf 'root=%s\nrun_dir=%s\nformal_log=%s\ninterval_seconds=%s\nmax_iterations=%s\n' \
    "${ROOT}" "${RUN_DIR}" "${FORMAL_LOG}" "${INTERVAL_SECONDS}" "${MAX_ITERATIONS}"
  iteration=0
  while true; do
    iteration=$((iteration + 1))
    emit_section "monitor iteration ${iteration}"
    snapshot
    if [ "${MAX_ITERATIONS}" -gt 0 ] && [ "${iteration}" -ge "${MAX_ITERATIONS}" ]; then
      emit_section "monitor complete"
      break
    fi
    sleep "${INTERVAL_SECONDS}"
  done
} >> "${MONITOR_LOG}" 2>&1
