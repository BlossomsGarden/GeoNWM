#!/usr/bin/env python
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


DEFAULT_RUN_DIR = "runs/deltatok_da3_front_back_700x252_8tok_release_aligned"
DEFAULT_CONFIG = "configs/deltatok_da3_nuscenes_front_back_700x252.yaml"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Write a read-only reproducibility manifest.")
    parser.add_argument("--run-dir", default=DEFAULT_RUN_DIR)
    parser.add_argument("--config", default=DEFAULT_CONFIG)
    parser.add_argument("--output", default=None)
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def file_record(root: Path, path: Path) -> dict[str, Any]:
    stat = path.stat()
    return {
        "path": path.relative_to(root).as_posix(),
        "size_bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "sha256": sha256_file(path),
    }


def collect_project_files(root: Path) -> list[dict[str, Any]]:
    candidates: list[Path] = []
    for rel in ["configs", "src/deltatok_da3", "scripts"]:
        base = root / rel
        if base.exists():
            candidates.extend(path for path in base.rglob("*") if path.is_file())
    for rel in ["README.md", "EXPERIMENT_LOG.md"]:
        path = root / rel
        if path.exists():
            candidates.append(path)
    return [file_record(root, path) for path in sorted(set(candidates))]


def safe_command(command: list[str]) -> dict[str, Any]:
    try:
        result = subprocess.run(
            command,
            check=False,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=20,
        )
        return {
            "returncode": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }
    except Exception as exc:  # pragma: no cover - defensive manifest path
        return {"error": repr(exc)}


def path_summary(path: str | None) -> dict[str, Any]:
    if not path:
        return {"path": None, "exists": False}
    p = Path(path)
    out: dict[str, Any] = {"path": str(p), "exists": p.exists()}
    if p.exists():
        stat = p.stat()
        out.update({"is_dir": p.is_dir(), "size_bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns})
        if p.is_file():
            out["sha256"] = sha256_file(p)
        elif p.is_dir():
            children = sorted(child for child in p.iterdir() if child.is_file())
            out["top_level_files"] = [
                {
                    "name": child.name,
                    "size_bytes": child.stat().st_size,
                    "mtime_ns": child.stat().st_mtime_ns,
                }
                for child in children[:32]
            ]
    return out


def main() -> None:
    args = parse_args()
    root = Path(__file__).resolve().parents[1]
    run_dir = (root / args.run_dir).resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    config_path = (root / args.config).resolve()

    config_text = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    model_dir = None
    nuscenes_root = None
    for line in config_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("da3_model_dir:"):
            model_dir = stripped.split(":", 1)[1].strip()
        if stripped.startswith("nuscenes_root:"):
            nuscenes_root = stripped.split(":", 1)[1].strip()

    timestamp = datetime.now().astimezone().strftime("%Y-%m-%dT%H:%M:%S%z")
    manifest = {
        "timestamp": timestamp,
        "root": str(root),
        "run_dir": str(run_dir),
        "python": {
            "executable": sys.executable,
            "version": sys.version,
            "platform": platform.platform(),
        },
        "environment": {
            "conda_default_env": os.environ.get("CONDA_DEFAULT_ENV"),
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "pythonpath": os.environ.get("PYTHONPATH"),
        },
        "commands": {
            "nvidia_smi": safe_command(
                [
                    "nvidia-smi",
                    "--query-gpu=index,name,memory.total,memory.used,memory.free,utilization.gpu",
                    "--format=csv,noheader,nounits",
                ]
            ),
            "torchrun_processes": safe_command(
                [
                    "bash",
                    "-lc",
                    "ps -eo pid,ppid,stat,etime,cmd | grep -E 'torchrun --standalone --nproc_per_node=2 src/deltatok_da3/train.py|src/deltatok_da3/train.py --config configs/deltatok_da3_nuscenes_front_back_700x252.yaml' | grep -v grep || true",
                ]
            ),
        },
        "paths": {
            "config": path_summary(str(config_path)),
            "model_dir": path_summary(model_dir),
            "nuscenes_root": path_summary(nuscenes_root),
            "metrics_csv": path_summary(str(run_dir / "metrics.csv")),
            "val_metrics_csv": path_summary(str(run_dir / "val_metrics.csv")),
        },
        "project_files": collect_project_files(root),
    }

    output = Path(args.output) if args.output else run_dir / f"run_manifest_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    latest = run_dir / "run_manifest_latest.json"
    shutil.copy2(output, latest)
    print(f"manifest_written={output}")
    print(f"manifest_latest={latest}")
    print(f"project_file_count={len(manifest['project_files'])}")


if __name__ == "__main__":
    main()
