#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_DIR="${RUN_DIR:-${ROOT}/runs/deltatok_da3_front_back_700x252_8tok_release_aligned}"
CHECKPOINT="${CHECKPOINT:-${RUN_DIR}/checkpoints/step_0000050.pt}"
OUTPUT_DIR="${OUTPUT_DIR:-${RUN_DIR}/checkpoint_evals}"
SUMMARY_STEP="${SUMMARY_STEP:-50}"
SPLIT="${SPLIT:-val}"
TAG="${TAG:-full_val}"
INTERVAL_SECONDS="${INTERVAL_SECONDS:-300}"
MAX_ITERATIONS="${MAX_ITERATIONS:-0}"
LOG_DIR="${LOG_DIR:-${ROOT}/logs}"
WATCH_LOG="${WATCH_LOG:-${LOG_DIR}/watch_checkpoint_full_eval_$(date +%Y%m%d_%H%M%S).log}"
RESULT_JSON="${OUTPUT_DIR}/${TAG}_step_$(printf '%07d' "${SUMMARY_STEP}")_${SPLIT}.json"

mkdir -p "${LOG_DIR}" "${OUTPUT_DIR}"

file_size_bytes() {
  local path="$1"
  if [ ! -f "${path}" ]; then
    printf -- '-1\n'
    return
  fi
  stat -c '%s' "${path}"
}

wait_for_stable_file() {
  local path="$1"
  local checks="${STABLE_CHECKS:-2}"
  local sleep_seconds="${STABLE_SLEEP_SECONDS:-30}"
  local previous_size="-1"
  local stable_count=0

  while true; do
    current_size="$(file_size_bytes "${path}")"
    printf 'checkpoint size check: path=%s size=%s stable_count=%s/%s\n' \
      "${path}" "${current_size}" "${stable_count}" "${checks}"
    if [ "${current_size}" -gt 0 ] && [ "${current_size}" = "${previous_size}" ]; then
      stable_count=$((stable_count + 1))
    else
      stable_count=0
    fi
    if [ "${stable_count}" -ge "${checks}" ]; then
      break
    fi
    previous_size="${current_size}"
    sleep "${sleep_seconds}"
  done
}

{
  printf 'watcher_pid=%s\n' "$$"
  printf 'root=%s\nrun_dir=%s\ncheckpoint=%s\noutput_dir=%s\nresult_json=%s\ninterval_seconds=%s\nmax_iterations=%s\n' \
    "${ROOT}" "${RUN_DIR}" "${CHECKPOINT}" "${OUTPUT_DIR}" "${RESULT_JSON}" "${INTERVAL_SECONDS}" "${MAX_ITERATIONS}"

  iteration=0
  while true; do
    iteration=$((iteration + 1))
    printf '\n[%s] watcher iteration %s\n' "$(date '+%F %T %Z')" "${iteration}"

    if [ -f "${CHECKPOINT}" ]; then
      printf 'checkpoint found: %s\n' "${CHECKPOINT}"
      wait_for_stable_file "${CHECKPOINT}"
      if [ -f "${RESULT_JSON}" ]; then
        printf 'checkpoint full eval already exists: %s; exiting.\n' "${RESULT_JSON}"
        break
      fi

      cd "${ROOT}"
      CHECKPOINT="${CHECKPOINT}" OUTPUT_DIR="${OUTPUT_DIR}" SPLIT="${SPLIT}" TAG="${TAG}" \
        bash scripts/run_checkpoint_full_eval.sh
      printf '[%s] checkpoint full eval complete\n' "$(date '+%F %T %Z')"
      analysis_text="${RUN_DIR}/analysis_after_full_eval.txt"
      analysis_json="${RUN_DIR}/analysis_after_full_eval.json"
      bash scripts/analyze_run.sh --run-dir "${RUN_DIR}" > "${analysis_text}"
      bash scripts/analyze_run.sh --run-dir "${RUN_DIR}" --json > "${analysis_json}"
      manifest_output="$(bash scripts/write_run_manifest.sh)"
      snapshot_output="$(bash scripts/write_process_snapshot.sh)"
      {
        printf '\n## %s\n\n' "$(date '+%F %T %Z')"
        printf 'Checkpoint full validation completed for `%s`.\n\n' "${CHECKPOINT#${ROOT}/}"
        printf -- '- Evaluation JSON: `%s`\n' "${RESULT_JSON#${ROOT}/}"
        printf -- '- Evaluation directory: `%s`\n' "${OUTPUT_DIR#${ROOT}/}"
        printf -- '- Text report: `%s`\n' "${analysis_text#${ROOT}/}"
        printf -- '- JSON report: `%s`\n\n' "${analysis_json#${ROOT}/}"
        printf 'Evaluation result:\n\n'
        printf '```json\n'
        cat "${RESULT_JSON}"
        printf '\n```\n\n'
        printf 'Analyzer report:\n\n'
        printf '```text\n'
        cat "${analysis_text}"
        printf '```\n\n'
        printf 'Manifest output:\n\n'
        printf '```text\n%s\n```\n\n' "${manifest_output}"
        printf 'Process snapshot output:\n\n'
        printf '```text\n%s\n```\n'
      } >> "${ROOT}/EXPERIMENT_LOG.md"
      printf 'analysis written: %s\n' "${analysis_text}"
      printf 'analysis json written: %s\n' "${analysis_json}"
      printf 'experiment log appended: %s\n' "${ROOT}/EXPERIMENT_LOG.md"
      break
    fi

    printf 'checkpoint not ready yet\n'
    if [ "${MAX_ITERATIONS}" -gt 0 ] && [ "${iteration}" -ge "${MAX_ITERATIONS}" ]; then
      printf '[%s] watcher reached max iterations without checkpoint\n' "$(date '+%F %T %Z')"
      break
    fi
    sleep "${INTERVAL_SECONDS}"
  done
} >> "${WATCH_LOG}" 2>&1
