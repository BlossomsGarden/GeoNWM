# Experiment Log

## 2026-06-10 04:37 CST

Formal training has been launched on the remote server:

- Project: `/data/wlh/DA3/code/DeltaTok-DA3-nuscenes`
- Run directory: `/data/wlh/DA3/code/DeltaTok-DA3-nuscenes/runs/deltatok_da3_front_back_700x252_8tok`
- Log: `/data/wlh/DA3/code/DeltaTok-DA3-nuscenes/logs/formal_train_20260610_024230.log`
- GPUs: `CUDA_VISIBLE_DEVICES=2,3`
- Launcher PID observed: `1758469`
- Torchrun PID observed: `1758598`
- Worker PIDs observed: `1758795`, `1758796`

Verified setup:

- Full nuScenes pair indexing uses `CAM_FRONT` and `CAM_BACK`.
- Remote dataset count observed in the formal log: `train_pairs=55498`, `val_pairs=11840`.
- Images are resized/cropped to `3x252x700`.
- Frozen DA3 anyview DPT-projected feature shapes were previously verified as:
  - level 1: `B x 900 x 256`
  - level 2: `B x 900 x 512`
  - level 3: `B x 900 x 1024`
  - level 4: `B x 900 x 1024`
- The DeltaTok model uses 8 tokens per level and keeps native DA3 projected channel widths; no padding to 1024 is used.
- Batch probe selected `batch_size_per_gpu=64`, `grad_accum_steps=8`, effective batch size `1024`.
- Validation memory settings are `val_batch_size=4`, `decoder_chunk_size=1`, `max_val_batches=64`.

Observed early training signal:

- Latest observed step: `140`
- `train_mse=0.22353559732437134`
- `copy_mse=0.26664024591445923`
- `relative_improvement=0.16165844897966486`
- `lr=2.82e-05`
- GPU 2/3 utilization was 100%.
- No OOM, NaN, traceback, runtime error, or child failure was found in the formal log at this checkpoint.

Code audit note:

- `decode_projected_features` follows the frozen DA3 `DualDPT` tail after the four DPT projection layers.
- Training validation now reads DA3 decoder output keys through `extractor.da3.head.head_main` and `extractor.da3.head.head_aux`, matching the visualization script and avoiding hard-coded head-name assumptions.

Pending evidence:

- First limited validation is scheduled at step `500`; `val_metrics.csv` is expected only after that point.
- First checkpoint is scheduled at step `1000`; `checkpoints/last.pt` and `checkpoints/step_0001000.pt` are expected only after that point.
- Fixed-sample visual diagnostics should be run after the first checkpoint with `bash scripts/run_checkpoint_visualization.sh`, which now defaults to auto-selecting a non-training GPU.
- Strong scientific claims should wait for validation, checkpoint, and visualization evidence rather than relying only on training-batch improvement.

## 2026-06-10 04:44 CST

Additional safeguards were added without changing the formal training target,
feature dimensions, data split, optimizer settings, or the active DDP run:

- `src/deltatok_da3/train.py` now reads DA3 decoder metric keys from
  `extractor.da3.head.head_main` and `extractor.da3.head.head_aux` during
  validation, matching the visualization code path.
- `scripts/run_checkpoint_visualization.sh` now defaults to `DEVICE=auto`,
  excludes training GPUs `2,3`, and chooses an idle GPU by free memory.
- `scripts/watch_checkpoint_visualization.sh` was added to wait for
  `step_0001000.pt` and then run fixed-sample visualization once.

Remote status after syncing:

- Remote shell syntax check passed for the visualization scripts.
- Visualization watcher started with PID `1853660`.
- Watcher log: `logs/watch_checkpoint_visualization_20260610_0443.log`.
- The watcher observed that the step-1000 checkpoint was not ready yet.

Latest observed training status:

- Step `150`
- `train_mse=0.21583330631256104`
- `copy_mse=0.2635088264942169`
- `relative_improvement=0.1809257049031039`
- GPU 2/3 utilization remained 100%.
- No anomaly lines were observed in the formal training log.

## 2026-06-10 04:52 CST

The enhanced remote smoke check passed on `cuda:4`, avoiding training GPUs `2,3`.
It provides structural evidence for the formal experiment:

- `train_pairs=55498`
- `val_pairs=11840`
- Train cameras: `CAM_FRONT=27749`, `CAM_BACK=27749`
- Val cameras: `CAM_FRONT=5920`, `CAM_BACK=5920`
- Max adjacent-frame gap stayed below the configured bound:
  - train max gap: `749942 us`
  - val max gap: `749826 us`
- DA3 projected feature shapes:
  - `(2, 900, 256)`
  - `(2, 900, 512)`
  - `(2, 900, 1024)`
  - `(2, 900, 1024)`
- DA3 parameters were confirmed frozen.
- DeltaTok reconstructed feature shapes:
  - `(1, 900, 256)`
  - `(1, 900, 512)`
  - `(1, 900, 1024)`
  - `(1, 900, 1024)`
- Delta token shapes:
  - `(1, 8, 256)`
  - `(1, 8, 512)`
  - `(1, 8, 1024)`
  - `(1, 8, 1024)`
- No padding channels were used; native projected channels are `[256, 512, 1024, 1024]`.
- DA3 decoder keys were confirmed as `depth` and `ray`.
- The script ended with `smoke_check_ok True`.

## 2026-06-10 05:06 CST

Read-only run analysis tooling was added and verified remotely:

- `scripts/analyze_run.py` summarizes CSV/file evidence without importing torch or initializing CUDA.
- `scripts/analyze_run.sh` activates the fixed `da3` conda environment before running the analyzer, avoiding the remote shell's missing bare `python`.
- Remote analyzer output at this point:
  - latest training step: `190`
  - `train_mse=0.21778152883052826`
  - `copy_mse=0.2660755217075348`
  - relative improvement: `18.15%`
  - best logged train relative improvement: `19.26%` at step `170`
  - latest per-level relative improvements:
    - level 1: `8.69%`
    - level 2: `14.44%`
    - level 3: `21.41%`
    - level 4: `36.07%`
  - non-finite metric count: `0`
  - validation/checkpoint/visualization were still pending as expected.

The first-validation watcher was also started:

- PID: `1870091`
- Log: `logs/watch_validation_analysis_20260610_0505.log`
- Behavior: wait until `val_metrics.csv` reaches step `500`, then write
  `analysis_step_500.txt` and `analysis_step_500.json` under the run directory.
- This watcher reads CSV files only and does not initialize CUDA.

Analyzer update after syncing the note about metric interpretation:

- Latest training step: `200`
- `train_mse=0.23402421176433563`
- `copy_mse=0.29867592453956604`
- Relative improvement: `21.65%`
- Best logged train relative improvement so far: `21.65%` at step `200`
- Latest per-level relative improvements:
  - level 1: `9.25%`
  - level 2: `15.33%`
  - level 3: `25.85%`
  - level 4: `45.02%`
- Non-finite metric count: `0`

Interpretation note: train metrics are logged from the final micro-batch of each
accumulated optimizer step. They are a useful health signal, but formal claims
should rely on `val_metrics.csv`, full validation, checkpoints, and fixed-sample
decoder visualizations.

## 2026-06-10 05:20 CST

A one-batch validation-path preflight was run on non-training GPU `cuda:6`.
This did not touch the active DDP training process on GPUs `2,3`.

Purpose:

- Exercise the exact `validate(...)` path before the first scheduled step-500
  validation.
- Confirm DA3 projected-feature reconstruction metrics, copy-last metrics, and
  DA3 depth/ray decoder metrics are all emitted successfully.
- Confirm the zero-initialized DeltaTok decoder starts as copy-last, as expected.

Observed output:

- `validation_preflight_ok True`
- `val_mse=0.19741477072238922`
- `val_copy_mse=0.19741477072238922`
- `val_level1_mse=0.1549358367919922`
- `val_level2_mse=0.29945993423461914`
- `val_level3_mse=0.31509900093078613`
- `val_level4_mse=0.020164307206869125`
- `val_depth_mse=0.33967000246047974`
- `val_copy_depth_mse=0.33967000246047974`
- `val_ray_mse=9.030152432387695e-05`
- `val_copy_ray_mse=9.030152432387695e-05`

Interpretation:

- This is not a replacement for formal validation on the trained checkpoint.
- It confirms the validation code path is structurally healthy and should be
  able to write the scheduled `val_metrics.csv` at step `500`.

## 2026-06-10 05:24 CST

Checkpoint visualization watcher reliability was tightened:

- `scripts/watch_checkpoint_visualization.sh` now waits for the checkpoint file
  size to remain stable before loading `step_0001000.pt`.
- This avoids a race where the watcher could theoretically observe a checkpoint
  path before `torch.save` has finished writing it.
- The change affects only the diagnostic watcher and does not change training,
  validation, model dimensions, optimizer settings, or dataset usage.

## 2026-06-10 05:30 CST

A reproducibility manifest was generated on the remote server:

- Manifest: `runs/deltatok_da3_front_back_700x252_8tok/run_manifest_20260610_053016.json`
- Latest manifest copy: `runs/deltatok_da3_front_back_700x252_8tok/run_manifest_latest.json`
- Project files hashed: `29`
- Metrics CSV existed at manifest time; `val_metrics.csv` did not yet exist.
- Key file hashes:
  - `configs/deltatok_da3_nuscenes_front_back_700x252.yaml`:
    `e6f19e979cb8c066af427d1227ae22f6db12abbf26af49f3567fd55681060c2c`
  - `src/deltatok_da3/data.py`:
    `8483a9be63f1edeae6e5009003533bdeeff390b205bb037153b3c707846b84d3`
  - `src/deltatok_da3/da3_features.py`:
    `78929466de304d87d802eb62b14d3fdc3f30e33c02cb7edf047781b9d22515db`
  - `src/deltatok_da3/model.py`:
    `6df5ae1724348c801a355af0c7ad93422ba61f0c622b462e9fd4cf238b92c4c7`
  - `src/deltatok_da3/train.py`:
    `dadb19434b9b4ba209a55ce3545f85167556266198e5b5d15c01afeaa0a51572`

Source-version note:

- The active DDP training process was launched before the later
  `src/deltatok_da3/train.py` validation-key robustness patch.
- Therefore, the manifest records the current project directory used for
  monitoring/resume/diagnostics, not a byte-identical snapshot of the already
  loaded Python module inside the active process.
- The only known post-launch `train.py` behavioral change is replacing
  hard-coded `.depth` / `.ray` validation access with dynamic
  `head.head_main` / `head.head_aux` dictionary access.
- DA3 decoder keys were independently verified as `depth` and `ray`, so this
  patch is behaviorally equivalent for the active DA3 model and does not change
  training updates, feature dimensions, losses, optimizer settings, data usage,
  or checkpoint tensor format.

## 2026-06-10 05:36 CST

A validation memory preflight was run on non-training GPU `cuda:4` with the
formal validation settings:

- `val_batch_size=4`
- `decoder_chunk_size=1`
- `max_batches=1`
- `validation_memory_preflight_ok True`
- peak allocated memory: `7.051 GB`
- peak reserved memory: `7.695 GB`

Observed one-batch metrics from the zero-initialized DeltaTok model:

- `val_mse=0.23330548405647278`
- `val_copy_mse=0.23330548405647278`
- `val_level1_mse=0.16521205008029938`
- `val_level2_mse=0.3357028663158417`
- `val_level3_mse=0.40593641996383667`
- `val_level4_mse=0.026370612904429436`
- `val_depth_mse=0.21703016757965088`
- `val_copy_depth_mse=0.21703016757965088`
- `val_ray_mse=0.000305863592075184`
- `val_copy_ray_mse=0.000305863592075184`

Interpretation:

- This confirms the scheduled validation path can run with the configured
  validation batch and decoder chunk settings.
- The preflight used a newly initialized model, so equality with copy-last is
  expected and is not a formal trained-model result.
- The result reduces step-500 OOM risk, but the formal evidence remains the
  actual `val_metrics.csv` row produced by the active DDP training run.

## 2026-06-10 05:41 CST

Future recovery safety was added to the project directory:

- `src/deltatok_da3/train.py` now saves
  `checkpoints/pre_validation_latest.pt` immediately before scheduled
  validation.
- This is intended to prevent future validation-time failures from losing the
  last completed optimizer step.
- The updated code compiled successfully on the remote server.
- A new manifest was generated:
  `runs/deltatok_da3_front_back_700x252_8tok/run_manifest_20260610_054114.json`
- Updated key hashes:
  - `README.md`:
    `97ade94bdf6c4718b783d653b1511105afd6f92b067ab4b08895044d113ee9d1`
  - `src/deltatok_da3/train.py`:
    `d26b17b0337f64f0abbc91cccea7be3106ee16f9aa049b22b96306ad7864f9cc`

Active-process note:

- The current DDP training process was already running before this safety
  checkpoint patch was synced.
- Therefore, the active step-500 validation will still use the Python module
  loaded at launch time and may not emit `pre_validation_latest.pt`.
- The patch is available for any future restart/resume. It does not change DA3
  feature dimensions, model architecture, optimizer settings, loss, data scope,
  or checkpoint tensor format.
- Given the validation memory preflight and the cost of discarding current
  progress, the active formal run was not restarted solely to pick up this
  recovery enhancement.

## 2026-06-10 05:52 CST

An active-process snapshot was generated for the formal run:

- Snapshot: `runs/deltatok_da3_front_back_700x252_8tok/process_snapshot_20260610_055254.json`
- Latest snapshot copy: `runs/deltatok_da3_front_back_700x252_8tok/process_snapshot_latest.json`
- Matched process count: `19`
- Main launcher observed:
  - torchrun PID: `1758598`
  - cwd: `/data/wlh/DA3/code/DeltaTok-DA3-nuscenes`
  - `CONDA_DEFAULT_ENV=da3`
  - `CUDA_VISIBLE_DEVICES=2,3`
- DDP workers observed:
  - rank 0 PID: `1758795`, `LOCAL_RANK=0`, `WORLD_SIZE=2`
  - rank 1 PID: `1758796`, `LOCAL_RANK=1`, `WORLD_SIZE=2`
- Snapshot artifact state:
  - `metrics.csv` existed.
  - `val_metrics.csv` did not yet exist.

Interpretation:

- This snapshot anchors the formal run to the active torchrun/worker processes
  and environment, complementing the source/config manifest.
- It is read-only evidence and does not affect the training process.

## 2026-06-10 06:03 CST

The formal run was re-audited after handoff, without changing the active DDP
training process:

- Active training remained on `CUDA_VISIBLE_DEVICES=2,3` with torchrun PID
  `1758598` and DDP worker PIDs `1758795`, `1758796`.
- Latest analyzer output at audit time:
  - training step: `270`
  - `train_mse=0.1962430328130722`
  - `copy_mse=0.24723121523857117`
  - relative improvement: `20.62%`
  - learning rate: `5.42e-05`
- `metrics.csv` contained no non-finite values.
- `val_metrics.csv` was still absent, which is expected before the first
  scheduled validation at step `500`.
- No OOM, NaN, traceback, runtime error, child failure, or real training error
  was observed in the formal log. The only line matched by a broad `error`
  grep was the successful batch-probe field `error=`.

Code/path audit:

- The config still targets native DA3 projected channels
  `[256, 512, 1024, 1024]` and `num_delta_tokens=8`.
- The dataset uses only `CAM_FRONT` and `CAM_BACK`. Camera intrinsics are used
  only for DVGT-style resize/crop geometry, not as model input.
- The DeltaTok model is a single four-level checkpoint with per-level encoder
  and decoder modules; it does not split the experiment into four independent
  tokenizers.
- The loss remains the equal-weight mean of four real projected-feature MSE
  terms, with no padding channels and no padding mask.

Pending evidence remains unchanged:

- Step `500` limited validation and automatic `analysis_step_500.*`.
- Step `1000` checkpoint and automatic fixed-sample visualization.
- Longer-run validation before making strong scientific claims.

## 2026-06-10 06:17 CST

Read-only diagnostic tooling was tightened while leaving the active DDP
training process untouched:

- Added `scripts/check_strict_anomalies.py`.
- Updated `scripts/monitor_formal_training.sh` so future monitor launches use
  the strict scanner through `/data/wlh/miniconda3/envs/da3/bin/python`.
- The strict scanner avoids false positives such as matching `INFO` as `inf`.
- Remote syntax/compile checks passed:
  - `bash -n scripts/monitor_formal_training.sh`
  - `python -m py_compile scripts/check_strict_anomalies.py`
- A strict scan of `logs/formal_train_20260610_024230.log` reported:
  - `strict_anomaly_count 0`

This change affects only diagnostics and evidence quality. It does not alter
the model, DA3 feature dimensions, data scope, optimizer, loss, batch settings,
or the currently running Python training process.

## 2026-06-10 06:31 CST

A new read-only monitor instance using the strict anomaly scanner was started:

- PID: `1932557`
- Log: `logs/monitor_formal_training_strict_20260610_0630.log`
- PID file: `logs/monitor_formal_training_strict_20260610_0630.pid`
- The first strict-monitor snapshot observed the formal DDP run still active on
  GPUs `2,3`.
- Latest training metric in that snapshot:
  - step: `310`
  - `train_mse=0.22487060725688934`
  - `copy_mse=0.2943218946456909`
  - relative improvement: `23.60%`
  - learning rate: `6.22e-05`
- `val_metrics.csv`, `full_val_metrics.csv`, and checkpoints were still absent,
  which remains expected before step `500` / step `1000`.
- Strict anomaly scan remained clean:
  - `strict_anomaly_count 0`

This monitor is diagnostic only. It does not modify training state, model
weights, optimizer state, data loading, or validation scheduling.

## 2026-06-10 06:34 CST

The checkpoint visualization watcher was tightened so it cannot accidentally
skip the step-1000 diagnostic because of an unrelated old visualization summary:

- Updated `scripts/watch_checkpoint_visualization.sh`.
- The watcher now checks specifically for
  `visualizations/summary_step_0001000.csv` before deciding visualization is
  already complete.
- The previous checkpoint watcher PID `1885910` was stopped.
- A new checkpoint watcher was started:
  - PID: `1934400`
  - Log: `logs/watch_checkpoint_visualization_20260610_summary_step_exact.log`
  - Expected checkpoint:
    `runs/deltatok_da3_front_back_700x252_8tok/checkpoints/step_0001000.pt`
  - Expected summary:
    `runs/deltatok_da3_front_back_700x252_8tok/visualizations/summary_step_0001000.csv`
- Remote syntax check passed with `bash -n scripts/watch_checkpoint_visualization.sh`.

This change is diagnostic only. It does not affect the active DDP training
process, model weights, feature dimensions, optimizer state, data loading, or
validation schedule.

## 2026-06-10 07:02 CST

The first-validation watcher was upgraded to archive stronger evidence when
step `500` validation becomes available:

- Updated `scripts/watch_validation_analysis.sh`.
- The watcher now writes, after `val_metrics.csv` reaches step `500`:
  - `analysis_step_500.txt`
  - `analysis_step_500.json`
  - `strict_anomalies_step_500.txt`
  - a fresh run manifest
  - a fresh process snapshot
- The previous validation watcher PID `1876923` was stopped.
- A new validation watcher was started:
  - PID: `1949630`
  - Log: `logs/watch_validation_analysis_20260610_artifact_archive.log`
- Remote syntax check passed with `bash -n scripts/watch_validation_analysis.sh`.
- The watcher initially observed `val_step=0`, as expected before step `500`.
- Current analyzer status at restart time:
  - latest training step: `350`
  - `train_mse=0.1895740032196045`
  - `copy_mse=0.26132357120513916`
  - relative improvement: `27.46%`
  - strict anomaly count: `0`

This is a diagnostic/evidence-chain change only. It does not affect the active
training process, model weights, feature dimensions, optimizer state, data
loading, or validation schedule.

## 2026-06-10 07:14 CST

GPU memory was audited before the first scheduled validation because validation
runs inside the active training process and can require extra transient memory:

- Latest analyzer status during the audit:
  - step: `370`
  - `train_mse=0.20653748512268066`
  - `copy_mse=0.2741561830043793`
  - relative improvement: `24.66%`
  - strict anomaly count: `0`
- GPU `2`:
  - memory used/free: `34922 MB / 13718 MB`
  - active formal rank: PID `1758795`
- GPU `3`:
  - memory used/free: `38802 MB / 9839 MB`
  - active formal rank: PID `1758796`
  - one unrelated process was also present: PID `1954232`, about `3876 MB`,
    owned by another user.

No unrelated process was killed or modified. Given the current free memory and
the prior validation-memory preflight, the formal run was left untouched and
allowed to continue toward step `500`.

## 2026-06-10 release-alignment audit

The local code was audited against `0606-lightworldpred/DeltaWorld.txt` and the
released `deltatok-src` implementation. This was a code/config/documentation
alignment pass only; no new remote training was launched in this audit.

Confirmed source behavior:

- The DeltaWorld appendix text says tokenizer training uses MSE and
  `weight_decay=1e-4`, but the released `training/deltatok.py` defaults to
  `loss_fn="log_cosh"` and `weight_decay=1e-2`; the public DeltaTok YAML does
  not override those defaults.
- Released DeltaTok uses 12 encoder blocks and 12 decoder blocks.
- Released DeltaTok initializes LayerScale to `1e-5`, uses gated attention,
  QK-Norm, and SwiGLU, and omits decoder final LayerNorm.
- Released DeltaTok uses DINOv3 2D RoPE for tokenizer spatial tokens.

Code changes from this audit:

- `src/deltatok_da3/model.py` now applies 2D RoPE to Q/K before QK-Norm,
  preserves per-head gated attention, uses SwiGLU, keeps LayerScale at `1e-5`,
  and keeps decoder output on the no-final-LayerNorm path instead of relying on
  a separate zero-initialized residual head.
- The DA3 `700x252` image size is wired as a non-square RoPE patch grid
  `18x50 = 900` through training, checkpoint evaluation, visualization, and
  the remote smoke check.
- The formal config remains a single four-level checkpoint with 8 tokens per
  level, native channels `[256,512,1024,1024]`, 12/12 depth, `log_cosh`,
  `weight_decay=1e-2`, bf16, AdamW, 5K warmup to `1e-3`, and grad clip `1e-2`.
- `README.md` now separates the historical interrupted run
  `runs/deltatok_da3_front_back_700x252_8tok` from the current release-aligned
  default run directory
  `runs/deltatok_da3_front_back_700x252_8tok_release_aligned`.

Local verification:

- Python syntax/compile checks passed for:
  - `src/deltatok_da3/model.py`
  - `src/deltatok_da3/train.py`
  - `src/deltatok_da3/evaluate_checkpoint.py`
  - `src/deltatok_da3/visualize_checkpoint.py`
  - diagnostic helper scripts with Python entry points
- Local forward smoke testing could not be run because this Windows environment
  lacks the `torch` package and WSL/bash. The remote `da3` environment should run
  `CONDA_ENV_NAME=da3 bash scripts/remote_smoke_check.sh` before relaunching
  formal training.
