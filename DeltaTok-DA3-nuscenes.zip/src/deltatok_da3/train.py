from __future__ import annotations

import argparse
import csv
import json
import logging
import math
import os
import random
import shutil
import sys
import time
from contextlib import nullcontext
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
import yaml

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deltatok_da3.config import Config, load_config, to_plain_dict
from deltatok_da3.da3_features import DA3ProjectedFeatureExtractor
from deltatok_da3.data import NuScenesPairDataset, collate_pairs
from deltatok_da3.model import MultiLevelDeltaTok, copy_last_mse, multilevel_loss, multilevel_mse


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--grad-accum-steps", type=int, default=None)
    parser.add_argument("--resume", default=None)
    parser.add_argument("--max-steps", type=int, default=None)
    return parser.parse_args()


def setup_distributed() -> tuple[bool, int, int, int, torch.device]:
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    distributed = world_size > 1
    if distributed:
        dist.init_process_group(backend="nccl")
    if not torch.cuda.is_available():
        raise RuntimeError("DeltaTok-DA3 formal training requires CUDA.")
    torch.cuda.set_device(local_rank)
    return distributed, rank, local_rank, world_size, torch.device("cuda", local_rank)


def cleanup_distributed() -> None:
    if dist.is_available() and dist.is_initialized():
        dist.destroy_process_group()


def seed_everything(seed: int, rank: int) -> None:
    seed = int(seed) + int(rank)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def setup_logger(out_dir: Path, rank: int) -> logging.Logger:
    logger = logging.getLogger("deltatok_da3")
    logger.handlers.clear()
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if rank != 0:
        logger.addHandler(logging.NullHandler())
        return logger
    out_dir.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("[%(asctime)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    stream = logging.StreamHandler()
    stream.setFormatter(fmt)
    file_handler = logging.FileHandler(out_dir / "train.log", encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def precision_context(device: torch.device, precision: str):
    if precision == "bf16":
        return torch.autocast(device_type=device.type, dtype=torch.bfloat16)
    if precision == "fp16":
        return torch.autocast(device_type=device.type, dtype=torch.float16)
    return nullcontext()


def build_datasets(config: Config) -> tuple[NuScenesPairDataset, NuScenesPairDataset]:
    train_set = NuScenesPairDataset(
        root=config.data.nuscenes_root,
        split=config.data.train_split,
        image_size=config.data.image_size,
        cameras=config.data.cameras,
        max_frame_gap_factor=config.data.max_frame_gap_factor,
    )
    val_set = NuScenesPairDataset(
        root=config.data.nuscenes_root,
        split=config.data.val_split,
        image_size=config.data.image_size,
        cameras=config.data.cameras,
        max_frame_gap_factor=config.data.max_frame_gap_factor,
    )
    return train_set, val_set


def build_loader(
    dataset: NuScenesPairDataset,
    config: Config,
    batch_size: int,
    rank: int,
    world_size: int,
    train: bool,
    num_workers: int | None = None,
) -> DataLoader:
    sampler = DistributedSampler(
        dataset,
        num_replicas=world_size,
        rank=rank,
        shuffle=train,
        drop_last=train,
    )
    return DataLoader(
        dataset,
        batch_size=batch_size,
        sampler=sampler,
        shuffle=False,
        drop_last=train,
        num_workers=config.train.num_workers if num_workers is None else int(num_workers),
        pin_memory=True,
        persistent_workers=(config.train.num_workers if num_workers is None else int(num_workers)) > 0,
        collate_fn=collate_pairs,
    )


def patch_grid_from_config(config: Config) -> tuple[int, int]:
    return (config.data.image_size[1] // 14, config.data.image_size[0] // 14)


def build_model(config: Config, max_patches: int) -> MultiLevelDeltaTok:
    return MultiLevelDeltaTok(
        feature_channels=config.model.feature_channels,
        num_delta_tokens=config.model.num_delta_tokens,
        encoder_depth=config.model.encoder_depth,
        decoder_depth=config.model.decoder_depth,
        num_heads=config.model.num_heads,
        mlp_ratio=config.model.mlp_ratio,
        dropout=config.model.dropout,
        max_patches=max_patches,
        use_checkpointing=config.model.use_checkpointing,
        patch_grid=patch_grid_from_config(config),
        layer_scale_init=config.model.layer_scale_init,
        use_qk_norm=config.model.use_qk_norm,
        use_gated_attn=config.model.use_gated_attn,
        use_swiglu=config.model.use_swiglu,
    )


def unwrap_model(model: torch.nn.Module) -> torch.nn.Module:
    raw = model.module if isinstance(model, DDP) else model
    return getattr(raw, "_orig_mod", raw)


def decay_parameter_groups(model: torch.nn.Module, weight_decay: float) -> list[dict[str, Any]]:
    """Match the released DeltaTok AdamW grouping: decay only Linear/Conv weights."""
    raw_model = unwrap_model(model)
    decay_types = (
        nn.Linear,
        nn.Conv1d,
        nn.Conv2d,
        nn.Conv3d,
        nn.ConvTranspose1d,
        nn.ConvTranspose2d,
        nn.ConvTranspose3d,
    )
    decay: dict[str, nn.Parameter] = {}
    for module_name, module in raw_model.named_modules():
        if isinstance(module, decay_types):
            weight = getattr(module, "weight", None)
            if isinstance(weight, nn.Parameter) and weight.requires_grad:
                decay[f"{module_name}.weight" if module_name else "weight"] = weight
    no_decay = {
        name: param
        for name, param in raw_model.named_parameters()
        if param.requires_grad and name not in decay
    }
    decay_list = [decay[name] for name in sorted(decay)]
    no_decay_list = [no_decay[name] for name in sorted(no_decay)]
    return [
        {"params": decay_list, "weight_decay": float(weight_decay)},
        {"params": no_decay_list, "weight_decay": 0.0},
    ]


def make_optimizer_and_scheduler(model: torch.nn.Module, config: Config):
    optimizer = torch.optim.AdamW(
        decay_parameter_groups(model, config.train.weight_decay),
        lr=config.train.lr,
    )

    def lr_lambda(step: int) -> float:
        if config.train.warmup_steps > 0 and step < config.train.warmup_steps:
            return float(step + 1) / float(config.train.warmup_steps)
        return 1.0

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    return optimizer, scheduler


def maybe_compile_model(model: torch.nn.Module, config: Config, logger: logging.Logger) -> torch.nn.Module:
    if not config.train.use_compile:
        return model
    logger.info("enabling torch.compile for DeltaTok model")
    return torch.compile(model)


def move_batch(batch: dict[str, Any], device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    prev = batch["prev_image"].to(device, non_blocking=True)
    curr = batch["curr_image"].to(device, non_blocking=True)
    return prev, curr


def extract_pair_features(
    extractor: DA3ProjectedFeatureExtractor,
    prev: torch.Tensor,
    curr: torch.Tensor,
    precision: str,
    device: torch.device,
) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
    images = torch.cat([prev, curr], dim=0)
    with precision_context(device, precision):
        feats = extractor(images)
    b = prev.shape[0]
    prev_feats = [feat[:b].detach() for feat in feats]
    curr_feats = [feat[b:].detach() for feat in feats]
    return prev_feats, curr_feats


def append_csv(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def all_reduce_sum(tensor: torch.Tensor) -> torch.Tensor:
    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
    return tensor


def clear_cuda_cache(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.empty_cache()


@torch.no_grad()
def decoder_mse_chunked(
    extractor: DA3ProjectedFeatureExtractor,
    pred_feats: list[torch.Tensor],
    prev_feats: list[torch.Tensor],
    curr_feats: list[torch.Tensor],
    height: int,
    width: int,
    precision: str,
    device: torch.device,
    chunk_size: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Decode DA3 heads in chunks so validation cannot exceed training memory."""
    batch_size = int(curr_feats[0].shape[0])
    chunk_size = max(1, int(chunk_size))
    totals = torch.zeros(5, device=device, dtype=torch.float64)
    depth_key = extractor.da3.head.head_main
    ray_key = extractor.da3.head.head_aux
    for start in range(0, batch_size, chunk_size):
        end = min(start + chunk_size, batch_size)
        pred_chunk = [feat[start:end] for feat in pred_feats]
        prev_chunk = [feat[start:end] for feat in prev_feats]
        curr_chunk = [feat[start:end] for feat in curr_feats]
        with precision_context(device, precision):
            pred_decoded = extractor.decode_projected_features(pred_chunk, height, width)
            copy_decoded = extractor.decode_projected_features(prev_chunk, height, width)
            oracle_decoded = extractor.decode_projected_features(curr_chunk, height, width)
        local_bs = float(end - start)
        depth_mse = torch.nn.functional.mse_loss(
            pred_decoded[depth_key].float(), oracle_decoded[depth_key].detach().float()
        )
        copy_depth_mse = torch.nn.functional.mse_loss(
            copy_decoded[depth_key].float(), oracle_decoded[depth_key].detach().float()
        )
        ray_mse = torch.nn.functional.mse_loss(
            pred_decoded[ray_key].float(), oracle_decoded[ray_key].detach().float()
        )
        copy_ray_mse = torch.nn.functional.mse_loss(
            copy_decoded[ray_key].float(), oracle_decoded[ray_key].detach().float()
        )
        values = [
            depth_mse * local_bs,
            copy_depth_mse * local_bs,
            ray_mse * local_bs,
            copy_ray_mse * local_bs,
            torch.tensor(local_bs, device=device),
        ]
        totals += torch.tensor([float(v.detach().cpu()) for v in values], device=device, dtype=torch.float64)
    denom = totals[-1].clamp_min(1.0)
    return tuple((totals[i] / denom).to(dtype=torch.float32) for i in range(4))


@torch.no_grad()
def validate(
    model: torch.nn.Module,
    extractor: DA3ProjectedFeatureExtractor,
    loader: DataLoader,
    config: Config,
    device: torch.device,
    max_batches: int | None,
) -> dict[str, float]:
    model.eval()
    total = torch.zeros(15, device=device, dtype=torch.float64)
    num_batches = 0
    for batch in loader:
        prev, curr = move_batch(batch, device)
        prev_feats, curr_feats = extract_pair_features(
            extractor, prev, curr, config.train.precision, device
        )
        with precision_context(device, config.train.precision):
            pred, _ = model(prev_feats, curr_feats)
        loss, level_losses = multilevel_mse(pred, curr_feats)
        copy_loss, copy_levels = copy_last_mse(prev_feats, curr_feats)
        depth_mse, copy_depth_mse, ray_mse, copy_ray_mse = decoder_mse_chunked(
            extractor,
            pred,
            prev_feats,
            curr_feats,
            prev.shape[-2],
            prev.shape[-1],
            config.train.precision,
            device,
            config.train.decoder_chunk_size,
        )
        bs = float(prev.shape[0])
        values = [
            loss * bs,
            copy_loss * bs,
            *[level_loss * bs for level_loss in level_losses],
            *[copy_level * bs for copy_level in copy_levels],
            depth_mse * bs,
            copy_depth_mse * bs,
            ray_mse * bs,
            copy_ray_mse * bs,
            torch.tensor(bs, device=device),
        ]
        total += torch.tensor([float(v.detach().cpu()) for v in values], device=device, dtype=torch.float64)
        num_batches += 1
        if max_batches is not None and num_batches >= max_batches:
            break
    if num_batches == 0:
        raise RuntimeError("Validation loader produced no batches.")
    total = all_reduce_sum(total)
    denom = total[-1].item()
    names = [
        "val_mse",
        "val_copy_mse",
        "val_level1_mse",
        "val_level2_mse",
        "val_level3_mse",
        "val_level4_mse",
        "val_copy_level1_mse",
        "val_copy_level2_mse",
        "val_copy_level3_mse",
        "val_copy_level4_mse",
        "val_depth_mse",
        "val_copy_depth_mse",
        "val_ray_mse",
        "val_copy_ray_mse",
    ]
    return {name: total[i].item() / max(denom, 1.0) for i, name in enumerate(names)}


def save_checkpoint(
    path: Path,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler.LambdaLR,
    config: Config,
    step: int,
    selected_batch_size: int,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw_model = unwrap_model(model)
    torch.save(
        {
            "step": int(step),
            "selected_batch_size": int(selected_batch_size),
            "model": raw_model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "config": to_plain_dict(config),
        },
        path,
    )


def load_checkpoint(
    path: str,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer | None = None,
    scheduler: torch.optim.lr_scheduler.LambdaLR | None = None,
) -> int:
    ckpt = torch.load(path, map_location="cpu")
    unwrap_model(model).load_state_dict(ckpt["model"], strict=True)
    if optimizer is not None and ckpt.get("optimizer") is not None:
        optimizer.load_state_dict(ckpt["optimizer"])
    if scheduler is not None and ckpt.get("scheduler") is not None:
        scheduler.load_state_dict(ckpt["scheduler"])
    return int(ckpt.get("step", 0))


def probe_batch_size(
    candidates: tuple[int, ...],
    train_set: NuScenesPairDataset,
    config: Config,
    model: MultiLevelDeltaTok,
    extractor: DA3ProjectedFeatureExtractor,
    rank: int,
    world_size: int,
    device: torch.device,
    logger: logging.Logger,
    out_dir: Path,
) -> int:
    chosen = None
    probe_rows = []
    for candidate in sorted(set(int(x) for x in candidates), reverse=True):
        ok = True
        error = ""
        loader = build_loader(train_set, config, candidate, rank, world_size, train=True, num_workers=0)
        try:
            batch = next(iter(loader))
            prev, curr = move_batch(batch, device)
            with torch.enable_grad():
                prev_feats, curr_feats = extract_pair_features(
                    extractor, prev, curr, config.train.precision, device
                )
                with precision_context(device, config.train.precision):
                    pred, _ = model(prev_feats, curr_feats)
                    loss, _ = multilevel_loss(pred, curr_feats, config.train.loss_fn)
                loss.backward()
            model.zero_grad(set_to_none=True)
            del loader, batch, prev, curr, prev_feats, curr_feats, pred, loss
            torch.cuda.empty_cache()
        except RuntimeError as exc:
            ok = False
            error = str(exc).splitlines()[0]
            model.zero_grad(set_to_none=True)
            torch.cuda.empty_cache()
        flag = torch.tensor([1 if ok else 0], device=device, dtype=torch.int32)
        all_reduce_sum(flag)
        ok_all = int(flag.item()) == world_size
        probe_rows.append({"batch_size": candidate, "ok": ok_all, "rank_ok": ok, "error": error})
        if rank == 0:
            logger.info("batch probe batch_size=%s ok_all=%s rank_ok=%s error=%s", candidate, ok_all, ok, error)
        if ok_all:
            chosen = candidate
            break
    if chosen is None:
        raise RuntimeError(f"No batch size candidate fit: {probe_rows}")
    if rank == 0:
        with (out_dir / "batch_probe.json").open("w", encoding="utf-8") as f:
            json.dump(probe_rows, f, indent=2)
    return chosen


def choose_grad_accum_steps(config: Config, selected_batch: int, world_size: int) -> int:
    if config.train.grad_accum_steps > 0:
        return int(config.train.grad_accum_steps)
    per_step = max(int(selected_batch) * int(world_size), 1)
    return max(1, int(math.ceil(config.train.target_effective_batch_size / per_step)))


def main() -> None:
    args = parse_args()
    distributed, rank, _, world_size, device = setup_distributed()
    config = load_config(args.config)
    if args.batch_size is not None:
        object.__setattr__(config.train, "batch_size", int(args.batch_size))
        object.__setattr__(config.train, "batch_size_probe", (int(args.batch_size),))
    if args.grad_accum_steps is not None:
        object.__setattr__(config.train, "grad_accum_steps", int(args.grad_accum_steps))
    if args.max_steps is not None:
        object.__setattr__(config.train, "max_steps", int(args.max_steps))
    if args.resume is not None:
        object.__setattr__(config.train, "resume", args.resume)

    seed_everything(config.train.seed, rank)
    torch.set_float32_matmul_precision("high")
    torch.backends.cudnn.benchmark = True
    out_dir = Path(config.train.output_dir)
    logger = setup_logger(out_dir, rank)

    if rank == 0:
        out_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(args.config, out_dir / "config.source.yaml")
        with (out_dir / "config.resolved.yaml").open("w", encoding="utf-8") as f:
            yaml.safe_dump(to_plain_dict(config), f, sort_keys=False)

    logger.info("building full nuScenes datasets")
    train_set, val_set = build_datasets(config)
    max_patches = (config.data.image_size[0] // 14) * (config.data.image_size[1] // 14)
    logger.info(
        "train_pairs=%s val_pairs=%s max_patches=%s patch_grid=%s",
        len(train_set),
        len(val_set),
        max_patches,
        patch_grid_from_config(config),
    )

    extractor = DA3ProjectedFeatureExtractor(
        config.model.da3_src,
        config.model.da3_model_dir,
        config.model.feature_channels,
    ).to(device)
    model = build_model(config, max_patches=max_patches).to(device)
    model = maybe_compile_model(model, config, logger)

    selected_batch = probe_batch_size(
        config.train.batch_size_probe,
        train_set,
        config,
        model,
        extractor,
        rank,
        world_size,
        device,
        logger,
        out_dir,
    )
    selected_grad_accum = choose_grad_accum_steps(config, selected_batch, world_size)
    logger.info(
        "selected batch_size_per_gpu=%s grad_accum_steps=%s effective_batch=%s",
        selected_batch,
        selected_grad_accum,
        selected_batch * world_size * selected_grad_accum,
    )
    if distributed:
        model = DDP(model, device_ids=[device.index], output_device=device.index, find_unused_parameters=False)

    optimizer, scheduler = make_optimizer_and_scheduler(model, config)
    start_step = 0
    resume_path = config.train.resume
    if resume_path:
        start_step = load_checkpoint(resume_path, model.module if isinstance(model, DDP) else model, optimizer, scheduler)
        logger.info("resumed from %s at step %s", resume_path, start_step)

    train_loader = build_loader(train_set, config, selected_batch, rank, world_size, train=True)
    val_loader = build_loader(val_set, config, config.train.val_batch_size, rank, world_size, train=False)
    logger.info(
        "validation batch_size_per_gpu=%s decoder_chunk_size=%s max_val_batches=%s",
        config.train.val_batch_size,
        config.train.decoder_chunk_size,
        config.train.max_val_batches,
    )
    train_iter = iter(train_loader)
    model.train()
    optimizer.zero_grad(set_to_none=True)
    t0 = time.time()
    step = start_step
    accum = 0

    while step < config.train.max_steps:
        try:
            batch = next(train_iter)
        except StopIteration:
            train_loader.sampler.set_epoch(step)
            train_iter = iter(train_loader)
            batch = next(train_iter)

        prev, curr = move_batch(batch, device)
        prev_feats, curr_feats = extract_pair_features(
            extractor, prev, curr, config.train.precision, device
        )
        sync_context = (
            model.no_sync()
            if isinstance(model, DDP) and (accum + 1) < selected_grad_accum
            else nullcontext()
        )
        with sync_context:
            with precision_context(device, config.train.precision):
                pred, _ = model(prev_feats, curr_feats)
                train_loss, train_level_losses = multilevel_loss(pred, curr_feats, config.train.loss_fn)
            scaled_loss = train_loss / float(selected_grad_accum)
            scaled_loss.backward()
        accum += 1

        if accum < selected_grad_accum:
            continue

        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config.train.grad_clip_norm)
        optimizer.step()
        scheduler.step()
        optimizer.zero_grad(set_to_none=True)
        accum = 0
        step += 1

        mse_loss, level_losses = multilevel_mse(pred, curr_feats)
        copy_loss, copy_levels = copy_last_mse(prev_feats, curr_feats)
        if rank == 0 and (step % config.train.log_every_steps == 0 or step == 1):
            elapsed = max(time.time() - t0, 1e-6)
            mem_gb = torch.cuda.max_memory_allocated(device) / (1024**3)
            row = {
                "step": step,
                "lr": optimizer.param_groups[0]["lr"],
                "train_loss": float(train_loss.detach().cpu()),
                "loss_fn": config.train.loss_fn,
                "train_mse": float(mse_loss.detach().cpu()),
                "copy_mse": float(copy_loss.detach().cpu()),
                "relative_improvement": 1.0 - float(mse_loss.detach().cpu()) / max(float(copy_loss.detach().cpu()), 1e-12),
                "level1_mse": float(level_losses[0].detach().cpu()),
                "level2_mse": float(level_losses[1].detach().cpu()),
                "level3_mse": float(level_losses[2].detach().cpu()),
                "level4_mse": float(level_losses[3].detach().cpu()),
                "copy_level1_mse": float(copy_levels[0].detach().cpu()),
                "copy_level2_mse": float(copy_levels[1].detach().cpu()),
                "copy_level3_mse": float(copy_levels[2].detach().cpu()),
                "copy_level4_mse": float(copy_levels[3].detach().cpu()),
                "grad_norm": float(grad_norm.detach().cpu()),
                "batch_size_per_gpu": selected_batch,
                "grad_accum_steps": selected_grad_accum,
                "effective_batch_size": selected_batch * world_size * selected_grad_accum,
                "gpu_mem_gb": mem_gb,
                "steps_per_sec": step / elapsed,
            }
            append_csv(out_dir / "metrics.csv", row)
            logger.info(
                "step=%s loss=%.6g copy=%.6g rel=%.4f lr=%.3g mem=%.2fGB",
                step,
                row["train_mse"],
                row["copy_mse"],
                row["relative_improvement"],
                row["lr"],
                row["gpu_mem_gb"],
            )

        run_limited_val = step % config.train.val_every_steps == 0
        run_full_val = step % config.train.full_val_every_steps == 0
        if rank == 0 and (run_limited_val or run_full_val):
            save_checkpoint(
                out_dir / "checkpoints" / "pre_validation_latest.pt",
                model,
                optimizer,
                scheduler,
                config,
                step,
                selected_batch,
            )
        if run_limited_val or run_full_val:
            del batch, prev, curr, prev_feats, curr_feats, pred, train_loss, train_level_losses, mse_loss, level_losses
            del copy_loss, copy_levels, scaled_loss
            clear_cuda_cache(device)

        if run_limited_val:
            metrics = validate(
                model.module if isinstance(model, DDP) else model,
                extractor,
                val_loader,
                config,
                device,
                max_batches=config.train.max_val_batches,
            )
            if rank == 0:
                append_csv(out_dir / "val_metrics.csv", {"step": step, **metrics})
                logger.info("val step=%s %s", step, metrics)
            model.train()
            clear_cuda_cache(device)

        if run_full_val:
            metrics = validate(
                model.module if isinstance(model, DDP) else model,
                extractor,
                val_loader,
                config,
                device,
                max_batches=None,
            )
            if rank == 0:
                append_csv(out_dir / "full_val_metrics.csv", {"step": step, **metrics})
                logger.info("full_val step=%s %s", step, metrics)
            model.train()
            clear_cuda_cache(device)

        if rank == 0 and step % config.train.save_every_steps == 0:
            save_checkpoint(out_dir / "checkpoints" / "last.pt", model, optimizer, scheduler, config, step, selected_batch)
            save_checkpoint(
                out_dir / "checkpoints" / f"step_{step:07d}.pt",
                model,
                optimizer,
                scheduler,
                config,
                step,
                selected_batch,
            )

    if rank == 0:
        save_checkpoint(out_dir / "checkpoints" / "last.pt", model, optimizer, scheduler, config, step, selected_batch)
        logger.info("training complete at step=%s", step)
    cleanup_distributed()


if __name__ == "__main__":
    main()
