from __future__ import annotations

import argparse
import csv
import sys
from contextlib import nullcontext
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deltatok_da3.config import load_config
from deltatok_da3.da3_features import DA3ProjectedFeatureExtractor
from deltatok_da3.data import NuScenesPairDataset, collate_pairs
from deltatok_da3.model import MultiLevelDeltaTok
from deltatok_da3.train import patch_grid_from_config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Visualize a DeltaTok-DA3 checkpoint on fixed val pairs.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--split", default="val", choices=("train", "val"))
    parser.add_argument("--num-samples", type=int, default=8)
    parser.add_argument("--indices", default=None, help="Comma-separated dataset indices. Overrides --num-samples.")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--precision", default=None, choices=(None, "bf16", "fp16", "fp32"))
    return parser.parse_args()


def precision_context(device: torch.device, precision: str):
    if device.type != "cuda":
        return nullcontext()
    if precision == "bf16":
        return torch.autocast(device_type=device.type, dtype=torch.bfloat16)
    if precision == "fp16":
        return torch.autocast(device_type=device.type, dtype=torch.float16)
    return nullcontext()


def build_model_from_config(config, max_patches: int) -> MultiLevelDeltaTok:
    return MultiLevelDeltaTok(
        feature_channels=config.model.feature_channels,
        num_delta_tokens=config.model.num_delta_tokens,
        encoder_depth=config.model.encoder_depth,
        decoder_depth=config.model.decoder_depth,
        num_heads=config.model.num_heads,
        mlp_ratio=config.model.mlp_ratio,
        dropout=config.model.dropout,
        max_patches=max_patches,
        use_checkpointing=False,
        patch_grid=patch_grid_from_config(config),
        layer_scale_init=config.model.layer_scale_init,
        use_qk_norm=config.model.use_qk_norm,
        use_gated_attn=config.model.use_gated_attn,
        use_swiglu=config.model.use_swiglu,
    )


def choose_indices(length: int, num_samples: int, indices: str | None) -> list[int]:
    if indices:
        out = [int(x.strip()) for x in indices.split(",") if x.strip()]
    else:
        count = max(1, min(int(num_samples), length))
        out = np.linspace(0, length - 1, count, dtype=np.int64).tolist()
    for idx in out:
        if idx < 0 or idx >= length:
            raise IndexError(f"Dataset index {idx} outside [0, {length})")
    return out


def image_to_numpy(image: torch.Tensor) -> np.ndarray:
    image = image.detach().cpu().clamp(0, 1)
    return image.permute(1, 2, 0).numpy()


def tensor_to_numpy(tensor: torch.Tensor) -> np.ndarray:
    return tensor.detach().float().cpu().numpy()


def normalize_map(values: np.ndarray, lo: float | None = None, hi: float | None = None) -> tuple[np.ndarray, float, float]:
    arr = np.asarray(values, dtype=np.float32)
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        return np.zeros_like(arr), 0.0, 1.0
    if lo is None:
        lo = float(np.percentile(finite, 2.0))
    if hi is None:
        hi = float(np.percentile(finite, 98.0))
    if hi <= lo:
        hi = lo + 1e-6
    return np.clip((arr - lo) / (hi - lo), 0.0, 1.0), lo, hi


def pca_rgb_maps(
    prev_feat: torch.Tensor,
    pred_feat: torch.Tensor,
    target_feat: torch.Tensor,
    patch_grid: tuple[int, int],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    h, w = patch_grid
    groups = [
        prev_feat[0].detach().float().cpu().numpy(),
        pred_feat[0].detach().float().cpu().numpy(),
        target_feat[0].detach().float().cpu().numpy(),
    ]
    stacked = np.concatenate(groups, axis=0).astype(np.float32)
    stacked = stacked - stacked.mean(axis=0, keepdims=True)
    cov = stacked.T @ stacked / max(stacked.shape[0] - 1, 1)
    eigvals, eigvecs = np.linalg.eigh(cov)
    order = np.argsort(eigvals)[::-1][:3]
    components = eigvecs[:, order]
    projected = stacked @ components
    if projected.shape[1] < 3:
        projected = np.pad(projected, ((0, 0), (0, 3 - projected.shape[1])), mode="constant")
    finite = projected[np.isfinite(projected)]
    if finite.size == 0:
        lo, hi = 0.0, 1.0
    else:
        lo = float(np.percentile(finite, 1.0))
        hi = float(np.percentile(finite, 99.0))
        if hi <= lo:
            hi = lo + 1e-6
    projected = np.clip((projected - lo) / (hi - lo), 0.0, 1.0)
    chunks = np.split(projected[:, :3], 3, axis=0)
    prev_rgb, pred_rgb, target_rgb = [chunk.reshape(h, w, 3) for chunk in chunks]
    err = np.linalg.norm(groups[1] - groups[2], axis=-1).reshape(h, w)
    err_n, _, _ = normalize_map(err, 0.0, None)
    return prev_rgb, pred_rgb, target_rgb, err_n


def save_feature_pca_visualization(
    path: Path,
    prev_feats: list[torch.Tensor],
    pred_feats: list[torch.Tensor],
    target_feats: list[torch.Tensor],
    patch_grid: tuple[int, int],
    title: str,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    num_levels = len(prev_feats)
    fig, axes = plt.subplots(num_levels, 4, figsize=(12, 3.0 * num_levels), dpi=140)
    fig.suptitle(title, fontsize=10)
    if num_levels == 1:
        axes = np.expand_dims(axes, axis=0)

    for level_idx, (prev_feat, pred_feat, target_feat) in enumerate(zip(prev_feats, pred_feats, target_feats), start=1):
        prev_rgb, pred_rgb, target_rgb, err_n = pca_rgb_maps(prev_feat, pred_feat, target_feat, patch_grid)
        panels: list[tuple[str, Any, str | None]] = [
            (f"level {level_idx} t-1 PCA", prev_rgb, None),
            (f"level {level_idx} pred t PCA", pred_rgb, None),
            (f"level {level_idx} target t PCA", target_rgb, None),
            (f"level {level_idx} pred abs err", err_n, "inferno"),
        ]
        for ax, (name, image, cmap) in zip(axes[level_idx - 1], panels):
            ax.imshow(image, cmap=cmap, interpolation="nearest")
            ax.set_title(name, fontsize=8)
            ax.axis("off")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path)
    plt.close(fig)


def save_visualization(
    path: Path,
    prev_rgb: np.ndarray,
    curr_rgb: np.ndarray,
    copy_depth: np.ndarray,
    pred_depth: np.ndarray,
    target_depth: np.ndarray,
    copy_ray_norm: np.ndarray,
    pred_ray_norm: np.ndarray,
    target_ray_norm: np.ndarray,
    title: str,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    depth_stack = np.stack([copy_depth, pred_depth, target_depth], axis=0)
    _, d_lo, d_hi = normalize_map(depth_stack)
    copy_depth_n, _, _ = normalize_map(copy_depth, d_lo, d_hi)
    pred_depth_n, _, _ = normalize_map(pred_depth, d_lo, d_hi)
    target_depth_n, _, _ = normalize_map(target_depth, d_lo, d_hi)
    depth_err_n, _, _ = normalize_map(np.abs(pred_depth - target_depth), 0.0, None)

    ray_stack = np.stack([copy_ray_norm, pred_ray_norm, target_ray_norm], axis=0)
    _, r_lo, r_hi = normalize_map(ray_stack)
    copy_ray_n, _, _ = normalize_map(copy_ray_norm, r_lo, r_hi)
    pred_ray_n, _, _ = normalize_map(pred_ray_norm, r_lo, r_hi)
    target_ray_n, _, _ = normalize_map(target_ray_norm, r_lo, r_hi)
    ray_err_n, _, _ = normalize_map(np.abs(pred_ray_norm - target_ray_norm), 0.0, None)

    fig, axes = plt.subplots(2, 5, figsize=(18, 7), dpi=140)
    fig.suptitle(title, fontsize=10)
    panels: list[tuple[str, Any, str | None]] = [
        ("prev rgb", prev_rgb, None),
        ("curr rgb", curr_rgb, None),
        ("copy depth", copy_depth_n, "magma"),
        ("pred depth", pred_depth_n, "magma"),
        ("target depth", target_depth_n, "magma"),
        ("depth abs err", depth_err_n, "inferno"),
        ("copy ray norm", copy_ray_n, "viridis"),
        ("pred ray norm", pred_ray_n, "viridis"),
        ("target ray norm", target_ray_n, "viridis"),
        ("ray abs err", ray_err_n, "inferno"),
    ]
    for ax, (name, image, cmap) in zip(axes.reshape(-1), panels):
        ax.imshow(image, cmap=cmap)
        ax.set_title(name, fontsize=8)
        ax.axis("off")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path)
    plt.close(fig)


def decoded_field(decoded, key: str) -> torch.Tensor:
    value = decoded[key]
    if value.ndim >= 4 and value.shape[-1] == 1:
        value = value.squeeze(-1)
    return value


@torch.no_grad()
def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    precision = args.precision or config.train.precision
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(device)
        torch.set_float32_matmul_precision("high")

    output_dir = Path(args.output_dir) if args.output_dir else Path(config.train.output_dir) / "visualizations"
    output_dir.mkdir(parents=True, exist_ok=True)

    split = config.data.val_split if args.split == "val" else config.data.train_split
    dataset = NuScenesPairDataset(
        root=config.data.nuscenes_root,
        split=split,
        image_size=config.data.image_size,
        cameras=config.data.cameras,
        max_frame_gap_factor=config.data.max_frame_gap_factor,
    )
    indices = choose_indices(len(dataset), args.num_samples, args.indices)
    patch_grid = (config.data.image_size[1] // 14, config.data.image_size[0] // 14)
    max_patches = patch_grid[0] * patch_grid[1]

    extractor = DA3ProjectedFeatureExtractor(
        config.model.da3_src,
        config.model.da3_model_dir,
        config.model.feature_channels,
    ).to(device)
    model = build_model_from_config(config, max_patches).to(device).eval()
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model.load_state_dict(checkpoint["model"], strict=True)
    ckpt_step = int(checkpoint.get("step", -1))

    head = extractor.da3.head
    depth_key = head.head_main
    ray_key = head.head_aux
    rows: list[dict[str, Any]] = []
    for sample_idx in indices:
        batch = collate_pairs([dataset[sample_idx]])
        prev = batch["prev_image"].to(device, non_blocking=True)
        curr = batch["curr_image"].to(device, non_blocking=True)
        with precision_context(device, precision):
            images = torch.cat([prev, curr], dim=0)
            feats = extractor(images)
            prev_feats = [feat[:1] for feat in feats]
            curr_feats = [feat[1:] for feat in feats]
            pred_feats, delta_tokens = model(prev_feats, curr_feats)
            copy_decoded = extractor.decode_projected_features(prev_feats, prev.shape[-2], prev.shape[-1])
            pred_decoded = extractor.decode_projected_features(pred_feats, prev.shape[-2], prev.shape[-1])
            target_decoded = extractor.decode_projected_features(curr_feats, prev.shape[-2], prev.shape[-1])

        level_mse = [
            float(F.mse_loss(pred.float(), target.float()).detach().cpu())
            for pred, target in zip(pred_feats, curr_feats)
        ]
        copy_level_mse = [
            float(F.mse_loss(prev_feat.float(), target.float()).detach().cpu())
            for prev_feat, target in zip(prev_feats, curr_feats)
        ]
        feature_mse = float(sum(level_mse) / len(level_mse))
        copy_feature_mse = float(sum(copy_level_mse) / len(copy_level_mse))

        pred_depth = decoded_field(pred_decoded, depth_key)
        target_depth = decoded_field(target_decoded, depth_key)
        copy_depth = decoded_field(copy_decoded, depth_key)
        pred_ray = decoded_field(pred_decoded, ray_key)
        target_ray = decoded_field(target_decoded, ray_key)
        copy_ray = decoded_field(copy_decoded, ray_key)

        depth_mse = float(F.mse_loss(pred_depth.float(), target_depth.float()).detach().cpu())
        copy_depth_mse = float(F.mse_loss(copy_depth.float(), target_depth.float()).detach().cpu())
        ray_mse = float(F.mse_loss(pred_ray.float(), target_ray.float()).detach().cpu())
        copy_ray_mse = float(F.mse_loss(copy_ray.float(), target_ray.float()).detach().cpu())

        rel = 1.0 - feature_mse / max(copy_feature_mse, 1e-12)
        row = {
            "checkpoint_step": ckpt_step,
            "dataset_index": sample_idx,
            "camera": batch["camera"][0],
            "prev_path": batch["prev_path"][0],
            "curr_path": batch["curr_path"][0],
            "feature_mse": feature_mse,
            "copy_feature_mse": copy_feature_mse,
            "relative_improvement": rel,
            "level1_mse": level_mse[0],
            "level2_mse": level_mse[1],
            "level3_mse": level_mse[2],
            "level4_mse": level_mse[3],
            "depth_mse": depth_mse,
            "copy_depth_mse": copy_depth_mse,
            "ray_mse": ray_mse,
            "copy_ray_mse": copy_ray_mse,
            "delta_level1_token_norm": float(delta_tokens[0].float().norm(dim=-1).mean().detach().cpu()),
            "delta_level2_token_norm": float(delta_tokens[1].float().norm(dim=-1).mean().detach().cpu()),
            "delta_level3_token_norm": float(delta_tokens[2].float().norm(dim=-1).mean().detach().cpu()),
            "delta_level4_token_norm": float(delta_tokens[3].float().norm(dim=-1).mean().detach().cpu()),
        }
        rows.append(row)

        pred_ray_norm = torch.linalg.vector_norm(pred_ray.float(), dim=-1)
        target_ray_norm = torch.linalg.vector_norm(target_ray.float(), dim=-1)
        copy_ray_norm = torch.linalg.vector_norm(copy_ray.float(), dim=-1)
        title = (
            f"step {ckpt_step} idx {sample_idx} {batch['camera'][0]} "
            f"rel {rel:.4f} feature {feature_mse:.5g}/{copy_feature_mse:.5g}"
        )
        stem = f"step_{ckpt_step:07d}_idx_{sample_idx:06d}_{batch['camera'][0]}"
        save_visualization(
            output_dir / f"{stem}.png",
            image_to_numpy(prev[0]),
            image_to_numpy(curr[0]),
            tensor_to_numpy(copy_depth[0]),
            tensor_to_numpy(pred_depth[0]),
            tensor_to_numpy(target_depth[0]),
            tensor_to_numpy(copy_ray_norm[0]),
            tensor_to_numpy(pred_ray_norm[0]),
            tensor_to_numpy(target_ray_norm[0]),
            title,
        )
        save_feature_pca_visualization(
            output_dir / f"{stem}_feature_pca.png",
            prev_feats,
            pred_feats,
            curr_feats,
            patch_grid,
            title,
        )

    summary_path = output_dir / f"summary_step_{ckpt_step:07d}.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"saved {len(rows)} visualizations to {output_dir}")
    print(f"summary {summary_path}")


if __name__ == "__main__":
    main()
