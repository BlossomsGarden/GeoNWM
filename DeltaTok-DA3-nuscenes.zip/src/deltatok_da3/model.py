from __future__ import annotations

import math
from typing import Literal, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


LossName = Literal["mse", "log_cosh"]


def _rotate_every_two(x: torch.Tensor) -> torch.Tensor:
    even = x[..., 0::2]
    odd = x[..., 1::2]
    return torch.stack((-odd, even), dim=-1).flatten(-2)


def _axis_rope(position: torch.Tensor, dim: int) -> tuple[torch.Tensor, torch.Tensor]:
    if dim <= 0 or dim % 2 != 0:
        raise ValueError(f"RoPE axis dim must be a positive even number, got {dim}")
    inv_freq = 1.0 / (10000.0 ** (torch.arange(0, dim, 2, device=position.device, dtype=torch.float32) / dim))
    angles = position.float().unsqueeze(-1) * inv_freq.unsqueeze(0)
    return angles.cos().repeat_interleave(2, dim=-1), angles.sin().repeat_interleave(2, dim=-1)


def build_2d_rope(
    grid_h: int,
    grid_w: int,
    head_dim: int,
    *,
    num_prefix_tokens: int,
    duplicate_spatial: int,
    device: torch.device,
    dtype: torch.dtype,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Build DINO/DeltaTok-style 2D RoPE, leaving prefix delta tokens unrotated."""
    if grid_h <= 0 or grid_w <= 0:
        raise ValueError(f"Invalid RoPE grid {(grid_h, grid_w)}")
    if head_dim < 8:
        raise ValueError(f"head_dim={head_dim} is too small for 2D RoPE")
    unrotated = 4 if (head_dim - 4) % 4 == 0 else head_dim % 4
    rotary_dim = head_dim - unrotated
    if rotary_dim <= 0 or rotary_dim % 4 != 0:
        raise ValueError(f"Cannot split head_dim={head_dim} into 2D RoPE axes")
    axis_dim = rotary_dim // 2

    y = torch.arange(grid_h, device=device).repeat_interleave(grid_w)
    x = torch.arange(grid_w, device=device).repeat(grid_h)
    cos_y, sin_y = _axis_rope(y, axis_dim)
    cos_x, sin_x = _axis_rope(x, axis_dim)
    spatial_cos = torch.cat(
        [
            cos_y,
            cos_x,
            torch.ones(grid_h * grid_w, unrotated, device=device, dtype=torch.float32),
        ],
        dim=-1,
    )
    spatial_sin = torch.cat(
        [
            sin_y,
            sin_x,
            torch.zeros(grid_h * grid_w, unrotated, device=device, dtype=torch.float32),
        ],
        dim=-1,
    )
    if duplicate_spatial != 1:
        spatial_cos = spatial_cos.repeat(duplicate_spatial, 1)
        spatial_sin = spatial_sin.repeat(duplicate_spatial, 1)
    prefix_cos = torch.ones(num_prefix_tokens, head_dim, device=device, dtype=torch.float32)
    prefix_sin = torch.zeros(num_prefix_tokens, head_dim, device=device, dtype=torch.float32)
    cos = torch.cat([prefix_cos, spatial_cos], dim=0).to(dtype=dtype)
    sin = torch.cat([prefix_sin, spatial_sin], dim=0).to(dtype=dtype)
    return cos.view(1, 1, -1, head_dim), sin.view(1, 1, -1, head_dim)


class LayerScale(nn.Module):
    """DINOv3-style LayerScale used by the released DeltaTok blocks."""

    def __init__(self, dim: int, init_value: float) -> None:
        super().__init__()
        self.gamma = nn.Parameter(torch.full((int(dim),), float(init_value)))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.gamma.to(dtype=x.dtype)


class SwiGLUFFN(nn.Module):
    def __init__(self, dim: int, mlp_ratio: float, dropout: float) -> None:
        super().__init__()
        # HF DINOv3 sets gated intermediate_size to 2/3 of the standard MLP size.
        hidden = max(1, int((2.0 * float(mlp_ratio) * int(dim)) / 3.0))
        self.fc_in = nn.Linear(dim, hidden * 2)
        self.fc_out = nn.Linear(hidden, dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        gate, value = self.fc_in(x).chunk(2, dim=-1)
        x = F.silu(gate) * value
        x = self.dropout(x)
        x = self.fc_out(x)
        return self.dropout(x)


class MLP(nn.Module):
    def __init__(self, dim: int, mlp_ratio: float, dropout: float) -> None:
        super().__init__()
        hidden = int(float(mlp_ratio) * int(dim))
        self.net = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class GatedSelfAttention(nn.Module):
    """Self-attention with optional QK-Norm and per-head sigmoid attention gates."""

    def __init__(
        self,
        dim: int,
        num_heads: int,
        dropout: float,
        *,
        use_qk_norm: bool,
        use_gated_attn: bool,
    ) -> None:
        super().__init__()
        self.dim = int(dim)
        self.num_heads = int(num_heads)
        if self.dim % self.num_heads != 0:
            raise ValueError(f"dim={self.dim} must be divisible by num_heads={self.num_heads}")
        self.head_dim = self.dim // self.num_heads
        self.scale = self.head_dim**-0.5
        self.dropout = float(dropout)
        self.q_proj = nn.Linear(self.dim, self.dim)
        self.k_proj = nn.Linear(self.dim, self.dim)
        self.v_proj = nn.Linear(self.dim, self.dim)
        self.o_proj = nn.Linear(self.dim, self.dim)
        self.q_norm = nn.LayerNorm(self.head_dim, elementwise_affine=True, bias=False) if use_qk_norm else None
        self.k_norm = nn.LayerNorm(self.head_dim, elementwise_affine=True, bias=False) if use_qk_norm else None
        self.attn_gate = nn.Linear(self.dim, self.num_heads, bias=True) if use_gated_attn else None

    def _project(self, proj: nn.Linear, x: torch.Tensor) -> torch.Tensor:
        b, n, _ = x.shape
        return proj(x).view(b, n, self.num_heads, self.head_dim).transpose(1, 2)

    def forward(
        self,
        x: torch.Tensor,
        rope: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> torch.Tensor:
        q = self._project(self.q_proj, x)
        k = self._project(self.k_proj, x)
        v = self._project(self.v_proj, x)
        if rope is not None:
            cos, sin = rope
            q = (q * cos) + (_rotate_every_two(q) * sin)
            k = (k * cos) + (_rotate_every_two(k) * sin)
        if self.q_norm is not None and self.k_norm is not None:
            q = self.q_norm(q)
            k = self.k_norm(k)
        attn = F.scaled_dot_product_attention(
            q,
            k,
            v,
            dropout_p=self.dropout if self.training else 0.0,
            scale=self.scale,
        )
        if self.attn_gate is not None:
            gate = self.attn_gate(x).transpose(1, 2).unsqueeze(-1).sigmoid()
            attn = attn * gate
        attn = attn.transpose(1, 2).reshape(x.shape[0], x.shape[1], self.dim)
        return self.o_proj(attn)


class DeltaTokBlock(nn.Module):
    """ViT-style pre-norm block matching the released DeltaTok block mechanics."""

    def __init__(
        self,
        dim: int,
        num_heads: int,
        mlp_ratio: float,
        dropout: float,
        *,
        layer_scale_init: float,
        use_qk_norm: bool,
        use_gated_attn: bool,
        use_swiglu: bool,
    ) -> None:
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = GatedSelfAttention(
            dim,
            num_heads,
            dropout,
            use_qk_norm=use_qk_norm,
            use_gated_attn=use_gated_attn,
        )
        self.layer_scale1 = LayerScale(dim, layer_scale_init)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = SwiGLUFFN(dim, mlp_ratio, dropout) if use_swiglu else MLP(dim, mlp_ratio, dropout)
        self.layer_scale2 = LayerScale(dim, layer_scale_init)

    def forward(
        self,
        x: torch.Tensor,
        rope: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> torch.Tensor:
        x = x + self.layer_scale1(self.attn(self.norm1(x), rope))
        x = x + self.layer_scale2(self.mlp(self.norm2(x)))
        return x


class LevelDeltaTok(nn.Module):
    def __init__(
        self,
        dim: int,
        num_delta_tokens: int,
        encoder_depth: int,
        decoder_depth: int,
        num_heads: int,
        mlp_ratio: float,
        dropout: float,
        max_patches: int,
        patch_grid: tuple[int, int] | None,
        use_checkpointing: bool,
        *,
        layer_scale_init: float = 1e-5,
        use_qk_norm: bool = True,
        use_gated_attn: bool = True,
        use_swiglu: bool = True,
    ) -> None:
        super().__init__()
        self.dim = int(dim)
        self.num_delta_tokens = int(num_delta_tokens)
        self.use_checkpointing = bool(use_checkpointing)
        if patch_grid is None:
            side = int(math.isqrt(int(max_patches)))
            if side * side != int(max_patches):
                raise ValueError("patch_grid is required when max_patches is not a square")
            patch_grid = (side, side)
        self.patch_grid = (int(patch_grid[0]), int(patch_grid[1]))
        if self.patch_grid[0] * self.patch_grid[1] != int(max_patches):
            raise ValueError(f"patch_grid={self.patch_grid} does not match max_patches={max_patches}")
        self.delta_queries = nn.Parameter(torch.empty(1, self.num_delta_tokens, self.dim))
        self.time_embed = nn.Parameter(torch.empty(2, self.dim))
        block_kwargs = dict(
            dim=self.dim,
            num_heads=int(num_heads),
            mlp_ratio=float(mlp_ratio),
            dropout=float(dropout),
            layer_scale_init=float(layer_scale_init),
            use_qk_norm=bool(use_qk_norm),
            use_gated_attn=bool(use_gated_attn),
            use_swiglu=bool(use_swiglu),
        )
        self.encoder_blocks = nn.ModuleList([DeltaTokBlock(**block_kwargs) for _ in range(encoder_depth)])
        self.decoder_blocks = nn.ModuleList([DeltaTokBlock(**block_kwargs) for _ in range(decoder_depth)])
        self.z_norm = nn.LayerNorm(self.dim)
        self._init_weights()

    def _init_weights(self) -> None:
        nn.init.trunc_normal_(self.delta_queries, std=0.02)
        nn.init.trunc_normal_(self.time_embed, std=0.02)
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.trunc_normal_(module.weight, std=0.02)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def _rope(
        self,
        n: int,
        dtype: torch.dtype,
        device: torch.device,
        *,
        duplicate_spatial: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        grid_h, grid_w = self.patch_grid
        if n != grid_h * grid_w:
            raise ValueError(f"Feature has {n} patches but patch_grid={self.patch_grid}")
        return build_2d_rope(
            grid_h,
            grid_w,
            self.dim // self.level_num_heads,
            num_prefix_tokens=self.num_delta_tokens,
            duplicate_spatial=duplicate_spatial,
            device=device,
            dtype=dtype,
        )

    @property
    def level_num_heads(self) -> int:
        return self.encoder_blocks[0].attn.num_heads

    def _run_block(
        self,
        block: DeltaTokBlock,
        x: torch.Tensor,
        rope: tuple[torch.Tensor, torch.Tensor],
    ) -> torch.Tensor:
        if self.use_checkpointing and self.training:
            return checkpoint(lambda hidden: block(hidden, rope), x, use_reentrant=False)
        return block(x, rope)

    def encode(self, prev_feat: torch.Tensor, curr_feat: torch.Tensor) -> torch.Tensor:
        if prev_feat.shape != curr_feat.shape:
            raise ValueError(f"Feature shapes differ: {tuple(prev_feat.shape)} vs {tuple(curr_feat.shape)}")
        b, n, c = prev_feat.shape
        if c != self.dim:
            raise ValueError(f"Expected dim={self.dim}, got {c}")
        rope = self._rope(n, prev_feat.dtype, prev_feat.device, duplicate_spatial=2)
        prev = prev_feat + self.time_embed[0].to(prev_feat.dtype).view(1, 1, c)
        curr = curr_feat + self.time_embed[1].to(prev_feat.dtype).view(1, 1, c)
        z = self.delta_queries.to(dtype=prev_feat.dtype, device=prev_feat.device).expand(b, -1, -1)
        hidden = torch.cat([z, prev, curr], dim=1)
        for block in self.encoder_blocks:
            hidden = self._run_block(block, hidden, rope)
        return self.z_norm(hidden[:, : self.num_delta_tokens])

    def decode(self, prev_feat: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        b, n, c = prev_feat.shape
        if c != self.dim:
            raise ValueError(f"Expected dim={self.dim}, got {c}")
        if z.shape != (b, self.num_delta_tokens, c):
            raise ValueError(f"Expected z {(b, self.num_delta_tokens, c)}, got {tuple(z.shape)}")
        rope = self._rope(n, prev_feat.dtype, prev_feat.device, duplicate_spatial=1)
        hidden = torch.cat([z, prev_feat], dim=1)
        for block in self.decoder_blocks:
            hidden = self._run_block(block, hidden, rope)
        # The released DeltaTok omits decoder final LayerNorm. With small LayerScale,
        # the decoder branch is near identity at initialization.
        return hidden[:, self.num_delta_tokens :]

    def forward(self, prev_feat: torch.Tensor, curr_feat: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        z = self.encode(prev_feat, curr_feat)
        return self.decode(prev_feat, z), z


class MultiLevelDeltaTok(nn.Module):
    def __init__(
        self,
        feature_channels: Sequence[int],
        num_delta_tokens: int,
        encoder_depth: int,
        decoder_depth: int,
        num_heads: Sequence[int],
        mlp_ratio: float,
        dropout: float,
        max_patches: int,
        use_checkpointing: bool,
        patch_grid: tuple[int, int] | None = None,
        *,
        layer_scale_init: float = 1e-5,
        use_qk_norm: bool = True,
        use_gated_attn: bool = True,
        use_swiglu: bool = True,
    ) -> None:
        super().__init__()
        self.feature_channels = tuple(int(x) for x in feature_channels)
        self.num_delta_tokens = int(num_delta_tokens)
        if len(self.feature_channels) != 4:
            raise ValueError("DeltaTok-DA3 expects exactly four DA3 feature levels")
        if len(num_heads) != 4:
            raise ValueError("num_heads must contain one entry per feature level")
        self.levels = nn.ModuleList(
            [
                LevelDeltaTok(
                    dim=dim,
                    num_delta_tokens=self.num_delta_tokens,
                    encoder_depth=encoder_depth,
                    decoder_depth=decoder_depth,
                    num_heads=int(heads),
                    mlp_ratio=mlp_ratio,
                    dropout=dropout,
                    max_patches=max_patches,
                    patch_grid=patch_grid,
                    use_checkpointing=use_checkpointing,
                    layer_scale_init=layer_scale_init,
                    use_qk_norm=use_qk_norm,
                    use_gated_attn=use_gated_attn,
                    use_swiglu=use_swiglu,
                )
                for dim, heads in zip(self.feature_channels, num_heads)
            ]
        )

    def encode(
        self,
        prev_feats: Sequence[torch.Tensor],
        curr_feats: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        self._check_features(prev_feats)
        self._check_features(curr_feats)
        return [level.encode(prev, curr) for level, prev, curr in zip(self.levels, prev_feats, curr_feats)]

    def decode(
        self,
        prev_feats: Sequence[torch.Tensor],
        delta_tokens: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        self._check_features(prev_feats)
        if len(delta_tokens) != 4:
            raise ValueError(f"Expected four delta token groups, got {len(delta_tokens)}")
        return [level.decode(prev, z) for level, prev, z in zip(self.levels, prev_feats, delta_tokens)]

    def forward(
        self,
        prev_feats: Sequence[torch.Tensor],
        curr_feats: Sequence[torch.Tensor],
    ) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
        delta_tokens = self.encode(prev_feats, curr_feats)
        recon = self.decode(prev_feats, delta_tokens)
        return recon, delta_tokens

    def _check_features(self, features: Sequence[torch.Tensor]) -> None:
        if len(features) != 4:
            raise ValueError(f"Expected four feature levels, got {len(features)}")
        for idx, (feat, dim) in enumerate(zip(features, self.feature_channels)):
            if feat.ndim != 3:
                raise ValueError(f"Level {idx} must be [B,N,C], got {tuple(feat.shape)}")
            if feat.shape[-1] != dim:
                raise ValueError(f"Level {idx} has dim {feat.shape[-1]}, expected {dim}")


def log_cosh_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    diff = (pred.float() - target.detach().float()).abs()
    return (diff + F.softplus(-2.0 * diff) - math.log(2.0)).mean()


def multilevel_loss(
    pred: Sequence[torch.Tensor],
    target: Sequence[torch.Tensor],
    loss_fn: LossName = "mse",
) -> tuple[torch.Tensor, list[torch.Tensor]]:
    if loss_fn == "mse":
        losses = [F.mse_loss(p.float(), t.detach().float()) for p, t in zip(pred, target)]
    elif loss_fn == "log_cosh":
        losses = [log_cosh_loss(p, t) for p, t in zip(pred, target)]
    else:
        raise ValueError(f"Unsupported loss_fn={loss_fn!r}; expected 'mse' or 'log_cosh'")
    return sum(losses) / len(losses), losses


def multilevel_mse(
    pred: Sequence[torch.Tensor],
    target: Sequence[torch.Tensor],
) -> tuple[torch.Tensor, list[torch.Tensor]]:
    return multilevel_loss(pred, target, "mse")


def copy_last_mse(
    prev_feats: Sequence[torch.Tensor],
    curr_feats: Sequence[torch.Tensor],
) -> tuple[torch.Tensor, list[torch.Tensor]]:
    losses = [F.mse_loss(p.float(), c.detach().float()) for p, c in zip(prev_feats, curr_feats)]
    return sum(losses) / len(losses), losses
