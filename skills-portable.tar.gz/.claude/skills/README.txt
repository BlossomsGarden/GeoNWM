============================================
  Claude Code Skills - 便携式技能包
============================================

包含 5 个 skills：

  • academic-paper        - 12-agent 学术论文写作流水线
  • deep-research         - 13-agent 深度研究团队
  • research-lookup       - 学术信息检索
  • scientific-brainstorming - 科研头脑风暴
  • using-superpowers     - 技能发现与使用指南

--------------------------------------------

在另一台电脑上的使用方法：

  1. 将 skills-portable.tar.gz 拷贝到目标电脑
  2. 进入目标项目的根目录（即你想安装 skills 的目录）
  3. 执行解压命令：

     tar -xzf skills-portable.tar.gz

  4. 解压后会自动创建 .claude/skills/ 目录
  5. 重启 Claude Code 即可自动加载

  验证安装：

     ls .claude/skills/
