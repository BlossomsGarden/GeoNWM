# Copyright (c) 2025 ByteDance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from depth_anything_3.specs import Prediction


def export_to_gs_ply(
    prediction: Prediction,
    export_dir: str,
    gs_views_interval: Optional[int] = 1,
) -> None:
    raise RuntimeError("3DGS PLY downstream export is disabled in this feature-only build.")


def export_to_gs_video(
    prediction: Prediction,
    export_dir: str,
    **kwargs,
) -> None:
    raise RuntimeError("3DGS video downstream export is disabled in this feature-only build.")
