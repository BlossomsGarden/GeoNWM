# 此文档用于 —— 基于 Difix-RGBD 模型生成的偏置后的锚点帧多模态信息，生成完整的仿真视频，并支持自回归式生成

## 验收功能

首先，训练数据构造脚本验证。分别构造如下两类offset形成的训练数据的chunk：1、相对于自车当前位姿逐帧向左渐进式地施加偏移量2~4米；2、相对于自车当前位姿逐帧向左施加固定偏移量4米。最终形成的监督数据拼成一个大chunk长度的4x6视频，让我看看是否达到训练数据的标准：包括 “上方2行包括 target RGB 2x3全视角chunk视频和 target Depth 2x3 全视角chunk视频形成2x6、下方是predict RGB + Depth 形成的2x6” 的拼接结果。
其次，按照预生成好的RGBD anchor将目标要输出的视频切分成chunk，第一个chunk的anchor即为起点帧。
在每个chunk内，输入 warpped RGB和Depth 序列，以anchor为提示生成该chunk的修复后的 RGB和Depth 序列
训练时只关注单一chunk，推理时才使用多chunk


## 环境

DiST-4D-main 文件夹下的 REMOTE_SERVER.md 所述远程linux服务器，使用 dists 环境训练



## 在线训练数据构造

需要重新构建 dataset_nuscenes.py 数据集采样相关脚本。

### base 数据集与关键anchor帧机制

nuscenes (/data2/DATA/AutoDrive/nuscenes/v1.0-trainval) + lidar 标定深度 (/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_256x704_fp16/align_depth)。具体采样逻辑为训练数据采样以预处理好的 anchor keyframe 表（远程服务器/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv + nuscenes_val_samples.csv）为基本采样单元，local indices: 0, 6, 12, 18, 24, 30, ..., 这些设置为“关键anchor”帧，每个 anchor 对应一个 scene 内长度为 7 的 chunk 起点，如果最后一个chunk不满7帧则直接丢弃。


### 阶段一

不全量提前存 14 种 offset，而采用offset在线生成的方案，DataLoader 开 num_workers，让 CPU 几何和 GPU 训练重叠。
训练数据一次只喂单camera，仿照Dataset-scripts/train_stage_1_offset_preview.py文件里的Difix-RGBD的在线训练数据构造的逻辑，只改变帧数、offset类型和补充anchor。具体如下：预设某个摄像头的某帧，后面5帧，后面第6帧这一共连续7帧为一个chunk，并对去头去尾的中间5帧执行预设视角偏移的 offset = [逐帧向左/右渐进式地施加偏移量0~2米,2~4米,4~6米；逐帧向左/右施加固定偏移量1米,2米,4米,6米]。然后手动取首帧、尾帧的GT RGBD作为anchor。
其他的逻辑几乎可以原样保留，将rgb帧与深度分辨率对齐，再根据Rgb帧的分辨率修正相机内参，然后将摄像头进行对应逐帧的offset，获得虚拟新视角下的rgb帧以及可见区域的逐像素深度值（需要在 shifted view 里做近邻深度反穿透过滤）。然后根据这个RGB-D结果逐帧又反投影为点云再用原数据集的相机投影获得原相机视角下的存在不可见区域的Rgb、depth、不可见区域mask。于是联合最初的完整RGB、depth形成监督数据。mask可视化时白色标识不可见区域和失真区域。

具体采样逻辑为训练数据采样GT anchor keyframe 表为基本采样单元，每个 anchor 对应一个 scene 内长度为 7 的 chunk 起点，__getitem__ 的 idx 不直接表示原始 frame_id，而被拆分为 anchor_id 与 offset_type：offset_type 按当前阶段的 offset pool 做 round-robin，anchor_id 通过每个 epoch 重新打乱的 anchor permutation 轮转采样，保证在一个 virtual epoch 内每个 anchor 与每种 offset 尽量等概率配对。前50%steps只用 progressive 0-2/2-4 + fixed 1/2/4，先让模型学会稳定补洞和时序一致;后50% steps全 14 offset。具体offset类型按均等概率进行 round-robin。

前 50% training steps 只使用 progressive left/right 0->2m、2->4m 以及 fixed left/right 1m、2m、4m，共 10 类 offset，让模型先学习稳定补洞、anchor 条件使用和 chunk 内时序一致性；后 50% training steps 切换到全 14 类 offset，即 progressive left/right 0->2m、2->4m、4->6m 与 fixed left/right 1m、2m、4m、6m。每个样本的 anchor RGB-D 使用该 offset schedule 第一帧对应的GT anchor，后续 6 帧 warped RGB-D / mask 按对应逐帧 offset 构造。

Depth 表示沿用 DiST-S 完成 offset 阶段后再将 target depth 与 warped depth condition 分别 clip 到 [0.5, 100]，除以 100 归一化，并 repeat 成 3 通道作为网络输入表示。


### 阶段二（仿照DiST-4D的SCC，待完成）

不全量提前存 14 种 offset，而采用 "offset在线生成 + 关键anchor帧进行Difix-MM缓存" 的方案，DataLoader 开 num_workers，让 CPU 几何和 GPU 训练重叠。



## 训练代码与框架

基于同目录下的 DiST-4D-main 里的 ./examples/scripts/mm_train_nus_768.sh 所指向的脚本做修改，加载 stabilityai/stable-video-diffusion-img2vid-xt 模型做训练。具体模型我已经下载到 /data4/DATA/wlh/Difix3D+/model 路径下。RGB target 和 depth target 可以 concat 后一次 VAE encode，减少 kernel launch 和框架开销。


## depth/mask/anchor 联合生成方案

原 SVD：8 个输入通道 4ch noisy RGB video latent + 4ch image condition latent，其中后者为image->VAE encoder，再复制frames份形成伪video latent, 4 个输出通道。
原 DiST-S：内部训练 span 是 6 帧，16个输入通道 4ch noisy target RGB latent + 4ch noisy target depth latent + 4ch warpped RGB condition latent + 4ch warpped depth condition latent，其中后两个是RGB-D条件直接通过 ConvNeXt supertiny 风格的 LayoutCondEncoder 编码得到，8个输出通道。训练不是直接拿 model_pred 和 noise 做 loss，而是 EDM/SVD 风格的 preconditioning。

本方案：加载原 SVD 的权重启动训练。总体来说使用双锚点 chunk 内插补全，内部训练 span 应该是 7 帧（与DiST-S不同），首尾为anchor直接copy过来，中间帧为warpped 结果，需要模型补全中间5帧。RGB和Depth公用同一个 mask 作为需要修复区域的提示。Depth 的两条路径均沿用 DiST-S 的 depth image 表示，Depth-Prior Async 只改变 target RGB/depth latent 的加噪 sigma 与 timestep 条件，不改变 warped RGB-D condition 的编码方式。对现在 DiST 代码只有 16ch的输入多扩展一个通道放 max-pool downsample后的mask（一个 latent cell 覆盖的 8x8 图像 patch 里只要有无效/待修复区域，就把该 latent mask 标成 1。这样它不是精细边界 mask，而是“这个 latent token 是否涉及洞区”的提示，仍然有效），即17个通道，其他处理不变，输出也仍为8个通道。训练loss在原 DiST-S 的基础上再增加一项专注于RGB与Depth结果在 mask 区域的损失，因为需要重点训练Depth的估计能力所以mask区域的损失内部设置lambda_mask_rgb = 2.0，而lambda_mask_depth = 3.0。不在pixel-space施加loss。anchor帧不参与loss计算。

消融方案A（用于与“本方案”对比说明双锚点的有效性）: 加载原 SVD 的权重启动训练，针对RGB-D-Mask 通道的设计与loss设计相同，只是anchor有所改变。总体来说使用单锚点 chunk ，内部训练span依然但 7 帧，仅首帧为anchor直接copy过来，后续6帧为warpped 结果，需要模型补全。


## Depth-Prior Async生成方案

前面的“原DiST-S”“本方案”“消融方案A”都是让RGB与Depth联合生成，我希望在这个方案中测试类似于 /paper/Semantics Lead the Way.txt 论文里的连续时间偏移 Δt 进行先低频信息（Depth）后高频信息（RGB）的生成范式。该方案基于“消融方案A”构建，用于与“消融方案A”做一组对比，验证“Depth 先于 RGB/texture 生成”是否有效。除异步噪声调度与双 timestep 条件外，其余设置保持不变：仍加载原 SVD 权重初始化，仍采用单锚点 chunk，训练 span 为 7 帧，首帧为 anchor 直接 copy，后续 6 帧为 warped RGB-D 条件并由模型补全；RGB-D-Mask 输入通道设计、condition encoder、mask loss、训练数据、优化器、学习率、batch size 和训练步数均与消融方案A一致。

修改点主要基于 /paper/Semantics Lead the Way.txt 论文的思想执行，核心修改包括：1、训练时不要再采一个共享 timestep/sigma。采一个全局进度 u ~ Uniform(0, 1 + Δ)，tau_depth = min(u, 1)，tau_rgb   = max(u - Δ, 0)，这里 tau=0 表示最 noisy，tau=1 表示最 clean。然后把 tau 映射到 SVD/EDM 的 sigma schedule 再对两个模态分别加噪（sigma(tau)用 log-normal 的 inverse-CDF，并 clamp tau 到 [eps, 1-eps]，这样 Δ=0 时 sigma 分布严格退化成原同步训练分布）；2、模型输出仍为 8 channels，并按通道拆分为 RGB prediction 和 Depth prediction。训练 loss 沿用原 DiST-S/SVD 的 EDM/v-pred 目标定义，但所有依赖 sigma 的 preconditioning 和 loss weighting 都按模态分别计算：RGB 分支使用 sigma_rgb 的 c_in/c_skip/c_out/c_noise/weight，Depth 分支使用 sigma_depth 的对应项。最终 loss 为：L = λ_rgb L_rgb + λ_depth L_depth + 原有 mask-region loss，其中 λ_rgb、λ_depth 以及 mask loss 权重保持与消融方案A一致，以保证对比公平。3、原来的模型都只有一个time_embedding(t)，现在应该根据模态分为两个，并且初始化时直接从原time_embedding拷贝，fuse 初始化成平均或线性投影，这样最稳；4、采样时 loop 不能再直接用一个 scheduler step 更新所有 8 个 latent channel。要按模态 split 更新，采用Depth-leading schedule，u ∈ [0, Δ)：只更新 Depth，RGB 保持初始高噪声状态；u ∈ [Δ, 1)：Depth 和 RGB 同时更新，但 Depth 的 denoising 进度始终领先 RGB；u ∈ [1, 1+Δ]：Depth 固定在 clean/near-clean 状态，只继续更新 RGB。该方案的推荐默认超参为 Δ=0.3，后续补充 Δ∈{0, 0.1, 0.3, 0.5} 的 ablation。其中 Δ=0 应退化为消融方案A的同步 RGB-D 生成，用于验证实现正确性。5、关于原 single timestep embedder的替换机制，则采用emb_rgb和emb_depth concat 后再 linear，但初始化成平均保证初始时等于原来的single timestep embedder。

消融方案B：即主方案的Δ=0版本，相比于消融方案A的差异在于将模型架构改成了Async-capable，实现更加精准的消融。


## evaluation

在val上随机抽10个样本做所有4个offsets的效果验证，每个offset不要单独保存而是一个样本一个6x6的拼接大视频：包括 “上方2行包括 target RGB 2x3全视角视频和 target Depth 2x3 全视角视频形成2x6、中间是inference input RGB + Depth 形成的2x6、下方是predict RGB + Depth 形成的2x6” 的拼接结果。最后计算predict RGB与target RGB之间的逐帧 SSIM/PSNR 均值和 mask-only的补全区域的 SSIM/PSNR 均值，depth之间就计算逐帧 depth RMSE、depth AbsRel 均值和 mask-only 的补全区域的逐帧 depth RMSE/AbsRel 均值。


## rebuttal

必须承认仅 Depth map（单通道）提供的信息原不足 DINO Layer Info（768通道），但是额外引入 DINO 对整个视频生成的架构贡献不足，就是增加了一个注入条件，还引入了更多的计算量，并不是一个完美的解决方案。况且信息细粒度也有区别，512x512 image, DINO Layer Info 32x32x768, Depth Latent
64x64x4。我其实后面还可以微调Depth Conditioner让这个4通道或许扩张成8通道？或者VAE可以挂个Depth Video LoRA？所以它还是有足够的潜力的


## TBD

1、你要不在samples文件夹下继续设置关键帧？而且针对关键帧才去推理存放2米4米6米？毕竟第二阶段可能还得先Difix然后再Difix呢
2、不违背“offset 在线生成”的前提下，可以缓存每个原始 frame 的 RGB-D point cloud/intrinsics/pose。不同 offset 只做投影和 z-buffer，能省很多重复 CPU。
