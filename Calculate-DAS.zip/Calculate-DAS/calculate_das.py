#!/usr/bin/env python3
"""Reproduce X-Drive's Depth Alignment Score (DAS).

DAS in the paper:
1. Estimate image disparity with Depth Anything V2 ViT-B.
2. Project the generated point cloud to the camera image as sparse disparity.
3. Normalize projected sparse disparity to the same scale as estimated disparity.
4. Report mean absolute error on valid projected pixels.

This implementation follows the paper path: convert the 32 x 1024 LiDAR range
map into 3D LiDAR points, project them into each camera with lidar2image and
img_aug_matrix from an X-Drive/MagicDrive demo .pth, and compare the resulting
sparse disparity with Depth Anything V2 disparity.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from tqdm import tqdm
from transformers import AutoImageProcessor, AutoModelForDepthEstimation


DEFAULT_MODEL_DIR = "../model/depth-anything/Depth-Anything-V2-Base-hf"
DEFAULT_MODEL_ID = "depth-anything/Depth-Anything-V2-Base-hf"

XDRIVE_HEIGHT_OFFSETS = np.array(
    [
        -0.00216031, -0.00098729, -0.00020528, 0.00174976,
        0.0044868, -0.00294233, -0.00059629, -0.00020528,
        0.00174976, -0.00294233, -0.0013783, 0.00018573,
        0.00253177, -0.00098729, 0.00018573, 0.00096774,
        -0.00411535, -0.0013783, 0.00018573, 0.00018573,
        -0.00294233, -0.0013783, -0.00098729, -0.00020528,
        0.00018573, 0.00018573, 0.00018573, -0.00020528,
        0.00018573, 0.00018573, 0.00018573, 0.00018573,
    ],
    dtype=np.float32,
)

XDRIVE_ZENITH = np.array(
    [
        1.86705767e-01, 1.63245357e-01, 1.39784946e-01, 1.16324536e-01,
        9.28641251e-02, 7.01857283e-02, 4.67253177e-02, 2.32649071e-02,
        -1.95503421e-04, -2.28739003e-02, -4.63343109e-02, -6.97947214e-02,
        -9.32551320e-02, -1.15933529e-01, -1.39393939e-01, -1.62854350e-01,
        -1.85532747e-01, -2.08993157e-01, -2.32453568e-01, -2.55913978e-01,
        -2.78592375e-01, -3.02052786e-01, -3.25513196e-01, -3.48973607e-01,
        -3.72434018e-01, -3.95894428e-01, -4.19354839e-01, -4.42033236e-01,
        -4.65493646e-01, -4.88954057e-01, -5.12414467e-01, -5.35874878e-01,
    ],
    dtype=np.float32,
)
XDRIVE_INCLINATION = -XDRIVE_ZENITH


@dataclass
class DasResult:
    sample_id: str
    das: float
    valid_pixels: int
    valid_ratio: float
    view: str
    pth_path: str
    range_path: str
    visualization_path: str
    rangemap_visualization_path: str
    report_path: str
    method: str
    normalization: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Calculate Depth Alignment Score (DAS).")
    parser.add_argument(
        "--demo-pth",
        required=True,
        help="X-Drive/MagicDrive demo .pth containing img, camera_intrinsics, lidar2camera, and img_aug_matrix.",
    )
    parser.add_argument(
        "--range-bin",
        required=True,
        help="32x1024 float range map .bin. First channel is range in meters unless --range-normalized is set.",
    )
    parser.add_argument("--output-dir", default="outputs")

    parser.add_argument("--model-dir", default=DEFAULT_MODEL_DIR)
    parser.add_argument("--model-id", default=DEFAULT_MODEL_ID)
    parser.add_argument("--local-files-only", action="store_true", help="Do not try network model downloads.")
    parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])

    parser.add_argument("--range-height", type=int, default=32)
    parser.add_argument("--range-width", type=int, default=1024)
    parser.add_argument("--bin-dtype", default="float32", choices=["float32", "float16", "uint16"])
    parser.add_argument("--range-channel", type=int, default=0)
    parser.add_argument("--range-is-disparity", action="store_true")
    parser.add_argument(
        "--range-normalized",
        action="store_true",
        help="Interpret range channel as X-Drive normalized range and de-normalize with range * std + mean.",
    )
    parser.add_argument("--range-mean", type=float, default=50.0)
    parser.add_argument("--range-std", type=float, default=50.0)
    parser.add_argument("--max-range", type=float, default=60.0)
    parser.add_argument("--min-range", type=float, default=0.1)
    parser.add_argument("--view-index", type=int, default=-1, help="-1 evaluates all 6 views; otherwise evaluate one view.")
    parser.add_argument(
        "--depth-to-disparity",
        default="identity",
        choices=["identity", "inverse"],
        help="Depth Anything V2 relative output is treated as disparity by default, matching the X-Drive text.",
    )
    parser.add_argument(
        "--normalization",
        default="robust_minmax",
        choices=["robust_minmax", "affine_lstsq"],
        help="Scale projected sparse disparity to image disparity before MAE.",
    )
    parser.add_argument("--quantile-low", type=float, default=2.0)
    parser.add_argument("--quantile-high", type=float, default=98.0)
    parser.add_argument("--save-arrays", action="store_true")
    parser.add_argument(
        "--save-rangemap",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Save a separate visualization for the raw 32x1024 range map and camera-FOV crop.",
    )
    return parser.parse_args()


def choose_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available.")
    return torch.device(name)


def load_depth_model(args: argparse.Namespace, device: torch.device):
    model_dir = Path(args.model_dir).expanduser().resolve()
    source = str(model_dir) if model_dir.exists() else args.model_id
    processor = AutoImageProcessor.from_pretrained(source, local_files_only=args.local_files_only)
    model = AutoModelForDepthEstimation.from_pretrained(source, local_files_only=args.local_files_only)
    model.to(device)
    model.eval()
    return processor, model


def estimate_image_disparity(
    image: Image.Image,
    processor,
    model,
    device: torch.device,
    depth_to_disparity: str,
) -> np.ndarray:
    inputs = processor(images=image, return_tensors="pt")
    inputs = {name: tensor.to(device) for name, tensor in inputs.items()}
    with torch.no_grad():
        predicted_depth = model(**inputs).predicted_depth
    prediction = F.interpolate(
        predicted_depth.unsqueeze(1),
        size=image.size[::-1],
        mode="bicubic",
        align_corners=False,
    ).squeeze(0).squeeze(0)
    arr = prediction.detach().float().cpu().numpy()
    arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
    if depth_to_disparity == "inverse":
        arr = 1.0 / np.maximum(arr, 1e-6)
    return arr.astype(np.float32)


def load_range_bin(path: Path, height: int, width: int, dtype_name: str, channel: int) -> np.ndarray:
    dtype = np.dtype(dtype_name)
    data = np.fromfile(path, dtype=dtype).astype(np.float32)
    pixels = height * width
    if data.size == pixels:
        return data.reshape(height, width)
    if data.size % pixels != 0:
        raise ValueError(
            f"{path} has {data.size} values, which cannot reshape to {height}x{width} with whole channels."
        )
    channels = data.size // pixels
    if channel < 0 or channel >= channels:
        raise ValueError(f"Requested channel {channel}, but {path} has {channels} channels.")
    return data.reshape(height, width, channels)[..., channel]


def load_demo_pth(path: Path) -> dict:
    try:
        data = torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        data = torch.load(path, map_location="cpu")
    required = ["img", "camera_intrinsics", "lidar2camera", "img_aug_matrix"]
    missing = [key for key in required if key not in data]
    if missing:
        raise ValueError(f"{path} is missing required keys: {missing}")
    if tuple(data["img"].shape[-2:]) != (224, 400):
        raise ValueError(f"Expected demo images with shape (*, 224, 400), got {tuple(data['img'].shape)}")
    return data


def demo_images_to_pil(img_tensor: torch.Tensor) -> list[Image.Image]:
    arr = img_tensor.detach().cpu().float().numpy()
    if arr.ndim != 4 or arr.shape[1] != 3:
        raise ValueError(f"Expected img tensor shape (6,3,224,400), got {arr.shape}")
    arr = np.clip((arr + 1.0) * 127.5, 0, 255).astype(np.uint8)
    return [Image.fromarray(np.transpose(arr[i], (1, 2, 0)), "RGB") for i in range(arr.shape[0])]


def range_map_to_lidar_points(range_map: np.ndarray, args: argparse.Namespace) -> tuple[np.ndarray, np.ndarray]:
    if args.range_normalized:
        range_map = range_map * args.range_std + args.range_mean
    valid = np.isfinite(range_map) & (range_map >= args.min_range) & (range_map <= args.max_range)
    rows, cols = np.nonzero(valid)
    ranges = range_map[rows, cols].astype(np.float32)
    width = range_map.shape[1]
    azimuth = ((width - 0.5 - cols.astype(np.float32)) / width) * (2.0 * np.pi) - np.pi
    inclination = XDRIVE_INCLINATION[rows].astype(np.float32)
    xy = ranges * np.cos(inclination)
    x = xy * np.cos(azimuth)
    y = xy * np.sin(azimuth)
    z = XDRIVE_HEIGHT_OFFSETS[rows] + ranges * np.sin(inclination)
    points = np.stack([x, y, z], axis=1).astype(np.float32)
    return points, ranges


def project_points_to_view(
    points_lidar: np.ndarray,
    ranges: np.ndarray,
    lidar2image: np.ndarray,
    img_aug_matrix: np.ndarray,
    image_hw: tuple[int, int],
    range_is_disparity: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    height, width = image_hw
    points_h = np.concatenate([points_lidar, np.ones((points_lidar.shape[0], 1), dtype=np.float32)], axis=1)
    transform = img_aug_matrix @ lidar2image
    coords = points_h @ transform.T
    z_cam = coords[:, 2]
    in_front = z_cam > 1e-5
    u = coords[:, 0] / np.clip(z_cam, 1e-5, None)
    v = coords[:, 1] / np.clip(z_cam, 1e-5, None)
    inside = in_front & (u >= 0) & (u < width) & (v >= 0) & (v < height)

    sparse = np.zeros((height, width), dtype=np.float32)
    depth = np.full((height, width), np.inf, dtype=np.float32)
    valid = np.zeros((height, width), dtype=bool)
    if not np.any(inside):
        return sparse, valid, depth

    px = np.floor(u[inside]).astype(np.int32)
    py = np.floor(v[inside]).astype(np.int32)
    cam_depth = z_cam[inside].astype(np.float32)
    values = ranges[inside] if range_is_disparity else 1.0 / np.maximum(ranges[inside], 1e-6)
    order = np.argsort(cam_depth)[::-1]
    for idx in order:
        y_i = py[idx]
        x_i = px[idx]
        if cam_depth[idx] < depth[y_i, x_i]:
            depth[y_i, x_i] = cam_depth[idx]
            sparse[y_i, x_i] = values[idx]
            valid[y_i, x_i] = True
    depth[~valid] = 0.0
    return sparse, valid, depth


def robust_minmax(values: np.ndarray, mask: np.ndarray, low: float, high: float) -> np.ndarray:
    out = np.zeros_like(values, dtype=np.float32)
    selected = values[mask]
    if selected.size == 0:
        return out
    lo, hi = np.percentile(selected, [low, high])
    if not np.isfinite(lo) or not np.isfinite(hi) or abs(hi - lo) < 1e-8:
        return out
    out = (values - lo) / (hi - lo)
    return np.clip(out, 0.0, 1.0).astype(np.float32)


def affine_match(source: np.ndarray, target: np.ndarray, mask: np.ndarray) -> np.ndarray:
    x = source[mask].astype(np.float64)
    y = target[mask].astype(np.float64)
    if x.size < 2 or np.std(x) < 1e-8:
        return source.astype(np.float32)
    design = np.stack([x, np.ones_like(x)], axis=1)
    scale, bias = np.linalg.lstsq(design, y, rcond=None)[0]
    return (source * scale + bias).astype(np.float32)


def normalize_for_das(
    image_disp: np.ndarray,
    sensor_disp: np.ndarray,
    valid: np.ndarray,
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray]:
    common = valid & np.isfinite(image_disp) & np.isfinite(sensor_disp)
    if args.normalization == "affine_lstsq":
        image_norm = robust_minmax(image_disp, common, args.quantile_low, args.quantile_high)
        sensor_scaled = affine_match(sensor_disp, image_disp, common)
        sensor_norm = robust_minmax(sensor_scaled, common, args.quantile_low, args.quantile_high)
        return image_norm, sensor_norm
    image_norm = robust_minmax(image_disp, common, args.quantile_low, args.quantile_high)
    sensor_norm = robust_minmax(sensor_disp, common, args.quantile_low, args.quantile_high)
    return image_norm, sensor_norm


def save_visualization(
    image: Image.Image,
    image_disp: np.ndarray,
    sensor_disp: np.ndarray,
    valid: np.ndarray,
    das: float,
    valid_ratio: float,
    output_path: Path,
    title: str,
) -> None:
    masked_sensor = np.ma.masked_where(~valid, sensor_disp)
    err = np.ma.masked_where(~valid, np.abs(image_disp - sensor_disp))
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    axes[0, 0].imshow(image)
    axes[0, 0].set_title("camera image")
    axes[0, 1].imshow(image_disp, cmap="magma")
    axes[0, 1].set_title("Depth Anything V2 disparity")
    axes[1, 0].imshow(masked_sensor, cmap="viridis")
    axes[1, 0].set_title("projected/range disparity")
    axes[1, 1].imshow(err, cmap="inferno")
    axes[1, 1].set_title("absolute error")
    for ax in axes.ravel():
        ax.axis("off")
    fig.suptitle(f"{title} | DAS={das:.6f} | valid={valid_ratio:.3%}", fontsize=14)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_rangemap_visualization(
    debug: dict[str, np.ndarray],
    output_path: Path,
    title: str,
) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(14, 7), constrained_layout=True)
    axes[0].imshow(debug["raw_range_map"], cmap="viridis", aspect="auto")
    axes[0].set_title("raw range map (.bin, 32 x 1024)")
    axes[1].imshow(debug["projected_sparse_disparity"], cmap="viridis")
    axes[1].set_title("sparse projected disparity in camera view")
    axes[2].imshow(debug["projected_valid_mask"], cmap="gray", vmin=0, vmax=1)
    axes[2].set_title("valid projected pixels")
    for ax in np.ravel(axes):
        ax.axis("off")
    fig.suptitle(f"{title} | X-Drive LiDAR-to-camera projection", fontsize=14)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def calculate_one_view(
    pth_path: Path,
    range_path: Path,
    image: Image.Image,
    view_index: int,
    lidar2image: np.ndarray,
    img_aug_matrix: np.ndarray,
    range_map: np.ndarray,
    points_lidar: np.ndarray,
    ranges: np.ndarray,
    processor,
    model,
    device: torch.device,
    args: argparse.Namespace,
) -> DasResult:
    image_disp_raw = estimate_image_disparity(image, processor, model, device, args.depth_to_disparity)
    sensor_disp_raw, valid, projected_depth = project_points_to_view(
        points_lidar=points_lidar,
        ranges=ranges,
        lidar2image=lidar2image,
        img_aug_matrix=img_aug_matrix,
        image_hw=image_disp_raw.shape,
        range_is_disparity=args.range_is_disparity,
    )
    common = valid & np.isfinite(image_disp_raw) & np.isfinite(sensor_disp_raw)
    if int(common.sum()) == 0:
        raise ValueError(f"No valid projected LiDAR pixels for view {view_index} in {pth_path}.")

    image_disp, sensor_disp = normalize_for_das(image_disp_raw, sensor_disp_raw, common, args)
    common = common & np.isfinite(image_disp) & np.isfinite(sensor_disp)
    das = float(np.mean(np.abs(image_disp[common] - sensor_disp[common])))
    valid_ratio = float(common.mean())

    sample_id = f"{pth_path.stem}_view{view_index}"
    output_dir = Path(args.output_dir)
    visualization_path = output_dir / f"{sample_id}_das.png"
    rangemap_visualization_path = output_dir / f"{sample_id}_rangemap.png"
    report_path = output_dir / f"{sample_id}_das.json"
    save_visualization(
        image=image,
        image_disp=image_disp,
        sensor_disp=sensor_disp,
        valid=common,
        das=das,
        valid_ratio=valid_ratio,
        output_path=visualization_path,
        title=sample_id,
    )
    if args.save_rangemap:
        save_rangemap_visualization(
            debug={
                "raw_range_map": range_map,
                "projected_sparse_disparity": sensor_disp_raw,
                "projected_valid_mask": common.astype(np.float32),
                "projected_depth": projected_depth,
            },
            output_path=rangemap_visualization_path,
            title=sample_id,
        )
    if args.save_arrays:
        np.save(output_dir / f"{sample_id}_image_disparity.npy", image_disp)
        np.save(output_dir / f"{sample_id}_sensor_disparity.npy", sensor_disp)
        np.save(output_dir / f"{sample_id}_valid_mask.npy", common.astype(np.uint8))

    result = DasResult(
        sample_id=sample_id,
        das=das,
        valid_pixels=int(common.sum()),
        valid_ratio=valid_ratio,
        view=str(view_index),
        pth_path=str(pth_path),
        range_path=str(range_path),
        visualization_path=str(visualization_path),
        rangemap_visualization_path=str(rangemap_visualization_path) if args.save_rangemap else "",
        report_path=str(report_path),
        method="xdrive_lidar2image_projection",
        normalization=args.normalization,
    )
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(asdict(result), indent=2), encoding="utf-8")
    return result


def write_summary(results: Iterable[DasResult], output_dir: Path) -> None:
    results = list(results)
    if not results:
        return
    summary_json = output_dir / "summary.json"
    summary_csv = output_dir / "summary.csv"
    mean_das = float(np.mean([item.das for item in results]))
    summary_json.write_text(
        json.dumps(
            {
                "mean_das": mean_das,
                "num_samples": len(results),
                "samples": [asdict(item) for item in results],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    with summary_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(results[0]).keys()))
        writer.writeheader()
        for result in results:
            writer.writerow(asdict(result))
    print(f"mean_DAS={mean_das:.6f} over {len(results)} sample(s)")
    print(f"summary: {summary_json}")


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
    device = choose_device(args.device)
    processor, model = load_depth_model(args, device)
    pth_path = Path(args.demo_pth)
    range_path = Path(args.range_bin)
    demo = load_demo_pth(pth_path)
    images = demo_images_to_pil(demo["img"])
    range_map = load_range_bin(
        path=range_path,
        height=args.range_height,
        width=args.range_width,
        dtype_name=args.bin_dtype,
        channel=args.range_channel,
    )
    points_lidar, ranges = range_map_to_lidar_points(range_map, args)
    lidar2image = torch.bmm(demo["camera_intrinsics"], demo["lidar2camera"]).cpu().numpy()
    img_aug_matrix = demo["img_aug_matrix"].cpu().numpy()
    if args.view_index >= 0:
        view_indices = [args.view_index]
    else:
        view_indices = list(range(len(images)))

    results = []
    for view_index in tqdm(view_indices, desc="DAS"):
        results.append(
            calculate_one_view(
                pth_path=pth_path,
                range_path=range_path,
                image=images[view_index],
                view_index=view_index,
                lidar2image=lidar2image[view_index],
                img_aug_matrix=img_aug_matrix[view_index],
                range_map=range_map,
                points_lidar=points_lidar,
                ranges=ranges,
                processor=processor,
                model=model,
                device=device,
                args=args,
            )
        )
    write_summary(results, output_dir)


if __name__ == "__main__":
    main()
