# Calculate-DAS

This folder reproduces the DAS idea from **X-Drive: Cross-modality Consistent Multi-Sensor Data Synthesis for Driving Scenarios**.

DAS compares:

- image disparity estimated by **Depth Anything V2 ViT-B**
- sparse disparity obtained by projecting LiDAR/range points into each camera view

The projected sparse disparity is normalized to the same scale as the estimated disparity before MAE is computed.

## Method

The original repository does not release the DAS script. This implementation follows the metric process described in the paper:

1. read an X-Drive/MagicDrive demo `.pth` with six `224 x 400` camera views and calibration matrices
2. read a `32 x 1024` LiDAR range map
3. invert the X-Drive range-map projection to LiDAR points
4. project LiDAR points to each camera with `img_aug_matrix @ camera_intrinsics @ lidar2camera`
5. compare sparse projected disparity against Depth Anything V2 disparity

## Remote Setup

```bash
cd /data/wlh/XDrive/Calculate-DAS
/data/wlh/miniconda3/bin/conda create -y -n das python=3.10
source /data/wlh/miniconda3/bin/activate das
python -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
python download_model.py --output-dir ../model/depth-anything/Depth-Anything-V2-Base-hf
```

The downloader defaults to `https://hf-mirror.com` and stores the model under `project_dir/model/`.

## Smoke Test

This test uses a repository demo `.pth` for images/calibration and a synthetic range map for the LiDAR branch.

```bash
cd /data/wlh/XDrive/Calculate-DAS
source /data/wlh/miniconda3/bin/activate das
python create_synthetic_range.py --output demo_inputs/synthetic_range.bin
python calculate_das.py \
  --demo-pth /data/wlh/XDrive/demo/data/0adef8c999c6418d8c138df6a99b6282.pth \
  --range-bin demo_inputs/synthetic_range.bin \
  --model-dir ../model/depth-anything/Depth-Anything-V2-Base-hf \
  --local-files-only \
  --device cpu \
  --output-dir outputs_demo
```

Expected outputs:

- `outputs_demo/*_das.png`: camera image, Depth Anything V2 disparity, sparse projected LiDAR disparity, and error map
- `outputs_demo/*_rangemap.png`: raw `32 x 1024` rangemap, sparse projected disparity in image coordinates, and projected valid mask
- `outputs_demo/*_das.json`: per-view DAS result
- `outputs_demo/summary.json` and `outputs_demo/summary.csv`: aggregate result

## Real Data Usage

```bash
python calculate_das.py \
  --demo-pth path/to/demo_sample.pth \
  --range-bin path/to/range.bin \
  --model-dir ../model/depth-anything/Depth-Anything-V2-Base-hf \
  --local-files-only \
  --output-dir outputs_real
```

Useful options:

- `--view-index 1`: evaluate a single camera view; default `-1` evaluates all six views
- `--range-normalized`: use this if `.bin` stores X-Drive normalized range; applies `range * 50 + 50`
- `--range-is-disparity`: use this if `.bin` already stores disparity rather than range
- `--normalization robust_minmax`: robust quantile min-max normalization before MAE

Lower DAS means better depth/range alignment.
