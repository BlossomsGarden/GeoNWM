#!/usr/bin/env python3
"""Create a tiny synthetic jpg/bin pair for remote smoke tests.

The generated .bin follows the user's stated range-image shape: 32 x 1024.
It is not intended for paper-level reporting, only to confirm the code path,
environment, visualization, and output files.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create synthetic DAS inputs.")
    parser.add_argument("--output-dir", default="demo_inputs")
    parser.add_argument("--height", type=int, default=32)
    parser.add_argument("--width", type=int, default=1024)
    return parser.parse_args()


def make_demo_image(path: Path) -> None:
    h, w = 224, 400
    y = np.linspace(0, 1, h, dtype=np.float32)[:, None]
    x = np.linspace(0, 1, w, dtype=np.float32)[None, :]
    y_full = np.broadcast_to(y, (h, w))
    x_full = np.broadcast_to(x, (h, w))
    sky = np.stack(
        [
            90 + 80 * (1 - y_full) + 10 * x_full,
            135 + 55 * (1 - y_full),
            175 + 50 * (1 - y_full),
        ],
        axis=-1,
    )
    road = np.stack(
        [
            45 + 45 * y_full,
            45 + 45 * y_full,
            48 + 45 * y_full,
        ],
        axis=-1,
    )
    img = np.where((y_full > 0.48)[..., None], road, sky)
    image = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGB")
    draw = ImageDraw.Draw(image)
    draw.polygon([(70, 224), (175, 108), (225, 108), (330, 224)], fill=(62, 62, 66))
    draw.line([(196, 224), (200, 108)], fill=(230, 220, 150), width=3)
    draw.rectangle((64, 128, 128, 178), fill=(180, 40, 36))
    draw.rectangle((265, 118, 350, 182), fill=(38, 88, 170))
    draw.rectangle((22, 94, 80, 136), fill=(38, 130, 70))
    image.save(path, quality=95)


def make_demo_range(path: Path, height: int, width: int) -> None:
    rows = np.linspace(-1, 1, height, dtype=np.float32)[:, None]
    cols = np.linspace(-np.pi, np.pi, width, dtype=np.float32)[None, :]
    base = 35.0 + 18.0 * np.abs(rows) + 4.0 * np.cos(cols)
    front_weight = np.exp(-(cols / 0.72) ** 2)
    road_plane = 8.0 + 30.0 * np.linspace(1, 0, height, dtype=np.float32)[:, None]
    ranges = base * (1 - front_weight) + road_plane * front_weight

    def add_object(center_col: float, row0: int, row1: int, half_width: int, distance: float) -> None:
        col_center = int((center_col + np.pi) / (2 * np.pi) * width)
        for offset in range(-half_width, half_width + 1):
            col = (col_center + offset) % width
            ranges[row0:row1, col] = np.minimum(ranges[row0:row1, col], distance)

    add_object(-0.32, 9, 22, 23, 12.0)
    add_object(0.38, 7, 24, 28, 16.0)
    add_object(-0.83, 12, 20, 16, 20.0)

    ranges = np.clip(ranges, 1.0, 60.0).astype(np.float32)
    ranges.tofile(path)


def main() -> None:
    args = parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    make_demo_image(out / "sample.jpg")
    make_demo_range(out / "sample.bin", args.height, args.width)
    print(f"Wrote {out / 'sample.jpg'} and {out / 'sample.bin'}")


if __name__ == "__main__":
    main()
