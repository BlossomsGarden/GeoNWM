#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/data/wlh/XDrive}"
CONDA_DIR="${CONDA_DIR:-/data/wlh/miniconda3}"
ENV_NAME="${ENV_NAME:-das}"

cd "${PROJECT_DIR}/Calculate-DAS"
source "${CONDA_DIR}/bin/activate" "${ENV_NAME}"

python create_synthetic_range.py --output demo_inputs/synthetic_range.bin
python calculate_das.py \
  --demo-pth "${PROJECT_DIR}/demo/data/0adef8c999c6418d8c138df6a99b6282.pth" \
  --range-bin demo_inputs/synthetic_range.bin \
  --model-dir "${PROJECT_DIR}/model/depth-anything/Depth-Anything-V2-Base-hf" \
  --local-files-only \
  --device cpu \
  --output-dir outputs_demo

echo "Demo outputs:"
ls -lh outputs_demo
