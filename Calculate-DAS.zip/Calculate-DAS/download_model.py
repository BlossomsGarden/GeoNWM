#!/usr/bin/env python3
"""Download the Depth Anything V2 model into project_dir/model.

The remote server cannot reach the global Hugging Face endpoint reliably, so the
default endpoint is hf-mirror.com. This script only downloads model files; the
DAS calculator can then run with --local-files-only.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import os


DEFAULT_MODEL_ID = "depth-anything/Depth-Anything-V2-Base-hf"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Download Depth Anything V2 for DAS.")
    parser.add_argument("--model-id", default=DEFAULT_MODEL_ID)
    parser.add_argument(
        "--output-dir",
        default="../model/depth-anything/Depth-Anything-V2-Base-hf",
        help="Directory under project_dir/model where the model snapshot is stored.",
    )
    parser.add_argument(
        "--endpoint",
        default="https://hf-mirror.com",
        help="Hugging Face compatible mirror endpoint. Use https://huggingface.co only if the server can access it.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    os.environ.setdefault("HF_ENDPOINT", args.endpoint)
    os.environ.setdefault("HF_HUB_DISABLE_XET", "1")

    from huggingface_hub import snapshot_download

    snapshot_download(
        repo_id=args.model_id,
        local_dir=str(output_dir),
        local_dir_use_symlinks=False,
        resume_download=True,
    )
    print(f"Model ready: {output_dir}")


if __name__ == "__main__":
    main()
