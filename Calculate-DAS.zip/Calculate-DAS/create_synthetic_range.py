#!/usr/bin/env python3
"""Create a synthetic X-Drive-style 32 x 1024 LiDAR range map for testing."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a synthetic X-Drive range map.")
    parser.add_argument("--output", default="demo_inputs/synthetic_range.bin")
    parser.add_argument("--height", type=int, default=32)
    parser.add_argument("--width", type=int, default=1024)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = np.linspace(-1.0, 1.0, args.height, dtype=np.float32)[:, None]
    cols = np.linspace(-np.pi, np.pi, args.width, dtype=np.float32)[None, :]
    ranges = 28.0 + 10.0 * np.abs(rows) + 5.0 * np.sin(cols * 2.0) ** 2
    front = np.exp(-(cols / 0.65) ** 2)
    road = 8.0 + 26.0 * np.linspace(1.0, 0.0, args.height, dtype=np.float32)[:, None]
    ranges = ranges * (1.0 - front) + road * front

    def add_object(yaw: float, row0: int, row1: int, half_width: int, distance: float) -> None:
        center = int((args.width - 0.5) - ((yaw + np.pi) / (2.0 * np.pi)) * args.width)
        center = int(np.clip(center, 0, args.width - 1))
        for offset in range(-half_width, half_width + 1):
            col = (center + offset) % args.width
            ranges[row0:row1, col] = np.minimum(ranges[row0:row1, col], distance)

    add_object(0.0, 8, 22, 22, 11.0)
    add_object(-0.7, 10, 24, 18, 16.0)
    add_object(0.85, 9, 21, 16, 18.0)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.clip(ranges, 2.5, 60.0).astype(np.float32).tofile(out)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
