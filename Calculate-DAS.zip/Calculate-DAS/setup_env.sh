#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/data/wlh/XDrive}"
CONDA_DIR="${CONDA_DIR:-/data/wlh/miniconda3}"
ENV_NAME="${ENV_NAME:-das}"
PIP_INDEX_URL="${PIP_INDEX_URL:-https://pypi.tuna.tsinghua.edu.cn/simple}"
HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"

cd "${PROJECT_DIR}/Calculate-DAS"

if ! "${CONDA_DIR}/bin/conda" env list | awk '{print $1}' | grep -qx "${ENV_NAME}"; then
  "${CONDA_DIR}/bin/conda" create -y -n "${ENV_NAME}" python=3.10
fi

source "${CONDA_DIR}/bin/activate" "${ENV_NAME}"
python -m pip install -i "${PIP_INDEX_URL}" -r requirements.txt

mkdir -p "${PROJECT_DIR}/model"
export HF_ENDPOINT
export HF_HUB_DISABLE_XET=1
python download_model.py --output-dir "${PROJECT_DIR}/model/depth-anything/Depth-Anything-V2-Base-hf"

echo "DAS environment ready: ${ENV_NAME}"
