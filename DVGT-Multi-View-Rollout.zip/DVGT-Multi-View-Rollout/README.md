# DVGT Multi-View Rollout Stage 2

This project implements the Stage-2 feature-space rollout world model from `0602-NWM-两阶段规划.md`.

## Implemented

- Frozen DVGT-1 native token extraction for layers `{4, 11, 17, 23}`.
- nuScenes consecutive 6-view window sampling from `nuscenes_infos_train/val.pkl`.
- Trajectory-conditioned feature transport model with EG-CVA-style cross-view attention, temporal causal attention, residual flow, source term, QKNorm, LayerScale, and zero-initialized residual heads.
- Zero-parameter ego-motion transport from DVGT point maps and camera geometry, with `valid_mask` for ego-motion-explainable regions.
- End-to-end feature reconstruction supervision:
  `L_forward = L_recon + 1e-4 * (|v_res| + |S| on valid_mask)`.
- Flexible Forcing, BiC-Flow cycle loss, Chain-of-Forward, and cross-view geometric `L_3D_flow` regularization.
- Point-map eval using DVGT native metric-scale point head only.

## Training

Remote default:

```bash
cd /data/wlh/GLD/code/DVGT-Multi-View-Rollout
bash scripts/start_remote_training.sh --max-steps 100000
```

Direct:

```bash
python scripts/train_stage2.py \
  --config configs/stage2_rollout_nuscenes_704x256.yaml \
  --max-steps 100000
```

Outputs:

```text
/data/wlh/GLD/code/DVGT-Multi-View-Rollout/results/stage2-rollout/
  checkpoints/
  reports/
```

## Eval

```bash
python scripts/eval_pointmap.py \
  --ckpt results/stage2-rollout/checkpoints/best.pt \
  --horizon 8 \
  --save-xyz
```

The eval script rollouts future features, decodes them with the frozen DVGT point head, and writes `metrics.csv`, `summary.json`, and optional per-frame compressed `.npz` files containing `pred_xyz`, `pred_conf`, `gt_xyz`, and `gt_conf`.

## Remote Upload And Smoke Test

From the local machine:

```bash
python DVGT-Multi-View-Rollout/scripts/upload_remote.py --smoke-test
```

This uploads directly to `/data/wlh/GLD/code/DVGT-Multi-View-Rollout`, compiles the project with `/data/wlh/miniconda3/envs/gld/bin/python`, runs two training steps in the `gld` environment, then runs one point-map eval sample. No remote symlinks are created.

## Implementation Report And Deferred Items

- The latest planning document explicitly removed explicit `v_res_gt` and `S_gt` construction because DVGT-1 has no VGGT tracking features. This implementation follows that update: flow/source are trained through differentiable feature transport and future-feature reconstruction.
- `L_3D_flow` is implemented as a geometry consistency regularizer, not artificial flow-label supervision.
- Horizontal flip is intentionally disabled for the first implementation. It requires synchronized camera-index remapping, trajectory sign/yaw transforms, intrinsics/extrinsics updates, and point-map consistency; doing it partially would corrupt geometry.
- Clip-level generation, TensorRT acceleration, Stage-1 RGB/Depth/Sem/Occ decoder eval, Occ-loss ablation, 40-frame long-horizon drift benchmark, and downstream detection/motion-prediction experiments are not included in this first code drop.
