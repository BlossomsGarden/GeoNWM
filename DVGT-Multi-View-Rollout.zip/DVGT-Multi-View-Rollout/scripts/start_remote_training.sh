#!/bin/bash
set -euo pipefail

PROJECT_DIR="/data/wlh/GLD/code/DVGT-Multi-View-Rollout"
CONDA_SH="/data/wlh/miniconda3/etc/profile.d/conda.sh"
LOG_DIR="${PROJECT_DIR}/logs"
mkdir -p "${LOG_DIR}"

set +u
source "${CONDA_SH}"
conda activate gld
set -u

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTHONPATH="${PROJECT_DIR}:${PYTHONPATH:-}"

cd "${PROJECT_DIR}"
LOG_FILE="${LOG_DIR}/train_stage2.log"
PID_FILE="${LOG_DIR}/train_stage2.pid"

setsid nohup python scripts/train_stage2.py --config configs/stage2_rollout_nuscenes_704x256.yaml "$@" > "${LOG_FILE}" 2>&1 < /dev/null &
echo $! > "${PID_FILE}"
echo "Started Stage-2 rollout training"
echo "PID: $(cat "${PID_FILE}")"
echo "Log: ${LOG_FILE}"
