#!/usr/bin/env python
from __future__ import annotations

import argparse
import posixpath
import stat
import sys
import time
from pathlib import Path

import paramiko


def sftp_mkdirs(sftp, remote_dir: str):
    parts = []
    cur = remote_dir
    while cur not in ("", "/"):
        parts.append(cur)
        cur = posixpath.dirname(cur)
    for d in reversed(parts):
        try:
            sftp.stat(d)
        except FileNotFoundError:
            sftp.mkdir(d)


def upload_tree(sftp, local_root: Path, remote_root: str):
    skip_dirs = {"__pycache__", ".pytest_cache", "results", ".mypy_cache"}
    for path in local_root.rglob("*"):
        if any(part in skip_dirs for part in path.parts):
            continue
        rel = path.relative_to(local_root).as_posix()
        remote = posixpath.join(remote_root, rel)
        if path.is_dir():
            sftp_mkdirs(sftp, remote)
            continue
        sftp_mkdirs(sftp, posixpath.dirname(remote))
        sftp.put(str(path), remote)
        if path.suffix in {".py", ".sh"}:
            sftp.chmod(
                remote,
                stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR |
                stat.S_IRGRP | stat.S_IXGRP |
                stat.S_IROTH | stat.S_IXOTH,
            )


def stream_command(ssh, command: str, timeout: int | None = None) -> int:
    print(f"\n$ {command}", flush=True)
    chan = ssh.get_transport().open_session(timeout=30)
    chan.get_pty()
    chan.exec_command(command)
    start = time.time()
    while True:
        while chan.recv_ready():
            sys.stdout.buffer.write(chan.recv(4096))
            sys.stdout.buffer.flush()
        while chan.recv_stderr_ready():
            sys.stderr.buffer.write(chan.recv_stderr(4096))
            sys.stderr.buffer.flush()
        if chan.exit_status_ready():
            break
        if timeout is not None and time.time() - start > timeout:
            chan.close()
            raise TimeoutError(command)
        time.sleep(0.5)
    return chan.recv_exit_status()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="219.223.207.223")
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--user", default="wlh")
    parser.add_argument("--password", default="wlh@2025")
    parser.add_argument("--remote-code-dir", default="/data/wlh/GLD/code")
    parser.add_argument("--remote-name", default="DVGT-Multi-View-Rollout")
    parser.add_argument("--smoke-test", action="store_true")
    args = parser.parse_args()

    local_root = Path(__file__).resolve().parents[1]
    remote_root = posixpath.join(args.remote_code_dir, args.remote_name)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(args.host, port=args.port, username=args.user, password=args.password, timeout=20, banner_timeout=20, auth_timeout=20)
    try:
        sftp = ssh.open_sftp()
        try:
            upload_tree(sftp, local_root, remote_root)
        finally:
            sftp.close()
        code = stream_command(ssh, f"cd {remote_root} && find . -maxdepth 3 -type f | sort | sed -n '1,200p'")
        if code != 0:
            raise SystemExit(code)
        code = stream_command(ssh, f"cd {remote_root} && /data/wlh/miniconda3/envs/gld/bin/python -m compileall -q .")
        if code != 0:
            raise SystemExit(code)
        if args.smoke_test:
            code = stream_command(ssh, f"cd {remote_root} && bash scripts/smoke_test_all.sh", timeout=7200)
            raise SystemExit(code)
    finally:
        ssh.close()


if __name__ == "__main__":
    main()
