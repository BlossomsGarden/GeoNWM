#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
import torch
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_rollout import DVGTNativeWrapper
from dvgt_rollout.geometry import compute_ego_backward_flow
from dvgt_rollout.metrics import chamfer_numpy, pointmap_metrics
from dvgt_rollout.model import Stage2RolloutModel
from dvgt_rollout.utils import build_sequence_loader, get_device, load_model_state, precision_context, save_json


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage2_rollout_nuscenes_704x256.yaml"))
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--horizon", type=int, default=8)
    parser.add_argument("--num-samples", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    parser.add_argument("--out-dir", default=None)
    parser.add_argument("--save-xyz", action="store_true")
    return parser.parse_args()


def model_from_cfg(cfg, device: torch.device) -> Stage2RolloutModel:
    return Stage2RolloutModel(
        feature_indices=list(cfg.dvgt.feature_indices),
        token_dim=int(cfg.dvgt.token_dim),
        model_dim=int(cfg.rollout.model_dim),
        num_heads=int(cfg.rollout.num_heads),
        num_egcva_blocks=int(cfg.rollout.num_egcva_blocks),
        num_temporal_blocks=int(cfg.rollout.num_temporal_blocks),
        patch_size=int(cfg.dvgt.patch_size),
        max_flow_norm=float(cfg.rollout.max_flow_norm),
        source_scale=float(cfg.rollout.source_scale),
        layer_scale_init=float(cfg.rollout.layer_scale_init),
        dropout=float(cfg.rollout.dropout),
    ).to(device)


def push_cache(cache: dict[int, torch.Tensor], pred: dict[int, torch.Tensor], feature_indices) -> dict[int, torch.Tensor]:
    return {int(idx): torch.cat([cache[int(idx)][:, 1:].detach(), pred[int(idx)]], dim=1) for idx in feature_indices}


def main():
    args = parse_args()
    cfg = OmegaConf.load(args.config)
    cfg.rollout.future_frames = int(args.horizon)
    cfg.training.num_workers = int(args.num_workers)
    precision = args.precision or str(cfg.training.precision)
    device = get_device()
    out_dir = Path(args.out_dir or (Path(cfg.paths.results_dir) / "eval_pointmap"))
    out_dir.mkdir(parents=True, exist_ok=True)
    history_frames = int(cfg.rollout.history_frames)
    feature_indices = [int(x) for x in cfg.dvgt.feature_indices]

    loader = build_sequence_loader(
        cfg,
        "val",
        history_frames=history_frames,
        future_frames=int(args.horizon),
        max_samples=int(args.num_samples),
        num_workers=int(args.num_workers),
    )
    dvgt = DVGTNativeWrapper(
        str(cfg.paths.dvgt_code_dir),
        str(cfg.paths.dvgt_ckpt_dir),
        feature_indices=feature_indices,
        device=device,
        frames_chunk_size=int(cfg.dvgt.get("frames_chunk_size", 1)),
    )
    model = model_from_cfg(cfg, device).eval()
    ckpt = load_model_state(args.ckpt, model, prefer_ema=True)
    print(f"Loaded checkpoint step={ckpt.get('step', -1)} from {args.ckpt}")

    rows: list[dict[str, float | int | str]] = []
    with torch.no_grad():
        for batch_idx, batch in enumerate(tqdm(loader, desc="eval pointmap")):
            images = batch["images"].to(device, non_blocking=True)
            _, _, _, _, h, w = images.shape
            with precision_context(device, precision):
                tokens, patch_start_idx, gt_points, gt_conf = dvgt.extract_tokens_and_points(images)
                cache = {idx: value[:, :history_frames].detach() for idx, value in tokens.items()}
                current_points = gt_points[:, history_frames - 1]
                for step in range(int(args.horizon)):
                    target_frame = history_frames + step
                    patch_hw = (h // int(cfg.dvgt.patch_size), w // int(cfg.dvgt.patch_size))
                    ego_flow, ego_valid = compute_ego_backward_flow(
                        current_points,
                        batch["intrinsics"][:, target_frame].to(device),
                        batch["ego_first_to_cam"][:, target_frame].to(device),
                        (h, w),
                        patch_hw,
                    )
                    out = model.forward_one_step(
                        cache,
                        patch_start_idx,
                        (h, w),
                        batch["future_trajectory"].to(device),
                        step_index=step,
                        ego_flow_norm=ego_flow,
                        ego_valid_mask=ego_valid,
                    )
                    pred_points, pred_conf = dvgt.decode_points(out.pred, (h, w), patch_start_idx)
                    gt_step_points = gt_points[:, target_frame : target_frame + 1]
                    gt_step_conf = gt_conf[:, target_frame : target_frame + 1]
                    metrics = pointmap_metrics(pred_points, gt_step_points, gt_step_conf)
                    chamfer = chamfer_numpy(pred_points.cpu().numpy(), gt_step_points.cpu().numpy())
                    row = {
                        "batch": batch_idx,
                        "step": step,
                        "seq_name": batch["seq_name"][0],
                        "sample_token": batch["sample_tokens"][0][target_frame],
                        **metrics,
                        "chamfer": chamfer,
                    }
                    rows.append(row)
                    if args.save_xyz:
                        npz_dir = out_dir / "xyz" / f"batch_{batch_idx:04d}"
                        npz_dir.mkdir(parents=True, exist_ok=True)
                        np.savez_compressed(
                            npz_dir / f"step_{step:02d}.npz",
                            pred_xyz=pred_points.cpu().numpy(),
                            pred_conf=pred_conf.cpu().numpy(),
                            gt_xyz=gt_step_points.cpu().numpy(),
                            gt_conf=gt_step_conf.cpu().numpy(),
                        )
                    cache = push_cache(cache, out.pred, feature_indices)
                    current_points = pred_points[:, 0].detach()

    metrics_csv = out_dir / "metrics.csv"
    if rows:
        with metrics_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    summary = {}
    for key in ["xyz_l1", "xyz_rmse", "ray_absrel", "chamfer"]:
        vals = [float(row[key]) for row in rows if np.isfinite(float(row[key]))]
        summary[key] = float(np.mean(vals)) if vals else float("nan")
    summary["num_rows"] = len(rows)
    save_json(out_dir / "summary.json", summary)
    print(f"Saved metrics to {metrics_csv}")
    print(summary)


if __name__ == "__main__":
    main()
