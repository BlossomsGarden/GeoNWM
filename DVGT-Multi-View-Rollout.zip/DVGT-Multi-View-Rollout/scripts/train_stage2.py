#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_rollout import DVGTNativeWrapper, Stage2RolloutModel
from dvgt_rollout.geometry import compute_ego_backward_flow
from dvgt_rollout.losses import forward_loss, l3d_flow_loss
from dvgt_rollout.utils import (
    append_csv,
    build_optimizer_and_scheduler,
    build_sequence_loader,
    create_ema,
    get_device,
    precision_context,
    save_checkpoint,
    save_json,
    setup_logger,
    update_ema,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/stage2_rollout_nuscenes_704x256.yaml"))
    parser.add_argument("--results-dir", default=None)
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--history-frames", type=int, default=None)
    parser.add_argument("--future-frames", type=int, default=None)
    parser.add_argument("--val-batches", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--precision", choices=["fp32", "fp16", "bf16"], default=None)
    return parser.parse_args()


def stage_name(step: int, cfg) -> str:
    a = int(cfg.training.stage2a_steps)
    b = a + int(cfg.training.stage2b_steps)
    if step < a:
        return "2a"
    if step < b:
        return "2b"
    return "2c"


def cycle_weight(step: int, cfg) -> float:
    a = int(cfg.training.stage2a_steps)
    b = int(cfg.training.stage2b_steps)
    if step < a:
        return 0.0
    progress = min(max((step - a) / max(b, 1), 0.0), 1.0)
    start = float(cfg.training.cycle_start_weight)
    end = float(cfg.training.cycle_end_weight)
    return start + (end - start) * progress


def add_flexible_noise(cache: dict[int, torch.Tensor], sigma_max: float, sigma_view: float) -> dict[int, torch.Tensor]:
    noisy = {}
    for idx, value in cache.items():
        b, hist, views = value.shape[:3]
        scales = []
        for i in range(hist):
            sigma = float(sigma_max) * (1.0 - float(i + 1) / float(hist)) ** 2
            scales.append(sigma)
        frame_scale = value.new_tensor(scales).reshape(1, hist, 1, 1, 1)
        frame_noise = torch.randn_like(value) * frame_scale
        view_noise = torch.randn_like(value) * float(sigma_view)
        view_noise[:, -1] = 0.0
        noisy[idx] = value + frame_noise + view_noise
    return noisy


def model_from_cfg(cfg, device: torch.device) -> Stage2RolloutModel:
    return Stage2RolloutModel(
        feature_indices=list(cfg.dvgt.feature_indices),
        token_dim=int(cfg.dvgt.token_dim),
        model_dim=int(cfg.rollout.model_dim),
        num_heads=int(cfg.rollout.num_heads),
        num_egcva_blocks=int(cfg.rollout.num_egcva_blocks),
        num_temporal_blocks=int(cfg.rollout.num_temporal_blocks),
        patch_size=int(cfg.dvgt.patch_size),
        max_flow_norm=float(cfg.rollout.max_flow_norm),
        source_scale=float(cfg.rollout.source_scale),
        layer_scale_init=float(cfg.rollout.layer_scale_init),
        dropout=float(cfg.rollout.dropout),
    ).to(device)


def target_slice(tokens: dict[int, torch.Tensor], frame_index: int, feature_indices) -> dict[int, torch.Tensor]:
    return {int(idx): tokens[int(idx)][:, frame_index : frame_index + 1].detach() for idx in feature_indices}


def replace_cache_tail(cache: dict[int, torch.Tensor], pred: dict[int, torch.Tensor], feature_indices) -> dict[int, torch.Tensor]:
    return {int(idx): torch.cat([cache[int(idx)][:, 1:].detach(), pred[int(idx)]], dim=1) for idx in feature_indices}


def one_step_losses(
    model: Stage2RolloutModel,
    cache: dict[int, torch.Tensor],
    tokens: dict[int, torch.Tensor],
    points: torch.Tensor,
    batch: dict,
    patch_start_idx: int,
    image_size: tuple[int, int],
    cfg,
    source_frame: int,
    target_frame: int,
    step_index: int,
    include_l3d: bool,
    feature_indices,
) -> tuple[dict[str, torch.Tensor], object]:
    patch_hw = (image_size[0] // int(cfg.dvgt.patch_size), image_size[1] // int(cfg.dvgt.patch_size))
    ego_flow, ego_valid = compute_ego_backward_flow(
        points[:, source_frame].to(next(model.parameters()).device),
        batch["intrinsics"][:, target_frame].to(next(model.parameters()).device),
        batch["ego_first_to_cam"][:, target_frame].to(next(model.parameters()).device),
        image_size,
        patch_hw,
    )
    out = model.forward_one_step(
        cache,
        patch_start_idx,
        image_size,
        batch["future_trajectory"].to(next(model.parameters()).device),
        step_index=step_index,
        ego_flow_norm=ego_flow,
        ego_valid_mask=ego_valid,
    )
    losses = forward_loss(
        out,
        target_slice(tokens, target_frame, feature_indices),
        feature_indices,
        sparse_weight=float(cfg.training.sparse_weight),
    )
    if include_l3d:
        l3d = l3d_flow_loss(
            out,
            points[:, source_frame].to(next(model.parameters()).device),
            batch["intrinsics"][:, target_frame].to(next(model.parameters()).device),
            batch["ego_first_to_cam"][:, target_frame].to(next(model.parameters()).device),
            image_size,
        )
        losses.update(l3d)
    return losses, out


def add_cycle_loss(
    model: Stage2RolloutModel,
    cache: dict[int, torch.Tensor],
    forward_out,
    patch_start_idx: int,
    image_size: tuple[int, int],
    trajectory: torch.Tensor,
    feature_indices,
) -> torch.Tensor:
    reverse_cache = replace_cache_tail(cache, forward_out.pred, feature_indices)
    reverse_traj = -trajectory.clone()
    reverse_out = model.forward_one_step(reverse_cache, patch_start_idx, image_size, reverse_traj, step_index=0)
    terms = []
    for idx in feature_indices:
        terms.append(F.mse_loss(reverse_out.pred[int(idx)].float(), cache[int(idx)][:, -1:].float()))
    return torch.stack(terms).mean()


@torch.no_grad()
def validate(dvgt, model, loader, cfg, device, precision, max_batches: int, history_frames: int):
    model.eval()
    total = {"val/recon": 0.0, "val/sparse": 0.0, "val/forward": 0.0}
    count = 0
    for i, batch in enumerate(tqdm(loader, desc="val", leave=False)):
        if i >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        _, total_frames, _, _, h, w = images.shape
        with precision_context(device, precision):
            tokens, patch_start_idx, points, _ = dvgt.extract_tokens_and_points(images)
            cache = {idx: value[:, :history_frames].detach() for idx, value in tokens.items()}
            losses, _ = one_step_losses(
                model,
                cache,
                tokens,
                points,
                {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()},
                patch_start_idx,
                (h, w),
                cfg,
                source_frame=history_frames - 1,
                target_frame=history_frames,
                step_index=0,
                include_l3d=False,
                feature_indices=list(cfg.dvgt.feature_indices),
            )
        total["val/recon"] += float(losses["loss/recon"].item())
        total["val/sparse"] += float(losses["loss/sparse"].item())
        total["val/forward"] += float(losses["loss/forward"].item())
        count += 1
    model.train()
    return {k: v / max(count, 1) for k, v in total.items()} | {"val/batches": count}


def main():
    args = parse_args()
    cfg = OmegaConf.load(args.config)
    if args.history_frames is not None:
        cfg.rollout.history_frames = args.history_frames
    if args.future_frames is not None:
        cfg.rollout.future_frames = args.future_frames
    if args.num_workers is not None:
        cfg.training.num_workers = args.num_workers
    precision = args.precision or str(cfg.training.precision)
    torch.manual_seed(int(cfg.training.seed))
    device = get_device()
    out_root = Path(args.results_dir or cfg.paths.results_dir)
    logger = setup_logger(out_root)
    logger.info(f"config={args.config}")
    logger.info(f"device={device} precision={precision}")

    history_frames = int(cfg.rollout.history_frames)
    future_frames = int(cfg.rollout.future_frames)
    train_loader = build_sequence_loader(
        cfg,
        "train",
        history_frames=history_frames,
        future_frames=future_frames,
        max_samples=cfg.training.get("max_train_samples"),
        num_workers=args.num_workers,
    )
    val_loader = build_sequence_loader(
        cfg,
        "val",
        history_frames=history_frames,
        future_frames=future_frames,
        max_samples=cfg.training.get("max_val_samples"),
        num_workers=args.num_workers,
    )
    dvgt = DVGTNativeWrapper(
        str(cfg.paths.dvgt_code_dir),
        str(cfg.paths.dvgt_ckpt_dir),
        feature_indices=list(cfg.dvgt.feature_indices),
        device=device,
        frames_chunk_size=int(cfg.dvgt.get("frames_chunk_size", 1)),
    )
    model = model_from_cfg(cfg, device)
    ema = create_ema(model, bool(cfg.training.ema))
    optimizer, scheduler = build_optimizer_and_scheduler(model, cfg)
    metrics_csv = out_root / "reports/metrics.csv"
    global_step = 0
    max_steps = args.max_steps
    grad_accum = int(cfg.training.get("grad_accum_steps", 1))
    feature_indices = [int(x) for x in cfg.dvgt.feature_indices]

    for epoch in range(int(cfg.training.epochs)):
        model.train()
        for batch in tqdm(train_loader, desc=f"stage2 epoch {epoch}"):
            images = batch["images"].to(device, non_blocking=True)
            _, total_frames, _, _, h, w = images.shape
            if total_frames < history_frames + 1:
                raise RuntimeError("batch has no future target frame")
            with torch.no_grad():
                tokens, patch_start_idx, points, _ = dvgt.extract_tokens_and_points(images)
            cache = {idx: value[:, :history_frames].detach() for idx, value in tokens.items()}
            cur_stage = stage_name(global_step, cfg)
            if cur_stage in ("2b", "2c"):
                train_cache = add_flexible_noise(cache, float(cfg.training.flexible_sigma_max), float(cfg.training.flexible_sigma_view))
            else:
                train_cache = cache

            if global_step % grad_accum == 0:
                optimizer.zero_grad(set_to_none=True)
            chain_mode = cur_stage == "2c" and global_step % int(cfg.training.chain_interval) == 0
            chain_len = min(int(cfg.training.chain_length) if chain_mode else 1, future_frames)
            total_loss = None
            log_terms: dict[str, float] = {"stage": cur_stage, "chain_len": float(chain_len)}
            running_cache = train_cache
            with precision_context(device, precision):
                for k in range(chain_len):
                    include_l3d = cur_stage in ("2b", "2c")
                    losses, out = one_step_losses(
                        model,
                        running_cache,
                        tokens,
                        points,
                        {kk: (vv.to(device) if torch.is_tensor(vv) else vv) for kk, vv in batch.items()},
                        patch_start_idx,
                        (h, w),
                        cfg,
                        source_frame=history_frames - 1 + k,
                        target_frame=history_frames + k,
                        step_index=k,
                        include_l3d=include_l3d,
                        feature_indices=feature_indices,
                    )
                    step_loss = losses["loss/forward"]
                    if include_l3d:
                        step_loss = step_loss + float(cfg.training.l3d_weight) * losses["loss/l3d_flow"]
                    if cur_stage in ("2b", "2c"):
                        cyc = add_cycle_loss(
                            model,
                            running_cache,
                            out,
                            patch_start_idx,
                            (h, w),
                            batch["future_trajectory"].to(device),
                            feature_indices,
                        )
                        losses["loss/cycle"] = cyc
                        step_loss = step_loss + cycle_weight(global_step, cfg) * cyc
                    total_loss = step_loss if total_loss is None else total_loss + step_loss
                    running_cache = replace_cache_tail(running_cache, out.pred, feature_indices)
                    for name, value in losses.items():
                        log_terms[name] = log_terms.get(name, 0.0) + float(value.detach().item()) / float(chain_len)
                total_loss = total_loss / float(chain_len * grad_accum)
            total_loss.backward()
            if (global_step + 1) % grad_accum == 0:
                if float(cfg.training.clip_grad) > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg.training.clip_grad))
                optimizer.step()
                scheduler.step()
                update_ema(ema, model, float(cfg.training.ema_decay))
                optimizer.zero_grad(set_to_none=True)

            if global_step % int(cfg.training.log_interval) == 0:
                row = {
                    "step": global_step,
                    "epoch": epoch,
                    "lr": optimizer.param_groups[0]["lr"],
                    "loss/total": float(total_loss.detach().item() * grad_accum),
                    **log_terms,
                }
                logger.info(", ".join(f"{k}={v:.6f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
                append_csv(metrics_csv, row)

            global_step += 1
            if global_step % int(cfg.training.val_interval) == 0:
                metrics = validate(
                    dvgt,
                    ema or model,
                    val_loader,
                    cfg,
                    device,
                    precision,
                    args.val_batches or int(cfg.training.val_batches),
                    history_frames,
                )
                metrics["step"] = global_step
                save_json(out_root / f"reports/eval/step_{global_step:07d}.json", metrics)
                logger.info("[val] " + ", ".join(f"{k}={v:.6f}" for k, v in metrics.items() if isinstance(v, float)))
            if global_step % int(cfg.training.ckpt_interval) == 0:
                save_checkpoint(out_root / f"checkpoints/step_{global_step:07d}.pt", global_step, epoch, model, optimizer, scheduler, cfg, ema)
            if max_steps is not None and global_step >= max_steps:
                save_checkpoint(out_root / "checkpoints/smoke_last.pt", global_step, epoch, model, optimizer, scheduler, cfg, ema)
                return
        save_checkpoint(out_root / f"checkpoints/epoch_{epoch + 1:04d}.pt", global_step, epoch, model, optimizer, scheduler, cfg, ema)


if __name__ == "__main__":
    main()
