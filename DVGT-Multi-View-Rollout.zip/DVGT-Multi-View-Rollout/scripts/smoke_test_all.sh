#!/bin/bash
set -euo pipefail

cd /data/wlh/GLD/code/DVGT-Multi-View-Rollout

set +u
source /data/wlh/miniconda3/etc/profile.d/conda.sh
conda activate gld
set -u

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTHONPATH="/data/wlh/GLD/code/DVGT-Multi-View-Rollout:${PYTHONPATH:-}"

python -m compileall -q .
python scripts/train_stage2.py \
  --config configs/stage2_rollout_nuscenes_704x256.yaml \
  --max-steps 2 \
  --num-workers 0 \
  --history-frames 2 \
  --future-frames 1 \
  --val-batches 1

python scripts/eval_pointmap.py \
  --config configs/stage2_rollout_nuscenes_704x256.yaml \
  --ckpt results/stage2-rollout/checkpoints/smoke_last.pt \
  --num-samples 1 \
  --num-workers 0 \
  --horizon 1 \
  --save-xyz

echo "Stage-2 rollout smoke tests completed."
