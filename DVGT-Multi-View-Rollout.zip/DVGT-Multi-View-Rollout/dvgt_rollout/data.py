from __future__ import annotations

import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF


CAMERAS = (
    "CAM_FRONT",
    "CAM_FRONT_LEFT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_BACK_RIGHT",
)


def _resolve_nuscenes_path(root: Path, path_value: str) -> Path:
    rel = str(path_value).replace("./data/nuscenes/", "")
    return root / rel


def _sequence_key(info: dict[str, Any]) -> str:
    name = Path(info["lidar_path"]).name
    if "__LIDAR_TOP__" in name:
        return name.split("__LIDAR_TOP__", 1)[0]
    return name.rsplit("__", 1)[0]


def _quat_to_rotmat(q: list[float] | np.ndarray) -> np.ndarray:
    w, x, y, z = [float(v) for v in q]
    n = w * w + x * x + y * y + z * z
    if n < 1e-12:
        return np.eye(3, dtype=np.float32)
    s = 2.0 / n
    wx, wy, wz = s * w * x, s * w * y, s * w * z
    xx, xy, xz = s * x * x, s * x * y, s * x * z
    yy, yz, zz = s * y * y, s * y * z, s * z * z
    return np.array(
        [
            [1.0 - (yy + zz), xy - wz, xz + wy],
            [xy + wz, 1.0 - (xx + zz), yz - wx],
            [xz - wy, yz + wx, 1.0 - (xx + yy)],
        ],
        dtype=np.float32,
    )


def _make_transform(rotation: list[float], translation: list[float]) -> np.ndarray:
    mat = np.eye(4, dtype=np.float32)
    mat[:3, :3] = _quat_to_rotmat(rotation)
    mat[:3, 3] = np.asarray(translation, dtype=np.float32)
    return mat


def _invert_transform(mat: np.ndarray) -> np.ndarray:
    out = np.eye(4, dtype=np.float32)
    out[:3, :3] = mat[:3, :3].T
    out[:3, 3] = -out[:3, :3] @ mat[:3, 3]
    return out


def _yaw_from_rotmat(rot: np.ndarray) -> float:
    return float(math.atan2(rot[1, 0], rot[0, 0]))


class NuScenesSequenceDataset(Dataset):
    """nuScenes 6-view consecutive-window loader for stage-2 rollout training."""

    def __init__(
        self,
        root: str,
        split: str,
        image_size: list[int] | tuple[int, int] = (704, 256),
        history_frames: int = 8,
        future_frames: int = 1,
        cameras: list[str] | tuple[str, ...] = CAMERAS,
        max_samples: int | None = None,
        stride: int = 1,
    ):
        self.root = Path(root)
        self.split = split
        self.width, self.height = int(image_size[0]), int(image_size[1])
        self.history_frames = int(history_frames)
        self.future_frames = int(future_frames)
        self.total_frames = self.history_frames + self.future_frames
        self.cameras = tuple(cameras)
        self.stride = max(int(stride), 1)
        if self.width % 16 != 0 or self.height % 16 != 0:
            raise ValueError(f"image_size must be divisible by 16, got {(self.width, self.height)}")
        if self.history_frames < 1 or self.future_frames < 1:
            raise ValueError("history_frames and future_frames must be positive")

        info_path = self.root / f"nuscenes_infos_{'train' if split == 'train' else 'val'}.pkl"
        with info_path.open("rb") as f:
            infos = pickle.load(f)["infos"]
        groups: dict[str, list[dict[str, Any]]] = {}
        for info in infos:
            groups.setdefault(_sequence_key(info), []).append(info)
        for key in list(groups):
            groups[key].sort(key=lambda row: int(row["timestamp"]))
            if len(groups[key]) < self.total_frames:
                del groups[key]

        windows: list[tuple[str, int]] = []
        for key, seq_infos in sorted(groups.items()):
            for start in range(0, len(seq_infos) - self.total_frames + 1, self.stride):
                windows.append((key, start))
                if max_samples is not None and len(windows) >= int(max_samples):
                    break
            if max_samples is not None and len(windows) >= int(max_samples):
                break
        if not windows:
            raise RuntimeError(f"No sequence windows found for split={split}")
        self.groups = groups
        self.windows = windows

    def __len__(self) -> int:
        return len(self.windows)

    def _load_image(self, path: Path) -> torch.Tensor:
        image = Image.open(path).convert("RGB")
        image = image.resize((self.width, self.height), Image.Resampling.BICUBIC)
        return TF.to_tensor(image)

    def _scaled_intrinsics(self, cam_info: dict[str, Any]) -> np.ndarray:
        intr = np.asarray(cam_info["camera_intrinsics"], dtype=np.float32).copy()
        intr[0, :] *= self.width / 1600.0
        intr[1, :] *= self.height / 900.0
        return intr

    def _frame_ego_to_global(self, info: dict[str, Any]) -> np.ndarray:
        return _make_transform(info["ego2global_rotation"], info["ego2global_translation"])

    def _cam_to_ego(self, cam_info: dict[str, Any]) -> np.ndarray:
        return _make_transform(cam_info["sensor2ego_rotation"], cam_info["sensor2ego_translation"])

    def __getitem__(self, idx: int) -> dict[str, Any]:
        seq_key, start = self.windows[idx]
        infos = self.groups[seq_key][start : start + self.total_frames]
        ego_to_global = np.stack([self._frame_ego_to_global(info) for info in infos], axis=0)
        ego_first_to_global = ego_to_global[0]
        global_to_ego_curr = _invert_transform(ego_to_global[self.history_frames - 1])

        images, intrinsics, cam_to_ego, ego_first_to_cam = [], [], [], []
        labels: list[list[str]] = []
        for t, info in enumerate(infos):
            frame_images, frame_intr, frame_cam_to_ego, frame_ego_first_to_cam = [], [], [], []
            frame_labels = []
            for cam in self.cameras:
                cam_info = info["cams"][cam]
                image_path = _resolve_nuscenes_path(self.root, cam_info["data_path"])
                frame_images.append(self._load_image(image_path))
                intr = self._scaled_intrinsics(cam_info)
                c2e = self._cam_to_ego(cam_info)
                c2g = ego_to_global[t] @ c2e
                g2c = _invert_transform(c2g)
                frame_intr.append(torch.from_numpy(intr))
                frame_cam_to_ego.append(torch.from_numpy(c2e))
                frame_ego_first_to_cam.append(torch.from_numpy(g2c @ ego_first_to_global))
                frame_labels.append(str(image_path.relative_to(self.root)))
            images.append(torch.stack(frame_images, dim=0))
            intrinsics.append(torch.stack(frame_intr, dim=0))
            cam_to_ego.append(torch.stack(frame_cam_to_ego, dim=0))
            ego_first_to_cam.append(torch.stack(frame_ego_first_to_cam, dim=0))
            labels.append(frame_labels)

        future_rel = []
        curr_to_global = ego_to_global[self.history_frames - 1]
        global_to_curr = global_to_ego_curr
        for f in range(self.future_frames):
            rel = global_to_curr @ ego_to_global[self.history_frames + f]
            yaw = _yaw_from_rotmat(rel[:3, :3])
            future_rel.append([rel[0, 3], rel[1, 3], rel[2, 3], yaw])

        return {
            "seq_name": seq_key,
            "sample_tokens": [str(info["token"]) for info in infos],
            "timestamps": torch.tensor([int(info["timestamp"]) for info in infos], dtype=torch.long),
            "images": torch.stack(images, dim=0),
            "intrinsics": torch.stack(intrinsics, dim=0),
            "cam_to_ego": torch.stack(cam_to_ego, dim=0),
            "ego_to_global": torch.from_numpy(ego_to_global),
            "ego_first_to_cam": torch.stack(ego_first_to_cam, dim=0),
            "future_trajectory": torch.tensor(future_rel, dtype=torch.float32),
            "labels": labels,
        }


def collate_sequence_batch(samples: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    tensor_keys = {
        "timestamps",
        "images",
        "intrinsics",
        "cam_to_ego",
        "ego_to_global",
        "ego_first_to_cam",
        "future_trajectory",
    }
    for key in samples[0]:
        if key in tensor_keys:
            out[key] = torch.stack([s[key] for s in samples], dim=0)
        else:
            out[key] = [s[key] for s in samples]
    return out
