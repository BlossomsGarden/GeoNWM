from __future__ import annotations

import numpy as np
import torch


def pointmap_metrics(pred_xyz: torch.Tensor, gt_xyz: torch.Tensor, gt_conf: torch.Tensor | None = None) -> dict[str, float]:
    pred = pred_xyz.float()
    gt = gt_xyz.float()
    mask = torch.isfinite(gt).all(dim=-1) & torch.isfinite(pred).all(dim=-1)
    if gt_conf is not None:
        mask = mask & torch.isfinite(gt_conf).bool() & (gt_conf.float() > 1.0)
    if not mask.any():
        return {"xyz_l1": float("nan"), "xyz_rmse": float("nan"), "ray_absrel": float("nan")}
    diff = pred[mask] - gt[mask]
    l1 = diff.abs().mean()
    rmse = diff.pow(2).sum(dim=-1).mean().sqrt()
    pred_depth = pred.norm(dim=-1).clamp_min(1e-6)
    gt_depth = gt.norm(dim=-1).clamp_min(1e-6)
    absrel = ((pred_depth[mask] - gt_depth[mask]).abs() / gt_depth[mask]).mean()
    return {"xyz_l1": float(l1.item()), "xyz_rmse": float(rmse.item()), "ray_absrel": float(absrel.item())}


def chamfer_numpy(pred_xyz: np.ndarray, gt_xyz: np.ndarray, max_points: int = 12000) -> float:
    from scipy.spatial import cKDTree

    pred = pred_xyz.reshape(-1, 3)
    gt = gt_xyz.reshape(-1, 3)
    valid_pred = np.isfinite(pred).all(axis=1)
    valid_gt = np.isfinite(gt).all(axis=1)
    pred = pred[valid_pred]
    gt = gt[valid_gt]
    if pred.size == 0 or gt.size == 0:
        return float("nan")
    if len(pred) > max_points:
        pred = pred[np.linspace(0, len(pred) - 1, max_points).astype(np.int64)]
    if len(gt) > max_points:
        gt = gt[np.linspace(0, len(gt) - 1, max_points).astype(np.int64)]
    gt_tree = cKDTree(gt)
    pred_tree = cKDTree(pred)
    acc = gt_tree.query(pred, k=1)[0].mean()
    comp = pred_tree.query(gt, k=1)[0].mean()
    return float(acc + comp)
