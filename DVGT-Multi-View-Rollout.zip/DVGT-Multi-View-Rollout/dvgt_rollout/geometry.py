from __future__ import annotations

import torch

from .transport import downsample_points_to_patches, patch_centers_pixel


def compute_ego_backward_flow(
    current_points_ego_first: torch.Tensor,
    target_intrinsics: torch.Tensor,
    target_ego_first_to_cam: torch.Tensor,
    image_size: tuple[int, int],
    patch_hw: tuple[int, int],
) -> tuple[torch.Tensor, torch.Tensor]:
    """Compute zero-parameter ego-motion backward flow for pull-based transport.

    The flow is defined on target patch locations and stores the source patch
    coordinate to sample from. It is built by projecting current-frame point-map
    patches into the target camera and keeping the nearest source patch per
    target patch.
    """
    b, views = current_points_ego_first.shape[:2]
    hp, wp = patch_hw
    height, width = int(image_size[0]), int(image_size[1])
    patch_points = downsample_points_to_patches(current_points_ego_first.float(), patch_hw)
    patches = hp * wp
    ones = torch.ones((b, views, patches, 1), device=patch_points.device, dtype=patch_points.dtype)
    pts_h = torch.cat([patch_points, ones], dim=-1)
    cam = torch.einsum("bvij,bvpj->bvpi", target_ego_first_to_cam.float(), pts_h)[..., :3]
    pix_h = torch.einsum("bvij,bvpj->bvpi", target_intrinsics.float(), cam)
    z = cam[..., 2]
    uv = pix_h[..., :2] / z.clamp_min(1e-6)[..., None]
    uv_patch = uv.clone()
    uv_patch[..., 0] = uv_patch[..., 0] / (float(width) / float(wp))
    uv_patch[..., 1] = uv_patch[..., 1] / (float(height) / float(hp))

    src_centers = patch_centers_pixel(patch_hw, patch_points.device, patch_points.dtype)
    target_centers = src_centers
    flow_pix = torch.zeros((b, views, patches, 2), device=patch_points.device, dtype=patch_points.dtype)
    valid = torch.zeros((b, views, patches), device=patch_points.device, dtype=torch.bool)

    for bi in range(b):
        for vi in range(views):
            uv_v = uv_patch[bi, vi]
            z_v = z[bi, vi]
            inside = (
                (z_v > 0.05)
                & torch.isfinite(uv_v).all(dim=-1)
                & (uv_v[:, 0] >= 0)
                & (uv_v[:, 0] <= wp - 1)
                & (uv_v[:, 1] >= 0)
                & (uv_v[:, 1] <= hp - 1)
            )
            if not inside.any():
                continue
            src_idx = inside.nonzero(as_tuple=False).flatten()
            tgt_x = uv_v[src_idx, 0].round().long().clamp(0, wp - 1)
            tgt_y = uv_v[src_idx, 1].round().long().clamp(0, hp - 1)
            tgt_idx = tgt_y * wp + tgt_x
            order = torch.argsort(z_v[src_idx])
            chosen = torch.full((patches,), -1, device=patch_points.device, dtype=torch.long)
            for src_order_idx in order.tolist():
                t_idx = int(tgt_idx[src_order_idx].item())
                if int(chosen[t_idx].item()) < 0:
                    chosen[t_idx] = src_idx[src_order_idx]
            filled = chosen >= 0
            if filled.any():
                src = src_centers[chosen[filled]]
                tgt = target_centers[filled]
                flow_pix[bi, vi, filled] = src - tgt
                valid[bi, vi, filled] = True

    norm = flow_pix.clone()
    norm[..., 0] = norm[..., 0] * 2.0 / max(wp - 1, 1)
    norm[..., 1] = norm[..., 1] * 2.0 / max(hp - 1, 1)
    return norm, valid
