from __future__ import annotations

import torch
import torch.nn.functional as F


def patch_grid(height: int, width: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    ys = torch.linspace(-1.0, 1.0, height, device=device, dtype=dtype)
    xs = torch.linspace(-1.0, 1.0, width, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(ys, xs, indexing="ij")
    return torch.stack([xx, yy], dim=-1)


def transport_patch_tokens(
    patch_tokens: torch.Tensor,
    flow_norm: torch.Tensor,
    patch_hw: tuple[int, int],
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Warp patch tokens with normalized grid offsets.

    Args:
        patch_tokens: B,L,V,P,C.
        flow_norm: B,L,V,P,2 in grid_sample normalized coordinates.
        patch_hw: (Hp, Wp).

    Returns:
        warped: B,L,V,P,C.
        valid_mask: B,L,V,P.
        sample_grid: B,L,V,Hp,Wp,2.
    """
    b, layers, views, patches, channels = patch_tokens.shape
    hp, wp = patch_hw
    if patches != hp * wp:
        raise ValueError(f"patch count {patches} does not match patch_hw={patch_hw}")
    base = patch_grid(hp, wp, patch_tokens.device, patch_tokens.dtype)
    base = base.reshape(1, 1, 1, hp, wp, 2)
    grid = base + flow_norm.reshape(b, layers, views, hp, wp, 2)
    valid = (
        (grid[..., 0] >= -1.0)
        & (grid[..., 0] <= 1.0)
        & (grid[..., 1] >= -1.0)
        & (grid[..., 1] <= 1.0)
    )
    src = patch_tokens.reshape(b * layers * views, hp, wp, channels).permute(0, 3, 1, 2).contiguous()
    warped = F.grid_sample(
        src,
        grid.reshape(b * layers * views, hp, wp, 2),
        mode="bilinear",
        padding_mode="zeros",
        align_corners=True,
    )
    warped = warped.permute(0, 2, 3, 1).reshape(b, layers, views, patches, channels)
    return warped, valid.reshape(b, layers, views, patches), grid


def normalized_flow_to_pixel(flow_norm: torch.Tensor, patch_hw: tuple[int, int]) -> torch.Tensor:
    hp, wp = patch_hw
    scale = flow_norm.new_tensor([(wp - 1) / 2.0, (hp - 1) / 2.0])
    return flow_norm * scale


def patch_centers_pixel(patch_hw: tuple[int, int], device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    hp, wp = patch_hw
    ys = torch.arange(hp, device=device, dtype=dtype)
    xs = torch.arange(wp, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(ys, xs, indexing="ij")
    return torch.stack([xx, yy], dim=-1).reshape(hp * wp, 2)


def sample_patch_map(
    values: torch.Tensor,
    coords_patch: torch.Tensor,
    patch_hw: tuple[int, int],
) -> torch.Tensor:
    """Sample B,V,P,C values at patch-grid pixel coordinates B,V,P,2."""
    b, views, patches, channels = values.shape
    hp, wp = patch_hw
    grid = coords_patch.clone()
    grid_x = 2.0 * grid[..., 0] / max(wp - 1, 1) - 1.0
    grid_y = 2.0 * grid[..., 1] / max(hp - 1, 1) - 1.0
    norm_grid = torch.stack([grid_x, grid_y], dim=-1).reshape(b * views, patches, 1, 2)
    src = values.reshape(b * views, hp, wp, channels).permute(0, 3, 1, 2).contiguous()
    sampled = F.grid_sample(src, norm_grid, mode="bilinear", padding_mode="zeros", align_corners=True)
    return sampled.squeeze(-1).permute(0, 2, 1).reshape(b, views, patches, channels)


def downsample_points_to_patches(points: torch.Tensor, patch_hw: tuple[int, int]) -> torch.Tensor:
    """Downsample point maps B,V,H,W,3 to B,V,P,3."""
    b, views, height, width, channels = points.shape
    hp, wp = patch_hw
    src = points.permute(0, 1, 4, 2, 3).reshape(b * views, channels, height, width)
    out = F.interpolate(src, size=(hp, wp), mode="bilinear", align_corners=True)
    return out.reshape(b, views, channels, hp, wp).permute(0, 1, 3, 4, 2).reshape(b, views, hp * wp, channels)
