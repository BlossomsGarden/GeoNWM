from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path
from typing import Iterable

import torch


class DVGTNativeWrapper(torch.nn.Module):
    """Frozen DVGT-1 wrapper exposing native tokens and the native metric point head."""

    def __init__(
        self,
        code_dir: str,
        ckpt_dir: str,
        feature_indices: Iterable[int] = (4, 11, 17, 23),
        device: torch.device | str = "cuda",
        frames_chunk_size: int | None = None,
    ):
        super().__init__()
        self.code_dir = Path(code_dir)
        self.ckpt_dir = Path(ckpt_dir)
        self.feature_indices = [int(x) for x in feature_indices]
        self.device = torch.device(device)
        self.frames_chunk_size = frames_chunk_size
        self.model = self._build_model().to(self.device).eval()
        for p in self.model.parameters():
            p.requires_grad_(False)

    def _build_model(self):
        if not self.code_dir.is_dir():
            raise FileNotFoundError(f"DVGT code_dir does not exist: {self.code_dir}")
        sys.path.insert(0, str(self.code_dir))
        module = importlib.import_module("dvgt.models.architectures.dvgt1")
        builder = getattr(module, "DVGT1")

        old_cwd = os.getcwd()
        orig_hub_load = torch.hub.load

        def hub_load_no_pretrain(repo_or_dir, model, *args, **kwargs):
            if "dinov3" in str(repo_or_dir) and "pretrained" not in kwargs:
                kwargs["pretrained"] = False
            return orig_hub_load(repo_or_dir, model, *args, **kwargs)

        torch.hub.load = hub_load_no_pretrain
        os.chdir(str(self.code_dir))
        try:
            try:
                model = builder(
                    dino_v3_weight_path=None,
                    enable_ego_pose=False,
                    enable_point=True,
                    frames_chunk_size=self.frames_chunk_size,
                )
            except TypeError:
                model = builder(enable_ego_pose=False, enable_point=True)
        finally:
            torch.hub.load = orig_hub_load
            os.chdir(old_cwd)

        ckpt_files = sorted(self.ckpt_dir.glob("*.pt")) + sorted(self.ckpt_dir.glob("*.pth"))
        if not ckpt_files:
            raise FileNotFoundError(f"No DVGT checkpoint found under {self.ckpt_dir}")
        state = torch.load(ckpt_files[0], map_location="cpu")
        if isinstance(state, dict):
            state = state.get("model", state.get("state_dict", state))
        missing, unexpected = model.load_state_dict(state, strict=False)
        print(f"[DVGT] loaded {ckpt_files[0]} missing={len(missing)} unexpected={len(unexpected)}")
        return model

    @torch.no_grad()
    def extract_tokens(self, images_01: torch.Tensor) -> tuple[dict[int, torch.Tensor], int]:
        """Return selected native tokens shaped B,T,V,N,C and patch_start_idx."""
        if images_01.ndim != 6:
            raise ValueError(f"Expected images shaped B,T,V,3,H,W, got {tuple(images_01.shape)}")
        images = images_01.to(self.device, non_blocking=True)
        out_list, patch_start_idx = self.model.aggregator(images)
        selected = {idx: out_list[idx].detach() for idx in self.feature_indices}
        return selected, int(patch_start_idx)

    def make_token_list(self, selected: dict[int, torch.Tensor]) -> list[torch.Tensor | None]:
        max_idx = max(self.feature_indices)
        out: list[torch.Tensor | None] = [None] * (max_idx + 1)
        for idx in self.feature_indices:
            out[idx] = selected[idx]
        return out

    @torch.no_grad()
    def decode_points(
        self,
        selected: dict[int, torch.Tensor],
        image_size: tuple[int, int],
        patch_start_idx: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Decode selected native tokens through the frozen DVGT point head."""
        if self.model.point_head is None:
            raise RuntimeError("DVGT model was built without point_head")
        first = selected[self.feature_indices[0]]
        b, t, v = first.shape[:3]
        h, w = int(image_size[0]), int(image_size[1])
        dummy_images = first.new_zeros((b, t, v, 3, h, w))
        token_list = self.make_token_list(selected)
        points, conf = self.model.point_head(
            token_list,
            images=dummy_images,
            patch_start_idx=patch_start_idx,
            frames_chunk_size=self.frames_chunk_size,
        )
        return points.detach(), conf.detach()

    @torch.no_grad()
    def extract_tokens_and_points(
        self,
        images_01: torch.Tensor,
    ) -> tuple[dict[int, torch.Tensor], int, torch.Tensor, torch.Tensor]:
        selected, patch_start_idx = self.extract_tokens(images_01)
        _, _, _, _, h, w = images_01.shape
        points, conf = self.decode_points(selected, (h, w), patch_start_idx)
        return selected, patch_start_idx, points, conf
