from __future__ import annotations

import csv
import json
import logging
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import torch
from omegaconf import DictConfig, OmegaConf
from torch.utils.data import DataLoader

from .data import NuScenesSequenceDataset, collate_sequence_batch


def get_device() -> torch.device:
    return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def precision_context(device: torch.device, precision: str):
    enabled = precision in ("fp16", "bf16") and device.type == "cuda"
    dtype = torch.float16 if precision == "fp16" else torch.bfloat16
    return torch.autocast(device_type="cuda", dtype=dtype, enabled=enabled)


def setup_logger(out_dir: Path) -> logging.Logger:
    out_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(str(out_dir))
    logger.handlers.clear()
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("[%(asctime)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    stream = logging.StreamHandler()
    stream.setFormatter(fmt)
    file_handler = logging.FileHandler(out_dir / "log.txt", encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def build_sequence_loader(
    cfg: DictConfig,
    split: str,
    history_frames: int | None = None,
    future_frames: int | None = None,
    max_samples: int | None = None,
    num_workers: int | None = None,
) -> DataLoader:
    data_cfg = cfg.data
    dataset = NuScenesSequenceDataset(
        root=str(data_cfg.nuscenes_root),
        split=split,
        image_size=tuple(int(x) for x in data_cfg.image_size),
        history_frames=int(history_frames or cfg.rollout.history_frames),
        future_frames=int(future_frames or cfg.rollout.future_frames),
        max_samples=max_samples,
        stride=int(data_cfg.get("stride", 1)),
    )
    return DataLoader(
        dataset,
        batch_size=int(cfg.training.batch_size),
        shuffle=(split == "train"),
        num_workers=int(cfg.training.num_workers if num_workers is None else num_workers),
        pin_memory=True,
        drop_last=(split == "train"),
        collate_fn=collate_sequence_batch,
    )


def build_optimizer_and_scheduler(model: torch.nn.Module, cfg: DictConfig):
    opt_cfg = cfg.training.optimizer
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=float(opt_cfg.lr),
        betas=tuple(float(x) for x in opt_cfg.get("betas", [0.9, 0.95])),
        weight_decay=float(opt_cfg.get("weight_decay", 0.01)),
    )
    sched_cfg = cfg.training.scheduler
    warmup_steps = int(sched_cfg.get("warmup_steps", 2000))
    decay_end_steps = int(sched_cfg.get("decay_end_steps", 100000))
    base_lr = float(sched_cfg.get("base_lr", opt_cfg.lr))
    final_lr = float(sched_cfg.get("final_lr", base_lr * 0.1))
    final_ratio = final_lr / base_lr if base_lr > 0 else 1.0
    decay_end_steps = max(decay_end_steps, warmup_steps + 1)

    def lr_lambda(step: int) -> float:
        if warmup_steps > 0 and step < warmup_steps:
            return float(step + 1) / float(warmup_steps)
        if step >= decay_end_steps:
            return final_ratio
        progress = (step - warmup_steps) / max(decay_end_steps - warmup_steps, 1)
        return final_ratio + (1.0 - final_ratio) * 0.5 * (1.0 + np.cos(np.pi * progress))

    return optimizer, torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lr_lambda)


@torch.no_grad()
def update_ema(ema_model: torch.nn.Module | None, model: torch.nn.Module, decay: float) -> None:
    if ema_model is None:
        return
    ema_params = dict(ema_model.named_parameters())
    for name, param in model.named_parameters():
        if name in ema_params:
            ema_params[name].mul_(decay).add_(param.data, alpha=1.0 - decay)


def create_ema(model: torch.nn.Module, enabled: bool) -> torch.nn.Module | None:
    if not enabled:
        return None
    ema = deepcopy(model).eval()
    ema.requires_grad_(False)
    return ema


def append_csv(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def save_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def save_checkpoint(
    path: Path,
    step: int,
    epoch: int,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer | None,
    scheduler: Any,
    cfg: DictConfig,
    ema_model: torch.nn.Module | None = None,
    best_metric: float | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {
        "stage": "stage2-rollout",
        "step": int(step),
        "epoch": int(epoch),
        "model": model.state_dict(),
        "ema_model": ema_model.state_dict() if ema_model is not None else None,
        "optimizer": optimizer.state_dict() if optimizer is not None else None,
        "scheduler": scheduler.state_dict() if scheduler is not None else None,
        "best_metric": best_metric,
        "config": OmegaConf.to_container(cfg, resolve=True),
    }
    torch.save(state, path)


def load_model_state(path: str | Path, model: torch.nn.Module, prefer_ema: bool = True) -> dict[str, Any]:
    ckpt = torch.load(path, map_location="cpu")
    state = ckpt
    if isinstance(ckpt, dict):
        if prefer_ema and ckpt.get("ema_model") is not None:
            state = ckpt["ema_model"]
        elif "model" in ckpt:
            state = ckpt["model"]
    model.load_state_dict(state, strict=True)
    return ckpt if isinstance(ckpt, dict) else {"step": -1}
