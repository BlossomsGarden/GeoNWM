from __future__ import annotations

import itertools

import torch
import torch.nn.functional as F

from .model import RolloutOutput
from .transport import downsample_points_to_patches, normalized_flow_to_pixel, patch_centers_pixel, sample_patch_map


def feature_reconstruction_loss(
    pred: dict[int, torch.Tensor],
    target: dict[int, torch.Tensor],
    feature_indices: list[int] | tuple[int, ...],
) -> torch.Tensor:
    losses = []
    for idx in feature_indices:
        losses.append(F.mse_loss(pred[int(idx)].float(), target[int(idx)].float()))
    return torch.stack(losses).mean()


def sparse_transport_loss(output: RolloutOutput, sparse_weight: float = 1e-4) -> torch.Tensor:
    valid = (output.ego_valid_mask & output.valid_mask)[..., None].float()
    flow_l1 = (output.flow_res.abs() * valid).sum() / valid.sum().clamp_min(1.0)
    source_l1 = (output.source.abs() * valid).sum() / (valid.sum() * output.source.shape[-1]).clamp_min(1.0)
    return float(sparse_weight) * (flow_l1 + source_l1)


def forward_loss(
    output: RolloutOutput,
    target: dict[int, torch.Tensor],
    feature_indices: list[int] | tuple[int, ...],
    sparse_weight: float = 1e-4,
) -> dict[str, torch.Tensor]:
    recon = feature_reconstruction_loss(output.pred, target, feature_indices)
    sparse = sparse_transport_loss(output, sparse_weight)
    return {
        "loss/forward": recon + sparse,
        "loss/recon": recon,
        "loss/sparse": sparse,
    }


def _project_points(points_ego_first: torch.Tensor, ego_first_to_cam: torch.Tensor, intrinsics: torch.Tensor):
    b, views, patches, _ = points_ego_first.shape
    ones = torch.ones((b, views, patches, 1), device=points_ego_first.device, dtype=points_ego_first.dtype)
    pts_h = torch.cat([points_ego_first, ones], dim=-1)
    cam = torch.einsum("bvij,bvpj->bvpi", ego_first_to_cam, pts_h)[..., :3]
    pix_h = torch.einsum("bvij,bvpj->bvpi", intrinsics, cam)
    z = cam[..., 2].clamp_min(1e-6)
    uv = pix_h[..., :2] / z[..., None]
    return uv, cam[..., 2]


def _fundamental_from_cameras(k_i: torch.Tensor, t_i: torch.Tensor, k_j: torch.Tensor, t_j: torch.Tensor) -> torch.Tensor:
    cam_i_to_ego = torch.linalg.inv(t_i)
    t_j_i = t_j @ cam_i_to_ego
    r = t_j_i[:3, :3]
    trans = t_j_i[:3, 3]
    tx = torch.zeros((3, 3), device=k_i.device, dtype=k_i.dtype)
    tx[0, 1] = -trans[2]
    tx[0, 2] = trans[1]
    tx[1, 0] = trans[2]
    tx[1, 2] = -trans[0]
    tx[2, 0] = -trans[1]
    tx[2, 1] = trans[0]
    return torch.linalg.inv(k_j).transpose(-1, -2) @ tx @ r @ torch.linalg.inv(k_i)


def _sampson_distance(f_mat: torch.Tensor, x_i: torch.Tensor, x_j: torch.Tensor) -> torch.Tensor:
    ones = torch.ones_like(x_i[..., :1])
    xi = torch.cat([x_i, ones], dim=-1)
    xj = torch.cat([x_j, ones], dim=-1)
    f_xi = torch.einsum("ij,pj->pi", f_mat, xi)
    ft_xj = torch.einsum("ji,pj->pi", f_mat, xj)
    xj_f_xi = (xj * f_xi).sum(dim=-1)
    denom = f_xi[:, 0].pow(2) + f_xi[:, 1].pow(2) + ft_xj[:, 0].pow(2) + ft_xj[:, 1].pow(2)
    return xj_f_xi.pow(2) / denom.clamp_min(1e-6)


def l3d_flow_loss(
    output: RolloutOutput,
    points_ego_first: torch.Tensor,
    intrinsics: torch.Tensor,
    ego_first_to_cam: torch.Tensor,
    image_size: tuple[int, int],
    max_pairs: int = 6,
) -> dict[str, torch.Tensor]:
    """Cross-view geometric consistency for predicted flow endpoints.

    Args:
        output: one-step model output.
        points_ego_first: B,V,H,W,3 current-frame DVGT point map.
        intrinsics: B,V,3,3.
        ego_first_to_cam: B,V,4,4.
    """
    b, layers, views, patches = output.flow_res.shape[:4]
    hp, wp = output.patch_hw
    height, width = image_size
    flow = output.total_flow.mean(dim=1)
    flow_pix_patch = normalized_flow_to_pixel(flow, output.patch_hw)
    centers = patch_centers_pixel(output.patch_hw, flow.device, flow.dtype)
    centers = centers.reshape(1, 1, patches, 2).expand(b, views, -1, -1)
    endpoint_patch = centers + flow_pix_patch
    endpoint_image = endpoint_patch.clone()
    endpoint_image[..., 0] = endpoint_image[..., 0] * (float(width) / float(wp))
    endpoint_image[..., 1] = endpoint_image[..., 1] * (float(height) / float(hp))

    patch_points = downsample_points_to_patches(points_ego_first.float(), output.patch_hw)
    proj_uv, proj_z = _project_points(patch_points, ego_first_to_cam.float(), intrinsics.float())
    proj_patch = proj_uv.clone()
    proj_patch[..., 0] = proj_patch[..., 0] / (float(width) / float(wp))
    proj_patch[..., 1] = proj_patch[..., 1] / (float(height) / float(hp))
    sampled_flow = sample_patch_map(flow, proj_patch, output.patch_hw)
    sampled_endpoint = proj_patch + normalized_flow_to_pixel(sampled_flow, output.patch_hw)
    sampled_endpoint_image = sampled_endpoint.clone()
    sampled_endpoint_image[..., 0] = sampled_endpoint_image[..., 0] * (float(width) / float(wp))
    sampled_endpoint_image[..., 1] = sampled_endpoint_image[..., 1] * (float(height) / float(hp))
    endpoint_points = sample_patch_map(patch_points, endpoint_patch, output.patch_hw)
    sampled_endpoint_points = sample_patch_map(patch_points, sampled_endpoint, output.patch_hw)

    pairs = list(itertools.combinations(range(views), 2))[:max_pairs]
    sampson_terms = []
    point_terms = []
    for i, j in pairs:
        valid_i_to_j = (
            (proj_z[:, i] > 0.05)
            & (proj_patch[:, i, :, 0] >= 0)
            & (proj_patch[:, i, :, 0] <= wp - 1)
            & (proj_patch[:, i, :, 1] >= 0)
            & (proj_patch[:, i, :, 1] <= hp - 1)
        )
        valid_j_to_i = (
            (proj_z[:, j] > 0.05)
            & (proj_patch[:, j, :, 0] >= 0)
            & (proj_patch[:, j, :, 0] <= wp - 1)
            & (proj_patch[:, j, :, 1] >= 0)
            & (proj_patch[:, j, :, 1] <= hp - 1)
        )
        for batch_idx in range(b):
            mask = valid_i_to_j[batch_idx] & valid_j_to_i[batch_idx]
            if mask.sum() < 8:
                continue
            f_mat = _fundamental_from_cameras(
                intrinsics[batch_idx, i].float(),
                ego_first_to_cam[batch_idx, i].float(),
                intrinsics[batch_idx, j].float(),
                ego_first_to_cam[batch_idx, j].float(),
            )
            d = _sampson_distance(
                f_mat,
                endpoint_image[batch_idx, i, mask].float(),
                sampled_endpoint_image[batch_idx, j, mask].float(),
            )
            sampson_terms.append(d.clamp_max(100.0).mean())
            p_i = endpoint_points[batch_idx, i, mask]
            p_j = sampled_endpoint_points[batch_idx, j, mask]
            point_terms.append((p_i - p_j).abs().mean())

    zero = output.flow_res.new_zeros(())
    sampson = torch.stack(sampson_terms).mean() if sampson_terms else zero
    endpoint = torch.stack(point_terms).mean() if point_terms else zero
    return {
        "loss/l3d_flow": sampson + endpoint,
        "loss/l3d_sampson": sampson,
        "loss/l3d_endpoint": endpoint,
    }
