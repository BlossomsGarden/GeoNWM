from __future__ import annotations

import math
from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F

from .transport import transport_patch_tokens


class LayerScale(nn.Module):
    def __init__(self, dim: int, init: float = 0.01):
        super().__init__()
        self.gamma = nn.Parameter(torch.ones(dim) * float(init))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.gamma


class QKNormAttention(nn.Module):
    def __init__(self, dim: int, heads: int, dropout: float = 0.0):
        super().__init__()
        if dim % heads != 0:
            raise ValueError(f"dim={dim} must be divisible by heads={heads}")
        self.heads = int(heads)
        self.head_dim = dim // heads
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)
        self.q_norm = nn.LayerNorm(self.head_dim)
        self.k_norm = nn.LayerNorm(self.head_dim)
        self.dropout = float(dropout)

    def forward(self, q: torch.Tensor, kv: torch.Tensor | None = None) -> torch.Tensor:
        if kv is None:
            kv = q
        b, nq, c = q.shape
        nk = kv.shape[1]
        qh = self.q_proj(q).reshape(b, nq, self.heads, self.head_dim).transpose(1, 2)
        kh = self.k_proj(kv).reshape(b, nk, self.heads, self.head_dim).transpose(1, 2)
        vh = self.v_proj(kv).reshape(b, nk, self.heads, self.head_dim).transpose(1, 2)
        qh = self.q_norm(qh)
        kh = self.k_norm(kh)
        out = F.scaled_dot_product_attention(
            qh,
            kh,
            vh,
            dropout_p=self.dropout if self.training else 0.0,
        )
        out = out.transpose(1, 2).reshape(b, nq, c)
        return self.out_proj(out)


class AttentionBlock(nn.Module):
    def __init__(self, dim: int, heads: int, mlp_ratio: float = 4.0, dropout: float = 0.0, layer_scale: float = 0.01):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = QKNormAttention(dim, heads, dropout)
        self.ls1 = LayerScale(dim, layer_scale)
        self.norm2 = nn.LayerNorm(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
        )
        self.ls2 = LayerScale(dim, layer_scale)

    def forward(self, x: torch.Tensor, kv: torch.Tensor | None = None) -> torch.Tensor:
        x = x + self.ls1(self.attn(self.norm1(x), self.norm1(kv) if kv is not None else None))
        x = x + self.ls2(self.mlp(self.norm2(x)))
        return x


class TrajectoryEncoder(nn.Module):
    def __init__(self, in_dim: int = 4, hidden_dim: int = 256, out_dim: int = 512):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, trajectory: torch.Tensor, step_index: int = 0) -> torch.Tensor:
        if trajectory.ndim != 3:
            raise ValueError(f"trajectory must be B,F,4, got {tuple(trajectory.shape)}")
        step = min(int(step_index), trajectory.shape[1] - 1)
        return self.net(trajectory[:, step])


@dataclass
class RolloutOutput:
    pred: dict[int, torch.Tensor]
    total_flow: torch.Tensor
    ego_flow: torch.Tensor
    flow_res: torch.Tensor
    source: torch.Tensor
    ego_valid_mask: torch.Tensor
    valid_mask: torch.Tensor
    sample_grid: torch.Tensor
    patch_hw: tuple[int, int]


class Stage2RolloutModel(nn.Module):
    """Trajectory-conditioned one-step feature transport model."""

    def __init__(
        self,
        feature_indices: list[int] | tuple[int, ...] = (4, 11, 17, 23),
        token_dim: int = 3072,
        model_dim: int = 512,
        num_heads: int = 8,
        num_egcva_blocks: int = 2,
        num_temporal_blocks: int = 2,
        max_views: int = 8,
        max_history: int = 16,
        patch_size: int = 16,
        max_flow_norm: float = 0.35,
        source_scale: float = 0.1,
        layer_scale_init: float = 0.01,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.feature_indices = [int(x) for x in feature_indices]
        self.token_dim = int(token_dim)
        self.model_dim = int(model_dim)
        self.patch_size = int(patch_size)
        self.max_flow_norm = float(max_flow_norm)
        self.source_scale = float(source_scale)
        self.input_proj = nn.Linear(token_dim, model_dim)
        self.layer_embed = nn.Embedding(len(self.feature_indices), model_dim)
        self.view_embed = nn.Embedding(max_views, model_dim)
        self.time_embed = nn.Embedding(max_history + 8, model_dim)
        self.trajectory_encoder = TrajectoryEncoder(out_dim=model_dim)
        self.egcva_blocks = nn.ModuleList(
            [AttentionBlock(model_dim, num_heads, dropout=dropout, layer_scale=layer_scale_init) for _ in range(num_egcva_blocks)]
        )
        self.temporal_blocks = nn.ModuleList(
            [AttentionBlock(model_dim, num_heads, dropout=dropout, layer_scale=layer_scale_init) for _ in range(num_temporal_blocks)]
        )
        self.fused_norm = nn.LayerNorm(model_dim)
        self.flow_head = nn.Linear(model_dim, 2)
        self.source_head = nn.Linear(model_dim, token_dim)
        self.special_head = nn.Linear(model_dim, token_dim)
        nn.init.zeros_(self.flow_head.weight)
        nn.init.zeros_(self.flow_head.bias)
        nn.init.zeros_(self.source_head.weight)
        nn.init.zeros_(self.source_head.bias)
        nn.init.zeros_(self.special_head.weight)
        nn.init.zeros_(self.special_head.bias)

    def _patch_hw(self, image_size: tuple[int, int]) -> tuple[int, int]:
        height, width = int(image_size[0]), int(image_size[1])
        return height // self.patch_size, width // self.patch_size

    def _stack_selected(self, selected: dict[int, torch.Tensor], patch_start_idx: int):
        layers = []
        special = []
        for idx in self.feature_indices:
            tokens = selected[idx]
            layers.append(tokens[..., patch_start_idx:, :])
            special.append(tokens[..., :patch_start_idx, :])
        return torch.stack(layers, dim=1), torch.stack(special, dim=1)

    def _encode_patches(self, patches: torch.Tensor) -> torch.Tensor:
        return self.input_proj(F.layer_norm(patches, (patches.shape[-1],)))

    def forward_one_step(
        self,
        history: dict[int, torch.Tensor],
        patch_start_idx: int,
        image_size: tuple[int, int],
        trajectory: torch.Tensor,
        step_index: int = 0,
        ego_flow_norm: torch.Tensor | None = None,
        ego_valid_mask: torch.Tensor | None = None,
    ) -> RolloutOutput:
        patch_hw = self._patch_hw(image_size)
        patch_stack, special_stack = self._stack_selected(history, patch_start_idx)
        b, layers, hist, views, patches, channels = patch_stack.shape
        if patches != patch_hw[0] * patch_hw[1]:
            raise ValueError(f"patch count {patches} does not match image_size={image_size}")

        current_patch = patch_stack[:, :, -1]
        current_special = special_stack[:, :, -1]
        current_h = self._encode_patches(current_patch)
        cache_h = self._encode_patches(patch_stack)

        layer_ids = torch.arange(layers, device=current_h.device)
        view_ids = torch.arange(views, device=current_h.device)
        time_ids = torch.arange(hist, device=current_h.device)
        current_h = current_h + self.layer_embed(layer_ids)[None, :, None, None, :]
        current_h = current_h + self.view_embed(view_ids)[None, None, :, None, :]
        cache_h = cache_h + self.layer_embed(layer_ids)[None, :, None, None, None, :]
        cache_h = cache_h + self.view_embed(view_ids)[None, None, None, :, None, :]
        cache_h = cache_h + self.time_embed(time_ids)[None, None, :, None, None, :]
        traj = self.trajectory_encoder(trajectory.to(current_h.device, current_h.dtype), step_index)
        current_h = current_h + traj[:, None, None, None, :]

        x = current_h.reshape(b * layers, views * patches, self.model_dim)
        for block in self.egcva_blocks:
            x = block(x)
        x = x.reshape(b, layers, views, patches, self.model_dim)

        q = x.reshape(b * layers * views, patches, self.model_dim)
        kv = cache_h.permute(0, 1, 3, 2, 4, 5).reshape(b * layers * views, hist * patches, self.model_dim)
        for block in self.temporal_blocks:
            q = block(q, kv=kv)
        fused = self.fused_norm(q.reshape(b, layers, views, patches, self.model_dim))

        flow_res = torch.tanh(self.flow_head(fused)) * self.max_flow_norm
        if ego_flow_norm is None:
            ego_flow = torch.zeros_like(flow_res)
        else:
            ego_flow = ego_flow_norm.to(flow_res.device, flow_res.dtype)[:, None].expand_as(flow_res)
        total_flow = ego_flow + flow_res
        source = self.source_head(fused) * self.source_scale
        transported, valid_mask, sample_grid = transport_patch_tokens(current_patch, total_flow, patch_hw)
        if ego_valid_mask is None:
            ego_valid = torch.ones_like(valid_mask)
        else:
            ego_valid = ego_valid_mask.to(valid_mask.device).bool()[:, None].expand_as(valid_mask)
        pred_patch = transported + source

        special_context = fused.mean(dim=3)
        special_delta = self.special_head(special_context)[:, :, :, None, :].expand_as(current_special) * self.source_scale
        pred_special = current_special + special_delta

        pred: dict[int, torch.Tensor] = {}
        for layer_pos, idx in enumerate(self.feature_indices):
            full = torch.cat([pred_special[:, layer_pos], pred_patch[:, layer_pos]], dim=2)
            pred[idx] = full[:, None].contiguous()
        return RolloutOutput(pred, total_flow, ego_flow, flow_res, source, ego_valid, valid_mask, sample_grid, patch_hw)

    def rollout(
        self,
        history: dict[int, torch.Tensor],
        patch_start_idx: int,
        image_size: tuple[int, int],
        trajectory: torch.Tensor,
        steps: int,
    ) -> list[RolloutOutput]:
        outputs = []
        cache = {idx: value for idx, value in history.items()}
        for step in range(int(steps)):
            out = self.forward_one_step(cache, patch_start_idx, image_size, trajectory, step)
            outputs.append(out)
            cache = {
                idx: torch.cat([cache[idx][:, 1:].detach(), out.pred[idx]], dim=1)
                for idx in self.feature_indices
            }
        return outputs
