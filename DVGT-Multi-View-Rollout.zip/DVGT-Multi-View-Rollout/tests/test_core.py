from __future__ import annotations

import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dvgt_rollout.losses import forward_loss, l3d_flow_loss
from dvgt_rollout.model import Stage2RolloutModel
from dvgt_rollout.transport import transport_patch_tokens


def test_transport_identity():
    tokens = torch.randn(2, 4, 3, 16, 8)
    flow = torch.zeros(2, 4, 3, 16, 2)
    warped, valid, _ = transport_patch_tokens(tokens, flow, (4, 4))
    assert torch.allclose(warped, tokens, atol=1e-5)
    assert valid.all()


def test_rollout_shape_and_forward_loss():
    model = Stage2RolloutModel(token_dim=32, model_dim=32, num_heads=4, num_egcva_blocks=1, num_temporal_blocks=1)
    history = {idx: torch.randn(1, 2, 6, 7, 32) for idx in [4, 11, 17, 23]}
    out = model.forward_one_step(history, patch_start_idx=3, image_size=(32, 32), trajectory=torch.zeros(1, 1, 4))
    assert set(out.pred) == {4, 11, 17, 23}
    assert out.pred[4].shape == (1, 1, 6, 7, 32)
    target = {idx: torch.randn(1, 1, 6, 7, 32) for idx in [4, 11, 17, 23]}
    losses = forward_loss(out, target, [4, 11, 17, 23])
    assert losses["loss/forward"].isfinite()
    assert losses["loss/recon"].isfinite()
    assert losses["loss/sparse"].isfinite()


def test_l3d_flow_finite():
    model = Stage2RolloutModel(token_dim=32, model_dim=32, num_heads=4, num_egcva_blocks=1, num_temporal_blocks=1)
    history = {idx: torch.randn(1, 2, 6, 7, 32) for idx in [4, 11, 17, 23]}
    out = model.forward_one_step(history, patch_start_idx=3, image_size=(32, 32), trajectory=torch.zeros(1, 1, 4))
    points = torch.randn(1, 6, 32, 32, 3)
    points[..., 2] = points[..., 2].abs() + 2.0
    intr = torch.eye(3).view(1, 1, 3, 3).repeat(1, 6, 1, 1)
    intr[..., 0, 0] = 20.0
    intr[..., 1, 1] = 20.0
    intr[..., 0, 2] = 16.0
    intr[..., 1, 2] = 16.0
    pose = torch.eye(4).view(1, 1, 4, 4).repeat(1, 6, 1, 1)
    losses = l3d_flow_loss(out, points, intr, pose, (32, 32))
    assert losses["loss/l3d_flow"].isfinite()
