import io
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image

from so101_real import EXAMPLE_STATE, PROMPT
from so101_real.config import Config, HardwareConfig, SafetyConfig, ServerConfig, load_config
from so101_real.observations import Observation, SavedSource, SyntheticSource, save_observation
from so101_real.protocol import JPEG_KEYS
from third_party.openpi_client import msgpack_numpy


class ConfigurationTests(unittest.TestCase):
    def test_example_config(self):
        config = load_config(Path(__file__).resolve().parents[1] / "config.example.json")
        self.assertFalse(config.hardware.use_degrees)
        self.assertEqual(config.execute_horizon, 5)

    def test_invalid_config(self):
        cases = [lambda: Config(control_hz=0), lambda: Config(control_hz=31),
                 lambda: Config(execute_horizon=51), lambda: Config(jpeg_quality=True),
                 lambda: Config(prompt=""), lambda: HardwareConfig(use_degrees=True),
                 lambda: SafetyConfig(step_limits=[1]*5), lambda: SafetyConfig(step_limits=[1]*5+[float("nan")]),
                 lambda: SafetyConfig(lower=[-101]*6), lambda: ServerConfig(url="http://localhost:1"),
                 lambda: ServerConfig(url="ws://user:password@localhost:1"),
                 lambda: ServerConfig(request_timeout_s=-1)]
        for make in cases:
            with self.subTest(make=make), self.assertRaises(ValueError):
                make()

    def test_unknown_settings_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            path.write_text('{"safty":{}}')
            with self.assertRaises(ValueError):
                load_config(path)

    def test_relative_calibration_path(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            path.write_text('{"hardware":{"calibration_file":"cal/arm.json"}}')
            self.assertEqual(load_config(path).hardware.calibration_file,
                             str((Path(directory) / "cal/arm.json").resolve()))


class ObservationTests(unittest.TestCase):
    def test_rgb_jpeg_resize_and_msgpack_roundtrip(self):
        wire = SyntheticSource().observe().wire(PROMPT)
        decoded = msgpack_numpy.unpackb(msgpack_numpy.packb(wire))
        np.testing.assert_array_equal(decoded["observation/state"], np.asarray(EXAMPLE_STATE, dtype=np.float32))
        self.assertEqual(decoded["prompt"], PROMPT)
        for key in JPEG_KEYS:
            with Image.open(io.BytesIO(decoded[key])) as image:
                self.assertEqual(image.size, (224, 224))
                self.assertEqual(image.mode, "RGB")

    def test_invalid_images_and_states(self):
        observation = SyntheticSource().observe()
        for image in (np.zeros((20, 20), dtype=np.uint8), np.zeros((20, 20, 3)),
                      np.zeros((0, 20, 3), dtype=np.uint8)):
            with self.subTest(shape=image.shape), self.assertRaises(ValueError):
                Observation(observation.state, image, observation.side, observation.captured_at)
        for state in ([0]*5, [0]*5+[float("nan")]):
            with self.assertRaises(ValueError):
                SyntheticSource(state)

    def test_codec_rejects_object_array(self):
        with self.assertRaises(ValueError):
            msgpack_numpy.packb({"unsafe": np.array([object()], dtype=object)})

    def test_capture_replay_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "capture"
            original = SyntheticSource().observe()
            save_observation(original, path)
            source = SavedSource(path)
            source.connect()
            replay = source.observe()
            np.testing.assert_array_equal(replay.state, original.state)
            np.testing.assert_array_equal(replay.front, original.front)
            with self.assertRaises(FileExistsError):
                save_observation(original, path)

    def test_replay_rejects_unknown_units_and_path_escape(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "capture"
            save_observation(SyntheticSource().observe(), path)
            metadata_path = path / "state.json"
            data = json.loads(metadata_path.read_text())
            data["units"] = "degrees"
            metadata_path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                SavedSource(path).connect()
            data["units"] = "lerobot_range_m100_100_gripper_0_100"
            data["front"] = "../outside.png"
            metadata_path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                SavedSource(path).connect()


if __name__ == "__main__":
    unittest.main()
