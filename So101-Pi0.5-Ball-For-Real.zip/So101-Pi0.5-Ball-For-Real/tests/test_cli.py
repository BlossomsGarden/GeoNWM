import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from so101_real.mock_server import MockServer

ROOT = Path(__file__).resolve().parents[1]


class CliTests(unittest.TestCase):
    def run_cli(self, *arguments):
        return subprocess.run([sys.executable, "-m", "so101_real", *map(str, arguments)],
                              cwd=ROOT, text=True, capture_output=True, timeout=15, encoding="utf-8")

    def test_probe_and_simulated_closed_loop(self):
        with MockServer() as server, tempfile.TemporaryDirectory() as directory:
            url = f"ws://127.0.0.1:{server.port}"
            probe = self.run_cli("--url", url, "probe")
            self.assertEqual(probe.returncode, 0, probe.stderr)
            self.assertTrue(json.loads(probe.stdout)["mock"])
            report_path = Path(directory) / "report.json"
            run = self.run_cli("--url", url, "run", "--simulate-execution", "--chunks", 2,
                               "--max-steps", 8, "--output", report_path)
            self.assertEqual(run.returncode, 0, run.stderr)
            report = json.loads(report_path.read_text())
            self.assertEqual(report["execution"], "simulated")
            self.assertEqual(len(report["commands"]), 8)
            self.assertEqual(len(report["chunks"]), 2)

    def test_capture_then_replay(self):
        with MockServer() as server, tempfile.TemporaryDirectory() as directory:
            capture = Path(directory) / "capture"
            result = self.run_cli("capture", "--output", capture)
            self.assertEqual(result.returncode, 0, result.stderr)
            report = Path(directory) / "report.json"
            result = self.run_cli("--url", f"ws://127.0.0.1:{server.port}", "run", "--source", "saved",
                                  "--capture-dir", capture, "--output", report)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(report.read_text())["execution"], "none")

    def test_import_cli_does_not_import_lerobot(self):
        code = "import sys; import so101_real.cli; assert 'lerobot' not in sys.modules"
        result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_execute_cannot_use_synthetic_source(self):
        result = self.run_cli("run", "--execute")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("requires --source hardware", result.stderr)


if __name__ == "__main__":
    unittest.main()
