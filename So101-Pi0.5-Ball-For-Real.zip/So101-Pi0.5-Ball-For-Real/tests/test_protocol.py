from dataclasses import replace
import socket
import time
import unittest

import numpy as np

from so101_real import PROMPT
from so101_real.config import ServerConfig
from so101_real.mock_server import MockServer
from so101_real.observations import SyntheticSource
from so101_real.protocol import PolicyClient, validate_actions


class ProtocolTests(unittest.TestCase):
    def settings(self, server, **kwargs):
        return ServerConfig(url=f"ws://127.0.0.1:{server.port}", **kwargs)

    def test_metadata_and_real_wire_roundtrip(self):
        with MockServer() as server, PolicyClient(self.settings(server)) as client:
            self.assertTrue(client.metadata["mock"])
            observation = SyntheticSource().observe()
            result, latency = client.infer(observation.wire(PROMPT))
            self.assertEqual(result["actions"].shape, (50, 6))
            np.testing.assert_array_equal(result["actions"][0, 1:], observation.state[1:])
            self.assertGreater(latency, 0)

    def test_invalid_metadata(self):
        with MockServer(bad_metadata=True) as server:
            client = PolicyClient(self.settings(server))
            with self.assertRaises(ValueError):
                client.__enter__()
            self.assertIsNone(client.connection)

    def test_wrong_response_shape_closes_connection(self):
        with MockServer(bad_shape=True) as server, PolicyClient(self.settings(server)) as client:
            with self.assertRaises(ValueError):
                client.infer(SyntheticSource().observe().wire(PROMPT))
            self.assertIsNone(client.connection)

    def test_timeout_is_bounded_and_connection_is_not_reused(self):
        with MockServer(delay=0.3) as server, PolicyClient(self.settings(server, request_timeout_s=0.05)) as client:
            started = time.perf_counter()
            with self.assertRaises(TimeoutError):
                client.infer(SyntheticSource().observe().wire(PROMPT))
            self.assertLess(time.perf_counter() - started, 2)
            self.assertIsNone(client.connection)
            with self.assertRaises(RuntimeError):
                client.infer(SyntheticSource().observe().wire(PROMPT))

    def test_server_error_and_disconnect(self):
        for option in ("text_error", "disconnect"):
            with self.subTest(option=option), MockServer(**{option: True}) as server:
                with PolicyClient(self.settings(server)) as client:
                    with self.assertRaises(Exception):
                        client.infer(SyntheticSource().observe().wire(PROMPT))
                    self.assertIsNone(client.connection)

    def test_connection_refusal_does_not_retry_forever(self):
        with socket.socket() as reserved:
            reserved.bind(("127.0.0.1", 0))
            port = reserved.getsockname()[1]
        started = time.perf_counter()
        with self.assertRaises(OSError):
            with PolicyClient(ServerConfig(url=f"ws://127.0.0.1:{port}", connect_timeout_s=0.2)):
                pass
        self.assertLess(time.perf_counter() - started, 3)

    def test_nan_and_wrong_horizon_rejected(self):
        for actions in (np.zeros((6,)), np.zeros((10, 6)), np.full((50, 6), np.nan)):
            with self.subTest(shape=actions.shape), self.assertRaises(ValueError):
                validate_actions(actions)

    def test_incomplete_observation_is_not_sent(self):
        with MockServer() as server, PolicyClient(self.settings(server)) as client:
            wire = SyntheticSource().observe().wire(PROMPT)
            del wire["transport/side_image_jpeg"]
            with self.assertRaises(ValueError):
                client.infer(wire)


if __name__ == "__main__":
    unittest.main()
