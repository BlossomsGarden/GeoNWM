import json
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock

import numpy as np

from so101_real import JOINTS
from so101_real.config import Config, HardwareConfig, SafetyConfig
from so101_real.control import SafetyError, SafetyGuard, run_session, wait_for_settle
from so101_real.hardware import HardwareSource, make_robot, validate_calibration
from so101_real.mock_server import metadata
from so101_real.observations import SyntheticSource


class FakePolicy:
    metadata = metadata()

    def __init__(self, transform=None):
        self.transform = transform

    def infer(self, wire):
        actions = np.repeat(wire["observation/state"][None, :], 50, axis=0)
        actions[:, 0] += 5
        if self.transform:
            self.transform(actions)
        return {"actions": actions}, 0.01


class ControlTests(unittest.TestCase):
    def test_dry_run_never_sends(self):
        source = SyntheticSource()
        source.send_action = Mock(side_effect=AssertionError("must not move"))
        report = run_session(source, FakePolicy(), Config(), chunks=2)
        self.assertEqual(report["execution"], "none")
        self.assertEqual(len(report["chunks"]), 2)
        source.send_action.assert_not_called()

    def test_first_command_rate_limit_and_closed_loop_reobservation(self):
        source = SyntheticSource()
        initial = source.state.copy()
        config = Config(execute_horizon=2)
        report = run_session(source, FakePolicy(), config, chunks=2, max_steps=4, simulate=True)
        self.assertEqual(len(report["commands"]), 4)
        self.assertAlmostEqual(report["commands"][0]["sent"][0], initial[0] + 1, places=4)
        self.assertAlmostEqual(report["chunks"][1]["state"][0], initial[0] + 2, places=4)

    def test_absolute_actions_are_not_rebased(self):
        source = SyntheticSource()
        initial = source.state.copy()
        config = Config(safety=SafetyConfig(step_limits=[10]*6), execute_horizon=1)
        report = run_session(source, FakePolicy(), config, simulate=True)
        self.assertAlmostEqual(report["commands"][0]["sent"][0], initial[0] + 5, places=4)

    def test_expired_model_response_cannot_move(self):
        source = SyntheticSource()
        source.send_action = Mock()
        policy = FakePolicy(lambda _: time.sleep(0.03))
        config = Config(safety=SafetyConfig(max_observation_age_s=0.01))
        with self.assertRaises(SafetyError):
            run_session(source, policy, config, simulate=True)
        source.send_action.assert_not_called()

    def test_drift_while_inference_is_rejected(self):
        source = SyntheticSource()
        source.send_action = Mock()
        policy = FakePolicy(lambda _: source.state.__setitem__(0, source.state[0]+20))
        with self.assertRaises(SafetyError):
            run_session(source, policy, Config(), simulate=True)
        source.send_action.assert_not_called()

    def test_tracking_error_and_bad_target_rejected(self):
        guard = SafetyGuard(SafetyConfig())
        with self.assertRaises(SafetyError):
            guard.target([30]*6, [30]*6, [0]*6)
        with self.assertRaises(SafetyError):
            guard.target([101]*6, [0]*6, [0]*6)

    def test_stop_during_inference_sends_nothing(self):
        stop = threading.Event()
        source = SyntheticSource()
        source.send_action = Mock()
        report = run_session(source, FakePolicy(lambda _: stop.set()), Config(), simulate=True, stop=stop)
        self.assertEqual(report["status"], "stopped")
        source.send_action.assert_not_called()

    def test_failure_writes_report_and_no_queued_actions_continue(self):
        source = SyntheticSource()
        source.send_action = Mock(side_effect=OSError("serial disconnected"))
        with tempfile.TemporaryDirectory() as directory:
            report_path = Path(directory) / "run.json"
            with self.assertRaises(OSError):
                run_session(source, FakePolicy(), Config(), simulate=True, output=report_path)
            report = json.loads(report_path.read_text())
            self.assertEqual(report["status"], "error")
            self.assertEqual(report["commands"], [])
            self.assertEqual(source.send_action.call_count, 1)

    def test_mock_cannot_control_hardware(self):
        source = SyntheticSource()
        source.kind = "hardware"
        with self.assertRaises(ValueError):
            run_session(source, FakePolicy(), Config(), execute=True)

    def test_invalid_execution_combinations(self):
        with self.assertRaises(ValueError):
            run_session(SyntheticSource(), FakePolicy(), Config(), execute=True)
        with self.assertRaises(ValueError):
            run_session(SyntheticSource(), FakePolicy(), Config(), chunks=0)

    def test_stop_after_command_drops_remaining_chunk(self):
        stop = threading.Event()
        source = SyntheticSource()
        original = source.send_action

        def send(target):
            stop.set()
            return original(target)

        source.send_action = send
        report = run_session(source, FakePolicy(), Config(), simulate=True, stop=stop, max_steps=5)
        self.assertEqual(len(report["commands"]), 1)
        self.assertEqual(report["status"], "stopped")

    def test_settle_deadline_and_stop(self):
        source = SyntheticSource()
        source.read_state = Mock(side_effect=[np.full(6, value) for value in range(100)])
        with self.assertRaises(SafetyError):
            wait_for_settle(source, SafetyConfig(settle_timeout_s=0.08, settle_delta=0.1), threading.Event())
        stop = threading.Event()
        stop.set()
        with self.assertRaises(InterruptedError):
            wait_for_settle(SyntheticSource(), SafetyConfig(), stop)


def calibration_file(directory):
    path = Path(directory) / "arm.json"
    path.write_text(json.dumps({name: {"id": i, "drive_mode": 0, "homing_offset": 0,
                                     "range_min": 100, "range_max": 3900}
                                for i, name in enumerate(JOINTS, 1)}))
    return path


class HardwareTests(unittest.TestCase):
    def make(self, directory, execute=False):
        config = HardwareConfig(port="COM_TEST_NOT_OPENED", calibration_file=str(calibration_file(directory)))
        bus = Mock()
        bus.is_calibrated = True
        bus.is_connected = True
        bus.sync_read.side_effect = lambda register, **_: {name: 0 for name in JOINTS}
        cameras = {key: Mock(is_connected=True) for key in ("front", "side")}
        robot = SimpleNamespace(bus=bus, cameras=cameras, send_action=Mock())
        source = HardwareSource(config, execute=execute, factory=lambda _: robot)
        return source, robot

    def test_read_only_connect_and_disconnect_do_not_configure_or_write(self):
        with tempfile.TemporaryDirectory() as directory:
            source, robot = self.make(directory)
            source.connect()
            np.testing.assert_array_equal(source.read_state(), np.zeros(6))
            with self.assertRaises(RuntimeError):
                source.send_action(np.zeros(6))
            source.close()
            robot.bus.sync_write.assert_not_called()
            robot.bus.enable_torque.assert_not_called()
            robot.bus.disable_torque.assert_not_called()
            robot.bus.disconnect.assert_called_once_with(disable_torque=False)

    def test_calibration_mismatch_aborts_without_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            source, robot = self.make(directory)
            robot.bus.is_calibrated = False
            with self.assertRaises(ValueError):
                source.connect()
            robot.bus.sync_write.assert_not_called()
            robot.bus.disconnect.assert_called_once_with(disable_torque=False)

    def test_camera_failure_cleans_open_serial_and_cameras(self):
        with tempfile.TemporaryDirectory() as directory:
            source, robot = self.make(directory)
            robot.cameras["side"].connect.side_effect = OSError("camera unavailable")
            with self.assertRaises(OSError):
                source.connect()
            robot.cameras["front"].disconnect.assert_called_once()
            robot.bus.disconnect.assert_called_once_with(disable_torque=False)

    def test_explicit_execution_seeds_present_target_before_enabling(self):
        with tempfile.TemporaryDirectory() as directory:
            source, robot = self.make(directory, execute=True)
            source.connect()
            calls = [call[0] for call in robot.bus.method_calls]
            self.assertLess(calls.index("disable_torque"), calls.index("sync_write"))
            self.assertLess(calls.index("sync_write"), calls.index("enable_torque"))
            source.close()
            robot.bus.disconnect.assert_called_once_with(disable_torque=True)

    def test_partial_serial_open_failure_is_cleaned(self):
        with tempfile.TemporaryDirectory() as directory:
            source, robot = self.make(directory)
            robot.bus.connect.side_effect = OSError("handshake failed after open")
            with self.assertRaises(OSError):
                source.connect()
            robot.bus.disconnect.assert_called_once_with(disable_torque=False)

    def test_invalid_calibration_rejected_before_robot_factory(self):
        with tempfile.TemporaryDirectory() as directory:
            path = calibration_file(directory)
            path.write_text('{}')
            with self.assertRaises(ValueError):
                validate_calibration(path)

    def test_real_lerobot_construction_matches_training_without_opening_devices(self):
        try:
            import lerobot  # noqa: F401
        except ImportError:
            self.skipTest("Optional LeRobot hardware dependency is not installed")
        with tempfile.TemporaryDirectory() as directory:
            config = HardwareConfig(port="COM_TEST_NOT_OPENED", calibration_file=str(calibration_file(directory)))
            robot = make_robot(config)
            self.assertFalse(robot.bus.is_connected)
            self.assertFalse(robot.config.use_degrees)
            self.assertEqual(tuple(robot.bus.motors), JOINTS)
            self.assertEqual(robot.calibration_fpath.name, "arm.json")
            self.assertTrue(all(not camera.is_connected for camera in robot.cameras.values()))

    def test_invalid_camera_timestamp_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            source, robot = self.make(directory)
            source.connect()
            for camera in robot.cameras.values():
                camera.frame_lock = threading.Lock()
                camera.latest_frame = np.zeros((480, 640, 3), dtype=np.uint8)
                camera.latest_timestamp = time.perf_counter() - 1
            with self.assertRaises(TimeoutError):
                source.observe()
            source.close()

    def test_non_position_mode_cannot_enable_execution(self):
        with tempfile.TemporaryDirectory() as directory:
            source, robot = self.make(directory, execute=True)
            robot.bus.sync_read.side_effect = lambda *_, **__: {name: 1 for name in JOINTS}
            with self.assertRaises(ValueError):
                source.connect()
            robot.bus.enable_torque.assert_not_called()
            robot.bus.sync_write.assert_not_called()


if __name__ == "__main__":
    unittest.main()
