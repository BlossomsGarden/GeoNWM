@echo off
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set "CLIENT_PYTHON=%~dp0.venv\Scripts\python.exe"
if not exist "%CLIENT_PYTHON%" set "CLIENT_PYTHON=%~dp0..\sources\lelab-main\.venv\Scripts\python.exe"
if not exist "%CLIENT_PYTHON%" (
  echo Python environment not found. See README.md.
  exit /b 1
)
"%CLIENT_PYTHON%" -m so101_real %*
exit /b %errorlevel%
