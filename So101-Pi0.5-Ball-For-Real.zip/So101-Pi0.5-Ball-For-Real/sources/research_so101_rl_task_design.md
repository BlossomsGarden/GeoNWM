# SO101 RL task and integration notes

Date: 2026-10-22

These notes support a design discussion. No RL implementation or real-robot
validation was performed for this discussion.

## Task selection

- A task need not be impossible for supervised fine-tuning to justify an RL
  experiment. Measure reliability, recovery, time, and intervention cost under
  a defined evaluation distribution.
- Start the integration with a short pushing or grasp-and-lift task. A proposed
  main task is randomized two-block stacking with release, gripper withdrawal,
  and a stability condition. This proposal has not been validated on this arm.
- Use held-out layouts and repeatable, recoverable disturbances. Respect the
  SO101 workspace, degrees of freedom, backlash, and sensing limitations.
- Compare SFT, SFT plus corrective demonstrations, and SFT plus RL while
  reporting demonstration, robot-interaction, and human-intervention budgets.

## Data and system requirements

- Existing compatible demonstrations and an SFT checkpoint can be reused.
- Collect policy rollouts containing natural successes and failures. Deliberate
  unsafe failed demonstrations are unnecessary. Reward classifiers may need
  positive and negative states rather than complete failure demonstrations.
- Add reward, reset, termination/truncation, transition recording, policy
  versions, and learner-to-actor parameter updates. Keep reset movements out of
  autonomous rollout data.
- Ordinary PPO is on-policy. Old teleoperation data can support initialization
  or auxiliary imitation, but cannot simply replace current-policy rollouts.
- Preserve the sampled action, executed action, safety processing, human
  intervention, and actual next observation. PPO likelihoods must correspond
  to the chosen stochastic policy and action processing.
- If only K actions from a generated chunk are executed, the transition,
  accumulated reward, and elapsed-time discount must describe those K actions.

## Algorithm choices

- HIL-SERL-style SAC/RLPD combines demonstrations, reward feedback, and human
  interventions. This does not automatically fine-tune a pi0.5 backbone.
- A frozen pi0.5 plus bounded learned residual is a separate option. Training
  the residual does not mean that the VLA backbone weights were updated.
- PPO fine-tuning of a flow-based VLA requires a compatible stochastic sampler,
  likelihood formulation, training traces, and value learning. piRL provides
  Flow-SDE and Flow-Noise formulations; a standard PPO wrapper around the
  existing deterministic inference endpoint is insufficient.
- The current Windows/SSH/WebSocket inference bridge is useful transport and
  control infrastructure, not a complete RL environment or rollout collector.
- Local RLinf examples and other repository recipes are implementation leads,
  not evidence that this particular six-dimensional SO101 interface has been
  validated with their training configurations.

## Primary sources

1. LeRobot HIL-SERL documentation:
   https://huggingface.co/docs/lerobot/hilserl
   Demonstrations, reward classifier, SAC actor/learner, and interventions.
2. HIL-SERL project:
   https://hil-serl.github.io/
   Human-in-the-loop real-robot RL with sparse rewards and demonstrations.
3. piRL: Online RL Fine-tuning for Flow-based Vision-Language-Action Models:
   https://arxiv.org/abs/2510.25889
   Flow-SDE and Flow-Noise address policy optimization for flow-based VLAs.
4. Physical Intelligence RECAP discussion and paper:
   https://www.physicalintelligence.company/blog/pistar06
   https://arxiv.org/abs/2511.14759
   Learning from demonstrations, autonomous experience, and corrections. This
   is not a drop-in PPO recipe for the current pi0.5 checkpoint.
5. PPO algorithm reference:
   https://spinningup.openai.com/en/latest/algorithms/ppo.html
   On-policy rollouts, action likelihood ratios, and value estimation.
