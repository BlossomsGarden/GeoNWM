param(
    [int]$LocalPort = 16006,
    [int]$RemotePort = 6006
)
$ErrorActionPreference = 'Stop'
$settingsPath = Join-Path (Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))) 'REMOTE_SERVER.md'
$settings = @{}
foreach ($line in Get-Content -LiteralPath $settingsPath -Encoding UTF8) {
    if ($line -match '^\s*(ip|port|user_name)\s*:\s*(.*?)\s*$') {
        $settings[$matches[1]] = $matches[2]
    }
}
foreach ($name in @('ip', 'port', 'user_name')) {
    if (-not $settings[$name]) { throw "Missing SSH setting: $name" }
}
if ($LocalPort -lt 1 -or $LocalPort -gt 65535 -or $RemotePort -lt 1 -or $RemotePort -gt 65535) {
    throw 'Ports must be between 1 and 65535.'
}
Write-Host "Forwarding ws://127.0.0.1:$LocalPort to server 127.0.0.1:$RemotePort. Keep this window open."
& ssh.exe -N -T -o ExitOnForwardFailure=yes -o ServerAliveInterval=15 -o ServerAliveCountMax=3 `
    -L "127.0.0.1:${LocalPort}:127.0.0.1:${RemotePort}" -p $settings['port'] `
    "$($settings['user_name'])@$($settings['ip'])"
exit $LASTEXITCODE
