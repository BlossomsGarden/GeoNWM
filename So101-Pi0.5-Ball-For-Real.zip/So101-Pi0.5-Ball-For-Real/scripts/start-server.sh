#!/usr/bin/env bash
set -eo pipefail
export SO101_GPU="${SO101_GPU:-3}"
source /data4/DATA/wlh/offer/pi05-so101-three-ball-order/runtime/scripts/inference_env.sh
cd /data4/DATA/wlh/offer/pi05-so101-three-ball-order
exec python "$SO101_ROOT/runtime/scripts/serve_so101.py" \
  --config pi05_so101_three_ball_h50 \
  --checkpoint-dir "$SO101_ROOT/model" \
  --port "${SO101_PORT:-6006}" --noise-seed 0
