"""RGB observations from synthetic data or an explicit saved capture."""

from dataclasses import dataclass
import io
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image, ImageDraw

from third_party.openpi_client.image_tools import resize_with_pad
from . import EXAMPLE_STATE
from .protocol import JPEG_KEYS, validate_state


def validate_image(value):
    image = np.asarray(value)
    if image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3 or min(image.shape[:2]) < 2:
        raise ValueError("Images must be nonempty uint8 HWC RGB arrays")
    return image


@dataclass
class Observation:
    state: np.ndarray
    front: np.ndarray
    side: np.ndarray
    captured_at: float

    def __post_init__(self):
        self.state = validate_state(self.state).copy()
        self.front = validate_image(self.front)
        self.side = validate_image(self.side)
        if not np.isfinite(self.captured_at):
            raise ValueError("Invalid observation timestamp")

    def wire(self, prompt, jpeg_quality=90):
        payload = {"observation/state": self.state, "prompt": prompt}
        for key, image in zip(JPEG_KEYS, (self.front, self.side)):
            buffer = io.BytesIO()
            resized = resize_with_pad(image, 224, 224)
            Image.fromarray(resized).save(buffer, "JPEG", quality=jpeg_quality, subsampling=2)
            payload[key] = buffer.getvalue()
        return payload


def save_observation(observation, directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    Image.fromarray(observation.front).save(directory / "front.png")
    Image.fromarray(observation.side).save(directory / "side.png")
    (directory / "state.json").write_text(json.dumps({
        "state": observation.state.tolist(), "units": "lerobot_range_m100_100_gripper_0_100",
        "front": "front.png", "side": "side.png",
    }, indent=2) + "\n", encoding="utf-8")


class SyntheticSource:
    kind = "synthetic"

    def __init__(self, state=EXAMPLE_STATE):
        self.state = validate_state(state).copy()
        self.images = []
        for offset in (0, 45):
            image = Image.new("RGB", (640, 480), (215, 222, 220))
            draw = ImageDraw.Draw(image)
            draw.rectangle((400-offset, 110, 580-offset, 310), outline=(70, 75, 80), width=5)
            for x, color in ((135, (220, 30, 45)), (240, (30, 170, 80)), (345, (30, 80, 220))):
                draw.ellipse((x-22, 295+offset, x+22, 339+offset), fill=color)
            draw.text((15, 15), "SYNTHETIC INPUT - NOT A REAL CAMERA", fill=(10, 20, 30))
            self.images.append(np.asarray(image))

    def connect(self):
        pass

    def observe(self):
        return Observation(self.state, *self.images, time.perf_counter())

    def read_state(self):
        return self.state.copy()

    def send_action(self, target):
        self.state = validate_state(target).copy()
        return self.state.copy()

    def close(self):
        pass


class SavedSource:
    kind = "saved"

    def __init__(self, directory):
        self.directory = Path(directory).resolve()

    def connect(self):
        data = json.loads((self.directory / "state.json").read_text(encoding="utf-8-sig"))
        if data.get("units") != "lerobot_range_m100_100_gripper_0_100":
            raise ValueError("Saved capture must explicitly use this checkpoint's normalized units")
        images = []
        for key in ("front", "side"):
            path = (self.directory / data[key]).resolve()
            if not path.is_relative_to(self.directory):
                raise ValueError("Saved image paths must stay inside the capture directory")
            with Image.open(path) as image:
                images.append(np.asarray(image.convert("RGB")))
        self.state = validate_state(data["state"])
        self.images = images

    def observe(self):
        # The timestamp denotes replay arrival, not the original physical capture.
        return Observation(self.state, *self.images, time.perf_counter())

    def close(self):
        pass
