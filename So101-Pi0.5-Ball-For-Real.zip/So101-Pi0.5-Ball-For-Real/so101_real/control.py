"""Synchronous absolute-target execution with local guards and bounded runs."""

import json
from pathlib import Path
import threading
import time

import numpy as np

from .protocol import validate_actions, validate_state


class SafetyError(RuntimeError):
    pass


class SafetyGuard:
    def __init__(self, config):
        self.config = config

    def check_bounds(self, values):
        values = np.asarray(values)
        if not np.isfinite(values).all():
            raise SafetyError("Nonfinite target/state")
        if np.any(values < self.config.lower) or np.any(values > self.config.upper):
            raise SafetyError("Target/state lies outside configured normalized joint bounds")

    def check_age(self, observation, now=None):
        age = (time.perf_counter() if now is None else now) - observation.captured_at
        if age < 0 or age > self.config.max_observation_age_s:
            raise SafetyError(f"Observation expired: age={age:.3f}s")

    def check_drift(self, state, observed):
        if np.any(np.abs(validate_state(state) - validate_state(observed)) > self.config.max_state_drift):
            raise SafetyError("Robot state changed too far while waiting for inference")

    def target(self, requested, previous, present):
        requested, previous, present = map(validate_state, (requested, previous, present))
        self.check_bounds(requested)
        self.check_bounds(present)
        # The first command is limited relative to measured present position.
        target = previous + np.clip(requested - previous, -np.asarray(self.config.step_limits), self.config.step_limits)
        self.check_bounds(target)
        if np.any(np.abs(target - present) > self.config.tracking_limits):
            raise SafetyError("Tracking watchdog exceeded; target was not sent")
        return target.astype(np.float32)


def wait_for_settle(source, config, stop, *, clock=time.perf_counter):
    deadline = clock() + config.settle_timeout_s
    previous = source.read_state()
    consecutive = 0
    while clock() < deadline:
        if stop.wait(1 / 30):
            raise InterruptedError("Stopped while waiting for the arm to settle")
        current = source.read_state()
        consecutive = consecutive + 1 if np.max(np.abs(current - previous)) <= config.settle_delta else 0
        if consecutive >= config.settle_samples:
            return
        previous = current
    raise SafetyError("Arm did not settle before the replan deadline")


def run_session(source, client, config, *, chunks=1, max_steps=1, execute=False,
                simulate=False, stop=None, output=None):
    if type(chunks) is not int or chunks < 1 or type(max_steps) is not int or max_steps < 1:
        raise ValueError("chunks and max_steps must be positive integers")
    if execute and (simulate or source.kind != "hardware"):
        raise ValueError("--execute requires the hardware source and cannot be combined with simulation")
    if simulate and source.kind != "synthetic":
        raise ValueError("Simulation requires synthetic observations")
    if execute and client.metadata.get("mock"):
        raise ValueError("Mock server cannot drive physical hardware")
    moving = execute or simulate
    stop = stop or threading.Event()
    guard = SafetyGuard(config.safety)
    report = {
        "source": source.kind, "execution": "hardware" if execute else "simulated" if simulate else "none",
        "task_success_evaluated": False, "metadata": client.metadata,
        "units": "lerobot_range_m100_100_gripper_0_100", "actions_are_absolute": True,
        "config": config.as_dict(), "chunks": [], "commands": [], "status": "running",
    }
    try:
        for chunk_index in range(chunks):
            if stop.is_set():
                report["status"] = "stopped"
                break
            if moving and chunk_index:
                try:
                    wait_for_settle(source, config.safety, stop)
                except InterruptedError:
                    report["status"] = "stopped"
                    break
            observation = source.observe()
            guard.check_bounds(observation.state)
            payload = observation.wire(config.prompt, config.jpeg_quality)
            guard.check_age(observation)
            result, latency = client.infer(payload)
            actions = validate_actions(result["actions"])
            record = {
                "index": chunk_index, "state": observation.state.tolist(),
                "actions": actions.tolist(), "round_trip_seconds": latency,
                "jpeg_bytes": sum(len(payload[key]) for key in ("transport/front_image_jpeg", "transport/side_image_jpeg")),
                "server_timing": result.get("server_timing"),
                "observation_age_on_response_s": time.perf_counter() - observation.captured_at,
            }
            report["chunks"].append(record)
            if stop.is_set():
                report["status"] = "stopped"
                break
            if not moving:
                continue
            guard.check_age(observation)
            present = source.read_state()
            guard.check_drift(present, observation.state)
            previous = present.copy()
            segment = actions[:min(config.execute_horizon, max_steps - len(report["commands"]))]
            guard.check_bounds(segment)
            for requested in segment:
                if stop.is_set():
                    break
                guard.check_age(observation)
                present = source.read_state()
                target = guard.target(requested, previous, present)
                if stop.is_set():
                    break
                sent = validate_state(source.send_action(target))
                if not np.allclose(sent, target, atol=1e-4):
                    raise SafetyError("Robot returned a different target from the guarded command")
                previous = sent
                report["commands"].append({"requested": requested.tolist(), "sent": sent.tolist(),
                                           "present_before": present.tolist(), "chunk": chunk_index})
                # Wait after completion of each send: slow I/O never causes catch-up bursts.
                stop.wait(1 / config.control_hz)
            if len(report["commands"]) >= max_steps:
                report["status"] = "completed"
                break
        if report["status"] == "running":
            report["status"] = "stopped" if stop.is_set() else "completed"
        return report
    except BaseException as exc:
        report["status"] = "error"
        report["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        if output is not None:
            path = Path(output)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
