"""OpenPI JPEG/MessagePack wire protocol with finite network deadlines."""

import socket
import threading
import time
import numpy as np
from websockets.sync.client import connect

from third_party.openpi_client import msgpack_numpy
from .config import ServerConfig

JPEG_KEYS = ("transport/front_image_jpeg", "transport/side_image_jpeg")
MAX_MESSAGE_BYTES = 16 * 1024 * 1024


def validate_state(value):
    state = np.asarray(value, dtype=np.float32)
    if state.shape != (6,) or not np.isfinite(state).all():
        raise ValueError("Expected six finite joint positions")
    return state


def validate_actions(value):
    actions = np.asarray(value, dtype=np.float32)
    if actions.shape != (50, 6) or not np.isfinite(actions).all():
        raise ValueError(f"Expected finite H50x6 absolute actions, got {actions.shape}")
    return actions


def validate_metadata(metadata, expected_config):
    if not isinstance(metadata, dict):
        raise ValueError("Server metadata must be a dictionary")
    for key, expected in (("config", expected_config), ("action_horizon", 50),
                          ("robot_action_dim", 6), ("transport", "jpeg")):
        if metadata.get(key) != expected:
            raise ValueError(f"Server {key}: expected {expected!r}, got {metadata.get(key)!r}")
    if set(metadata.get("jpeg_input_keys", [])) != set(JPEG_KEYS):
        raise ValueError("Server JPEG input fields do not match this policy")
    return metadata


class PolicyClient:
    def __init__(self, config: ServerConfig):
        self.config = config
        self.connection = None
        self._context = None
        self.metadata = None

    def __enter__(self):
        self._context = connect(
            self.config.url, compression=None, proxy=None,
            open_timeout=self.config.connect_timeout_s, close_timeout=2,
            max_size=MAX_MESSAGE_BYTES,
        )
        try:
            self.connection = self._context.__enter__()
            payload = self.connection.recv(timeout=self.config.connect_timeout_s)
            self.metadata = validate_metadata(self._decode(payload), self.config.expected_config)
        except BaseException:
            self.close()
            raise
        return self

    @staticmethod
    def _decode(payload):
        if isinstance(payload, str):
            raise RuntimeError(f"OpenPI server error: {payload[:2000]}")
        result = msgpack_numpy.unpackb(payload)
        if not isinstance(result, dict):
            raise ValueError("Expected a MessagePack dictionary")
        return result

    def infer(self, observation):
        if self.connection is None:
            raise RuntimeError("PolicyClient is not connected")
        validate_state(observation["observation/state"])
        if not isinstance(observation.get("prompt"), str) or not observation["prompt"].strip():
            raise ValueError("Missing task prompt")
        for key in JPEG_KEYS:
            if not isinstance(observation.get(key), bytes) or not observation[key]:
                raise ValueError(f"Missing JPEG bytes: {key}")
        payload = msgpack_numpy.packb(observation)
        if len(payload) > MAX_MESSAGE_BYTES:
            raise ValueError("Observation exceeds maximum message size")
        started = time.perf_counter()
        expired = threading.Event()
        connection = self.connection

        def expire():
            expired.set()
            # Interrupt blocked sends as well as receives. Socket timeouts alone
            # interfere with websockets' background reader.
            try:
                connection.socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

        timer = threading.Timer(self.config.request_timeout_s, expire)
        timer.daemon = True
        timer.start()
        try:
            self.connection.send(payload)
            remaining = self.config.request_timeout_s - (time.perf_counter() - started)
            if remaining <= 0:
                raise TimeoutError("Inference request deadline exceeded")
            result = self._decode(self.connection.recv(timeout=remaining))
            result["actions"] = validate_actions(result["actions"])
            if expired.is_set():
                raise TimeoutError("Inference request deadline exceeded")
        except BaseException as exc:
            # A timed-out response cannot be matched to a later observation.
            self.close()
            if expired.is_set():
                raise TimeoutError("Inference request deadline exceeded") from exc
            raise
        finally:
            timer.cancel()
            timer.join()
        return result, time.perf_counter() - started

    def close(self):
        if self.connection is not None:
            self._context.__exit__(None, None, None)
            self.connection = None
        self._context = None

    def __exit__(self, *_):
        self.close()
