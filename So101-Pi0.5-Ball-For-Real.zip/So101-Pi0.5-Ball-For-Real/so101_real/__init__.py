"""Windows acquisition and execution for a remote SO101 OpenPI policy."""

JOINTS = (
    "shoulder_pan", "shoulder_lift", "elbow_flex",
    "wrist_flex", "wrist_roll", "gripper",
)
PROMPT = "Put the balls into the box in this order: red, green, blue."
EXAMPLE_STATE = (-6.215878, -34.317089, 33.718967, 64.482658, 0.105258, 29.188202)
