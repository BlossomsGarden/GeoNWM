"""Optional LeRobot 0.6 adapter; construction and imports do not open hardware."""

import json
from pathlib import Path
import time
import warnings

from . import JOINTS
from .observations import Observation
from .protocol import validate_state


def validate_calibration(path):
    path = Path(path).expanduser().resolve()
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if set(data) != set(JOINTS):
        raise ValueError("Calibration must describe exactly the six SO101 joints")
    for index, name in enumerate(JOINTS, 1):
        row = data[name]
        for key in ("id", "drive_mode", "homing_offset", "range_min", "range_max"):
            if type(row.get(key)) is not int:
                raise ValueError(f"Invalid calibration {name}.{key}")
        if row["id"] != index or row["drive_mode"] not in (0, 1):
            raise ValueError(f"Unexpected motor ID or direction: {name}")
        if not 0 <= row["range_min"] < row["range_max"] <= 4095:
            raise ValueError(f"Invalid encoder range: {name}")
    return path


def make_robot(config):
    from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig
    from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig
    import cv2

    calibration = validate_calibration(config.calibration_file)
    cameras = {}
    for key in ("front", "side"):
        camera = getattr(config, key)
        cameras[key] = OpenCVCameraConfig(
            index_or_path=camera.index, width=camera.width, height=camera.height,
            fps=camera.fps, backend=getattr(cv2, f"CAP_{camera.backend}"),
        )
    return SO101Follower(SO101FollowerConfig(
        port=config.port, id=calibration.stem, calibration_dir=calibration.parent,
        cameras=cameras, use_degrees=False, max_relative_target=None,
        disable_torque_on_disconnect=config.disable_torque_on_disconnect,
    ))


class HardwareSource:
    kind = "hardware"

    def __init__(self, config, *, execute=False, factory=None):
        self.config = config
        self.execute = execute
        self.factory = factory or make_robot
        self.robot = None
        self.actuation_started = False

    def connect(self):
        if not self.config.port or not self.config.calibration_file:
            raise ValueError("Hardware requires explicit port and calibration_file")
        validate_calibration(self.config.calibration_file)
        try:
            self.robot = self.factory(self.config)
            self.robot.bus.connect()
            if not self.robot.bus.is_calibrated:
                raise ValueError("Calibration file does not match motor registers; calibrate separately")
            for camera in self.robot.cameras.values():
                camera.connect()
            if self.execute:
                self._enable_execution()
        except BaseException:
            self.close()
            raise

    def _enable_execution(self):
        bus = self.robot.bus
        modes = bus.sync_read("Operating_Mode", normalize=False)
        if any(modes[name] != 0 for name in JOINTS):
            raise ValueError("All motors must already be in position mode; configure them separately")
        # Only this explicitly enabled branch writes any motor registers.
        self.actuation_started = True
        bus.disable_torque()
        current = self.read_state()
        bus.sync_write("Goal_Position", dict(zip(JOINTS, current.tolist())))
        bus.enable_torque()

    def read_state(self):
        present = self.robot.bus.sync_read("Present_Position")
        return validate_state([present[name] for name in JOINTS])

    def observe(self):
        started = time.perf_counter()
        state = self.read_state()
        state_time = time.perf_counter()
        images, stamps = [], [state_time]
        for key in ("front", "side"):
            camera = self.robot.cameras[key]
            camera.read_latest(max_age_ms=500)
            with camera.frame_lock:
                images.append(camera.latest_frame.copy())
                stamps.append(camera.latest_timestamp)
        now = time.perf_counter()
        if any(stamp is None or now - stamp > 0.5 for stamp in stamps):
            raise TimeoutError("Camera/state observation is stale")
        if max(stamps) - min(stamps) > 0.15 or state_time - started > 0.15:
            raise TimeoutError("Camera and state timestamps differ by more than 150 ms")
        return Observation(state, *images, min(stamps))

    def send_action(self, target):
        if not self.execute or not self.actuation_started:
            raise RuntimeError("Read-only hardware source cannot send actions")
        target = validate_state(target)
        sent = self.robot.send_action({f"{name}.pos": float(value) for name, value in zip(JOINTS, target)})
        return validate_state([sent[f"{name}.pos"] for name in JOINTS])

    def close(self):
        if self.robot is None:
            return
        for camera in self.robot.cameras.values():
            try:
                if camera.is_connected:
                    camera.disconnect()
                elif getattr(camera, "videocapture", None) is not None:
                    camera.videocapture.release()
                    camera.videocapture = None
            except Exception as exc:
                warnings.warn(f"Camera cleanup failed: {exc}", RuntimeWarning)
        try:
            if self.robot.bus.is_connected:
                self.robot.bus.disconnect(disable_torque=(
                    self.actuation_started and self.config.disable_torque_on_disconnect
                ))
        except Exception as exc:
            warnings.warn(f"Serial cleanup failed: {exc}", RuntimeWarning)
        self.robot = None


def require_calibrated_config(config):
    """Validate a physical configuration without connecting any device."""
    if not config.port:
        raise ValueError("hardware.port is empty")
    return validate_calibration(config.calibration_file)
