"""Validated configuration; importing this module never imports LeRobot."""

from dataclasses import asdict, dataclass, field, fields
import json
import math
from pathlib import Path
from urllib.parse import urlsplit

from . import PROMPT


def positive(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{label} must be positive and finite")


def vector(values, label, *, positive_only=False):
    if not isinstance(values, (list, tuple)) or len(values) != 6:
        raise ValueError(f"{label} must contain six numbers")
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
        raise ValueError(f"{label} must contain finite numbers")
    if positive_only and any(v <= 0 for v in values):
        raise ValueError(f"{label} must contain positive numbers")


@dataclass
class ServerConfig:
    url: str = "ws://127.0.0.1:16006"
    connect_timeout_s: float = 10
    request_timeout_s: float = 60
    expected_config: str = "pi05_so101_three_ball_h50"

    def __post_init__(self):
        parsed = urlsplit(self.url)
        if parsed.scheme not in ("ws", "wss") or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("server.url must be a ws/wss URL without embedded credentials")
        if parsed.query or parsed.fragment:
            raise ValueError("server.url must not include query parameters or a fragment")
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            raise ValueError("Invalid server port")
        positive(self.connect_timeout_s, "connect_timeout_s")
        positive(self.request_timeout_s, "request_timeout_s")
        if not self.expected_config:
            raise ValueError("expected_config must not be empty")


@dataclass
class SafetyConfig:
    lower: tuple = (-100, -100, -100, -100, -100, 0)
    upper: tuple = (100, 100, 100, 100, 100, 100)
    step_limits: tuple = (1, 1, 1, 1, 0.5, 1)
    tracking_limits: tuple = (10, 10, 10, 10, 5, 10)
    max_observation_age_s: float = 2
    max_state_drift: tuple = (5, 5, 5, 5, 3, 5)
    settle_timeout_s: float = 3
    settle_delta: float = 0.5
    settle_samples: int = 3

    def __post_init__(self):
        for name in ("lower", "upper", "step_limits", "tracking_limits", "max_state_drift"):
            vector(getattr(self, name), name, positive_only=name not in ("lower", "upper"))
        if any(lo >= hi for lo, hi in zip(self.lower, self.upper)):
            raise ValueError("Every lower bound must be less than its upper bound")
        if any(lo < minimum or hi > maximum for lo, hi, minimum, maximum in
               zip(self.lower, self.upper, [-100]*5+[0], [100]*6)):
            raise ValueError("Bounds must stay inside normalized arm [-100,100], gripper [0,100]")
        for name in ("max_observation_age_s", "settle_timeout_s", "settle_delta"):
            positive(getattr(self, name), name)
        if type(self.settle_samples) is not int or self.settle_samples < 2:
            raise ValueError("settle_samples must be an integer >=2")


@dataclass
class CameraConfig:
    index: int = 0
    width: int = 640
    height: int = 480
    fps: int = 30
    backend: str = "DSHOW"

    def __post_init__(self):
        if type(self.index) is not int or self.index < 0:
            raise ValueError("camera.index must be a nonnegative integer")
        for name in ("width", "height", "fps"):
            if type(getattr(self, name)) is not int or getattr(self, name) <= 0:
                raise ValueError(f"camera.{name} must be a positive integer")
        if self.backend not in ("DSHOW", "MSMF", "V4L2", "ANY"):
            raise ValueError("Unsupported camera backend")


@dataclass
class HardwareConfig:
    port: str = ""
    calibration_file: str = ""
    use_degrees: bool = False
    disable_torque_on_disconnect: bool = True
    front: CameraConfig = field(default_factory=lambda: CameraConfig(index=1))
    side: CameraConfig = field(default_factory=lambda: CameraConfig(index=2))

    def __post_init__(self):
        if self.use_degrees is not False:
            raise ValueError("This checkpoint requires use_degrees=false (normalized training units)")
        if type(self.disable_torque_on_disconnect) is not bool:
            raise ValueError("disable_torque_on_disconnect must be boolean")
        if self.front.index == self.side.index:
            raise ValueError("front and side must use different camera indices")


@dataclass
class Config:
    server: ServerConfig = field(default_factory=ServerConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    hardware: HardwareConfig = field(default_factory=HardwareConfig)
    prompt: str = PROMPT
    jpeg_quality: int = 90
    control_hz: float = 30
    execute_horizon: int = 5

    def __post_init__(self):
        if not isinstance(self.prompt, str) or not self.prompt.strip():
            raise ValueError("prompt must not be empty")
        if type(self.jpeg_quality) is not int or not 1 <= self.jpeg_quality <= 100:
            raise ValueError("jpeg_quality must be an integer from 1 to 100")
        positive(self.control_hz, "control_hz")
        if self.control_hz > 30:
            raise ValueError("control_hz must not exceed this dataset's 30 Hz")
        if type(self.execute_horizon) is not int or not 1 <= self.execute_horizon <= 50:
            raise ValueError("execute_horizon must be an integer from 1 to 50")

    def as_dict(self):
        return asdict(self)


def _construct(cls, values):
    if not isinstance(values, dict):
        raise ValueError(f"{cls.__name__} must be an object")
    unknown = set(values) - {f.name for f in fields(cls)}
    if unknown:
        raise ValueError(f"Unknown {cls.__name__} settings: {sorted(unknown)}")
    return cls(**values)


def load_config(path=None):
    if path is None:
        return Config()
    path = Path(path).resolve()
    values = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(values, dict):
        raise ValueError("Configuration must be a JSON object")
    for key, cls in (("server", ServerConfig), ("safety", SafetyConfig)):
        if key in values:
            values[key] = _construct(cls, values[key])
    if "hardware" in values:
        hardware = dict(values["hardware"])
        for key in ("front", "side"):
            if key in hardware:
                hardware[key] = _construct(CameraConfig, hardware[key])
        calibration = hardware.get("calibration_file")
        if calibration:
            calibration = Path(calibration).expanduser()
            hardware["calibration_file"] = str((path.parent / calibration).resolve())
        values["hardware"] = _construct(HardwareConfig, hardware)
    return _construct(Config, values)
