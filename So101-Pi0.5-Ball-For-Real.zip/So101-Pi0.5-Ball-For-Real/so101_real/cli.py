"""Hardware-free defaults; physical commands require --source hardware --execute."""

import argparse
import json
from pathlib import Path
import signal
import sys
import threading

from .config import ServerConfig, load_config
from .control import run_session
from .observations import SavedSource, SyntheticSource, save_observation
from .protocol import PolicyClient


def parser():
    root = argparse.ArgumentParser(description=__doc__)
    root.add_argument("--config", type=Path)
    root.add_argument("--url", help="Override inference endpoint, e.g. ws://127.0.0.1:16006")
    commands = root.add_subparsers(dest="command", required=True)
    commands.add_parser("probe", help="Read policy metadata; no observations or hardware")
    run = commands.add_parser("run", help="Request actions; default synthetic and non-actuating")
    run.add_argument("--source", choices=("synthetic", "saved", "hardware"), default="synthetic")
    run.add_argument("--capture-dir", type=Path)
    run.add_argument("--chunks", type=int, default=1)
    run.add_argument("--max-steps", type=int, default=1)
    group = run.add_mutually_exclusive_group()
    group.add_argument("--simulate-execution", action="store_true")
    group.add_argument("--execute", action="store_true")
    run.add_argument("--output", type=Path, default=Path("results/run.json"))
    capture = commands.add_parser("capture", help="Save RGB/state, never send model actions")
    capture.add_argument("--source", choices=("synthetic", "hardware"), default="synthetic")
    capture.add_argument("--output", type=Path, required=True)
    commands.add_parser("check-config", help="Validate settings without opening devices")
    return root


def source_for(args, config):
    if args.source == "synthetic":
        return SyntheticSource()
    if args.source == "saved":
        if args.capture_dir is None:
            raise ValueError("--source saved requires --capture-dir")
        return SavedSource(args.capture_dir)
    from .hardware import HardwareSource
    return HardwareSource(config.hardware, execute=getattr(args, "execute", False))


def main(argv=None):
    args = parser().parse_args(argv)
    config = load_config(args.config)
    if args.url:
        config.server = ServerConfig(**{**vars(config.server), "url": args.url})
    if args.command == "check-config":
        print(json.dumps(config.as_dict(), indent=2))
        return 0
    if args.command == "probe":
        with PolicyClient(config.server) as client:
            print(json.dumps(client.metadata, indent=2))
        return 0
    if args.command == "run":
        if args.execute and args.source != "hardware":
            raise ValueError("--execute requires --source hardware")
        if args.simulate_execution and args.source != "synthetic":
            raise ValueError("--simulate-execution requires --source synthetic")
        if args.chunks < 1 or args.max_steps < 1:
            raise ValueError("chunks and max-steps must be positive")
    source = source_for(args, config)
    stop = threading.Event()
    previous_handler = signal.signal(signal.SIGINT, lambda *_: stop.set())
    try:
        if args.command == "capture":
            source.connect()
            save_observation(source.observe(), args.output)
            print(f"Capture saved: {args.output.resolve()}")
            return 0
        with PolicyClient(config.server) as client:
            if args.execute and client.metadata.get("mock"):
                raise ValueError("Refusing hardware execution against a mock server")
            source.connect()
            report = run_session(source, client, config, chunks=args.chunks, max_steps=args.max_steps,
                                 execute=args.execute, simulate=args.simulate_execution,
                                 stop=stop, output=args.output)
        print(json.dumps({"status": report["status"], "source": report["source"],
                          "execution": report["execution"], "chunks": len(report["chunks"]),
                          "commands": len(report["commands"]), "report": str(args.output.resolve())}, indent=2))
        return 0 if report["status"] == "completed" else 130
    finally:
        source.close()
        signal.signal(signal.SIGINT, previous_handler)


def entrypoint():
    try:
        return main()
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
