"""Protocol-only loopback test double. No model weights or hardware are used."""

import argparse
import io
import threading
import time

import numpy as np
from PIL import Image
from websockets.sync.server import serve

from third_party.openpi_client import msgpack_numpy
from .protocol import JPEG_KEYS, MAX_MESSAGE_BYTES, validate_state


def metadata():
    return {
        "config": "pi05_so101_three_ball_h50", "action_horizon": 50, "robot_action_dim": 6,
        "transport": "jpeg", "jpeg_input_keys": list(JPEG_KEYS), "mock": True,
        "description": "Protocol test double; output is NOT a VLA prediction",
    }


def predict(observation):
    state = validate_state(observation["observation/state"])
    if not observation.get("prompt"):
        raise ValueError("Prompt is missing")
    for key in JPEG_KEYS:
        with Image.open(io.BytesIO(observation[key])) as image:
            if image.size != (224, 224) or image.mode != "RGB":
                raise ValueError("Expected 224x224 RGB JPEG")
            image.load()
    actions = np.repeat(state[None, :], 50, axis=0)
    actions[:, 0] += np.linspace(0.1, 1.0, 50)
    return {"actions": actions, "server_timing": {"infer_ms": 0.0}}


class MockServer:
    def __init__(self, host="127.0.0.1", port=0, *, delay=0, bad_shape=False,
                 bad_metadata=False, text_error=False, disconnect=False):
        self.host, self.port = host, port
        self.delay, self.bad_shape = delay, bad_shape
        self.bad_metadata, self.text_error, self.disconnect = bad_metadata, text_error, disconnect
        self.server = None
        self.thread = None

    def handle(self, connection):
        info = metadata()
        if self.bad_metadata:
            info["robot_action_dim"] = 7
        try:
            connection.send(msgpack_numpy.packb(info))
            for payload in connection:
                if self.disconnect:
                    connection.close()
                    return
                result = predict(msgpack_numpy.unpackb(payload))
                if self.delay:
                    time.sleep(self.delay)
                if self.bad_shape:
                    result["actions"] = result["actions"][:, :5]
                if self.text_error:
                    connection.send("Mock inference failure")
                else:
                    connection.send(msgpack_numpy.packb(result))
        except Exception:
            connection.close()

    def __enter__(self):
        self.server = serve(self.handle, self.host, self.port, compression=None, max_size=MAX_MESSAGE_BYTES)
        self.port = self.server.socket.getsockname()[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *_):
        self.server.shutdown()
        self.thread.join(timeout=3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=16006)
    args = parser.parse_args()
    with MockServer(port=args.port) as server:
        print(f"MOCK ONLY: ws://127.0.0.1:{server.port}", flush=True)
        try:
            threading.Event().wait()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
