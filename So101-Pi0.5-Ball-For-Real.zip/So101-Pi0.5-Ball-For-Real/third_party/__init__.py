"""Small, attributed upstream helpers; no OpenPI/JAX runtime dependency."""
