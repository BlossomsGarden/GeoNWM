# Provenance

`msgpack_numpy.py` and `image_tools.py` are copied unchanged from
`Physical-Intelligence/openpi`, commit
`15a9616a00943ada6c20a0f158e3adb39df2ccac`, under
`packages/openpi-client/src/openpi_client/`.

Source: https://github.com/Physical-Intelligence/openpi/tree/15a9616a00943ada6c20a0f158e3adb39df2ccac/packages/openpi-client

The accompanying `LICENSE` is from that repository (Apache-2.0). The MessagePack
helper itself credits `lebedov/msgpack-numpy` in its module docstring.

This project reuses the wire format and PIL resize behavior. It supplies its own
bounded WebSocket client and does not install the old distribution's NumPy<2
dependency, which conflicts with LeRobot 0.6.0's NumPy>=2 requirement.
