"""Run hardware-free tests and save reproducible loopback evidence."""

import importlib.metadata
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from so101_real.config import Config, ServerConfig
from so101_real.control import run_session
from so101_real.mock_server import MockServer
from so101_real.observations import SyntheticSource
from so101_real.protocol import PolicyClient


def main():
    output = ROOT / "results"
    output.mkdir(exist_ok=True)
    tests = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    with (output / "unit-tests.log").open("w", encoding="utf-8") as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(tests)
    summary = {
        "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
        "skipped": len(result.skipped), "passed": result.wasSuccessful(),
        "hardware_connected": False, "physical_actions_sent": 0,
        "python": sys.version, "packages": {key: importlib.metadata.version(key)
            for key in ("numpy", "Pillow", "msgpack", "websockets")},
    }
    if result.wasSuccessful():
        with MockServer() as server:
            config = Config(server=ServerConfig(url=f"ws://127.0.0.1:{server.port}"))
            with PolicyClient(config.server) as client:
                report = run_session(SyntheticSource(), client, config, chunks=3, max_steps=12,
                                     simulate=True, output=output / "local-loopback.json")
        summary["loopback"] = {"status": report["status"], "chunks": len(report["chunks"]),
                               "simulated_commands": len(report["commands"])}
    (output / "verification-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
