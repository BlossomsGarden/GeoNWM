"""Read workspace SSH settings without copying credentials into this project."""

import argparse
from contextlib import contextmanager
import json
from pathlib import Path
import select
import shlex
import socketserver
import sys
import threading
import time
import traceback
import uuid

import paramiko

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
OFFER_ROOT = "/data4/DATA/wlh/offer"
MODEL_ROOT = OFFER_ROOT + "/pi05-so101-three-ball-order"
PRELUDE = "source /data4/DATA/wlh/offer/ROS2/env.sh; export PYTHONDONTWRITEBYTECODE=1; "


def settings():
    values = {}
    for line in (WORKSPACE / "REMOTE_SERVER.md").read_text(encoding="utf-8-sig").splitlines():
        key, separator, value = line.partition(":")
        if separator and key.strip() in ("ip", "port", "user_name", "password"):
            values[key.strip()] = value.strip()
    if any(not values.get(key) for key in ("ip", "port", "user_name")):
        raise ValueError("Incomplete REMOTE_SERVER.md SSH settings")
    return values


def connect_ssh(accept_new=False):
    values = settings()
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    if accept_new:
        # Trust is for this process only; no global known_hosts changes.
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(values["ip"], port=int(values["port"]), username=values["user_name"],
                   password=values.get("password"), timeout=15, banner_timeout=15, auth_timeout=15)
    client.get_transport().set_keepalive(15)
    return client


def command(client, script, timeout=30):
    stdin, stdout, stderr = client.exec_command(PRELUDE + "bash -s", timeout=timeout)
    stdin.write(script)
    stdin.channel.shutdown_write()
    output = stdout.read().decode("utf-8", "replace")
    error = stderr.read().decode("utf-8", "replace")
    code = stdout.channel.recv_exit_status()
    if code:
        raise RuntimeError(f"Remote command failed ({code}): {error[-3000:]} {output[-1000:]}")
    return output


@contextmanager
def forward(client, remote_port):
    transport = client.get_transport()

    class Handler(socketserver.BaseRequestHandler):
        def handle(self):
            channel = transport.open_channel("direct-tcpip", ("127.0.0.1", remote_port), self.client_address)
            if channel is None:
                return
            try:
                while True:
                    ready, _, _ = select.select([self.request, channel], [], [], 1)
                    for origin in ready:
                        data = origin.recv(65536)
                        if not data:
                            return
                        (channel if origin is self.request else self.request).sendall(data)
            finally:
                channel.close()

    class Server(socketserver.ThreadingTCPServer):
        daemon_threads = True
        allow_reuse_address = True

    server = Server(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server.server_address[1]
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


def smoke(client, args):
    sys.path.insert(0, str(ROOT))
    from so101_real.config import ServerConfig
    from so101_real.observations import SyntheticSource
    from so101_real.protocol import PolicyClient
    from so101_real import PROMPT
    import numpy as np

    remote_dir = f"{OFFER_ROOT}/pi05-so101-real/validation/{uuid.uuid4().hex}"
    pid = None
    report = {"input": "synthetic RGB/state; no hardware", "execution": "none",
              "task_success_evaluated": False, "remote_port": args.remote_port, "status": "running"}
    try:
        if args.start:
            launch = (f"export SO101_GPU={args.gpu}; source {MODEL_ROOT}/runtime/scripts/inference_env.sh; "
                      f"cd {MODEL_ROOT}; exec python {MODEL_ROOT}/runtime/scripts/serve_so101.py "
                      f"--config pi05_so101_three_ball_h50 --checkpoint-dir {MODEL_ROOT}/model "
                      f"--port {args.remote_port} --noise-seed 0")
            script = f"""set -e
mkdir -p {shlex.quote(remote_dir)}
if ss -lntH 'sport = :{args.remote_port}' | grep -q .; then
  echo 'Validation port is occupied; refusing to replace its process' >&2; exit 1
fi
nohup bash -c {shlex.quote(launch)} >{shlex.quote(remote_dir + '/server.log')} 2>&1 </dev/null &
pid=$!
echo "$pid" > {shlex.quote(remote_dir + '/server.pid')}
echo "$pid"
"""
            pid = int(command(client, script).strip())
            report.update(remote_log=remote_dir + "/server.log", started_pid=pid, gpu=args.gpu)
            print(f"Started validation model PID {pid}; waiting for model load...", flush=True)
        with forward(client, args.remote_port) as local_port:
            deadline = time.monotonic() + args.startup_timeout
            while True:
                status = command(client, f"ss -lntH 'sport = :{args.remote_port}'\n").strip()
                if status:
                    break
                if pid and command(client, f"kill -0 {pid} 2>/dev/null && echo alive || echo exited\n").strip() != "alive":
                    raise RuntimeError("Model exited: " + command(client, f"tail -c 6000 {shlex.quote(remote_dir + '/server.log')}\n"))
                if time.monotonic() >= deadline:
                    raise TimeoutError("Model startup deadline exceeded")
                time.sleep(2)
            config = ServerConfig(url=f"ws://127.0.0.1:{local_port}", request_timeout_s=90)
            with PolicyClient(config) as policy:
                if policy.metadata.get("mock"):
                    raise RuntimeError("Remote validation requires a real model server")
                observation = SyntheticSource().observe().wire(PROMPT)
                records, outputs = [], []
                for _ in range(2):
                    result, latency = policy.infer(observation)
                    outputs.append(result["actions"])
                    records.append({"round_trip_seconds": latency, "action_shape": list(result["actions"].shape),
                                    "finite": bool(np.isfinite(result["actions"]).all()),
                                    "actions": result["actions"].tolist(), "server_timing": result.get("server_timing")})
                report.update(status="passed", metadata=policy.metadata, requests=records,
                              fixed_input_max_abs_difference=float(np.max(np.abs(outputs[0] - outputs[1]))))
    except BaseException as exc:
        report.update(status="error", error=f"{type(exc).__name__}: {exc}")
        report["traceback"] = traceback.format_exc()
        raise
    finally:
        if pid:
            # Verify command line before terminating only our own dedicated process.
            cleanup = f"""if [ -r /proc/{pid}/cmdline ] && tr '\\0' ' ' </proc/{pid}/cmdline | grep -q 'serve_so101.py.*--port {args.remote_port}'; then
kill -TERM {pid}
for i in 1 2 3 4 5; do kill -0 {pid} 2>/dev/null || break; sleep 1; done
if kill -0 {pid} 2>/dev/null && [ -r /proc/{pid}/cmdline ] && tr '\\0' ' ' </proc/{pid}/cmdline | grep -q 'serve_so101.py.*--port {args.remote_port}'; then kill -KILL {pid}; fi
fi
tail -c 12000 {shlex.quote(remote_dir + '/server.log')}
"""
            try:
                log = command(client, cleanup, timeout=15)
                args.output.parent.mkdir(parents=True, exist_ok=True)
                args.output.with_suffix(".server.log").write_text(log, encoding="utf-8")
                report["started_process_stopped"] = not bool(command(client, f"ss -lntH 'sport = :{args.remote_port}'\n").strip())
            except Exception as exc:
                report["cleanup_error"] = str(exc)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Remote model validation: {report['status']}; report={args.output}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--accept-new-host-key", action="store_true")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("inspect")
    test = commands.add_parser("smoke")
    test.add_argument("--start", action="store_true", help="Start and clean up a dedicated validation model")
    test.add_argument("--gpu", type=int, default=3)
    test.add_argument("--remote-port", type=int, default=6016)
    test.add_argument("--startup-timeout", type=float, default=240)
    test.add_argument("--output", type=Path, default=ROOT / "results/remote-model.json")
    args = parser.parse_args()
    if args.command == "smoke" and (args.gpu < 0 or not 1 <= args.remote_port <= 65535 or args.startup_timeout <= 0):
        parser.error("Invalid GPU, port or startup timeout")
    client = connect_ssh(args.accept_new_host_key)
    try:
        if args.command == "inspect":
            print(command(client, f"nvidia-smi --query-gpu=index,name,memory.used,memory.total --format=csv,noheader\n"
                                 f"test -f {MODEL_ROOT}/model/params/_METADATA && echo checkpoint-present\n"
                                 "ss -lntH 'sport = :6006 or sport = :6016'\n"))
        else:
            smoke(client, args)
    finally:
        client.close()


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    try:
        main()
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
