# Windows SO101 Remote Inference Implementation Plan

**Goal:** Exchange dual-camera observations and H50 actions with the existing OpenPI service, with hardware-free validation and an explicitly enabled LeRobot execution adapter.

**Architecture:** Windows owns acquisition and execution. The existing Linux OpenPI/JAX service owns inference. SSH forwards a local port to server port 6006. ROS2 and MuJoCo are not runtime dependencies.

**Tech Stack:** Python 3.12, NumPy 2, Pillow, MessagePack, websockets, LeRobot 0.6.0 for optional hardware access, Paramiko for optional remote tooling, unittest.

## Files And Responsibilities

- `so101_real/config.py`: validated JSON configuration and paths.
- `so101_real/protocol.py`: bounded OpenPI-compatible WebSocket client, metadata and response validation.
- `so101_real/observations.py`: synthetic and prerecorded observations, RGB JPEG preparation.
- `so101_real/hardware.py`: lazy LeRobot adapter, existing calibration, explicit normalized units, read-only acquisition and opt-in execution.
- `so101_real/control.py`: absolute-target safety checks and synchronous receding-horizon runner.
- `so101_real/cli.py`: probe, capture and run commands; report output.
- `so101_real/mock_server.py`: deterministic protocol-compatible test server, explicitly not a VLA model.
- `third_party/openpi_client/`: unchanged upstream MessagePack and image helpers with license/provenance.
- `scripts/`: Windows launch wrappers and a server launch wrapper reusing the existing checkpoint/runtime.
- `tools/remote.py`: read connection settings from workspace `REMOTE_SERVER.md`; optional read-only inspection and reversible model validation.
- `tests/`: protocol, control and adapter tests using test doubles, with a loopback WebSocket server.
- `README.md`: installation, mock/capture/real commands, configuration and limitations.
- `操作手册.md`: architecture diagram only, as requested.
- `results/`: actual test and optional remote inference reports; never label synthetic validation as physical task success.

## Implementation And Verification

- [x] Preserve the existing simulation and LeLab projects; keep all new files here.
- [x] Reuse the upstream NumPy MessagePack codec and image resizing helper without installing its NumPy<2 package requirement.
- [x] Validate image/state shapes, finite values, metadata, H50x6 absolute actions and timeouts.
- [x] Implement synthetic and saved-observation modes without importing or opening hardware.
- [x] Implement read-only acquisition without `SOFollower.connect()`/`configure()` or torque writes; require explicit execution for actuation.
- [x] Require explicit calibration path and normalized joint units for hardware. Check file/motor calibration agreement without interactive recalibration.
- [x] Execute only leading actions, re-observe between chunks, reject expired observations, bound targets/rate/tracking and abort on connection failure. Do not rebase server absolute actions.
- [x] Test invalid payloads, dtype handling, wrong metadata, stalled responses, disconnects, first-command limits, tracking errors, stopping, partial cleanup and dry-run non-actuation.
- [x] Run a local mock end-to-end CLI test and compile/import checks.
- [x] If remote resources permit, start a dedicated temporary model process inside `/data4/DATA/wlh/offer/`, forward SSH in-process, send synthetic JPEG/state observations and record real output shape/latency. Terminate only the process started by this validation.
- [x] Document actual results and untested physical behavior. No hardware access or physical motion during this implementation.
