# SO101 真机远程推理客户端

这个目录提供一条面向 SO101 真机的 Windows 客户端链路：本地主机采集双相机 RGB 图像和 6 维关节状态，经 SSH 转发的 WebSocket 发送到远程 Linux 主机上的 OpenPI π0.5 服务，再接收 `H50 x 6` 的绝对关节目标。当前实现可以在没有连接机械臂时完成协议、图像、控制保护和远程模型测试。

`操作手册.md` 只保留架构框图。安装、命令、配置和限制记录在本文档中。

## 目录

- `so101_real/`：客户端、观测源、协议、控制保护和可选 LeRobot 适配器。
- `tests/`：本地单元测试，不打开串口或摄像头。
- `tools/verify.py`：运行测试并保存本地回环报告。
- `tools/remote.py`：使用工作区根目录的 `REMOTE_SERVER.md` 做 SSH 检查和临时远程模型验证，不复制凭据。
- `scripts/ssh-tunnel.ps1`：Windows OpenSSH 本地端口转发。
- `scripts/start-server.sh`：远程模型启动命令模板，复用已有 checkpoint 和运行环境。
- `config.example.json`：配置模板，复制为本地配置后再填写硬件信息。
- `run-client.cmd`：Windows 客户端入口；优先使用本目录 `.venv`，否则使用 `sources/lelab-main/.venv`。
- `run-mock-server.cmd`：仅用于本地协议测试的假服务，不是 VLA 模型。

## 环境

当前已验证的环境是 Python 3.12.10，位于：

```text
D:\2026offer\so101\sources\lelab-main\.venv
```

其中已安装 LeRobot 0.6.0、NumPy 2.2.6、Pillow 12.3.0、MessagePack 1.2.3、websockets 17.3 和 Paramiko 4.0.0。客户端的默认依赖可以单独安装：

```powershell
cd D:\2026offer\so101\So101-Pi0.5-Ball-For-Real
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -U pip
.\.venv\Scripts\python.exe -m pip install -r requirements-client.txt -r requirements-ssh.txt
```

只有要连接真机时才需要 LeRobot 和 Feetech 支持。可以继续使用已经安装 LeRobot 0.6.0 的 `sources/lelab-main\.venv`，也可以在独立环境中安装与现有项目匹配的 LeRobot 版本。远程模型的 JAX、OpenPI 和模型权重留在 Linux 服务器上，Windows 不需要安装 JAX。

安装后检查：

```powershell
.\run-client.cmd check-config
python tools/verify.py
```

如果单独创建了本目录 `.venv`，上面的 `run-client.cmd` 会自动优先使用它。

## 先做本地无硬件测试

打开 PowerShell 窗口一，启动本地协议测试服务：

```powershell
cd D:\2026offer\so101\So101-Pi0.5-Ball-For-Real
.\run-mock-server.cmd
```

记住它输出的端口，默认是 `16006`。再打开 PowerShell 窗口二：

```powershell
cd D:\2026offer\so101\So101-Pi0.5-Ball-For-Real
.\run-client.cmd --url ws://127.0.0.1:16006 probe
.\run-client.cmd --url ws://127.0.0.1:16006 run --simulate-execution --chunks 3 --max-steps 12 --output results/mock-run.json
```

模拟执行会使用合成 RGB 图像和合成关节状态，并经过与真机相同的限位、限速、状态漂移和停止逻辑，但不会打开串口、摄像头或电机。

生成和回放一组保存的观测：

```powershell
.\run-client.cmd capture --source synthetic --output results/captures/demo
.\run-client.cmd --url ws://127.0.0.1:16006 run --source saved `
  --capture-dir results/captures/demo --output results/saved-run.json
```

保存目录必须不存在，程序不会覆盖已有采集目录。

## 远程 OpenPI 服务

远程服务器已经有以下运行时和模型目录，客户端不需要把 ROS 2 或 MuJoCo 容器搬到 Windows：

```text
/data4/DATA/wlh/offer/pi05-so101-three-ball-order
```

服务器端启动真实服务的核心命令如下。请在服务器上执行，GPU 编号按实际空闲设备调整；不要把这里的服务端口直接暴露到公网。

```bash
cd /data4/DATA/wlh/offer/pi05-so101-three-ball-order
source runtime/scripts/inference_env.sh
python runtime/scripts/serve_so101.py \
  --config pi05_so101_three_ball_h50 \
  --checkpoint-dir /data4/DATA/wlh/offer/pi05-so101-three-ball-order/model \
  --port 6006 --noise-seed 0
```

也可以使用本目录的 `scripts/start-server.sh` 作为启动模板。该脚本依赖服务器上已有的 `/data4/DATA/wlh/offer/` 目录结构，不应在 Windows PowerShell 中执行。

服务器服务启动后，在 Windows 保持一个 PowerShell 窗口运行 SSH 转发：

```powershell
cd D:\2026offer\so101\So101-Pi0.5-Ball-For-Real
.\scripts\ssh-tunnel.ps1
```

脚本从工作区根目录 `D:\2026offer\REMOTE_SERVER.md` 读取 SSH 的主机、端口和用户名，默认把本地 `127.0.0.1:16006` 转发到远程 `127.0.0.1:6006`。转发窗口必须保持打开。也可以指定端口：

```powershell
.\scripts\ssh-tunnel.ps1 -LocalPort 16016 -RemotePort 6006
```

然后用真实模型做不执行动作的检查：

```powershell
.\run-client.cmd --url ws://127.0.0.1:16006 probe
.\run-client.cmd --url ws://127.0.0.1:16006 run --chunks 2 --output results/remote-synthetic.json
```

第二条命令发送合成图像和状态，只接收动作并写报告，不会连接机械臂。服务返回的 metadata 必须匹配 `pi05_so101_three_ball_h50`、动作长度 50、动作维度 6 和 JPEG 传输格式。

## 配置

复制模板：

```powershell
Copy-Item config.example.json config.local.json
```

需要硬件时至少填写：

```json
{
  "hardware": {
    "port": "COM7",
    "calibration_file": "calibration/so101.json",
    "use_degrees": false,
    "front": {"index": 1, "width": 640, "height": 480, "fps": 30, "backend": "DSHOW"},
    "side": {"index": 2, "width": 640, "height": 480, "fps": 30, "backend": "DSHOW"}
  }
}
```

`calibration_file` 相对 `config.local.json` 解析。标定文件必须包含 SO101 的六个关节，电机 ID 为 1 到 6，并且与当前电机寄存器一致。程序不会自动标定、覆盖或清空标定文件。相机索引、视角和图像内容也必须与训练数据约定一致；这里的 `side` 只是第二个相机名称，不会自动变成腕部相机。

检查配置不会打开设备：

```powershell
.\run-client.cmd --config config.local.json check-config
```

本项目沿用训练链路的归一化单位：前五个关节为 `[-100, 100]`，夹爪为 `[0, 100]`，`use_degrees` 必须为 `false`。远程服务已经完成反归一化并返回绝对目标，客户端不会再次 rebase 或把动作当作增量。

## 真机接入阶段

当前没有连接过真机。接入时建议按下面顺序推进。

第一步只读取相机和关节状态，不发送动作：

```powershell
.\run-client.cmd --config config.local.json capture --source hardware --output results/captures/hardware-check
```

第二步连接真实模型，但仍然只采集、推理和写报告：

```powershell
.\run-client.cmd --config config.local.json --url ws://127.0.0.1:16006 `
  run --source hardware --chunks 1 --output results/hardware-readonly.json
```

只有在标定、相机画面、动作范围和急停流程都人工确认后，才显式使用执行开关。下面只发送一个动作步：

```powershell
.\run-client.cmd --config config.local.json --url ws://127.0.0.1:16006 `
  run --source hardware --execute --chunks 1 --max-steps 1 --output results/hardware-one-step.json
```

`--execute` 是唯一允许动作写入的分支，并且必须同时指定 `--source hardware`。连接时会检查位置模式，读取当前 Present Position，将第一个目标初始化到当前状态附近，再启用扭矩；默认在执行连接结束时关闭扭矩。只读模式不会调用 `SO101Follower.connect()`、不会配置电机、不会写 Goal Position，也不会写扭矩寄存器。

真实模型首次推理可能触发 JAX 编译。已验证的第一次合成请求约 4.58 秒，第二次约 0.205 秒；默认观测有效期是 2 秒，所以第一次推理不应直接用于真机动作。先做一次只读预热，再单独启动执行流程。不要仅为绕过这个保护而盲目放宽有效期。

## 保护和已知限制

- WebSocket 连接、接收、消息大小和请求时间都有上限；超时连接会关闭，避免把迟到动作交给下一次观测。
- 客户端校验双 JPEG、六维有限状态、`50 x 6` 有限动作、metadata、观测年龄、推理期间状态漂移、目标范围、单步变化量和跟踪误差。
- 执行采用小段 receding horizon，每段重新观测；串口发送变慢时不会补发积压动作，通信或跟踪错误会停止本轮。
- 默认安全范围是前五轴 `[-100, 100]`、夹爪 `[0, 100]`。真实模型验证中曾产生 `104.58` 左右的超范围目标，客户端会拒绝这类动作；这说明模型输出和具体真机安全范围仍需单独校准。
- 当前没有实现电机电流监控、碰撞检测、独立急停、夹爪力控或任务成功判定。不得把这个客户端当成完整的工业安全控制器。
- 摄像头帧和关节状态必须在 150 ms 内对齐，超过 500 ms 的帧会被拒绝。训练输入是 640 x 480、30 FPS 图像并统一 padding 到 224 x 224 JPEG。
- 远程服务复用现有 OpenPI checkpoint；本项目不修改 checkpoint，也不自动把 ROS 2 仿真控制器转换成真机控制器。

## 验证记录

已完成的本地验证：

```powershell
python tools/verify.py
```

结果保存在：

- `results/verification-summary.json`：42 项测试通过，0 失败，0 错误；没有连接硬件，物理动作数为 0。
- `results/local-loopback.json`：本地 mock 服务 3 个推理块、12 个模拟动作。
- `results/unit-tests.log`：详细测试日志。

已完成的远程验证使用 Windows Paramiko SSH 转发和 GPU 上的真实 OpenPI 服务，发送的是合成图像与状态，未执行硬件动作：

- 两次返回均为有限的 `(50, 6)` 动作。
- 第一次往返约 4.576 秒，第二次约 0.205 秒。
- 相同输入和固定噪声下两次动作最大差异为 0。
- 临时服务进程已停止，远程验证端口已释放。
- 该测试证明传输和模型推理链路可用，不证明相机标定、机械臂动作安全或任务成功。
