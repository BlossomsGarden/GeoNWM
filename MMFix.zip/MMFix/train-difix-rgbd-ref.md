# MMFix RGB-D Reference 微调记录

MMFix 基于本地 `/data4/DATA/wlh/Difix3D+/model/nvidia_difix_ref` 做微调，不从 Turbo Diffusion 重新开始。模型通过 `/data4/DATA/wlh/Difix3D+/code/src/pipeline_difix.py` 加载 checkpoint 自带的 custom UNet/VAE；UNet 的 self-attention 使用 NVIDIA Difix-ref 的实现，把两个 view 的空间 token 合并到同一序列，decoder 仍分别恢复两个 view。

## 双视角 RGB-D 组织

每个样本固定包含两个 view：view 0 是经过 offset 的待修复帧，view 1 是同 scene、同 camera 的真实时间参考帧。RGB 和 depth 在每个 view 内分别经过同一个 VAE encoder，再拼成 8 通道 latent，并拼接一个 latent-resolution mask，UNet 输入为 9 通道；UNet 输出 8 通道，拆成 RGB 和 depth latent 后分别解码。参考帧的 target 就是参考帧本身，mask 恒为全 0，因此参考 view 既参与 self-attention，也约束模型不要破坏已知参考内容。

训练参考帧从 CSV 的 `frame_id` 选择同视角 `-4、-2、+2、+4` 中的一个。目标帧必须拥有同 scene、同 camera 的全部四个候选，否则从训练集过滤掉。选择由 `global_seed + epoch + sample_id` 决定，跨 worker 可复现，并与空间 offset 独立。参考帧不做 warp。

## 深度与投影语义

原始深度文件中的无效值先填为 `100m`，作为天空等有意保留的远背景代理用于投影，但原始 `source_valid` 始终保留并用于监督。offset 投影新产生的不可见区域使用 `depth=0`、`valid=false`、`mask=true`，不会把这些新空洞当作 100m 的有效 3D 点。

训练样本使用 double project 构造有监督的 target；验证和推理使用 single project：从原始 RGB-D 只做一次 offset 投影，把未 warp 的原始 RGB-D 作为 reference。验证没有 GT 和指标，只随机选择验证帧，渲染六个 camera 的四种 offset，并保存 RGB、depth、mask、reference 和 prediction 的拼接图。模型输出不做 mask 外 hard composite，允许模型修正已知区域中的小失真。

## VAE、UNet 与三种 depth skip 模式

RGB 和 depth 共用 VAE 主体及同一组 VAE LoRA。UNet `conv_in` 的 RGB 四通道和 depth 四通道都由原 RGB 权重复制并乘 `0.5`，mask 通道 zero-init；`conv_out` 的 RGB、depth 两半都复制原 RGB 输出权重。VAE decoder 额外建立四层普通 depth skip conv，初始化为对应 RGB skip 的 `0.5` 倍，只在初始化时缩放。depth skip 的学习率默认是 UNet 学习率的 `0.5`，共享 VAE LoRA 使用单独的 `--learning_rate_vae_lora`。

训练入口通过 `--scheme` 提供三种可比模式，数据、checkpoint 和其余超参数保持一致：`main` 保留 depth skip；`a` 保留 depth skip，但每层 skip activation 乘以 `1 - maxpool(mask)`；`b` 关闭 depth skip。模式写入 checkpoint，加载时会校验 checkpoint 与启动参数一致，避免把 A/B 权重误加载到主方案。

深度使用 log-depth 归一化。损失在 source-valid 区域计算 full-view log L1、AbsRel 和梯度项，并在 view 0 的 repair mask 内增加对应项；RGB 对两个 view 做全图损失，只对 view 0 额外计算 repair-mask 损失。训练日志记录各项 loss、GPU 显存和迭代速度，eval 后更新 loss 曲线。

## 远程运行

远程使用 `difix` 环境。深度文件固定读取 `/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth`；文件原始分辨率为 `480x832`，dataset 在送入模型前与 RGB 一起对齐到训练分辨率 `576x1024`。三种启动方式分别为：

```bash
bash scripts/launch_main.sh
bash scripts/launch_a.sh
bash scripts/launch_b.sh
```

如需单卡测试，可固定使用空闲卡并覆盖脚本默认值：

```bash
CUDA_VISIBLE_DEVICES=5 NUM_GPUS=1 bash scripts/launch_main.sh
```

当前远端验证已通过全部 `py_compile` 和 9 个项目测试；真实 `nvidia_difix_ref` 初始化确认了 custom UNet/VAE、9→8 通道、双视角 attention patch、四层 0.5 倍 depth skip 以及共享 VAE LoRA。使用新 `480x832` depth root 在 GPU 5 的 24GB RTX 4090 上以正式 `576x1024`、双 view 启动了 1-step smoke，数据、模型和 optimizer 均完成初始化并进入训练 loop，随后在 VAE decoder 反向传播时因额外申请 288 MiB 发生 CUDA OOM。该结果只记录为 24GB 测试卡的显存边界，没有为它修改分辨率、网络结构或训练方案；正式训练目标仍是 8xH200。
