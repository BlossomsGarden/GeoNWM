#!/usr/bin/env bash
set -eo pipefail

PROJECT_DIR="${PROJECT_DIR:-/data4/DATA/wlh/Difix3D+}"
MMFIX_DIR="${MMFIX_DIR:-${PROJECT_DIR}/MMFix}"
CONDA_DIR="${CONDA_DIR:-/data/wlh/miniconda3}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-difix}"
SCHEME="${SCHEME:-main}"

source "${CONDA_DIR}/etc/profile.d/conda.sh"
conda activate "${CONDA_ENV_NAME}"

export HF_HOME="${HF_HOME:-${PROJECT_DIR}/model/.hf_cache}"
export PYTHONPATH="${MMFIX_DIR}/src:${PROJECT_DIR}/code/src:${PYTHONPATH:-}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
NUM_GPUS="${NUM_GPUS:-8}"
MAIN_PROCESS_PORT="${MAIN_PROCESS_PORT:-29527}"
GRAD_ACCUM_STEPS="${GRAD_ACCUM_STEPS:-1}"
RUN_NAME="${RUN_NAME:-rgbd_ref_${SCHEME}_$(date +%Y%m%d_%H%M%S)}"
OUTPUT_DIR="${OUTPUT_DIR:-${PROJECT_DIR}/outputs/mmfix/${RUN_NAME}}"
mkdir -p "${OUTPUT_DIR}"
cd "${MMFIX_DIR}"

LAUNCH_ARGS=(--mixed_precision=bf16 --main_process_port "${MAIN_PROCESS_PORT}" --num_processes "${NUM_GPUS}")
if [[ "${NUM_GPUS}" -gt 1 ]]; then
  LAUNCH_ARGS+=(--multi_gpu)
fi

accelerate launch "${LAUNCH_ARGS[@]}" train_rgbd_ref.py \
  --scheme "${SCHEME}" \
  --output_dir "${OUTPUT_DIR}" \
  --train_csv "${PROJECT_DIR}/nuscenes_train_samples.csv" \
  --val_csv "${PROJECT_DIR}/nuscenes_val_samples.csv" \
  --nuscenes_root /data2/DATA/AutoDrive/nuscenes/v1.0-trainval \
  --depth_root /data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth \
  --pretrained_model_dir "${PROJECT_DIR}/model/nvidia_difix_ref" \
  --difix3d_src "${PROJECT_DIR}/code/src" \
  --height 576 --width 1024 --camera all \
  --train_batch_size 1 --gradient_accumulation_steps "${GRAD_ACCUM_STEPS}" \
  --max_train_steps 10000 --learning_rate_unet 2e-5 --learning_rate_vae_lora 1e-5 \
  --lr_warmup_steps 500 --lambda_l2 1.0 --lambda_lpips 1.0 --lambda_gram 0.2 --lambda_mask 2.0 \
  --lambda_depth_start 0.5 --lambda_depth 1.0 --lambda_depth_warmup_steps 2000 \
  --lambda_depth_gradient 0.1 --lambda_depth_mask_gradient 0.2 \
  --checkpointing_steps 1000 --eval_freq 1000 --num_eval_frames 10 \
  --dataloader_num_workers 4 --log_steps 10 --timestep 199 --mixed_precision bf16 \
  --enable_xformers_memory_efficient_attention --gradient_checkpointing --allow_tf32 --set_grads_to_none \
  --report_to none "$@"
