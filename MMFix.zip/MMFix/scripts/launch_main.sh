#!/usr/bin/env bash
set -eo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCHEME=main bash "${SCRIPT_DIR}/launch_train_rgbd_ref.sh" "$@"
