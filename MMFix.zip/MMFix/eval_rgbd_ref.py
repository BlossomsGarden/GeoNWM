#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import torch
from accelerate import Accelerator

from difixmm.dataset_nuscenes import DEFAULT_PROMPT, NuScenesOffsetDataset
from difixmm.modeling import create_rgbd_ref_model, load_stage2_checkpoint
from train_rgbd_ref import ensure_dirs, run_eval


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run qualitative single-project RGB-D reference evaluation.")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--val_csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv")
    parser.add_argument("--nuscenes_root", default="/data2/DATA/AutoDrive/nuscenes/v1.0-trainval")
    parser.add_argument("--nuscenes_version_dir", default=None)
    parser.add_argument("--depth_root", default="/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth")
    parser.add_argument("--pretrained_model_dir", default="/data4/DATA/wlh/Difix3D+/model/nvidia_difix_ref")
    parser.add_argument("--difix3d_src", default="/data4/DATA/wlh/Difix3D+/code/src")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--prompt", default=DEFAULT_PROMPT)
    parser.add_argument("--height", type=int, default=576)
    parser.add_argument("--width", type=int, default=1024)
    parser.add_argument("--camera", default="all")
    parser.add_argument("--depth_max", type=float, default=120.0)
    parser.add_argument("--invalid_depth_fill", type=float, default=100.0)
    parser.add_argument("--max_val_frames", type=int, default=None)
    parser.add_argument("--num_eval_frames", type=int, default=10)
    parser.add_argument("--eval_seed", type=int, default=42)
    parser.add_argument("--mixed_precision", default="bf16", choices=["no", "fp16", "bf16"])
    parser.add_argument("--timestep", type=int, default=199)
    parser.add_argument("--scheme", default="main", choices=["main", "a", "b"])
    return parser.parse_args()


def main(args: argparse.Namespace) -> None:
    accelerator = Accelerator(mixed_precision=None if args.mixed_precision == "no" else args.mixed_precision)
    dirs = ensure_dirs(Path(args.output_dir))
    model = create_rgbd_ref_model(
        scheme=args.scheme,
        pretrained_model_dir=args.pretrained_model_dir,
        difix3d_src=args.difix3d_src,
        timestep=args.timestep,
    )
    load_stage2_checkpoint(model, args.checkpoint)
    weight_dtype = torch.float32
    if accelerator.mixed_precision == "fp16":
        weight_dtype = torch.float16
    elif accelerator.mixed_precision == "bf16":
        weight_dtype = torch.bfloat16
    model.to(accelerator.device, dtype=weight_dtype)

    val_dataset = NuScenesOffsetDataset(
        csv_path=args.val_csv,
        nuscenes_root=args.nuscenes_root,
        depth_root=args.depth_root,
        split="val",
        tokenizer=model.tokenizer,
        height=args.height,
        width=args.width,
        prompt=args.prompt,
        camera=args.camera,
        nuscenes_version_dir=args.nuscenes_version_dir,
        depth_max=args.depth_max,
        invalid_depth_fill=args.invalid_depth_fill,
        max_frames=args.max_val_frames,
        retry_on_error=False,
        global_seed=args.eval_seed,
        require_temporal_references=False,
    )
    summary = run_eval(
        accelerator,
        model,
        val_dataset,
        None,
        args,
        global_step=0,
        weight_dtype=weight_dtype,
        dirs=dirs,
    )
    with (Path(args.output_dir) / "standalone_eval_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main(parse_args())
