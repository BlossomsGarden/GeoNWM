#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import gc
import json
import math
import random
import sys
import time
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import lpips
import numpy as np
import torch
import torch.nn.functional as F
import torchvision
from accelerate import Accelerator
from accelerate.utils import set_seed
from diffusers.optimization import get_scheduler
from diffusers.utils.import_utils import is_xformers_available
from PIL import Image, ImageDraw, ImageFont
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.transforms.functional import crop
from tqdm.auto import tqdm

from difixmm.dataset_nuscenes import CAMERA_ORDER, DEFAULT_PROMPT, NuScenesOffsetDataset, short_camera_name
from difixmm.losses import (
    full_l2_loss,
    gram_loss,
    lpips_loss,
    masked_absrel_loss,
    masked_l1_loss,
    masked_l2_loss,
    masked_lpips_loss,
    masked_rmse,
    masked_gradient_l1_loss,
)
from difixmm.modeling import (
    MaskGuidedRGBDRefDifix,
    create_rgbd_model,
    load_stage2_checkpoint,
    save_inference_checkpoint,
    save_resume_checkpoint,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train two-view Difix-ref RGB-D completion.")

    parser.add_argument("--train_csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_train_samples.csv")
    parser.add_argument("--val_csv", default="/data4/DATA/wlh/Difix3D+/nuscenes_val_samples.csv")
    parser.add_argument("--nuscenes_root", default="/data2/DATA/AutoDrive/nuscenes/v1.0-trainval")
    parser.add_argument("--nuscenes_version_dir", default=None)
    parser.add_argument("--depth_root", default="/data/wlh/MoGe-2/outputs/nuscenes_moge2_depth_480x832_fp16/align_depth")
    parser.add_argument("--pretrained_model_dir", default="/data4/DATA/wlh/Difix3D+/model/nvidia_difix_ref")
    parser.add_argument("--difix3d_src", default="/data4/DATA/wlh/Difix3D+/code/src")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--prompt", default=DEFAULT_PROMPT)
    parser.add_argument("--height", type=int, default=576)
    parser.add_argument("--width", type=int, default=1024)
    parser.add_argument("--camera", default="all")
    parser.add_argument("--depth_max", type=float, default=120.0)
    parser.add_argument("--invalid_depth_fill", type=float, default=100.0)
    parser.add_argument("--max_train_frames", type=int, default=None)
    parser.add_argument("--max_val_frames", type=int, default=None)

    parser.add_argument("--lambda_l2", default=1.0, type=float)
    parser.add_argument("--lambda_lpips", default=1.0, type=float)
    parser.add_argument("--lambda_gram", default=0.2, type=float)
    parser.add_argument("--lambda_mask", default=2.0, type=float)
    parser.add_argument("--lambda_depth", default=1.0, type=float)
    parser.add_argument("--lambda_depth_start", default=0.5, type=float)
    parser.add_argument("--lambda_depth_warmup_steps", default=2000, type=int)
    parser.add_argument("--lambda_depth_l1", default=1.0, type=float)
    parser.add_argument("--lambda_depth_absrel", default=0.25, type=float)
    parser.add_argument("--lambda_depth_mask_l1", default=2.0, type=float)
    parser.add_argument("--lambda_depth_mask_absrel", default=0.25, type=float)
    parser.add_argument("--lambda_depth_gradient", default=0.1, type=float)
    parser.add_argument("--lambda_depth_mask_gradient", default=0.2, type=float)
    parser.add_argument("--lpips_height", default=288, type=int)
    parser.add_argument("--lpips_width", default=512, type=int)
    parser.add_argument("--gram_loss_warmup_steps", default=2000, type=int)
    parser.add_argument("--gram_crop_size", default=400, type=int)
    parser.add_argument("--allow_random_vgg_for_gram", action="store_true")
    parser.add_argument("--scheme", default="main", choices=["main", "a", "b"])

    parser.add_argument("--train_batch_size", type=int, default=1)
    parser.add_argument("--dataloader_num_workers", type=int, default=4)
    parser.add_argument("--num_training_epochs", type=int, default=100)
    parser.add_argument("--max_train_steps", type=int, default=10000)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--gradient_checkpointing", action="store_true")
    parser.add_argument("--learning_rate_unet", type=float, default=2e-5)
    parser.add_argument("--learning_rate_vae_lora", type=float, default=1e-5)
    parser.add_argument("--learning_rate_depth_skip_conv", type=float, default=None)
    parser.add_argument("--lr_scheduler", type=str, default="constant_with_warmup")
    parser.add_argument("--lr_warmup_steps", type=int, default=500)
    parser.add_argument("--lr_num_cycles", type=int, default=1)
    parser.add_argument("--lr_power", type=float, default=1.0)
    parser.add_argument("--adam_beta1", type=float, default=0.9)
    parser.add_argument("--adam_beta2", type=float, default=0.999)
    parser.add_argument("--adam_weight_decay", type=float, default=1e-2)
    parser.add_argument("--adam_epsilon", type=float, default=1e-8)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--allow_tf32", action="store_true")
    parser.add_argument("--mixed_precision", default="bf16", choices=["no", "fp16", "bf16"])
    parser.add_argument("--enable_xformers_memory_efficient_attention", action="store_true")
    parser.add_argument("--set_grads_to_none", action="store_true")
    parser.add_argument("--timestep", type=int, default=199)

    parser.add_argument("--log_steps", type=int, default=10)
    parser.add_argument("--checkpointing_steps", type=int, default=1000)
    parser.add_argument("--eval_freq", type=int, default=1000)
    parser.add_argument("--num_eval_frames", type=int, default=10)
    parser.add_argument("--eval_seed", type=int, default=42)
    parser.add_argument("--eval_at_start", action="store_true")
    parser.add_argument("--tracker_project_name", default="difix-mm-rgbd")
    parser.add_argument("--tracker_run_name", default="rgbd_stage1")
    parser.add_argument("--report_to", default="none", choices=["none", "tensorboard", "wandb"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume", default=None)
    return parser.parse_args()


def ensure_dirs(output_dir: Path) -> Dict[str, Path]:
    dirs = {
        "root": output_dir,
        "logs": output_dir / "logs",
        "eval": output_dir / "eval",
        "checkpoints": output_dir / "checkpoints",
        "resume": output_dir / "resume",
    }
    for path in dirs.values():
        path.mkdir(parents=True, exist_ok=True)
    return dirs


def append_csv(path: Path, row: Dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def read_csv_numeric(path: Path) -> List[Dict[str, float]]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            numeric = {}
            for key, value in row.items():
                try:
                    numeric[key] = float(value)
                except (TypeError, ValueError):
                    pass
            rows.append(numeric)
    return rows


def plot_loss_curves(train_csv: Path, eval_csv: Path, output_path: Path) -> None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(f"[plot_loss_curves] matplotlib unavailable: {exc}")
        return

    train_rows = read_csv_numeric(train_csv)
    eval_rows = read_csv_numeric(eval_csv)
    if not train_rows and not eval_rows:
        return

    fig, axes = plt.subplots(3, 1, figsize=(11, 11), sharex=False)
    if train_rows:
        steps = [r["step"] for r in train_rows if "step" in r]
        train_keys = [
            "loss",
            "rgb_loss",
            "loss_l2",
            "loss_lpips",
            "loss_mask_l2",
            "loss_mask_lpips",
            "loss_gram",
            "depth_loss",
        ]
        for key in train_keys:
            values = [r.get(key, math.nan) for r in train_rows]
            if any(math.isfinite(v) for v in values):
                axes[0].plot(steps, values, label=key, linewidth=1.1)
        axes[0].set_title("Train losses")
        axes[0].set_xlabel("step")
        axes[0].grid(True, alpha=0.3)
        axes[0].legend(loc="best", fontsize=8)

    if eval_rows:
        steps = [r["step"] for r in eval_rows if "step" in r]
        for key in ["val_rgb_l2", "val_rgb_lpips", "val_rgb_mask_l2", "val_depth_rmse", "val_depth_absrel"]:
            values = [r.get(key, math.nan) for r in eval_rows]
            if any(math.isfinite(v) for v in values):
                axes[1].plot(steps, values, marker="o", label=key, linewidth=1.1)
        axes[1].set_title("Eval reconstruction")
        axes[1].set_xlabel("step")
        axes[1].grid(True, alpha=0.3)
        axes[1].legend(loc="best", fontsize=8)

        for key in ["val_rgb_psnr", "val_rgb_mask_psnr", "val_rgb_ssim", "val_rgb_mask_ssim"]:
            values = [r.get(key, math.nan) for r in eval_rows]
            if any(math.isfinite(v) for v in values):
                axes[2].plot(steps, values, marker="o", label=key, linewidth=1.1)
        axes[2].set_title("Eval RGB quality")
        axes[2].set_xlabel("step")
        axes[2].grid(True, alpha=0.3)
        axes[2].legend(loc="best", fontsize=8)

    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)


def tensor_to_uint8(tensor: torch.Tensor) -> np.ndarray:
    tensor = tensor.detach().float().cpu().clamp(-1, 1)
    tensor = (tensor * 0.5 + 0.5).clamp(0, 1)
    arr = (tensor.permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)
    return arr


def depth_log_norm_to_meters(depth_log_norm: torch.Tensor, depth_max: float) -> torch.Tensor:
    log01 = (depth_log_norm.float() * 0.5 + 0.5).clamp(0.0, 1.0)
    return torch.expm1(log01 * math.log1p(float(depth_max)))


def depth_meters_to_uint8(depth: torch.Tensor, depth_max: float, valid: torch.Tensor | None = None) -> np.ndarray:
    depth01 = (depth.detach().float().cpu().squeeze(0) / float(depth_max)).clamp(0, 1).numpy()
    gray = ((1.0 - depth01) * 255.0).round().astype(np.uint8)
    if valid is not None:
        valid_arr = valid.detach().float().cpu().squeeze(0).numpy() > 0.5
        gray = np.where(valid_arr, gray, 36).astype(np.uint8)
    return np.stack([gray, gray, gray], axis=-1)


def mask_to_uint8(mask: torch.Tensor) -> np.ndarray:
    mask = mask.detach().float().cpu().squeeze(0).clamp(0, 1)
    arr = (mask.numpy() * 255.0).round().astype(np.uint8)
    return np.stack([arr, arr, arr], axis=-1)


def overlay_mask(rgb: np.ndarray, mask_rgb: np.ndarray) -> np.ndarray:
    mask = mask_rgb[..., 0] > 127
    out = rgb.astype(np.float32).copy()
    out[mask] = out[mask] * 0.35 + np.array([255, 48, 48], dtype=np.float32) * 0.65
    return np.clip(out, 0, 255).astype(np.uint8)


def draw_label(draw: ImageDraw.ImageDraw, xy: tuple[int, int], text: str) -> None:
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None
    draw.text(xy, text, fill=(0, 0, 0), font=font)


def resize_tile(arr: np.ndarray, tile_w: int) -> Image.Image:
    pil = Image.fromarray(arr)
    tile_h = int(round(tile_w * pil.height / pil.width))
    return pil.resize((tile_w, tile_h), Image.BILINEAR)


def save_eval_group_offsets_rgbd_grid(path: Path, offset_blocks: List[tuple[str, List[dict]]], depth_max: float) -> None:
    if not offset_blocks:
        return
    tile_w = 150
    label_h = 20
    section_h = 24
    offset_h = 26
    gap = 5
    cols = 6

    first_rows = sorted(offset_blocks[0][1], key=lambda row: row["camera_idx"])
    if len(first_rows) != len(CAMERA_ORDER):
        return
    sample_tile = resize_tile(tensor_to_uint8(first_rows[0]["target_rgb"]), tile_w)
    tile_h = sample_tile.height
    section_total_h = section_h + 2 * (label_h + tile_h + gap)
    block_h = offset_h + 3 * section_total_h + 3 * gap
    canvas_w = cols * tile_w + (cols + 1) * gap
    canvas_h = len(offset_blocks) * block_h + (len(offset_blocks) + 1) * gap
    canvas = Image.new("RGB", (canvas_w, canvas_h), (245, 246, 248))
    draw = ImageDraw.Draw(canvas)

    sections = [
        ("target RGB + depth", "target_rgb", "target_depth", "target_depth_valid"),
        ("input RGB + depth", "input_rgb", "input_depth", "input_depth_valid"),
        ("prediction RGB + depth", "pred_rgb", "pred_depth", "target_depth_valid"),
    ]
    for block_idx, (offset_label, rows) in enumerate(offset_blocks):
        ordered = sorted(rows, key=lambda row: row["camera_idx"])
        if len(ordered) != len(CAMERA_ORDER):
            continue
        block_y = gap + block_idx * block_h
        draw.rectangle((gap, block_y, canvas_w - gap, block_y + offset_h), fill=(255, 255, 255))
        draw.text((gap + 8, block_y + 8), offset_label, fill=(20, 24, 28))
        for section_idx, (section_title, rgb_key, depth_key, valid_key) in enumerate(sections):
            section_y = block_y + offset_h + gap + section_idx * section_total_h
            draw.rectangle((gap, section_y, canvas_w - gap, section_y + section_h), fill=(255, 255, 255))
            draw.text((gap + 8, section_y + 7), section_title, fill=(20, 24, 28))
            for camera_pos, row in enumerate(ordered):
                grid_row = camera_pos // 3
                grid_col = camera_pos % 3
                y = section_y + section_h + gap + grid_row * (label_h + tile_h + gap)
                x_rgb = gap + grid_col * (tile_w + gap)
                x_depth = gap + (grid_col + 3) * (tile_w + gap)
                label = short_camera_name(row["camera"])
                draw_label(draw, (x_rgb, y), f"{label} RGB")
                draw_label(draw, (x_depth, y), f"{label} depth")
                rgb_arr = tensor_to_uint8(row[rgb_key])
                depth_arr = depth_meters_to_uint8(row[depth_key], depth_max, row[valid_key])
                if rgb_key == "input_rgb":
                    rgb_arr = overlay_mask(rgb_arr, mask_to_uint8(row["mask"]))
                canvas.paste(resize_tile(rgb_arr, tile_w), (x_rgb, y + label_h))
                canvas.paste(resize_tile(depth_arr, tile_w), (x_depth, y + label_h))

    path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(path)


def save_single_project_group_grid(path: Path, offset_blocks: List[tuple[str, List[dict]]], depth_max: float) -> None:
    if not offset_blocks:
        return
    tile_w, label_h, section_h, gap, cols = 150, 20, 24, 5, 6
    first_rows = sorted(offset_blocks[0][1], key=lambda row: row["camera_idx"])
    if len(first_rows) != len(CAMERA_ORDER):
        return
    tile_h = resize_tile(tensor_to_uint8(first_rows[0]["reference_rgb"]), tile_w).height
    section_total_h = section_h + 2 * (label_h + tile_h + gap)
    block_h = 26 + 3 * section_total_h + 3 * gap
    canvas_w = cols * tile_w + (cols + 1) * gap
    canvas_h = len(offset_blocks) * block_h + (len(offset_blocks) + 1) * gap
    canvas = Image.new("RGB", (canvas_w, canvas_h), (245, 246, 248))
    draw = ImageDraw.Draw(canvas)
    sections = [
        ("reference RGB + depth", "reference_rgb", "reference_depth", "reference_depth_valid"),
        ("single-project input RGB + depth", "input_rgb", "input_depth", "input_depth_valid"),
        ("prediction RGB + depth", "pred_rgb", "pred_depth", "pred_depth_valid"),
    ]
    for block_idx, (offset_label, rows) in enumerate(offset_blocks):
        ordered = sorted(rows, key=lambda row: row["camera_idx"])
        if len(ordered) != len(CAMERA_ORDER):
            continue
        block_y = gap + block_idx * block_h
        draw.rectangle((gap, block_y, canvas_w - gap, block_y + 26), fill=(255, 255, 255))
        draw.text((gap + 8, block_y + 8), offset_label, fill=(20, 24, 28))
        for section_idx, (title, rgb_key, depth_key, valid_key) in enumerate(sections):
            section_y = block_y + 26 + gap + section_idx * section_total_h
            draw.rectangle((gap, section_y, canvas_w - gap, section_y + section_h), fill=(255, 255, 255))
            draw.text((gap + 8, section_y + 7), title, fill=(20, 24, 28))
            for camera_pos, row in enumerate(ordered):
                grid_row, grid_col = camera_pos // 3, camera_pos % 3
                y = section_y + section_h + gap + grid_row * (label_h + tile_h + gap)
                x_rgb, x_depth = gap + grid_col * (tile_w + gap), gap + (grid_col + 3) * (tile_w + gap)
                label = short_camera_name(row["camera"])
                draw_label(draw, (x_rgb, y), f"{label} RGB")
                draw_label(draw, (x_depth, y), f"{label} depth")
                rgb_arr = tensor_to_uint8(row[rgb_key])
                if rgb_key == "input_rgb":
                    rgb_arr = overlay_mask(rgb_arr, mask_to_uint8(row["mask"]))
                depth_arr = depth_meters_to_uint8(row[depth_key], depth_max, row[valid_key])
                canvas.paste(resize_tile(rgb_arr, tile_w), (x_rgb, y + label_h))
                canvas.paste(resize_tile(depth_arr, tile_w), (x_depth, y + label_h))
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(path)


def rgb_psnr(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> float:
    pred01 = (pred.float() * 0.5 + 0.5).clamp(0, 1)
    target01 = (target.float() * 0.5 + 0.5).clamp(0, 1)
    sq = (pred01 - target01) ** 2
    if mask is not None:
        mask = mask.float()
        mse = (sq * mask).sum() / (mask.sum() * pred.shape[1] + 1e-8)
    else:
        mse = sq.mean()
    mse = mse.detach().float().clamp_min(1e-10)
    return float((-10.0 * torch.log10(mse)).cpu())


def rgb_ssim(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> float:
    pred01 = (pred.float() * 0.5 + 0.5).clamp(0, 1)
    target01 = (target.float() * 0.5 + 0.5).clamp(0, 1)
    channels = pred01.shape[1]
    window = torch.ones((channels, 1, 11, 11), device=pred01.device, dtype=pred01.dtype) / 121.0
    mu_x = F.conv2d(pred01, window, padding=5, groups=channels)
    mu_y = F.conv2d(target01, window, padding=5, groups=channels)
    sigma_x = F.conv2d(pred01 * pred01, window, padding=5, groups=channels) - mu_x * mu_x
    sigma_y = F.conv2d(target01 * target01, window, padding=5, groups=channels) - mu_y * mu_y
    sigma_xy = F.conv2d(pred01 * target01, window, padding=5, groups=channels) - mu_x * mu_y
    c1 = 0.01**2
    c2 = 0.03**2
    score = ((2 * mu_x * mu_y + c1) * (2 * sigma_xy + c2)) / (
        (mu_x * mu_x + mu_y * mu_y + c1) * (sigma_x + sigma_y + c2)
    )
    score = score.mean(dim=1, keepdim=True)
    if mask is not None:
        mask = mask.float()
        return float(((score * mask).sum() / (mask.sum() + 1e-8)).detach().cpu())
    return float(score.mean().detach().cpu())


def build_vgg_features(args: argparse.Namespace) -> torch.nn.Module | None:
    if args.lambda_gram <= 0:
        return None
    try:
        weights = torchvision.models.VGG16_Weights.IMAGENET1K_V1
        return torchvision.models.vgg16(weights=weights).features
    except Exception as exc:
        if not args.allow_random_vgg_for_gram:
            raise RuntimeError(
                "Could not load pretrained VGG16 weights for gram loss. "
                "Use --allow_random_vgg_for_gram only for smoke tests."
            ) from exc
        print(f"[build_vgg_features] using random VGG16 weights for gram loss because: {exc}")
        return torchvision.models.vgg16(weights=None).features


def current_depth_weight(args: argparse.Namespace, global_step: int) -> float:
    if args.lambda_depth_warmup_steps <= 0:
        return float(args.lambda_depth)
    ratio = min(1.0, max(0.0, float(global_step) / float(args.lambda_depth_warmup_steps)))
    return float(args.lambda_depth_start + (args.lambda_depth - args.lambda_depth_start) * ratio)


def compute_losses(
    pred: dict[str, torch.Tensor],
    batch: dict,
    net_lpips,
    net_vgg,
    t_vgg_renorm,
    args: argparse.Namespace,
    global_step: int,
    weight_dtype: torch.dtype,
) -> tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    pred_rgb = pred["rgb"]
    target_rgb = batch["output_pixel_values"].to(pred_rgb.device, dtype=pred_rgb.dtype)
    mask = batch["mask_pixel_values"].to(pred_rgb.device, dtype=pred_rgb.dtype)
    b, v, _, h, w = pred_rgb.shape
    lpips_size = None
    if args.lpips_height > 0 and args.lpips_width > 0:
        lpips_size = (int(args.lpips_height), int(args.lpips_width))

    flat_pred_rgb = pred_rgb.reshape(b * v, 3, h, w)
    flat_target_rgb = target_rgb.reshape(b * v, 3, h, w)
    loss_l2 = full_l2_loss(flat_pred_rgb, flat_target_rgb) * args.lambda_l2
    loss_lpips = lpips_loss(net_lpips, flat_pred_rgb.float(), flat_target_rgb.float(), lpips_size) * args.lambda_lpips
    raw_mask_l2 = masked_l2_loss(pred_rgb[:, 0].float(), target_rgb[:, 0].float(), mask[:, 0].float())
    raw_mask_lpips = masked_lpips_loss(net_lpips, pred_rgb[:, 0].float(), target_rgb[:, 0].float(), mask[:, 0].float(), lpips_size)
    loss_mask_l2 = raw_mask_l2 * args.lambda_mask
    loss_mask_lpips = raw_mask_lpips * args.lambda_mask

    loss_gram = torch.zeros((), device=pred_rgb.device, dtype=weight_dtype)
    if args.lambda_gram > 0 and net_vgg is not None and global_step >= args.gram_loss_warmup_steps:
        crop_size = min(args.gram_crop_size, h, w)
        top = random.randint(0, h - crop_size)
        left = random.randint(0, w - crop_size)
        pred_renorm = t_vgg_renorm(pred_rgb[:, 0] * 0.5 + 0.5)
        target_renorm = t_vgg_renorm(target_rgb[:, 0] * 0.5 + 0.5)
        pred_crop = crop(pred_renorm, top, left, crop_size, crop_size)
        target_crop = crop(target_renorm, top, left, crop_size, crop_size)
        loss_gram = gram_loss(pred_crop.to(weight_dtype), target_crop.to(weight_dtype), net_vgg) * args.lambda_gram

    rgb_loss = loss_l2 + loss_lpips + loss_mask_l2 + loss_mask_lpips + loss_gram

    pred_depth_log = pred["depth_log"].float()
    target_depth_log = batch["target_depth_log_values"].to(pred_rgb.device, dtype=torch.float32) * 2.0 - 1.0
    target_depth_m = batch["target_depth_meters"].to(pred_rgb.device, dtype=torch.float32)
    target_depth_valid = batch["target_depth_valid_values"].to(pred_rgb.device, dtype=torch.float32)
    repair_depth_valid = (target_depth_valid * mask.float()).clamp(0, 1)
    pred_depth_m = depth_log_norm_to_meters(pred_depth_log, args.depth_max)

    def per_view(fn, values, targets, valid):
        terms = [fn(values[:, i], targets[:, i], valid[:, i]) for i in range(v)]
        return torch.stack(terms).mean()

    loss_depth_l1 = per_view(masked_l1_loss, pred_depth_log, target_depth_log, target_depth_valid) * args.lambda_depth_l1
    loss_depth_absrel = per_view(masked_absrel_loss, pred_depth_m, target_depth_m, target_depth_valid) * args.lambda_depth_absrel
    raw_depth_mask_l1 = masked_l1_loss(pred_depth_log[:, 0], target_depth_log[:, 0], repair_depth_valid[:, 0])
    raw_depth_mask_absrel = masked_absrel_loss(pred_depth_m[:, 0], target_depth_m[:, 0], repair_depth_valid[:, 0])
    loss_depth_mask_l1 = raw_depth_mask_l1 * args.lambda_depth_mask_l1
    loss_depth_mask_absrel = raw_depth_mask_absrel * args.lambda_depth_mask_absrel
    raw_depth_gradient = per_view(masked_gradient_l1_loss, pred_depth_log, target_depth_log, target_depth_valid)
    raw_depth_mask_gradient = masked_gradient_l1_loss(pred_depth_log[:, 0], target_depth_log[:, 0], repair_depth_valid[:, 0])
    loss_depth_gradient = raw_depth_gradient * args.lambda_depth_gradient
    loss_depth_mask_gradient = raw_depth_mask_gradient * args.lambda_depth_mask_gradient
    depth_unweighted = (
        loss_depth_l1 + loss_depth_absrel + loss_depth_mask_l1 + loss_depth_mask_absrel
        + loss_depth_gradient + loss_depth_mask_gradient
    )
    lambda_depth_now = current_depth_weight(args, global_step)
    depth_loss = depth_unweighted * lambda_depth_now
    total = rgb_loss + depth_loss

    logs = {
        "loss": total.detach(),
        "rgb_loss": rgb_loss.detach(),
        "depth_loss": depth_loss.detach(),
        "lambda_depth": torch.tensor(lambda_depth_now, device=pred_rgb.device),
        "loss_l2": loss_l2.detach(),
        "loss_lpips": loss_lpips.detach(),
        "loss_mask_l2": loss_mask_l2.detach(),
        "loss_mask_lpips": loss_mask_lpips.detach(),
        "loss_gram": loss_gram.detach(),
        "loss_depth_l1": loss_depth_l1.detach(),
        "loss_depth_absrel": loss_depth_absrel.detach(),
        "loss_depth_mask_l1": loss_depth_mask_l1.detach(),
        "loss_depth_mask_absrel": loss_depth_mask_absrel.detach(),
        "loss_depth_gradient": loss_depth_gradient.detach(),
        "loss_depth_mask_gradient": loss_depth_mask_gradient.detach(),
        "raw_mask_l2": raw_mask_l2.detach(),
        "raw_mask_lpips": raw_mask_lpips.detach(),
        "raw_depth_mask_l1": raw_depth_mask_l1.detach(),
        "raw_depth_mask_absrel": raw_depth_mask_absrel.detach(),
        "raw_depth_gradient": raw_depth_gradient.detach(),
        "raw_depth_mask_gradient": raw_depth_mask_gradient.detach(),
    }
    return total, logs


@torch.no_grad()
def run_eval(
    accelerator: Accelerator,
    model: MaskGuidedRGBDRefDifix,
    val_dataset: NuScenesOffsetDataset,
    net_lpips,
    args: argparse.Namespace,
    global_step: int,
    weight_dtype: torch.dtype,
    dirs: Dict[str, Path],
) -> Dict[str, float]:
    unwrapped = accelerator.unwrap_model(model)
    unwrapped.set_eval()
    rng = random.Random(args.eval_seed)
    group_count = len(val_dataset.frame_groups)
    if group_count <= 0:
        raise RuntimeError("Evaluation requires complete six-camera frame groups in the validation CSV")
    group_indices = rng.sample(range(group_count), k=min(args.num_eval_frames, group_count))
    step_dir = dirs["eval"] / f"step_{global_step:06d}"
    step_dir.mkdir(parents=True, exist_ok=True)

    rendered_groups = 0
    for group_idx in group_indices:
        group_records = [val_dataset.records[i] for i in val_dataset.frame_groups[int(group_idx)]]
        frame_id = group_records[0].frame_id if group_records else group_idx
        scene_id = group_records[0].scene_id if group_records else -1
        offset_blocks: List[tuple[str, List[dict]]] = []
        for offset_idx, (direction, meters) in enumerate(val_dataset.offsets):
            six_rows: List[dict] = []
            for record_idx in val_dataset.frame_groups[int(group_idx)]:
                record = val_dataset.records[int(record_idx)]
                item = val_dataset.get_single_project_item_by_frame_offset(record_idx, offset_idx)
                x_rgb = item["conditioning_pixel_values"].unsqueeze(0).to(accelerator.device, dtype=weight_dtype)
                x_depth = item["conditioning_depth_pixel_values"].unsqueeze(0).to(accelerator.device, dtype=weight_dtype)
                mask = item["mask_pixel_values"].unsqueeze(0).to(accelerator.device, dtype=weight_dtype)
                input_ids = item["input_ids"].unsqueeze(0).to(accelerator.device)
                pred = unwrapped(x_rgb, x_depth, mask, prompt_tokens=input_ids)
                pred_rgb = pred["rgb"][0, 0].detach().cpu()
                pred_depth_m = depth_log_norm_to_meters(pred["depth_log"][0, 0].detach().cpu(), args.depth_max)

                six_rows.append(
                    {
                        "camera": record.camera,
                        "camera_idx": int(item["camera_idx"].item()),
                        "input_rgb": item["input_rgb"],
                        "input_depth": item["input_depth_meters"],
                        "input_depth_valid": item["input_depth_valid"],
                        "reference_rgb": item["reference_rgb"],
                        "reference_depth": item["reference_depth_meters"],
                        "reference_depth_valid": item["reference_depth_valid"],
                        "pred_rgb": pred_rgb,
                        "pred_depth": pred_depth_m,
                        "pred_depth_valid": torch.ones_like(item["input_depth_valid"]),
                        "mask": item["mask_pixel_values"][0],
                    }
                )
            offset_blocks.append((f"{direction} {meters:g}m", six_rows))
            save_single_project_group_grid(
                step_dir
                / f"scene{int(scene_id):03d}_frame{int(frame_id):06d}_{direction}_{meters:g}m_rgbd.png",
                [(f"{direction} {meters:g}m", six_rows)],
                args.depth_max,
            )

        save_single_project_group_grid(
            step_dir / f"scene{int(scene_id):03d}_frame{int(frame_id):06d}_all_offsets_rgbd.png",
            offset_blocks,
            args.depth_max,
        )
        rendered_groups += 1

    metrics = {"step": int(global_step), "val_single_project_groups": float(rendered_groups)}
    with (step_dir / "qualitative_summary.json").open("w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    plot_loss_curves(dirs["logs"] / "train_metrics.csv", dirs["logs"] / "eval_metrics.csv", dirs["logs"] / "loss_curve.png")
    unwrapped.set_train()
    gc.collect()
    torch.cuda.empty_cache()
    return metrics


def main(args: argparse.Namespace) -> None:
    log_with = None if args.report_to == "none" else args.report_to
    accelerator = Accelerator(
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        mixed_precision=None if args.mixed_precision == "no" else args.mixed_precision,
        log_with=log_with,
    )
    if args.seed is not None:
        set_seed(args.seed)
    if args.allow_tf32:
        torch.backends.cuda.matmul.allow_tf32 = True

    output_dir = Path(args.output_dir)
    dirs = ensure_dirs(output_dir)

    if accelerator.is_main_process:
        with (output_dir / "args.json").open("w", encoding="utf-8") as f:
            json.dump(vars(args), f, indent=2, sort_keys=True)

    model = create_rgbd_model(
        scheme=args.scheme,
        pretrained_model_dir=args.pretrained_model_dir,
        difix3d_src=args.difix3d_src,
        timestep=args.timestep,
    )
    if args.enable_xformers_memory_efficient_attention:
        if not is_xformers_available():
            raise RuntimeError("xformers is not available")
        model.unet.enable_xformers_memory_efficient_attention()
    if args.gradient_checkpointing:
        model.unet.enable_gradient_checkpointing()
        if hasattr(model.vae, "enable_gradient_checkpointing"):
            model.vae.enable_gradient_checkpointing()

    train_dataset = NuScenesOffsetDataset(
        csv_path=args.train_csv,
        nuscenes_root=args.nuscenes_root,
        depth_root=args.depth_root,
        split="train",
        tokenizer=model.tokenizer,
        height=args.height,
        width=args.width,
        prompt=args.prompt,
        camera=args.camera,
        nuscenes_version_dir=args.nuscenes_version_dir,
        depth_max=args.depth_max,
        invalid_depth_fill=args.invalid_depth_fill,
        max_frames=args.max_train_frames,
        global_seed=args.seed,
        require_temporal_references=True,
    )
    val_dataset = NuScenesOffsetDataset(
        csv_path=args.val_csv,
        nuscenes_root=args.nuscenes_root,
        depth_root=args.depth_root,
        split="val",
        tokenizer=model.tokenizer,
        height=args.height,
        width=args.width,
        prompt=args.prompt,
        camera=args.camera,
        nuscenes_version_dir=args.nuscenes_version_dir,
        depth_max=args.depth_max,
        invalid_depth_fill=args.invalid_depth_fill,
        max_frames=args.max_val_frames,
        retry_on_error=False,
        global_seed=args.eval_seed,
        require_temporal_references=False,
    )

    if accelerator.is_main_process:
        summary = {"train": train_dataset.describe(), "val": val_dataset.describe()}
        with (output_dir / "dataset_summary.json").open("w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(json.dumps(summary, indent=2))

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        num_workers=args.dataloader_num_workers,
        pin_memory=True,
        drop_last=True,
    )

    depth_skip_lr = (
        args.learning_rate_unet * 0.5
        if args.learning_rate_depth_skip_conv is None
        else args.learning_rate_depth_skip_conv
    )
    parameter_groups = model.optimizer_parameter_groups(
        lr_unet=args.learning_rate_unet,
        lr_vae_lora=args.learning_rate_vae_lora,
        lr_depth_skip_conv=depth_skip_lr,
    )
    if accelerator.is_main_process:
        group_summary = [
            {"name": group.get("name", "group"), "lr": group["lr"], "params": sum(p.numel() for p in group["params"])}
            for group in parameter_groups
        ]
        print(json.dumps({"optimizer_groups": group_summary}, indent=2))
    optimizer = torch.optim.AdamW(
        parameter_groups,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )
    lr_scheduler = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer,
        num_warmup_steps=args.lr_warmup_steps * accelerator.num_processes,
        num_training_steps=args.max_train_steps * accelerator.num_processes,
        num_cycles=args.lr_num_cycles,
        power=args.lr_power,
    )

    global_step = 0
    if args.resume is not None:
        global_step = load_stage2_checkpoint(model, args.resume, optimizer=optimizer, lr_scheduler=lr_scheduler)
        if accelerator.is_main_process:
            print(f"Resumed from {args.resume} at global_step={global_step}")

    weight_dtype = torch.float32
    if accelerator.mixed_precision == "fp16":
        weight_dtype = torch.float16
    elif accelerator.mixed_precision == "bf16":
        weight_dtype = torch.bfloat16

    model.to(accelerator.device, dtype=weight_dtype)
    net_lpips = lpips.LPIPS(net="vgg").to(accelerator.device)
    net_lpips.requires_grad_(False)
    net_vgg = None
    t_vgg_renorm = transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))

    model, optimizer, train_loader, lr_scheduler = accelerator.prepare(model, optimizer, train_loader, lr_scheduler)
    net_lpips = accelerator.prepare(net_lpips)

    if accelerator.is_main_process and log_with is not None:
        accelerator.init_trackers(args.tracker_project_name, config=vars(args))

    progress_bar = tqdm(
        range(args.max_train_steps),
        initial=global_step,
        desc=f"rgbd-ref-{args.scheme}",
        disable=not accelerator.is_local_main_process,
    )
    last_log_time = time.perf_counter()
    last_log_step = global_step

    if args.eval_at_start:
        accelerator.wait_for_everyone()
        if accelerator.is_main_process:
            run_eval(accelerator, model, val_dataset, net_lpips, args, global_step, weight_dtype, dirs)
        accelerator.wait_for_everyone()

    for _epoch in range(args.num_training_epochs):
        train_dataset.set_epoch(_epoch)
        for batch in train_loader:
            if global_step >= args.max_train_steps:
                break
            gc.collect()
            with accelerator.accumulate(model):
                x_rgb = batch["conditioning_pixel_values"].to(accelerator.device, dtype=weight_dtype)
                x_depth = batch["conditioning_depth_pixel_values"].to(accelerator.device, dtype=weight_dtype)
                mask = batch["mask_pixel_values"].to(accelerator.device, dtype=weight_dtype)
                input_ids = batch["input_ids"].to(accelerator.device)

                pred = model(x_rgb, x_depth, mask, prompt_tokens=input_ids)
                if args.lambda_gram > 0 and net_vgg is None and global_step >= args.gram_loss_warmup_steps:
                    net_vgg = build_vgg_features(args)
                    net_vgg.to(accelerator.device, dtype=weight_dtype)
                    net_vgg.requires_grad_(False)
                loss, loss_logs = compute_losses(
                    pred,
                    batch,
                    net_lpips,
                    net_vgg,
                    t_vgg_renorm,
                    args,
                    global_step,
                    weight_dtype,
                )
                accelerator.backward(loss)
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], args.max_grad_norm)
                optimizer.step()
                lr_scheduler.step()
                optimizer.zero_grad(set_to_none=args.set_grads_to_none)

            if not accelerator.sync_gradients:
                continue

            global_step += 1
            progress_bar.update(1)

            should_log = global_step == 1 or global_step % args.log_steps == 0
            if should_log and accelerator.is_main_process:
                now = time.perf_counter()
                steps_delta = max(1, global_step - last_log_step)
                elapsed = max(1e-6, now - last_log_time)
                iter_per_sec = steps_delta / elapsed
                last_log_time = now
                last_log_step = global_step
                mem_alloc = torch.cuda.max_memory_allocated(accelerator.device) / (1024**2) if torch.cuda.is_available() else 0.0
                mem_reserved = torch.cuda.max_memory_reserved(accelerator.device) / (1024**2) if torch.cuda.is_available() else 0.0
                row = {
                    "step": int(global_step),
                    "lr_unet": float(optimizer.param_groups[0]["lr"]),
                    "iter_per_sec": float(iter_per_sec),
                    "gpu_mem_alloc_mb": float(mem_alloc),
                    "gpu_mem_reserved_mb": float(mem_reserved),
                    "mask_ratio": float(batch["mask_ratio"].float().mean().detach().cpu()),
                }
                for key, value in loss_logs.items():
                    row[key] = float(value.detach().float().cpu())
                append_csv(dirs["logs"] / "train_metrics.csv", row)
                progress_bar.set_postfix({k: f"{v:.4g}" for k, v in row.items() if k in {"loss", "rgb_loss", "depth_loss"}})
                accelerator.log(row, step=global_step)
                torch.cuda.reset_peak_memory_stats(accelerator.device)

            do_checkpoint = args.checkpointing_steps > 0 and global_step % args.checkpointing_steps == 0
            do_eval = args.eval_freq > 0 and global_step % args.eval_freq == 0

            if do_checkpoint:
                accelerator.wait_for_everyone()
                if accelerator.is_main_process:
                    unwrapped = accelerator.unwrap_model(model)
                    save_inference_checkpoint(unwrapped, dirs["checkpoints"] / f"model_{global_step:06d}.pkl")
                    save_resume_checkpoint(unwrapped, optimizer, lr_scheduler, global_step, dirs["resume"] / f"resume_{global_step:06d}.pt")
                accelerator.wait_for_everyone()

            if do_eval:
                accelerator.wait_for_everyone()
                if accelerator.is_main_process:
                    metrics = run_eval(accelerator, model, val_dataset, net_lpips, args, global_step, weight_dtype, dirs)
                    accelerator.log(metrics, step=global_step)
                accelerator.wait_for_everyone()

            if global_step >= args.max_train_steps:
                break
        if global_step >= args.max_train_steps:
            break

    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        unwrapped = accelerator.unwrap_model(model)
        save_inference_checkpoint(unwrapped, dirs["checkpoints"] / f"model_{global_step:06d}_final.pkl")
        save_resume_checkpoint(unwrapped, optimizer, lr_scheduler, global_step, dirs["resume"] / f"resume_{global_step:06d}_final.pt")
        plot_loss_curves(dirs["logs"] / "train_metrics.csv", dirs["logs"] / "eval_metrics.csv", dirs["logs"] / "loss_curve.png")
        print(f"Training complete at step {global_step}. Output: {output_dir}")
    accelerator.end_training()


if __name__ == "__main__":
    main(parse_args())
