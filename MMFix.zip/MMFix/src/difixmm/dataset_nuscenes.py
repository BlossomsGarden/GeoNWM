from __future__ import annotations

import csv
import random
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from PIL import Image

from .geometry import (
    DEPTH_EPS,
    generate_offset_supervision,
    generate_single_project_input,
    scale_intrinsics,
    transform_from_translation_rotation,
)


CAMERA_ORDER: Tuple[str, ...] = (
    "CAM_FRONT_LEFT",
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_LEFT",
    "CAM_BACK",
    "CAM_BACK_RIGHT",
)

DEFAULT_OFFSETS: Tuple[Tuple[str, float], ...] = (
    ("left", 1.0),
    ("left", 2.0),
    ("right", 1.0),
    ("right", 2.0),
)

DEFAULT_PROMPT = "Complete the distorted and invisible regions in this RGB image and depth map."


@dataclass(frozen=True)
class NuScenesFrameRecord:
    row_id: str
    frame_id: Optional[int]
    scene_id: Optional[int]
    camera: str
    filename: str
    stem: str
    image_path: Path | None
    depth_path: Path | None
    sample_data: dict
    calibrated_sensor: dict
    ego_pose: dict
    sensor: dict


def normalize_camera_name(camera: str) -> str:
    camera = camera.strip()
    if camera.startswith("CAM_"):
        return camera
    return f"CAM_{camera}"


def short_camera_name(camera: str) -> str:
    camera = normalize_camera_name(camera)
    return camera[4:] if camera.startswith("CAM_") else camera


def camera_sort_key(camera: str) -> int:
    camera = normalize_camera_name(camera)
    if camera not in CAMERA_ORDER:
        raise ValueError(f"Unsupported camera {camera}; expected one of {CAMERA_ORDER}")
    return CAMERA_ORDER.index(camera)


def offset_to_shift_left(direction: str, meters: float) -> float:
    if direction == "left":
        return float(meters)
    if direction == "right":
        return -float(meters)
    raise ValueError(f"Unknown offset direction: {direction}")


def load_json_rows(path: Path) -> list:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def resolve_version_dir(nuscenes_root: Path, version_dir: Optional[Path]) -> Path:
    if version_dir is not None:
        return version_dir
    candidate = nuscenes_root / "v1.0-trainval"
    return candidate if candidate.is_dir() else nuscenes_root


def read_csv_rows(csv_path: Path, camera_filter: Optional[str]) -> List[dict]:
    with csv_path.open("r", newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if camera_filter is None:
        return rows
    normalized = normalize_camera_name(camera_filter)
    return [row for row in rows if normalize_camera_name(row.get("cam", "")) == normalized]


def parse_optional_int(value: object) -> Optional[int]:
    if value is None or value == "":
        return None
    return int(value)


def image_to_normalized_tensor(image: np.ndarray, image_size: Tuple[int, int]) -> torch.Tensor:
    pil = Image.fromarray(image.astype(np.uint8), mode="RGB")
    tensor = TF.to_tensor(pil)
    tensor = TF.resize(tensor, image_size, interpolation=TF.InterpolationMode.BILINEAR, antialias=True)
    return TF.normalize(tensor, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])


def mask_to_tensor(mask: np.ndarray, image_size: Tuple[int, int]) -> torch.Tensor:
    pil = Image.fromarray(mask.astype(np.uint8) * 255, mode="L")
    tensor = TF.to_tensor(pil)
    tensor = TF.resize(tensor, image_size, interpolation=TF.InterpolationMode.NEAREST)
    return (tensor > 0.5).to(torch.float32)


def depth_to_meter_tensor(depth: np.ndarray, image_size: Tuple[int, int]) -> torch.Tensor:
    depth_t = torch.from_numpy(depth.astype(np.float32, copy=False)).unsqueeze(0).unsqueeze(0)
    depth_t = F.interpolate(depth_t, size=image_size, mode="nearest").squeeze(0)
    return depth_t


def depth_valid_to_tensor(valid: np.ndarray, image_size: Tuple[int, int]) -> torch.Tensor:
    valid_t = torch.from_numpy(valid.astype(np.float32, copy=False)).unsqueeze(0).unsqueeze(0)
    valid_t = F.interpolate(valid_t, size=image_size, mode="nearest").squeeze(0)
    return (valid_t > 0.5).to(torch.float32)


def depth_to_log01_tensor(depth: np.ndarray, image_size: Tuple[int, int], depth_max: float) -> torch.Tensor:
    depth_t = depth_to_meter_tensor(depth, image_size)
    depth_t = depth_t.clamp(min=DEPTH_EPS, max=float(depth_max))
    return torch.log1p(depth_t) / float(np.log1p(float(depth_max)))


def log01_to_vae_depth(log01: torch.Tensor) -> torch.Tensor:
    normalized = log01.clamp(0.0, 1.0) * 2.0 - 1.0
    return normalized.repeat(3, 1, 1)


class NuScenesOffsetDataset(torch.utils.data.Dataset):
    def __init__(
        self,
        csv_path: str | Path,
        nuscenes_root: str | Path,
        depth_root: str | Path,
        split: str,
        tokenizer=None,
        height: int = 576,
        width: int = 1024,
        offsets: Sequence[Tuple[str, float]] = DEFAULT_OFFSETS,
        prompt: str = DEFAULT_PROMPT,
        camera: str | None = None,
        nuscenes_version_dir: str | Path | None = None,
        depth_max: float = 120.0,
        invalid_depth_fill: float = 100.0,
        max_frames: Optional[int] = None,
        retry_on_error: bool = True,
        global_seed: int = 42,
        require_temporal_references: bool | None = None,
    ) -> None:
        super().__init__()
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.depth_root = Path(depth_root)
        self.version_dir = resolve_version_dir(self.nuscenes_root, Path(nuscenes_version_dir) if nuscenes_version_dir else None)
        self.split = split
        self.tokenizer = tokenizer
        self.image_size = (int(height), int(width))
        self.offsets = tuple((str(direction), float(meters)) for direction, meters in offsets)
        self.prompt = prompt
        self.camera_filter = None if camera in (None, "", "all", "ALL", "six", "SIX") else normalize_camera_name(str(camera))
        self.depth_max = float(depth_max)
        self.invalid_depth_fill = float(invalid_depth_fill)
        self.retry_on_error = retry_on_error
        self.global_seed = int(global_seed)
        self.epoch = 0
        if require_temporal_references is None:
            require_temporal_references = split.lower() == "train"
        self.require_temporal_references = bool(require_temporal_references)
        all_records = self._build_records(max_frames=None)
        self.all_records = all_records
        self._records_by_temporal_key = {
            (record.scene_id, record.camera, record.frame_id): record
            for record in all_records
            if record.scene_id is not None and record.frame_id is not None
        }
        if self.require_temporal_references:
            self.records = self._filter_reference_complete(all_records)
        else:
            self.records = all_records
        if max_frames is not None:
            allowed_frames: list[int] = []
            allowed_set: set[int] = set()
            limited: list[NuScenesFrameRecord] = []
            for record in self.records:
                key = int(record.frame_id if record.frame_id is not None else len(allowed_frames))
                if key not in allowed_set:
                    if len(allowed_frames) >= int(max_frames):
                        break
                    allowed_frames.append(key)
                    allowed_set.add(key)
                limited.append(record)
            self.records = limited
        self.frame_groups = self._build_frame_groups()

        if not self.records:
            camera_msg = "all cameras" if self.camera_filter is None else self.camera_filter
            raise RuntimeError(f"No usable records were found in {self.csv_path} for {camera_msg}")

    def _build_metadata_index(self) -> Tuple[Dict[Tuple[str, str], Tuple[dict, dict, dict, dict]], Dict[str, dict]]:
        sample_data_rows = load_json_rows(self.version_dir / "sample_data.json")
        calibrated_sensor_rows = load_json_rows(self.version_dir / "calibrated_sensor.json")
        ego_pose_rows = load_json_rows(self.version_dir / "ego_pose.json")
        sensor_rows = load_json_rows(self.version_dir / "sensor.json")

        calibrated_by_token = {row["token"]: row for row in calibrated_sensor_rows}
        ego_by_token = {row["token"]: row for row in ego_pose_rows}
        sensor_by_token = {row["token"]: row for row in sensor_rows}

        index: Dict[Tuple[str, str], Tuple[dict, dict, dict, dict]] = {}
        for row in sample_data_rows:
            calibrated = calibrated_by_token[row["calibrated_sensor_token"]]
            sensor = sensor_by_token[calibrated["sensor_token"]]
            channel = sensor.get("channel", "")
            if channel not in CAMERA_ORDER:
                continue
            ego_pose = ego_by_token[row["ego_pose_token"]]
            path = Path(row.get("filename", ""))
            index[(channel, path.name)] = (row, calibrated, ego_pose, sensor)
            index[(channel, path.stem)] = (row, calibrated, ego_pose, sensor)
        return index, ego_by_token

    def _depth_path_for(self, camera: str, stem: str) -> Path:
        camera_depth_root = self.depth_root / camera
        if camera_depth_root.is_dir():
            return camera_depth_root / f"{stem}.npz"
        return self.depth_root / f"{stem}.npz"

    def _image_path_for(self, sample_data: dict, camera: str, filename: str) -> Path:
        image_path = self.nuscenes_root / sample_data["filename"]
        if image_path.exists():
            return image_path
        return self.nuscenes_root / "samples" / camera / filename

    def _build_records(self, max_frames: Optional[int]) -> List[NuScenesFrameRecord]:
        metadata, ego_by_token = self._build_metadata_index()
        rows = read_csv_rows(self.csv_path, self.camera_filter)

        records: List[NuScenesFrameRecord] = []
        seen_frame_ids: set[int] = set()
        missing = 0
        for row in rows:
            frame_id = parse_optional_int(row.get("frame_id"))
            if max_frames is not None and frame_id is not None and frame_id not in seen_frame_ids:
                if len(seen_frame_ids) >= int(max_frames):
                    break
            filename = Path(row.get("file", "")).name
            if not filename:
                continue
            camera = normalize_camera_name(row.get("cam", ""))
            stem = Path(filename).stem
            key = (camera, filename)
            if key not in metadata:
                key = (camera, stem)
            if key not in metadata:
                missing += 1
                continue
            sample_data, calibrated, default_ego_pose, sensor = metadata[key]
            if sensor.get("channel") != camera:
                missing += 1
                continue
            ego_pose_token = row.get("ego_pose_token") or sample_data["ego_pose_token"]
            ego_pose = ego_by_token.get(ego_pose_token, default_ego_pose)
            image_path = self._image_path_for(sample_data, camera, filename)
            depth_path = self._depth_path_for(camera, stem)
            if not image_path.exists() or not depth_path.exists():
                missing += 1
                continue
            records.append(
                NuScenesFrameRecord(
                    row_id=str(row.get("id", len(records))),
                    frame_id=frame_id,
                    scene_id=parse_optional_int(row.get("scene_id")),
                    camera=camera,
                    filename=filename,
                    stem=stem,
                    image_path=image_path,
                    depth_path=depth_path,
                    sample_data=sample_data,
                    calibrated_sensor=calibrated,
                    ego_pose=ego_pose,
                    sensor=sensor,
                )
            )
            if frame_id is not None:
                seen_frame_ids.add(frame_id)
        if missing:
            print(f"[NuScenesOffsetDataset] skipped {missing} rows with missing metadata/images/depth")
        return records

    def _build_frame_groups(self) -> List[List[int]]:
        groups: Dict[Tuple[int, int], List[int]] = {}
        for index, record in enumerate(self.records):
            if record.frame_id is None:
                continue
            key = (record.scene_id if record.scene_id is not None else -1, record.frame_id)
            groups.setdefault(key, []).append(index)

        complete_groups: List[List[int]] = []
        for key in sorted(groups):
            group = sorted(groups[key], key=lambda idx: camera_sort_key(self.records[idx].camera))
            if self.camera_filter is None and len(group) != len(CAMERA_ORDER):
                continue
            complete_groups.append(group)
        return complete_groups

    def _filter_reference_complete(self, records: List[NuScenesFrameRecord]) -> List[NuScenesFrameRecord]:
        by_key = {(r.scene_id, r.camera, r.frame_id): r for r in records if r.frame_id is not None}
        required = (-4, -2, 2, 4)
        kept = [
            record
            for record in records
            if record.frame_id is not None
            and record.scene_id is not None
            and all((record.scene_id, record.camera, record.frame_id + delta) in by_key for delta in required)
        ]
        dropped = len(records) - len(kept)
        if dropped:
            print(f"[NuScenesOffsetDataset] skipped {dropped} training records without all temporal references")
        return kept

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)

    def _reference_record(self, record: NuScenesFrameRecord, sample_id: int) -> NuScenesFrameRecord:
        if record.frame_id is None or record.scene_id is None:
            raise ValueError("Temporal reference selection requires frame_id and scene_id")
        by_key = getattr(self, "_records_by_temporal_key", None)
        if by_key is None:
            by_key = {
                (item.scene_id, item.camera, item.frame_id): item
                for item in self.all_records
                if item.scene_id is not None and item.frame_id is not None
            }
            self._records_by_temporal_key = by_key
        deltas = (-4, -2, 2, 4)
        rng = random.Random(self.global_seed + self.epoch + int(sample_id))
        delta = deltas[rng.randrange(len(deltas))]
        return by_key[(record.scene_id, record.camera, record.frame_id + delta)]

    def __len__(self) -> int:
        return len(self.records) * len(self.offsets)

    def __getitem__(self, idx: int) -> dict:
        if not self.retry_on_error:
            frame_idx = idx // len(self.offsets)
            offset_idx = idx % len(self.offsets)
            return self.get_item_by_frame_offset(frame_idx, offset_idx)

        start_idx = int(idx)
        for attempt in range(5):
            try:
                frame_idx = idx // len(self.offsets)
                offset_idx = idx % len(self.offsets)
                return self.get_item_by_frame_offset(frame_idx, offset_idx)
            except Exception as exc:
                if attempt == 4:
                    raise RuntimeError(f"Failed to load dataset index {start_idx} after retries") from exc
                idx = (idx + 1) % len(self)
        raise AssertionError("unreachable")

    def get_item_by_frame_offset(self, frame_idx: int, offset_idx: int) -> dict:
        record = self.records[int(frame_idx)]
        direction, meters = self.offsets[int(offset_idx)]
        rgb, depth, valid, intrinsics = self._load_rgb_depth(record)
        camera_to_ego = transform_from_translation_rotation(
            record.calibrated_sensor["translation"],
            record.calibrated_sensor["rotation"],
        )
        result = generate_offset_supervision(
            rgb=rgb,
            depth=depth,
            valid=valid,
            intrinsics=intrinsics,
            camera_to_ego=camera_to_ego,
            shift_left_m=offset_to_shift_left(direction, meters),
            depth_max=self.depth_max,
            invalid_depth_fill=self.invalid_depth_fill,
        )

        input_t = image_to_normalized_tensor(result.input_rgb, self.image_size)
        target_t = image_to_normalized_tensor(result.target_rgb, self.image_size)
        mask_t = mask_to_tensor(result.invalid_mask, self.image_size)
        input_depth_m = depth_to_meter_tensor(result.training_input_depth, self.image_size)
        target_depth_m = depth_to_meter_tensor(result.source_depth, self.image_size)
        input_depth_valid_t = depth_valid_to_tensor(result.reprojected_valid, self.image_size)
        target_depth_valid_t = depth_valid_to_tensor(result.source_valid, self.image_size)
        input_depth_log01 = depth_to_log01_tensor(result.training_input_depth, self.image_size, self.depth_max)
        target_depth_log01 = depth_to_log01_tensor(result.source_depth, self.image_size, self.depth_max)

        ref_record = self._reference_record(record, int(frame_idx * len(self.offsets) + offset_idx)) if self.require_temporal_references else None
        if ref_record is not None:
            ref_rgb, ref_depth, ref_valid, _ = self._load_rgb_depth(ref_record)
            ref_rgb_t = image_to_normalized_tensor(ref_rgb, self.image_size)
            ref_depth_m = depth_to_meter_tensor(ref_depth, self.image_size)
            ref_valid_t = depth_valid_to_tensor(ref_valid, self.image_size)
            ref_depth_log01 = depth_to_log01_tensor(ref_depth, self.image_size, self.depth_max)
            ref_depth_t = log01_to_vae_depth(ref_depth_log01)
        else:
            ref_rgb_t = image_to_normalized_tensor(result.target_rgb, self.image_size)
            ref_depth_m = target_depth_m
            ref_valid_t = target_depth_valid_t
            ref_depth_log01 = target_depth_log01
            ref_depth_t = log01_to_vae_depth(ref_depth_log01)

        zero_mask = torch.zeros_like(mask_t)

        out = {
            "conditioning_pixel_values": torch.stack([input_t, ref_rgb_t], dim=0),
            "output_pixel_values": torch.stack([target_t, ref_rgb_t], dim=0),
            "mask_pixel_values": torch.stack([mask_t, zero_mask], dim=0),
            "conditioning_depth_pixel_values": torch.stack([log01_to_vae_depth(input_depth_log01), ref_depth_t], dim=0),
            "target_depth_pixel_values": torch.stack([log01_to_vae_depth(target_depth_log01), ref_depth_t], dim=0),
            "conditioning_depth_log_values": torch.stack([input_depth_log01, ref_depth_log01], dim=0),
            "target_depth_log_values": torch.stack([target_depth_log01, ref_depth_log01], dim=0),
            "conditioning_depth_meters": torch.stack([input_depth_m, ref_depth_m], dim=0),
            "target_depth_meters": torch.stack([target_depth_m, ref_depth_m], dim=0),
            "conditioning_depth_valid_values": torch.stack([input_depth_valid_t, ref_valid_t], dim=0),
            "target_depth_valid_values": torch.stack([target_depth_valid_t, ref_valid_t], dim=0),
            "caption": self.prompt,
            "frame_idx": torch.tensor(int(frame_idx), dtype=torch.long),
            "offset_idx": torch.tensor(int(offset_idx), dtype=torch.long),
            "csv_frame_id": torch.tensor(int(record.frame_id if record.frame_id is not None else -1), dtype=torch.long),
            "scene_id": torch.tensor(int(record.scene_id if record.scene_id is not None else -1), dtype=torch.long),
            "camera_idx": torch.tensor(camera_sort_key(record.camera), dtype=torch.long),
            "mask_ratio": torch.tensor(float(mask_t.mean().item()), dtype=torch.float32),
            "reference_delta": torch.tensor(
                int(ref_record.frame_id - record.frame_id) if ref_record is not None else 0, dtype=torch.long
            ),
            "sample_key": f"{record.stem}_{short_camera_name(record.camera)}_{direction}_{meters:g}m",
        }
        if self.tokenizer is not None:
            input_ids = self.tokenizer(
                self.prompt,
                max_length=self.tokenizer.model_max_length,
                padding="max_length",
                truncation=True,
                return_tensors="pt",
            ).input_ids[0]
            out["input_ids"] = input_ids
        return out

    def get_single_project_item_by_frame_offset(self, frame_idx: int, offset_idx: int) -> dict:
        """Build inference-only single-project input and keep the original frame as reference."""
        record = self.records[int(frame_idx)]
        direction, meters = self.offsets[int(offset_idx)]
        rgb, depth, valid, intrinsics = self._load_rgb_depth(record)
        camera_to_ego = transform_from_translation_rotation(
            record.calibrated_sensor["translation"], record.calibrated_sensor["rotation"]
        )
        result = generate_single_project_input(
            rgb=rgb,
            depth=depth,
            valid=valid,
            intrinsics=intrinsics,
            camera_to_ego=camera_to_ego,
            shift_left_m=offset_to_shift_left(direction, meters),
            depth_max=self.depth_max,
            invalid_depth_fill=self.invalid_depth_fill,
        )
        input_rgb_t = image_to_normalized_tensor(result.input_rgb, self.image_size)
        ref_rgb_t = image_to_normalized_tensor(result.reference_rgb, self.image_size)
        input_depth_m = depth_to_meter_tensor(result.input_depth, self.image_size)
        ref_depth_m = depth_to_meter_tensor(result.reference_depth, self.image_size)
        input_valid_t = depth_valid_to_tensor(result.input_valid, self.image_size)
        ref_valid_t = depth_valid_to_tensor(result.reference_valid, self.image_size)
        input_log = depth_to_log01_tensor(result.input_depth, self.image_size, self.depth_max)
        ref_log = depth_to_log01_tensor(result.reference_depth, self.image_size, self.depth_max)
        mask_t = mask_to_tensor(result.invalid_mask, self.image_size)
        zero_mask = torch.zeros_like(mask_t)
        out = {
            "conditioning_pixel_values": torch.stack([input_rgb_t, ref_rgb_t], dim=0),
            "conditioning_depth_pixel_values": torch.stack([log01_to_vae_depth(input_log), log01_to_vae_depth(ref_log)], dim=0),
            "conditioning_depth_log_values": torch.stack([input_log, ref_log], dim=0),
            "conditioning_depth_meters": torch.stack([input_depth_m, ref_depth_m], dim=0),
            "conditioning_depth_valid_values": torch.stack([input_valid_t, ref_valid_t], dim=0),
            "mask_pixel_values": torch.stack([mask_t, zero_mask], dim=0),
            "reference_rgb": ref_rgb_t,
            "reference_depth_meters": ref_depth_m,
            "reference_depth_valid": ref_valid_t,
            "input_rgb": input_rgb_t,
            "input_depth_meters": input_depth_m,
            "input_depth_valid": input_valid_t,
            "frame_idx": torch.tensor(int(frame_idx), dtype=torch.long),
            "offset_idx": torch.tensor(int(offset_idx), dtype=torch.long),
            "csv_frame_id": torch.tensor(int(record.frame_id if record.frame_id is not None else -1), dtype=torch.long),
            "scene_id": torch.tensor(int(record.scene_id if record.scene_id is not None else -1), dtype=torch.long),
            "camera_idx": torch.tensor(camera_sort_key(record.camera), dtype=torch.long),
            "mask_ratio": torch.tensor(float(mask_t.mean().item()), dtype=torch.float32),
            "sample_key": f"{record.stem}_{short_camera_name(record.camera)}_{direction}_{meters:g}m_single",
        }
        if self.tokenizer is not None:
            out["input_ids"] = self.tokenizer(
                self.prompt,
                max_length=self.tokenizer.model_max_length,
                padding="max_length",
                truncation=True,
                return_tensors="pt",
            ).input_ids[0]
        return out

    def get_six_camera_items(self, group_idx: int, offset_idx: int) -> List[dict]:
        record_indices = self.frame_groups[int(group_idx)]
        return [self.get_item_by_frame_offset(record_idx, offset_idx) for record_idx in record_indices]

    def _load_rgb_depth(self, record: NuScenesFrameRecord) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        if record.image_path is None or record.depth_path is None:
            raise ValueError("NuScenesFrameRecord must provide image_path and depth_path")
        image = Image.open(record.image_path).convert("RGB")
        with np.load(record.depth_path) as data:
            depth = data["depth"].astype(np.float32)
            if "mask" in data.files:
                mask = data["mask"].astype(bool)
            else:
                mask = np.isfinite(depth) & (depth > DEPTH_EPS)
            if "intrinsics" in data.files:
                intrinsics = data["intrinsics"].astype(np.float32)
            else:
                official_k = np.asarray(record.calibrated_sensor["camera_intrinsic"], dtype=np.float32)
                intrinsics = scale_intrinsics(official_k, image.size, (depth.shape[1], depth.shape[0]))

        valid = mask & np.isfinite(depth) & (depth > DEPTH_EPS) & (depth < self.depth_max)
        depth = np.where(valid, depth, float(self.invalid_depth_fill)).astype(np.float32)
        rgb = np.asarray(image.resize((depth.shape[1], depth.shape[0]), Image.BILINEAR), dtype=np.uint8)
        return rgb, depth, valid, intrinsics

    def describe(self) -> dict:
        return {
            "split": self.split,
            "csv_path": str(self.csv_path),
            "records": len(self.records),
            "all_records": len(self.all_records),
            "grouped_frames": len(self.frame_groups),
            "camera_filter": self.camera_filter or "all",
            "offsets": list(self.offsets),
            "expanded_samples": len(self),
            "image_size_hw": list(self.image_size),
            "prompt": self.prompt,
            "strict_temporal_references": self.require_temporal_references,
        }
