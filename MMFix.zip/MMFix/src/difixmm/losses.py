from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn.functional as F


STYLE_WEIGHTS = {
    "relu1_2": 1.0 / 2.6,
    "relu2_2": 1.0 / 4.8,
    "relu3_3": 1.0 / 3.7,
    "relu4_3": 1.0 / 5.6,
    "relu5_3": 10.0 / 1.5,
}


def masked_l2_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    mask = mask.to(dtype=pred.dtype)
    while mask.ndim < pred.ndim:
        mask = mask.unsqueeze(1)
    numerator = ((pred - target) ** 2 * mask).sum()
    denominator = mask.sum() * pred.shape[1] + eps
    return numerator / denominator


def masked_l1_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    mask = mask.to(dtype=pred.dtype)
    while mask.ndim < pred.ndim:
        mask = mask.unsqueeze(1)
    numerator = (torch.abs(pred - target) * mask).sum()
    denominator = mask.sum() * pred.shape[1] + eps
    return numerator / denominator


def masked_rmse(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    return torch.sqrt(masked_l2_loss(pred, target, mask, eps=eps).clamp_min(eps))


def masked_absrel_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    mask = mask.to(dtype=pred.dtype)
    while mask.ndim < pred.ndim:
        mask = mask.unsqueeze(1)
    absrel = torch.abs(pred - target) / target.clamp_min(eps)
    numerator = (absrel * mask).sum()
    denominator = mask.sum() * pred.shape[1] + eps
    return numerator / denominator


def masked_gradient_l1_loss(
    pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6
) -> torch.Tensor:
    """L1 loss on horizontal/vertical depth gradients within valid neighbors."""
    if pred.ndim == 5:
        b, v, c, h, w = pred.shape
        return masked_gradient_l1_loss(
            pred.reshape(b * v, c, h, w), target.reshape(b * v, c, h, w), mask.reshape(b * v, 1, h, w), eps
        )
    if mask.ndim == 3:
        mask = mask.unsqueeze(1)
    mask = mask.to(dtype=pred.dtype)
    dx_mask = mask[..., :, 1:] * mask[..., :, :-1]
    dy_mask = mask[..., 1:, :] * mask[..., :-1, :]
    dx = torch.abs((pred[..., :, 1:] - pred[..., :, :-1]) - (target[..., :, 1:] - target[..., :, :-1]))
    dy = torch.abs((pred[..., 1:, :] - pred[..., :-1, :]) - (target[..., 1:, :] - target[..., :-1, :]))
    numerator = (dx * dx_mask).sum() + (dy * dy_mask).sum()
    denominator = (dx_mask.sum() + dy_mask.sum()) * pred.shape[1] + eps
    return numerator / denominator


def resize_for_lpips(tensor: torch.Tensor, size: Tuple[int, int] | None, mode: str = "bilinear") -> torch.Tensor:
    if size is None:
        return tensor
    if tuple(tensor.shape[-2:]) == tuple(size):
        return tensor
    if mode == "nearest":
        return F.interpolate(tensor, size=size, mode=mode)
    return F.interpolate(tensor, size=size, mode=mode, align_corners=False)


def lpips_loss(net_lpips, pred: torch.Tensor, target: torch.Tensor, size: Tuple[int, int] | None = None) -> torch.Tensor:
    pred = resize_for_lpips(pred, size)
    target = resize_for_lpips(target, size)
    return net_lpips(pred.float(), target.float()).mean()


def masked_lpips_loss(
    net_lpips,
    pred: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
    size: Tuple[int, int] | None = None,
) -> torch.Tensor:
    mask = mask.to(dtype=pred.dtype)
    if mask.ndim == 3:
        mask = mask.unsqueeze(1)
    pred = resize_for_lpips(pred, size)
    target = resize_for_lpips(target, size)
    mask = resize_for_lpips(mask, size, mode="nearest")
    pred_for_lpips = pred * mask + target * (1.0 - mask)
    return net_lpips(pred_for_lpips.float(), target.float()).mean()


def get_features(image: torch.Tensor, model: torch.nn.Module, layers: Dict[str, str] | None = None) -> Dict[str, torch.Tensor]:
    if layers is None:
        layers = {
            "3": "relu1_2",
            "8": "relu2_2",
            "15": "relu3_3",
            "22": "relu4_3",
            "29": "relu5_3",
        }

    features = {}
    x = image
    for name, layer in model._modules.items():
        x = layer(x)
        if name in layers:
            features[layers[name]] = x
    return features


def gram_matrix(tensor: torch.Tensor) -> torch.Tensor:
    b, d, h, w = tensor.size()
    tensor = tensor.reshape(b * d, h * w)
    return torch.mm(tensor, tensor.t())


def gram_loss(style: torch.Tensor, target: torch.Tensor, model: torch.nn.Module) -> torch.Tensor:
    style_features = get_features(style, model)
    target_features = get_features(target, model)
    style_grams = {layer: gram_matrix(style_features[layer]) for layer in style_features}

    total_loss = 0.0
    for layer, weight in STYLE_WEIGHTS.items():
        target_feature = target_features[layer]
        target_gram = gram_matrix(target_feature)
        style_gram = style_grams[layer]
        _, d, h, w = target_feature.shape
        layer_loss = weight * torch.mean((target_gram - style_gram) ** 2)
        total_loss = total_loss + layer_loss / (d * h * w)
    return total_loss


def full_l2_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    return F.mse_loss(pred.float(), target.float(), reduction="mean")
