"""Mask-guided Difix RGB-D training utilities."""

__all__ = ["__version__"]

__version__ = "0.1.0"
