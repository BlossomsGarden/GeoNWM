from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, Iterable, Tuple

import cv2
import numpy as np


DEPTH_EPS = 1e-6


@dataclass
class OffsetResult:
    input_rgb: np.ndarray
    training_input_depth: np.ndarray
    target_rgb: np.ndarray
    source_depth: np.ndarray
    source_valid: np.ndarray
    source_depth_for_projection: np.ndarray
    source_valid_for_projection: np.ndarray
    shifted_rgb: np.ndarray
    shifted_depth: np.ndarray
    shifted_depth_for_input: np.ndarray
    shifted_valid: np.ndarray
    shifted_depth_leak_mask: np.ndarray
    reprojected_rgb: np.ndarray
    reprojected_depth: np.ndarray
    reprojected_valid: np.ndarray
    invalid_mask: np.ndarray
    timings_ms: Dict[str, float]
    stats: Dict[str, float]


@dataclass
class SingleProjectResult:
    input_rgb: np.ndarray
    input_depth: np.ndarray
    input_valid: np.ndarray
    invalid_mask: np.ndarray
    reference_rgb: np.ndarray
    reference_depth: np.ndarray
    reference_valid: np.ndarray
    shifted_depth_leak_mask: np.ndarray
    timings_ms: Dict[str, float]
    stats: Dict[str, float]


def elapsed_ms(start: float) -> float:
    return (time.perf_counter() - start) * 1000.0


def quaternion_to_rotation_matrix(q: Iterable[float]) -> np.ndarray:
    w, x, y, z = [float(v) for v in q]
    n = w * w + x * x + y * y + z * z
    if n < DEPTH_EPS:
        return np.eye(3, dtype=np.float32)
    s = 2.0 / n
    wx, wy, wz = s * w * x, s * w * y, s * w * z
    xx, xy, xz = s * x * x, s * x * y, s * x * z
    yy, yz, zz = s * y * y, s * y * z, s * z * z
    return np.array(
        [
            [1.0 - (yy + zz), xy - wz, xz + wy],
            [xy + wz, 1.0 - (xx + zz), yz - wx],
            [xz - wy, yz + wx, 1.0 - (xx + yy)],
        ],
        dtype=np.float32,
    )


def transform_from_translation_rotation(translation: Iterable[float], rotation: Iterable[float]) -> np.ndarray:
    transform = np.eye(4, dtype=np.float32)
    transform[:3, :3] = quaternion_to_rotation_matrix(rotation)
    transform[:3, 3] = np.asarray(list(translation), dtype=np.float32)
    return transform


def scale_intrinsics(k: np.ndarray, source_wh: Tuple[int, int], target_wh: Tuple[int, int]) -> np.ndarray:
    scaled = k.astype(np.float32).copy()
    scaled[0, :] *= float(target_wh[0]) / float(source_wh[0])
    scaled[1, :] *= float(target_wh[1]) / float(source_wh[1])
    return scaled


def transform_points(transform: np.ndarray, points: np.ndarray) -> np.ndarray:
    return points @ transform[:3, :3].T + transform[:3, 3]


def backproject_rgbd_to_ego(
    rgb: np.ndarray,
    depth: np.ndarray,
    valid: np.ndarray,
    intrinsics: np.ndarray,
    camera_to_ego: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    ys, xs = np.nonzero(valid)
    if xs.size == 0:
        return np.zeros((0, 3), dtype=np.float32), np.zeros((0, 3), dtype=np.uint8)

    z = depth[ys, xs].astype(np.float32)
    fx = float(intrinsics[0, 0])
    fy = float(intrinsics[1, 1])
    cx = float(intrinsics[0, 2])
    cy = float(intrinsics[1, 2])
    points_cam = np.column_stack(
        [
            (xs.astype(np.float32) - cx) * z / fx,
            (ys.astype(np.float32) - cy) * z / fy,
            z,
        ]
    ).astype(np.float32)
    points_ego = transform_points(camera_to_ego, points_cam)
    colors = rgb[ys, xs].astype(np.uint8)
    return points_ego, colors


def project_ego_points_to_rgbd(
    points_ego: np.ndarray,
    colors: np.ndarray,
    camera_to_ego: np.ndarray,
    intrinsics: np.ndarray,
    height: int,
    width: int,
    depth_max: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    rgb = np.zeros((height, width, 3), dtype=np.uint8)
    depth = np.zeros((height, width), dtype=np.float32)
    valid = np.zeros((height, width), dtype=bool)
    if points_ego.size == 0:
        return rgb, depth, valid

    ego_to_camera = np.linalg.inv(camera_to_ego).astype(np.float32)
    points_cam = transform_points(ego_to_camera, points_ego)
    z = points_cam[:, 2]
    front = np.isfinite(z) & (z > DEPTH_EPS) & (z < depth_max)
    if not np.any(front):
        return rgb, depth, valid

    points_cam = points_cam[front]
    colors = colors[front]
    z = z[front].astype(np.float32)
    fx = float(intrinsics[0, 0])
    fy = float(intrinsics[1, 1])
    cx = float(intrinsics[0, 2])
    cy = float(intrinsics[1, 2])
    u = np.rint(points_cam[:, 0] * fx / z + cx).astype(np.int32)
    v = np.rint(points_cam[:, 1] * fy / z + cy).astype(np.int32)
    inside = (u >= 0) & (u < width) & (v >= 0) & (v < height)
    if not np.any(inside):
        return rgb, depth, valid

    u = u[inside]
    v = v[inside]
    z = z[inside]
    colors = colors[inside]
    flat_index = v * width + u

    order = np.lexsort((z, flat_index))
    sorted_flat = flat_index[order]
    keep = np.empty(sorted_flat.shape[0], dtype=bool)
    keep[0] = True
    keep[1:] = sorted_flat[1:] != sorted_flat[:-1]
    chosen = order[keep]

    chosen_u = u[chosen]
    chosen_v = v[chosen]
    rgb[chosen_v, chosen_u] = colors[chosen]
    depth[chosen_v, chosen_u] = z[chosen]
    valid[chosen_v, chosen_u] = True
    return rgb, depth, valid


def filter_far_depth_leaks(
    depth: np.ndarray,
    valid: np.ndarray,
    kernel_size: int = 5,
    abs_threshold_m: float = 0.5,
    rel_threshold: float = 0.05,
) -> np.ndarray:
    """Find far sparse points that leak through nearby foreground surfaces."""
    if kernel_size <= 1 or not np.any(valid):
        return np.zeros_like(valid, dtype=bool)
    if kernel_size % 2 == 0:
        raise ValueError(f"kernel_size must be odd, got {kernel_size}")

    sentinel = np.float32(1e6)
    depth_for_min = np.where(valid, depth.astype(np.float32), sentinel)
    kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
    local_min = cv2.erode(depth_for_min, kernel, borderType=cv2.BORDER_CONSTANT, borderValue=float(sentinel))
    threshold = np.maximum(float(abs_threshold_m), float(rel_threshold) * local_min)
    return valid & (local_min < sentinel * 0.5) & ((depth - local_min) > threshold)


def reproject_virtual_depth_to_original(
    virtual_depth: np.ndarray,
    virtual_valid: np.ndarray,
    intrinsics: np.ndarray,
    shifted_camera_to_ego: np.ndarray,
    original_camera_to_ego: np.ndarray,
    projection_depth_max: float,
    hole_depth_fill: float = 0.0,
) -> Tuple[np.ndarray, np.ndarray]:
    height, width = virtual_depth.shape
    full_valid = (
        virtual_valid.astype(bool)
        & np.isfinite(virtual_depth)
        & (virtual_depth > DEPTH_EPS)
        & (virtual_depth < projection_depth_max)
    )
    dummy_rgb = np.zeros((height, width, 3), dtype=np.uint8)
    virtual_points_ego, virtual_colors = backproject_rgbd_to_ego(
        dummy_rgb,
        virtual_depth.astype(np.float32),
        full_valid,
        intrinsics,
        shifted_camera_to_ego,
    )
    _, input_depth, input_depth_valid = project_ego_points_to_rgbd(
        virtual_points_ego,
        virtual_colors,
        original_camera_to_ego,
        intrinsics,
        height,
        width,
        projection_depth_max,
    )
    filled = np.where(input_depth_valid, input_depth, float(hole_depth_fill)).astype(np.float32)
    return filled, input_depth_valid


def fill_target_invalid_depth(
    depth: np.ndarray,
    valid: np.ndarray,
    fill_depth: float,
) -> Tuple[np.ndarray, np.ndarray, int]:
    filled_depth = depth.astype(np.float32, copy=True)
    filled_valid = np.ones_like(valid, dtype=bool)
    invalid = ~valid
    count = int(np.count_nonzero(invalid))
    if count > 0:
        filled_depth[invalid] = float(fill_depth)
    return filled_depth, filled_valid, count


def generate_offset_supervision(
    rgb: np.ndarray,
    depth: np.ndarray,
    valid: np.ndarray,
    intrinsics: np.ndarray,
    camera_to_ego: np.ndarray,
    shift_left_m: float,
    depth_max: float,
    invalid_depth_fill: float,
) -> OffsetResult:
    timings: Dict[str, float] = {}
    total_t0 = time.perf_counter()
    height, width = depth.shape
    projection_depth_max = max(float(depth_max), float(invalid_depth_fill) + 1.0)

    t0 = time.perf_counter()
    source_depth_for_projection, source_valid_for_projection, invalid_depth_fill_pixels = fill_target_invalid_depth(
        depth,
        valid,
        invalid_depth_fill,
    )
    timings["target_invalid_depth_fill_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    source_points_ego, source_colors = backproject_rgbd_to_ego(
        rgb,
        source_depth_for_projection,
        source_valid_for_projection,
        intrinsics,
        camera_to_ego,
    )
    timings["backproject_source_ms"] = elapsed_ms(t0)

    # Shift the whole rig in nuScenes ego coordinates: x forward, y left, z up.
    shifted_camera_to_ego = camera_to_ego.copy()
    shifted_camera_to_ego[1, 3] += float(shift_left_m)

    t0 = time.perf_counter()
    shifted_rgb, shifted_depth, shifted_valid = project_ego_points_to_rgbd(
        source_points_ego,
        source_colors,
        shifted_camera_to_ego,
        intrinsics,
        height,
        width,
        projection_depth_max,
    )
    timings["project_to_shifted_left_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    shifted_depth_projected = shifted_depth
    shifted_depth_leak_mask = filter_far_depth_leaks(shifted_depth_projected, shifted_valid)
    if np.any(shifted_depth_leak_mask):
        shifted_valid = shifted_valid & ~shifted_depth_leak_mask
        shifted_rgb = shifted_rgb.copy()
        shifted_rgb[shifted_depth_leak_mask] = 0
    shifted_depth = shifted_depth_projected.astype(np.float32, copy=True)
    shifted_depth_for_input = np.where(shifted_valid, shifted_depth, 0.0).astype(np.float32)
    timings["shifted_depth_leak_filter_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    training_input_depth, input_depth_valid = reproject_virtual_depth_to_original(
        shifted_depth_for_input,
        shifted_valid,
        intrinsics,
        shifted_camera_to_ego,
        camera_to_ego,
        projection_depth_max,
        hole_depth_fill=0.0,
    )
    timings["project_virtual_depth_back_original_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    shifted_points_ego, shifted_colors = backproject_rgbd_to_ego(
        shifted_rgb,
        shifted_depth,
        shifted_valid,
        intrinsics,
        shifted_camera_to_ego,
    )
    timings["backproject_shifted_ms"] = elapsed_ms(t0)

    t0 = time.perf_counter()
    reprojected_rgb, reprojected_depth, reprojected_valid = project_ego_points_to_rgbd(
        shifted_points_ego,
        shifted_colors,
        camera_to_ego,
        intrinsics,
        height,
        width,
        projection_depth_max,
    )
    reprojected_depth = np.where(reprojected_valid, reprojected_depth, 0.0).astype(np.float32)
    timings["project_back_original_ms"] = elapsed_ms(t0)

    if not np.array_equal(input_depth_valid, reprojected_valid):
        raise RuntimeError("RGB and depth double-project validity diverged")
    invalid_mask = ~reprojected_valid
    input_rgb = reprojected_rgb.copy()
    input_rgb[invalid_mask] = 0

    timings["online_offset_total_ms"] = elapsed_ms(total_t0)
    total_pixels = float(height * width)
    stats = {
        "source_points_after_invalid_depth_fill": int(source_points_ego.shape[0]),
        "shifted_points": int(shifted_points_ego.shape[0]),
        "source_valid_ratio": float(np.count_nonzero(valid) / total_pixels),
        "source_valid_for_projection_ratio": float(np.count_nonzero(source_valid_for_projection) / total_pixels),
        "shifted_valid_ratio": float(np.count_nonzero(shifted_valid) / total_pixels),
        "reprojected_valid_ratio": float(np.count_nonzero(reprojected_valid) / total_pixels),
        "offset_invalid_mask_ratio": float(np.count_nonzero(invalid_mask) / total_pixels),
        "shifted_depth_leak_filtered_pixels": int(np.count_nonzero(shifted_depth_leak_mask)),
        "shifted_depth_leak_filtered_ratio": float(np.count_nonzero(shifted_depth_leak_mask) / total_pixels),
        "target_invalid_depth_fill_pixels": int(invalid_depth_fill_pixels),
        "target_invalid_depth_fill": float(invalid_depth_fill),
        "projection_depth_max": float(projection_depth_max),
        "source_depth_zero_pixels_after_fill": int(np.count_nonzero(source_depth_for_projection <= DEPTH_EPS)),
        "shifted_depth_zero_pixels_after_fill": int(np.count_nonzero(shifted_depth <= DEPTH_EPS)),
        "training_input_depth_zero_pixels_after_fill": int(np.count_nonzero(training_input_depth <= DEPTH_EPS)),
        "width": int(width),
        "height": int(height),
        "shift_left_m": float(shift_left_m),
    }
    return OffsetResult(
        input_rgb=input_rgb,
        training_input_depth=training_input_depth,
        target_rgb=rgb,
        source_depth=depth,
        source_valid=valid,
        source_depth_for_projection=source_depth_for_projection,
        source_valid_for_projection=source_valid_for_projection,
        shifted_rgb=shifted_rgb,
        shifted_depth=shifted_depth,
        shifted_depth_for_input=shifted_depth_for_input,
        shifted_valid=shifted_valid,
        shifted_depth_leak_mask=shifted_depth_leak_mask,
        reprojected_rgb=reprojected_rgb,
        reprojected_depth=reprojected_depth,
        reprojected_valid=reprojected_valid,
        invalid_mask=invalid_mask,
        timings_ms=timings,
        stats=stats,
    )


def generate_single_project_input(
    rgb: np.ndarray,
    depth: np.ndarray,
    valid: np.ndarray,
    intrinsics: np.ndarray,
    camera_to_ego: np.ndarray,
    shift_left_m: float,
    depth_max: float,
    invalid_depth_fill: float,
) -> SingleProjectResult:
    """Project the source frame once into the offset camera for qualitative inference."""
    timings: Dict[str, float] = {}
    total_t0 = time.perf_counter()
    height, width = depth.shape
    projection_depth_max = max(float(depth_max), float(invalid_depth_fill) + 1.0)

    t0 = time.perf_counter()
    source_depth, source_projection_valid, _ = fill_target_invalid_depth(depth, valid, invalid_depth_fill)
    source_points, source_colors = backproject_rgbd_to_ego(
        rgb, source_depth, source_projection_valid, intrinsics, camera_to_ego
    )
    timings["backproject_source_ms"] = elapsed_ms(t0)

    shifted_camera_to_ego = camera_to_ego.copy()
    shifted_camera_to_ego[1, 3] += float(shift_left_m)
    t0 = time.perf_counter()
    shifted_rgb, shifted_depth, shifted_valid = project_ego_points_to_rgbd(
        source_points,
        source_colors,
        shifted_camera_to_ego,
        intrinsics,
        height,
        width,
        projection_depth_max,
    )
    leak_mask = filter_far_depth_leaks(shifted_depth, shifted_valid)
    shifted_valid = shifted_valid & ~leak_mask
    shifted_rgb = shifted_rgb.copy()
    shifted_rgb[~shifted_valid] = 0
    shifted_depth = np.where(shifted_valid, shifted_depth, 0.0).astype(np.float32)
    timings["project_to_shifted_ms"] = elapsed_ms(t0)
    timings["online_offset_total_ms"] = elapsed_ms(total_t0)

    total_pixels = float(height * width)
    return SingleProjectResult(
        input_rgb=shifted_rgb,
        input_depth=shifted_depth,
        input_valid=shifted_valid,
        invalid_mask=~shifted_valid,
        reference_rgb=rgb,
        reference_depth=depth,
        reference_valid=valid,
        shifted_depth_leak_mask=leak_mask,
        timings_ms=timings,
        stats={
            "source_valid_ratio": float(np.count_nonzero(valid) / total_pixels),
            "shifted_valid_ratio": float(np.count_nonzero(shifted_valid) / total_pixels),
            "offset_invalid_mask_ratio": float(np.count_nonzero(~shifted_valid) / total_pixels),
            "shifted_depth_leak_filtered_pixels": int(np.count_nonzero(leak_mask)),
            "shift_left_m": float(shift_left_m),
        },
    )
