from __future__ import annotations

import inspect
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Dict, Iterable, Iterator, Optional

import torch
import torch.nn.functional as F


def import_difix_pipeline(difix3d_src: str | Path | None):
    if difix3d_src is not None:
        src = str(Path(difix3d_src).resolve())
        if src not in sys.path:
            sys.path.insert(0, src)
    from pipeline_difix import DifixPipeline

    return DifixPipeline


def _replace_conv(conv: torch.nn.Conv2d, in_channels: int | None = None, out_channels: int | None = None) -> torch.nn.Conv2d:
    return torch.nn.Conv2d(
        conv.in_channels if in_channels is None else in_channels,
        conv.out_channels if out_channels is None else out_channels,
        kernel_size=conv.kernel_size,
        stride=conv.stride,
        padding=conv.padding,
        dilation=conv.dilation,
        groups=conv.groups,
        bias=conv.bias is not None,
        padding_mode=conv.padding_mode,
    ).to(device=conv.weight.device, dtype=conv.weight.dtype)


def expand_unet_rgbd_channels(unet: torch.nn.Module) -> None:
    """Expand a Difix-ref UNet and initialize both modalities from RGB weights."""
    old_in = unet.conv_in
    if old_in.in_channels != 9:
        if old_in.in_channels != 4:
            raise ValueError(f"Expected pretrained conv_in with 4 channels, got {old_in.in_channels}")
        new_in = _replace_conv(old_in, in_channels=9)
        with torch.no_grad():
            new_in.weight.zero_()
            new_in.weight[:, :4].copy_(old_in.weight * 0.5)
            new_in.weight[:, 4:8].copy_(old_in.weight * 0.5)
            if old_in.bias is not None:
                new_in.bias.copy_(old_in.bias)
        unet.conv_in = new_in
    old_out = unet.conv_out
    if old_out.out_channels != 8:
        if old_out.out_channels != 4:
            raise ValueError(f"Expected pretrained conv_out with 4 channels, got {old_out.out_channels}")
        new_out = _replace_conv(old_out, out_channels=8)
        with torch.no_grad():
            new_out.weight[:4].copy_(old_out.weight)
            new_out.weight[4:].copy_(old_out.weight)
            if old_out.bias is not None:
                new_out.bias[:4].copy_(old_out.bias)
                new_out.bias[4:].copy_(old_out.bias)
        unet.conv_out = new_out
    if hasattr(unet, "register_to_config"):
        unet.register_to_config(in_channels=9, out_channels=8)
    else:
        unet.config.in_channels = 9
        unet.config.out_channels = 8


def _vae_encoder_forward(self, sample, *args, **kwargs):
    sample = self.conv_in(sample)
    blocks = []
    for down_block in self.down_blocks:
        blocks.append(sample)
        sample = down_block(sample)
    sample = self.mid_block(sample)
    sample = self.conv_norm_out(sample)
    sample = self.conv_act(sample)
    sample = self.conv_out(sample)
    self.current_down_blocks = tuple(blocks)
    return sample


def _vae_decoder_forward(self, sample, latent_embeds=None, *args, **kwargs):
    sample = self.conv_in(sample)
    upscale_dtype = next(iter(self.up_blocks.parameters())).dtype
    sample = self.mid_block(sample, latent_embeds)
    sample = sample.to(upscale_dtype)
    skip_acts = getattr(self, "incoming_skip_acts", None)
    use_skip = not getattr(self, "ignore_skip", False) and skip_acts is not None
    if use_skip:
        skip_convs = [self.skip_conv_1, self.skip_conv_2, self.skip_conv_3, self.skip_conv_4]
        for idx, up_block in enumerate(self.up_blocks):
            sample = sample + skip_convs[idx](skip_acts[::-1][idx] * getattr(self, "gamma", 1.0))
            sample = up_block(sample, latent_embeds)
    else:
        for up_block in self.up_blocks:
            sample = up_block(sample, latent_embeds)
    if latent_embeds is None:
        sample = self.conv_norm_out(sample)
    else:
        sample = self.conv_norm_out(sample, latent_embeds)
    sample = self.conv_act(sample)
    return self.conv_out(sample)


def ensure_vae_skip_modules(vae: torch.nn.Module) -> None:
    """Install Difix skip plumbing when the local pipeline VAE does not expose it."""
    encoder = vae.encoder
    decoder = vae.decoder
    shapes = ((512, 512), (256, 512), (128, 512), (128, 256))
    has_authoritative_skips = all(hasattr(decoder, f"skip_conv_{idx}") for idx in range(1, 5))
    if has_authoritative_skips:
        return
    encoder.forward = _vae_encoder_forward.__get__(encoder, encoder.__class__)
    decoder.forward = _vae_decoder_forward.__get__(decoder, decoder.__class__)
    for idx, (in_ch, out_ch) in enumerate(shapes, 1):
        name = f"skip_conv_{idx}"
        if not hasattr(decoder, name):
            setattr(decoder, name, torch.nn.Conv2d(in_ch, out_ch, 1, bias=False).to(decoder.conv_in.weight))
            torch.nn.init.constant_(getattr(decoder, name).weight, 1e-5)
    decoder.ignore_skip = False
    decoder.gamma = 1.0


def ensure_depth_skip_convs(vae: torch.nn.Module, scale: float = 0.5) -> None:
    decoder = vae.decoder
    for idx in range(1, 5):
        rgb_name = f"skip_conv_{idx}"
        depth_name = f"depth_skip_conv_{idx}"
        if not hasattr(decoder, depth_name):
            rgb_module = getattr(decoder, rgb_name)
            base = getattr(rgb_module, "base_layer", rgb_module)
            module = torch.nn.Conv2d(
                base.in_channels,
                base.out_channels,
                kernel_size=base.kernel_size,
                stride=base.stride,
                padding=base.padding,
                dilation=base.dilation,
                groups=base.groups,
                bias=base.bias is not None,
                padding_mode=base.padding_mode,
            ).to(device=base.weight.device, dtype=base.weight.dtype)
            with torch.no_grad():
                module.weight.copy_(base.weight * float(scale))
                if base.bias is not None:
                    module.bias.copy_(base.bias * float(scale))
            setattr(decoder, depth_name, module)


@contextmanager
def use_depth_skip_convs(vae: torch.nn.Module, gated_acts: Optional[tuple[torch.Tensor, ...]] = None) -> Iterator[None]:
    decoder = vae.decoder
    originals: Dict[str, torch.nn.Module] = {}
    original_acts = getattr(decoder, "incoming_skip_acts", None)
    for idx in range(1, 5):
        rgb_name = f"skip_conv_{idx}"
        depth_name = f"depth_skip_conv_{idx}"
        originals[rgb_name] = getattr(decoder, rgb_name)
        setattr(decoder, rgb_name, getattr(decoder, depth_name))
    if gated_acts is not None:
        decoder.incoming_skip_acts = list(gated_acts)
    try:
        yield
    finally:
        for name, module in originals.items():
            setattr(decoder, name, module)
        decoder.incoming_skip_acts = original_acts


def load_difix_components(pretrained_model_dir: str | Path, difix3d_src: str | Path | None):
    pipeline_cls = import_difix_pipeline(difix3d_src)
    return pipeline_cls.from_pretrained(
        str(pretrained_model_dir),
        local_files_only=True,
        safety_checker=None,
    )


def assert_multiview_attention_loaded() -> None:
    from diffusers.models.attention import BasicTransformerBlock

    try:
        source = inspect.getsource(BasicTransformerBlock.forward)
    except (OSError, TypeError) as exc:
        raise RuntimeError("Could not verify nvidia_difix_ref multi-view attention") from exc
    if "(b v) n d" not in source or "b (v n) d" not in source:
        raise RuntimeError(
            "nvidia_difix_ref custom UNet was not loaded; self-attention would not mix the two views"
        )


class MaskGuidedRGBDRefDifix(torch.nn.Module):
    def __init__(
        self,
        pretrained_model_dir: str | Path,
        difix3d_src: str | Path | None,
        timestep: int = 199,
        depth_skip_mode: str = "main",
        train_vae_lora: bool = True,
    ) -> None:
        super().__init__()
        if depth_skip_mode not in {"main", "a", "b"}:
            raise ValueError("depth_skip_mode must be 'main', 'a', or 'b'")
        pipe = load_difix_components(pretrained_model_dir, difix3d_src)
        self.tokenizer = pipe.tokenizer
        self.text_encoder = pipe.text_encoder
        self.vae = pipe.vae
        self.scheduler = pipe.scheduler
        self.unet = pipe.unet
        assert_multiview_attention_loaded()
        self.timestep = int(timestep)
        self.depth_skip_mode = depth_skip_mode
        self.train_vae_lora = bool(train_vae_lora)
        ensure_vae_skip_modules(self.vae)
        ensure_depth_skip_convs(self.vae, scale=0.5)
        expand_unet_rgbd_channels(self.unet)
        self.text_encoder.requires_grad_(False)
        self.set_train()

    def set_train(self) -> None:
        self.train()
        self.unet.train()
        self.vae.train()
        self.unet.requires_grad_(True)
        self.vae.requires_grad_(False)
        if self.train_vae_lora:
            for name, param in self.vae.named_parameters():
                if "lora" in name or ("depth_skip_conv" in name and self.depth_skip_mode != "b"):
                    param.requires_grad = True

    def set_eval(self) -> None:
        self.eval()
        self.unet.eval()
        self.vae.eval()

    def optimizer_parameter_groups(self, lr_unet: float, lr_vae_lora: float, lr_depth_skip_conv: float) -> list[dict]:
        groups = [{"params": [p for p in self.unet.parameters() if p.requires_grad], "lr": float(lr_unet), "name": "unet"}]
        lora = [p for n, p in self.vae.named_parameters() if p.requires_grad and "lora" in n]
        depth_skip = [p for n, p in self.vae.named_parameters() if p.requires_grad and "depth_skip_conv" in n]
        if lora:
            groups.append({"params": lora, "lr": float(lr_vae_lora), "name": "vae_lora"})
        if depth_skip:
            groups.append({"params": depth_skip, "lr": float(lr_depth_skip_conv), "name": "depth_skip_conv"})
        return groups

    def trainable_parameters(self) -> Iterable[torch.nn.Parameter]:
        for group in self.optimizer_parameter_groups(1.0, 1.0, 1.0):
            yield from group["params"]

    def _prepare_scheduler(self, device: torch.device) -> None:
        if hasattr(self.scheduler, "alphas_cumprod"):
            self.scheduler.alphas_cumprod = self.scheduler.alphas_cumprod.to(device)
        if hasattr(self.scheduler, "set_timesteps"):
            self.scheduler.set_timesteps(1, device=device)

    def _encode_prompt(self, prompt_tokens: torch.Tensor, num_views: int) -> torch.Tensor:
        if prompt_tokens.ndim == 3 and prompt_tokens.shape[1] == 1:
            prompt_tokens = prompt_tokens[:, 0]
        text_device = next(self.text_encoder.parameters()).device
        caption = self.text_encoder(prompt_tokens.to(text_device))[0]
        return caption.repeat_interleave(num_views, dim=0)

    def _encode_with_skips(self, x: torch.Tensor) -> tuple[torch.Tensor, tuple[torch.Tensor, ...]]:
        z = self.vae.encode(x).latent_dist.sample() * self.vae.config.scaling_factor
        return z, tuple(self.vae.encoder.current_down_blocks)

    def _gated_skip_acts(self, skip_acts: tuple[torch.Tensor, ...], mask: torch.Tensor) -> tuple[torch.Tensor, ...]:
        return tuple(act * (1.0 - F.adaptive_max_pool2d(mask, act.shape[-2:])) for act in skip_acts)

    def _decode(self, z: torch.Tensor, skips: tuple[torch.Tensor, ...], branch: str, mask: torch.Tensor) -> torch.Tensor:
        self.vae.decoder.incoming_skip_acts = list(skips)
        if branch == "depth" and self.depth_skip_mode == "b":
            self.vae.decoder.ignore_skip = True
            try:
                out = self.vae.decode(z / self.vae.config.scaling_factor).sample
            finally:
                self.vae.decoder.ignore_skip = False
        elif branch == "depth":
            gated = self._gated_skip_acts(skips, mask) if self.depth_skip_mode == "a" else None
            with use_depth_skip_convs(self.vae, gated_acts=gated):
                out = self.vae.decode(z / self.vae.config.scaling_factor).sample
        else:
            out = self.vae.decode(z / self.vae.config.scaling_factor).sample
        return out.clamp(-1, 1)

    def forward(self, rgb: torch.Tensor, depth: torch.Tensor, mask: torch.Tensor, prompt_tokens: torch.Tensor) -> dict[str, torch.Tensor]:
        if rgb.ndim != 5 or depth.ndim != 5 or mask.ndim != 5:
            raise ValueError("Expected rgb/depth/mask as [B,V,C,H,W]")
        batch_size, num_views, _, height, width = rgb.shape
        if num_views != 2 or depth.shape[:2] != (batch_size, num_views) or mask.shape[:2] != (batch_size, num_views):
            raise ValueError("RGB-D reference model requires exactly two aligned views")
        device = rgb.device
        self._prepare_scheduler(device)
        flat_rgb = rgb.reshape(batch_size * num_views, 3, height, width)
        flat_depth = depth.reshape(batch_size * num_views, 3, height, width)
        flat_mask = mask.reshape(batch_size * num_views, 1, height, width).to(dtype=rgb.dtype)
        z_rgb, rgb_skips = self._encode_with_skips(flat_rgb)
        z_depth, depth_skips = self._encode_with_skips(flat_depth)
        latent_mask = F.adaptive_max_pool2d(flat_mask, z_rgb.shape[-2:])
        z_joint = torch.cat([z_rgb, z_depth], dim=1)
        unet_input = torch.cat([z_joint, latent_mask], dim=1)
        prompt = self._encode_prompt(prompt_tokens, num_views).to(device=device, dtype=z_joint.dtype)
        timestep = torch.tensor(self.timestep, device=device, dtype=torch.long)
        result = self.unet(unet_input, timestep, encoder_hidden_states=prompt)
        model_pred = result.sample if hasattr(result, "sample") else result[0]
        if model_pred.shape[1] != 8:
            raise ValueError(f"Expected 8 output channels, got {model_pred.shape[1]}")
        z_denoised = self.scheduler.step(model_pred, timestep, z_joint, return_dict=True).prev_sample
        z_rgb_out, z_depth_out = z_denoised.chunk(2, dim=1)
        pred_rgb = self._decode(z_rgb_out, rgb_skips, "rgb", flat_mask)
        pred_depth_pixel = self._decode(z_depth_out, depth_skips, "depth", flat_mask)
        pred_rgb = pred_rgb.reshape(batch_size, num_views, 3, height, width)
        pred_depth_pixel = pred_depth_pixel.reshape(batch_size, num_views, 3, height, width)
        return {
            "rgb": pred_rgb,
            "depth_pixel": pred_depth_pixel,
            "depth_log": pred_depth_pixel.mean(dim=2, keepdim=True).clamp(-1, 1),
        }

    def inference_state_dict(self) -> Dict[str, object]:
        return {
            "format_version": 3,
            "scheme": "rgbd_ref",
            "depth_skip_mode": self.depth_skip_mode,
            "timestep": self.timestep,
            "unet_in_channels": int(self.unet.conv_in.in_channels),
            "unet_out_channels": int(self.unet.conv_out.out_channels),
            "state_dict_unet": self.unet.state_dict(),
            "state_dict_vae_trainable": {
                k: v for k, v in self.vae.state_dict().items() if "lora" in k or "depth_skip_conv" in k
            },
        }

    def load_inference_state_dict(self, state: Dict[str, object], strict: bool = False) -> None:
        state_mode = state.get("depth_skip_mode")
        if state_mode is not None and str(state_mode) != self.depth_skip_mode:
            raise ValueError(
                f"Checkpoint depth_skip_mode={state_mode!r} does not match model mode={self.depth_skip_mode!r}"
            )
        self.unet.load_state_dict(state["state_dict_unet"], strict=strict)
        vae_state = self.vae.state_dict()
        vae_state.update(state.get("state_dict_vae_trainable", {}))
        self.vae.load_state_dict(vae_state, strict=False)


def create_rgbd_ref_model(scheme: str, pretrained_model_dir: str | Path, difix3d_src: str | Path | None, timestep: int = 199) -> MaskGuidedRGBDRefDifix:
    mode = {"main": "main", "a": "a", "b": "b"}.get(str(scheme).lower())
    if mode is None:
        raise ValueError("scheme must be main, a, or b")
    return MaskGuidedRGBDRefDifix(pretrained_model_dir, difix3d_src, timestep=timestep, depth_skip_mode=mode)


def create_rgbd_model(*args, **kwargs):
    return create_rgbd_ref_model(*args, **kwargs)


def save_inference_checkpoint(model: MaskGuidedRGBDRefDifix, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(model.inference_state_dict(), path)


def save_resume_checkpoint(model, optimizer, lr_scheduler, global_step: int, path: str | Path) -> None:
    state = model.inference_state_dict()
    state.update({"checkpoint_type": "resume", "global_step": int(global_step), "optimizer": optimizer.state_dict(), "lr_scheduler": lr_scheduler.state_dict()})
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(state, path)


def load_stage2_checkpoint(model, checkpoint_path: str | Path, optimizer=None, lr_scheduler=None) -> int:
    state = torch.load(checkpoint_path, map_location="cpu")
    model.load_inference_state_dict(state, strict=False)
    if optimizer is not None and state.get("optimizer") is not None:
        optimizer.load_state_dict(state["optimizer"])
    if lr_scheduler is not None and state.get("lr_scheduler") is not None:
        lr_scheduler.load_state_dict(state["lr_scheduler"])
    return int(state.get("global_step", 0))
