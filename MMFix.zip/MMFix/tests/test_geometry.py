import numpy as np

from difixmm.geometry import fill_target_invalid_depth, reproject_virtual_depth_to_original


def test_sky_proxy_is_filled_but_original_validity_is_preserved_by_caller():
    depth = np.array([[4.0, 0.0]], dtype=np.float32)
    valid = np.array([[True, False]])
    filled, projection_valid, count = fill_target_invalid_depth(depth, valid, 100.0)
    np.testing.assert_allclose(filled, [[4.0, 100.0]])
    assert projection_valid.all()
    assert not valid[0, 1]
    assert count == 1


def test_reprojection_uses_explicit_valid_and_leaves_holes_at_zero():
    depth = np.array([[5.0, 100.0], [7.0, 8.0]], dtype=np.float32)
    valid = np.array([[True, False], [True, True]])
    intrinsics = np.eye(3, dtype=np.float32)
    intrinsics[0, 0] = intrinsics[1, 1] = 1.0
    transform = np.eye(4, dtype=np.float32)
    output, output_valid = reproject_virtual_depth_to_original(
        depth,
        valid,
        intrinsics,
        transform,
        transform,
        projection_depth_max=120.0,
        hole_depth_fill=0.0,
    )
    assert output[0, 1] == 0.0
    assert not output_valid[0, 1]
    assert np.count_nonzero(output) == np.count_nonzero(output_valid)
