from types import SimpleNamespace

import pytest
import torch

from difixmm.modeling import (
    MaskGuidedRGBDRefDifix,
    ensure_depth_skip_convs,
    expand_unet_rgbd_channels,
)


class DummyUNet(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.conv_in = torch.nn.Conv2d(4, 2, 3, padding=1, bias=True)
        self.conv_out = torch.nn.Conv2d(2, 4, 3, padding=1, bias=True)
        self.config = SimpleNamespace(in_channels=4, out_channels=4)


def test_rgbd_channel_initialization_matches_confirmed_ratios():
    unet = DummyUNet()
    old_in = unet.conv_in.weight.detach().clone()
    old_out = unet.conv_out.weight.detach().clone()
    expand_unet_rgbd_channels(unet)
    torch.testing.assert_close(unet.conv_in.weight[:, :4], old_in * 0.5)
    torch.testing.assert_close(unet.conv_in.weight[:, 4:8], old_in * 0.5)
    assert torch.count_nonzero(unet.conv_in.weight[:, 8:]) == 0
    torch.testing.assert_close(unet.conv_out.weight[:4], old_out)
    torch.testing.assert_close(unet.conv_out.weight[4:], old_out)


def test_depth_skip_is_half_copy_without_separate_lora():
    decoder = torch.nn.Module()
    shapes = ((4, 4), (3, 4), (2, 4), (2, 3))
    for idx, (in_ch, out_ch) in enumerate(shapes, 1):
        conv = torch.nn.Conv2d(in_ch, out_ch, 1, bias=False)
        torch.nn.init.constant_(conv.weight, float(idx))
        setattr(decoder, f"skip_conv_{idx}", conv)
    vae = SimpleNamespace(decoder=decoder)
    ensure_depth_skip_convs(vae, scale=0.5)
    for idx in range(1, 5):
        rgb = getattr(decoder, f"skip_conv_{idx}")
        depth = getattr(decoder, f"depth_skip_conv_{idx}")
        torch.testing.assert_close(depth.weight, rgb.weight * 0.5)
        assert not any("lora" in name for name, _ in depth.named_parameters())


def test_scheme_a_max_pool_gate_preserves_reference_and_suppresses_target_holes():
    model = MaskGuidedRGBDRefDifix.__new__(MaskGuidedRGBDRefDifix)
    torch.nn.Module.__init__(model)
    acts = (torch.ones(2, 1, 2, 2),)
    mask = torch.zeros(2, 1, 4, 4)
    mask[0, :, 0, 0] = 1
    gated = model._gated_skip_acts(acts, mask)[0]
    assert gated[0, 0, 0, 0] == 0
    assert torch.all(gated[1] == 1)


def test_checkpoint_depth_skip_mode_must_match_model():
    model = MaskGuidedRGBDRefDifix.__new__(MaskGuidedRGBDRefDifix)
    torch.nn.Module.__init__(model)
    model.depth_skip_mode = "a"
    with pytest.raises(ValueError, match="does not match"):
        model.load_inference_state_dict({"depth_skip_mode": "main"})
