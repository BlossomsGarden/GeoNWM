import torch

from difixmm.losses import masked_gradient_l1_loss


def test_depth_gradient_loss_ignores_invalid_edges():
    target = torch.zeros(1, 1, 2, 3)
    pred = target.clone()
    pred[..., 0, 1] = 10.0
    valid = torch.ones(1, 1, 2, 3)
    valid[..., 0, 1] = 0.0
    assert masked_gradient_l1_loss(pred, target, valid).item() == 0.0
