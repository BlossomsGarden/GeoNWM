from dataclasses import replace

from difixmm.dataset_nuscenes import NuScenesFrameRecord, NuScenesOffsetDataset


def make_record(frame_id: int, scene_id: int = 1, camera: str = "CAM_FRONT") -> NuScenesFrameRecord:
    return NuScenesFrameRecord(
        row_id=str(frame_id),
        frame_id=frame_id,
        scene_id=scene_id,
        camera=camera,
        filename=f"{frame_id}.jpg",
        stem=str(frame_id),
        image_path=None,
        depth_path=None,
        sample_data={},
        calibrated_sensor={},
        ego_pose={},
        sensor={},
    )


def test_strict_filter_requires_all_four_same_scene_camera_candidates():
    ds = NuScenesOffsetDataset.__new__(NuScenesOffsetDataset)
    records = [make_record(i) for i in range(9)]
    records += [make_record(i, scene_id=2) for i in (0, 2, 4, 6)]
    kept = ds._filter_reference_complete(records)
    assert [(r.scene_id, r.frame_id) for r in kept] == [(1, 4)]


def test_reference_sampling_is_epoch_seeded_and_reproducible():
    ds = NuScenesOffsetDataset.__new__(NuScenesOffsetDataset)
    ds.all_records = [make_record(i) for i in range(9)]
    ds.records = [ds.all_records[4]]
    ds.global_seed = 17
    target = ds.records[0]
    sequence_a = []
    for epoch in range(12):
        ds.set_epoch(epoch)
        sequence_a.append(ds._reference_record(target, sample_id=9).frame_id - target.frame_id)
    sequence_b = []
    for epoch in range(12):
        ds.set_epoch(epoch)
        sequence_b.append(ds._reference_record(target, sample_id=9).frame_id - target.frame_id)
    assert sequence_a == sequence_b
    assert set(sequence_a).issubset({-4, -2, 2, 4})
    assert len(set(sequence_a)) > 1
