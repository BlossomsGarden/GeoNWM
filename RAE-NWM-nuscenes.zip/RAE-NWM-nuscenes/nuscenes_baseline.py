from __future__ import annotations

from dataclasses import dataclass
from math import isqrt

import torch


@dataclass
class ChunkBatch:
    anchor_latent: torch.Tensor
    future_latents: torch.Tensor
    x_cond: torch.Tensor
    x_start: torch.Tensor
    actions: torch.Tensor
    rel_t: torch.Tensor


def to_unit_range(frames: torch.Tensor) -> torch.Tensor:
    """Convert uint8, [0, 1], or legacy [-1, 1] images to [0, 1]."""
    frames = frames.float()
    if frames.numel() == 0:
        return frames
    if frames.detach().amax() > 1.5:
        return frames / 255.0
    if frames.detach().amin() < -0.01:
        return frames.mul(0.5).add(0.5)
    return frames


def _tokens_to_maps(latent: torch.Tensor) -> torch.Tensor:
    if latent.ndim == 4:
        return latent
    if latent.ndim != 3:
        raise ValueError(
            f"RAE encoder must return [B,C,H,W] or [B,N,C], got {tuple(latent.shape)}"
        )
    batch, tokens, channels = latent.shape
    grid = isqrt(tokens)
    if grid * grid != tokens:
        raise ValueError(f"Latent token count must be square, got {tokens}")
    return latent.transpose(1, 2).reshape(batch, channels, grid, grid)


def encode_frames(rae, frames: torch.Tensor) -> torch.Tensor:
    frames = to_unit_range(frames)
    batch, time, channels, height, width = frames.shape
    with torch.no_grad():
        latents = rae.encode(frames.reshape(batch * time, channels, height, width))
    latents = _tokens_to_maps(latents)
    return latents.reshape(batch, time, *latents.shape[1:])


def normalize_actions(
    actions: torch.Tensor,
    action_mean: list[float] | tuple[float, ...] | None = None,
    action_std: list[float] | tuple[float, ...] | None = None,
    action_clip: float | None = None,
) -> torch.Tensor:
    """Apply DeltaTok's motion statistics while preserving degree-valued yaw."""
    actions = actions.float()
    if action_mean is None or action_std is None:
        return actions
    mean = torch.as_tensor(action_mean, dtype=actions.dtype, device=actions.device)
    std = torch.as_tensor(action_std, dtype=actions.dtype, device=actions.device).clamp_min(1e-6)
    wrapped_yaw = torch.remainder(actions[..., 2] + 180.0, 360.0) - 180.0
    actions = torch.cat((actions[..., :2], wrapped_yaw.unsqueeze(-1)), dim=-1)
    normalized = (actions - mean) / std
    if action_clip is not None:
        normalized = normalized.clamp(-float(action_clip), float(action_clip))
    return normalized


def make_relative_times(
    batch_size: int,
    horizon: int,
    divisor: float = 128.0,
    device: torch.device | None = None,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    values = torch.arange(1, horizon + 1, device=device, dtype=dtype) / float(divisor)
    return values.unsqueeze(0).expand(batch_size, -1)


def pack_parallel_chunk(
    frames: torch.Tensor,
    actions: torch.Tensor,
    rae,
    num_cond: int = 1,
    action_mean: list[float] | tuple[float, ...] | None = None,
    action_std: list[float] | tuple[float, ...] | None = None,
    action_clip: float | None = None,
    rel_time_divisor: float = 128.0,
) -> ChunkBatch:
    if frames.ndim != 5 or frames.shape[1] != num_cond + actions.shape[1]:
        raise ValueError(
            f"Expected frames [B,{num_cond + actions.shape[1]},C,H,W], got {tuple(frames.shape)}"
        )
    if actions.ndim != 3 or actions.shape[-1] != 3:
        raise ValueError(f"Expected actions [B,H,3], got {tuple(actions.shape)}")

    latents = encode_frames(rae, frames)
    anchor_latent = latents[:, :num_cond]
    future_latents = latents[:, num_cond:]
    batch_size, horizon = actions.shape[:2]

    x_cond = anchor_latent
    x_start = future_latents.reshape(
        batch_size,
        horizon * future_latents.shape[2],
        *future_latents.shape[3:],
    )
    flat_actions = normalize_actions(
        actions,
        action_mean=action_mean,
        action_std=action_std,
        action_clip=action_clip,
    )
    rel_t = make_relative_times(
        batch_size,
        horizon,
        divisor=rel_time_divisor,
        device=actions.device,
        dtype=actions.dtype,
    )
    return ChunkBatch(
        anchor_latent=anchor_latent,
        future_latents=future_latents,
        x_cond=x_cond,
        x_start=x_start,
        actions=flat_actions,
        rel_t=rel_t,
    )


def prepare_parallel_rollout(
    anchor_frames: torch.Tensor,
    actions: torch.Tensor,
    rae,
    num_cond: int = 1,
    action_mean: list[float] | tuple[float, ...] | None = None,
    action_std: list[float] | tuple[float, ...] | None = None,
    action_clip: float | None = None,
    rel_time_divisor: float = 128.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Build one anchor plus four parallel action conditions without GT latents."""
    if anchor_frames.ndim != 5 or anchor_frames.shape[1] != num_cond:
        raise ValueError(
            f"Expected anchor frames [B,{num_cond},C,H,W], got {tuple(anchor_frames.shape)}"
        )
    if actions.ndim != 3 or actions.shape[-1] != 3:
        raise ValueError(f"Expected actions [B,H,3], got {tuple(actions.shape)}")
    anchor_latent = encode_frames(rae, anchor_frames)
    batch_size, horizon = actions.shape[:2]
    x_cond = anchor_latent
    flat_actions = normalize_actions(
        actions,
        action_mean=action_mean,
        action_std=action_std,
        action_clip=action_clip,
    )
    rel_t = make_relative_times(
        batch_size,
        horizon,
        divisor=rel_time_divisor,
        device=actions.device,
        dtype=actions.dtype,
    )
    return anchor_latent, x_cond, flat_actions, rel_t
