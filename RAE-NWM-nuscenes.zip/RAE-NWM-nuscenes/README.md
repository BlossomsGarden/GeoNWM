# RAE-NWM-nuscenes Baseline Spec

This folder records the nuScenes baseline contract for `RAE-NWM`.

## Locked Decisions

- 5 consecutive `CAM_FRONT` frames.
- 1 anchor latent + 4 future actions.
- 4 future latents predicted in one chunk.
- Native RAE latent width: 768, not 832.
- Input resolution: `512x512`.
- Encoder: DINOv3-B MLS=6.
- Decoder/stats: RAEv2 `imagenet/k6`.
- Goal input: removed.
- Training: keep the original diffusion / transport paradigm.
- Loss: equal-weight 4-step latent diffusion loss.
- Output: pure rollout RGB video only.
- DINOv3 processor files must live beside the encoder path; otherwise `RAE` falls back to ImageNet normalization.
- The remote smoke run used GPU 3 and the local `deltaworld` conda env.

## Data Contract

- `frames`: `[B, 5, 3, 512, 512]`
- `actions`: `[B, 4, 3]`
- Action meaning: `[dx, dy, dyaw]` in the previous ego frame.
- Crop/resize: DeltaTok-style principal-point aware square crop.

## Model Contract

- Anchor latent: `[B, 1, 768, 32, 32]`
- Future latents: `[B, 4, 768, 32, 32]`
- Diffusion state: `[B, 3072, 32, 32]`
- Rollout output: `[B, 4, 3, 512, 512]`

## Verified Smoke

- 7 pytest smoke tests passed on the remote server.
- Real nuScenes batch forward passed with:
  - `frames = (1, 5, 3, 512, 512)`
  - `actions = (1, 4, 3)`
  - `chunk.x_start = (1, 3072, 32, 32)`
  - `pred = (1, 4, 768, 32, 32)`
- Rollout video export succeeded.
- Remote smoke used the DINOv3 processor directory with `config.json` and `preprocessor_config.json` mirrored next to the encoder weights.
- Remote smoke passed with `pred = (1, 4, 768, 32, 32)` and a valid rollout MP4 output.
