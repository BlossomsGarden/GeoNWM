# RAE-NWM-nuscenes Implementation Plan

## Completed

- [x] Switch the baseline encoder to DINOv3-B MLS=6.
- [x] Keep the latent width at 768.
- [x] Use the RAEv2 `imagenet/k6` decoder and stats.
- [x] Align input preprocessing to 512 with principal-point aware crop/resize.
- [x] Build 5-frame `CAM_FRONT` nuScenes windows.
- [x] Remove future goal input entirely.
- [x] Predict 4 future latents in one parallel chunk.
- [x] Preserve the original diffusion / transport training recipe.
- [x] Use equal-weight 4-step latent diffusion loss.
- [x] Export pure rollout RGB video.
- [x] Update baseline entrypoints to the nuScenes config.
- [x] Remove DINOv2 defaults from the baseline path.
- [x] Mirror the DINOv3 processor files beside the encoder path.

## Verified

- [x] 7 remote pytest smoke tests passed.
- [x] Real nuScenes batch forward passed.
- [x] Rollout MP4 export passed.
- [x] Real batch smoke reran successfully after enforcing processor-path validation.

## Notes

- Legacy goal-based scripts and configs are still present for historical comparison.
- The baseline path itself does not use them.
