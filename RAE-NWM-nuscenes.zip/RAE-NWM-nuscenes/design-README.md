# RAE-NWM-nuscenes Baseline Spec

**Goal:** Build a nuScenes baseline for RAE-NWM that matches the DeltaTok 512 data contract and uses the RAEv2 DINOv3-B `k6` stage1 recipe, while keeping the original RAE-NWM diffusion training paradigm.

## Locked Decisions

- Dataset windows: 5 consecutive `CAM_FRONT` keyframes.
- Model input: 1 initial frame latent plus 4 future actions.
- Model output: 4 future latents in one parallel chunk.
- Action format: `[dx, dy, dyaw]`, measured in the previous ego frame, with yaw in degrees.
- Preprocessing: DeltaTok-style principal-point aware resize/crop to `512x512`.
- Stage1 encoder: DINOv3-B MLS=6, using `encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m-73cec8be.pth`.
- Stage1 processor config: `pretrained_models/encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m`.
- Stage1 decoder and stats: the public RAEv2 `imagenet` `k6` pair for now.
- Latent width: native DINOv3-B width, no conversion to 832.
- Training: keep the original RAE-NWM diffusion / transport recipe.
- Loss: equal-weight 4-step latent diffusion loss.
- Goal input: removed entirely.
- RGB output: frozen decode for visualization only, pure rollout, no GT comparison strip.

## Data Contract

- Return `frames [B, 5, 3, 512, 512]`.
- Return `actions [B, 4, 3]`.
- Keep only `CAM_FRONT` rows.
- Require consecutive `frame_id + 1` continuity inside every 5-frame window.
- Compute each action from adjacent `ego_pose` entries, always in the previous ego frame.
- The model context size is 1; the 5-frame window is supervision data, and the model conditions only on the first latent.

## Stage1 Contract

- Replace every legacy non-nuScenes path in `RAE-NWM-main`.
- Remove every encoder-specific image-size shortcut.
- Derive latent grid size from the encoder patch size, not from a hardcoded encoder-specific rule.
- For `512x512` with patch size `16`, the latent grid is `32 x 32 = 1024` tokens.
- The public `imagenet/k6` decoder and stats are released at a `16 x 16` latent grid; the baseline adapts the frozen decoder position embedding and per-location latent stats to `32 x 32`.
- Keep the stage1 encoder frozen during world-model training.
- Use the decoder/stat artifact that matches the public RAEv2 MLS=6 release; do not mix artifacts from another encoder setting.

## Diffusion Contract

- The denoising target is a horizon chunk, not a single future frame.
- Internal tensors should preserve the natural shapes:
  - anchor latent: `[B, N, 768]`
  - future target latents: `[B, 4, N, 768]`
- The diffusion state is the whole future chunk packed as `[B, 4*768, 32, 32]` for the existing spatial CDiT backbone, then reshaped back to `[B, 4, 768, 32, 32]` for decode and visualization.
- The action condition is the whole future action chunk `[B, 4, 3]`; the four future steps are not trained as independent per-step samples.
  - predicted chunk: `[B, 4, N, 768]`
- No autoregressive rollout training in this baseline.
- No future-goal branch, no future-goal loss, no future-goal evaluation.

## Training Notes

- Match the DeltaTok 512 input-size and crop/resize contract.
- Keep the RAE-NWM diffusion stack intact on top of that input contract.
- The exact internal action-conditioning block is an implementation detail, as long as the external contract stays `1 latent + 4 actions -> 4 future latents`.

## Implementation Boundary

Files that will likely change:

- `sources/RAE-NWM-main/RAE/src/stage1/encoders/`
- `sources/RAE-NWM-main/RAE/src/stage1/rae.py`
- `sources/RAE-NWM-main/train.py`
- `sources/RAE-NWM-main/models.py`
- `sources/RAE-NWM-main/datasets.py` or a new nuScenes dataset module
- `sources/RAE-NWM-main/config/`
- this folder's `README.md`

## Acceptance Checks

1. A train batch builds a 5-frame `CAM_FRONT` window at 512 and 4 actions.
2. Stage1 encode/decode works with DINOv3-B MLS=6 and 768-d latents.
3. The diffusion model predicts 4 future latents in one forward pass.
4. The saved rollout video is a pure predicted RGB rollout, not a GT comparison strip.
