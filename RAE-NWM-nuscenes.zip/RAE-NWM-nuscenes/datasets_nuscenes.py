from __future__ import annotations

import csv
import json
import logging
import math
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

try:
    import ijson
except ImportError:  # pragma: no cover - exercised only on minimal installs
    ijson = None


CAM_FRONT_NAMES = {"FRONT", "CAM_FRONT"}


def as_hw(frame_size: int | tuple[int, int]) -> tuple[int, int]:
    if isinstance(frame_size, int):
        return int(frame_size), int(frame_size)
    height, width = frame_size
    return int(height), int(width)


def resize_then_principal_crop(
    image: np.ndarray,
    intrinsics: np.ndarray | None,
    out_size: int | tuple[int, int],
) -> np.ndarray:
    """Match DeltaTok's short-edge resize and principal-point crop exactly."""
    out_h, out_w = as_hw(out_size)
    if out_h != out_w:
        raise ValueError("nuScenes preprocessing requires a square output")

    height, width = image.shape[:2]
    scale = out_h / min(height, width)
    resized_h = max(out_h, int(round(height * scale)))
    resized_w = max(out_w, int(round(width * scale)))
    resized = cv2.resize(image, (resized_w, resized_h), interpolation=cv2.INTER_AREA)

    if intrinsics is None:
        principal_x = resized_w / 2.0
        principal_y = resized_h / 2.0
    else:
        principal_x = float(intrinsics[0, 2]) * scale
        principal_y = float(intrinsics[1, 2]) * scale

    left = int(round(principal_x - out_w / 2.0))
    top = int(round(principal_y - out_h / 2.0))
    right = left + out_w
    bottom = top + out_h

    pad_left = max(0, -left)
    pad_top = max(0, -top)
    pad_right = max(0, right - resized_w)
    pad_bottom = max(0, bottom - resized_h)
    if pad_left or pad_top or pad_right or pad_bottom:
        resized = np.pad(
            resized,
            ((pad_top, pad_bottom), (pad_left, pad_right), (0, 0)),
            mode="edge",
        )
        left += pad_left
        top += pad_top

    return resized[top : top + out_h, left : left + out_w]


def _quat_to_rotation(quaternion: list[float]) -> np.ndarray:
    w, x, y, z = map(float, quaternion)
    return np.asarray(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def compute_action(prev_pose: dict[str, Any], curr_pose: dict[str, Any]) -> torch.Tensor:
    """Return [forward meters, left meters, relative yaw degrees]."""
    prev_rotation = _quat_to_rotation(prev_pose["rotation"])
    curr_rotation = _quat_to_rotation(curr_pose["rotation"])
    delta_global = np.asarray(curr_pose["translation"], dtype=np.float64) - np.asarray(
        prev_pose["translation"], dtype=np.float64
    )
    delta_prev = prev_rotation.T @ delta_global
    relative_rotation = prev_rotation.T @ curr_rotation
    delta_yaw = math.degrees(
        math.atan2(relative_rotation[1, 0], relative_rotation[0, 0])
    )
    return torch.tensor(
        [delta_prev[0], delta_prev[1], delta_yaw], dtype=torch.float32
    )


def _load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _load_selected_token_map(path: Path, tokens: set[str]) -> dict[str, dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"nuScenes metadata file not found: {path}")
    if ijson is None:
        items = _load_json(path)
        selected = {item["token"]: item for item in items if item.get("token") in tokens}
    else:
        selected = {}
        remaining = set(tokens)
        with path.open("rb") as handle:
            for item in ijson.items(handle, "item"):
                token = item.get("token")
                if token in remaining:
                    selected[token] = item
                    remaining.remove(token)
                    if not remaining:
                        break
    missing = tokens.difference(selected)
    if missing:
        examples = sorted(missing)[:5]
        raise KeyError(f"{path} is missing {len(missing)} requested poses; examples={examples}")
    return selected


def _load_token_map(path: Path) -> dict[str, dict[str, Any]]:
    return {item["token"]: item for item in _load_json(path)}


@lru_cache(maxsize=4)
def _load_cam_front_intrinsics(
    sample_data_path_str: str,
    calibrated_sensor_path_str: str,
) -> dict[str, np.ndarray]:
    sample_data_path = Path(sample_data_path_str)
    calibrated_sensor_path = Path(calibrated_sensor_path_str)
    if not sample_data_path.exists() or not calibrated_sensor_path.exists():
        return {}

    calibrated = _load_token_map(calibrated_sensor_path)
    result: dict[str, np.ndarray] = {}
    if ijson is None:
        items = _load_json(sample_data_path)
        iterator = iter(items)
    else:
        handle = sample_data_path.open("rb")
        iterator = ijson.items(handle, "item")

    try:
        for item in iterator:
            filename = str(item.get("filename", ""))
            if "CAM_FRONT" not in Path(filename).parts:
                continue
            sensor = calibrated.get(item.get("calibrated_sensor_token"))
            matrix = sensor.get("camera_intrinsic") if sensor else None
            if matrix is None:
                continue
            value = np.asarray(matrix, dtype=np.float32)
            result[filename] = value
            result[Path(filename).name] = value
    finally:
        if ijson is not None:
            handle.close()
    return result


@dataclass(frozen=True)
class SampleRow:
    sample_id: str
    scene_id: str
    frame_id: int
    file: str
    ego_pose_token: str


class _NuScenesSequenceDataset(Dataset):
    horizon = 4

    def __init__(
        self,
        csv_path: str,
        nuscenes_root: str,
        frame_size: int | tuple[int, int] = 512,
        ego_pose_path: str | None = None,
        sample_data_path: str | None = None,
        calibrated_sensor_path: str | None = None,
    ) -> None:
        self.csv_path = Path(csv_path)
        self.nuscenes_root = Path(nuscenes_root)
        self.frame_size = as_hw(frame_size)
        metadata_root = self.nuscenes_root / "v1.0-trainval"
        if not metadata_root.exists():
            metadata_root = self.nuscenes_root

        self.ego_pose_path = Path(ego_pose_path or metadata_root / "ego_pose.json")
        self.sample_data_path = Path(
            sample_data_path or metadata_root / "sample_data.json"
        )
        self.calibrated_sensor_path = Path(
            calibrated_sensor_path or metadata_root / "calibrated_sensor.json"
        )

        rows_by_scene = self._build_rows()
        pose_tokens = {
            row.ego_pose_token
            for rows in rows_by_scene.values()
            for row in rows
        }
        self.ego_poses = _load_selected_token_map(self.ego_pose_path, pose_tokens)
        self.intrinsics_by_file = _load_cam_front_intrinsics(
            str(self.sample_data_path.resolve()),
            str(self.calibrated_sensor_path.resolve()),
        )
        if not self.intrinsics_by_file:
            logging.warning(
                "No CAM_FRONT intrinsics loaded from %s; using centered crops",
                self.sample_data_path,
            )
        self.windows = self._build_windows(rows_by_scene)
        if not self.windows:
            raise ValueError(
                f"No consecutive 5-frame CAM_FRONT windows found in {self.csv_path}"
            )

    def _build_rows(self) -> dict[str, list[SampleRow]]:
        grouped: dict[str, list[SampleRow]] = {}
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            required = {"frame_id", "scene_id", "file", "ego_pose_token"}
            missing = required.difference(reader.fieldnames or ())
            if missing:
                raise ValueError(f"CSV is missing required columns: {sorted(missing)}")
            for raw in reader:
                cam = str(raw.get("cam", "CAM_FRONT")).upper()
                if cam not in CAM_FRONT_NAMES:
                    continue
                row = SampleRow(
                    sample_id=str(raw.get("id", raw["frame_id"])),
                    scene_id=str(raw["scene_id"]),
                    frame_id=int(raw["frame_id"]),
                    file=str(raw["file"]),
                    ego_pose_token=str(raw["ego_pose_token"]),
                )
                grouped.setdefault(row.scene_id, []).append(row)
        for rows in grouped.values():
            rows.sort(key=lambda row: row.frame_id)
        return grouped

    def _build_windows(
        self,
        rows_by_scene: dict[str, list[SampleRow]],
    ) -> list[tuple[SampleRow, ...]]:
        windows: list[tuple[SampleRow, ...]] = []
        for rows in rows_by_scene.values():
            for start in range(len(rows) - self.horizon):
                window = tuple(rows[start : start + self.horizon + 1])
                if all(
                    curr.frame_id == prev.frame_id + 1
                    for prev, curr in zip(window, window[1:])
                ):
                    windows.append(window)
        return windows

    def __len__(self) -> int:
        return len(self.windows)

    def _resolve_image_path(self, filename: str) -> Path:
        path = Path(filename)
        if path.is_absolute() and path.exists():
            return path
        candidates = (
            self.nuscenes_root / path,
            self.nuscenes_root / "samples" / "CAM_FRONT" / path.name,
        )
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(
            f"Could not resolve CSV image path {filename!r}; tried {candidates}"
        )

    def _load_frame(self, row: SampleRow) -> torch.Tensor:
        image_path = self._resolve_image_path(row.file)
        with Image.open(image_path) as image:
            image_np = np.asarray(image.convert("RGB"))
        intrinsic = self.intrinsics_by_file.get(row.file)
        if intrinsic is None:
            intrinsic = self.intrinsics_by_file.get(Path(row.file).name)
        image_np = resize_then_principal_crop(image_np, intrinsic, self.frame_size)
        return torch.from_numpy(image_np.copy()).permute(2, 0, 1).float().div(255.0)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        rows = self.windows[idx]
        frames = torch.stack([self._load_frame(row) for row in rows])
        actions = torch.stack(
            [
                compute_action(
                    self.ego_poses[prev.ego_pose_token],
                    self.ego_poses[curr.ego_pose_token],
                )
                for prev, curr in zip(rows, rows[1:])
            ]
        )
        return frames, actions


class NuScenesSequenceTrain(_NuScenesSequenceDataset):
    pass


class NuScenesSequenceVal(_NuScenesSequenceDataset):
    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor, int]:
        frames, actions = super().__getitem__(idx)
        return frames, actions, idx

