from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parent
RAE_SRC = PROJECT_ROOT / "RAE" / "src"
if str(RAE_SRC) not in sys.path:
    sys.path.insert(0, str(RAE_SRC))

from RAE.src.stage1.rae import RAE
from RAE.src.stage2.transport.transport import (
    ModelType,
    PathType,
    Sampler,
    Transport,
    WeightType,
)
from RAE.src.utils.model_utils import instantiate_from_config
from RAE.src.utils.train_utils import parse_configs
from datasets_nuscenes import NuScenesSequenceVal
from models import CDiT_models
from nuscenes_baseline import prepare_parallel_rollout


def save_image(output_path: str | Path, image: torch.Tensor) -> None:
    image = torch.nan_to_num(image.detach().float()).clamp(0.0, 1.0)
    array = (image.permute(1, 2, 0).cpu().numpy() * 255.0).round().astype(np.uint8)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output_path), cv2.cvtColor(array, cv2.COLOR_RGB2BGR))


def save_rollout_video(
    output_path: str | Path,
    frames: torch.Tensor,
    fps: int = 4,
) -> None:
    """Save only predicted rollout frames; no anchor or GT frames are appended."""
    if frames.ndim != 4 or frames.shape[1] != 3:
        raise ValueError(f"Expected frames [T,3,H,W], got {tuple(frames.shape)}")
    frames = torch.nan_to_num(frames.detach().float()).clamp(0.0, 1.0)
    array = (frames.permute(0, 2, 3, 1).cpu().numpy() * 255.0).round().astype(np.uint8)
    if array.shape[0] == 0:
        raise ValueError("Cannot save an empty rollout video")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    height, width = array.shape[1:3]
    writer = cv2.VideoWriter(
        str(output_path),
        cv2.VideoWriter_fourcc(*"mp4v"),
        float(fps),
        (int(width), int(height)),
    )
    if not writer.isOpened():
        raise RuntimeError(f"Could not open video writer for {output_path}")
    try:
        for frame in array:
            writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
    finally:
        writer.release()


def _load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def _resolve_path(path: str) -> str:
    candidate = Path(os.path.expandvars(os.path.expanduser(path)))
    if candidate.exists():
        return str(candidate)
    project_candidate = PROJECT_ROOT / candidate
    if project_candidate.exists():
        return str(project_candidate)
    return str(candidate)


def _build_models(config: dict, checkpoint_path: str, device: torch.device):
    stage1_path = _resolve_path(
        str(config.get("config_path", "RAE/configs/stage1/pretrained/DINOv3-B_512.yaml"))
    )
    rae_config, *_ = parse_configs(stage1_path)
    rae: RAE = instantiate_from_config(rae_config).to(device).eval()

    latent_size = int(rae.latent_grid_size)
    context_size = int(config.get("context_size", 1))
    if context_size != 1 or int(config.get("future_action_len", 4)) != 4:
        raise ValueError("The nuScenes baseline is fixed to context_size=1 and future_action_len=4")

    model_kwargs = {
        "context_size": context_size,
        "input_size": latent_size,
        "in_channels": int(rae.latent_dim) * int(config.get("future_action_len", 4)),
        "cond_channels": int(rae.latent_dim),
        "future_action_len": int(config.get("future_action_len", 4)),
        "learn_sigma": bool(config.get("learn_sigma", False)),
        "head_width": int(config.get("head_width", rae.latent_dim)),
        "head_depth": int(config.get("head_depth", 2)),
        "head_num_heads": int(config.get("head_num_heads", 16)),
    }
    try:
        model = CDiT_models[config["model"]](**model_kwargs)
    except TypeError:
        for key in ("head_width", "head_depth", "head_num_heads"):
            model_kwargs.pop(key, None)
        model = CDiT_models[config["model"]](**model_kwargs)

    checkpoint = torch.load(_resolve_path(checkpoint_path), map_location="cpu", weights_only=False)
    state = checkpoint.get("ema", checkpoint.get("model", checkpoint))
    state = {key.replace("_orig_mod.", ""): value for key, value in state.items()}
    incompatible = model.load_state_dict(state, strict=False)
    print(
        f"Loaded checkpoint: missing={len(incompatible.missing_keys)} "
        f"unexpected={len(incompatible.unexpected_keys)}"
    )
    model = model.to(device).eval()

    tp = config.get("transport", {})
    shift_dim = int(rae.latent_dim) * latent_size * latent_size
    shift_base = float(tp.get("time_dist_shift_base", 4096))
    time_dist_shift = (shift_dim / shift_base) ** 0.5
    if tp.get("time_dist_shift") is not None:
        time_dist_shift = float(tp["time_dist_shift"])
    if bool(tp.get("time_dist_shift_disable", False)):
        time_dist_shift = 1.0
    transport = Transport(
        model_type=getattr(ModelType, str(tp.get("model_type", "velocity")).upper()),
        path_type=getattr(PathType, str(tp.get("path_type", "linear")).upper()),
        loss_type=getattr(WeightType, str(tp.get("loss_type", "velocity")).upper()),
        time_dist_type=str(tp.get("time_dist_type", "uniform")),
        time_dist_shift=time_dist_shift,
        train_eps=1e-3,
        sample_eps=1e-3,
    )
    sampler = Sampler(transport)
    return model, rae, sampler


@torch.no_grad()
def predict_parallel_chunk(
    model,
    rae,
    sampler,
    frames: torch.Tensor,
    actions: torch.Tensor,
    config: dict,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    action_cfg = config.get("action", {})
    anchor_latent, x_cond, action_cond, rel_t = prepare_parallel_rollout(
        frames[:, :1].to(device),
        actions.to(device),
        rae,
        num_cond=1,
        action_mean=action_cfg.get("mean"),
        action_std=action_cfg.get("std"),
        action_clip=action_cfg.get("clip", 3.0),
        rel_time_divisor=float(config.get("rel_time_divisor", 128.0)),
    )
    batch_size, horizon = actions.shape[:2]
    latent_shape = (
        batch_size,
        horizon * int(rae.latent_dim),
        int(rae.latent_grid_size),
        int(rae.latent_grid_size),
    )
    init = torch.randn(latent_shape, device=device, dtype=anchor_latent.dtype)
    transport_cfg = config.get("transport", {})
    sample_fn = sampler.sample_ode(
        sampling_method=str(transport_cfg.get("sampling_method", "euler")),
        num_steps=int(transport_cfg.get("num_steps", 50)),
        atol=1e-6,
        rtol=1e-3,
        reverse=False,
    )
    samples = sample_fn(init, model, y=action_cond, x_cond=x_cond, rel_t=rel_t)[-1]
    predicted_latents = samples.reshape(
        batch_size,
        horizon,
        int(rae.latent_dim),
        int(rae.latent_grid_size),
        int(rae.latent_grid_size),
    )
    predicted_rgb = rae.decode(predicted_latents.flatten(0, 1)).float().clamp(0.0, 1.0)
    predicted_rgb = predicted_rgb.reshape(batch_size, horizon, *predicted_rgb.shape[1:])
    return predicted_latents, predicted_rgb


def main(args: argparse.Namespace) -> None:
    config = _load_config(args.config)
    if str(config.get("dataset_type", "")).lower() != "nuscenes":
        raise ValueError("infer_nuscenes.py requires a config with dataset_type: nuscenes")
    if not torch.cuda.is_available():
        raise RuntimeError("nuScenes inference requires a CUDA device")
    device = torch.device(args.device)
    model, rae, sampler = _build_models(config, args.checkpoint, device)

    data_cfg = config["nuscenes"]
    dataset = NuScenesSequenceVal(
        csv_path=str(data_cfg["val_csv_path"]),
        nuscenes_root=str(data_cfg["nuscenes_root"]),
        frame_size=int(config["image_size"]),
        ego_pose_path=data_cfg.get("ego_pose_path"),
        sample_data_path=data_cfg.get("sample_data_path"),
        calibrated_sensor_path=data_cfg.get("calibrated_sensor_path"),
    )
    loader = DataLoader(
        dataset,
        batch_size=int(args.batch_size),
        shuffle=False,
        num_workers=int(args.num_workers),
        pin_memory=True,
        drop_last=False,
        persistent_workers=int(args.num_workers) > 0,
    )

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    saved = 0
    for frames, actions, sample_indices in loader:
        if args.max_ids > 0:
            remaining = args.max_ids - saved
            if remaining <= 0:
                break
            frames = frames[:remaining]
            actions = actions[:remaining]
            sample_indices = sample_indices[:remaining]

        _, predicted_rgb = predict_parallel_chunk(
            model, rae, sampler, frames, actions, config, device
        )
        for batch_idx, sample_idx in enumerate(sample_indices.tolist()):
            sample_dir = output_dir / f"id_{int(sample_idx)}"
            sample_dir.mkdir(parents=True, exist_ok=True)
            rollout = predicted_rgb[batch_idx].cpu()
            for future_idx, frame in enumerate(rollout):
                save_image(sample_dir / f"future_{future_idx + 1}.png", frame)
            save_rollout_video(sample_dir / "rollout.mp4", rollout, fps=int(args.fps))
            saved += 1
        print(f"saved={saved}")
        if args.max_ids > 0 and saved >= args.max_ids:
            break


def get_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--fps", type=int, default=4)
    parser.add_argument("--max-ids", type=int, default=0)
    return parser


if __name__ == "__main__":
    main(get_parser().parse_args())
