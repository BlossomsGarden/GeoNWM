from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

import torch
from torch import nn

from . import register_encoder


DINOV3_HUB_REF = "facebookresearch/dinov3:94a96ac83c2446f15f9bdcfae23cad3c6a9d4988"
MODEL_NAMES = {"dinov3_vitb16"}
DEFAULT_LAYER_INDICES = [6, 7, 8, 9, 10, 11]


@contextmanager
def _rank0_first():
    """Gate torch.hub download so only rank 0 fetches, others wait then read cache."""
    initialized = torch.distributed.is_available() and torch.distributed.is_initialized()
    rank = torch.distributed.get_rank() if initialized else 0
    if initialized and rank != 0:
        torch.distributed.barrier()
    try:
        yield
    finally:
        if initialized and rank == 0:
            torch.distributed.barrier()


def load_dinov3(model_name: str, weights: str):
    if model_name not in MODEL_NAMES:
        raise ValueError(f"Unknown DINOv3 model name: {model_name}")

    expanded = os.path.expandvars(os.path.expanduser(weights))
    ckpt = Path(expanded)
    if not ckpt.is_file() and expanded.startswith("pretrained_models/"):
        model_root = os.environ.get("RAE_NWM_MODEL_DIR")
        if model_root:
            ckpt = Path(model_root) / expanded.removeprefix("pretrained_models/")
    if not ckpt.is_file():
        project_root = Path(__file__).resolve().parents[4]
        project_candidate = project_root / expanded
        if project_candidate.is_file():
            ckpt = project_candidate
    if not ckpt.is_file():
        raise FileNotFoundError(f"Missing DINOv3 weights: {ckpt}")

    repo_dir = os.environ.get("DINOV3_REPO_DIR")
    with _rank0_first():
        if repo_dir and Path(repo_dir, "hubconf.py").is_file():
            return torch.hub.load(
                repo_dir,
                model_name,
                source="local",
                trust_repo=True,
                skip_validation=True,
                weights=str(ckpt),
            )
        return torch.hub.load(
            DINOV3_HUB_REF,
            model_name,
            source="github",
            trust_repo=True,
            skip_validation=True,
            weights=str(ckpt),
        )


@register_encoder()
class DINOv3MLSWithNorm(nn.Module):
    def __init__(
        self,
        dinov3_path: str,
        normalize: bool = True,
        layer_indices: Optional[list[int]] = None,
        model_name: str = "dinov3_vitb16",
    ):
        super().__init__()
        self.model_name = model_name
        self.encoder = load_dinov3(self.model_name, dinov3_path)
        self.encoder.requires_grad_(False)

        self.hidden_size = int(self.encoder.embed_dim)
        self.patch_size = int(self.encoder.patch_size)
        self.layer_indices = [int(i) for i in (layer_indices or DEFAULT_LAYER_INDICES)]

        if normalize and hasattr(self.encoder, "norm"):
            self.encoder.norm = nn.LayerNorm(self.hidden_size, elementwise_affine=False)

    @torch.no_grad()
    def forward(self, images: torch.Tensor) -> torch.Tensor:
        outputs = self.encoder.get_intermediate_layers(
            images,
            n=self.layer_indices,
            reshape=False,
            return_class_token=False,
            norm=True,
        )
        # MLS=6 here means the sum of the final six normalized patch layers,
        # matching the requested RAEv2 DINOv3-B recipe.
        return torch.stack(outputs, dim=0).sum(dim=0)
