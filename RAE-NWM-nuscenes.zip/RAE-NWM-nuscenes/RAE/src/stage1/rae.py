import os
from pathlib import Path

import torch
import torch.nn as nn
from .decoders import GeneralDecoder
from .encoders import ARCHS
from transformers import AutoConfig, AutoImageProcessor
from typing import Optional
from math import sqrt
from typing import Protocol


def _resolve_local_path(path: Optional[str]) -> Optional[str]:
    if path is None:
        return None
    expanded = os.path.expandvars(os.path.expanduser(str(path)))
    candidate = Path(expanded)
    if candidate.exists():
        return str(candidate)

    model_root = os.environ.get("RAE_NWM_MODEL_DIR")
    if model_root and expanded.startswith("pretrained_models/"):
        candidate = Path(model_root) / expanded.removeprefix("pretrained_models/")
        if candidate.exists():
            return str(candidate)

    project_root = Path(__file__).resolve().parents[2]
    for root in (Path.cwd(), project_root):
        candidate = root / expanded
        if candidate.exists():
            return str(candidate)
    return expanded


def _resize_decoder_pos_embed(
    position_embedding: torch.Tensor,
    target_patches: int,
) -> torch.Tensor:
    """Resize frozen decoder 2D sine/cos positions to the target latent grid."""
    source_patches = int(position_embedding.shape[1] - 1)
    source_grid = int(sqrt(source_patches))
    target_grid = int(sqrt(target_patches))
    if source_grid * source_grid != source_patches:
        raise ValueError(f"Decoder position count is not square: {source_patches}")
    if target_grid * target_grid != target_patches:
        raise ValueError(f"Target latent patch count is not square: {target_patches}")
    if source_grid == target_grid:
        return position_embedding

    cls = position_embedding[:, :1]
    patch = position_embedding[:, 1:].transpose(1, 2).reshape(
        position_embedding.shape[0], position_embedding.shape[2], source_grid, source_grid
    )
    patch = nn.functional.interpolate(
        patch,
        size=(target_grid, target_grid),
        mode="bicubic",
        align_corners=False,
    )
    patch = patch.flatten(2).transpose(1, 2)
    return torch.cat((cls, patch), dim=1)


def _resize_latent_stat(stat: Optional[torch.Tensor], target_grid: int) -> Optional[torch.Tensor]:
    """Adapt 256px per-location stats to the 512px latent grid when needed."""
    if stat is None or not torch.is_tensor(stat) or stat.ndim < 3:
        return stat
    if tuple(stat.shape[-2:]) == (target_grid, target_grid):
        return stat
    if stat.ndim == 3:
        resized = nn.functional.interpolate(
            stat.unsqueeze(0).float(),
            size=(target_grid, target_grid),
            mode="bilinear",
            align_corners=False,
        ).squeeze(0)
    elif stat.ndim == 4:
        resized = nn.functional.interpolate(
            stat.float(),
            size=(target_grid, target_grid),
            mode="bilinear",
            align_corners=False,
        )
    else:
        raise ValueError(f"Unsupported latent-stat shape: {tuple(stat.shape)}")
    return resized.to(dtype=stat.dtype)

class Stage1Protocal(Protocol):
    # must have patch size attribute
    patch_size: int
    hidden_size: int 
    def encode(self, x: torch.Tensor) -> torch.Tensor:
        ...

class RAE(nn.Module):
    def __init__(self, 
        # ---- encoder configs ----
        encoder_cls: str = 'DINOv3MLSWithNorm',
        encoder_config_path: str = 'pretrained_models/encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m',
        encoder_input_size: int = 512,
        encoder_params: Optional[dict] = None,
        # ---- decoder configs ----
        decoder_config_path: str = 'RAE/configs/decoder/ViTXL',
        decoder_patch_size: int = 16,
        pretrained_decoder_path: Optional[str] = 'pretrained_models/stage1/imagenet/dinov3b-k6/decoder.pt',
        # ---- noising, reshaping and normalization-----
        noise_tau: float = 0.8,
        reshape_to_2d: bool = True,
        normalization_stat_path: Optional[str] = 'pretrained_models/stage1/imagenet/dinov3b-k6/stats.pt',
        decoder_output_normalized: bool = False,
        eps: float = 1e-5,
    ):
        super().__init__()
        encoder_cls = ARCHS[encoder_cls]
        base_encoder_params = {
            'dinov3_path': 'pretrained_models/encoders/dinov3/dinov3_vitb16_pretrain_lvd1689m-73cec8be.pth',
            'normalize': True,
            'layer_indices': [6, 7, 8, 9, 10, 11],
        }
        encoder_params = {**base_encoder_params, **(encoder_params or {})}
        self.encoder: Stage1Protocal = encoder_cls(**encoder_params)
        encoder_config_path = _resolve_local_path(encoder_config_path)
        decoder_config_path = _resolve_local_path(decoder_config_path)
        pretrained_decoder_path = _resolve_local_path(pretrained_decoder_path)
        normalization_stat_path = _resolve_local_path(normalization_stat_path)
        print(f"encoder_config_path: {encoder_config_path}")
        default_mean = (0.485, 0.456, 0.406)
        default_std = (0.229, 0.224, 0.225)
        try:
            proc = AutoImageProcessor.from_pretrained(
                encoder_config_path,
                local_files_only=True,
            )
            image_mean = tuple(proc.image_mean)
            image_std = tuple(proc.image_std)
        except Exception as exc:
            if "dinov3" in str(encoder_config_path).lower():
                raise FileNotFoundError(
                    f"Could not load the DINOv3 image processor from {encoder_config_path}. "
                    "Mirror config.json and preprocessor_config.json beside the encoder path."
                ) from exc
            print(f"Falling back to ImageNet normalization for {encoder_config_path}: {exc}")
            image_mean = default_mean
            image_std = default_std
        self.encoder_mean = torch.tensor(image_mean).view(1, 3, 1, 1)
        self.encoder_std = torch.tensor(image_std).view(1, 3, 1, 1)
        # see if the encoder has patch size attribute            
        self.encoder_input_size = encoder_input_size
        self.encoder_patch_size = self.encoder.patch_size
        self.latent_dim = self.encoder.hidden_size
        assert self.encoder_input_size % self.encoder_patch_size == 0, f"encoder_input_size {self.encoder_input_size} must be divisible by encoder_patch_size {self.encoder_patch_size}"
        self.latent_grid_size = self.encoder_input_size // self.encoder_patch_size
        self.base_patches = self.latent_grid_size ** 2 # number of patches of the latent
        
        # decoder
        decoder_config = AutoConfig.from_pretrained(decoder_config_path)
        decoder_config.hidden_size = self.latent_dim # set the hidden size of the decoder to be the same as the encoder's output
        decoder_config.patch_size = decoder_patch_size
        decoder_config.image_size = int(decoder_patch_size * self.latent_grid_size)
        self.decoder = GeneralDecoder(decoder_config, num_patches=self.base_patches)
        # load pretrained decoder weights
        if pretrained_decoder_path is not None:
            print(f"Loading pretrained decoder from {pretrained_decoder_path}")
            state_dict = torch.load(pretrained_decoder_path, map_location='cpu', weights_only=False)
            checkpoint_pos = state_dict.get("decoder_pos_embed")
            if checkpoint_pos is not None and checkpoint_pos.shape != self.decoder.decoder_pos_embed.shape:
                state_dict = dict(state_dict)
                state_dict["decoder_pos_embed"] = _resize_decoder_pos_embed(
                    checkpoint_pos,
                    self.base_patches,
                )
            keys = self.decoder.load_state_dict(state_dict, strict=False)
            if len(keys.missing_keys) > 0:
                print(f"Missing keys when loading pretrained decoder: {keys.missing_keys}")
        self.noise_tau = noise_tau
        self.reshape_to_2d = reshape_to_2d
        if normalization_stat_path is not None:
            stats = torch.load(normalization_stat_path, map_location='cpu', weights_only=False)
            self.latent_mean = _resize_latent_stat(stats.get('mean', None), self.latent_grid_size)
            self.latent_var = _resize_latent_stat(stats.get('var', None), self.latent_grid_size)
            self.do_normalization = True
            self.eps = eps
            print(f"Loaded normalization stats from {normalization_stat_path}")
        else:
            self.do_normalization = False
        self.decoder_output_normalized = bool(decoder_output_normalized)
    def noising(self, x: torch.Tensor) -> torch.Tensor:
        noise_sigma = self.noise_tau * torch.rand((x.size(0),) + (1,) * (len(x.shape) - 1), device=x.device)
        noise = noise_sigma * torch.randn_like(x)
        return x + noise

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        # normalize input
        _, _, h, w = x.shape
        if h != self.encoder_input_size or w != self.encoder_input_size:
            x = nn.functional.interpolate(x, size=(self.encoder_input_size, self.encoder_input_size), mode='bicubic', align_corners=False)
        x = (x - self.encoder_mean.to(x.device)) / self.encoder_std.to(x.device)
        z = self.encoder(x)
        if self.training and self.noise_tau > 0:
            z = self.noising(z)
        if self.reshape_to_2d:
            b, n, c = z.shape
            h = w = int(sqrt(n))
            z = z.transpose(1, 2).view(b, c, h, w)
        if self.do_normalization:
            latent_mean = self.latent_mean.to(z.device) if self.latent_mean is not None else 0
            latent_var = self.latent_var.to(z.device) if self.latent_var is not None else 1
            z = (z - latent_mean) / torch.sqrt(latent_var + self.eps)
        return z
    
    def decode(self, z: torch.Tensor) -> torch.Tensor:
        if self.do_normalization:
            latent_mean = self.latent_mean.to(z.device) if self.latent_mean is not None else 0
            latent_var = self.latent_var.to(z.device) if self.latent_var is not None else 1
            z = z * torch.sqrt(latent_var + self.eps) + latent_mean
        if self.reshape_to_2d:
            b, c, h, w = z.shape
            n = h * w
            z = z.view(b, c, n).transpose(1, 2)
        output = self.decoder(z, drop_cls_token=False).logits
        x_rec = self.decoder.unpatchify(output)
        if self.decoder_output_normalized:
            x_rec = x_rec * self.encoder_std.to(x_rec.device) + self.encoder_mean.to(x_rec.device)
        return x_rec
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encode(x)
        x_rec = self.decode(z)
        return x_rec
